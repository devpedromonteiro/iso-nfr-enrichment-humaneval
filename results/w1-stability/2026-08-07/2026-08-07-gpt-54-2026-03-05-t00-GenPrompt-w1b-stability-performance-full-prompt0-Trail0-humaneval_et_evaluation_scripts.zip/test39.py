
import unittest



def prime_fib(n: int):
    """
    prime_fib returns n-th number that is a Fibonacci number and it's also prime.
    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """
    if n < 1:
        raise ValueError("n must be a positive integer")

    # All prime Fibonacci numbers are F_p where p is prime, except F_4 = 3.
    # We count: 2(F_3), 3(F_4), 5(F_5), 13(F_7), 89(F_11), ...
    if n == 1:
        return 2
    if n == 2:
        return 3

    def is_prime(x: int) -> bool:
        if x < 2:
            return False
        if x % 2 == 0:
            return x == 2
        if x % 3 == 0:
            return x == 3
        i = 5
        while i * i <= x:
            if x % i == 0 or x % (i + 2) == 0:
                return False
            i += 6
        return True

    def fib_fast_doubling(k: int) -> int:
        def fd(m: int):
            if m == 0:
                return 0, 1
            a, b = fd(m >> 1)
            c = a * ((b << 1) - a)
            d = a * a + b * b
            if m & 1:
                return d, c + d
            return c, d
        return fd(k)[0]

    count = 2  # already counted 2 and 3
    candidate = 5  # prime indices to test: 5, 7, 11, 13, ...

    while True:
        if is_prime(candidate):
            f = fib_fast_doubling(candidate)
            if is_prime(f):
                count += 1
                if count == n:
                    return f
        candidate += 2
candidate = prime_fib


class Test(unittest.TestCase):
    def test(self):
        assert candidate(2) == 3
        assert candidate(12) == 99194853094755497
        assert candidate(6) == 233
        assert candidate(10) == 433494437
        assert candidate(3) == 5
        assert candidate(5) == 89
        assert candidate(8) == 28657
        assert candidate(11) == 2971215073
        assert candidate(1) == 2
        assert candidate(4) == 13
        assert candidate(9) == 514229
        assert candidate(7) == 1597

if __name__ == '__main__':
    unittest.main()
