
import unittest
import re
import sys
import math
import copy



def largest_prime_factor(n: int):
    """Return the largest prime factor of n. Assume n > 1 and is not a prime.
    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    largest = None

    # Remove factor 2 first so we can skip even numbers later.
    while n % 2 == 0:
        largest = 2
        n //= 2

    factor = 3
    # Only test odd factors up to sqrt(n). As n shrinks, so does the limit.
    while factor * factor <= n:
        while n % factor == 0:
            largest = factor
            n //= factor
        factor += 2

    # If n > 1 here, then n itself is prime and larger than any factor found.
    return n if n > 1 else largest
candidate = largest_prime_factor




METADATA = {}


def check(candidate):
    assert candidate(15) == 5
    assert candidate(27) == 3
    assert candidate(63) == 7
    assert candidate(330) == 11
    assert candidate(13195) == 29



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
