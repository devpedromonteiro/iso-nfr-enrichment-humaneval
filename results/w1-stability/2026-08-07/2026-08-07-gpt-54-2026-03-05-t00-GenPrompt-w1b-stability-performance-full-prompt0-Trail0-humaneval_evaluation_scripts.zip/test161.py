
import unittest
import re
import sys
import math
import copy


def solve(s):
    has_letter = False
    out = []

    for ch in s:
        o = ord(ch)
        if 65 <= o <= 90:          # A-Z
            out.append(chr(o + 32))
            has_letter = True
        elif 97 <= o <= 122:       # a-z
            out.append(chr(o - 32))
            has_letter = True
        else:
            out.append(ch)

    return ''.join(out) if has_letter else s[::-1]
candidate = solve


def check(candidate):

    # Check some simple cases
    assert candidate("AsDf") == "aSdF"
    assert candidate("1234") == "4321"
    assert candidate("ab") == "AB"
    assert candidate("#a@C") == "#A@c"
    assert candidate("#AsdfW^45") == "#aSDFw^45"
    assert candidate("#6@2") == "2@6#"

    # Check some edge cases that are easy to work out by hand.
    assert candidate("#$a^D") == "#$A^d"
    assert candidate("#ccc") == "#CCC"

    # Don't remove this line:


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
