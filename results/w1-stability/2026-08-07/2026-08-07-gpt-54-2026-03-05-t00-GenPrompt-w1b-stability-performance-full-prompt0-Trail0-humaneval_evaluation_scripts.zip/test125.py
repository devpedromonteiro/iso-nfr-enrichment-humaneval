
import unittest
import re
import sys
import math
import copy


def split_words(txt):
    """
    Given a string of words, return a list of words split on whitespace.
    If no whitespace exists in the text, split on commas ','.
    If no commas exist, return the number of lower-case letters with odd
    order in the alphabet: a=0, b=1, ..., z=25.
    """
    if ' ' in txt or '	' in txt or '
candidate = split_words


def check(candidate):

    assert candidate("Hello world!") == ["Hello","world!"]
    assert candidate("Hello,world!") == ["Hello","world!"]
    assert candidate("Hello world,!") == ["Hello","world,!"]
    assert candidate("Hello,Hello,world !") == ["Hello,Hello,world","!"]
    assert candidate("abcdef") == 3
    assert candidate("aaabb") == 2
    assert candidate("aaaBb") == 1
    assert candidate("") == 0


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
