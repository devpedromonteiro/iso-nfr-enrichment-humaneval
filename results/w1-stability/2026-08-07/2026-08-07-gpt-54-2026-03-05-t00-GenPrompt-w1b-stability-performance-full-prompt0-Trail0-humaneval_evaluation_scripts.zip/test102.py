
import unittest
import re
import sys
import math
import copy


def choose_num(x, y):
    """Return the largest even integer in the inclusive range [x, y].
    If no such number exists, return -1.
    """
    if x > y:
        return -1
    return y if y % 2 == 0 else y - 1 if y - 1 >= x else -1
candidate = choose_num


def check(candidate):

    # Check some simple cases
    assert candidate(12, 15) == 14
    assert candidate(13, 12) == -1
    assert candidate(33, 12354) == 12354
    assert candidate(5234, 5233) == -1
    assert candidate(6, 29) == 28
    assert candidate(27, 10) == -1

    # Check some edge cases that are easy to work out by hand.
    assert candidate(7, 7) == -1
    assert candidate(546, 546) == 546



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
