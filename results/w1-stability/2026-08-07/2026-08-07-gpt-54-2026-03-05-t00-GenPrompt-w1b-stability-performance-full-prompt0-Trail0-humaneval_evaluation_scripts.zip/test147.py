
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    You are given a positive integer n. Create an array a of length n where:
        a[i] = i*i - i + 1   for 1 <= i <= n

    Return the number of triples (a[i], a[j], a[k]) with i < j < k such that
    a[i] + a[j] + a[k] is divisible by 3.

    Example:
        n = 5
        a = [1, 3, 7, 13, 21]
        Valid triple count = 1
    """
    # a[i] = i^2 - i + 1 = i(i-1) + 1
    # Since i(i-1) is always divisible by 2, but we care about mod 3:
    #
    # i % 3 == 0 -> a[i] % 3 = 1
    # i % 3 == 1 -> a[i] % 3 = 1
    # i % 3 == 2 -> a[i] % 3 = 0
    #
    # So values contribute residues:
    # - residue 1 for indices not congruent to 2 mod 3
    # - residue 0 for indices congruent to 2 mod 3
    #
    # A triple sum is divisible by 3 only if residues are:
    # (0,0,0) or (1,1,1)
    #
    # Let:
    # c0 = count of indices i in [1..n] with i % 3 == 2
    # c1 = n - c0
    #
    # Answer = C(c0, 3) + C(c1, 3)

    c0 = (n + 1) // 3   # count of numbers in [1..n] congruent to 2 mod 3
    c1 = n - c0

    def comb3(x):
        return x * (x - 1) * (x - 2) // 6 if x >= 3 else 0

    return comb3(c0) + comb3(c1)
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
