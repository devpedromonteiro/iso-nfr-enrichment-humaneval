
import unittest
import re
import sys
import math
import copy


def numerical_letter_grade(grades):
    return [
        'A+' if g == 4.0 else
        'A'  if g > 3.7 else
        'A-' if g > 3.3 else
        'B+' if g > 3.0 else
        'B'  if g > 2.7 else
        'B-' if g > 2.3 else
        'C+' if g > 2.0 else
        'C'  if g > 1.7 else
        'C-' if g > 1.3 else
        'D+' if g > 1.0 else
        'D'  if g > 0.7 else
        'D-' if g > 0.0 else
        'E'
        for g in grades
    ]
candidate = numerical_letter_grade


def check(candidate):

    # Check some simple cases
    assert candidate([4.0, 3, 1.7, 2, 3.5]) == ['A+', 'B', 'C-', 'C', 'A-']
    assert candidate([1.2]) == ['D+']
    assert candidate([0.5]) == ['D-']
    assert candidate([0.0]) == ['E']
    assert candidate([1, 0.3, 1.5, 2.8, 3.3]) == ['D', 'D-', 'C-', 'B', 'B+']
    assert candidate([0, 0.7]) == ['E', 'D-']

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
