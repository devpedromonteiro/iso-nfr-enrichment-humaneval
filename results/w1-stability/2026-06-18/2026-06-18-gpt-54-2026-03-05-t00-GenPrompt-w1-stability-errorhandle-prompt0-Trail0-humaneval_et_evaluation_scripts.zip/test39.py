
import unittest



def prime_fib(n: int):
    """
    Return the n-th Fibonacci number that is also prime.

    Prime Fibonacci sequence:
    2, 3, 5, 13, 89, ...

    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """
    # Type validation
    if not isinstance(n, int):
        raise TypeError("n must be an integer")

    # Value validation
    if n <= 0:
        raise ValueError("n must be a positive integer")

    def is_prime(num: int) -> bool:
        """Check whether num is prime."""
        if num < 2:
            return False
        if num == 2:
            return True
        if num % 2 == 0:
            return False

        i = 3
        while i * i <= num:
            if num % i == 0:
                return False
            i += 2
        return True

    count = 0
    a, b = 0, 1

    try:
        while True:
            a, b = b, a + b
            if is_prime(a):
                count += 1
                if count == n:
                    return a
    except OverflowError as e:
        raise OverflowError("Number grew too large during Fibonacci computation") from e
    except Exception as e:
        raise RuntimeError(f"Unexpected error while computing prime Fibonacci: {e}") from e
candidate = prime_fib


class Test(unittest.TestCase):
    def test(self):
        assert candidate(2) == 3
        assert candidate(12) == 99194853094755497
        assert candidate(6) == 233
        assert candidate(10) == 433494437
        assert candidate(3) == 5
        assert candidate(5) == 89
        assert candidate(8) == 28657
        assert candidate(11) == 2971215073
        assert candidate(1) == 2
        assert candidate(4) == 13
        assert candidate(9) == 514229
        assert candidate(7) == 1597

if __name__ == '__main__':
    unittest.main()
