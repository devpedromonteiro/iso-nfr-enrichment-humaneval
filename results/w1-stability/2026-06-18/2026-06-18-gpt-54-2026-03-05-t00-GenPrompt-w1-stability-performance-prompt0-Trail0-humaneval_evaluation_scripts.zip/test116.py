
import unittest
import re
import sys
import math
import copy


def sort_array(arr):
    """
    Sort integers by:
    1. Number of 1s in their binary representation (ascending)
    2. Decimal value (ascending) when counts are equal

    Examples:
    >>> sort_array([1, 5, 2, 3, 4])
    [1, 2, 4, 3, 5]
    >>> sort_array([-2, -3, -4, -5, -6])
    [-4, -2, -6, -5, -3]
    >>> sort_array([1, 0, 2, 3, 4])
    [0, 1, 2, 4, 3]
    """
    return sorted(arr, key=lambda x: (x.bit_count(), x))
candidate = sort_array


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,5,2,3,4]) == [1, 2, 4, 3, 5]
    assert candidate([-2,-3,-4,-5,-6]) == [-4, -2, -6, -5, -3]
    assert candidate([1,0,2,3,4]) == [0, 1, 2, 4, 3]
    assert candidate([]) == []
    assert candidate([2,5,77,4,5,3,5,7,2,3,4]) == [2, 2, 4, 4, 3, 3, 5, 5, 5, 7, 77]
    assert candidate([3,6,44,12,32,5]) == [32, 3, 5, 6, 12, 44]
    assert candidate([2,4,8,16,32]) == [2, 4, 8, 16, 32]
    assert candidate([2,4,8,16,32]) == [2, 4, 8, 16, 32]

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
