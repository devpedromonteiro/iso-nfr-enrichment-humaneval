
import unittest
import re
import sys
import math
import copy


def f(n):
    """Return a list of length n where:
    - at 1-based odd positions i, the value is 1 + 2 + ... + i
    - at 1-based even positions i, the value is i!

    Example:
    f(5) == [1, 2, 6, 24, 15]
    """
    result = [0] * n
    fact = 1
    summ = 0

    for i in range(1, n + 1):
        fact *= i
        summ += i
        result[i - 1] = fact if i % 2 == 0 else summ

    return result
candidate = f


def check(candidate):

    assert candidate(5) == [1, 2, 6, 24, 15]
    assert candidate(7) == [1, 2, 6, 24, 15, 720, 28]
    assert candidate(1) == [1]
    assert candidate(3) == [1, 2, 6]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
