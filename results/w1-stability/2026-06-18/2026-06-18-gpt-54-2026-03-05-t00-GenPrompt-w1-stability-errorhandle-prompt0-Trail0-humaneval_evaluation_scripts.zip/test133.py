
import unittest
import re
import sys
import math
import copy



import math

def sum_squares(lst):
    """Return the sum of squares of the elements in lst after rounding
    each element up using math.ceil().

    Examples:
    [1, 2, 3] -> 14
    [1, 4, 9] -> 98
    [1, 3, 5, 7] -> 84
    [1.4, 4.2, 0] -> 29
    [-2.4, 1, 1] -> 6
    """
    try:
        if lst is None:
            raise ValueError("Input cannot be None.")
        if not isinstance(lst, (list, tuple)):
            raise TypeError("Input must be a list or tuple.")

        total = 0
        for i, x in enumerate(lst):
            try:
                if not isinstance(x, (int, float)):
                    raise TypeError(f"Element at index {i} is not a number: {x}")
                total += math.ceil(x) ** 2
            except TypeError as e:
                raise TypeError(f"Invalid element in input: {e}")

        return total

    except Exception as e:
        raise e
candidate = sum_squares


def check(candidate):

    # Check some simple cases
    assert candidate([1,2,3])==14, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1.0,2,3])==14, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,3,5,7])==84, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1.4,4.2,0])==29, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([-2.4,1,1])==6, "This prints if this assert fails 1 (good for debugging!)"

    assert candidate([100,1,15,2])==10230, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([10000,10000])==200000000, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([-1.4,4.6,6.3])==75, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([-1.4,17.9,18.9,19.9])==1086, "This prints if this assert fails 1 (good for debugging!)"


    # Check some edge cases that are easy to work out by hand.
    assert candidate([0])==0, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([-1])==1, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([-1,1,0])==2, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
