
import unittest
import re
import sys
import math
import copy



def remove_vowels(text):
    """
    remove_vowels is a function that takes string and returns string without vowels.

    Error handling:
    - Raises TypeError if text is not a string.
    - Safely handles empty strings.
    - Catches unexpected errors and re-raises them with context.

    >>> remove_vowels('')
    ''
    >>> remove_vowels("abcdef
candidate = remove_vowels




METADATA = {}


def check(candidate):
    assert candidate('') == ''
    assert candidate("abcdef\nghijklm") == 'bcdf\nghjklm'
    assert candidate('fedcba') == 'fdcb'
    assert candidate('eeeee') == ''
    assert candidate('acBAA') == 'cB'
    assert candidate('EcBOO') == 'cB'
    assert candidate('ybcd') == 'ybcd'



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
