
import unittest
import re
import sys
import math
import copy


def solution(lst):
    """
    Given a non-empty list of integers, return the sum of all odd elements
    that are in even positions (0-based indexing).

    Examples
    --------
    solution([5, 8, 7, 1]) -> 12
    solution([3, 3, 3, 3, 3]) -> 9
    solution([30, 13, 24, 321]) -> 0
    """
    try:
        # Validate input type
        if not isinstance(lst, list):
            raise TypeError("Input must be a list.")

        # Validate non-empty list
        if len(lst) == 0:
            raise ValueError("Input list must not be empty.")

        # Validate all elements are integers
        if not all(isinstance(x, int) for x in lst):
            raise TypeError("All elements in the list must be integers.")

        # Sum odd elements at even indices
        return sum(lst[i] for i in range(0, len(lst), 2) if lst[i] % 2 != 0)

    except TypeError as te:
        print(f"Type error: {te}")
        return None
    except ValueError as ve:
        print(f"Value error: {ve}")
        return None
    except Exception as e:
        print(f"Unexpected error: {e}")
        return None
candidate = solution


def check(candidate):

    # Check some simple cases
    assert candidate([5, 8, 7, 1])    == 12
    assert candidate([3, 3, 3, 3, 3]) == 9
    assert candidate([30, 13, 24, 321]) == 0
    assert candidate([5, 9]) == 5
    assert candidate([2, 4, 8]) == 0
    assert candidate([30, 13, 23, 32]) == 23
    assert candidate([3, 13, 2, 9]) == 3

    # Check some edge cases that are easy to work out by hand.



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
