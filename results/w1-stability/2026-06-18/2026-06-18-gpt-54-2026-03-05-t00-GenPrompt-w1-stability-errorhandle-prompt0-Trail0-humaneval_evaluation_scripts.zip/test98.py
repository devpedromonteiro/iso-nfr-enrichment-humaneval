
import unittest
import re
import sys
import math
import copy


def count_upper(s):
    """
    Given a string s, count the number of uppercase vowels in even indices.

    For example:
    count_upper('aBCdEf') returns 1
    count_upper('abcdefg') returns 0
    count_upper('dBBE') returns 0
    """
    # Type validation
    if s is None:
        raise ValueError("Input cannot be None")

    if not isinstance(s, str):
        raise TypeError("Input must be a string")

    try:
        vowels = {"A", "E", "I", "O", "U"}
        count = 0

        for i, ch in enumerate(s):
            if i % 2 == 0 and ch in vowels:
                count += 1

        return count

    except Exception as e:
        # Catch unexpected errors and re-raise with context
        raise RuntimeError(f"An error occurred while counting uppercase vowels: {e}") from e
candidate = count_upper


def check(candidate):

    # Check some simple cases
    assert candidate('aBCdEf')  == 1
    assert candidate('abcdefg') == 0
    assert candidate('dBBE') == 0
    assert candidate('B')  == 0
    assert candidate('U')  == 1
    assert candidate('') == 0
    assert candidate('EEEE') == 2

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
