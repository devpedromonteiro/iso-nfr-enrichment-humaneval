
import unittest
import re
import sys
import math
import copy


def by_length(arr):
    """
    Given an array of integers, sort the integers that are between 1 and 9 inclusive,
    reverse the resulting array, and then replace each digit by its corresponding name.

    Error handling techniques included:
    - Type checking for the input
    - Safe handling of None
    - Ignoring non-integer values
    - Ignoring out-of-range integers
    """
    digit_names = {
        1: "One",
        2: "Two",
        3: "Three",
        4: "Four",
        5: "Five",
        6: "Six",
        7: "Seven",
        8: "Eight",
        9: "Nine"
    }

    try:
        if arr is None:
            return []

        if not isinstance(arr, list):
            raise TypeError("Input must be a list.")

        valid_numbers = []

        for item in arr:
            try:
                if isinstance(item, int) and 1 <= item <= 9:
                    valid_numbers.append(item)
            except Exception:
                continue

        valid_numbers.sort(reverse=True)

        return [digit_names[num] for num in valid_numbers]

    except TypeError as e:
        print(f"TypeError: {e}")
        return []
    except Exception as e:
        print(f"Unexpected error: {e}")
        return []
candidate = by_length


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([2, 1, 1, 4, 5, 8, 2, 3]) == ["Eight", "Five", "Four", "Three", "Two", "Two", "One", "One"], "Error"
    assert candidate([]) == [], "Error"
    assert candidate([1, -1 , 55]) == ['One'], "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([1, -1, 3, 2]) == ["Three", "Two", "One"]
    assert candidate([9, 4, 8]) == ["Nine", "Eight", "Four"]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
