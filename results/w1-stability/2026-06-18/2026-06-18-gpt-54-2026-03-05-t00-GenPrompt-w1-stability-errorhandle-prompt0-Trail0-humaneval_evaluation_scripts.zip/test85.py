
import unittest
import re
import sys
import math
import copy


def add(lst):
    """
    Given a non-empty list of integers lst, add the even elements
    that are at odd indices.

    Examples:
        add([4, 2, 6, 7]) ==> 2
    """
    try:
        # Validate input type
        if not isinstance(lst, list):
            raise TypeError("Input must be a list.")

        # Validate non-empty list
        if len(lst) == 0:
            raise ValueError("List must not be empty.")

        total = 0

        for i in range(1, len(lst), 2):  # odd indices only
            try:
                if not isinstance(lst[i], int):
                    raise TypeError(f"Element at index {i} is not an integer.")
                if lst[i] % 2 == 0:
                    total += lst[i]
            except TypeError as e:
                print(f"Skipping invalid element: {e}")

        return total

    except Exception as e:
        print(f"Error: {e}")
        return None
candidate = add


def check(candidate):

    # Check some simple cases
    assert candidate([4, 88]) == 88
    assert candidate([4, 5, 6, 7, 2, 122]) == 122
    assert candidate([4, 0, 6, 7]) == 0
    assert candidate([4, 4, 6, 8]) == 12

    # Check some edge cases that are easy to work out by hand.
    


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
