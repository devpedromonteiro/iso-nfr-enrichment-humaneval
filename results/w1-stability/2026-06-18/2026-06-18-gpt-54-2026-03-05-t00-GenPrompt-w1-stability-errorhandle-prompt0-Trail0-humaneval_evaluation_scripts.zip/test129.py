
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Given an N x N grid containing each integer from 1 to N*N exactly once,
    return the lexicographically smallest path of length k, where each move
    goes to a 4-directionally adjacent cell.

    Error handling included for:
    - invalid grid type
    - empty grid
    - non-square grid
    - invalid cell values
    - duplicate / missing values
    - invalid k
    """

    # ---------- Input validation ----------
    if grid is None:
        raise ValueError("grid cannot be None")

    if not isinstance(grid, list):
        raise TypeError("grid must be a list of lists")

    if len(grid) < 2:
        raise ValueError("grid must have at least 2 rows")

    n = len(grid)

    for i, row in enumerate(grid):
        if not isinstance(row, list):
            raise TypeError(f"grid[{i}] must be a list")
        if len(row) != n:
            raise ValueError("grid must be square (N x N)")

    if not isinstance(k, int):
        raise TypeError("k must be an integer")
    if k <= 0:
        raise ValueError("k must be a positive integer")

    values = []
    pos = {}

    for r in range(n):
        for c in range(n):
            val = grid[r][c]
            if not isinstance(val, int):
                raise TypeError(f"grid[{r}][{c}] must be an integer")
            values.append(val)
            pos[val] = (r, c)

    expected = set(range(1, n * n + 1))
    actual = set(values)

    if len(values) != len(actual):
        raise ValueError("grid contains duplicate values")

    if actual != expected:
        missing = sorted(expected - actual)
        extra = sorted(actual - expected)
        raise ValueError(
            f"grid must contain each integer from 1 to {n*n} exactly once. "
            f"Missing: {missing}, Extra: {extra}"
        )

    # ---------- Build adjacency ----------
    neighbors = {}
    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]

    for val in range(1, n * n + 1):
        r, c = pos[val]
        adj = []
        for dr, dc in directions:
            nr, nc = r + dr, c + dc
            if 0 <= nr < n and 0 <= nc < n:
                adj.append(grid[nr][nc])
        neighbors[val] = sorted(adj)

    # ---------- Construct lexicographically smallest path ----------
    try:
        path = [1]  # smallest possible starting value
        current = 1

        for _ in range(k - 1):
            # choose smallest-valued neighbor each time
            current = neighbors[current][0]
            path.append(current)

        return path

    except KeyError as e:
        raise RuntimeError(f"Internal error: missing adjacency for value {e}") from e
    except IndexError as e:
        raise RuntimeError("Internal error: a cell has no valid neighbors") from e
    except Exception as e:
        raise RuntimeError(f"Unexpected error while computing path: {e}") from e
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
