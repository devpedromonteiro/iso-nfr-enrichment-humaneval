
import unittest
import re
import sys
import math
import copy


def encrypt(s):
    """
    Encrypt a string by rotating each alphabetic character forward by 4 places.

    Examples:
        encrypt('hi') -> 'lm'
        encrypt('asdfghjkl') -> 'ewhjklnop'
        encrypt('gf') -> 'kj'
        encrypt('et') -> 'ix'
    """
    try:
        if s is None:
            raise ValueError("Input cannot be None.")

        if not isinstance(s, str):
            raise TypeError("Input must be a string.")

        if s == "":
            return ""

        result = []

        for char in s:
            if char.isalpha():
                if char.islower():
                    shifted = chr((ord(char) - ord('a') + 4) % 26 + ord('a'))
                elif char.isupper():
                    shifted = chr((ord(char) - ord('A') + 4) % 26 + ord('A'))
                result.append(shifted)
            else:
                raise ValueError(f"Invalid character '{char}': only alphabetic characters are allowed.")

        return "".join(result)

    except TypeError as te:
        return f"TypeError: {te}"
    except ValueError as ve:
        return f"ValueError: {ve}"
    except Exception as e:
        return f"Unexpected error: {e}"
candidate = encrypt


def check(candidate):

    # Check some simple cases
    assert candidate('hi') == 'lm', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('asdfghjkl') == 'ewhjklnop', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('gf') == 'kj', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('et') == 'ix', "This prints if this assert fails 1 (good for debugging!)"

    assert candidate('faewfawefaewg')=='jeiajeaijeiak', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('hellomyfriend')=='lippsqcjvmirh', "This prints if this assert fails 2 (good for debugging!)"
    assert candidate('dxzdlmnilfuhmilufhlihufnmlimnufhlimnufhfucufh')=='hbdhpqrmpjylqmpyjlpmlyjrqpmqryjlpmqryjljygyjl', "This prints if this assert fails 3 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate('a')=='e', "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
