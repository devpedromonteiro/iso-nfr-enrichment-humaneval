
import unittest
import re
import sys
import math
import copy


def add(lst):
    """Given a non-empty list of integers lst, add the even elements that are at odd indices.

    Examples:
        add([4, 2, 6, 7]) ==> 2
    """
    # Error management: type checks
    if not isinstance(lst, list):
        raise TypeError("Input must be a list.")

    if len(lst) == 0:
        raise ValueError("List must be non-empty.")

    # Error management: validate all elements
    for i, item in enumerate(lst):
        if not isinstance(item, int):
            raise TypeError(f"Element at index {i} is not an integer.")

    total = 0

    try:
        for i in range(1, len(lst), 2):  # odd indices
            if lst[i] % 2 == 0:          # even elements
                total += lst[i]
    except Exception as e:
        raise RuntimeError(f"Unexpected error while processing list: {e}")

    return total
candidate = add


def check(candidate):

    # Check some simple cases
    assert candidate([4, 88]) == 88
    assert candidate([4, 5, 6, 7, 2, 122]) == 122
    assert candidate([4, 0, 6, 7]) == 0
    assert candidate([4, 4, 6, 8]) == 12

    # Check some edge cases that are easy to work out by hand.
    


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
