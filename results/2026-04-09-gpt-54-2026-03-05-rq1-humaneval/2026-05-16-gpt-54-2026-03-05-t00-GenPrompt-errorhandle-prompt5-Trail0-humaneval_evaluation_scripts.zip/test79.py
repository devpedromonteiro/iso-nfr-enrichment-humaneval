
import unittest
import re
import sys
import math
import copy


def decimal_to_binary(decimal):
    """You will be given a number in decimal form and your task is to convert it to
    binary format. The function should return a string, with each character representing a binary
    number. Each character in the string will be '0' or '1'.

    There will be an extra couple of characters 'db' at the beginning and at the end of the string.
    The extra characters are there to help with the format.

    Examples:
    decimal_to_binary(15)   # returns "db1111db"
    decimal_to_binary(32)   # returns "db100000db"
    """
    try:
        # Reject booleans explicitly since bool is a subclass of int
        if isinstance(decimal, bool):
            raise TypeError("Boolean values are not valid decimal inputs.")

        # Try converting valid numeric-like input to int
        decimal = int(decimal)

        # Handle zero directly
        if decimal == 0:
            return "db0db"

        # Handle negative numbers
        is_negative = decimal < 0
        decimal = abs(decimal)

        binary_digits = []
        while decimal > 0:
            binary_digits.append(str(decimal % 2))
            decimal //= 2

        binary_string = ''.join(reversed(binary_digits))

        if is_negative:
            binary_string = '-' + binary_string

        return f"db{binary_string}db"

    except ValueError:
        return "Error: Input must be a valid integer."
    except TypeError:
        return "Error: Input must be an integer."
    except Exception as e:
        return f"Unexpected error: {e}"
candidate = decimal_to_binary


def check(candidate):

    # Check some simple cases
    assert candidate(0) == "db0db"
    assert candidate(32) == "db100000db"
    assert candidate(103) == "db1100111db"
    assert candidate(15) == "db1111db", "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
