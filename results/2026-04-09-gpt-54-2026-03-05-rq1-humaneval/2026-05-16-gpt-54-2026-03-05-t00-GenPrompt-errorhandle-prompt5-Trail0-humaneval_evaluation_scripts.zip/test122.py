
import unittest
import re
import sys
import math
import copy


def add_elements(arr, k):
    """
    Given a non-empty array of integers arr and an integer k, return
    the sum of the elements with at most two digits from the first k elements of arr.

    Example:
        Input: arr = [111,21,3,4000,5,6,7,8,9], k = 4
        Output: 24  # sum of 21 + 3

    Constraints:
        1. 1 <= len(arr) <= 100
        2. 1 <= k <= len(arr)
    """
    # Type checks
    if not isinstance(arr, list):
        raise TypeError("arr must be a list")
    if not isinstance(k, int):
        raise TypeError("k must be an integer")

    # Value checks
    if len(arr) == 0:
        raise ValueError("arr must be non-empty")
    if not (1 <= k <= len(arr)):
        raise ValueError("k must satisfy 1 <= k <= len(arr)")

    total = 0

    for i in range(k):
        value = arr[i]

        # Element validation
        if not isinstance(value, int):
            raise TypeError(f"arr[{i}] must be an integer")

        # At most two digits means absolute value is between 0 and 99 inclusive
        if -99 <= value <= 99:
            total += value

    return total
candidate = add_elements


def check(candidate):

    # Check some simple cases
    assert candidate([1,-2,-3,41,57,76,87,88,99], 3) == -4
    assert candidate([111,121,3,4000,5,6], 2) == 0
    assert candidate([11,21,3,90,5,6,7,8,9], 4) == 125
    assert candidate([111,21,3,4000,5,6,7,8,9], 4) == 24, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate([1], 1) == 1, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
