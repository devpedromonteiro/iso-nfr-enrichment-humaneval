
import unittest
import re
import sys
import math
import copy


def solve(s):
    """You are given a string s.
    if s[i] is a letter, reverse its case from lower to upper or vise versa, 
    otherwise keep it as it is.
    If the string contains no letters, reverse the string.
    The function should return the resulted string.
    Examples
    solve("1234") = "4321"
    solve("ab") = "AB"
    solve("#a@C") = "#A@c"
    """
    try:
        if s is None:
            return ""

        if not isinstance(s, str):
            s = str(s)

        has_letter = any(ch.isalpha() for ch in s)

        if not has_letter:
            return s[::-1]

        result = []
        for ch in s:
            try:
                if ch.isalpha():
                    result.append(ch.swapcase())
                else:
                    result.append(ch)
            except Exception:
                result.append(ch)

        return "".join(result)

    except Exception:
        return ""
candidate = solve


def check(candidate):

    # Check some simple cases
    assert candidate("AsDf") == "aSdF"
    assert candidate("1234") == "4321"
    assert candidate("ab") == "AB"
    assert candidate("#a@C") == "#A@c"
    assert candidate("#AsdfW^45") == "#aSDFw^45"
    assert candidate("#6@2") == "2@6#"

    # Check some edge cases that are easy to work out by hand.
    assert candidate("#$a^D") == "#$A^d"
    assert candidate("#ccc") == "#CCC"

    # Don't remove this line:


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
