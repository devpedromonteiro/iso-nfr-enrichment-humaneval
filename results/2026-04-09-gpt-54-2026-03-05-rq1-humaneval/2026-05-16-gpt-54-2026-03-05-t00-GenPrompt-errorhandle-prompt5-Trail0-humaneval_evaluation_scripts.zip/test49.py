
import unittest
import re
import sys
import math
import copy



def modp(n: int, p: int):
    """Return 2^n modulo p (be aware of numerics).

    Uses fast modular exponentiation and several error-management checks.

    >>> modp(3, 5)
    3
    >>> modp(1101, 101)
    2
    >>> modp(0, 101)
    1
    >>> modp(3, 11)
    8
    >>> modp(100, 101)
    1
    """
    # Type validation
    if not isinstance(n, int) or not isinstance(p, int):
        raise TypeError("n and p must both be integers")

    # Value validation
    if n < 0:
        raise ValueError("n must be non-negative")
    if p <= 0:
        raise ValueError("p must be a positive integer")

    # Special-case modulus 1
    if p == 1:
        return 0

    try:
        # Built-in modular exponentiation avoids huge intermediate values
        return pow(2, n, p)
    except OverflowError as e:
        raise OverflowError("numerical overflow while computing 2^n mod p") from e
    except Exception as e:
        raise RuntimeError("unexpected error during modular exponentiation") from e
candidate = modp




METADATA = {}


def check(candidate):
    assert candidate(3, 5) == 3
    assert candidate(1101, 101) == 2
    assert candidate(0, 101) == 1
    assert candidate(3, 11) == 8
    assert candidate(100, 101) == 1
    assert candidate(30, 5) == 4
    assert candidate(31, 5) == 3



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
