
import unittest
import re
import sys
import math
import copy



def correct_bracketing(brackets: str):
    """brackets is a string of "<" and ">".
    return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("<")
    False
    >>> correct_bracketing("<>")
    True
    >>> correct_bracketing("<<><>>")
    True
    >>> correct_bracketing("><<>")
    False
    """
    # Error management technique 1: type validation
    if not isinstance(brackets, str):
        raise TypeError("brackets must be a string")

    balance = 0

    for ch in brackets:
        # Error management technique 2: input validation
        if ch not in "<>":
            raise ValueError("brackets must contain only '<' and '>'")

        if ch == "<":
            balance += 1
        else:  # ch == ">"
            balance -= 1

        # Error management technique 3: early failure detection
        if balance < 0:
            return False

    # Final consistency check
    return balance == 0
candidate = correct_bracketing




METADATA = {}


def check(candidate):
    assert candidate("<>")
    assert candidate("<<><>>")
    assert candidate("<><><<><>><>")
    assert candidate("<><><<<><><>><>><<><><<>>>")
    assert not candidate("<<<><>>>>")
    assert not candidate("><<>")
    assert not candidate("<")
    assert not candidate("<<<<")
    assert not candidate(">")
    assert not candidate("<<>")
    assert not candidate("<><><<><>><>><<>")
    assert not candidate("<><><<><>><>>><>")



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
