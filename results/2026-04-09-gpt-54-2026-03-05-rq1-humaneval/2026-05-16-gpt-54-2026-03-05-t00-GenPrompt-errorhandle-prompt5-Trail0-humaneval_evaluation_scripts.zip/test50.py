
import unittest
import re
import sys
import math
import copy



def encode_shift(s: str):
    """
    returns encoded string by shifting every character by 5 in the alphabet.
    """
    return "".join([chr(((ord(ch) + 5 - ord("a")) % 26) + ord("a")) for ch in s])


def encode_shift(s: str):
    """
    Returns encoded string by shifting every lowercase alphabetic character by 5.
    """
    if not isinstance(s, str):
        raise TypeError("Input must be a string.")

    result = []
    for ch in s:
        if not ("a" <= ch <= "z"):
            raise ValueError("Input must contain only lowercase letters a-z.")
        result.append(chr(((ord(ch) - ord("a") + 5) % 26) + ord("a")))
    return "".join(result)


def decode_shift(s: str):
    """
    Takes as input a string encoded with encode_shift function.
    Returns decoded string by shifting every lowercase alphabetic character back by 5.
    """
    if not isinstance(s, str):
        raise TypeError("Input must be a string.")

    try:
        result = []
        for ch in s:
            if not ("a" <= ch <= "z"):
                raise ValueError(f"Invalid character '{ch}'. Only lowercase letters a-z are allowed.")
            result.append(chr(((ord(ch) - ord("a") - 5) % 26) + ord("a")))
        return "".join(result)
    except Exception as e:
        raise ValueError(f"Failed to decode string: {e}") from e
candidate = decode_shift




METADATA = {}


def check(candidate):
    from random import randint, choice
    import copy
    import string

    letters = string.ascii_lowercase
    for _ in range(100):
        str = ''.join(choice(letters) for i in range(randint(10, 20)))
        encoded_str = encode_shift(str)
        assert candidate(copy.deepcopy(encoded_str)) == str



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
