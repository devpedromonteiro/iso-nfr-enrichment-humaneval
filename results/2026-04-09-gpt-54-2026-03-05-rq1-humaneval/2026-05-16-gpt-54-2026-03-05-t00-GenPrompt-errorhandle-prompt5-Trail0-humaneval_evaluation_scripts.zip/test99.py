
import unittest
import re
import sys
import math
import copy


def closest_integer(value):
    '''
    Create a function that takes a value (string) representing a number
    and returns the closest integer to it. If the number is equidistant
    from two integers, round it away from zero.

    Examples
    >>> closest_integer("10")
    10
    >>> closest_integer("15.3")
    15

    Note:
    Rounding away from zero means that if the given number is equidistant
    from two integers, the one you should return is the one that is the
    farthest from zero. For example closest_integer("14.5") should
    return 15 and closest_integer("-14.5") should return -15.
    '''
    try:
        if value is None:
            raise ValueError("Input cannot be None")

        num = float(str(value).strip())

        if num >= 0:
            return int(num + 0.5)
        else:
            return int(num - 0.5)

    except ValueError:
        raise ValueError("Input must be a valid numeric string")
    except TypeError:
        raise TypeError("Input must be convertible to a string or number")
    except Exception as e:
        raise RuntimeError(f"Unexpected error: {e}")
candidate = closest_integer


def check(candidate):

    # Check some simple cases
    assert candidate("10") == 10, "Test 1"
    assert candidate("14.5") == 15, "Test 2"
    assert candidate("-15.5") == -16, "Test 3"
    assert candidate("15.3") == 15, "Test 3"

    # Check some edge cases that are easy to work out by hand.
    assert candidate("0") == 0, "Test 0"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
