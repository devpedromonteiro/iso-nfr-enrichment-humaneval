
import unittest
import re
import sys
import math
import copy


def can_arrange(arr):
    """Return the largest index i such that arr[i] <= arr[i - 1].
    If no such index exists, return -1.

    Examples:
    can_arrange([1, 2, 4, 3, 5]) -> 3
    can_arrange([1, 2, 3]) -> -1
    """
    try:
        if arr is None:
            return -1
        if not hasattr(arr, "__iter__"):
            return -1

        arr = list(arr)

        if len(arr) < 2:
            return -1

        result = -1
        for i in range(1, len(arr)):
            try:
                if arr[i] <= arr[i - 1]:
                    result = i
            except TypeError:
                return -1

        return result

    except Exception:
        return -1
candidate = can_arrange


def check(candidate):

    # Check some simple cases
    assert candidate([1,2,4,3,5])==3
    assert candidate([1,2,4,5])==-1
    assert candidate([1,4,2,5,6,7,8,9,10])==2
    assert candidate([4,8,5,7,3])==4

    # Check some edge cases that are easy to work out by hand.
    assert candidate([])==-1



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
