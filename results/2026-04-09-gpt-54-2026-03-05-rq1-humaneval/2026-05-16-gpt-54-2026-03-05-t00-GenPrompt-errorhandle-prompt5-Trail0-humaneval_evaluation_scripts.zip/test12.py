
import unittest
import re
import sys
import math
import copy

from typing import List, Optional


from typing import List, Optional


def longest(strings: List[str]) -> Optional[str]:
    """Out of list of strings, return the longest one.

    Return the first one in case of multiple strings of the same length.
    Return None in case the input list is empty.

    >>> longest([])
    >>> longest(['a', 'b', 'c'])
    'a'
    >>> longest(['a', 'bb', 'ccc'])
    'ccc'
    """
    # Error management: handle None explicitly
    if strings is None:
        return None

    # Error management: ensure input is a list
    if not isinstance(strings, list):
        raise TypeError("Input must be a list of strings")

    # Handle empty list
    if not strings:
        return None

    # Error management: validate all elements
    for s in strings:
        if not isinstance(s, str):
            raise TypeError("All elements in the list must be strings")

    # Return the first longest string
    longest_string = strings[0]
    for s in strings[1:]:
        if len(s) > len(longest_string):
            longest_string = s

    return longest_string
candidate = longest




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == None
    assert candidate(['x', 'y', 'z']) == 'x'
    assert candidate(['x', 'yyy', 'zzzz', 'www', 'kkkk', 'abc']) == 'zzzz'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
