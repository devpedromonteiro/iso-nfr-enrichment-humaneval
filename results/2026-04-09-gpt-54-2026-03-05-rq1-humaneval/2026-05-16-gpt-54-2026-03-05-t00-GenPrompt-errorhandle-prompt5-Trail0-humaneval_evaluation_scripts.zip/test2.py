
import unittest
import re
import sys
import math
import copy



import math
from numbers import Real


def truncate_number(number: float) -> float:
    """Given a positive floating point number, return its decimal part.

    The decimal part is the leftover after removing the integer part.

    Examples:
    >>> truncate_number(3.5)
    0.5
    >>> truncate_number(7.0)
    0.0
    """

    # Type validation
    if not isinstance(number, Real):
        raise TypeError("number must be a real numeric value")

    # Reject NaN and infinity
    if not math.isfinite(number):
        raise ValueError("number must be finite")

    # Enforce problem constraint
    if number < 0:
        raise ValueError("number must be positive")

    # Return decimal part
    return number - math.floor(number)
candidate = truncate_number




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(3.5) == 0.5
    assert abs(candidate(1.33) - 0.33) < 1e-6
    assert abs(candidate(123.456) - 0.456) < 1e-6


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
