
import unittest
import re
import sys
import math
import copy


def find_max(words):
    """Return the word with the maximum number of unique characters.

    If multiple words have the same maximum number of unique characters,
    return the lexicographically smallest one.

    Error management:
    - Raises TypeError if input is not a list/tuple
    - Raises ValueError if input is empty
    - Raises TypeError if any element is not a string
    """
    try:
        if not isinstance(words, (list, tuple)):
            raise TypeError("Input must be a list or tuple of strings.")

        if not words:
            raise ValueError("Input list cannot be empty.")

        max_unique = -1
        result = None

        for word in words:
            if not isinstance(word, str):
                raise TypeError("All elements must be strings.")

            unique_count = len(set(word))

            if unique_count > max_unique:
                max_unique = unique_count
                result = word
            elif unique_count == max_unique:
                if word < result:
                    result = word

        return result

    except Exception as e:
        print(f"Error: {e}")
        return None
candidate = find_max


def check(candidate):

    # Check some simple cases
    assert (candidate(["name", "of", "string"]) == "string"), "t1"
    assert (candidate(["name", "enam", "game"]) == "enam"), 't2'
    assert (candidate(["aaaaaaa", "bb", "cc"]) == "aaaaaaa"), 't3'
    assert (candidate(["abc", "cba"]) == "abc"), 't4'
    assert (candidate(["play", "this", "game", "of","footbott"]) == "footbott"), 't5'
    assert (candidate(["we", "are", "gonna", "rock"]) == "gonna"), 't6'
    assert (candidate(["we", "are", "a", "mad", "nation"]) == "nation"), 't7'
    assert (candidate(["this", "is", "a", "prrk"]) == "this"), 't8'

    # Check some edge cases that are easy to work out by hand.
    assert (candidate(["b"]) == "b"), 't9'
    assert (candidate(["play", "play", "play"]) == "play"), 't10'



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
