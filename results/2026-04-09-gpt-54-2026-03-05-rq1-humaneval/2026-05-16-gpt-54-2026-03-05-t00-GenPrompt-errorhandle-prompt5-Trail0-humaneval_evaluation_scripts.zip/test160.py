
import unittest
import re
import sys
import math
import copy


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and 
    the second list is a list of integers. Use the two given lists to build the algebric 
    expression and return the evaluation of this expression.

    The basic algebra operations:
    Addition ( + ) 
    Subtraction ( - ) 
    Multiplication ( * ) 
    Floor division ( // ) 
    Exponentiation ( ** ) 
    """
    # Error management: validate input types
    if not isinstance(operator, list) or not isinstance(operand, list):
        raise TypeError("Both operator and operand must be lists.")

    # Error management: validate lengths
    if len(operator) < 1 or len(operand) < 2:
        raise ValueError("Operator must have at least one item and operand at least two items.")
    if len(operator) != len(operand) - 1:
        raise ValueError("Length of operator must be exactly one less than length of operand.")

    # Error management: validate operators
    valid_ops = {"+", "-", "*", "//", "**"}
    for op in operator:
        if op not in valid_ops:
            raise ValueError(f"Invalid operator: {op}")

    # Error management: validate operands
    for num in operand:
        if not isinstance(num, int):
            raise TypeError("All operands must be integers.")
        if num < 0:
            raise ValueError("Operands must be non-negative integers.")

    # Build expression safely
    expression = str(operand[0])
    for op, num in zip(operator, operand[1:]):
        expression += f" {op} {num}"

    # Evaluate with runtime error handling
    try:
        return eval(expression)
    except ZeroDivisionError:
        raise ZeroDivisionError("Division by zero occurred in the algebra expression.")
    except OverflowError:
        raise OverflowError("Numerical result is too large.")
    except Exception as e:
        raise RuntimeError(f"An error occurred while evaluating the expression: {e}")
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
