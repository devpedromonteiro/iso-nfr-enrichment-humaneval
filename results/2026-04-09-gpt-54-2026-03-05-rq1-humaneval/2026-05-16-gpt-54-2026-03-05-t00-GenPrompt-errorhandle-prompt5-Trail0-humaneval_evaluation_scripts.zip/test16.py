
import unittest
import re
import sys
import math
import copy



def count_distinct_characters(string: str) -> int:
    """Given a string, find out how many distinct characters (regardless of case) it consists of.

    >>> count_distinct_characters('xyzXYZ')
    3
    >>> count_distinct_characters('Jerry')
    4
    """
    try:
        if string is None:
            raise ValueError("Input cannot be None.")

        if not isinstance(string, str):
            raise TypeError("Input must be a string.")

        normalized = string.casefold()
        return len(set(normalized))

    except TypeError as e:
        raise TypeError(f"Type error in count_distinct_characters: {e}") from e
    except ValueError as e:
        raise ValueError(f"Value error in count_distinct_characters: {e}") from e
    except Exception as e:
        raise RuntimeError(f"Unexpected error in count_distinct_characters: {e}") from e
candidate = count_distinct_characters




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == 0
    assert candidate('abcde') == 5
    assert candidate('abcde' + 'cade' + 'CADE') == 5
    assert candidate('aaaaAAAAaaaa') == 1
    assert candidate('Jerry jERRY JeRRRY') == 5


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
