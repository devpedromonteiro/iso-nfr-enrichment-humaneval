
import unittest
import re
import sys
import math
import copy

from typing import List, Tuple


from typing import List, Tuple


def sum_product(numbers: List[int]) -> Tuple[int, int]:
    """For a given list of integers, return a tuple consisting of the sum
    and the product of all integers in the list.

    Empty sum is 0 and empty product is 1.

    >>> sum_product([])
    (0, 1)
    >>> sum_product([1, 2, 3, 4])
    (10, 24)
    """
    # Error management: validate input type
    if numbers is None:
        raise ValueError("Input cannot be None.")

    if not isinstance(numbers, list):
        raise TypeError("Input must be a list of integers.")

    total_sum = 0
    total_product = 1

    for i, num in enumerate(numbers):
        # Error management: validate each element
        if not isinstance(num, int):
            raise TypeError(f"Element at index {i} is not an integer: {num!r}")

        try:
            total_sum += num
            total_product *= num
        except OverflowError as e:
            raise OverflowError(f"Arithmetic overflow at index {i} with value {num}") from e
        except Exception as e:
            raise RuntimeError(f"Unexpected error while processing index {i}") from e

    return total_sum, total_product
candidate = sum_product




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == (0, 1)
    assert candidate([1, 1, 1]) == (3, 1)
    assert candidate([100, 0]) == (100, 0)
    assert candidate([3, 5, 7]) == (3 + 5 + 7, 3 * 5 * 7)
    assert candidate([10]) == (10, 10)


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
