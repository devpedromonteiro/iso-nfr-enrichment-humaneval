
import unittest
import re
import sys
import math
import copy



def largest_divisor(n: int) -> int:
    """For a given number n, find the largest number that divides n evenly, smaller than n.

    >>> largest_divisor(15)
    5
    """
    # Type validation
    if not isinstance(n, int):
        raise TypeError("n must be an integer")

    # Value validation
    if n <= 1:
        raise ValueError("n must be greater than 1")

    try:
        # Search from n-1 downward so the first divisor found is the largest
        for i in range(n - 1, 0, -1):
            if n % i == 0:
                return i

        # Fallback, though this should never be reached because 1 divides all n > 1
        raise RuntimeError("No divisor found")
    except Exception as e:
        raise RuntimeError(f"Error while computing largest divisor for {n}: {e}") from e
candidate = largest_divisor




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(3) == 1
    assert candidate(7) == 1
    assert candidate(10) == 5
    assert candidate(100) == 50
    assert candidate(49) == 7


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
