
import unittest
import re
import sys
import math
import copy


def smallest_change(arr):
    """
    Given an array arr of integers, find the minimum number of elements that
    need to be changed to make the array palindromic. A palindromic array is an array that
    is read the same backwards and forwards. In one change, you can change one element to any other element.

    For example:
    smallest_change([1,2,3,5,4,7,9,6]) == 4
    smallest_change([1, 2, 3, 4, 3, 2, 2]) == 1
    smallest_change([1, 2, 3, 2, 1]) == 0
    """
    try:
        if arr is None:
            raise ValueError("Input cannot be None")
        if not isinstance(arr, (list, tuple)):
            raise TypeError("Input must be a list or tuple")

        n = len(arr)
        changes = 0

        for i in range(n // 2):
            try:
                if arr[i] != arr[n - 1 - i]:
                    changes += 1
            except IndexError as e:
                raise IndexError(f"Index error while comparing elements at position {i}") from e

        return changes

    except Exception as e:
        raise e
candidate = smallest_change


def check(candidate):

    # Check some simple cases
    assert candidate([1,2,3,5,4,7,9,6]) == 4
    assert candidate([1, 2, 3, 4, 3, 2, 2]) == 1
    assert candidate([1, 4, 2]) == 1
    assert candidate([1, 4, 4, 2]) == 1

    # Check some edge cases that are easy to work out by hand.
    assert candidate([1, 2, 3, 2, 1]) == 0
    assert candidate([3, 1, 1, 3]) == 0
    assert candidate([1]) == 0
    assert candidate([0, 1]) == 1



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
