
import unittest
import re
import sys
import math
import copy


def x_or_y(n, x, y):
    """Return x if n is prime, otherwise return y.

    A simple program which should return the value of x if n is
    a prime number and should return the value of y otherwise.

    Examples:
    >>> x_or_y(7, 34, 12)
    34
    >>> x_or_y(15, 8, 5)
    5
    """
    # Error management: validate input type
    try:
        if not isinstance(n, int):
            raise TypeError("n must be an integer")
    except TypeError:
        return y

    # Error management: handle invalid prime range
    if n < 2:
        return y

    # Fast checks for small numbers
    if n == 2:
        return x
    if n % 2 == 0:
        return y

    # Prime check with bounded iteration
    try:
        i = 3
        while i * i <= n:
            if n % i == 0:
                return y
            i += 2
    except Exception:
        return y

    return x
candidate = x_or_y


def check(candidate):

    # Check some simple cases
    assert candidate(7, 34, 12) == 34
    assert candidate(15, 8, 5) == 5
    assert candidate(3, 33, 5212) == 33
    assert candidate(1259, 3, 52) == 3
    assert candidate(7919, -1, 12) == -1
    assert candidate(3609, 1245, 583) == 583
    assert candidate(91, 56, 129) == 129
    assert candidate(6, 34, 1234) == 1234
    

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1, 2, 0) == 0
    assert candidate(2, 2, 0) == 2



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
