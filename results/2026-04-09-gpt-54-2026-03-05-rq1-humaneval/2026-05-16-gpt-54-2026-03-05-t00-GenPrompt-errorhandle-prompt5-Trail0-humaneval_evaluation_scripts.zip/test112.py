
import unittest
import re
import sys
import math
import copy


def reverse_delete(s, c):
    """
    Remove from string `s` every character that appears in string `c`,
    then return a tuple: (filtered_string, is_palindrome).

    Examples:
        reverse_delete("abcde", "ae") -> ('bcd', False)
        reverse_delete("abcdef", "b") -> ('acdef', False)
        reverse_delete("abcdedcba", "ab") -> ('cdedc', True)
    """
    try:
        # Basic type validation
        if not isinstance(s, str) or not isinstance(c, str):
            raise TypeError("Both s and c must be strings.")

        # Use a set for efficient membership checks
        chars_to_remove = set(c)

        # Build filtered string
        result = ''.join(ch for ch in s if ch not in chars_to_remove)

        # Palindrome check
        is_palindrome = result == result[::-1]

        return (result, is_palindrome)

    except TypeError as e:
        # Re-raise type-related issues with clear context
        raise TypeError(f"Invalid input: {e}")

    except Exception as e:
        # Catch unexpected errors
        raise RuntimeError(f"An unexpected error occurred: {e}")
candidate = reverse_delete


def check(candidate):

    assert candidate("abcde","ae") == ('bcd',False)
    assert candidate("abcdef", "b") == ('acdef',False)
    assert candidate("abcdedcba","ab") == ('cdedc',True)
    assert candidate("dwik","w") == ('dik',False)
    assert candidate("a","a") == ('',True)
    assert candidate("abcdedcba","") == ('abcdedcba',True)
    assert candidate("abcdedcba","v") == ('abcdedcba',True)
    assert candidate("vabba","v") == ('abba',True)
    assert candidate("mamma", "mia") == ("", True)


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
