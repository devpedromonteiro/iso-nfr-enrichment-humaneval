
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def rescale_to_unit(numbers: List[float]) -> List[float]:
    """Given a list of numbers, linearly rescale them so that:
    - the smallest value becomes 0
    - the largest value becomes 1

    The input must contain at least two numeric elements.

    >>> rescale_to_unit([1.0, 2.0, 3.0, 4.0, 5.0])
    [0.0, 0.25, 0.5, 0.75, 1.0]
    >>> rescale_to_unit([10, 20])
    [0.0, 1.0]
    """
    # Type validation
    if not isinstance(numbers, list):
        raise TypeError("numbers must be a list of numeric values")

    # Length validation
    if len(numbers) < 2:
        raise ValueError("numbers must contain at least two elements")

    # Element validation
    if not all(isinstance(x, (int, float)) for x in numbers):
        raise TypeError("all elements in numbers must be int or float")

    try:
        min_val = min(numbers)
        max_val = max(numbers)
        range_val = max_val - min_val

        # Prevent division by zero when all values are equal
        if range_val == 0:
            raise ValueError("cannot rescale a list where all values are equal")

        return [(x - min_val) / range_val for x in numbers]

    except OverflowError as e:
        raise OverflowError(f"numeric overflow occurred during rescaling: {e}")

    except Exception as e:
        raise RuntimeError(f"unexpected error during rescaling: {e}")
candidate = rescale_to_unit




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([2.0, 49.9]) == [0.0, 1.0]
    assert candidate([100.0, 49.9]) == [1.0, 0.0]
    assert candidate([1.0, 2.0, 3.0, 4.0, 5.0]) == [0.0, 0.25, 0.5, 0.75, 1.0]
    assert candidate([2.0, 1.0, 5.0, 3.0, 4.0]) == [0.25, 0.0, 1.0, 0.5, 0.75]
    assert candidate([12.0, 11.0, 15.0, 13.0, 14.0]) == [0.25, 0.0, 1.0, 0.5, 0.75]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
