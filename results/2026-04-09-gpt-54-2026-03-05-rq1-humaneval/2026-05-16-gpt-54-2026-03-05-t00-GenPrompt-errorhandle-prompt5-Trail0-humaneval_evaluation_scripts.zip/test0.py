
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List
import math


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """Check if any two numbers in the list are closer than the given threshold.

    Returns True if there exist distinct elements a and b such that
    abs(a - b) < threshold, otherwise False.

    Error management techniques used:
    - Type validation for inputs
    - Value validation for threshold
    - Safe handling of empty/small lists
    - Validation against NaN/infinite values

    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    if not isinstance(numbers, list):
        raise TypeError("numbers must be a list")

    if not isinstance(threshold, (int, float)):
        raise TypeError("threshold must be a number")

    if math.isnan(threshold) or math.isinf(threshold):
        raise ValueError("threshold must be a finite number")

    if threshold < 0:
        raise ValueError("threshold must be non-negative")

    if len(numbers) < 2:
        return False

    validated_numbers = []
    for i, num in enumerate(numbers):
        if not isinstance(num, (int, float)):
            raise TypeError(f"numbers[{i}] must be a number")
        if math.isnan(num) or math.isinf(num):
            raise ValueError(f"numbers[{i}] must be finite")
        validated_numbers.append(float(num))

    validated_numbers.sort()

    for i in range(len(validated_numbers) - 1):
        if abs(validated_numbers[i] - validated_numbers[i + 1]) < threshold:
            return True

    return False
candidate = has_close_elements




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([1.0, 2.0, 3.9, 4.0, 5.0, 2.2], 0.3) == True
    assert candidate([1.0, 2.0, 3.9, 4.0, 5.0, 2.2], 0.05) == False
    assert candidate([1.0, 2.0, 5.9, 4.0, 5.0], 0.95) == True
    assert candidate([1.0, 2.0, 5.9, 4.0, 5.0], 0.8) == False
    assert candidate([1.0, 2.0, 3.0, 4.0, 5.0, 2.0], 0.1) == True
    assert candidate([1.1, 2.2, 3.1, 4.1, 5.1], 1.0) == True
    assert candidate([1.1, 2.2, 3.1, 4.1, 5.1], 0.5) == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
