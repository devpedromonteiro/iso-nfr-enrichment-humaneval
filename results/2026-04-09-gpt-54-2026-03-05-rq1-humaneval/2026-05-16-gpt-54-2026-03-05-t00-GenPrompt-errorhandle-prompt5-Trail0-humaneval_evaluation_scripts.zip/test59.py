
import unittest
import re
import sys
import math
import copy



def largest_prime_factor(n: int):
    """Return the largest prime factor of n. Assume n > 1 and is not a prime.
    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    # Error management: type and value checks
    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if n <= 1:
        raise ValueError("n must be greater than 1")

    original_n = n
    largest = None

    try:
        # Remove factor 2 first
        while n % 2 == 0:
            largest = 2
            n //= 2

        # Check odd factors up to sqrt(n)
        factor = 3
        while factor * factor <= n:
            while n % factor == 0:
                largest = factor
                n //= factor
            factor += 2

        # If remainder is > 1, it is prime and largest
        if n > 1:
            largest = n

        # Defensive check in case assumptions are violated
        if largest is None:
            raise ValueError(f"{original_n} has no prime factors under the given assumptions")

        return largest

    except OverflowError as e:
        raise OverflowError("Number is too large to process safely") from e
    except Exception:
        # Re-raise expected exceptions unchanged
        raise
candidate = largest_prime_factor




METADATA = {}


def check(candidate):
    assert candidate(15) == 5
    assert candidate(27) == 3
    assert candidate(63) == 7
    assert candidate(330) == 11
    assert candidate(13195) == 29



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
