
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def below_zero(operations: List[int]) -> bool:
    """You're given a list of deposit and withdrawal operations on a bank account
    that starts with zero balance. Return True if at any point the balance falls
    below zero, otherwise return False.

    >>> below_zero([1, 2, 3])
    False
    >>> below_zero([1, 2, -4, 5])
    True
    """
    # Defensive check: handle None or invalid input gracefully
    if operations is None:
        raise ValueError("operations cannot be None")

    balance = 0

    try:
        for op in operations:
            if not isinstance(op, int):
                raise TypeError(f"All operations must be integers, got {type(op).__name__}")
            balance += op
            if balance < 0:
                return True
        return False
    except TypeError:
        # Re-raise type errors for invalid iterable contents
        raise
    except Exception as e:
        # Catch unexpected issues with a clearer message
        raise RuntimeError(f"Unexpected error while processing operations: {e}") from e
candidate = below_zero




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == False
    assert candidate([1, 2, -3, 1, 2, -3]) == False
    assert candidate([1, 2, -4, 5, 6]) == True
    assert candidate([1, -1, 2, -2, 5, -5, 4, -4]) == False
    assert candidate([1, -1, 2, -2, 5, -5, 4, -5]) == True
    assert candidate([1, -2, 2, -2, 5, -5, 4, -4]) == True


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
