
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def separate_paren_groups(paren_string: str) -> List[str]:
    """Input to this function is a string containing multiple groups of nested parentheses.
    Your goal is to separate those groups into separate strings and return them as a list.

    Separate groups are balanced (each open brace is properly closed) and not nested within each other.
    Ignore any spaces in the input string.

    >>> separate_paren_groups('( ) (( )) (( )( ))')
    ['()', '(())', '(()())']
    """
    # Error management: validate input type
    if not isinstance(paren_string, str):
        raise TypeError("Input must be a string.")

    result: List[str] = []
    current_group = []
    balance = 0

    try:
        for char in paren_string:
            # Ignore spaces
            if char.isspace():
                continue

            # Error management: reject invalid characters
            if char not in "()":
                raise ValueError(f"Invalid character encountered: {char!r}")

            current_group.append(char)

            if char == "(":
                balance += 1
            else:  # char == ")"
                balance -= 1

            # Error management: detect premature closing parenthesis
            if balance < 0:
                raise ValueError("Unbalanced parentheses: too many closing parentheses.")

            # When balance returns to zero, one full group is complete
            if balance == 0 and current_group:
                result.append("".join(current_group))
                current_group = []

        # Error management: detect incomplete group
        if balance != 0:
            raise ValueError("Unbalanced parentheses: missing closing parenthesis.")

        # Error management: detect leftover partial group
        if current_group:
            raise ValueError("Incomplete parenthesis group detected.")

        return result

    except Exception as e:
        # Re-raise with context for easier debugging
        raise type(e)(f"Error while separating parenthesis groups: {e}") from e
candidate = separate_paren_groups




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('(()()) ((())) () ((())()())') == [
        '(()())', '((()))', '()', '((())()())'
    ]
    assert candidate('() (()) ((())) (((())))') == [
        '()', '(())', '((()))', '(((())))'
    ]
    assert candidate('(()(())((())))') == [
        '(()(())((())))'
    ]
    assert candidate('( ) (( )) (( )( ))') == ['()', '(())', '(()())']


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
