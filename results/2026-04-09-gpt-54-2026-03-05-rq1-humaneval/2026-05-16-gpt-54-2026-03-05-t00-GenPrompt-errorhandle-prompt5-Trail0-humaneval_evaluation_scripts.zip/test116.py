
import unittest
import re
import sys
import math
import copy


def sort_array(arr):
    """
    Sort an array of integers by:
    1. Number of ones in their binary representation (ascending)
    2. Decimal value (ascending) when counts are equal

    Examples:
    >>> sort_array([1, 5, 2, 3, 4])
    [1, 2, 4, 3, 5]
    >>> sort_array([-2, -3, -4, -5, -6])
    [-4, -2, -6, -5, -3]
    >>> sort_array([1, 0, 2, 3, 4])
    [0, 1, 2, 4, 3]
    """
    # Error management: validate input type
    if arr is None:
        raise ValueError("Input cannot be None")
    if not isinstance(arr, list):
        raise TypeError("Input must be a list")

    # Error management: validate elements
    for i, x in enumerate(arr):
        if not isinstance(x, int):
            raise TypeError(f"All elements must be integers, found {type(x).__name__} at index {i}")

    def count_ones(n):
        """
        Count 1-bits in binary representation.
        For negative numbers, use absolute value to avoid '-' in bin output.
        """
        try:
            return bin(abs(n)).count('1')
        except Exception as e:
            raise ValueError(f"Failed to process element {n}: {e}")

    try:
        return sorted(arr, key=lambda x: (count_ones(x), x))
    except Exception as e:
        raise RuntimeError(f"Sorting failed: {e}")
candidate = sort_array


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,5,2,3,4]) == [1, 2, 4, 3, 5]
    assert candidate([-2,-3,-4,-5,-6]) == [-4, -2, -6, -5, -3]
    assert candidate([1,0,2,3,4]) == [0, 1, 2, 4, 3]
    assert candidate([]) == []
    assert candidate([2,5,77,4,5,3,5,7,2,3,4]) == [2, 2, 4, 4, 3, 3, 5, 5, 5, 7, 77]
    assert candidate([3,6,44,12,32,5]) == [32, 3, 5, 6, 12, 44]
    assert candidate([2,4,8,16,32]) == [2, 4, 8, 16, 32]
    assert candidate([2,4,8,16,32]) == [2, 4, 8, 16, 32]

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
