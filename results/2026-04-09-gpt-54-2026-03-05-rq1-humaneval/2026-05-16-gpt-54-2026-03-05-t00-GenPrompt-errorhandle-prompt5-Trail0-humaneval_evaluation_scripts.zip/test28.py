
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def concatenate(strings: List[str]) -> str:
    """Concatenate list of strings into a single string.

    >>> concatenate([])
    ''
    >>> concatenate(['a', 'b', 'c'])
    'abc'
    """
    # Type validation for the outer argument
    if strings is None:
        raise ValueError("strings cannot be None")

    if not isinstance(strings, list):
        raise TypeError("strings must be a list of strings")

    # Validate each element and collect safely
    result = []

    for index, item in enumerate(strings):
        if item is None:
            raise ValueError(f"strings[{index}] cannot be None")
        if not isinstance(item, str):
            raise TypeError(f"strings[{index}] must be a string, got {type(item).__name__}")
        result.append(item)

    # Safe concatenation
    try:
        return "".join(result)
    except Exception as exc:
        raise RuntimeError("unexpected error during concatenation") from exc
candidate = concatenate




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == ''
    assert candidate(['x', 'y', 'z']) == 'xyz'
    assert candidate(['x', 'y', 'z', 'w', 'k']) == 'xyzwk'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
