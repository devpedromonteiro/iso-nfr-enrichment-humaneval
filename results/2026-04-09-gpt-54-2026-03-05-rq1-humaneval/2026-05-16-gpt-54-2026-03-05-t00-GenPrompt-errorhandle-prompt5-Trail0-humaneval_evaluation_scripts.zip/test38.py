
import unittest
import re
import sys
import math
import copy



def encode_cyclic(s: str):
    """
    returns encoded string by cycling groups of three characters.
    """
    # split string to groups. Each of length 3.
    groups = [s[(3 * i):min((3 * i + 3), len(s))] for i in range((len(s) + 2) // 3)]
    # cycle elements in each group. Unless group has fewer elements than 3.
    groups = [(group[1:] + group[0]) if len(group) == 3 else group for group in groups]
    return "".join(groups)


def encode_cyclic(s: str):
    """
    Returns encoded string by cycling groups of three characters.

    Example:
        "abcdef" -> "bcaefd"
    """
    if not isinstance(s, str):
        raise TypeError("encode_cyclic expects a string input.")

    # split string to groups. Each of length 3.
    groups = [s[(3 * i):min((3 * i + 3), len(s))] for i in range((len(s) + 2) // 3)]
    # cycle elements in each group. Unless group has fewer elements than 3.
    groups = [(group[1:] + group[0]) if len(group) == 3 else group for group in groups]
    return "".join(groups)


def decode_cyclic(s: str):
    """
    Takes as input string encoded with encode_cyclic function.
    Returns decoded string.

    Decoding reverses the 3-character left rotation performed by encode_cyclic:
        abc -> bca
        bca -> abc

    Error management techniques used:
    - Type validation
    - Safe handling of empty strings
    - Per-group guarded decoding with fallback error context
    """
    if s is None:
        raise ValueError("decode_cyclic received None; expected a string.")

    if not isinstance(s, str):
        raise TypeError(f"decode_cyclic expects a string, got {type(s).__name__}.")

    if s == "":
        return ""

    try:
        # Split into groups of up to 3 characters
        groups = [s[(3 * i):min((3 * i + 3), len(s))] for i in range((len(s) + 2) // 3)]
        decoded_groups = []

        for idx, group in enumerate(groups):
            try:
                # Reverse of left rotation by 1 on length-3 groups:
                # encoded = group[1:] + group[0]
                # decoded = last char + first two chars
                if len(group) == 3:
                    decoded_groups.append(group[-1] + group[:-1])
                else:
                    decoded_groups.append(group)
            except Exception as e:
                raise ValueError(f"Failed to decode group at index {idx}: {group!r}") from e

        return "".join(decoded_groups)

    except Exception as e:
        raise RuntimeError("Unexpected error while decoding cyclic string.") from e
candidate = decode_cyclic




METADATA = {}


def check(candidate):
    from random import randint, choice
    import string

    letters = string.ascii_lowercase
    for _ in range(100):
        str = ''.join(choice(letters) for i in range(randint(10, 20)))
        encoded_str = encode_cyclic(str)
        assert candidate(encoded_str) == str



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
