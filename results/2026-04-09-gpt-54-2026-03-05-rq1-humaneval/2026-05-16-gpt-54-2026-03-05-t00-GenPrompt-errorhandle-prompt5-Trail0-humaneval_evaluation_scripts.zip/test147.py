
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    You are given a positive integer n. Create an integer array a of length n where:
        a[i] = i * i - i + 1   for 1 <= i <= n

    Return the number of triples (a[i], a[j], a[k]) such that:
        i < j < k
        and (a[i] + a[j] + a[k]) is divisible by 3.

    Example:
        Input: n = 5
        Output: 1
        Explanation:
            a = [1, 3, 7, 13, 21]
            The only valid triple is (1, 7, 13).
    """

    # Error management: type check
    if not isinstance(n, int):
        raise TypeError("n must be an integer")

    # Error management: value check
    if n <= 0:
        raise ValueError("n must be a positive integer")

    try:
        # Observe:
        # a[i] = i^2 - i + 1 = i(i-1) + 1
        # Since i(i-1) is always divisible by 2, but we care mod 3:
        # Check pattern modulo 3:
        # i % 3 == 0 -> a[i] % 3 == 1
        # i % 3 == 1 -> a[i] % 3 == 1
        # i % 3 == 2 -> a[i] % 3 == 0
        #
        # So values fall into:
        # residue 1: count of indices i where i % 3 != 2
        # residue 0: count of indices i where i % 3 == 2
        #
        # A triple sum is divisible by 3 only if residues are:
        # (0,0,0) or (1,1,1), since residue 2 never appears.

        count_mod_0 = n // 3  # indices congruent to 2 mod 3 among 1..n
        count_mod_1 = n - count_mod_0

        def comb3(x):
            return x * (x - 1) * (x - 2) // 6 if x >= 3 else 0

        return comb3(count_mod_0) + comb3(count_mod_1)

    except OverflowError:
        raise OverflowError("Computation overflowed for the given input")
    except Exception as e:
        raise RuntimeError(f"Unexpected error occurred: {e}")
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
