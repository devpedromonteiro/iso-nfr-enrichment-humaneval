
import unittest
import re
import sys
import math
import copy



def unique(l: list):
    """Return sorted unique elements in a list
    >>> unique([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [0, 2, 3, 5, 9, 123]
    """
    # Error management: validate input type
    if not isinstance(l, list):
        raise TypeError("Input must be a list")

    try:
        # Error management: remove duplicates
        unique_items = set(l)

        try:
            # Error management: sort elements
            return sorted(unique_items)
        except TypeError as e:
            raise TypeError(
                "All elements in the list must be mutually comparable for sorting"
            ) from e

    except TypeError as e:
        raise TypeError(
            "All elements in the list must be hashable to determine uniqueness"
        ) from e
candidate = unique




METADATA = {}


def check(candidate):
    assert candidate([5, 3, 5, 2, 3, 3, 9, 0, 123]) == [0, 2, 3, 5, 9, 123]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
