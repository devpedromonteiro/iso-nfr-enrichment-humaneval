
import unittest
import re
import sys
import math
import copy


def specialFilter(nums):
    """Write a function that takes an array of numbers as input and returns 
    the number of elements in the array that are greater than 10 and both 
    first and last digits of a number are odd (1, 3, 5, 7, 9).
    For example:
    specialFilter([15, -73, 14, -15]) => 1 
    specialFilter([33, -2, -3, 45, 21, 109]) => 2
    """
    
    # Error management: ensure input is iterable
    if nums is None:
        return 0
    
    try:
        iterator = iter(nums)
    except TypeError:
        raise TypeError("Input must be an iterable of numbers")
    
    count = 0
    odd_digits = {'1', '3', '5', '7', '9'}
    
    for num in iterator:
        try:
            # Skip non-numeric values safely
            if not isinstance(num, (int, float)) or isinstance(num, bool):
                continue
            
            # Only numbers greater than 10 qualify
            if num <= 10:
                continue
            
            # Convert to integer-like string for digit checks
            num_str = str(abs(int(num)))
            
            # Defensive check for empty conversion
            if not num_str:
                continue
            
            if num_str[0] in odd_digits and num_str[-1] in odd_digits:
                count += 1
                
        except (ValueError, TypeError, OverflowError):
            # Skip problematic elements instead of crashing
            continue
    
    return count
candidate = specialFilter


def check(candidate):

    # Check some simple cases
    assert candidate([5, -2, 1, -5]) == 0  
    assert candidate([15, -73, 14, -15]) == 1
    assert candidate([33, -2, -3, 45, 21, 109]) == 2
    assert candidate([43, -12, 93, 125, 121, 109]) == 4
    assert candidate([71, -2, -33, 75, 21, 19]) == 3


    # Check some edge cases that are easy to work out by hand.
    assert candidate([1]) == 0              
    assert candidate([]) == 0                   



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
