
import unittest
import re
import sys
import math
import copy



def triangle_area(a, h):
    """Given length of a side and high return area for a triangle.
    >>> triangle_area(5, 3)
    7.5
    """
    # Type checks
    if not isinstance(a, (int, float)) or not isinstance(h, (int, float)):
        raise TypeError("Both 'a' and 'h' must be numbers.")

    # Value checks
    if a < 0 or h < 0:
        raise ValueError("Both 'a' and 'h' must be non-negative.")

    # Handle edge case
    if a == 0 or h == 0:
        return 0.0

    try:
        area = (a * h) / 2
    except OverflowError as e:
        raise OverflowError("Calculation overflowed for the given inputs.") from e
    except Exception as e:
        raise RuntimeError("Unexpected error during area calculation.") from e

    return float(area)
candidate = triangle_area




METADATA = {}


def check(candidate):
    assert candidate(5, 3) == 7.5
    assert candidate(2, 2) == 2.0
    assert candidate(10, 8) == 40.0



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
