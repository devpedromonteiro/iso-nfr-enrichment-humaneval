
import unittest
import re
import sys
import math
import copy


def sort_array(array):
    """
    Given an array of non-negative integers, return a copy of the given array after sorting,
    you will sort the given array in ascending order if the sum(first index value, last index value) is odd,
    or sort it in descending order if the sum(first index value, last index value) is even.

    Note:
    * don't change the given array.

    Examples:
    * sort_array([]) => []
    * sort_array([5]) => [5]
    * sort_array([2, 4, 3, 0, 1, 5]) => [0, 1, 2, 3, 4, 5]
    * sort_array([2, 4, 3, 0, 1, 5, 6]) => [6, 5, 4, 3, 2, 1, 0]
    """
    try:
        if array is None:
            raise ValueError("Input cannot be None")

        if not isinstance(array, list):
            raise TypeError("Input must be a list")

        if len(array) == 0:
            return []

        if len(array) == 1:
            if not isinstance(array[0], int) or array[0] < 0:
                raise ValueError("Array must contain only non-negative integers")
            return array[:]

        for item in array:
            if not isinstance(item, int):
                raise TypeError("All elements must be integers")
            if item < 0:
                raise ValueError("All elements must be non-negative")

        first_val = array[0]
        last_val = array[-1]

        if (first_val + last_val) % 2 == 1:
            return sorted(array)
        else:
            return sorted(array, reverse=True)

    except (TypeError, ValueError) as e:
        print(f"Error: {e}")
        return []
    except Exception as e:
        print(f"Unexpected error: {e}")
        return []
candidate = sort_array


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([]) == [], "Error"
    assert candidate([5]) == [5], "Error"
    assert candidate([2, 4, 3, 0, 1, 5]) == [0, 1, 2, 3, 4, 5], "Error"
    assert candidate([2, 4, 3, 0, 1, 5, 6]) == [6, 5, 4, 3, 2, 1, 0], "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([2, 1]) == [1, 2], "Error"
    assert candidate([15, 42, 87, 32 ,11, 0]) == [0, 11, 15, 32, 42, 87], "Error"
    assert candidate([21, 14, 23, 11]) == [23, 21, 14, 11], "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
