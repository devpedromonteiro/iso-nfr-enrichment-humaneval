
import unittest
import re
import sys
import math
import copy



def derivative(xs: list):
    """xs represent coefficients of a polynomial.
    xs[0] + xs[1] * x + xs[2] * x^2 + ....
    Return derivative of this polynomial in the same form.

    >>> derivative([3, 1, 2, 4, 5])
    [1, 4, 12, 20]
    >>> derivative([1, 2, 3])
    [2, 6]
    """
    # Error management: validate input type
    if xs is None:
        raise ValueError("Input cannot be None.")
    if not isinstance(xs, list):
        raise TypeError("Input must be a list of polynomial coefficients.")

    # Error management: handle empty or constant polynomial
    if len(xs) <= 1:
        return []

    result = []
    for i in range(1, len(xs)):
        coef = xs[i]

        # Error management: validate coefficient type
        if not isinstance(coef, (int, float, complex)):
            raise TypeError(f"Coefficient at index {i} is not numeric: {coef!r}")

        result.append(i * coef)

    return result
candidate = derivative




METADATA = {}


def check(candidate):
    assert candidate([3, 1, 2, 4, 5]) == [1, 4, 12, 20]
    assert candidate([1, 2, 3]) == [2, 6]
    assert candidate([3, 2, 1]) == [2, 2]
    assert candidate([3, 2, 1, 0, 4]) == [2, 2, 0, 16]
    assert candidate([1]) == []



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
