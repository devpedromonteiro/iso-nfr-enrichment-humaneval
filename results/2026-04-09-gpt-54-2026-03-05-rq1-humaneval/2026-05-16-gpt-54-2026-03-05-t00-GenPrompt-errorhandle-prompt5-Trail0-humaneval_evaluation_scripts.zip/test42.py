
import unittest
import re
import sys
import math
import copy



def incr_list(l: list):
    """Return list with elements incremented by 1.
    >>> incr_list([1, 2, 3])
    [2, 3, 4]
    >>> incr_list([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [6, 4, 6, 3, 4, 4, 10, 1, 124]
    """
    # Type check for the outer container
    if not isinstance(l, list):
        raise TypeError("Input must be a list.")

    result = []

    for i, item in enumerate(l):
        try:
            # Reject booleans explicitly since bool is a subclass of int
            if isinstance(item, bool):
                raise TypeError(f"Element at index {i} is a bool, not a valid number.")

            result.append(item + 1)

        except TypeError as e:
            raise TypeError(
                f"Element at index {i} ({item!r}) cannot be incremented by 1."
            ) from e
        except Exception as e:
            raise ValueError(
                f"Unexpected error while processing element at index {i}: {item!r}"
            ) from e

    return result
candidate = incr_list




METADATA = {}


def check(candidate):
    assert candidate([]) == []
    assert candidate([3, 2, 1]) == [4, 3, 2]
    assert candidate([5, 2, 5, 2, 3, 3, 9, 0, 123]) == [6, 3, 6, 3, 4, 4, 10, 1, 124]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
