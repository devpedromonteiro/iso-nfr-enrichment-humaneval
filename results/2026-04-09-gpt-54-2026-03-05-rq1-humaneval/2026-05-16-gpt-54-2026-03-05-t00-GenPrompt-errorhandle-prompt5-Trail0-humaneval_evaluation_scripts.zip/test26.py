
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List
from collections import Counter


def remove_duplicates(numbers: List[int]) -> List[int]:
    """From a list of integers, remove all elements that occur more than once.
    Keep order of elements left the same as in the input.

    >>> remove_duplicates([1, 2, 3, 2, 4])
    [1, 3, 4]
    """
    try:
        if numbers is None:
            return []

        if not isinstance(numbers, list):
            raise TypeError("Input must be a list of integers.")

        if not all(isinstance(x, int) for x in numbers):
            raise ValueError("All elements in the list must be integers.")

        counts = Counter(numbers)
        return [x for x in numbers if counts[x] == 1]

    except TypeError as e:
        raise TypeError(f"Type error in remove_duplicates: {e}")
    except ValueError as e:
        raise ValueError(f"Value error in remove_duplicates: {e}")
    except Exception as e:
        raise RuntimeError(f"Unexpected error in remove_duplicates: {e}")
candidate = remove_duplicates




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == []
    assert candidate([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert candidate([1, 2, 3, 2, 4, 3, 5]) == [1, 4, 5]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
