
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    """Insert a number `delimeter` between every two consecutive elements of input list `numbers`.

    Error management techniques used:
    - Type validation for `numbers`
    - Element validation for items inside `numbers`
    - Type validation for `delimeter`
    - Safe handling of empty and single-element lists

    >>> intersperse([], 4)
    []
    >>> intersperse([1, 2, 3], 4)
    [1, 4, 2, 4, 3]
    """
    if not isinstance(numbers, list):
        raise TypeError("numbers must be a list")

    if not isinstance(delimeter, int):
        raise TypeError("delimeter must be an integer")

    for i, value in enumerate(numbers):
        if not isinstance(value, int):
            raise TypeError(f"numbers[{i}] must be an integer")

    if len(numbers) <= 1:
        return numbers.copy()

    result = []
    try:
        for i, num in enumerate(numbers):
            result.append(num)
            if i < len(numbers) - 1:
                result.append(delimeter)
    except Exception as e:
        raise RuntimeError(f"Unexpected error while interspersing values: {e}") from e

    return result
candidate = intersperse




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([], 7) == []
    assert candidate([5, 6, 3, 2], 8) == [5, 8, 6, 8, 3, 8, 2]
    assert candidate([2, 2, 2], 2) == [2, 2, 2, 2, 2]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
