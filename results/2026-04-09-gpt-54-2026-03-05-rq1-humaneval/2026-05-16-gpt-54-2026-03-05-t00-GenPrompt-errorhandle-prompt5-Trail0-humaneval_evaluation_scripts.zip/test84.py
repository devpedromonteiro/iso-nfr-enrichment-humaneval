
import unittest
import re
import sys
import math
import copy


def solve(N):
    """Given a positive integer N, return the total sum of its digits in binary.
    
    Example
        For N = 1000, the sum of digits will be 1 the output should be "1".
        For N = 150, the sum of digits will be 6 the output should be "110".
        For N = 147, the sum of digits will be 12 the output should be "1100".
    
    Variables:
        @N integer
             Constraints: 0 â¤ N â¤ 10000.
    Output:
         a string of binary number
    """
    try:
        # Type validation
        if isinstance(N, bool):
            raise TypeError("Input must be an integer, not boolean.")
        
        # Attempt safe conversion if possible
        if not isinstance(N, int):
            try:
                N = int(N)
            except (ValueError, TypeError):
                raise TypeError("Input must be an integer or convertible to integer.")
        
        # Range validation
        if N < 0 or N > 10000:
            raise ValueError("Input must satisfy 0 â¤ N â¤ 10000.")
        
        # Sum digits
        digit_sum = sum(int(d) for d in str(N))
        
        # Convert sum to binary
        return bin(digit_sum)[2:]
    
    except Exception as e:
        return f"Error: {e}"
candidate = solve


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(1000) == "1", "Error"
    assert candidate(150) == "110", "Error"
    assert candidate(147) == "1100", "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate(333) == "1001", "Error"
    assert candidate(963) == "10010", "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
