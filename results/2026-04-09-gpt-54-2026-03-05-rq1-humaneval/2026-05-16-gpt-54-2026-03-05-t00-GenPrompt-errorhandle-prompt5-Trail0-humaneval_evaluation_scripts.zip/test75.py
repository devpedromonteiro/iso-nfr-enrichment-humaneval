
import unittest
import re
import sys
import math
import copy


def is_multiply_prime(a):
    """Return True if a is the product of exactly 3 prime numbers, else False.

    The 3 prime numbers do not need to be distinct.
    Examples:
        30 = 2 * 3 * 5 -> True
         8 = 2 * 2 * 2 -> True
        12 = 2 * 2 * 3 -> True
    """
    # Error management: validate type
    if not isinstance(a, int):
        return False

    # Error management: invalid range / impossible values
    if a < 2:
        return False

    def is_prime(n):
        """Check if n is prime."""
        if not isinstance(n, int) or n < 2:
            return False
        if n == 2:
            return True
        if n % 2 == 0:
            return False

        i = 3
        while i * i <= n:
            if n % i == 0:
                return False
            i += 2
        return True

    # Try all combinations of 3 primes whose product could be a
    for i in range(2, a + 1):
        if not is_prime(i):
            continue
        for j in range(2, a + 1):
            if not is_prime(j):
                continue
            for k in range(2, a + 1):
                if not is_prime(k):
                    continue
                if i * j * k == a:
                    return True

    return False
candidate = is_multiply_prime


def check(candidate):

    assert candidate(5) == False
    assert candidate(30) == True
    assert candidate(8) == True
    assert candidate(10) == False
    assert candidate(125) == True
    assert candidate(3 * 5 * 7) == True
    assert candidate(3 * 6 * 7) == False
    assert candidate(9 * 9 * 9) == False
    assert candidate(11 * 9 * 9) == False
    assert candidate(11 * 13 * 7) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
