
import unittest
import re
import sys
import math
import copy


def circular_shift(x, shift):
    """Circular shift the digits of the integer x, shift the digits right by shift
    and return the result as a string.
    If shift > number of digits, return digits reversed.
    >>> circular_shift(12, 1)
    "21"
    >>> circular_shift(12, 2)
    "12"
    """
    # Error management: validate input types
    if not isinstance(x, int):
        raise TypeError("x must be an integer")
    if not isinstance(shift, int):
        raise TypeError("shift must be an integer")

    # Convert integer to string for digit manipulation
    digits = str(x)
    n = len(digits)

    # Error management: handle negative shift
    if shift < 0:
        raise ValueError("shift must be non-negative")

    # If shift exceeds number of digits, return reversed digits
    if shift > n:
        return digits[::-1]

    # Normalize shift for exact-length or smaller rotations
    shift = shift % n

    # Circular right shift
    return digits[-shift:] + digits[:-shift] if shift != 0 else digits
candidate = circular_shift


def check(candidate):

    # Check some simple cases
    assert candidate(100, 2) == "001"
    assert candidate(12, 2) == "12"
    assert candidate(97, 8) == "79"
    assert candidate(12, 1) == "21", "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(11, 101) == "11", "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
