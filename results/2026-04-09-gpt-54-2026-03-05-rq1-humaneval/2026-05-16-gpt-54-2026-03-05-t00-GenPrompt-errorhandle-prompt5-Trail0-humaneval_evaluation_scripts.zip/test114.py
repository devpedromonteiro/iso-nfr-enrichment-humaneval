
import unittest
import re
import sys
import math
import copy


def minSubArraySum(nums):
    """
    Given an array of integers nums, find the minimum sum of any non-empty sub-array
    of nums.

    Examples:
        minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
        minSubArraySum([-1, -2, -3]) == -6
    """
    # Error management: validate input type
    if nums is None:
        raise ValueError("Input cannot be None")

    if not isinstance(nums, (list, tuple)):
        raise TypeError("Input must be a list or tuple of integers")

    if len(nums) == 0:
        raise ValueError("Input array must be non-empty")

    # Error management: validate contents
    for i, num in enumerate(nums):
        if not isinstance(num, int):
            raise TypeError(f"Element at index {i} is not an integer: {num}")

    try:
        # Kadane-style algorithm for minimum subarray sum
        current_min = global_min = nums[0]

        for num in nums[1:]:
            current_min = min(num, current_min + num)
            global_min = min(global_min, current_min)

        return global_min

    except Exception as e:
        # Fallback error handling for unexpected runtime issues
        raise RuntimeError(f"An unexpected error occurred while computing minimum subarray sum: {e}")
candidate = minSubArraySum


def check(candidate):

    # Check some simple cases
    assert candidate([2, 3, 4, 1, 2, 4]) == 1, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([-1, -2, -3]) == -6
    assert candidate([-1, -2, -3, 2, -10]) == -14
    assert candidate([-9999999999999999]) == -9999999999999999
    assert candidate([0, 10, 20, 1000000]) == 0
    assert candidate([-1, -2, -3, 10, -5]) == -6
    assert candidate([100, -1, -2, -3, 10, -5]) == -6
    assert candidate([10, 11, 13, 8, 3, 4]) == 3
    assert candidate([100, -33, 32, -1, 0, -2]) == -33

    # Check some edge cases that are easy to work out by hand.
    assert candidate([-10]) == -10, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([7]) == 7
    assert candidate([1, -1]) == -1


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
