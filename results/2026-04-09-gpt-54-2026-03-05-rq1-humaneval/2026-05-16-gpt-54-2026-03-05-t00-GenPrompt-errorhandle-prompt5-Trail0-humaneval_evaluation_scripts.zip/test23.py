
import unittest
import re
import sys
import math
import copy



def strlen(string: str) -> int:
    """Return length of given string.

    Uses multiple error-management techniques:
    - Type checking
    - None checking
    - Defensive exception handling

    >>> strlen('')
    0
    >>> strlen('abc')
    3
    """
    if string is None:
        raise ValueError("Input cannot be None")

    if not isinstance(string, str):
        raise TypeError(f"Expected str, got {type(string).__name__}")

    try:
        return len(string)
    except Exception as exc:
        raise RuntimeError("Failed to calculate string length") from exc
candidate = strlen




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == 0
    assert candidate('x') == 1
    assert candidate('asdasnakj') == 9


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
