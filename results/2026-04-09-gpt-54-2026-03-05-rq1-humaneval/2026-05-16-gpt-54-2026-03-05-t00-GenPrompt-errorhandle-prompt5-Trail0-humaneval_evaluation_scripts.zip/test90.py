
import unittest
import re
import sys
import math
import copy


def next_smallest(lst):
    """
    You are given a list of integers.
    Write a function next_smallest() that returns the 2nd smallest element of the list.
    Return None if there is no such element.
    
    next_smallest([1, 2, 3, 4, 5]) == 2
    next_smallest([5, 1, 4, 3, 2]) == 2
    next_smallest([]) == None
    next_smallest([1, 1]) == None
    """
    # Error management: validate input type
    if not isinstance(lst, list):
        return None

    # Error management: handle empty or too-small lists early
    if len(lst) < 2:
        return None

    # Error management: ensure all elements are integers
    if not all(isinstance(x, int) for x in lst):
        return None

    try:
        # Remove duplicates so "2nd smallest" means distinct value
        unique_values = sorted(set(lst))

        # Return None if there is no second distinct smallest
        if len(unique_values) < 2:
            return None

        return unique_values[1]

    except (TypeError, ValueError):
        # Catch unexpected issues during sorting/set conversion
        return None
candidate = next_smallest


def check(candidate):

    # Check some simple cases
    assert candidate([1, 2, 3, 4, 5]) == 2
    assert candidate([5, 1, 4, 3, 2]) == 2
    assert candidate([]) == None
    assert candidate([1, 1]) == None
    assert candidate([1,1,1,1,0]) == 1
    assert candidate([1, 0**0]) == None
    assert candidate([-35, 34, 12, -45]) == -35

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
