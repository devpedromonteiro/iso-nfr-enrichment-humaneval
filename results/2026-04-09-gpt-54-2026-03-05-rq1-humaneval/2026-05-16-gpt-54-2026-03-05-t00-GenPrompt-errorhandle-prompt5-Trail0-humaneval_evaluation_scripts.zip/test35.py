
import unittest
import re
import sys
import math
import copy



def max_element(l: list):
    """Return maximum element in the list.
    >>> max_element([1, 2, 3])
    3
    >>> max_element([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    123
    """
    # Type validation
    if not isinstance(l, list):
        raise TypeError("Input must be a list.")

    # Value validation
    if len(l) == 0:
        raise ValueError("List must not be empty.")

    # Element validation
    for i, item in enumerate(l):
        if not isinstance(item, (int, float)):
            raise TypeError(f"Element at index {i} is not a number: {item!r}")

    try:
        maximum = l[0]
        for item in l[1:]:
            if item > maximum:
                maximum = item
        return maximum
    except Exception as e:
        raise RuntimeError(f"Unexpected error while finding maximum: {e}")
candidate = max_element




METADATA = {}


def check(candidate):
    assert candidate([1, 2, 3]) == 3
    assert candidate([5, 3, -5, 2, -3, 3, 9, 0, 124, 1, -10]) == 124


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
