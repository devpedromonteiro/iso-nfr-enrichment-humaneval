
import unittest
import re
import sys
import math
import copy

from typing import List, Tuple


from typing import List


def rolling_max(numbers: List[int]) -> List[int]:
    """From a given list of integers, generate a list of rolling maximum
    element found until given moment in the sequence.

    >>> rolling_max([1, 2, 3, 2, 3, 4, 2])
    [1, 2, 3, 3, 3, 4, 4]
    """
    # Error management: validate input type
    if numbers is None:
        raise ValueError("Input cannot be None")
    if not isinstance(numbers, list):
        raise TypeError("Input must be a list")
    if not all(isinstance(x, int) for x in numbers):
        raise TypeError("All elements in the list must be integers")

    # Handle empty input safely
    if not numbers:
        return []

    result = []
    current_max = numbers[0]

    for num in numbers:
        try:
            if num > current_max:
                current_max = num
            result.append(current_max)
        except TypeError as e:
            raise TypeError(f"Invalid comparison encountered with value {num}: {e}")

    return result
candidate = rolling_max




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == []
    assert candidate([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert candidate([4, 3, 2, 1]) == [4, 4, 4, 4]
    assert candidate([3, 2, 3, 100, 3]) == [3, 3, 3, 100, 100]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
