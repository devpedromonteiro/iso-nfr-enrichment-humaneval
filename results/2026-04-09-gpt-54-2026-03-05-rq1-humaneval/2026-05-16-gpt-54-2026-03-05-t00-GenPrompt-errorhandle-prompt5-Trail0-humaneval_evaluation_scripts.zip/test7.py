
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    """Filter an input list of strings only for ones that contain given substring.

    Error management techniques used:
    - Type validation for inputs
    - Graceful handling of invalid elements inside the list
    - Safe fallback return on unexpected errors

    >>> filter_by_substring([], 'a')
    []
    >>> filter_by_substring(['abc', 'bacd', 'cde', 'array'], 'a')
    ['abc', 'bacd', 'array']
    """
    try:
        if not isinstance(strings, list):
            raise TypeError("strings must be a list")
        if not isinstance(substring, str):
            raise TypeError("substring must be a string")

        result = []
        for item in strings:
            try:
                if isinstance(item, str) and substring in item:
                    result.append(item)
            except Exception:
                # Skip malformed items safely
                continue

        return result

    except TypeError:
        raise
    except Exception:
        # Fallback for any unforeseen error
        return []
candidate = filter_by_substring




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([], 'john') == []
    assert candidate(['xxx', 'asd', 'xxy', 'john doe', 'xxxAAA', 'xxx'], 'xxx') == ['xxx', 'xxxAAA', 'xxx']
    assert candidate(['xxx', 'asd', 'aaaxxy', 'john doe', 'xxxAAA', 'xxx'], 'xx') == ['xxx', 'aaaxxy', 'xxxAAA', 'xxx']
    assert candidate(['grunt', 'trumpet', 'prune', 'gruesome'], 'run') == ['grunt', 'prune']


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
