
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def mean_absolute_deviation(numbers: List[float]) -> float:
    """For a given list of input numbers, calculate Mean Absolute Deviation
    around the mean of this dataset.

    Mean Absolute Deviation is the average absolute difference between each
    element and a centerpoint (mean in this case):
    MAD = average | x - x_mean |

    >>> mean_absolute_deviation([1.0, 2.0, 3.0, 4.0])
    1.0
    """
    # Type validation
    if not isinstance(numbers, list):
        raise TypeError("Input must be a list of numbers.")

    # Empty input check
    if not numbers:
        raise ValueError("Input list must not be empty.")

    # Element validation
    for i, value in enumerate(numbers):
        if not isinstance(value, (int, float)):
            raise TypeError(f"Element at index {i} is not a number: {value!r}")

    try:
        mean = sum(numbers) / len(numbers)
        mad = sum(abs(x - mean) for x in numbers) / len(numbers)
    except ZeroDivisionError as e:
        raise ValueError("Cannot compute mean absolute deviation for an empty list.") from e
    except OverflowError as e:
        raise OverflowError("Numerical overflow occurred during calculation.") from e
    except Exception as e:
        raise RuntimeError(f"Unexpected error during calculation: {e}") from e

    return float(mad)
candidate = mean_absolute_deviation




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert abs(candidate([1.0, 2.0, 3.0]) - 2.0/3.0) < 1e-6
    assert abs(candidate([1.0, 2.0, 3.0, 4.0]) - 1.0) < 1e-6
    assert abs(candidate([1.0, 2.0, 3.0, 4.0, 5.0]) - 6.0/5.0) < 1e-6



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
