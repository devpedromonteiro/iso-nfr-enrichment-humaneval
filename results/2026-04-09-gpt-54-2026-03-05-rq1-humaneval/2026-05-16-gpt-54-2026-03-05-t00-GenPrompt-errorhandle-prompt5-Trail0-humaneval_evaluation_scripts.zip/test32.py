
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[2] * x^2 + .... + xs[n] * x^n
    """
    if not isinstance(xs, list):
        raise TypeError("xs must be a list of coefficients")
    if len(xs) == 0:
        raise ValueError("xs must not be empty")
    if not isinstance(x, (int, float)):
        raise TypeError("x must be a number")

    try:
        return sum(coeff * math.pow(x, i) for i, coeff in enumerate(xs))
    except TypeError as e:
        raise TypeError("all coefficients in xs must be numeric") from e


def find_zero(xs: list):
    """ xs are coefficients of a polynomial.
    find_zero find x such that poly(x) = 0.
    find_zero returns only only zero point, even if there are many.
    Moreover, find_zero only takes list xs having even number of coefficients
    and largest non zero coefficient as it guarantees
    a solution.
    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3
    1.0
    """
    # Input validation
    if not isinstance(xs, list):
        raise TypeError("xs must be a list")
    if len(xs) == 0:
        raise ValueError("xs must not be empty")
    if len(xs) % 2 != 0:
        raise ValueError("xs must contain an even number of coefficients")
    if not all(isinstance(c, (int, float)) for c in xs):
        raise TypeError("all coefficients must be numeric")

    # Remove trailing zeros to determine actual degree
    ys = xs[:]
    while len(ys) > 1 and ys[-1] == 0:
        ys.pop()

    if ys[-1] == 0:
        raise ValueError("largest non-zero coefficient must exist")

    # Degree must be odd (which is guaranteed by even number of coefficients)
    degree = len(ys) - 1
    if degree % 2 == 0:
        raise ValueError("polynomial degree must be odd")

    # Direct handling for x = 0
    if poly(ys, 0.0) == 0:
        return 0.0

    # Find interval [lo, hi] with sign change
    lo, hi = -1.0, 1.0
    f_lo = poly(ys, lo)
    f_hi = poly(ys, hi)

    max_expand = 10_000
    expand_count = 0

    while f_lo * f_hi > 0:
        lo *= 2
        hi *= 2
        f_lo = poly(ys, lo)
        f_hi = poly(ys, hi)
        expand_count += 1
        if expand_count > max_expand:
            raise RuntimeError("failed to bracket a root")

    # Bisection method
    tol = 1e-12
    max_iter = 10_000

    for _ in range(max_iter):
        mid = (lo + hi) / 2.0
        f_mid = poly(ys, mid)

        if abs(f_mid) < tol or abs(hi - lo) < tol:
            return mid

        if f_lo * f_mid <= 0:
            hi = mid
            f_hi = f_mid
        else:
            lo = mid
            f_lo = f_mid

    raise RuntimeError("bisection did not converge")
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
