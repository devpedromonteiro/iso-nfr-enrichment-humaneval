
import unittest
import re
import sys
import math
import copy


def is_equal_to_sum_even(n):
    """Evaluate whether the given number n can be written as the sum of exactly 4 positive even numbers.

    Example:
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """
    try:
        # Reject booleans explicitly since bool is a subclass of int
        if isinstance(n, bool):
            return False

        # Ensure input is numeric/integer-like
        if not isinstance(n, int):
            # Allow values like 8.0 but reject 8.5 or non-numeric types
            if isinstance(n, float):
                if not n.is_integer():
                    return False
                n = int(n)
            else:
                return False

        # Minimum sum of 4 positive even numbers is 2 + 2 + 2 + 2 = 8
        # Any valid sum must also be even
        return n >= 8 and n % 2 == 0

    except (TypeError, ValueError, OverflowError):
        return False
    except Exception:
        # Fallback for any unexpected error
        return False
candidate = is_equal_to_sum_even


def check(candidate):
    assert candidate(4) == False
    assert candidate(6) == False
    assert candidate(8) == True
    assert candidate(10) == True
    assert candidate(11) == False
    assert candidate(12) == True
    assert candidate(13) == False
    assert candidate(16) == True


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
