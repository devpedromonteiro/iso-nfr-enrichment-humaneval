
import unittest
import re
import sys
import math
import copy



def encode_cyclic(s: str):
    """
    returns encoded string by cycling groups of three characters.
    """
    # split string to groups. Each of length 3.
    groups = [s[(3 * i):min((3 * i + 3), len(s))] for i in range((len(s) + 2) // 3)]
    # cycle elements in each group. Unless group has fewer elements than 3.
    groups = [(group[1:] + group[0]) if len(group) == 3 else group for group in groups]
    return "".join(groups)


def encode_cyclic(s: str):
    """
    Returns encoded string by cycling groups of three characters.

    Example:
        "abcdef" -> "bcaefd"
    """
    if not isinstance(s, str):
        raise TypeError("encode_cyclic expects a string")

    # split string to groups, each of length 3
    groups = [s[3 * i:min(3 * i + 3, len(s))] for i in range((len(s) + 2) // 3)]

    # cycle elements in each group unless group has fewer than 3 characters
    groups = [(group[1:] + group[0]) if len(group) == 3 else group for group in groups]
    return "".join(groups)


def decode_cyclic(s: str):
    """
    Takes as input a string encoded with encode_cyclic function.
    Returns decoded string.

    Example:
        "bcaefd" -> "abcdef"
    """
    try:
        if not isinstance(s, str):
            raise TypeError("decode_cyclic expects a string")

        # split string to groups, each of length 3
        groups = [s[3 * i:min(3 * i + 3, len(s))] for i in range((len(s) + 2) // 3)]

        # reverse the cycle: xyz (encoded as yzx) -> xyz
        groups = [(group[-1] + group[:-1]) if len(group) == 3 else group for group in groups]

        return "".join(groups)

    except TypeError:
        raise
    except Exception as e:
        raise ValueError(f"Failed to decode cyclic string: {e}") from e
candidate = decode_cyclic




METADATA = {}


def check(candidate):
    from random import randint, choice
    import string

    letters = string.ascii_lowercase
    for _ in range(100):
        str = ''.join(choice(letters) for i in range(randint(10, 20)))
        encoded_str = encode_cyclic(str)
        assert candidate(encoded_str) == str



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
