
import unittest
import re
import sys
import math
import copy


def exchange(lst1, lst2):
    """In this problem, you will implement a function that takes two lists of numbers,
    and determines whether it is possible to perform an exchange of elements
    between them to make lst1 a list of only even numbers.
    There is no limit on the number of exchanged elements between lst1 and lst2.
    If it is possible to exchange elements between the lst1 and lst2 to make
    all the elements of lst1 to be even, return "YES".
    Otherwise, return "NO".
    For example:
    exchange([1, 2, 3, 4], [1, 2, 3, 4]) => "YES"
    exchange([1, 2, 3, 4], [1, 5, 3, 4]) => "NO"
    It is assumed that the input lists will be non-empty.
    """
    try:
        if not isinstance(lst1, list) or not isinstance(lst2, list):
            raise TypeError("Both inputs must be lists.")
        if not lst1 or not lst2:
            raise ValueError("Input lists must be non-empty.")
        if not all(isinstance(x, (int, float)) for x in lst1 + lst2):
            raise ValueError("All elements in both lists must be numbers.")

        odd_count_lst1 = sum(1 for x in lst1 if x % 2 != 0)
        even_count_lst2 = sum(1 for x in lst2 if x % 2 == 0)

        return "YES" if even_count_lst2 >= odd_count_lst1 else "NO"

    except TypeError as te:
        return f"TypeError: {te}"
    except ValueError as ve:
        return f"ValueError: {ve}"
    except Exception as e:
        return f"Unexpected error: {e}"
candidate = exchange


def check(candidate):

    # Check some simple cases
    assert candidate([1, 2, 3, 4], [1, 2, 3, 4]) == "YES"
    assert candidate([1, 2, 3, 4], [1, 5, 3, 4]) == "NO"
    assert candidate([1, 2, 3, 4], [2, 1, 4, 3]) == "YES" 
    assert candidate([5, 7, 3], [2, 6, 4]) == "YES"
    assert candidate([5, 7, 3], [2, 6, 3]) == "NO" 
    assert candidate([3, 2, 6, 1, 8, 9], [3, 5, 5, 1, 1, 1]) == "NO"

    # Check some edge cases that are easy to work out by hand.
    assert candidate([100, 200], [200, 200]) == "YES"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
