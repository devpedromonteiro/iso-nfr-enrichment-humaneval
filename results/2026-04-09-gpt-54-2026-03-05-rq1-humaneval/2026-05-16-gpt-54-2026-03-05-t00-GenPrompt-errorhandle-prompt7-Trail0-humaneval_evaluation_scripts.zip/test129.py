
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Given a grid with N rows and N columns (N >= 2) and a positive integer k,
    each cell of the grid contains a value. Every integer in the range [1, N * N]
    inclusive appears exactly once on the cells of the grid.

    Return the lexicographically smallest path of length k, where each move goes
    to an edge-adjacent neighbor cell.

    Error handling:
    - Raises TypeError for wrong input types.
    - Raises ValueError for invalid shapes, invalid k, or invalid grid contents.
    """
    # Type checks
    if not isinstance(grid, list):
        raise TypeError("grid must be a list of lists")
    if not isinstance(k, int):
        raise TypeError("k must be an integer")

    # Basic value checks
    if k <= 0:
        raise ValueError("k must be a positive integer")
    if len(grid) < 2:
        raise ValueError("grid must have at least 2 rows")

    n = len(grid)

    # Validate square grid
    for row in grid:
        if not isinstance(row, list):
            raise TypeError("each row in grid must be a list")
        if len(row) != n:
            raise ValueError("grid must be square (N x N)")

    # Validate contents
    vals = []
    for row in grid:
        for x in row:
            if not isinstance(x, int):
                raise TypeError("all grid values must be integers")
            vals.append(x)

    expected = set(range(1, n * n + 1))
    if set(vals) != expected or len(vals) != len(set(vals)):
        raise ValueError("grid must contain each integer from 1 to N*N exactly once")

    # Map value -> position
    pos = {}
    for i in range(n):
        for j in range(n):
            pos[grid[i][j]] = (i, j)

    # Build adjacency by value
    neighbors = {}
    for val in range(1, n * n + 1):
        i, j = pos[val]
        adj = []
        for di, dj in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            ni, nj = i + di, j + dj
            if 0 <= ni < n and 0 <= nj < n:
                adj.append(grid[ni][nj])
        neighbors[val] = sorted(adj)

    # Greedy construction:
    # At each step choose the smallest possible next value reachable from
    # any current candidate endpoint that preserves lexicographic minimality.
    current = [min(pos.keys())]
    candidates = {current[0]}

    for _ in range(1, k):
        next_candidates = set()
        best_next = None

        for val in candidates:
            for nxt in neighbors[val]:
                if best_next is None or nxt < best_next:
                    best_next = nxt
                    next_candidates = {nxt}
                elif nxt == best_next:
                    next_candidates.add(nxt)

        current.append(best_next)

        # New candidate endpoints are cells with value best_next that are reachable
        # from previous candidate endpoints. Since values are unique, this is enough.
        new_endpoints = set()
        for val in candidates:
            if best_next in neighbors[val]:
                new_endpoints.add(best_next)
        candidates = new_endpoints

    return current
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
