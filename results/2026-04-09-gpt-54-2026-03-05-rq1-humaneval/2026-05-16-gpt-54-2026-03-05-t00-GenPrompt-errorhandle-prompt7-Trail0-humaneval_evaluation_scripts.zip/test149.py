
import unittest
import re
import sys
import math
import copy


def sorted_list_sum(lst):
    """Accept a list of strings, remove strings with odd lengths,
    and return the remaining strings sorted by length, then alphabetically.
    """
    try:
        if not isinstance(lst, list):
            raise TypeError("Input must be a list.")

        if not all(isinstance(item, str) for item in lst):
            raise TypeError("All elements in the list must be strings.")

        even_strings = [s for s in lst if len(s) % 2 == 0]
        return sorted(even_strings, key=lambda x: (len(x), x))

    except TypeError as e:
        return f"TypeError: {e}"
    except Exception as e:
        return f"Unexpected error: {e}"
candidate = sorted_list_sum


def check(candidate):

    # Check some simple cases
    assert candidate(["aa", "a", "aaa"]) == ["aa"]
    assert candidate(["school", "AI", "asdf", "b"]) == ["AI", "asdf", "school"]
    assert candidate(["d", "b", "c", "a"]) == []
    assert candidate(["d", "dcba", "abcd", "a"]) == ["abcd", "dcba"]

    # Check some edge cases that are easy to work out by hand.
    assert candidate(["AI", "ai", "au"]) == ["AI", "ai", "au"]
    assert candidate(["a", "b", "b", "c", "c", "a"]) == []
    assert candidate(['aaaa', 'bbbb', 'dd', 'cc']) == ["cc", "dd", "aaaa", "bbbb"]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
