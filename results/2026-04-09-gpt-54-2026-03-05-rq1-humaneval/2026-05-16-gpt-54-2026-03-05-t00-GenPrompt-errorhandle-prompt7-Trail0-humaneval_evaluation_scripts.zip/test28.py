
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def concatenate(strings: List[str]) -> str:
    """Concatenate list of strings into a single string.

    >>> concatenate([])
    ''
    >>> concatenate(['a', 'b', 'c'])
    'abc'
    """
    if strings is None:
        raise ValueError("strings must not be None")

    if not isinstance(strings, list):
        raise TypeError("strings must be a list of strings")

    try:
        for s in strings:
            if not isinstance(s, str):
                raise TypeError("all items in strings must be str")
        return "".join(strings)
    except TypeError as e:
        raise TypeError(f"failed to concatenate strings: {e}") from e
candidate = concatenate




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == ''
    assert candidate(['x', 'y', 'z']) == 'xyz'
    assert candidate(['x', 'y', 'z', 'w', 'k']) == 'xyzwk'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
