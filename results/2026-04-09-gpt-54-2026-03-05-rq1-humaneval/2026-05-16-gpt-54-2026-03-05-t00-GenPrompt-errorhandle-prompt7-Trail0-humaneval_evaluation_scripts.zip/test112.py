
import unittest
import re
import sys
import math
import copy


def reverse_delete(s, c):
    """Task
    We are given two strings s and c, you have to deleted all the characters in s
    that are equal to any character in c then check if the result string is palindrome.
    A string is called palindrome if it reads the same backward as forward.
    You should return a tuple containing the result string and True/False for the check.
    Example
    For s = "abcde", c = "ae", the result should be ('bcd',False)
    For s = "abcdef", c = "b"  the result should be ('acdef',False)
    For s = "abcdedcba", c = "ab", the result should be ('cdedc',True)
    """
    try:
        if not isinstance(s, str) or not isinstance(c, str):
            raise TypeError("Both s and c must be strings")

        result = ''.join(ch for ch in s if ch not in c)
        return (result, result == result[::-1])

    except TypeError as e:
        return (str(e), False)
    except Exception:
        return ("Unexpected error", False)
candidate = reverse_delete


def check(candidate):

    assert candidate("abcde","ae") == ('bcd',False)
    assert candidate("abcdef", "b") == ('acdef',False)
    assert candidate("abcdedcba","ab") == ('cdedc',True)
    assert candidate("dwik","w") == ('dik',False)
    assert candidate("a","a") == ('',True)
    assert candidate("abcdedcba","") == ('abcdedcba',True)
    assert candidate("abcdedcba","v") == ('abcdedcba',True)
    assert candidate("vabba","v") == ('abba',True)
    assert candidate("mamma", "mia") == ("", True)


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
