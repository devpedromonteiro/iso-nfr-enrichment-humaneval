
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    You are given a positive integer n. Create an array a of length n where:
        a[i] = i*i - i + 1   for 1 <= i <= n

    Return the number of triples (a[i], a[j], a[k]) such that:
        i < j < k
        and (a[i] + a[j] + a[k]) % 3 == 0

    Example:
        Input: n = 5
        Output: 1
    """
    # Error handling: type check
    if not isinstance(n, int):
        raise TypeError("n must be an integer")

    # Error handling: value check
    if n <= 0:
        raise ValueError("n must be a positive integer")

    # Observe:
    # a[i] = i^2 - i + 1 = i(i-1) + 1
    # Since i(i-1) is always divisible by 2 but we care mod 3:
    # Check pattern modulo 3:
    # i % 3 == 0 -> a[i] % 3 == 1
    # i % 3 == 1 -> a[i] % 3 == 1
    # i % 3 == 2 -> a[i] % 3 == 0
    #
    # So values are only 0 or 1 modulo 3.
    # For sum of 3 numbers to be divisible by 3, the only possible combination is:
    # 1 + 1 + 1 â¡ 0 (mod 3)
    # Thus all three chosen elements must come from indices i where i % 3 != 2.

    count_mod_1 = 0
    for i in range(1, n + 1):
        if i % 3 != 2:
            count_mod_1 += 1

    # Number of ways to choose 3 such elements
    if count_mod_1 < 3:
        return 0

    return count_mod_1 * (count_mod_1 - 1) * (count_mod_1 - 2) // 6
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
