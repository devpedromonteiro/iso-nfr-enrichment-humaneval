
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def rescale_to_unit(numbers: List[float]) -> List[float]:
    """Given a list of numbers, linearly rescale them so that the minimum becomes 0
    and the maximum becomes 1.

    The input must contain at least two elements, and not all values may be equal.

    >>> rescale_to_unit([1.0, 2.0, 3.0, 4.0, 5.0])
    [0.0, 0.25, 0.5, 0.75, 1.0]
    """
    if not isinstance(numbers, list):
        raise TypeError("numbers must be a list of floats")

    if len(numbers) < 2:
        raise ValueError("numbers must contain at least two elements")

    try:
        min_val = min(numbers)
        max_val = max(numbers)
    except TypeError as e:
        raise TypeError("all elements in numbers must be numeric") from e

    if min_val == max_val:
        raise ValueError("cannot rescale when all numbers are equal")

    scale = max_val - min_val
    return [(x - min_val) / scale for x in numbers]
candidate = rescale_to_unit




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([2.0, 49.9]) == [0.0, 1.0]
    assert candidate([100.0, 49.9]) == [1.0, 0.0]
    assert candidate([1.0, 2.0, 3.0, 4.0, 5.0]) == [0.0, 0.25, 0.5, 0.75, 1.0]
    assert candidate([2.0, 1.0, 5.0, 3.0, 4.0]) == [0.25, 0.0, 1.0, 0.5, 0.75]
    assert candidate([12.0, 11.0, 15.0, 13.0, 14.0]) == [0.25, 0.0, 1.0, 0.5, 0.75]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
