
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def string_xor(a: str, b: str) -> str:
    """Input are two strings a and b consisting only of 1s and 0s.
    Perform binary XOR on these inputs and return result also as a string.

    >>> string_xor('010', '110')
    '100'
    """
    if not isinstance(a, str) or not isinstance(b, str):
        raise TypeError("Both inputs must be strings.")

    if len(a) != len(b):
        raise ValueError("Input strings must have the same length.")

    if any(ch not in "01" for ch in a) or any(ch not in "01" for ch in b):
        raise ValueError("Input strings must contain only '0' and '1'.")

    try:
        return "".join("1" if x != y else "0" for x, y in zip(a, b))
    except Exception as e:
        raise RuntimeError(f"Unexpected error during XOR operation: {e}") from e
candidate = string_xor




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('111000', '101010') == '010010'
    assert candidate('1', '1') == '0'
    assert candidate('0101', '0000') == '0101'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
