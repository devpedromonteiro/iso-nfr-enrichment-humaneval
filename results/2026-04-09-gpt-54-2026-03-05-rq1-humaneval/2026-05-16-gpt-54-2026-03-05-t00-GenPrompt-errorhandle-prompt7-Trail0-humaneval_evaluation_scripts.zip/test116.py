
import unittest
import re
import sys
import math
import copy


def sort_array(arr):
    """
    Sort an array of integers by:
    1. Number of ones in their binary representation (ascending)
    2. Decimal value (ascending) when the number of ones is equal

    Examples:
    >>> sort_array([1, 5, 2, 3, 4])
    [1, 2, 3, 4, 5]
    >>> sort_array([-2, -3, -4, -5, -6])
    [-6, -5, -4, -3, -2]
    >>> sort_array([1, 0, 2, 3, 4])
    [0, 1, 2, 3, 4]
    """
    try:
        if not isinstance(arr, list):
            raise TypeError("Input must be a list.")

        if not all(isinstance(x, int) for x in arr):
            raise ValueError("All elements in the list must be integers.")

        return sorted(arr, key=lambda x: (bin(abs(x)).count('1'), x))

    except TypeError as te:
        print(f"Type error: {te}")
        return []

    except ValueError as ve:
        print(f"Value error: {ve}")
        return []

    except Exception as e:
        print(f"Unexpected error: {e}")
        return []
candidate = sort_array


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,5,2,3,4]) == [1, 2, 4, 3, 5]
    assert candidate([-2,-3,-4,-5,-6]) == [-4, -2, -6, -5, -3]
    assert candidate([1,0,2,3,4]) == [0, 1, 2, 4, 3]
    assert candidate([]) == []
    assert candidate([2,5,77,4,5,3,5,7,2,3,4]) == [2, 2, 4, 4, 3, 3, 5, 5, 5, 7, 77]
    assert candidate([3,6,44,12,32,5]) == [32, 3, 5, 6, 12, 44]
    assert candidate([2,4,8,16,32]) == [2, 4, 8, 16, 32]
    assert candidate([2,4,8,16,32]) == [2, 4, 8, 16, 32]

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
