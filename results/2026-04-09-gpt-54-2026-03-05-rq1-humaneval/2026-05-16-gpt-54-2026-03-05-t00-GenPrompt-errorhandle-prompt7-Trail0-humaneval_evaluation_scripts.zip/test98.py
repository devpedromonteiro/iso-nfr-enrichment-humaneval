
import unittest
import re
import sys
import math
import copy


def count_upper(s):
    """
    Given a string s, count the number of uppercase vowels in even indices.
    
    For example:
    count_upper('aBCdEf') returns 1
    count_upper('abcdefg') returns 0
    count_upper('dBBE') returns 0
    """
    try:
        if not isinstance(s, str):
            raise TypeError("Input must be a string")
        
        count = 0
        vowels = "AEIOU"
        
        for i in range(0, len(s), 2):
            if s[i] in vowels:
                count += 1
                
        return count

    except TypeError as e:
        print(f"Error: {e}")
        return 0
    except Exception as e:
        print(f"Unexpected error: {e}")
        return 0
candidate = count_upper


def check(candidate):

    # Check some simple cases
    assert candidate('aBCdEf')  == 1
    assert candidate('abcdefg') == 0
    assert candidate('dBBE') == 0
    assert candidate('B')  == 0
    assert candidate('U')  == 1
    assert candidate('') == 0
    assert candidate('EEEE') == 2

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
