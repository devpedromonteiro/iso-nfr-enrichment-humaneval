
import unittest
import re
import sys
import math
import copy


def count_nums(arr):
    """
    Write a function count_nums which takes an array of integers and returns
    the number of elements which has a sum of digits > 0.
    If a number is negative, then its first signed digit will be negative:
    e.g. -123 has signed digits -1, 2, and 3.
    >>> count_nums([]) == 0
    >>> count_nums([-1, 11, -11]) == 1
    >>> count_nums([1, 1, 2]) == 3
    """
    if arr is None:
        raise ValueError("Input cannot be None")
    if not isinstance(arr, list):
        raise TypeError("Input must be a list of integers")

    count = 0

    for num in arr:
        if not isinstance(num, int):
            raise TypeError("All elements must be integers")

        try:
            digit_sum = sum(map(int, str(num)))
        except ValueError:
            s = str(num)
            digit_sum = -int(s[1]) + sum(int(ch) for ch in s[2:]) if num < 0 else sum(int(ch) for ch in s)

        if digit_sum > 0:
            count += 1

    return count
candidate = count_nums


def check(candidate):

    # Check some simple cases
    assert candidate([]) == 0
    assert candidate([-1, -2, 0]) == 0
    assert candidate([1, 1, 2, -2, 3, 4, 5]) == 6
    assert candidate([1, 6, 9, -6, 0, 1, 5]) == 5
    assert candidate([1, 100, 98, -7, 1, -1]) == 4
    assert candidate([12, 23, 34, -45, -56, 0]) == 5
    assert candidate([-0, 1**0]) == 1
    assert candidate([1]) == 1

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
