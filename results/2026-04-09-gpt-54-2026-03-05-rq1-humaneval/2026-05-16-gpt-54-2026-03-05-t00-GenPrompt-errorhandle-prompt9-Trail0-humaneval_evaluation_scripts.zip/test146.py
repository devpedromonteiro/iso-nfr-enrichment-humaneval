
import unittest
import re
import sys
import math
import copy


def specialFilter(nums):
    """Write a function that takes an array of numbers as input and returns 
    the number of elements in the array that are greater than 10 and both 
    first and last digits of a number are odd (1, 3, 5, 7, 9).
    """
    if not isinstance(nums, (list, tuple)):
        raise TypeError("Input must be a list or tuple of integers.")

    count = 0
    for x in nums:
        if not isinstance(x, int):
            raise TypeError(f"All elements must be integers. Invalid element: {x}")

        if x > 10:
            s = str(abs(x))
            if int(s[0]) % 2 == 1 and int(s[-1]) % 2 == 1:
                count += 1

    return count
candidate = specialFilter


def check(candidate):

    # Check some simple cases
    assert candidate([5, -2, 1, -5]) == 0  
    assert candidate([15, -73, 14, -15]) == 1
    assert candidate([33, -2, -3, 45, 21, 109]) == 2
    assert candidate([43, -12, 93, 125, 121, 109]) == 4
    assert candidate([71, -2, -33, 75, 21, 19]) == 3


    # Check some edge cases that are easy to work out by hand.
    assert candidate([1]) == 0              
    assert candidate([]) == 0                   



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
