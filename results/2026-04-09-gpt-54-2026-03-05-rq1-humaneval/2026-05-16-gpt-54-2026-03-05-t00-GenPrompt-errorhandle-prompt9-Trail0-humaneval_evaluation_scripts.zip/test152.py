
import unittest
import re
import sys
import math
import copy


def compare(game, guess):
    """Return absolute differences between corresponding scores and guesses."""
    if not isinstance(game, (list, tuple)) or not isinstance(guess, (list, tuple)):
        raise TypeError("Both game and guess must be lists or tuples.")
    
    if len(game) != len(guess):
        raise ValueError("game and guess must have the same length.")
    
    result = []
    for g, h in zip(game, guess):
        if not isinstance(g, (int, float)) or not isinstance(h, (int, float)):
            raise TypeError("All elements in game and guess must be numeric.")
        result.append(abs(g - h))
    
    return result
candidate = compare


def check(candidate):

    # Check some simple cases
    assert candidate([1,2,3,4,5,1],[1,2,3,4,2,-2])==[0,0,0,0,3,3], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([0,0,0,0,0,0],[0,0,0,0,0,0])==[0,0,0,0,0,0], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,2,3],[-1,-2,-3])==[2,4,6], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,2,3,5],[-1,2,3,4])==[2,0,0,1], "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
