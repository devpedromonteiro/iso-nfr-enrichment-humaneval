
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Given a grid with N rows and N columns (N >= 2) and a positive integer k, 
    each cell of the grid contains a value. Every integer in the range [1, N * N]
    inclusive appears exactly once on the cells of the grid.

    You have to find the minimum path of length k in the grid. You can start
    from any cell, and in each step you can move to any of the neighbor cells,
    in other words, you can go to cells which share an edge with your current
    cell.
    Please note that a path of length k means visiting exactly k cells (not
    necessarily distinct).
    You CANNOT go off the grid.
    A path A (of length k) is considered less than a path B (of length k) if
    after making the ordered lists of the values on the cells that A and B go
    through (let's call them lst_A and lst_B), lst_A is lexicographically less
    than lst_B.
    It is guaranteed that the answer is unique.
    Return an ordered list of the values on the cells that the minimum path goes through.

    Error handling:
    - Raises TypeError if grid is not a list of lists or k is not an integer.
    - Raises ValueError if:
        * grid is empty
        * grid is not square
        * N < 2
        * k <= 0
        * grid does not contain exactly the integers 1..N*N each once
    """

    # ---------- Input validation ----------
    if not isinstance(grid, list):
        raise TypeError("grid must be a list of lists")
    if not isinstance(k, int):
        raise TypeError("k must be an integer")
    if k <= 0:
        raise ValueError("k must be a positive integer")
    if not grid:
        raise ValueError("grid must not be empty")
    if not all(isinstance(row, list) for row in grid):
        raise TypeError("grid must be a list of lists")

    n = len(grid)
    if n < 2:
        raise ValueError("grid must have at least 2 rows and 2 columns")
    if any(len(row) != n for row in grid):
        raise ValueError("grid must be square (N x N)")

    flat = []
    for row in grid:
        for val in row:
            if not isinstance(val, int):
                raise TypeError("all grid values must be integers")
            flat.append(val)

    expected = set(range(1, n * n + 1))
    if set(flat) != expected or len(flat) != len(set(flat)):
        raise ValueError(f"grid must contain each integer from 1 to {n*n} exactly once")

    # ---------- Map values to positions ----------
    pos = {}
    for i in range(n):
        for j in range(n):
            pos[grid[i][j]] = (i, j)

    # ---------- Build best path greedily ----------
    # Since values are unique, the lexicographically smallest path must start
    # at the smallest possible value, then among reachable neighbors choose the
    # smallest possible next value, and so on.
    min_val = 1
    r, c = pos[min_val]
    result = [min_val]

    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]

    for _ in range(k - 1):
        neighbor_values = []
        for dr, dc in directions:
            nr, nc = r + dr, c + dc
            if 0 <= nr < n and 0 <= nc < n:
                neighbor_values.append((grid[nr][nc], nr, nc))

        next_val, r, c = min(neighbor_values)
        result.append(next_val)

    return result
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
