
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """Input to this function is a string representing multiple groups of
    nested parentheses separated by spaces.

    For each group, return the deepest level of nesting.

    Examples:
    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """
    if not isinstance(paren_string, str):
        raise TypeError("paren_string must be a string")

    if not paren_string.strip():
        return []

    results: List[int] = []

    for group_index, group in enumerate(paren_string.split(), start=1):
        depth = 0
        max_depth = 0

        for char_index, ch in enumerate(group, start=1):
            if ch == '(':
                depth += 1
                max_depth = max(max_depth, depth)
            elif ch == ')':
                depth -= 1
                if depth < 0:
                    raise ValueError(
                        f"Invalid parentheses group at group {group_index}, "
                        f"position {char_index}: too many closing parentheses"
                    )
            else:
                raise ValueError(
                    f"Invalid character {ch!r} at group {group_index}, "
                    f"position {char_index}: only '(' and ')' are allowed"
                )

        if depth != 0:
            raise ValueError(
                f"Invalid parentheses group at group {group_index}: "
                "unbalanced parentheses"
            )

        results.append(max_depth)

    return results
candidate = parse_nested_parens




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('(()()) ((())) () ((())()())') == [2, 3, 1, 3]
    assert candidate('() (()) ((())) (((())))') == [1, 2, 3, 4]
    assert candidate('(()(())((())))') == [4]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
