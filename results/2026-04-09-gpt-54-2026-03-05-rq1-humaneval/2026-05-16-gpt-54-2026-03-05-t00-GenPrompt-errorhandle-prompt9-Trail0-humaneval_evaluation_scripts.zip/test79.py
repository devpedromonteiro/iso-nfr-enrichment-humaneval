
import unittest
import re
import sys
import math
import copy


def decimal_to_binary(decimal):
    """You will be given a number in decimal form and your task is to convert it to
    binary format. The function should return a string, with each character representing a binary
    number. Each character in the string will be '0' or '1'.

    There will be an extra couple of characters 'db' at the beginning and at the end of the string.
    The extra characters are there to help with the format.

    Examples:
    decimal_to_binary(15)   # returns "db1111db"
    decimal_to_binary(32)   # returns "db100000db"
    """
    # Error handling: reject booleans explicitly since bool is a subclass of int
    if isinstance(decimal, bool):
        raise TypeError("Input must be an integer, not bool.")

    # Error handling: ensure input is an integer
    if not isinstance(decimal, int):
        raise TypeError("Input must be an integer.")

    # Error handling: ensure input is non-negative
    if decimal < 0:
        raise ValueError("Input must be a non-negative integer.")

    return f"db{bin(decimal)[2:]}db"
candidate = decimal_to_binary


def check(candidate):

    # Check some simple cases
    assert candidate(0) == "db0db"
    assert candidate(32) == "db100000db"
    assert candidate(103) == "db1100111db"
    assert candidate(15) == "db1111db", "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
