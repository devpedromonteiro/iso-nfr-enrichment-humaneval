
import unittest
import re
import sys
import math
import copy


def intersection(interval1, interval2):
    """You are given two intervals,
    where each interval is a pair of integers. For example, interval = (start, end) = (1, 2).
    The given intervals are closed which means that the interval (start, end)
    includes both start and end.
    For each given interval, it is assumed that its start is less or equal its end.
    Your task is to determine whether the length of intersection of these two 
    intervals is a prime number.
    Example, the intersection of the intervals (1, 3), (2, 4) is (2, 3)
    which its length is 1, which not a prime number.
    If the length of the intersection is a prime number, return "YES",
    otherwise, return "NO".
    If the two intervals don't intersect, return "NO".


    [input/output] samples:
    intersection((1, 2), (2, 3)) ==> "NO"
    intersection((-1, 1), (0, 4)) ==> "NO"
    intersection((-3, -1), (-5, 5)) ==> "YES"
    """
    
    def is_prime(n):
        if n < 2:
            return False
        i = 2
        while i * i <= n:
            if n % i == 0:
                return False
            i += 1
        return True

    # Basic validation
    if not isinstance(interval1, (tuple, list)) or not isinstance(interval2, (tuple, list)):
        raise TypeError("Both intervals must be tuples or lists of two integers.")
    if len(interval1) != 2 or len(interval2) != 2:
        raise ValueError("Each interval must contain exactly two values.")

    a, b = interval1
    c, d = interval2

    if not all(isinstance(x, int) for x in (a, b, c, d)):
        raise TypeError("Interval bounds must be integers.")
    if a > b or c > d:
        raise ValueError("Each interval must satisfy start <= end.")

    start = max(a, c)
    end = min(b, d)

    if start > end:
        return "NO"

    # Closed interval length in this problem is end - start
    length = end - start

    return "YES" if is_prime(length) else "NO"
candidate = intersection


def check(candidate):

    # Check some simple cases
    assert candidate((1, 2), (2, 3)) == "NO"
    assert candidate((-1, 1), (0, 4)) == "NO"
    assert candidate((-3, -1), (-5, 5)) == "YES"
    assert candidate((-2, 2), (-4, 0)) == "YES"

    # Check some edge cases that are easy to work out by hand.
    assert candidate((-11, 2), (-1, -1)) == "NO"
    assert candidate((1, 2), (3, 5)) == "NO"
    assert candidate((1, 2), (1, 2)) == "NO"
    assert candidate((-2, -2), (-3, -2)) == "NO"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
