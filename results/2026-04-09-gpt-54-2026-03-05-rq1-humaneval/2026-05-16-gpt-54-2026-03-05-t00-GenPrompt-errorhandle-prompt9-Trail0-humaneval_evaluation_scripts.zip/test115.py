
import unittest
import re
import sys
import math
import copy


import math

def max_fill(grid, capacity):
    """
    You are given a rectangular grid of wells. Each row represents a single well,
    and each 1 in a row represents a single unit of water.
    Each well has a corresponding bucket that can be used to extract water from it, 
    and all buckets have the same capacity.
    Your task is to use the buckets to empty the wells.
    Output the number of times you need to lower the buckets.
    """
    
    # Error handling: validate capacity
    if not isinstance(capacity, int):
        raise TypeError("capacity must be an integer")
    if capacity <= 0:
        raise ValueError("capacity must be greater than 0")
    
    # Error handling: validate grid
    if not isinstance(grid, list):
        raise TypeError("grid must be a list of lists")
    if len(grid) == 0:
        return 0
    
    row_length = None
    total_drops = 0
    
    for i, row in enumerate(grid):
        if not isinstance(row, list):
            raise TypeError(f"grid[{i}] must be a list")
        
        if row_length is None:
            row_length = len(row)
        elif len(row) != row_length:
            raise ValueError("all rows in grid must have the same length")
        
        for j, cell in enumerate(row):
            if cell not in (0, 1):
                raise ValueError(f"grid[{i}][{j}] must be 0 or 1")
        
        water_units = sum(row)
        total_drops += math.ceil(water_units / capacity)
    
    return total_drops
candidate = max_fill


def check(candidate):


    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([[0,0,1,0], [0,1,0,0], [1,1,1,1]], 1) == 6, "Error"
    assert candidate([[0,0,1,1], [0,0,0,0], [1,1,1,1], [0,1,1,1]], 2) == 5, "Error"
    assert candidate([[0,0,0], [0,0,0]], 5) == 0, "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([[1,1,1,1], [1,1,1,1]], 2) == 4, "Error"
    assert candidate([[1,1,1,1], [1,1,1,1]], 9) == 2, "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
