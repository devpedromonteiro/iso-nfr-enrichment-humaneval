
import unittest
import re
import sys
import math
import copy


def is_multiply_prime(a):
    """Return True if a is the product of exactly 3 prime numbers, else False.

    Notes:
    - a must be an integer
    - a is expected to be less than 100
    - repeated primes are allowed, e.g. 8 = 2 * 2 * 2 -> True
    """

    # Error handling: type check
    if not isinstance(a, int):
        raise TypeError("Input must be an integer.")

    # Error handling: value check
    if a < 2:
        return False

    def is_prime(n):
        if n < 2:
            return False
        for i in range(2, int(n ** 0.5) + 1):
            if n % i == 0:
                return False
        return True

    prime_factors = []

    for i in range(2, a + 1):
        while a % i == 0:
            if is_prime(i):
                prime_factors.append(i)
            a //= i
        if len(prime_factors) > 3:
            return False

    return len(prime_factors) == 3
candidate = is_multiply_prime


def check(candidate):

    assert candidate(5) == False
    assert candidate(30) == True
    assert candidate(8) == True
    assert candidate(10) == False
    assert candidate(125) == True
    assert candidate(3 * 5 * 7) == True
    assert candidate(3 * 6 * 7) == False
    assert candidate(9 * 9 * 9) == False
    assert candidate(11 * 9 * 9) == False
    assert candidate(11 * 13 * 7) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
