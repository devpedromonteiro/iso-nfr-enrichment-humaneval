
import unittest
import re
import sys
import math
import copy



def unique(l: list):
    if not isinstance(l, list):
        raise TypeError("unique() expects a list")
    return sorted(set(l))
candidate = unique




METADATA = {}


def check(candidate):
    assert candidate([5, 3, 5, 2, 3, 3, 9, 0, 123]) == [0, 2, 3, 5, 9, 123]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
