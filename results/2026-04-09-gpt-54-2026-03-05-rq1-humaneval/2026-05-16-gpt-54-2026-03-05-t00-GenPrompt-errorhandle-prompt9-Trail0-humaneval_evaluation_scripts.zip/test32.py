
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[2] * x^2 + .... + xs[n] * x^n
    """
    if not isinstance(xs, list):
        raise TypeError("xs must be a list of numeric coefficients")
    if not isinstance(x, (int, float)):
        raise TypeError("x must be a number")
    if not xs:
        raise ValueError("xs must not be empty")
    if not all(isinstance(coeff, (int, float)) for coeff in xs):
        raise TypeError("all coefficients in xs must be numeric")

    return sum(coeff * math.pow(x, i) for i, coeff in enumerate(xs))


def find_zero(xs: list):
    """xs are coefficients of a polynomial.

    find_zero finds x such that poly(xs, x) = 0.
    find_zero returns only one zero point, even if there are many.

    find_zero only accepts lists xs having an even number of coefficients
    and whose largest non-zero coefficient is at an odd degree,
    which guarantees at least one real solution.

    >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2)  # (x - 1)(x - 2)(x - 3)
    1.0
    """
    # Error handling: type and structure checks
    if not isinstance(xs, list):
        raise TypeError("xs must be a list of numeric coefficients")

    if not xs:
        raise ValueError("xs must not be empty")

    if len(xs) % 2 != 0:
        raise ValueError("xs must contain an even number of coefficients")

    if not all(isinstance(coeff, (int, float)) for coeff in xs):
        raise TypeError("all coefficients in xs must be numeric")

    # Remove trailing zeros logically by finding the true degree
    degree = None
    for i in range(len(xs) - 1, -1, -1):
        if xs[i] != 0:
            degree = i
            break

    if degree is None:
        raise ValueError("zero polynomial has infinitely many roots")

    # Guarantee of a real root requires odd degree
    if degree % 2 == 0:
        raise ValueError(
            "polynomial must have odd degree (largest non-zero coefficient at odd index)"
        )

    # If x = 0 is already a root
    if xs[0] == 0:
        return 0.0

    # Bracket a root by expanding interval until sign change
    left, right = -1.0, 1.0
    f_left = poly(xs, left)
    f_right = poly(xs, right)

    max_expand = 1000
    expand_count = 0

    while f_left * f_right > 0:
        left *= 2
        right *= 2
        f_left = poly(xs, left)
        f_right = poly(xs, right)
        expand_count += 1

        if expand_count > max_expand:
            raise RuntimeError("failed to bracket a root")

    # Bisection method
    tol = 1e-12
    max_iter = 1000

    for _ in range(max_iter):
        mid = (left + right) / 2
        f_mid = poly(xs, mid)

        if abs(f_mid) < tol:
            return mid

        if f_left * f_mid <= 0:
            right = mid
            f_right = f_mid
        else:
            left = mid
            f_left = f_mid

    return (left + right) / 2
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
