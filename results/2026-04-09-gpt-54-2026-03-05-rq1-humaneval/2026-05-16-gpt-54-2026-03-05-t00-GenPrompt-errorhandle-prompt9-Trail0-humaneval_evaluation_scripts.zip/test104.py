
import unittest
import re
import sys
import math
import copy


def unique_digits(x):
    """Given a list of positive integers x, return a sorted list of all
    elements that do not contain any even digit.

    Note: Returned list should be sorted in increasing order.

    For example:
    >>> unique_digits([15, 33, 1422, 1])
    [1, 15, 33]
    >>> unique_digits([152, 323, 1422, 10])
    []
    """
    if not isinstance(x, list):
        raise TypeError("Input must be a list.")

    result = []

    for num in x:
        if not isinstance(num, int):
            raise TypeError("All elements must be integers.")
        if num <= 0:
            raise ValueError("All elements must be positive integers.")

        if all(int(digit) % 2 != 0 for digit in str(num)):
            result.append(num)

    return sorted(result)
candidate = unique_digits


def check(candidate):

    # Check some simple cases
    assert candidate([15, 33, 1422, 1]) == [1, 15, 33]
    assert candidate([152, 323, 1422, 10]) == []
    assert candidate([12345, 2033, 111, 151]) == [111, 151]
    assert candidate([135, 103, 31]) == [31, 135]

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
