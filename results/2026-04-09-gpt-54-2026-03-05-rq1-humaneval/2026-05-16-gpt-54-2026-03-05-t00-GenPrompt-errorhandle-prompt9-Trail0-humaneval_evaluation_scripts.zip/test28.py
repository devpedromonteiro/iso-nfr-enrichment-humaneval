
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def concatenate(strings: List[str]) -> str:
    """Concatenate list of strings into a single string.

    Error handling solutions included:
    - Raises TypeError if `strings` is not a list
    - Raises TypeError if any element is not a string

    >>> concatenate([])
    ''
    >>> concatenate(['a', 'b', 'c'])
    'abc'
    """
    if not isinstance(strings, list):
        raise TypeError("strings must be a list")

    for i, s in enumerate(strings):
        if not isinstance(s, str):
            raise TypeError(f"all elements must be strings, found {type(s).__name__} at index {i}")

    return "".join(strings)
candidate = concatenate




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == ''
    assert candidate(['x', 'y', 'z']) == 'xyz'
    assert candidate(['x', 'y', 'z', 'w', 'k']) == 'xyzwk'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
