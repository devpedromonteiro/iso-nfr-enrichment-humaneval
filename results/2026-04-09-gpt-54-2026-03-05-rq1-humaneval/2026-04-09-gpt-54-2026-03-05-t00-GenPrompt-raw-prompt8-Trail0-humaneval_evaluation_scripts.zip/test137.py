
import unittest
import re
import sys
import math
import copy


def compare_one(a, b):
    def to_number(x):
        if isinstance(x, str):
            x = x.replace(',', '.')
        return float(x)

    num_a = to_number(a)
    num_b = to_number(b)

    if num_a == num_b:
        return None
    return a if num_a > num_b else b
candidate = compare_one


def check(candidate):

    # Check some simple cases
    assert candidate(1, 2) == 2
    assert candidate(1, 2.5) == 2.5
    assert candidate(2, 3) == 3
    assert candidate(5, 6) == 6
    assert candidate(1, "2,3") == "2,3"
    assert candidate("5,1", "6") == "6"
    assert candidate("1", "2") == "2"
    assert candidate("1", 1) == None

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
