
import unittest
import re
import sys
import math
import copy


FIX = """
Add more test cases.
"""

def check(candidate):
    # Basic examples
    assert candidate("abcde") == 2
    assert candidate("ACEDY") == 3

    # No vowels
    assert candidate("bcdfg") == 0
    assert candidate("rhythm") == 0

    # Standard vowels, mixed case
    assert candidate("aeiou") == 5
    assert candidate("AEIOU") == 5
    assert candidate("AaEeIiOoUu") == 10

    # 'y' only counts at the end
    assert candidate("y") == 1
    assert candidate("Y") == 1
    assert candidate("happy") == 2
    assert candidate("HAPPY") == 2
    assert candidate("yellow") == 2
    assert candidate("YELLOW") == 2
    assert candidate("yay") == 2
    assert candidate("YAY") == 2
    assert candidate("syzygy") == 3

    # Empty string
    assert candidate("") == 0

    # Single-character cases
    assert candidate("a") == 1
    assert candidate("b") == 0
    assert candidate("u") == 1

    # Words ending and not ending with y
    assert candidate("toy") == 2
    assert candidate("toybox") == 2
    assert candidate("day") == 2
    assert candidate("days") == 1
candidate = check


def check(candidate):

    # Check some simple cases
    assert candidate("abcde") == 2, "Test 1"
    assert candidate("Alone") == 3, "Test 2"
    assert candidate("key") == 2, "Test 3"
    assert candidate("bye") == 1, "Test 4"
    assert candidate("keY") == 2, "Test 5"
    assert candidate("bYe") == 1, "Test 6"
    assert candidate("ACEDY") == 3, "Test 7"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
