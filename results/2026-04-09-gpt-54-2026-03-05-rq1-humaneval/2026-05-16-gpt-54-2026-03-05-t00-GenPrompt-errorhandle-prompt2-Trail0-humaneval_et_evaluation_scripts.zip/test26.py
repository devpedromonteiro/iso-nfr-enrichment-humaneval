
import unittest

from typing import List


from typing import List


def remove_duplicates(numbers: List[int]) -> List[int]:
    """From a list of integers, remove all elements that occur more than once.
    Keep order of elements left the same as in the input.

    >>> remove_duplicates([1, 2, 3, 2, 4])
    [1, 3, 4]
    """
    # Error handling: validate input type
    if not isinstance(numbers, list):
        raise TypeError("Input must be a list of integers.")

    # Error handling: validate element types
    if not all(isinstance(n, int) for n in numbers):
        raise ValueError("All elements in the list must be integers.")

    try:
        counts = {}
        for n in numbers:
            counts[n] = counts.get(n, 0) + 1

        result = [n for n in numbers if counts[n] == 1]
        return result

    except Exception as e:
        # Generic fallback error handling
        raise RuntimeError(f"An unexpected error occurred: {e}")
candidate = remove_duplicates


class Test(unittest.TestCase):
    def test(self):
        assert candidate([3, 2, 5, 4]) == [3, 2, 5, 4]
        assert candidate([1, 2, 3, 2, 4, 3, 5]) == [1, 4, 5]
        assert candidate([4, 4, 2, 1, 9, 6, 4]) == [2, 1, 9, 6]
        assert candidate([3, 3, 6, 1, 4, 4, 9]) == [6, 1, 9]
        assert candidate([3, 7, 4, 3]) == [7, 4]
        assert candidate([2, 1, 2, 4]) == [1, 4]
        assert candidate([1, 2, 3, 4]) == [1, 2, 3, 4]
        assert candidate([5, 2, 7, 2, 1, 3, 1]) == [5, 7, 3]
        assert candidate([4, 6, 8, 3, 1, 8, 3]) == [4, 6, 1]
        assert candidate([6, 7, 6, 4, 2, 1, 7]) == [4, 2, 1]
        assert candidate([5, 2, 1, 4, 6, 4, 8]) == [5, 2, 1, 6, 8]
        assert candidate([3, 2, 8, 2]) == [3, 8]
        assert candidate([6, 7, 3, 6]) == [7, 3]
        assert candidate([5, 7, 4, 6]) == [5, 7, 4, 6]
        assert candidate([4, 6, 3, 4, 2, 6, 5]) == [3, 2, 5]
        assert candidate([5, 2, 6, 7, 4, 1, 3]) == [5, 2, 6, 7, 4, 1, 3]
        assert candidate([4, 7, 7, 8]) == [4, 8]
        assert candidate([4, 4, 1, 5]) == [1, 5]
        assert candidate([6, 7, 2, 7, 7, 5, 9]) == [6, 2, 5, 9]
        assert candidate([6, 1, 8, 6]) == [1, 8]
        assert candidate([5, 1, 1, 6, 8, 7, 3]) == [5, 6, 8, 7, 3]
        assert candidate([1, 2, 1, 7, 6, 6, 10]) == [2, 7, 10]
        assert candidate([1, 2, 7, 4]) == [1, 2, 7, 4]
        assert candidate([1, 7, 2, 6]) == [1, 7, 2, 6]
        assert candidate([1, 3, 8, 9]) == [1, 3, 8, 9]
        assert candidate([2, 5, 6, 4, 8, 6, 6]) == [2, 5, 4, 8]
        assert candidate([4, 2, 5, 2]) == [4, 5]
        assert candidate([2, 6, 2, 7, 4, 2, 1]) == [6, 7, 4, 1]
        assert candidate([5, 2, 8, 3]) == [5, 2, 8, 3]
        assert candidate([5, 5, 5, 5, 5, 2, 2]) == []
        assert candidate([3, 7, 3, 7, 5, 2, 4]) == [5, 2, 4]
        assert candidate([5, 3, 7, 2, 3, 1, 5]) == [7, 2, 1]
        assert candidate([4, 1, 1, 3, 1, 6, 8]) == [4, 3, 6, 8]
        assert candidate([1, 7, 2, 4, 2, 4, 8]) == [1, 7, 8]
        assert candidate([5, 3, 6, 1, 5, 5, 3]) == [6, 1]
        assert candidate([4, 7, 5, 5]) == [4, 7]
        assert candidate([1, 2, 2, 8]) == [1, 8]
        assert candidate([1, 2, 4, 4, 3, 1, 6]) == [2, 3, 6]
        assert candidate([2, 7, 3, 2]) == [7, 3]
        assert candidate([1, 3, 4, 2]) == [1, 3, 4, 2]
        assert candidate([4, 2, 5, 8]) == [4, 2, 5, 8]
        assert candidate([4, 4, 5, 4, 3, 8, 9]) == [5, 3, 8, 9]
        assert candidate([3, 1, 8, 7]) == [3, 1, 8, 7]
        assert candidate([3, 5, 6, 6]) == [3, 5]
        assert candidate([6, 1, 1, 4, 3, 6, 3]) == [4]
        assert candidate([1, 1, 6, 6]) == []
        assert candidate([4, 3, 1, 5, 9, 7, 6]) == [4, 3, 1, 5, 9, 7, 6]
        assert candidate([3, 2, 2, 3]) == []
        assert candidate([6, 2, 7, 1, 2, 1, 2]) == [6, 7]
        assert candidate([2, 6, 7, 9]) == [2, 6, 7, 9]
        assert candidate([4, 3, 8, 2]) == [4, 3, 8, 2]
        assert candidate([4, 6, 4, 3, 4, 3, 2]) == [6, 2]
        assert candidate([1, 1, 5, 2, 2, 6, 7]) == [5, 6, 7]
        assert candidate([4, 6, 7, 6, 8, 1, 9]) == [4, 7, 8, 1, 9]
        assert candidate([1, 2, 8, 9]) == [1, 2, 8, 9]
        assert candidate([1, 6, 8, 1, 7, 5, 8]) == [6, 7, 5]
        assert candidate([3, 6, 2, 2, 6, 3, 7]) == [7]
        assert candidate([5, 7, 1, 1, 4, 3, 7]) == [5, 4, 3]
        assert candidate([2, 6, 3, 7]) == [2, 6, 3, 7]
        assert candidate([6, 2, 1, 3, 2, 5, 2]) == [6, 1, 3, 5]
        assert candidate([5, 3, 2, 1]) == [5, 3, 2, 1]
        assert candidate([6, 6, 3, 4, 3, 1, 3]) == [4, 1]
        assert candidate([6, 6, 1, 5, 4, 1, 10]) == [5, 4, 10]
        assert candidate([2, 2, 4, 5]) == [4, 5]
        assert candidate([3, 7, 3, 3, 5, 4, 4]) == [7, 5]
        assert candidate([3, 6, 8, 6]) == [3, 8]
        assert candidate([1, 3, 4, 8]) == [1, 3, 4, 8]
        assert candidate([6, 6, 6, 5]) == [5]
        assert candidate([2, 4, 6, 1, 1, 1, 2]) == [4, 6]
        assert candidate([6, 7, 6, 2]) == [7, 2]
        assert candidate([6, 1, 2, 4, 2, 4, 8]) == [6, 1, 8]
        assert candidate([2, 1, 1, 2]) == []
        assert candidate([3, 1, 2, 3]) == [1, 2]
        assert candidate([]) == []
        assert candidate([6, 2, 7, 2]) == [6, 7]
        assert candidate([2, 6, 8, 6]) == [2, 8]
        assert candidate([6, 7, 7, 3, 9, 2, 8]) == [6, 3, 9, 2, 8]
        assert candidate([5, 4, 5, 8]) == [4, 8]
        assert candidate([5, 5, 2, 3]) == [2, 3]
        assert candidate([4, 2, 2, 6]) == [4, 6]
        assert candidate([2, 5, 1, 2, 3, 8, 6]) == [5, 1, 3, 8, 6]
        assert candidate([3, 3, 7, 5]) == [7, 5]
        assert candidate([6, 1, 7, 5, 4, 3, 9]) == [6, 1, 7, 5, 4, 3, 9]
        assert candidate([2, 2, 2, 4, 5, 7, 4]) == [5, 7]
        assert candidate([5, 3, 1, 2]) == [5, 3, 1, 2]
        assert candidate([4, 1, 2, 6, 7, 5, 3]) == [4, 1, 2, 6, 7, 5, 3]
        assert candidate([5, 4, 3, 6, 2, 8, 2]) == [5, 4, 3, 6, 8]

if __name__ == '__main__':
    unittest.main()
