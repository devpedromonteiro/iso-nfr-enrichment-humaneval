
import unittest


def compare(game, guess):
    """I think we all remember that feeling when the result of some long-awaited
    event is finally known. The feelings and thoughts you have at that moment are
    definitely worth noting down and comparing.
    Your task is to determine if a person correctly guessed the results of a number of matches.
    You are given two arrays of scores and guesses of equal length, where each index shows a match. 
    Return an array of the same length denoting how far off each guess was. If they have guessed correctly,
    the value is 0, and if not, the value is the absolute difference between the guess and the score.

    example:

    compare([1,2,3,4,5,1],[1,2,3,4,2,-2]) -> [0,0,0,0,3,3]
    compare([0,5,0,0,0,4],[4,1,1,0,0,-2]) -> [4,4,1,0,0,6]
    """
    try:
        if not isinstance(game, list) or not isinstance(guess, list):
            raise TypeError("Both game and guess must be lists.")

        if len(game) != len(guess):
            raise ValueError("game and guess must have the same length.")

        result = []
        for g, s in zip(game, guess):
            if not isinstance(g, (int, float)) or not isinstance(s, (int, float)):
                raise TypeError("All elements in game and guess must be numbers.")
            result.append(abs(g - s))

        return result

    except TypeError as te:
        return f"Type error: {te}"
    except ValueError as ve:
        return f"Value error: {ve}"
    except Exception as e:
        return f"Unexpected error: {e}"
candidate = compare


class Test(unittest.TestCase):
    def test(self):
        assert candidate([3, 1, 5, 3, 9, 5], [6, 7, 4, 8, 4, -6]) == [3, 6, 1, 5, 5, 11]
        assert candidate([4, 3, 1, 4, 2, 4], [2, 3, 4, 5, 3, 2]) == [2, 0, 3, 1, 1, 2]
        assert candidate([5, 7, 3], [-6, 0, -2]) == [11, 7, 5]
        assert candidate([4, 7, 6, 3, 7, 2], [4, 3, 7, 8, 7, -3]) == [0, 4, 1, 5, 0, 5]
        assert candidate([5, 1, 4, 4, 2, 3], [3, 1, 3, 3, 2, 4]) == [2, 0, 1, 1, 0, 1]
        assert candidate([4, 1, 2, 1], [0, 5, 6, 2]) == [4, 4, 4, 1]
        assert candidate([1, 1, 3, 1, 3, 1], [5, 3, 1, 3, 2, 3]) == [4, 2, 2, 2, 1, 2]
        assert candidate([6, 6, 8, 9], [-5, 6, 8, 7]) == [11, 0, 0, 2]
        assert candidate([6, 3, 5, 9, 6, 1], [6, 1, 6, 4, 4, -5]) == [0, 2, 1, 5, 2, 6]
        assert candidate([1, 3, 5, 2, 3, 4], [3, 2, 4, 3, 2, 2]) == [2, 1, 1, 1, 1, 2]
        assert candidate([5, 3, 2, 2], [4, 1, 8, 5]) == [1, 2, 6, 3]
        assert candidate([5, 7, 8], [2, -3, 0]) == [3, 10, 8]
        assert candidate([1, 4, 3], [-5, 1, 2]) == [6, 3, 1]
        assert candidate([5, 4, 3, 2, 2, 4], [3, 1, 3, 1, 5, 4]) == [2, 3, 0, 1, 3, 0]
        assert candidate([1, 2, 3], [-1, -7, 0]) == [2, 9, 3]
        assert candidate([6, 5, 7], [0, -3, -5]) == [6, 8, 12]
        assert candidate([4, 5, 1, 1, 5, 3], [5, 4, 7, 2, 2, -3]) == [1, 1, 6, 1, 3, 6]
        assert candidate([4, 4, 6], [-5, -3, 1]) == [9, 7, 5]
        assert candidate([1, 2, 4, 2, 1, 4], [5, 4, 5, 4, 1, 2]) == [4, 2, 1, 2, 0, 2]
        assert candidate([1, 1, 8], [-3, -6, 0]) == [4, 7, 8]
        assert candidate([1, 3, 2, 9, 2, 4], [6, 2, 4, 3, 7, 1]) == [5, 1, 2, 6, 5, 3]
        assert candidate([5, 1, 5], [3, 2, 0]) == [2, 1, 5]
        assert candidate([1,2,3,4,5,1],[1,2,3,4,2,-2])==[0,0,0,0,3,3]
        assert candidate([1, 7, 2, 8], [-3, 4, 7, 7]) == [4, 3, 5, 1]
        assert candidate([4, 1, 5, 2, 3, 3], [5, 4, 3, 5, 3, 2]) == [1, 3, 2, 3, 0, 1]
        assert candidate([3, 2, 4, 3, 3, 1], [1, 3, 5, 4, 2, 2]) == [2, 1, 1, 1, 1, 1]
        assert candidate([2, 4, 8, 10], [1, 4, 5, 2]) == [1, 0, 3, 8]
        assert candidate([1, 3, 2, 2, 3, 5], [3, 4, 2, 4, 6, -5]) == [2, 1, 0, 2, 3, 10]
        assert candidate([2, 3, 3, 5, 2, 1], [4, 2, 1, 4, 1, 4]) == [2, 1, 2, 1, 1, 3]
        assert candidate([1, 3, 1, 2, 9, 2], [5, 2, 1, 9, 7, -7]) == [4, 1, 0, 7, 2, 9]
        assert candidate([3, 4, 3, 3, 4, 3], [5, 4, 1, 4, 3, 1]) == [2, 0, 2, 1, 1, 2]
        assert candidate([6, 5, 2, 9, 4, 1], [5, 4, 3, 8, 7, -3]) == [1, 1, 1, 1, 3, 4]
        assert candidate([6, 4, 3, 3, 2, 4], [4, 7, 6, 2, 4, 3]) == [2, 3, 3, 1, 2, 1]
        assert candidate([2, 4, 1, 2, 5, 2], [2, 1, 3, 5, 5, 3]) == [0, 3, 2, 3, 0, 1]
        assert candidate([2, 4, 8, 2, 3, 6], [6, 7, 1, 7, 2, 3]) == [4, 3, 7, 5, 1, 3]
        assert candidate([3, 2, 7, 3], [3, 1, 2, 4]) == [0, 1, 5, 1]
        assert candidate([6, 1, 2, 7], [-4, 2, 5, 2]) == [10, 1, 3, 5]
        assert candidate([1, 6, 4], [-3, -7, -6]) == [4, 13, 10]
        assert candidate([3, 2, 1], [2, -2, -1]) == [1, 4, 2]
        assert candidate([6, 1, 4, 3], [0, 5, 5, 3]) == [6, 4, 1, 0]
        assert candidate([3, 7, 1], [-6, 1, 1]) == [9, 6, 0]
        assert candidate([4, 4, 4, 4, 1, 5], [2, 1, 5, 7, 6, 2]) == [2, 3, 1, 3, 5, 3]
        assert candidate([6, 7, 6], [4, -3, 1]) == [2, 10, 5]
        assert candidate([5, 2, 2, 8], [4, 2, 2, 6]) == [1, 0, 0, 2]
        assert candidate([1, 2, 7, 3], [0, 5, 3, 1]) == [1, 3, 4, 2]
        assert candidate([3, 2, 8, 7, 5, 2], [2, 4, 8, 7, 3, 2]) == [1, 2, 0, 0, 2, 0]
        assert candidate([3, 4, 2, 9, 4, 1], [2, 4, 5, 2, 7, 3]) == [1, 0, 3, 7, 3, 2]
        assert candidate([2, 6, 3, 8, 4, 3], [5, 1, 6, 2, 7, -5]) == [3, 5, 3, 6, 3, 8]
        assert candidate([5, 5, 1, 4, 4, 1], [2, 1, 3, 3, 1, 1]) == [3, 4, 2, 1, 3, 0]
        assert candidate([2, 5, 6, 2], [-4, 5, 7, 3]) == [6, 0, 1, 1]
        assert candidate([6, 2, 1, 1, 9, 5], [5, 7, 5, 7, 2, -6]) == [1, 5, 4, 6, 7, 11]
        assert candidate([5, 2, 5, 2, 1, 5], [4, 5, 1, 3, 1, 2]) == [1, 3, 4, 1, 0, 3]
        assert candidate([3, 1, 7], [-1, -2, -1]) == [4, 3, 8]
        assert candidate([3, 5, 1, 5, 2, 3], [5, 2, 3, 3, 5, -7]) == [2, 3, 2, 2, 3, 10]
        assert candidate([3, 3, 3], [3, -6, 2]) == [0, 9, 1]
        assert candidate([6, 7, 6, 3], [-2, 3, 4, 6]) == [8, 4, 2, 3]
        assert candidate([6, 2, 2, 3], [-2, 5, 1, 7]) == [8, 3, 1, 4]
        assert candidate([1, 2, 4], [-4, 3, 2]) == [5, 1, 2]
        assert candidate([1, 4, 6, 3, 10, 1], [6, 6, 6, 9, 5, 3]) == [5, 2, 0, 6, 5, 2]
        assert candidate([3, 6, 7, 10], [-3, 4, 5, 7]) == [6, 2, 2, 3]
        assert candidate([0,0,0,0,0,0],[0,0,0,0,0,0])==[0,0,0,0,0,0]
        assert candidate([1, 5, 5], [0, 3, 0]) == [1, 2, 5]
        assert candidate([1, 5, 2, 3, 5, 2], [4, 3, 4, 1, 1, 1]) == [3, 2, 2, 2, 4, 1]
        assert candidate([4, 6, 7, 5, 5, 2], [2, 7, 2, 5, 2, -5]) == [2, 1, 5, 0, 3, 7]
        assert candidate([3, 1, 4, 7], [-6, 4, 5, 7]) == [9, 3, 1, 0]
        assert candidate([2, 7, 2], [1, 3, 2]) == [1, 4, 0]
        assert candidate([6, 7, 2], [-6, -2, -1]) == [12, 9, 3]
        assert candidate([1, 4, 1, 1, 1, 5], [4, 2, 1, 1, 5, 5]) == [3, 2, 0, 0, 4, 0]
        assert candidate([2, 1, 1], [0, -5, 2]) == [2, 6, 1]
        assert candidate([2, 5, 2, 7], [2, 5, 7, 1]) == [0, 0, 5, 6]
        assert candidate([5, 1, 6], [1, -3, -7]) == [4, 4, 13]
        assert candidate([6, 1, 6, 7, 9, 4], [4, 7, 7, 9, 5, 3]) == [2, 6, 1, 2, 4, 1]
        assert candidate([6, 4, 8, 7], [3, 3, 8, 9]) == [3, 1, 0, 2]
        assert candidate([3, 7, 4, 10], [3, 3, 7, 4]) == [0, 4, 3, 6]
        assert candidate([4, 1, 2, 5, 2, 5], [3, 1, 1, 1, 5, 4]) == [1, 0, 1, 4, 3, 1]
        assert candidate([1, 2, 2, 1, 5, 3], [4, 5, 1, 2, 1, 2]) == [3, 3, 1, 1, 4, 1]
        assert candidate([2, 5, 7], [0, -2, -4]) == [2, 7, 11]
        assert candidate([5, 5, 2, 4, 1, 1], [5, 3, 4, 5, 1, 2]) == [0, 2, 2, 1, 0, 1]
        assert candidate([3, 4, 2, 9, 10, 4], [5, 7, 7, 5, 1, 3]) == [2, 3, 5, 4, 9, 1]
        assert candidate([6, 5, 8, 3, 1, 1], [3, 5, 3, 4, 4, -6]) == [3, 0, 5, 1, 3, 7]
        assert candidate([2, 4, 1], [3, 2, 2]) == [1, 2, 1]
        assert candidate([4, 6, 3, 1], [3, 5, 8, 6]) == [1, 1, 5, 5]
        assert candidate([1, 2, 5, 2, 4, 4], [3, 2, 1, 2, 4, 1]) == [2, 0, 4, 0, 0, 3]
        assert candidate([6, 5, 4, 3, 5, 3], [5, 6, 7, 5, 1, 3]) == [1, 1, 3, 2, 4, 0]
        assert candidate([1, 6, 6], [4, -1, 0]) == [3, 7, 6]
        assert candidate([5, 3, 8, 2], [-2, 4, 6, 3]) == [7, 1, 2, 1]
        assert candidate([1,2,3],[-1,-2,-3])==[2,4,6]
        assert candidate([2, 1, 4, 2, 1, 1], [3, 4, 1, 4, 1, 1]) == [1, 3, 3, 2, 0, 0]
        assert candidate([5, 4, 2, 5, 10, 4], [3, 6, 8, 9, 6, 3]) == [2, 2, 6, 4, 4, 1]
        assert candidate([1, 3, 4, 4, 1, 1], [4, 2, 4, 3, 1, 2]) == [3, 1, 0, 1, 0, 1]
        assert candidate([2, 2, 4, 5, 2, 3], [5, 2, 2, 3, 4, 3]) == [3, 0, 2, 2, 2, 0]
        assert candidate([2, 3, 3, 4], [-2, 2, 4, 6]) == [4, 1, 1, 2]
        assert candidate([5, 5, 4, 3, 4, 5], [5, 5, 5, 2, 5, 4]) == [0, 0, 1, 1, 1, 1]
        assert candidate([2, 5, 5, 6, 6, 2], [5, 2, 2, 3, 5, -5]) == [3, 3, 3, 3, 1, 7]
        assert candidate([3, 1, 6, 2], [-4, 7, 8, 2]) == [7, 6, 2, 0]
        assert candidate([2, 6, 5, 6], [4, 2, 5, 5]) == [2, 4, 0, 1]
        assert candidate([1,2,3,5],[-1,2,3,4])==[2,0,0,1]
        assert candidate([4, 5, 2, 7, 7, 6], [1, 3, 6, 8, 2, -5]) == [3, 2, 4, 1, 5, 11]
        assert candidate([3, 4, 3, 3, 1, 1], [3, 3, 5, 4, 3, 4]) == [0, 1, 2, 1, 2, 3]
        assert candidate([3, 3, 8], [4, 1, -8]) == [1, 2, 16]
        assert candidate([4, 7, 7, 6], [-1, 5, 5, 9]) == [5, 2, 2, 3]
        assert candidate([1, 2, 1, 10], [-5, 4, 3, 6]) == [6, 2, 2, 4]
        assert candidate([4, 4, 3, 1, 3, 1], [1, 6, 3, 9, 1, -4]) == [3, 2, 0, 8, 2, 5]
        assert candidate([6, 7, 7, 9, 9, 4], [1, 7, 4, 9, 6, -3]) == [5, 0, 3, 0, 3, 7]
        assert candidate([1, 1, 2, 3, 5, 2], [4, 2, 5, 4, 4, 4]) == [3, 1, 3, 1, 1, 2]
        assert candidate([3, 1, 4, 1, 5, 3], [3, 1, 4, 4, 2, 5]) == [0, 0, 0, 3, 3, 2]
        assert candidate([2, 3, 6, 8, 9, 4], [3, 5, 8, 1, 5, 3]) == [1, 2, 2, 7, 4, 1]
        assert candidate([1, 4, 5, 2, 2, 3], [3, 5, 4, 2, 1, 5]) == [2, 1, 1, 0, 1, 2]
        assert candidate([2, 3, 3, 5, 5, 4], [5, 6, 1, 3, 7, 2]) == [3, 3, 2, 2, 2, 2]
        assert candidate([5, 1, 3, 1], [-3, 5, 4, 2]) == [8, 4, 1, 1]
        assert candidate([1, 4, 4, 3, 1, 4], [2, 5, 5, 2, 2, 3]) == [1, 1, 1, 1, 1, 1]
        assert candidate([5, 5, 8, 7], [-3, 6, 3, 8]) == [8, 1, 5, 1]
        assert candidate([5, 3, 3, 8], [-4, 4, 3, 7]) == [9, 1, 0, 1]
        assert candidate([1, 4, 3], [-3, 3, -6]) == [4, 1, 9]
        assert candidate([4, 2, 6], [-3, -2, 2]) == [7, 4, 4]
        assert candidate([2, 4, 5, 1], [-5, 2, 6, 5]) == [7, 2, 1, 4]
        assert candidate([3, 2, 1, 5, 2, 4], [2, 5, 4, 2, 3, 1]) == [1, 3, 3, 3, 1, 3]
        assert candidate([2, 1, 6, 8], [-4, 3, 6, 1]) == [6, 2, 0, 7]
        assert candidate([2, 5, 2, 4], [-5, 7, 4, 6]) == [7, 2, 2, 2]
        assert candidate([2, 5, 4], [1, -5, -3]) == [1, 10, 7]
        assert candidate([1, 6, 6, 1, 4, 5], [6, 1, 5, 3, 6, 2]) == [5, 5, 1, 2, 2, 3]
        assert candidate([1, 5, 7], [-6, 3, -7]) == [7, 2, 14]
        assert candidate([6, 2, 2], [-3, -1, 2]) == [9, 3, 0]
        assert candidate([1, 3, 2, 1, 5, 5], [5, 4, 1, 2, 2, 5]) == [4, 1, 1, 1, 3, 0]
        assert candidate([3, 3, 8, 4], [-3, 7, 3, 1]) == [6, 4, 5, 3]
        assert candidate([3, 4, 2, 3, 3, 3], [2, 4, 1, 5, 3, 1]) == [1, 0, 1, 2, 0, 2]
        assert candidate([2, 6, 8], [3, -2, -5]) == [1, 8, 13]
        assert candidate([3, 3, 4, 2, 1, 2], [1, 4, 2, 3, 3, 4]) == [2, 1, 2, 1, 2, 2]
        assert candidate([6, 7, 4], [1, 0, -2]) == [5, 7, 6]
        assert candidate([5, 2, 8], [3, 2, 0]) == [2, 0, 8]
        assert candidate([5, 7, 5, 5, 5, 4], [2, 4, 4, 5, 3, -3]) == [3, 3, 1, 0, 2, 7]
        assert candidate([6, 6, 7, 7, 1, 2], [1, 2, 1, 9, 4, 2]) == [5, 4, 6, 2, 3, 0]

if __name__ == '__main__':
    unittest.main()
