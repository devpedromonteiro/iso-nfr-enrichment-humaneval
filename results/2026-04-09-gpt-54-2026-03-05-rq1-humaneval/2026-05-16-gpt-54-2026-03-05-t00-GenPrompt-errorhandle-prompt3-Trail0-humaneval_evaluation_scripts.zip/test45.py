
import unittest
import re
import sys
import math
import copy



def triangle_area(a, h):
    """Given length of a side and high return area for a triangle.
    >>> triangle_area(5, 3)
    7.5
    """
    try:
        if a < 0 or h < 0:
            raise ValueError("Side length and height must be non-negative.")
        return (a * h) / 2
    except TypeError:
        raise TypeError("Side length and height must be numbers.")
candidate = triangle_area




METADATA = {}


def check(candidate):
    assert candidate(5, 3) == 7.5
    assert candidate(2, 2) == 2.0
    assert candidate(10, 8) == 40.0



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
