
import unittest
import re
import sys
import math
import copy


def f(n):
    """Implement the function f that takes n as a parameter,
    and returns a list of size n, such that the value of the element at index i is:
    - the factorial of i if i is even
    - the sum of numbers from 1 to i otherwise

    i starts from 1.

    Example:
    f(5) == [1, 2, 6, 24, 15]
    """
    try:
        if not isinstance(n, int):
            raise TypeError("n must be an integer")
        if n < 0:
            raise ValueError("n must be non-negative")

        result = []

        for i in range(1, n + 1):
            if i % 2 == 0:
                # factorial of i
                fact = 1
                for j in range(1, i + 1):
                    fact *= j
                result.append(fact)
            else:
                # sum from 1 to i
                total = sum(range(1, i + 1))
                result.append(total)

        return result

    except Exception as e:
        print(f"Error: {e}")
        return []
candidate = f


def check(candidate):

    assert candidate(5) == [1, 2, 6, 24, 15]
    assert candidate(7) == [1, 2, 6, 24, 15, 720, 28]
    assert candidate(1) == [1]
    assert candidate(3) == [1, 2, 6]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
