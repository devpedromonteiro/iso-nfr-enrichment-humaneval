
import unittest
import re
import sys
import math
import copy


def sort_array(array):
    """
    Given an array of non-negative integers, return a copy of the given array after sorting.
    Sort ascending if array[0] + array[-1] is odd, otherwise sort descending.

    Error handling approach:
    - TypeError if input is not a list/tuple
    - ValueError if elements are not non-negative integers
    - Gracefully handles empty and single-element inputs
    """
    try:
        if not isinstance(array, (list, tuple)):
            raise TypeError("Input must be a list or tuple of non-negative integers.")

        if len(array) <= 1:
            return list(array)

        if not all(isinstance(x, int) and x >= 0 for x in array):
            raise ValueError("All elements must be non-negative integers.")

        result = list(array)  # copy to avoid modifying original

        if (result[0] + result[-1]) % 2 == 1:
            return sorted(result)
        else:
            return sorted(result, reverse=True)

    except TypeError as te:
        raise TypeError(f"Type error in sort_array: {te}")
    except ValueError as ve:
        raise ValueError(f"Value error in sort_array: {ve}")
    except Exception as e:
        raise RuntimeError(f"Unexpected error in sort_array: {e}")
candidate = sort_array


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([]) == [], "Error"
    assert candidate([5]) == [5], "Error"
    assert candidate([2, 4, 3, 0, 1, 5]) == [0, 1, 2, 3, 4, 5], "Error"
    assert candidate([2, 4, 3, 0, 1, 5, 6]) == [6, 5, 4, 3, 2, 1, 0], "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([2, 1]) == [1, 2], "Error"
    assert candidate([15, 42, 87, 32 ,11, 0]) == [0, 11, 15, 32, 42, 87], "Error"
    assert candidate([21, 14, 23, 11]) == [23, 21, 14, 11], "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
