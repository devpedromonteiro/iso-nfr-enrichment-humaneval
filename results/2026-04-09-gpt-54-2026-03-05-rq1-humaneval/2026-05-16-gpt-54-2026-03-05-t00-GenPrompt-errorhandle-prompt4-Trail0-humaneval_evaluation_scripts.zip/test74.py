
import unittest
import re
import sys
import math
import copy


def total_match(lst1, lst2):
    '''
    Write a function that accepts two lists of strings and returns the list that has 
    total number of chars in the all strings of the list less than the other list.

    if the two lists have the same number of chars, return the first list.

    Examples
    total_match([], []) â []
    total_match(['hi', 'admin'], ['hI', 'Hi']) â ['hI', 'Hi']
    total_match(['hi', 'admin'], ['hi', 'hi', 'admin', 'project']) â ['hi', 'admin']
    total_match(['hi', 'admin'], ['hI', 'hi', 'hi']) â ['hI', 'hi', 'hi']
    total_match(['4'], ['1', '2', '3', '4', '5']) â ['4']
    '''
    try:
        if not isinstance(lst1, list) or not isinstance(lst2, list):
            raise TypeError("Both arguments must be lists.")

        total1 = 0
        total2 = 0

        for item in lst1:
            if not isinstance(item, str):
                raise ValueError("All elements in lst1 must be strings.")
            total1 += len(item)

        for item in lst2:
            if not isinstance(item, str):
                raise ValueError("All elements in lst2 must be strings.")
            total2 += len(item)

        return lst1 if total1 <= total2 else lst2

    except TypeError as te:
        print(f"Type error: {te}")
        return []
    except ValueError as ve:
        print(f"Value error: {ve}")
        return []
    except Exception as e:
        print(f"Unexpected error: {e}")
        return []
candidate = total_match


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([], []) == []
    assert candidate(['hi', 'admin'], ['hi', 'hi']) == ['hi', 'hi']
    assert candidate(['hi', 'admin'], ['hi', 'hi', 'admin', 'project']) == ['hi', 'admin']
    assert candidate(['4'], ['1', '2', '3', '4', '5']) == ['4']
    assert candidate(['hi', 'admin'], ['hI', 'Hi']) == ['hI', 'Hi']
    assert candidate(['hi', 'admin'], ['hI', 'hi', 'hi']) == ['hI', 'hi', 'hi']
    assert candidate(['hi', 'admin'], ['hI', 'hi', 'hii']) == ['hi', 'admin']


    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([], ['this']) == []
    assert candidate(['this'], []) == []



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
