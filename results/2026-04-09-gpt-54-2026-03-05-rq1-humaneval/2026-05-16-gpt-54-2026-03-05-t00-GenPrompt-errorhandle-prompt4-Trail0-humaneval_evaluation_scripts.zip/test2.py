
import unittest
import re
import sys
import math
import copy



import math
from typing import Union


def truncate_number(number: Union[int, float]) -> float:
    """Return the decimal part of a positive number.

    A positive floating point number can be decomposed into:
    - an integer part
    - a decimal part (the leftover, always smaller than 1)

    Examples:
    >>> truncate_number(3.5)
    0.5
    >>> truncate_number(7)
    0.0
    >>> truncate_number(2.75)
    0.75
    """
    # Type validation
    if not isinstance(number, (int, float)):
        raise TypeError("number must be an int or float")

    # Value validation
    if math.isnan(number):
        raise ValueError("number cannot be NaN")
    if math.isinf(number):
        raise ValueError("number must be finite")
    if number < 0:
        raise ValueError("number must be positive")

    try:
        return float(number - math.floor(number))
    except OverflowError as e:
        raise ValueError("number is too large to process") from e
candidate = truncate_number




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(3.5) == 0.5
    assert abs(candidate(1.33) - 0.33) < 1e-6
    assert abs(candidate(123.456) - 0.456) < 1e-6


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
