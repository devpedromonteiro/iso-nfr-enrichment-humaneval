
import unittest
import re
import sys
import math
import copy


def prime_length(string):
    """Write a function that takes a string and returns True if the string
    length is a prime number or False otherwise.

    Examples
    prime_length('Hello') == True
    prime_length('abcdcba') == True
    prime_length('kittens') == True
    prime_length('orange') == False
    """
    # Error handling approach 1: explicit type check
    if not isinstance(string, str):
        raise TypeError("prime_length expects a string")

    try:
        n = len(string)
    except Exception as e:
        # Error handling approach 2: defensive fallback with context
        raise ValueError("Could not determine string length") from e

    # Error handling approach 3: handle edge cases cleanly
    if n < 2:
        return False

    # Check if n is prime
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False
    return True
candidate = prime_length


def check(candidate):

    # Check some simple cases
    assert candidate('Hello') == True
    assert candidate('abcdcba') == True
    assert candidate('kittens') == True
    assert candidate('orange') == False
    assert candidate('wow') == True
    assert candidate('world') == True
    assert candidate('MadaM') == True
    assert candidate('Wow') == True
    assert candidate('') == False
    assert candidate('HI') == True
    assert candidate('go') == True
    assert candidate('gogo') == False
    assert candidate('aaaaaaaaaaaaaaa') == False

    # Check some edge cases that are easy to work out by hand.
    assert candidate('Madam') == True
    assert candidate('M') == False
    assert candidate('0') == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
