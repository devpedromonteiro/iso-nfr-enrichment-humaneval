
import unittest
import re
import sys
import math
import copy



def unique(l: list):
    """Return sorted unique elements in a list.

    Uses multiple error-handling strategies:
    - Type checking for the outer input
    - Graceful handling of unhashable items
    - Clear fallback error for unsortable mixed types

    >>> unique([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [0, 2, 3, 5, 9, 123]
    """
    if not isinstance(l, list):
        raise TypeError(f"unique() expected a list, got {type(l).__name__}")

    seen = []
    result = []

    for item in l:
        try:
            # Fast path for hashable items
            if item not in seen:
                seen.append(item)
                result.append(item)
        except Exception as e:
            raise ValueError(f"Error processing item {item!r}: {e}") from e

    try:
        return sorted(result)
    except TypeError as e:
        raise TypeError(
            "unique() could not sort the unique elements; "
            "make sure all items are mutually comparable"
        ) from e
candidate = unique




METADATA = {}


def check(candidate):
    assert candidate([5, 3, 5, 2, 3, 3, 9, 0, 123]) == [0, 2, 3, 5, 9, 123]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
