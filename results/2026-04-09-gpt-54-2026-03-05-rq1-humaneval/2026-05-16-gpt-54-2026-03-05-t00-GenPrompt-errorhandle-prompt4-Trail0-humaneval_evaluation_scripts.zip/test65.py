
import unittest
import re
import sys
import math
import copy


def circular_shift(x, shift):
    """Circular shift the digits of the integer x, shift the digits right by shift
    and return the result as a string.
    If shift > number of digits, return digits reversed.

    >>> circular_shift(12, 1)
    "21"
    >>> circular_shift(12, 2)
    "12"
    """
    # Type/value validation
    if not isinstance(x, int):
        raise TypeError("x must be an integer")
    if not isinstance(shift, int):
        raise TypeError("shift must be an integer")
    if shift < 0:
        raise ValueError("shift must be non-negative")

    s = str(x)

    # Handle negative numbers by preserving the sign
    sign = ""
    if s[0] == "-":
        sign = "-"
        s = s[1:]

    if len(s) == 0:
        return sign

    # If shift exceeds number of digits, return reversed digits
    if shift > len(s):
        return sign + s[::-1]

    # Circular right shift
    shift = shift % len(s)
    if shift == 0:
        return sign + s

    return sign + s[-shift:] + s[:-shift]
candidate = circular_shift


def check(candidate):

    # Check some simple cases
    assert candidate(100, 2) == "001"
    assert candidate(12, 2) == "12"
    assert candidate(97, 8) == "79"
    assert candidate(12, 1) == "21", "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(11, 101) == "11", "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
