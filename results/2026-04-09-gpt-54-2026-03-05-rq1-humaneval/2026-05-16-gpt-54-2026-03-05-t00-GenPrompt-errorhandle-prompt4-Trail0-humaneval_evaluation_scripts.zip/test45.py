
import unittest
import re
import sys
import math
import copy



def triangle_area(a, h):
    """Given length of a side and height, return area for a triangle.

    >>> triangle_area(5, 3)
    7.5
    """
    # Type validation
    if not isinstance(a, (int, float)) or not isinstance(h, (int, float)):
        raise TypeError("Both 'a' and 'h' must be numbers.")

    # Value validation
    if a < 0 or h < 0:
        raise ValueError("Both 'a' and 'h' must be non-negative.")

    try:
        return (a * h) / 2
    except OverflowError as e:
        raise OverflowError("Calculation resulted in an overflow.") from e
candidate = triangle_area




METADATA = {}


def check(candidate):
    assert candidate(5, 3) == 7.5
    assert candidate(2, 2) == 2.0
    assert candidate(10, 8) == 40.0



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
