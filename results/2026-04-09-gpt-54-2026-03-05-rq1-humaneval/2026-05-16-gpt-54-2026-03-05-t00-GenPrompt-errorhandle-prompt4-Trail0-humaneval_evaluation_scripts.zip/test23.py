
import unittest
import re
import sys
import math
import copy



def strlen(string: str) -> int:
    """Return length of given string.

    Supports multiple error-handling styles:
    - Raises TypeError for non-string inputs
    - Gracefully handles None by returning 0

    >>> strlen('')
    0
    >>> strlen('abc')
    3
    >>> strlen(None)
    0
    >>> strlen(123)
    Traceback (most recent call last):
    ...
    TypeError: strlen() argument must be a string
    """
    if string is None:
        return 0

    if not isinstance(string, str):
        raise TypeError("strlen() argument must be a string")

    try:
        return len(string)
    except Exception as e:
        raise ValueError(f"Unable to determine string length: {e}") from e
candidate = strlen




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == 0
    assert candidate('x') == 1
    assert candidate('asdasnakj') == 9


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
