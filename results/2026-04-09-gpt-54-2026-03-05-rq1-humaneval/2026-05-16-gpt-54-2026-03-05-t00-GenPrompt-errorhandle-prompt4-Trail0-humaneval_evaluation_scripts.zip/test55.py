
import unittest
import re
import sys
import math
import copy



def fib(n: int):
    """Return n-th Fibonacci number.

    >>> fib(10)
    55
    >>> fib(1)
    1
    >>> fib(8)
    21
    """
    # Type validation
    if isinstance(n, bool):
        raise TypeError("n must be an integer, not bool")
    if not isinstance(n, int):
        raise TypeError("n must be an integer")

    # Value validation
    if n < 0:
        raise ValueError("n must be non-negative")

    # Handle base cases
    if n == 0:
        return 0
    if n == 1:
        return 1

    # Iterative computation with defensive error handling
    try:
        a, b = 0, 1
        for _ in range(2, n + 1):
            a, b = b, a + b
        return b
    except OverflowError as e:
        raise OverflowError("integer overflow while computing Fibonacci number") from e
    except Exception as e:
        raise RuntimeError("unexpected error while computing Fibonacci number") from e
candidate = fib




METADATA = {}


def check(candidate):
    assert candidate(10) == 55
    assert candidate(1) == 1
    assert candidate(8) == 21
    assert candidate(11) == 89
    assert candidate(12) == 144



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
