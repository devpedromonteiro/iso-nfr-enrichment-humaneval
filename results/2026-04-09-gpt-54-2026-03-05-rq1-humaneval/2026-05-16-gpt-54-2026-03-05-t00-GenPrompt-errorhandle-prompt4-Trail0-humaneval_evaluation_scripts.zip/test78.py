
import unittest
import re
import sys
import math
import copy


def hex_key(num):
    """Count hexadecimal digits that are prime-valued: 2, 3, 5, 7, B, D."""
    try:
        if not isinstance(num, str):
            raise TypeError("Input must be a string")
        return sum(ch in {'2', '3', '5', '7', 'B', 'D'} for ch in num)
    except TypeError:
        raise
    except Exception:
        return 0
candidate = hex_key


def check(candidate):

    # Check some simple cases
    assert candidate("AB") == 1, "First test error: " + str(candidate("AB"))      
    assert candidate("1077E") == 2, "Second test error: " + str(candidate("1077E"))  
    assert candidate("ABED1A33") == 4, "Third test error: " + str(candidate("ABED1A33"))      
    assert candidate("2020") == 2, "Fourth test error: " + str(candidate("2020"))  
    assert candidate("123456789ABCDEF0") == 6, "Fifth test error: " + str(candidate("123456789ABCDEF0"))      
    assert candidate("112233445566778899AABBCCDDEEFF00") == 12, "Sixth test error: " + str(candidate("112233445566778899AABBCCDDEEFF00"))  


    # Check some edge cases that are easy to work out by hand.
    assert candidate([]) == 0



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
