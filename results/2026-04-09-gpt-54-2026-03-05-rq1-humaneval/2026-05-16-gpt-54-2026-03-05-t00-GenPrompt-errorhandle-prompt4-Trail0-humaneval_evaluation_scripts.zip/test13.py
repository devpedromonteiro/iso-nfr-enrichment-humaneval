
import unittest
import re
import sys
import math
import copy



def greatest_common_divisor(a: int, b: int) -> int:
    """Return the greatest common divisor of two integers a and b.

    Uses the Euclidean algorithm and includes basic error handling for:
    - non-integer inputs -> TypeError
    - gcd(0, 0) -> ValueError

    >>> greatest_common_divisor(3, 5)
    1
    >>> greatest_common_divisor(25, 15)
    5
    """
    if not isinstance(a, int) or not isinstance(b, int):
        raise TypeError("greatest_common_divisor expects two integers")

    if a == 0 and b == 0:
        raise ValueError("greatest_common_divisor is undefined for a = 0 and b = 0")

    a, b = abs(a), abs(b)

    try:
        while b != 0:
            a, b = b, a % b
        return a
    except Exception as exc:
        raise RuntimeError("unexpected error while computing gcd") from exc
candidate = greatest_common_divisor




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(3, 7) == 1
    assert candidate(10, 15) == 5
    assert candidate(49, 14) == 7
    assert candidate(144, 60) == 12


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
