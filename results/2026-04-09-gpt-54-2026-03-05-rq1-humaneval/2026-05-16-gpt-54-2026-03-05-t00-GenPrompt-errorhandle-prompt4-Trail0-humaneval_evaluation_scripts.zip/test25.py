
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def factorize(n: int) -> List[int]:
    """Return list of prime factors of given integer in ascending order.

    Each factor appears as many times as it occurs in the prime factorization.
    The product of all returned factors equals the input number.

    >>> factorize(8)
    [2, 2, 2]
    >>> factorize(25)
    [5, 5]
    >>> factorize(70)
    [2, 5, 7]
    """
    # Type validation
    if not isinstance(n, int):
        raise TypeError("Input must be an integer")

    # Value validation
    if n <= 1:
        raise ValueError("Input must be an integer greater than 1")

    factors = []

    # Handle factor 2 separately
    while n % 2 == 0:
        factors.append(2)
        n //= 2

    # Check odd divisors up to sqrt(n)
    divisor = 3
    while divisor * divisor <= n:
        while n % divisor == 0:
            factors.append(divisor)
            n //= divisor
        divisor += 2

    # If remainder is greater than 1, it is prime
    if n > 1:
        factors.append(n)

    return factors
candidate = factorize




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(2) == [2]
    assert candidate(4) == [2, 2]
    assert candidate(8) == [2, 2, 2]
    assert candidate(3 * 19) == [3, 19]
    assert candidate(3 * 19 * 3 * 19) == [3, 3, 19, 19]
    assert candidate(3 * 19 * 3 * 19 * 3 * 19) == [3, 3, 3, 19, 19, 19]
    assert candidate(3 * 19 * 19 * 19) == [3, 19, 19, 19]
    assert candidate(3 * 2 * 3) == [2, 3, 3]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
