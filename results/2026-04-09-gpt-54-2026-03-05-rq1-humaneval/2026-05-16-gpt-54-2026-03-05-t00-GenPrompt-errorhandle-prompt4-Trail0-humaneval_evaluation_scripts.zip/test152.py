
import unittest
import re
import sys
import math
import copy


def compare(game, guess):
    """Return a list of absolute differences between actual scores and guesses.

    If inputs are invalid, tries to handle them gracefully:
    - Raises TypeError if inputs are not iterable
    - Raises ValueError if lengths differ
    - Raises TypeError if elements cannot be compared numerically
    """
    try:
        if len(game) != len(guess):
            raise ValueError("game and guess must have the same length")
    except TypeError:
        raise TypeError("game and guess must be iterable sequences")

    result = []

    for i, (g, q) in enumerate(zip(game, guess)):
        try:
            result.append(abs(g - q))
        except TypeError:
            raise TypeError(f"Non-numeric value at index {i}: {g!r}, {q!r}")

    return result
candidate = compare


def check(candidate):

    # Check some simple cases
    assert candidate([1,2,3,4,5,1],[1,2,3,4,2,-2])==[0,0,0,0,3,3], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([0,0,0,0,0,0],[0,0,0,0,0,0])==[0,0,0,0,0,0], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,2,3],[-1,-2,-3])==[2,4,6], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,2,3,5],[-1,2,3,4])==[2,0,0,1], "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
