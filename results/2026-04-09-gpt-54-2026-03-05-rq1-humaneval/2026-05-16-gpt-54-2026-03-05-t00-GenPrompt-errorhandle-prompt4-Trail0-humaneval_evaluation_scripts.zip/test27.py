
import unittest
import re
import sys
import math
import copy



def flip_case(string: str) -> str:
    """For a given string, flip lowercase characters to uppercase and uppercase to lowercase.

    >>> flip_case('Hello')
    'hELLO'
    """
    # Type validation
    if string is None:
        raise ValueError("Input cannot be None.")
    if not isinstance(string, str):
        raise TypeError(f"Expected str, got {type(string).__name__}.")

    try:
        return string.swapcase()
    except Exception as exc:
        # Defensive fallback in case of unexpected string-like behavior
        raise RuntimeError(f"Failed to flip case for input: {string!r}") from exc
candidate = flip_case




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == ''
    assert candidate('Hello!') == 'hELLO!'
    assert candidate('These violent delights have violent ends') == 'tHESE VIOLENT DELIGHTS HAVE VIOLENT ENDS'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
