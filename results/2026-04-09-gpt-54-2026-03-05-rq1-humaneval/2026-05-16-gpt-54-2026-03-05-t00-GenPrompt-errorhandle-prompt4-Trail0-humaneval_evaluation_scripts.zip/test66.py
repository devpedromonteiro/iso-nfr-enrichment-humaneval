
import unittest
import re
import sys
import math
import copy


def digitSum(s):
    """Return the sum of ASCII codes of uppercase letters in the input string.

    Examples:
        digitSum("") => 0
        digitSum("abAB") => 131
        digitSum("abcCd") => 67
        digitSum("helloE") => 69
        digitSum("woArBld") => 131
        digitSum("aAaaaXa") => 153
    """
    # Error handling: reject None explicitly
    if s is None:
        raise ValueError("Input cannot be None")

    # Error handling: try to coerce non-string inputs to string
    try:
        if not isinstance(s, str):
            s = str(s)
    except Exception as e:
        raise TypeError("Input must be a string or convertible to string") from e

    total = 0

    for ch in s:
        try:
            if ch.isupper():
                total += ord(ch)
        except Exception:
            # Skip any problematic character-like value defensively
            continue

    return total
candidate = digitSum


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate("") == 0, "Error"
    assert candidate("abAB") == 131, "Error"
    assert candidate("abcCd") == 67, "Error"
    assert candidate("helloE") == 69, "Error"
    assert candidate("woArBld") == 131, "Error"
    assert candidate("aAaaaXa") == 153, "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate(" How are yOu?") == 151, "Error"
    assert candidate("You arE Very Smart") == 327, "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
