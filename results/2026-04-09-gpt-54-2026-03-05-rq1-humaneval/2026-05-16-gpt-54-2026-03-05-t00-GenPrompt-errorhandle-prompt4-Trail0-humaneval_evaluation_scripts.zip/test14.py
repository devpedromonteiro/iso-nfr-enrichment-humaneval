
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def all_prefixes(string: str) -> List[str]:
    """Return list of all prefixes from shortest to longest of the input string.

    >>> all_prefixes('abc')
    ['a', 'ab', 'abc']
    """
    if string is None:
        raise ValueError("Input cannot be None")

    if not isinstance(string, str):
        raise TypeError(f"Expected str, got {type(string).__name__}")

    try:
        return [string[:i] for i in range(1, len(string) + 1)]
    except Exception as e:
        raise RuntimeError(f"Unexpected error while generating prefixes: {e}") from e
candidate = all_prefixes




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == []
    assert candidate('asdfgh') == ['a', 'as', 'asd', 'asdf', 'asdfg', 'asdfgh']
    assert candidate('WWW') == ['W', 'WW', 'WWW']


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
