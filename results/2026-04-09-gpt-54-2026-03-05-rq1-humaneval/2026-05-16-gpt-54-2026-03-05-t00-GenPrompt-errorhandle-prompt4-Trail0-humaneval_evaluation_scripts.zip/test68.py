
import unittest
import re
import sys
import math
import copy


def pluck(arr):
    """
    Given an array representing a branch of a tree that has non-negative integer nodes,
    return the smallest even value and its index as [value, index].

    If multiple nodes share the same smallest even value, return the one with
    the smallest index.

    If there are no even values or the array is empty, return [].
    """

    # Error-handling approach 1: tolerate None / empty input
    if not arr:
        return []

    # Error-handling approach 2: validate input type
    if not isinstance(arr, list):
        raise TypeError("Input must be a list.")

    smallest_even = None
    smallest_index = -1

    for i, value in enumerate(arr):
        # Error-handling approach 3: validate element type/value
        if not isinstance(value, int):
            raise TypeError(f"All elements must be integers. Invalid element at index {i}: {value}")
        if value < 0:
            raise ValueError(f"All elements must be non-negative. Invalid element at index {i}: {value}")

        if value % 2 == 0:
            if smallest_even is None or value < smallest_even:
                smallest_even = value
                smallest_index = i

    return [smallest_even, smallest_index] if smallest_even is not None else []
candidate = pluck


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([4,2,3]) == [2, 1], "Error"
    assert candidate([1,2,3]) == [2, 1], "Error"
    assert candidate([]) == [], "Error"
    assert candidate([5, 0, 3, 0, 4, 2]) == [0, 1], "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([1, 2, 3, 0, 5, 3]) == [0, 3], "Error"
    assert candidate([5, 4, 8, 4 ,8]) == [4, 1], "Error"
    assert candidate([7, 6, 7, 1]) == [6, 1], "Error"
    assert candidate([7, 9, 7, 1]) == [], "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
