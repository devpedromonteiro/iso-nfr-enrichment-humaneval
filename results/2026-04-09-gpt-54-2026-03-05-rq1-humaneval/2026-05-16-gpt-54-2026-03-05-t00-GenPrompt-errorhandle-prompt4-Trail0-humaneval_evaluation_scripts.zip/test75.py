
import unittest
import re
import sys
import math
import copy


def is_multiply_prime(a):
    """Return True if `a` is the product of exactly 3 prime numbers, else False.

    The 3 prime numbers do not need to be distinct.
    Examples:
        30 = 2 * 3 * 5      -> True
         8 = 2 * 2 * 2      -> True
        12 = 2 * 2 * 3      -> True
        20 = 2 * 2 * 5      -> True
         7                  -> False
    """

    # Error-handling approach 1: reject invalid types safely
    if not isinstance(a, int) or isinstance(a, bool):
        return False

    # Error-handling approach 2: reject invalid numeric range/values
    if a < 2:
        return False

    def is_prime(n):
        """Check if n is prime."""
        if n < 2:
            return False
        for i in range(2, int(n ** 0.5) + 1):
            if n % i == 0:
                return False
        return True

    try:
        # Since a < 100, brute force over primes is simple and safe
        primes = [i for i in range(2, a + 1) if is_prime(i)]

        for p1 in primes:
            for p2 in primes:
                for p3 in primes:
                    if p1 * p2 * p3 == a:
                        return True
        return False

    # Error-handling approach 3: catch unexpected runtime issues
    except Exception:
        return False
candidate = is_multiply_prime


def check(candidate):

    assert candidate(5) == False
    assert candidate(30) == True
    assert candidate(8) == True
    assert candidate(10) == False
    assert candidate(125) == True
    assert candidate(3 * 5 * 7) == True
    assert candidate(3 * 6 * 7) == False
    assert candidate(9 * 9 * 9) == False
    assert candidate(11 * 9 * 9) == False
    assert candidate(11 * 13 * 7) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
