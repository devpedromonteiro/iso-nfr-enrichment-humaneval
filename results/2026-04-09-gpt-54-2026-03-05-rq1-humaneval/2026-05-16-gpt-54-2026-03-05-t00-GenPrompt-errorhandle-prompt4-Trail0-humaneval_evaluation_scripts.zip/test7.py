
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    """Filter an input list of strings only for ones that contain given substring.

    Error handling approach:
    - Raises TypeError if `strings` is not a list.
    - Raises TypeError if `substring` is not a string.
    - Raises TypeError if any element in `strings` is not a string.

    >>> filter_by_substring([], 'a')
    []
    >>> filter_by_substring(['abc', 'bacd', 'cde', 'array'], 'a')
    ['abc', 'bacd', 'array']
    """
    if not isinstance(strings, list):
        raise TypeError("strings must be a list")
    if not isinstance(substring, str):
        raise TypeError("substring must be a string")

    result = []
    for s in strings:
        if not isinstance(s, str):
            raise TypeError("all elements in strings must be strings")
        if substring in s:
            result.append(s)

    return result
candidate = filter_by_substring




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([], 'john') == []
    assert candidate(['xxx', 'asd', 'xxy', 'john doe', 'xxxAAA', 'xxx'], 'xxx') == ['xxx', 'xxxAAA', 'xxx']
    assert candidate(['xxx', 'asd', 'aaaxxy', 'john doe', 'xxxAAA', 'xxx'], 'xx') == ['xxx', 'aaaxxy', 'xxxAAA', 'xxx']
    assert candidate(['grunt', 'trumpet', 'prune', 'gruesome'], 'run') == ['grunt', 'prune']


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
