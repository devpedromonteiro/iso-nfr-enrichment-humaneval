
import unittest
import re
import sys
import math
import copy


import re

def fruit_distribution(s, n):
    """
    Given a string describing apples and oranges and an integer total fruit count,
    return the number of mangoes.

    Examples:
    fruit_distribution("5 apples and 6 oranges", 19) -> 8
    fruit_distribution("0 apples and 1 oranges", 3) -> 2
    fruit_distribution("2 apples and 3 oranges", 100) -> 95
    fruit_distribution("100 apples and 1 oranges", 120) -> 19
    """
    # Type validation
    if not isinstance(s, str):
        raise TypeError("s must be a string")
    if not isinstance(n, int):
        raise TypeError("n must be an integer")

    try:
        # Extract all integers from the string
        numbers = list(map(int, re.findall(r'-?\d+', s)))

        if len(numbers) < 2:
            raise ValueError("Input string must contain at least two numbers")

        apples, oranges = numbers[0], numbers[1]
        mangoes = n - apples - oranges

        if mangoes < 0:
            raise ValueError("Total fruits cannot be less than apples + oranges")

        return mangoes

    except ValueError:
        raise
    except Exception as e:
        raise RuntimeError(f"Unexpected error while processing fruit distribution: {e}")
candidate = fruit_distribution


def check(candidate):

    # Check some simple cases
    assert candidate("5 apples and 6 oranges",19) == 8
    assert candidate("5 apples and 6 oranges",21) == 10
    assert candidate("0 apples and 1 oranges",3) == 2
    assert candidate("1 apples and 0 oranges",3) == 2
    assert candidate("2 apples and 3 oranges",100) == 95
    assert candidate("2 apples and 3 oranges",5) == 0
    assert candidate("1 apples and 100 oranges",120) == 19


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
