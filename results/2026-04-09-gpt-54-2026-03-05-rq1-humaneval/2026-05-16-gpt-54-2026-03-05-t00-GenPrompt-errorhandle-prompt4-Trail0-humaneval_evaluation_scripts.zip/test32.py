
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[2] * x^2 + .... + xs[n] * x^n
    """
    if not isinstance(xs, list):
        raise TypeError("xs must be a list of coefficients")
    if len(xs) == 0:
        raise ValueError("xs must not be empty")
    if not isinstance(x, (int, float)):
        raise TypeError("x must be a number")

    try:
        return sum(coeff * math.pow(x, i) for i, coeff in enumerate(xs))
    except TypeError as e:
        raise TypeError("all coefficients must be numeric") from e
    except OverflowError:
        return math.inf if x >= 0 else -math.inf


def find_zero(xs: list):
    """ xs are coefficients of a polynomial.
    find_zero find x such that poly(x) = 0.
    find_zero returns only only zero point, even if there are many.
    Moreover, find_zero only takes list xs having even number of coefficients
    and largest non zero coefficient as it guarantees
    a solution.
    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3
    1.0
    """
    if not isinstance(xs, list):
        raise TypeError("xs must be a list")
    if len(xs) == 0:
        raise ValueError("xs must not be empty")
    if len(xs) % 2 != 0:
        raise ValueError("xs must have an even number of coefficients")
    if all(c == 0 for c in xs):
        raise ValueError("polynomial must not be identically zero")

    try:
        degree = max(i for i, c in enumerate(xs) if c != 0)
    except ValueError as e:
        raise ValueError("no non-zero coefficient found") from e

    if degree % 2 != 1:
        raise ValueError("largest non-zero coefficient must have odd degree")

    if degree == 1:
        a0, a1 = xs[0], xs[1]
        if a1 == 0:
            raise ZeroDivisionError("linear coefficient must be non-zero")
        return -a0 / a1

    def f(x):
        return poly(xs, x)

    left, right = -1.0, 1.0

    try:
        f_left = f(left)
        f_right = f(right)
    except Exception as e:
        raise RuntimeError("failed to evaluate polynomial during bracketing") from e

    max_expand = 10_000
    expand_count = 0

    while f_left == 0:
        return left
    while f_right == 0:
        return right

    while f_left * f_right > 0:
        left *= 2
        right *= 2
        expand_count += 1
        if expand_count > max_expand:
            raise RuntimeError("failed to bracket a root")

        try:
            f_left = f(left)
            f_right = f(right)
        except OverflowError as e:
            raise RuntimeError("numerical overflow while searching for root") from e

    tol = 1e-12
    max_iter = 1000

    for _ in range(max_iter):
        mid = (left + right) / 2
        f_mid = f(mid)

        if abs(f_mid) < tol or abs(right - left) < tol:
            return mid

        if f_left * f_mid <= 0:
            right = mid
            f_right = f_mid
        else:
            left = mid
            f_left = f_mid

    raise RuntimeError("bisection did not converge")
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
