
import unittest
import re
import sys
import math
import copy


def add(lst):
    """Given a non-empty list of integers lst, add the even elements at odd indices.

    Examples:
        add([4, 2, 6, 7]) ==> 2
    """
    # Type checks
    if not isinstance(lst, list):
        raise TypeError("Input must be a list.")
    if len(lst) == 0:
        raise ValueError("List must be non-empty.")
    if not all(isinstance(x, int) for x in lst):
        raise TypeError("All elements in the list must be integers.")

    total = 0
    for i in range(1, len(lst), 2):  # odd indices
        try:
            if lst[i] % 2 == 0:       # even element
                total += lst[i]
        except Exception as e:
            raise ValueError(f"Error processing element at index {i}: {e}")

    return total
candidate = add


def check(candidate):

    # Check some simple cases
    assert candidate([4, 88]) == 88
    assert candidate([4, 5, 6, 7, 2, 122]) == 122
    assert candidate([4, 0, 6, 7]) == 0
    assert candidate([4, 4, 6, 8]) == 12

    # Check some edge cases that are easy to work out by hand.
    


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
