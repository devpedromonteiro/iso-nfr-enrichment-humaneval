
import unittest
import re
import sys
import math
import copy



def is_palindrome(text: str):
    """
    Checks if given string is a palindrome

    Error handling approach:
    - Raises TypeError if `text` is not a string.
    - Gracefully handles unexpected runtime issues by returning False.

    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    """
    if text is None:
        raise TypeError("text must be a string, not None")

    if not isinstance(text, str):
        raise TypeError(f"text must be a string, got {type(text).__name__}")

    try:
        return text == text[::-1]
    except Exception:
        return False
candidate = is_palindrome




METADATA = {}


def check(candidate):
    assert candidate('') == True
    assert candidate('aba') == True
    assert candidate('aaaaa') == True
    assert candidate('zbcd') == False
    assert candidate('xywyx') == True
    assert candidate('xywyz') == False
    assert candidate('xywzx') == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
