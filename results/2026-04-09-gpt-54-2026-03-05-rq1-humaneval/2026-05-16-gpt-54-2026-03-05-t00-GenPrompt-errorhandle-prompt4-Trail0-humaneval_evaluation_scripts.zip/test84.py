
import unittest
import re
import sys
import math
import copy


def solve(N):
    """Given a non-negative integer N, return the binary representation
    of the sum of its decimal digits.

    Examples:
        solve(1000) -> "1"      # 1+0+0+0 = 1 -> binary "1"
        solve(150)  -> "110"    # 1+5+0 = 6 -> binary "110"
        solve(147)  -> "1100"   # 1+4+7 = 12 -> binary "1100"

    Args:
        N: integer, expected in range 0 <= N <= 10000

    Returns:
        A string containing the binary representation of the digit sum.

    Raises:
        TypeError: if N is not an integer
        ValueError: if N is negative or greater than 10000
    """
    # Type validation
    if not isinstance(N, int):
        raise TypeError("N must be an integer")

    # Range validation
    if N < 0 or N > 10000:
        raise ValueError("N must satisfy 0 <= N <= 10000")

    try:
        digit_sum = sum(int(ch) for ch in str(N))
    except Exception as e:
        raise ValueError(f"Failed to compute digit sum: {e}")

    try:
        return bin(digit_sum)[2:]
    except Exception as e:
        raise RuntimeError(f"Failed to convert digit sum to binary: {e}")
candidate = solve


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(1000) == "1", "Error"
    assert candidate(150) == "110", "Error"
    assert candidate(147) == "1100", "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate(333) == "1001", "Error"
    assert candidate(963) == "10010", "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
