
import unittest
import re
import sys
import math
import copy



def remove_vowels(text):
    """
    remove_vowels is a function that takes string and returns string without vowels.

    >>> remove_vowels('')
    ''
    >>> remove_vowels("abcdef\nghijklm")
    'bcdf\nghjklm'
    >>> remove_vowels('abcdef')
    'bcdf'
    >>> remove_vowels('aaaaa')
    ''
    >>> remove_vowels('aaBAA')
    'B'
    >>> remove_vowels('zbcd')
    'zbcd'
    """
    if text is None:
        raise ValueError("text cannot be None")

    if not isinstance(text, str):
        try:
            text = str(text)
        except Exception as e:
            raise TypeError("text must be a string or convertible to string") from e

    vowels = "aeiouAEIOU"

    try:
        return ''.join(char for char in text if char not in vowels)
    except Exception as e:
        raise RuntimeError("unexpected error while removing vowels") from e
candidate = remove_vowels




METADATA = {}


def check(candidate):
    assert candidate('') == ''
    assert candidate("abcdef\nghijklm") == 'bcdf\nghjklm'
    assert candidate('fedcba') == 'fdcb'
    assert candidate('eeeee') == ''
    assert candidate('acBAA') == 'cB'
    assert candidate('EcBOO') == 'cB'
    assert candidate('ybcd') == 'ybcd'



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
