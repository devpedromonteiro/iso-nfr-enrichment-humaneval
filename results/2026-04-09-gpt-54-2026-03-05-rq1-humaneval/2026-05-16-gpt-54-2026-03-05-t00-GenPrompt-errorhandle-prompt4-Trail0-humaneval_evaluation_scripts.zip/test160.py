
import unittest
import re
import sys
import math
import copy


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and
    the second list is a list of integers. Use the two given lists to build the algebraic
    expression and return the evaluation of this expression.

    Supported operations:
    Addition ( + )
    Subtraction ( - )
    Multiplication ( * )
    Floor division ( // )
    Exponentiation ( ** )
    """
    # Type and structure validation
    if not isinstance(operator, list) or not isinstance(operand, list):
        raise TypeError("Both operator and operand must be lists.")

    if len(operator) < 1:
        raise ValueError("Operator list must contain at least one operator.")

    if len(operand) < 2:
        raise ValueError("Operand list must contain at least two operands.")

    if len(operator) != len(operand) - 1:
        raise ValueError("Length of operator list must be one less than length of operand list.")

    valid_ops = {"+", "-", "*", "//", "**"}
    for op in operator:
        if op not in valid_ops:
            raise ValueError(f"Unsupported operator: {op}")

    for num in operand:
        if not isinstance(num, int):
            raise TypeError("All operands must be integers.")
        if num < 0:
            raise ValueError("Operands must be non-negative integers.")

    # Build expression safely
    expression = str(operand[0])
    for op, num in zip(operator, operand[1:]):
        expression += f" {op} {num}"

    # Evaluate with error handling
    try:
        return eval(expression)
    except ZeroDivisionError:
        raise ZeroDivisionError("Division by zero occurred in the algebraic expression.")
    except OverflowError:
        raise OverflowError("Numerical result out of range.")
    except Exception as e:
        raise RuntimeError(f"Failed to evaluate expression: {e}")
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
