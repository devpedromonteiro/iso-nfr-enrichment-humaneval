
import unittest


def special_factorial(n):
    """The Brazilian factorial is defined as:
    brazilian_factorial(n) = n! * (n-1)! * (n-2)! * ... * 1!
    where n > 0

    For example:
    >>> special_factorial(4)
    288

    The function will receive an integer as input and should return the special
    factorial of this integer.
    """
    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if n <= 0:
        raise ValueError("n must be greater than 0")

    result = 1
    current_factorial = 1

    for i in range(1, n + 1):
        current_factorial *= i
        result *= current_factorial

    return result
candidate = special_factorial


class Test(unittest.TestCase):
    def test(self):
        assert candidate(7) == 125411328000
        assert candidate(9) == 1834933472251084800000
        assert candidate(1) == 1, "Test 1"
        assert candidate(3) == 12
        assert candidate(10) == 6658606584104736522240000000
        assert candidate(12) == 127313963299399416749559771247411200000000000
        assert candidate(4) == 288
        assert candidate(1) == 1
        assert candidate(6) == 24883200
        assert candidate(8) == 5056584744960000
        assert candidate(5) == 34560
        assert candidate(4) == 288, "Test 4"
        assert candidate(2) == 2
        assert candidate(5) == 34560, "Test 5"
        assert candidate(11) == 265790267296391946810949632000000000
        assert candidate(7) == 125411328000, "Test 7"

    # Check some edge cases that are easy to work out by hand.

if __name__ == '__main__':
    unittest.main()
