
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Given an N x N grid containing each integer from 1 to N*N exactly once,
    return the lexicographically smallest path of length k, where each move
    goes to a 4-directionally adjacent cell.

    The answer is unique.
    """
    n = len(grid)

    # Map value -> position, so we can process cells in increasing value order.
    pos = [None] * (n * n + 1)
    for r in range(n):
        for c in range(n):
            pos[grid[r][c]] = (r, c)

    # Build adjacency by value instead of by coordinates.
    neighbors = [[] for _ in range(n * n + 1)]
    for val in range(1, n * n + 1):
        r, c = pos[val]
        for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nr, nc = r + dr, c + dc
            if 0 <= nr < n and 0 <= nc < n:
                neighbors[val].append(grid[nr][nc])

    # dp[x] = lexicographically smallest path of current length starting at value x
    dp = [[v] for v in range(n * n + 1)]

    for _ in range(2, k + 1):
        new_dp = [None] * (n * n + 1)
        for val in range(1, n * n + 1):
            best_neighbor = None
            for nxt in neighbors[val]:
                if best_neighbor is None or dp[nxt] < dp[best_neighbor]:
                    best_neighbor = nxt
            new_dp[val] = [val] + dp[best_neighbor]
        dp = new_dp

    # Find the best starting value
    best_start = 1
    for val in range(2, n * n + 1):
        if dp[val] < dp[best_start]:
            best_start = val

    return dp[best_start]
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
