
import unittest
import re
import sys
import math
import copy


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and 
    the second list is a list of integers. Use the two given lists to build the algebraic 
    expression and return the evaluation of this expression.
    """
    precedence = {'+': 1, '-': 1, '*': 2, '//': 2, '**': 3}
    values = [operand[0]]
    ops = []

    for op, num in zip(operator, operand[1:]):
        while ops and (
            precedence[ops[-1]] > precedence[op] or
            (precedence[ops[-1]] == precedence[op] and op != '**')
        ):
            b = values.pop()
            a = values.pop()
            top = ops.pop()

            if top == '+':
                values.append(a + b)
            elif top == '-':
                values.append(a - b)
            elif top == '*':
                values.append(a * b)
            elif top == '//':
                values.append(a // b)
            elif top == '**':
                values.append(a ** b)

        ops.append(op)
        values.append(num)

    while ops:
        b = values.pop()
        a = values.pop()
        top = ops.pop()

        if top == '+':
            values.append(a + b)
        elif top == '-':
            values.append(a - b)
        elif top == '*':
            values.append(a * b)
        elif top == '//':
            values.append(a // b)
        elif top == '**':
            values.append(a ** b)

    return values[0]
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
