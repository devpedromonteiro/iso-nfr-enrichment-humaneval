
import unittest
import re
import sys
import math
import copy


def f(n):
    result = []
    fact = 1
    summ = 0

    for i in range(1, n + 1):
        fact *= i
        summ += i

        if i % 2 == 0:
            result.append(fact)
        else:
            result.append(summ)

    return result
candidate = f


def check(candidate):

    assert candidate(5) == [1, 2, 6, 24, 15]
    assert candidate(7) == [1, 2, 6, 24, 15, 720, 28]
    assert candidate(1) == [1]
    assert candidate(3) == [1, 2, 6]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
