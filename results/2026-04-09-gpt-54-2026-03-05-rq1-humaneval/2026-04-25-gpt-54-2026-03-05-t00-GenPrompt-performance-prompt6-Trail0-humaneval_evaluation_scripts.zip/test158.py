
import unittest
import re
import sys
import math
import copy


def find_max(words):
    """Return the word with the highest number of unique characters.
    If there's a tie, return the lexicographically smallest word.
    """
    best_word = ""
    best_unique_count = -1

    for word in words:
        unique_count = len(set(word))

        if unique_count > best_unique_count or (
            unique_count == best_unique_count and word < best_word
        ):
            best_word = word
            best_unique_count = unique_count

    return best_word
candidate = find_max


def check(candidate):

    # Check some simple cases
    assert (candidate(["name", "of", "string"]) == "string"), "t1"
    assert (candidate(["name", "enam", "game"]) == "enam"), 't2'
    assert (candidate(["aaaaaaa", "bb", "cc"]) == "aaaaaaa"), 't3'
    assert (candidate(["abc", "cba"]) == "abc"), 't4'
    assert (candidate(["play", "this", "game", "of","footbott"]) == "footbott"), 't5'
    assert (candidate(["we", "are", "gonna", "rock"]) == "gonna"), 't6'
    assert (candidate(["we", "are", "a", "mad", "nation"]) == "nation"), 't7'
    assert (candidate(["this", "is", "a", "prrk"]) == "this"), 't8'

    # Check some edge cases that are easy to work out by hand.
    assert (candidate(["b"]) == "b"), 't9'
    assert (candidate(["play", "play", "play"]) == "play"), 't10'



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
