
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    You are given a positive integer n. You have to create an integer array a of length n.
    For each i (1 â¤ i â¤ n), a[i] = i * i - i + 1.
    Return the number of triples (a[i], a[j], a[k]) where i < j < k
    and a[i] + a[j] + a[k] is a multiple of 3.

    Example:
        Input: n = 5
        Output: 1
    """

    # a[i] = i^2 - i + 1 = i(i-1) + 1
    # Since i(i-1) is always divisible by 2, but we only care mod 3:
    # Check pattern modulo 3:
    # i % 3 == 0 -> a[i] % 3 = 1
    # i % 3 == 1 -> a[i] % 3 = 1
    # i % 3 == 2 -> a[i] % 3 = 0
    #
    # So values are only of type:
    #   residue 1: count1
    #   residue 0: count0
    #
    # A triple sum is divisible by 3 only in this case:
    #   1 + 1 + 1 = 3 â¡ 0 (mod 3)
    # Since residue 2 never appears, no other combination works.

    count0 = n // 3                 # indices i where i % 3 == 2
    count1 = n - count0             # remaining indices

    # Number of ways to choose 3 elements with residue 1
    if count1 < 3:
        return 0

    return count1 * (count1 - 1) * (count1 - 2) // 6
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
