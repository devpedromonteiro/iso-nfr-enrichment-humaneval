
import unittest

from typing import List


from typing import List


def separate_paren_groups(paren_string: str) -> List[str]:
    """Input to this function is a string containing multiple groups of nested parentheses.
    Your goal is to separate those groups into separate strings and return the list of those.
    Separate groups are balanced (each open brace is properly closed) and not nested within each other.
    Ignore any spaces in the input string.

    >>> separate_paren_groups('( ) (( )) (( )( ))')
    ['()', '(())', '(()())']
    """
    groups = []
    current = []
    balance = 0

    for ch in paren_string:
        if ch == ' ':
            continue
        if ch == '(':
            current.append(ch)
            balance += 1
        elif ch == ')':
            current.append(ch)
            balance -= 1

            if balance < 0:
                raise ValueError("Unbalanced parentheses: too many closing parentheses")

            if balance == 0:
                groups.append(''.join(current))
                current = []
        else:
            raise ValueError(f"Invalid character: {ch}")

    if balance != 0:
        raise ValueError("Unbalanced parentheses: too many opening parentheses")

    return groups
candidate = separate_paren_groups


class Test(unittest.TestCase):
    def test(self):
        assert candidate("(()())(()())(())") == ['(()())', '(()())', '(())']
        assert candidate("(())(((())))(((())))(((())))") == ['(())', '(((())))', '(((())))', '(((())))']
        assert candidate("()(())((()))(())") == ['()', '(())', '((()))', '(())']
        assert candidate("(()())()((())()())((()))") == ['(()())', '()', '((())()())', '((()))']
        assert candidate("(()())(()())((()))((()))") == ['(()())', '(()())', '((()))', '((()))']
        assert candidate("((()))()()((())()())") == ['((()))', '()', '()', '((())()())']
        assert candidate("(())()()") == ['(())', '()', '()']
        assert candidate("(((())))((()))((()))(((())))") == ['(((())))', '((()))', '((()))', '(((())))']
        assert candidate("((()))(())((()))(((())))") == ['((()))', '(())', '((()))', '(((())))']
        assert candidate("(())()(())") == ['(())', '()', '(())']
        assert candidate("(())(()())(())") == ['(())', '(()())', '(())']
        assert candidate("()()(()())") == ['()', '()', '(()())']
        assert candidate("(())(())(())") == ['(())', '(())', '(())']
        assert candidate("((())()())((()))((())()())((())()())") == ['((())()())', '((()))', '((())()())', '((())()())']
        assert candidate("()((())()())((()))((())()())") == ['()', '((())()())', '((()))', '((())()())']
        assert candidate("()((())()())((())()())((()))") == ['()', '((())()())', '((())()())', '((()))']
        assert candidate("((()))()()(((())))") == ['((()))', '()', '()', '(((())))']
        assert candidate("()()()((()))") == ['()', '()', '()', '((()))']
        assert candidate("()(((())))(((())))(())") == ['()', '(((())))', '(((())))', '(())']
        assert candidate("((())()())((())()())((())()())()") == ['((())()())', '((())()())', '((())()())', '()']
        assert candidate("(((())))(((())))(())(())") == ['(((())))', '(((())))', '(())', '(())']
        assert candidate("()(())()") == ['()', '(())', '()']
        assert candidate("((()))()((())()())(()())") == ['((()))', '()', '((())()())', '(()())']
        assert candidate("((())()())(()())((())()())()") == ['((())()())', '(()())', '((())()())', '()']
        assert candidate("(((())))(())()()") == ['(((())))', '(())', '()', '()']
        assert candidate("()(()())(()())((()))") == ['()', '(()())', '(()())', '((()))']
        assert candidate("(())(())(()())") == ['(())', '(())', '(()())']
        assert candidate("()(()())(()())()") == ['()', '(()())', '(()())', '()']
        assert candidate("(()())()(()())") == ['(()())', '()', '(()())']
        assert candidate("(()())(()())()((())()())") == ['(()())', '(()())', '()', '((())()())']
        assert candidate("()(())(())") == ['()', '(())', '(())']
        assert candidate("()(()())(())") == ['()', '(()())', '(())']
        assert candidate('(()()) ((())) () ((())()())') == [
        '(()())', '((()))', '()', '((())()())'
    ]
        assert candidate("(())((()))()(((())))") == ['(())', '((()))', '()', '(((())))']
        assert candidate("((())()())((()))((()))((()))") == ['((())()())', '((()))', '((()))', '((()))']
        assert candidate('() (()) ((())) (((())))') == [
        '()', '(())', '((()))', '(((())))'
    ]
        assert candidate("()()()((())()())") == ['()', '()', '()', '((())()())']
        assert candidate("()(((())))(())((()))") == ['()', '(((())))', '(())', '((()))']
        assert candidate("(())(()())()") == ['(())', '(()())', '()']
        assert candidate("((()))(((())))(())()") == ['((()))', '(((())))', '(())', '()']
        assert candidate("(()())()((()))()") == ['(()())', '()', '((()))', '()']
        assert candidate('( ) (( )) (( )( ))') == ['()', '(())', '(()())']
        assert candidate("()(())(((())))(((())))") == ['()', '(())', '(((())))', '(((())))']
        assert candidate("((()))(((())))((()))((()))") == ['((()))', '(((())))', '((()))', '((()))']
        assert candidate("(((())))(())(())(((())))") == ['(((())))', '(())', '(())', '(((())))']
        assert candidate("((()))()(()())((()))") == ['((()))', '()', '(()())', '((()))']
        assert candidate("()(((())))()(())") == ['()', '(((())))', '()', '(())']
        assert candidate("(())()(()())") == ['(())', '()', '(()())']
        assert candidate("()()()") == ['()', '()', '()']
        assert candidate("((()))(()())((()))()") == ['((()))', '(()())', '((()))', '()']
        assert candidate("((()))(()())()((())()())") == ['((()))', '(()())', '()', '((())()())']
        assert candidate("(()())(()())(()())") == ['(()())', '(()())', '(()())']
        assert candidate('(()(())((())))') == [
        '(()(())((())))'
    ]
        assert candidate("()(())()(())") == ['()', '(())', '()', '(())']
        assert candidate("(())()(())(((())))") == ['(())', '()', '(())', '(((())))']
        assert candidate("()((())()())((())()())()") == ['()', '((())()())', '((())()())', '()']
        assert candidate("()()(())((()))") == ['()', '()', '(())', '((()))']
        assert candidate("(())((()))((()))(((())))") == ['(())', '((()))', '((()))', '(((())))']
        assert candidate("((()))(())(())(())") == ['((()))', '(())', '(())', '(())']
        assert candidate("((()))()()((()))") == ['((()))', '()', '()', '((()))']
        assert candidate("(()())((()))((())()())(()())") == ['(()())', '((()))', '((())()())', '(()())']
        assert candidate("(())(())()()") == ['(())', '(())', '()', '()']
        assert candidate("(()(())((())))") == ['(()(())((())))']
        assert candidate("(((())))((()))(((())))((()))") == ['(((())))', '((()))', '(((())))', '((()))']
        assert candidate("()()(())") == ['()', '()', '(())']
        assert candidate("()(())(()())") == ['()', '(())', '(()())']
        assert candidate("(()())()(()())(()())") == ['(()())', '()', '(()())', '(()())']
        assert candidate("(()())()(())") == ['(()())', '()', '(())']
        assert candidate("((()))(())(())()") == ['((()))', '(())', '(())', '()']

if __name__ == '__main__':
    unittest.main()
