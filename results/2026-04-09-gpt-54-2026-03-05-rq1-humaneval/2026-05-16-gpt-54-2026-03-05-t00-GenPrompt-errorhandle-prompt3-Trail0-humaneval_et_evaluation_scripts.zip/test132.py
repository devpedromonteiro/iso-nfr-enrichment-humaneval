
import unittest


def is_nested(string):
    stack = 0
    nested = False

    for ch in string:
        if ch == '[':
            stack += 1
            if stack >= 2:
                nested = True
        elif ch == ']':
            if stack > 0:
                stack -= 1

    return nested
candidate = is_nested


class Test(unittest.TestCase):
    def test(self):
        assert candidate('[[]') == False
        assert candidate("[]]]][[]") == False
        assert candidate('[]]]]]]][[[[[]') == False
        assert candidate("][[[[]]") == True
        assert candidate("[][[][][") == True
        assert candidate(('[]')) == False
        assert candidate("[][][[[[[]]") == True
        assert candidate('[[]][[') == True
        assert candidate("][][[") == False
        assert candidate('') == False
        assert candidate("[]][") == False
        assert candidate("][][][]]]") == True
        assert candidate("]][[[[][][]") == True
        assert candidate("[[[]][][[") == True
        assert candidate("b") == False
        assert candidate("][][][]") == True
        assert candidate("[[[][]]][") == True
        assert candidate("][]]]]]]]") == False
        assert candidate("[][[[]") == False
        assert candidate("]][][]]") == True
        assert candidate('[][][[]]') == True
        assert candidate("[]]][[[") == False
        assert candidate("[]][[[[]]") == True
        assert candidate("][][[][]") == True
        assert candidate("[][[]") == False
        assert candidate('[[[[[[[[') == False
        assert candidate("]]]]][][]][[[]") == True
        assert candidate("][[]]") == True
        assert candidate("][]]][][[][]") == True
        assert candidate("]]]][[]][") == True
        assert candidate("][[][]") == True
        assert candidate('[[]]') == True
        assert candidate("[]]]][") == False
        assert candidate("gv") == False
        assert candidate("[[[[][[[") == False
        assert candidate("]][][][]]") == True
        assert candidate("]]]][][]]]]") == True
        assert candidate("][]]]][[]]") == True
        assert candidate("][[[") == False
        assert candidate("][[[]]]") == True
        assert candidate("[[][]") == True
        assert candidate("][[[]") == False
        assert candidate("][]][]") == False
        assert candidate("]]][") == False
        assert candidate("[[[[]]][[[[]") == True
        assert candidate("ol") == False
        assert candidate("][[][][[") == True
        assert candidate("][[]]]") == True
        assert candidate("]][[") == False
        assert candidate("][]]") == False
        assert candidate("][][]][[[") == True
        assert candidate("ljv") == False
        assert candidate('[[[[]]]]') == True
        assert candidate("]]][[") == False
        assert candidate("[]]]]") == False
        assert candidate("][[]") == False
        assert candidate("][]]]]") == False
        assert candidate("]][[]]]][[][") == True
        assert candidate("][[][[]") == True
        assert candidate("[[[[[][][[") == True
        assert candidate("][]][][") == False
        assert candidate("adx") == False
        assert candidate("][]][") == False
        assert candidate("[[]][][]]") == True
        assert candidate("[][[[]][]]]") == True
        assert candidate("][[[]][") == True
        assert candidate("]]]") == False
        assert candidate("][[]]][][]][") == True
        assert candidate("[[]]]") == True
        assert candidate("uh") == False
        assert candidate("]][]][[][") == False
        assert candidate("]]]]]][]") == False
        assert candidate("]]]]]") == False
        assert candidate(']]]]]]]]') == False
        assert candidate("[]]][[]][") == True
        assert candidate("[[][]]]]") == True
        assert candidate("[]][][[]]") == True
        assert candidate("][]]][][]]") == True
        assert candidate("[]]][[[[[]") == False
        assert candidate("]]]]]][[[") == False
        assert candidate("]]][[][[[") == False
        assert candidate("]]][]]]]][[[][[") == False
        assert candidate("[[[[][") == False
        assert candidate("[][]][[[]][[[][") == True
        assert candidate("[[[]]]") == True
        assert candidate("]][]][]]][") == True
        assert candidate("[[][][]") == True
        assert candidate('[][]') == False
        assert candidate("]][") == False
        assert candidate("[]][[]]]") == True
        assert candidate("[][]]") == True
        assert candidate("][[") == False
        assert candidate("]][][[") == False
        assert candidate("]]][[]][][]][[][]]") == True
        assert candidate("]][[[[") == False
        assert candidate("]]][][[[[][]]") == True
        assert candidate("][[]][[[[") == True
        assert candidate("c") == False
        assert candidate("]][[]]") == True
        assert candidate("[]][][][]") == True
        assert candidate("][]][[[") == False
        assert candidate("[]]]][[]]][][]") == True
        assert candidate("]]]][[[[") == False
        assert candidate("[[[[[[[[][]]") == True
        assert candidate("[][][[") == False
        assert candidate("][[][[[[") == False
        assert candidate("]]]][]") == False
        assert candidate("]][[[][][[[") == True
        assert candidate("[[[[[[") == False
        assert candidate("[][[") == False
        assert candidate('[]]]]]]]]]]') == False
        assert candidate('[[][]]') == True

    # Check some edge cases that are easy to work out by hand.
        assert candidate("[][[][]]]]") == True
        assert candidate('[]]') == False
        assert candidate("][]]][[") == False
        assert candidate("[][[][[][") == True
        assert candidate("[]][[") == False
        assert candidate("[][]][]][") == True
        assert candidate("[[]][[") == True
        assert candidate("[[[[]]][[[[[") == True
        assert candidate("uz") == False
        assert candidate("]][]]]]") == False
        assert candidate("[[[]][][][]") == True
        assert candidate("]]][[]][[") == True
        assert candidate("[]][]") == False
        assert candidate("[][][[[[[][") == True
        assert candidate("h") == False
        assert candidate("[]]]]][[]") == False

if __name__ == '__main__':
    unittest.main()
