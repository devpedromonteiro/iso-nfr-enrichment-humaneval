
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[2] * x^2 + .... + xs[n] * x^n
    """
    return sum(coeff * math.pow(x, i) for i, coeff in enumerate(xs))


def find_zero(xs: list):
    """ xs are coefficients of a polynomial.
    find_zero find x such that poly(x) = 0.
    find_zero returns only only zero point, even if there are many.
    Moreover, find_zero only takes list xs having even number of coefficients
    and largest non zero coefficient as it guarantees
    a solution.
    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3
    1.0
    """
    try:
        if not isinstance(xs, list):
            raise TypeError("xs must be a list")

        if len(xs) == 0:
            raise ValueError("xs must not be empty")

        if len(xs) % 2 != 0:
            raise ValueError("xs must have even number of coefficients")

        # remove trailing zeros to find actual degree
        while xs and xs[-1] == 0:
            xs = xs[:-1]

        if not xs:
            raise ValueError("zero polynomial has infinitely many roots")

        # highest non-zero coefficient must correspond to odd degree
        # because original requirement says even number of coefficients,
        # so degree = len(xs)-1 is odd, which guarantees at least one real root
        if (len(xs) - 1) % 2 == 0:
            raise ValueError("polynomial degree must be odd")

        # simple special case: linear polynomial
        if len(xs) == 2:
            return -xs[0] / xs[1]

        # find interval [a, b] with sign change
        a, b = -1.0, 1.0
        fa, fb = poly(xs, a), poly(xs, b)

        while fa * fb > 0:
            a *= 2
            b *= 2
            fa, fb = poly(xs, a), poly(xs, b)

        # bisection method
        for _ in range(100):
            mid = (a + b) / 2
            fm = poly(xs, mid)

            if abs(fm) < 1e-12:
                return mid

            if fa * fm <= 0:
                b, fb = mid, fm
            else:
                a, fa = mid, fm

        return (a + b) / 2

    except OverflowError:
        raise ValueError("numerical overflow while searching for a root")
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
