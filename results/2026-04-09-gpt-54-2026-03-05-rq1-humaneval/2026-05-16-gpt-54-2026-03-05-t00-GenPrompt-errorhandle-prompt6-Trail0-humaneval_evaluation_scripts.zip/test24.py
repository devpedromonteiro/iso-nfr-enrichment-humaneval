
import unittest
import re
import sys
import math
import copy



def largest_divisor(n: int) -> int:
    """For a given number n, find the largest number that divides n evenly, smaller than n.
    
    >>> largest_divisor(15)
    5
    """
    try:
        if n <= 1:
            raise ValueError("n must be greater than 1")

        for i in range(n - 1, 0, -1):
            if n % i == 0:
                return i

    except TypeError:
        raise TypeError("n must be an integer")
candidate = largest_divisor




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(3) == 1
    assert candidate(7) == 1
    assert candidate(10) == 5
    assert candidate(100) == 50
    assert candidate(49) == 7


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
