
import unittest


def words_string(s):
    """
    You will be given a string of words separated by commas or spaces. Your task is
    to split the string into words and return an array of the words.
    
    For example:
    words_string("Hi, my name is John") == ["Hi", "my", "name", "is", "John"]
    words_string("One, two, three, four, five, six") == ["One", "two", "three", "four", "five", "six"]
    """
    try:
        if s is None:
            return []
        if not isinstance(s, str):
            s = str(s)

        s = s.strip()
        if not s:
            return []

        parts = s.replace(",", " ").split()
        return [word for word in parts if word]

    except Exception:
        return []
candidate = words_string


class Test(unittest.TestCase):
    def test(self):
        assert candidate("kvrvqAfyGQii,LRqxgnsSKZuCPlRVdLSSoPL") == ['kvrvqAfyGQii', 'LRqxgnsSKZuCPlRVdLSSoPL']
        assert candidate("cw") == ['cw']
        assert candidate("zhEMApF ZweLYvTJzJyCSIyeSRwcLhh") == ['zhEMApF', 'ZweLYvTJzJyCSIyeSRwcLhh']
        assert candidate("DTxPnHGKBttNX") == ['DTxPnHGKBttNX']
        assert candidate("epb") == ['epb']
        assert candidate("ibK I, bkGB,bjbOTKWfyjRDbQeWgqbBC") == ['ibK', 'I', 'bkGB', 'bjbOTKWfyjRDbQeWgqbBC']
        assert candidate("uTivmZXAK") == ['uTivmZXAK']
        assert candidate("MsArpfwKikWOX EkQCvGey") == ['MsArpfwKikWOX', 'EkQCvGey']
        assert candidate("wp") == ['wp']
        assert candidate("DyVi WoWpxT") == ['DyVi', 'WoWpxT']
        assert candidate("mcCcfVi") == ['mcCcfVi']
        assert candidate("blOXrKZ,qOqLgDcLBIoNmtEMKbLwAXlbRm") == ['blOXrKZ', 'qOqLgDcLBIoNmtEMKbLwAXlbRm']
        assert candidate("gSucSDyVhoD") == ['gSucSDyVhoD']
        assert candidate("HVFsXkNi") == ['HVFsXkNi']
        assert candidate("kurydrzteZjGjVb") == ['kurydrzteZjGjVb']
        assert candidate("xRkNssRLsifBpmfRABRk,UjYxpSgeBhCPv") == ['xRkNssRLsifBpmfRABRk', 'UjYxpSgeBhCPv']
        assert candidate("OTDpNx,FwFRdmtkrDjQy") == ['OTDpNx', 'FwFRdmtkrDjQy']
        assert candidate("pBjJg vABqOhYXfSbFKLecWG,xNzVVrhsfh") == ['pBjJg', 'vABqOhYXfSbFKLecWG', 'xNzVVrhsfh']
        assert candidate("stb") == ['stb']
        assert candidate("uaQiIFqLrxeNXvrHuobWBve") == ['uaQiIFqLrxeNXvrHuobWBve']
        assert candidate("sl,ofctrbjdchqv") == ['sl', 'ofctrbjdchqv']
        assert candidate("ahsXZqEouQtXINycLOKbGOuGcwphxqrRqvBZt") == ['ahsXZqEouQtXINycLOKbGOuGcwphxqrRqvBZt']
        assert candidate("UexJfvVLheQPeDpDfHvbdRRDtKKbN") == ['UexJfvVLheQPeDpDfHvbdRRDtKKbN']
        assert candidate("sdzr,lexdbcesu") == ['sdzr', 'lexdbcesu']
        assert candidate("Hi, my name") == ["Hi", "my", "name"]
        assert candidate(" hwquelxbzzoe") == ['hwquelxbzzoe']
        assert candidate("UYttolHhOXzUbBiaVzfhkRW,BFWdArkBi") == ['UYttolHhOXzUbBiaVzfhkRW', 'BFWdArkBi']
        assert candidate("gvebQcmBsFwozD,oRQaAaIGGsafxNdm") == ['gvebQcmBsFwozD', 'oRQaAaIGGsafxNdm']
        assert candidate(" infhpodtvqrszuo") == ['infhpodtvqrszuo']
        assert candidate("TTuFfwkGwCmFdTlbC") == ['TTuFfwkGwCmFdTlbC']
        assert candidate("qnyc bwziheuwny") == ['qnyc', 'bwziheuwny']
        assert candidate("xys,jxkxw ,tuoehpjer") == ['xys', 'jxkxw', 'tuoehpjer']
        assert candidate("cQDiHWkehrOfupG") == ['cQDiHWkehrOfupG']
        assert candidate("fvh") == ['fvh']
        assert candidate("OoOrgcyESQK FlPUvBbNPdqpgWwJvBi") == ['OoOrgcyESQK', 'FlPUvBbNPdqpgWwJvBi']
        assert candidate("uEhummpbtTkgORcaLbXcJVGfvJsmz") == ['uEhummpbtTkgORcaLbXcJVGfvJsmz']
        assert candidate("VygouQdfHOtVolHJlKVLMqqEmwzHabijOymo") == ['VygouQdfHOtVolHJlKVLMqqEmwzHabijOymo']
        assert candidate("bte") == ['bte']
        assert candidate("hym") == ['hym']
        assert candidate("oLJLCcDoACDxL") == ['oLJLCcDoACDxL']
        assert candidate("naUjUlpJaMOOof") == ['naUjUlpJaMOOof']
        assert candidate("mevgcg,wvgt,") == ['mevgcg', 'wvgt']
        assert candidate("FgejvV,") == ['FgejvV']
        assert candidate("GsjyQgOavmhBupf") == ['GsjyQgOavmhBupf']
        assert candidate("bBWYyFOJXxQcsnfEsQk,ZeoBjA,jk") == ['bBWYyFOJXxQcsnfEsQk', 'ZeoBjA', 'jk']
        assert candidate("pugjwcoritrfumvzsd") == ['pugjwcoritrfumvzsd']
        assert candidate("gfWpHipxkdkzAOwTs c,a ") == ['gfWpHipxkdkzAOwTs', 'c', 'a']
        assert candidate("zhosdwvtflvydiauoba") == ['zhosdwvtflvydiauoba']
        assert candidate("qMXAauHwjKptfaZTyGPsLhvoGDWzqncRTM") == ['qMXAauHwjKptfaZTyGPsLhvoGDWzqncRTM']
        assert candidate("tk") == ['tk']
        assert candidate("b") == ['b']
        assert candidate("dhvYVGkVVyznhoKsnLVdRwx") == ['dhvYVGkVVyznhoKsnLVdRwx']
        assert candidate("so ttkzweq swrqcdtbaz") == ['so', 'ttkzweq', 'swrqcdtbaz']
        assert candidate("wv") == ['wv']
        assert candidate("sov") == ['sov']
        assert candidate("eXNTVyasv dSIyLCMOvbWmNhvLNOxyOup,y") == ['eXNTVyasv', 'dSIyLCMOvbWmNhvLNOxyOup', 'y']
        assert candidate("themh,ymgzbtho") == ['themh', 'ymgzbtho']
        assert candidate("sfvgqmtflnbda") == ['sfvgqmtflnbda']
        assert candidate("va") == ['va']
        assert candidate("ZlSBYyUCTAnKCmw") == ['ZlSBYyUCTAnKCmw']
        assert candidate("gYeyPwGHDIZRlz") == ['gYeyPwGHDIZRlz']
        assert candidate("yKwlUpa") == ['yKwlUpa']
        assert candidate("SRcWhegcy U") == ['SRcWhegcy', 'U']
        assert candidate("ddGcSinGJPgxVVVteggdQU,") == ['ddGcSinGJPgxVVVteggdQU']
        assert candidate("bkzihehhs,ceabnwya") == ['bkzihehhs', 'ceabnwya']
        assert candidate("rz") == ['rz']
        assert candidate("IzeHVkGFOidcsptUUXRxusgNq sm iAtJd ") == ['IzeHVkGFOidcsptUUXRxusgNq', 'sm', 'iAtJd']
        assert candidate("t") == ['t']
        assert candidate("l ldd,yz acrnudynbq r") == ['l', 'ldd', 'yz', 'acrnudynbq', 'r']
        assert candidate("Lsy,NFEbGfZechwIHnqpidqsbOGNkgzbCBO") == ['Lsy', 'NFEbGfZechwIHnqpidqsbOGNkgzbCBO']
        assert candidate("EMJ mpDTiunggTKAzXplshTbiFiGA NFNb,C") == ['EMJ', 'mpDTiunggTKAzXplshTbiFiGA', 'NFNb', 'C']
        assert candidate("g") == ['g']
        assert candidate("LURNOizrjMckoEKIzFTuyRTR jSKHkrZtLTYx") == ['LURNOizrjMckoEKIzFTuyRTR', 'jSKHkrZtLTYx']
        assert candidate("WgDd scUKSF") == ['WgDd', 'scUKSF']
        assert candidate("xWzaUixFW") == ['xWzaUixFW']
        assert candidate("noshyiofr gli") == ['noshyiofr', 'gli']
        assert candidate("ihUWzcgFsQ lzJliFKk") == ['ihUWzcgFsQ', 'lzJliFKk']
        assert candidate("gLpHulEPVziizSczNccUgDLHoBTnFrn") == ['gLpHulEPVziizSczNccUgDLHoBTnFrn']
        assert candidate("JC,gCMCtZrAwEFcYjC,RWXgMXixfBWI") == ['JC', 'gCMCtZrAwEFcYjC', 'RWXgMXixfBWI']
        assert candidate("yELtMNRoKeFaNNWQS") == ['yELtMNRoKeFaNNWQS']
        assert candidate("bkfyLMuKdOsEVsV") == ['bkfyLMuKdOsEVsV']
        assert candidate("judm ulimqrmvmaz") == ['judm', 'ulimqrmvmaz']
        assert candidate("TKEzFSnzlpthExzMWvTNBJOctWaefVxDHhP") == ['TKEzFSnzlpthExzMWvTNBJOctWaefVxDHhP']
        assert candidate("MBiLLSWSRZGfoIsDQdEDimbvfJnyd") == ['MBiLLSWSRZGfoIsDQdEDimbvfJnyd']
        assert candidate("CAWUQQFzesyEaUEDQzlrOnwMJ SLIzU SUAUiY") == ['CAWUQQFzesyEaUEDQzlrOnwMJ', 'SLIzU', 'SUAUiY']
        assert candidate("imdljccdkztanux") == ['imdljccdkztanux']
        assert candidate("MtvYkACzuMJOTZIiXgraJDRCqpmfK,me") == ['MtvYkACzuMJOTZIiXgraJDRCqpmfK', 'me']
        assert candidate("RRfAjhePwiRmMhWdKnjIYPzzLYrPHJubkNAF") == ['RRfAjhePwiRmMhWdKnjIYPzzLYrPHJubkNAF']
        assert candidate("cnfzRFFNFwfXPSqXjqUElvUsZggNF ") == ['cnfzRFFNFwfXPSqXjqUElvUsZggNF']
        assert candidate("SGtwBteVrtCvkSJA") == ['SGtwBteVrtCvkSJA']
        assert candidate("r") == ['r']
        assert candidate("eiDbEdQNTFsstgXJXOWTBSSpUKqmpp U") == ['eiDbEdQNTFsstgXJXOWTBSSpUKqmpp', 'U']
        assert candidate("VlLJgpwhOBzVLcbhqkmQmzeWXlHSccuyrpHH") == ['VlLJgpwhOBzVLcbhqkmQmzeWXlHSccuyrpHH']
        assert candidate("KPkJArYQ") == ['KPkJArYQ']
        assert candidate("h") == ['h']
        assert candidate("Hi, my name is John") == ["Hi", "my", "name", "is", "John"]
        assert candidate("IETXcW,sm,bpYf") == ['IETXcW', 'sm', 'bpYf']
        assert candidate("ArkAaiedRkLQtjmpSQ,iR,RclZFvQYpyYZR") == ['ArkAaiedRkLQtjmpSQ', 'iR', 'RclZFvQYpyYZR']
        assert candidate("GWcJmjkQKIx") == ['GWcJmjkQKIx']
        assert candidate("ecTCx vezfoWOrvTTOcGRTMFEEOaohYR") == ['ecTCx', 'vezfoWOrvTTOcGRTMFEEOaohYR']
        assert candidate("ahmed     , gamal") == ["ahmed", "gamal"]
        assert candidate("DrpROLcKKuGcer,bWorhjxCeSeaq") == ['DrpROLcKKuGcer', 'bWorhjxCeSeaq']
        assert candidate("qhggiasekci,ysdfjlhy") == ['qhggiasekci', 'ysdfjlhy']
        assert candidate(" leZBbO qQuGjnhqkIdNGdRvkeadXMFT") == ['leZBbO', 'qQuGjnhqkIdNGdRvkeadXMFT']
        assert candidate("dvDbFjMvIs,yPOhhjSDw") == ['dvDbFjMvIs', 'yPOhhjSDw']
        assert candidate("WlM oCXmJWnF") == ['WlM', 'oCXmJWnF']
        assert candidate("u") == ['u']
        assert candidate("KPJacYGjuUmCWvwKJAveSFo") == ['KPJacYGjuUmCWvwKJAveSFo']
        assert candidate("") == []
        assert candidate("f oxbpoemunlpv") == ['f', 'oxbpoemunlpv']
        assert candidate("essJbwCw,kDukNqtdENjUIrEDxBpP") == ['essJbwCw', 'kDukNqtdENjUIrEDxBpP']
        assert candidate("bkrUEEtoxSAaMATeSrJijoej") == ['bkrUEEtoxSAaMATeSrJijoej']
        assert candidate("One, two, three, four, five, six") == ["One", "two", "three", "four", "five", "six"]
        assert candidate("le") == ['le']
        assert candidate(" iLJsRzuIwY,hOcg") == ['iLJsRzuIwY', 'hOcg']
        assert candidate("IJvqozJwqj,OzRPOWZG") == ['IJvqozJwqj', 'OzRPOWZG']
        assert candidate("JJpldjNpRPXfWVUqZdqmtPFdqTSVDs") == ['JJpldjNpRPXfWVUqZdqmtPFdqTSVDs']
        assert candidate("YaF,F kRmeIGcYbSeYjQomoLcgsDxbtIUl") == ['YaF', 'F', 'kRmeIGcYbSeYjQomoLcgsDxbtIUl']
        assert candidate("CJnDHVRfDmGmkBDsLuZFv,SmQuqePvghf") == ['CJnDHVRfDmGmkBDsLuZFv', 'SmQuqePvghf']
        assert candidate("kqntl,i ,wktrx eextto") == ['kqntl', 'i', 'wktrx', 'eextto']
        assert candidate("lapaLhIeTOzXNKe,hnBK") == ['lapaLhIeTOzXNKe', 'hnBK']
        assert candidate("WHyIHiunVGo,dDdturk,DICJf,jTtBF IR") == ['WHyIHiunVGo', 'dDdturk', 'DICJf', 'jTtBF', 'IR']
        assert candidate("One,, two, three, four, five, six,") == ["One", "two", "three", "four", "five", "six"]

    # Check some edge cases that are easy to work out by hand.
        assert candidate("VRg eCKTNreW") == ['VRg', 'eCKTNreW']
        assert candidate("MviVJBmw,ncuWatloKvGCSUIpiXDYjA,ztGeFQ") == ['MviVJBmw', 'ncuWatloKvGCSUIpiXDYjA', 'ztGeFQ']

if __name__ == '__main__':
    unittest.main()
