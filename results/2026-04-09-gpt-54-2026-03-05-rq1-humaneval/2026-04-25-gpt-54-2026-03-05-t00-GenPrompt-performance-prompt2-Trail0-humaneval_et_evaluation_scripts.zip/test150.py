
import unittest


def x_or_y(n, x, y):
    """A simple program which should return the value of x if n is 
    a prime number and should return the value of y otherwise.

    Examples:
    for x_or_y(7, 34, 12) == 34
    for x_or_y(15, 8, 5) == 5
    """
    if n < 2:
        return y
    if n == 2:
        return x
    if n % 2 == 0:
        return y

    i = 3
    while i * i <= n:
        if n % i == 0:
            return y
        i += 2

    return x
candidate = x_or_y


class Test(unittest.TestCase):
    def test(self):
        assert candidate(6, 34, 1234) == 1234
    

    # Check some edge cases that are easy to work out by hand.
        assert candidate(2, 6, 3) == 6
        assert candidate(8402, -3, 10) == 10
        assert candidate(8, 32, 4783) == 4783
        assert candidate(7192, 0, 8) == 8
        assert candidate(7919, -1, 12) == -1
        assert candidate(11, 35, 8) == 35
        assert candidate(91, 59, 127) == 127
        assert candidate(4, 39, 16) == 16
        assert candidate(6, 7, 4) == 4
        assert candidate(3706, 658, 579) == 579
        assert candidate(6, 29, 12) == 12
        assert candidate(858, 8, 56) == 56
        assert candidate(90, 51, 134) == 134
        assert candidate(6, 35, 1233) == 1233
        assert candidate(2, 31, 1449) == 31
        assert candidate(3, 1, 4) == 1
        assert candidate(8032, 1, 8) == 8
        assert candidate(88, 56, 125) == 125
        assert candidate(702, 1, 55) == 55
        assert candidate(6929, -3, 15) == 15
        assert candidate(3577, 1382, 583) == 583
        assert candidate(8842, -4, 17) == 17
        assert candidate(20, 5, 6) == 6
        assert candidate(2, 30, 5677) == 30
        assert candidate(1848, 8, 51) == 51
        assert candidate(89, 59, 134) == 59
        assert candidate(933, 1, 55) == 55
        assert candidate(8, 37, 781) == 781
        assert candidate(7, 1, 3) == 1
        assert candidate(9, 36, 8) == 8
        assert candidate(6, 2, 3) == 3
        assert candidate(13, 7, 7) == 7
        assert candidate(3, 33, 5212) == 33
        assert candidate(1, 35, 5018) == 5018
        assert candidate(5, 1, 3) == 1
        assert candidate(91, 56, 129) == 129
        assert candidate(15, 12, 5) == 5
        assert candidate(2, 33, 7) == 33
        assert candidate(1, 7, 4) == 4
        assert candidate(4, 6, 4) == 4
        assert candidate(5, 3, 3) == 3
        assert candidate(2, 3, 2) == 3
        assert candidate(3560, 1543, 584) == 584
        assert candidate(5, 1, 1) == 1
        assert candidate(13, 5, 6) == 5
        assert candidate(4, 3, 5) == 5
        assert candidate(3003, 1679, 588) == 588
        assert candidate(4, 7, 3) == 3
        assert candidate(3, 5, 5) == 5
        assert candidate(2, 2, 0) == 2
        assert candidate(2, 4, 2) == 4
        assert candidate(8, 33, 5730) == 5730
        assert candidate(8682, 0, 10) == 10
        assert candidate(3, 33, 9) == 33
        assert candidate(8, 35, 5383) == 5383
        assert candidate(88, 60, 127) == 127
        assert candidate(4, 5, 4) == 4
        assert candidate(17, 11, 9) == 11
        assert candidate(6942, 2, 14) == 14
        assert candidate(5, 34, 4936) == 34
        assert candidate(1, 35, 574) == 574
        assert candidate(4384, 1808, 580) == 580
        assert candidate(4, 4, 4) == 4
        assert candidate(89, 59, 124) == 59
        assert candidate(11, 32, 1982) == 32
        assert candidate(4, 7, 1) == 1
        assert candidate(5, 28, 6163) == 28
        assert candidate(3, 1, 3) == 1
        assert candidate(5, 34, 14) == 34
        assert candidate(6, 2, 5) == 5
        assert candidate(3, 32, 4854) == 32
        assert candidate(7727, -4, 16) == -4
        assert candidate(6, 32, 5433) == 5433
        assert candidate(6981, -2, 13) == 13
        assert candidate(95, 53, 126) == 126
        assert candidate(3068, 961, 580) == 580
        assert candidate(11, 9, 8) == 9
        assert candidate(15, 6, 2) == 2
        assert candidate(90, 59, 130) == 130
        assert candidate(1, 6, 5) == 5
        assert candidate(9, 34, 9) == 9
        assert candidate(17, 3, 7) == 3
        assert candidate(88, 52, 132) == 132
        assert candidate(96, 54, 128) == 128
        assert candidate(87, 51, 130) == 130
        assert candidate(17, 7, 7) == 7
        assert candidate(2103, 2, 47) == 47
        assert candidate(19, 8, 3) == 8
        assert candidate(1259, 3, 52) == 3
        assert candidate(7401, -3, 8) == 8
        assert candidate(11, 33, 8) == 33
        assert candidate(878, 3, 51) == 51
        assert candidate(8676, 0, 12) == 12
        assert candidate(9, 30, 315) == 315
        assert candidate(4372, 724, 579) == 579
        assert candidate(4027, 435, 578) == 435
        assert candidate(20, 5, 3) == 3
        assert candidate(2712, 1697, 583) == 583
        assert candidate(3, 38, 586) == 38
        assert candidate(10, 35, 12) == 12
        assert candidate(88, 56, 130) == 130
        assert candidate(5, 32, 5380) == 32
        assert candidate(3, 30, 4585) == 30
        assert candidate(7, 33, 446) == 33
        assert candidate(7, 34, 12) == 34
        assert candidate(8237, -3, 10) == -3
        assert candidate(3609, 1245, 583) == 583
        assert candidate(431, 5, 53) == 5
        assert candidate(743, 7, 54) == 7
        assert candidate(1605, 5, 48) == 48
        assert candidate(94, 59, 132) == 132
        assert candidate(2115, 6, 57) == 57
        assert candidate(9, 36, 12) == 12
        assert candidate(2094, 7, 54) == 54
        assert candidate(4, 32, 11) == 11
        assert candidate(9, 34, 1851) == 1851
        assert candidate(8561, 3, 9) == 9
        assert candidate(9, 36, 7) == 7
        assert candidate(4196, 479, 582) == 582
        assert candidate(6, 4, 5) == 5
        assert candidate(2, 4, 1) == 4
        assert candidate(15, 8, 5) == 5
        assert candidate(2, 30, 780) == 30
        assert candidate(7, 36, 423) == 36
        assert candidate(1, 37, 1396) == 1396
        assert candidate(3, 34, 1328) == 34
        assert candidate(3337, 759, 585) == 585
        assert candidate(8, 32, 4792) == 4792
        assert candidate(4410, 431, 587) == 587
        assert candidate(8, 35, 5150) == 5150
        assert candidate(3639, 1196, 583) == 583
        assert candidate(1527, 6, 50) == 50
        assert candidate(1936, 6, 53) == 53
        assert candidate(11, 3, 7) == 3
        assert candidate(1, 2, 0) == 0
        assert candidate(20, 8, 10) == 10

if __name__ == '__main__':
    unittest.main()
