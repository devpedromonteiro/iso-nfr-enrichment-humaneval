
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Given a grid with N rows and N columns (N >= 2) and a positive integer k,
    each cell of the grid contains a value. Every integer in the range [1, N * N]
    inclusive appears exactly once on the cells of the grid.

    Return the lexicographically smallest sequence of values obtainable by a path
    of length k, moving only up/down/left/right.
    """
    n = len(grid)

    # Map each value to its position for O(1) lookup by value.
    pos = [None] * (n * n + 1)
    for i in range(n):
        for j in range(n):
            pos[grid[i][j]] = (i, j)

    # Build adjacency by value instead of by coordinates.
    # Since values are unique and are exactly 1..n*n, this is compact and fast.
    adj = [[] for _ in range(n * n + 1)]
    for v in range(1, n * n + 1):
        i, j = pos[v]
        if i > 0:
            adj[v].append(grid[i - 1][j])
        if i + 1 < n:
            adj[v].append(grid[i + 1][j])
        if j > 0:
            adj[v].append(grid[i][j - 1])
        if j + 1 < n:
            adj[v].append(grid[i][j + 1])

    # reachable[t][v] = whether there exists a path of exactly t cells
    # starting from value v.
    # Since revisits are allowed, for any cell and any t >= 1 this is always True,
    # but we keep the DP-style filtering idea to construct the lexicographically
    # smallest valid sequence efficiently.
    current = [True] * (n * n + 1)

    # Candidate starting values: initially all values.
    candidates = list(range(1, n * n + 1))
    ans = []

    for remaining in range(k, 0, -1):
        # Pick the smallest value among current candidates.
        best = min(candidates)
        ans.append(best)

        if remaining == 1:
            break

        # Next candidates are neighbors of all cells with chosen value at this step.
        # Since values are unique, "best" corresponds to exactly one cell.
        candidates = adj[best]

    return ans
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
