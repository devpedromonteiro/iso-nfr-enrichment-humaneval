
import unittest



def is_palindrome(text: str):
    """
    Checks if given string is a palindrome
    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    """
    return text == text[::-1]
candidate = is_palindrome


class Test(unittest.TestCase):
    def test(self):
        assert candidate("szn") == False
        assert candidate("rkv") == False
        assert candidate("hjbymmr") == False
        assert candidate("eqjngnom") == False
        assert candidate("mvnui") == False
        assert candidate("jpsdq") == False
        assert candidate("huyna") == False
        assert candidate("sdrjwtzs") == False
        assert candidate("zlb") == False
        assert candidate("i") == True
        assert candidate("vrtooscvs") == False
        assert candidate('aaaaa') == True
        assert candidate("iaulv") == False
        assert candidate("qqfj") == False
        assert candidate("lbuj") == False
        assert candidate("tlo") == False
        assert candidate('xywzx') == False
        assert candidate("doh") == False
        assert candidate("cneyudv") == False
        assert candidate("paqo") == False
        assert candidate("lzktbv") == False
        assert candidate("tva") == False
        assert candidate("wsdwu") == False
        assert candidate("nitxmgysg") == False
        assert candidate("ktg") == False
        assert candidate("gbvydgiv") == False
        assert candidate("aywmrzjea") == False
        assert candidate("pvshmddrr") == False
        assert candidate("qyfcbx") == False
        assert candidate("itysck") == False
        assert candidate("xuznma") == False
        assert candidate("haqoixbz") == False
        assert candidate("hjutlwzss") == False
        assert candidate("zeryx") == False
        assert candidate("vlmhqnzd") == False
        assert candidate("ljhtqb") == False
        assert candidate("ufcy") == False
        assert candidate("wnwbndl") == False
        assert candidate('zbcd') == False
        assert candidate("zz") == True
        assert candidate("kldv") == False
        assert candidate("wwiaea") == False
        assert candidate("ltdbracy") == False
        assert candidate("a") == True
        assert candidate("bmcbauow") == False
        assert candidate("awjisoppb") == False
        assert candidate("ixvhtpow") == False
        assert candidate("lkfxoanwm") == False
        assert candidate("yoq") == False
        assert candidate("m") == True
        assert candidate('aba') == True
        assert candidate("gbfbdxnsb") == False
        assert candidate("ojo") == True
        assert candidate("isa") == False
        assert candidate("phnhdkuv") == False
        assert candidate("sbjdj") == False
        assert candidate("rpcgfvu") == False
        assert candidate("vvgif") == False
        assert candidate("lnlxmsj") == False
        assert candidate("rh") == False
        assert candidate("ychszuxp") == False
        assert candidate("ebzr") == False
        assert candidate("wehni") == False
        assert candidate("khkaxvnk") == False
        assert candidate("kjcmlw") == False
        assert candidate("ompnndmye") == False
        assert candidate("mhtikz") == False
        assert candidate("ojlpvu") == False
        assert candidate("xiuu") == False
        assert candidate('xywyz') == False
        assert candidate("koftjlh") == False
        assert candidate("jeosufcom") == False
        assert candidate("ddtg") == False
        assert candidate("aijdorvw") == False
        assert candidate("jybneeehi") == False
        assert candidate("jsl") == False
        assert candidate("bjknhlymn") == False
        assert candidate("efxuqeoa") == False
        assert candidate("lechj") == False
        assert candidate("iylcvntx") == False
        assert candidate("nhsb") == False
        assert candidate("ek") == False
        assert candidate("pvsftbkft") == False
        assert candidate("lotdardi") == False
        assert candidate("fwgsvakl") == False
        assert candidate("atrdc") == False
        assert candidate("wcn") == False
        assert candidate("ijiecnnua") == False
        assert candidate("qvn") == False
        assert candidate("kacug") == False
        assert candidate("ari") == False
        assert candidate("swygfgo") == False
        assert candidate("vhz") == False
        assert candidate("iuktid") == False
        assert candidate("jstxoibp") == False
        assert candidate("rwkyqbycn") == False
        assert candidate("ndt") == False
        assert candidate("kmm") == False
        assert candidate("esqcfar") == False
        assert candidate("pzwr") == False
        assert candidate("vo") == False
        assert candidate("vhuxo") == False
        assert candidate("bqxg") == False
        assert candidate("gvtpge") == False
        assert candidate("trfyowl") == False
        assert candidate("tzev") == False
        assert candidate("muq") == False
        assert candidate('xywyx') == True
        assert candidate("pc") == False
        assert candidate("gufwosl") == False
        assert candidate("fbgkamu") == False
        assert candidate("ohnqisnur") == False
        assert candidate('') == True
        assert candidate("hgwsd") == False
        assert candidate("huxrrtqxl") == False
        assert candidate("tivbexy") == False
        assert candidate("lsendyfuo") == False
        assert candidate("jsizy") == False
        assert candidate("hsjcijn") == False
        assert candidate("ixbjt") == False
        assert candidate("mkfmv") == False
        assert candidate("oluv") == False
        assert candidate("ibqulgnv") == False
        assert candidate("dpr") == False
        assert candidate("fjaus") == False
        assert candidate("evce") == False
        assert candidate("rdheftrdx") == False
        assert candidate("l") == True
        assert candidate("rnujwr") == False
        assert candidate("uhang") == False
        assert candidate("bm") == False

if __name__ == '__main__':
    unittest.main()
