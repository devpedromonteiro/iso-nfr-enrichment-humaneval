
import unittest



def correct_bracketing(brackets: str):
    count = 0
    for ch in brackets:
        if ch == "(":
            count += 1
        else:
            count -= 1
        if count < 0:
            return False
    return count == 0
candidate = correct_bracketing


class Test(unittest.TestCase):
    def test(self):
        assert candidate("(") == False
        assert candidate("))()))((())((()()((((") == False
        assert candidate(")((((((()())())()(((") == False
        assert candidate(")((())))()(()))())") == False
        assert not candidate("(()")
        assert candidate("(()())") == True
        assert candidate("(()())()()((()()())())(()()(()))()") == True
        assert candidate("()))") == False
        assert not candidate(")")
        assert candidate("()()") == True
        assert candidate(")())()())))(((") == False
        assert candidate("))((((((()") == False
        assert candidate(")((((") == False
        assert candidate("()(()())") == True
        assert candidate("(()())()()((()()())())(()()(()))") == True
        assert candidate("((())()))") == False
        assert candidate("()()()(())(") == False
        assert candidate("))())") == False
        assert candidate("()()(()())()")
        assert candidate("()()(()())()") == True
        assert candidate(")") == False
        assert candidate("()()()") == True
        assert candidate("()))()(") == False
        assert candidate("(())") == True
        assert candidate("()()(()())()()()(()())()") == True
        assert candidate("()()(()())()()()(()())()()()((()()())())(()()(()))") == True
        assert candidate("(()())()(()())") == True
        assert candidate("(()))))()") == False
        assert candidate(")(()())(") == False
        assert candidate("((((") == False
        assert candidate("(()())")
        assert candidate("(((()") == False
        assert candidate("))()") == False
        assert candidate(")))((") == False
        assert candidate(")()())") == False
        assert candidate("(()") == False
        assert candidate("(()())(()())()") == True
        assert candidate("(()())()()(()())()") == True
        assert candidate("()()(()())()(()())()") == True
        assert not candidate("((((")
        assert candidate("))))") == False
        assert candidate("()") == True
        assert candidate("())") == False
        assert candidate(")()(())()((()())") == False
        assert candidate("))()))))(()()(") == False
        assert candidate("()())())(") == False
        assert candidate("()()()()(()())()") == True
        assert candidate(")()(") == False
        assert candidate("((((((") == False
        assert candidate("()()()((()()(") == False
        assert candidate("()()((()()())())(()()(()))()()(()())()()") == True
        assert not candidate("((()())))")
        assert candidate("()")
        assert not candidate("(")
        assert candidate("())())((()()))") == False
        assert candidate("(()())()") == True
        assert candidate(")(()))(((()((()") == False
        assert candidate("()))))") == False
        assert candidate("))())()))(())") == False
        assert candidate(")())())()") == False
        assert candidate(")((()))))((()(") == False
        assert candidate("()())())))(()(())()") == False
        assert candidate(")((((((") == False
        assert not candidate(")(()")
        assert candidate("((())()()") == False
        assert not candidate("()()(()())()))()")
        assert candidate(")(()(())((())((())") == False
        assert candidate(")(()") == False
        assert candidate(")()") == False
        assert candidate("()()(()())()()()((()()())())(()()(()))(()())") == True
        assert candidate("()()(()())()()") == True
        assert candidate("(()())()()((()()())())(()()(()))(()())") == True
        assert candidate("()()((()()())())(()()(()))")
        assert candidate("(((") == False
        assert candidate("") == True
        assert not candidate("()()(()())())(()")
        assert candidate("()(())()()()") == True
        assert candidate(")()()(()(())(") == False
        assert candidate("))()()())(())") == False

if __name__ == '__main__':
    unittest.main()
