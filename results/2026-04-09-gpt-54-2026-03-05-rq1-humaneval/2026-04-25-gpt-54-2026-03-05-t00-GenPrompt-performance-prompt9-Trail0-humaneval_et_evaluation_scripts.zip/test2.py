
import unittest



def truncate_number(number: float) -> float:
    return number % 1.0
candidate = truncate_number


class Test(unittest.TestCase):
    def test(self):
        assert candidate(3.952) == 0.952
        assert abs(candidate(1.33) - 0.33) < 1e-6
        assert candidate(3.452) == 0.452
        assert candidate(5.473) == 0.473
        assert candidate(1.767) == 0.767
        assert candidate(7.378) == 0.378
        assert candidate(4.914) == 0.914
        assert candidate(5.029) == 0.029
        assert candidate(2.996) == 0.996
        assert candidate(1.661) == 0.661
        assert candidate(8.827) == 0.827
        assert candidate(7.001) == 0.001
        assert candidate(6.826) == 0.826
        assert candidate(8.419) == 0.419
        assert candidate(4.261) == 0.261
        assert candidate(3.908) == 0.908
        assert candidate(5.276) == 0.276
        assert candidate(7.062) == 0.062
        assert candidate(6.094) == 0.094
        assert candidate(7.798) == 0.798
        assert candidate(6.191) == 0.191
        assert candidate(3.904) == 0.904
        assert candidate(3.225) == 0.225
        assert candidate(8.878) == 0.878
        assert candidate(6.471) == 0.471
        assert abs(candidate(123.456) - 0.456) < 1e-6
        assert candidate(5.246) == 0.246
        assert candidate(8.588) == 0.588
        assert candidate(3.719) == 0.719
        assert candidate(2.856) == 0.856
        assert candidate(7.997) == 0.997
        assert candidate(5.168) == 0.168
        assert candidate(7.194) == 0.194
        assert candidate(3.194) == 0.194
        assert candidate(6.558) == 0.558
        assert candidate(8.631) == 0.631
        assert candidate(4.046) == 0.046
        assert candidate(3.505) == 0.505
        assert candidate(6.05) == 0.05
        assert candidate(6.333) == 0.333
        assert candidate(1.689) == 0.689
        assert candidate(7.733) == 0.733
        assert candidate(3.416) == 0.416
        assert candidate(7.299) == 0.299
        assert candidate(2.561) == 0.561
        assert candidate(1.319) == 0.319
        assert candidate(7.768) == 0.768
        assert candidate(7.016) == 0.016
        assert candidate(4.441) == 0.441
        assert candidate(8.66) == 0.66
        assert candidate(8.957) == 0.957
        assert candidate(8.788) == 0.788
        assert candidate(2.918) == 0.918
        assert candidate(8.063) == 0.063
        assert candidate(7.545) == 0.545
        assert candidate(1.338) == 0.338
        assert candidate(6.424) == 0.424
        assert candidate(1.657) == 0.657
        assert candidate(2.584) == 0.584
        assert candidate(3.753) == 0.753
        assert candidate(7.831) == 0.831
        assert candidate(2.562) == 0.562
        assert candidate(2.296) == 0.296
        assert candidate(3.723) == 0.723
        assert candidate(1.683) == 0.683
        assert candidate(1.98) == 0.98
        assert candidate(6.248) == 0.248
        assert candidate(4.532) == 0.532
        assert candidate(6.63) == 0.63
        assert candidate(1.055) == 0.055
        assert candidate(4.337) == 0.337
        assert candidate(3.5) == 0.5
        assert candidate(8.268) == 0.268
        assert candidate(6.382) == 0.382
        assert candidate(7.871) == 0.871
        assert candidate(2.622) == 0.622
        assert candidate(6.86) == 0.86
        assert candidate(7.256) == 0.256
        assert candidate(3.533) == 0.533
        assert candidate(3.2) == 0.2
        assert candidate(6.058) == 0.058
        assert candidate(7.662) == 0.662
        assert candidate(5.309) == 0.309
        assert candidate(1.615) == 0.615
        assert candidate(6.664) == 0.664
        assert candidate(6.824) == 0.824
        assert candidate(1.823) == 0.823
        assert candidate(5.987) == 0.987
        assert candidate(7.69) == 0.69
        assert candidate(2.72) == 0.72
        assert candidate(3.948) == 0.948
        assert candidate(5.319) == 0.319
        assert candidate(4.396) == 0.396
        assert candidate(3.127) == 0.127
        assert candidate(5.623) == 0.623
        assert candidate(1.496) == 0.496
        assert candidate(4.245) == 0.245
        assert candidate(1.471) == 0.471
        assert candidate(6.499) == 0.499
        assert candidate(6.682) == 0.682
        assert candidate(7.971) == 0.971
        assert candidate(8.976) == 0.976
        assert candidate(1.641) == 0.641

if __name__ == '__main__':
    unittest.main()
