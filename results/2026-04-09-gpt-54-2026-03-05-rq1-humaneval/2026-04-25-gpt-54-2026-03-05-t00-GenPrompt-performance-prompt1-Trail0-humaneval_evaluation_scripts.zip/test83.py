
import unittest
import re
import sys
import math
import copy


def starts_one_ends(n):
    """
    Given a positive integer n, return the count of n-digit
    positive integers that start or end with 1.
    """
    if n <= 0:
        return 0

    # Count numbers that start with 1:
    # first digit fixed as 1, remaining n-1 digits each have 10 choices
    starts_with_1 = 10 ** (n - 1)

    # Count numbers that end with 1:
    # last digit fixed as 1, first digit has 9 choices (1-9),
    # middle n-2 digits each have 10 choices
    ends_with_1 = 9 * (10 ** (n - 2)) if n > 1 else 1

    # Count numbers counted twice: start and end with 1
    # first and last digits fixed as 1, middle n-2 digits each have 10 choices
    both = 10 ** (n - 2) if n > 1 else 1

    return starts_with_1 + ends_with_1 - both
candidate = starts_one_ends


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(1) == 1
    assert candidate(2) == 18
    assert candidate(3) == 180
    assert candidate(4) == 1800
    assert candidate(5) == 18000

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
