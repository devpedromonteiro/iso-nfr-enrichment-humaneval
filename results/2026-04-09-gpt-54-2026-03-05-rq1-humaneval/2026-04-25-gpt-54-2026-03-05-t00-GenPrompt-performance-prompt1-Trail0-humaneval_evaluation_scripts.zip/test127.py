
import unittest
import re
import sys
import math
import copy


def intersection(interval1, interval2):
    a1, b1 = interval1
    a2, b2 = interval2

    start = max(a1, a2)
    end = min(b1, b2)

    if start > end:
        return "NO"

    # Closed intervals: length of [start, end] is end - start
    length = end - start

    if length < 2:
        return "NO"
    if length == 2:
        return "YES"
    if length % 2 == 0:
        return "NO"

    i = 3
    while i * i <= length:
        if length % i == 0:
            return "NO"
        i += 2

    return "YES"
candidate = intersection


def check(candidate):

    # Check some simple cases
    assert candidate((1, 2), (2, 3)) == "NO"
    assert candidate((-1, 1), (0, 4)) == "NO"
    assert candidate((-3, -1), (-5, 5)) == "YES"
    assert candidate((-2, 2), (-4, 0)) == "YES"

    # Check some edge cases that are easy to work out by hand.
    assert candidate((-11, 2), (-1, -1)) == "NO"
    assert candidate((1, 2), (3, 5)) == "NO"
    assert candidate((1, 2), (1, 2)) == "NO"
    assert candidate((-2, -2), (-3, -2)) == "NO"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
