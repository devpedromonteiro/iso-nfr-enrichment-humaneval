
import unittest
import re
import sys
import math
import copy



def is_palindrome(string: str) -> bool:
    """ Test if given string is a palindrome """
    return string == string[::-1]


def is_palindrome(string: str) -> bool:
    """Test if given string is a palindrome."""
    return string == string[::-1]


def make_palindrome(string: str) -> str:
    """Find the shortest palindrome that begins with the supplied string.

    The result is formed by appending the fewest possible characters to the end
    of `string` so that the whole result becomes a palindrome.

    Strategy:
    - Find the earliest position `i` such that `string[i:]` is a palindrome.
    - Append `string[:i]` reversed.

    This implementation avoids repeatedly slicing and reversing large suffixes.
    It checks palindromic suffixes in-place with two pointers.

    >>> make_palindrome('')
    ''
    >>> make_palindrome('cat')
    'catac'
    >>> make_palindrome('cata')
    'catac'
    >>> make_palindrome('race')
    'racecar'
    >>> make_palindrome('aba')
    'aba'
    """
    n = len(string)
    if n < 2:
        return string

    def is_palindromic_suffix(start: int) -> bool:
        left, right = start, n - 1
        while left < right:
            if string[left] != string[right]:
                return False
            left += 1
            right -= 1
        return True

    for i in range(n):
        if is_palindromic_suffix(i):
            return string + string[:i][::-1]

    return string
candidate = make_palindrome




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == ''
    assert candidate('x') == 'x'
    assert candidate('xyz') == 'xyzyx'
    assert candidate('xyx') == 'xyx'
    assert candidate('jerry') == 'jerryrrej'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
