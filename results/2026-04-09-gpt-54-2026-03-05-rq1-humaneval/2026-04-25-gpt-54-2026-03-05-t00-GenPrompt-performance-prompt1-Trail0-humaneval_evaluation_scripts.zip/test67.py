
import unittest
import re
import sys
import math
import copy


def fruit_distribution(s, n):
    nums = []
    num = 0
    in_number = False

    for ch in s:
        if '0' <= ch <= '9':
            num = num * 10 + (ord(ch) - ord('0'))
            in_number = True
        elif in_number:
            nums.append(num)
            num = 0
            in_number = False

    if in_number:
        nums.append(num)

    return n - nums[0] - nums[1]
candidate = fruit_distribution


def check(candidate):

    # Check some simple cases
    assert candidate("5 apples and 6 oranges",19) == 8
    assert candidate("5 apples and 6 oranges",21) == 10
    assert candidate("0 apples and 1 oranges",3) == 2
    assert candidate("1 apples and 0 oranges",3) == 2
    assert candidate("2 apples and 3 oranges",100) == 95
    assert candidate("2 apples and 3 oranges",5) == 0
    assert candidate("1 apples and 100 oranges",120) == 19


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
