
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Given a grid with N rows and N columns (N >= 2) and a positive integer k,
    each cell of the grid contains a value. Every integer in the range [1, N * N]
    inclusive appears exactly once on the cells of the grid.

    Return the lexicographically smallest sequence of values obtainable by a path
    of length k, moving only up/down/left/right.
    """
    n = len(grid)

    # Map each value -> its position for O(1) lookup.
    pos = [None] * (n * n + 1)
    for i in range(n):
        row = grid[i]
        for j, v in enumerate(row):
            pos[v] = (i, j)

    # Current candidate cells that can realize the prefix built so far.
    # Initially, any cell can be the start.
    current = {(i, j) for i in range(n) for j in range(n)}
    answer = []

    for step in range(k):
        best_val = None
        next_cells = set()

        # Among all neighbors reachable in one move from current cells
        # (or the same cells for step 0), find the minimum possible value.
        if step == 0:
            candidates = current
        else:
            candidates = set()
            for i, j in current:
                if i > 0:
                    candidates.add((i - 1, j))
                if i + 1 < n:
                    candidates.add((i + 1, j))
                if j > 0:
                    candidates.add((i, j - 1))
                if j + 1 < n:
                    candidates.add((i, j + 1))

        for i, j in candidates:
            v = grid[i][j]
            if best_val is None or v < best_val:
                best_val = v
                next_cells = {(i, j)}
            elif v == best_val:
                next_cells.add((i, j))

        answer.append(best_val)
        current = next_cells

    return answer
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
