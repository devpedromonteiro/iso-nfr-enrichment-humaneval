
import unittest
import re
import sys
import math
import copy


def f(n):
    """Implement the function f that takes n as a parameter,
    and returns a list of size n, such that the value of the element at index i
    is the factorial of i if i is even or the sum of numbers from 1 to i otherwise.
    i starts from 1.

    Example:
    f(5) == [1, 2, 6, 24, 15]
    """
    result = []
    factorial = 1
    running_sum = 0

    for i in range(1, n + 1):
        factorial *= i
        running_sum += i
        result.append(factorial if i % 2 == 0 else running_sum)

    return result
candidate = f


def check(candidate):

    assert candidate(5) == [1, 2, 6, 24, 15]
    assert candidate(7) == [1, 2, 6, 24, 15, 720, 28]
    assert candidate(1) == [1]
    assert candidate(3) == [1, 2, 6]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
