
import unittest



def prime_fib(n: int):
    """
    prime_fib returns n-th number that is a Fibonacci number and it's also prime.
    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """
    if n < 1:
        raise ValueError("n must be a positive integer")

    def is_prime(x: int) -> bool:
        if x < 2:
            return False
        if x in (2, 3):
            return True
        if x % 2 == 0 or x % 3 == 0:
            return False

        i = 5
        while i * i <= x:
            if x % i == 0 or x % (i + 2) == 0:
                return False
            i += 6
        return True

    # Fibonacci primes start from F(3)=2, F(4)=3
    a, b = 1, 2
    count = 1 if is_prime(a) else 0  # a == 1, so count starts at 0

    while True:
        if is_prime(b):
            count += 1
            if count == n:
                return b
        a, b = b, a + b
candidate = prime_fib


class Test(unittest.TestCase):
    def test(self):
        assert candidate(2) == 3
        assert candidate(12) == 99194853094755497
        assert candidate(6) == 233
        assert candidate(10) == 433494437
        assert candidate(3) == 5
        assert candidate(5) == 89
        assert candidate(8) == 28657
        assert candidate(11) == 2971215073
        assert candidate(1) == 2
        assert candidate(4) == 13
        assert candidate(9) == 514229
        assert candidate(7) == 1597

if __name__ == '__main__':
    unittest.main()
