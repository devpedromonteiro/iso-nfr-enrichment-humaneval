
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    # a[i] = i^2 - i + 1
    # modulo 3:
    # if i % 3 == 0 -> a[i] % 3 = 1
    # if i % 3 == 1 -> a[i] % 3 = 1
    # if i % 3 == 2 -> a[i] % 3 = 0
    #
    # So values are only in residue classes:
    # count0 = number of indices i in [1..n] with i % 3 == 2
    # count1 = remaining indices
    #
    # A triple sum is divisible by 3 only if residues are:
    # (0,1,1)

    count0 = (n + 1) // 3          # indices congruent to 2 mod 3
    count1 = n - count0            # indices congruent to 0 or 1 mod 3

    # choose 1 from count0 and 2 from count1
    return count0 * count1 * (count1 - 1) // 2
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
