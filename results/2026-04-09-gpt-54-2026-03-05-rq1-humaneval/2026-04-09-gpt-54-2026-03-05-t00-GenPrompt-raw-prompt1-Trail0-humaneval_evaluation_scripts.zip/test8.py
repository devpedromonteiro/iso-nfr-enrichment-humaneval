
import unittest
import re
import sys
import math
import copy

from typing import List, Tuple


from typing import List, Tuple


def sum_product(numbers: List[int]) -> Tuple[int, int]:
    total = sum(numbers)
    product = 1
    for num in numbers:
        product *= num
    return total, product
candidate = sum_product




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == (0, 1)
    assert candidate([1, 1, 1]) == (3, 1)
    assert candidate([100, 0]) == (100, 0)
    assert candidate([3, 5, 7]) == (3 + 5 + 7, 3 * 5 * 7)
    assert candidate([10]) == (10, 10)


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
