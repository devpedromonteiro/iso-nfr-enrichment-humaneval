
import unittest
import re
import sys
import math
import copy


def count_upper(s):
    count = 0
    for i in range(0, len(s), 2):
        c = s[i]
        if c == 'A' or c == 'E' or c == 'I' or c == 'O' or c == 'U':
            count += 1
    return count
candidate = count_upper


def check(candidate):

    # Check some simple cases
    assert candidate('aBCdEf')  == 1
    assert candidate('abcdefg') == 0
    assert candidate('dBBE') == 0
    assert candidate('B')  == 0
    assert candidate('U')  == 1
    assert candidate('') == 0
    assert candidate('EEEE') == 2

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
