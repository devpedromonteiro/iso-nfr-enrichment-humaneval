
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Given a grid with N rows and N columns (N >= 2) and a positive integer k,
    each cell of the grid contains a value. Every integer in the range [1, N * N]
    inclusive appears exactly once on the cells of the grid.

    Return the lexicographically smallest sequence of values obtainable by a path
    of length k, where each move goes to a 4-directionally adjacent cell.
    """
    n = len(grid)

    # Map value -> position for O(1) access by value.
    pos = [None] * (n * n + 1)
    for i in range(n):
        row = grid[i]
        for j in range(n):
            pos[row[j]] = (i, j)

    # Precompute neighbors by cell value, storing neighbor values directly.
    neighbors = [[] for _ in range(n * n + 1)]
    for v in range(1, n * n + 1):
        i, j = pos[v]
        cur = neighbors[v]
        if i > 0:
            cur.append(grid[i - 1][j])
        if i + 1 < n:
            cur.append(grid[i + 1][j])
        if j > 0:
            cur.append(grid[i][j - 1])
        if j + 1 < n:
            cur.append(grid[i][j + 1])
        cur.sort()  # Helps process candidates in increasing value order.

    # For k == 1, answer is always [1] since values are 1..N^2 uniquely.
    if k == 1:
        return [1]

    # Start from the globally smallest possible first value.
    ans = [1]
    frontier = {1}  # possible current end-cell values after matching ans

    # Build answer greedily, keeping all states that can still realize
    # the current lexicographically smallest prefix.
    for _ in range(k - 1):
        best_next = None

        # Find smallest possible next value from current frontier.
        for v in frontier:
            for nv in neighbors[v]:
                if best_next is None or nv < best_next:
                    best_next = nv
                    if best_next == 1:
                        break
            if best_next == 1:
                break

        ans.append(best_next)

        # Keep only endpoints that achieve this best next value.
        new_frontier = set()
        for v in frontier:
            for nv in neighbors[v]:
                if nv == best_next:
                    new_frontier.add(nv)

        frontier = new_frontier

    return ans
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
