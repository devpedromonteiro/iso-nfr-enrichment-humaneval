
import unittest

from typing import List


from typing import List


def separate_paren_groups(paren_string: str) -> List[str]:
    """Input to this function is a string containing multiple groups of nested parentheses.
    Your goal is to separate those groups into separate strings and return them as a list.

    Separate groups are balanced (each open brace is properly closed) and not nested within each other.
    Ignore any spaces in the input string.

    >>> separate_paren_groups('( ) (( )) (( )( ))')
    ['()', '(())', '(()())']
    """
    if not isinstance(paren_string, str):
        raise TypeError("Input must be a string.")

    result = []
    current_group = []
    balance = 0

    for char in paren_string:
        if char == ' ':
            continue
        if char not in '()':
            raise ValueError(f"Invalid character found: {char!r}")

        current_group.append(char)

        if char == '(':
            balance += 1
        else:
            balance -= 1

        if balance < 0:
            raise ValueError("Unbalanced parentheses: too many closing parentheses.")

        if balance == 0 and current_group:
            result.append(''.join(current_group))
            current_group = []

    if balance != 0:
        raise ValueError("Unbalanced parentheses: missing closing parenthesis.")

    return result
candidate = separate_paren_groups


class Test(unittest.TestCase):
    def test(self):
        assert candidate("(()())(()())(())") == ['(()())', '(()())', '(())']
        assert candidate("(())(((())))(((())))(((())))") == ['(())', '(((())))', '(((())))', '(((())))']
        assert candidate("()(())((()))(())") == ['()', '(())', '((()))', '(())']
        assert candidate("(()())()((())()())((()))") == ['(()())', '()', '((())()())', '((()))']
        assert candidate("(()())(()())((()))((()))") == ['(()())', '(()())', '((()))', '((()))']
        assert candidate("((()))()()((())()())") == ['((()))', '()', '()', '((())()())']
        assert candidate("(())()()") == ['(())', '()', '()']
        assert candidate("(((())))((()))((()))(((())))") == ['(((())))', '((()))', '((()))', '(((())))']
        assert candidate("((()))(())((()))(((())))") == ['((()))', '(())', '((()))', '(((())))']
        assert candidate("(())()(())") == ['(())', '()', '(())']
        assert candidate("(())(()())(())") == ['(())', '(()())', '(())']
        assert candidate("()()(()())") == ['()', '()', '(()())']
        assert candidate("(())(())(())") == ['(())', '(())', '(())']
        assert candidate("((())()())((()))((())()())((())()())") == ['((())()())', '((()))', '((())()())', '((())()())']
        assert candidate("()((())()())((()))((())()())") == ['()', '((())()())', '((()))', '((())()())']
        assert candidate("()((())()())((())()())((()))") == ['()', '((())()())', '((())()())', '((()))']
        assert candidate("((()))()()(((())))") == ['((()))', '()', '()', '(((())))']
        assert candidate("()()()((()))") == ['()', '()', '()', '((()))']
        assert candidate("()(((())))(((())))(())") == ['()', '(((())))', '(((())))', '(())']
        assert candidate("((())()())((())()())((())()())()") == ['((())()())', '((())()())', '((())()())', '()']
        assert candidate("(((())))(((())))(())(())") == ['(((())))', '(((())))', '(())', '(())']
        assert candidate("()(())()") == ['()', '(())', '()']
        assert candidate("((()))()((())()())(()())") == ['((()))', '()', '((())()())', '(()())']
        assert candidate("((())()())(()())((())()())()") == ['((())()())', '(()())', '((())()())', '()']
        assert candidate("(((())))(())()()") == ['(((())))', '(())', '()', '()']
        assert candidate("()(()())(()())((()))") == ['()', '(()())', '(()())', '((()))']
        assert candidate("(())(())(()())") == ['(())', '(())', '(()())']
        assert candidate("()(()())(()())()") == ['()', '(()())', '(()())', '()']
        assert candidate("(()())()(()())") == ['(()())', '()', '(()())']
        assert candidate("(()())(()())()((())()())") == ['(()())', '(()())', '()', '((())()())']
        assert candidate("()(())(())") == ['()', '(())', '(())']
        assert candidate("()(()())(())") == ['()', '(()())', '(())']
        assert candidate('(()()) ((())) () ((())()())') == [
        '(()())', '((()))', '()', '((())()())'
    ]
        assert candidate("(())((()))()(((())))") == ['(())', '((()))', '()', '(((())))']
        assert candidate("((())()())((()))((()))((()))") == ['((())()())', '((()))', '((()))', '((()))']
        assert candidate('() (()) ((())) (((())))') == [
        '()', '(())', '((()))', '(((())))'
    ]
        assert candidate("()()()((())()())") == ['()', '()', '()', '((())()())']
        assert candidate("()(((())))(())((()))") == ['()', '(((())))', '(())', '((()))']
        assert candidate("(())(()())()") == ['(())', '(()())', '()']
        assert candidate("((()))(((())))(())()") == ['((()))', '(((())))', '(())', '()']
        assert candidate("(()())()((()))()") == ['(()())', '()', '((()))', '()']
        assert candidate('( ) (( )) (( )( ))') == ['()', '(())', '(()())']
        assert candidate("()(())(((())))(((())))") == ['()', '(())', '(((())))', '(((())))']
        assert candidate("((()))(((())))((()))((()))") == ['((()))', '(((())))', '((()))', '((()))']
        assert candidate("(((())))(())(())(((())))") == ['(((())))', '(())', '(())', '(((())))']
        assert candidate("((()))()(()())((()))") == ['((()))', '()', '(()())', '((()))']
        assert candidate("()(((())))()(())") == ['()', '(((())))', '()', '(())']
        assert candidate("(())()(()())") == ['(())', '()', '(()())']
        assert candidate("()()()") == ['()', '()', '()']
        assert candidate("((()))(()())((()))()") == ['((()))', '(()())', '((()))', '()']
        assert candidate("((()))(()())()((())()())") == ['((()))', '(()())', '()', '((())()())']
        assert candidate("(()())(()())(()())") == ['(()())', '(()())', '(()())']
        assert candidate('(()(())((())))') == [
        '(()(())((())))'
    ]
        assert candidate("()(())()(())") == ['()', '(())', '()', '(())']
        assert candidate("(())()(())(((())))") == ['(())', '()', '(())', '(((())))']
        assert candidate("()((())()())((())()())()") == ['()', '((())()())', '((())()())', '()']
        assert candidate("()()(())((()))") == ['()', '()', '(())', '((()))']
        assert candidate("(())((()))((()))(((())))") == ['(())', '((()))', '((()))', '(((())))']
        assert candidate("((()))(())(())(())") == ['((()))', '(())', '(())', '(())']
        assert candidate("((()))()()((()))") == ['((()))', '()', '()', '((()))']
        assert candidate("(()())((()))((())()())(()())") == ['(()())', '((()))', '((())()())', '(()())']
        assert candidate("(())(())()()") == ['(())', '(())', '()', '()']
        assert candidate("(()(())((())))") == ['(()(())((())))']
        assert candidate("(((())))((()))(((())))((()))") == ['(((())))', '((()))', '(((())))', '((()))']
        assert candidate("()()(())") == ['()', '()', '(())']
        assert candidate("()(())(()())") == ['()', '(())', '(()())']
        assert candidate("(()())()(()())(()())") == ['(()())', '()', '(()())', '(()())']
        assert candidate("(()())()(())") == ['(()())', '()', '(())']
        assert candidate("((()))(())(())()") == ['((()))', '(())', '(())', '()']

if __name__ == '__main__':
    unittest.main()
