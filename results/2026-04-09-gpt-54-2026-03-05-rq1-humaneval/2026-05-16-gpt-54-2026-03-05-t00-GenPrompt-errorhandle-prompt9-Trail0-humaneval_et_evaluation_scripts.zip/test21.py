
import unittest

Here are several reasonable error-handling approaches, followed by a solid default implementation.

## Options for error handling

When rescaling to `[0, 1]`, the main failure case is when all values are equal, because then:

```python
max_val - min_val == 0
```

and division by zero would occur.

### 1. Raise a `ValueError` for invalid input
Best when you want strict behavior and bugs to be visible.

- Empty list
- Fewer than 2 elements
- All values identical

### 2. Return a fallback value
Best when you want the function to always return something.

Examples:
- Return all `0.0`
- Return all `0.5`
- Return a copy of the original list

### 3. Add a configurable policy parameter
Best when you want flexibility.

Example policies:
- `"raise"`
- `"zeros"`
- `"mid"`

---

## Completed code: strict version

```python
from typing import List


def rescale_to_unit(numbers: List[float]) -> List[float]:
    """Given list of numbers (of at least two elements), apply a linear transform
    to that list, such that the smallest number will become 0 and the largest
    will become 1.

    >>> rescale_to_unit([1.0, 2.0, 3.0, 4.0, 5.0])
    [0.0, 0.25, 0.5, 0.75, 1.0]
    """
    if len(numbers) < 2:
        raise ValueError("numbers must contain at least two elements")

    min_val = min(numbers)
    max_val = max(numbers)

    if min_val == max_val:
        raise ValueError("cannot rescale a list where all values are equal")

    scale = max_val - min_val
    return [(x - min_val) / scale for x in numbers]
```

---

## Alternative: tolerant version returning zeros

```python
from typing import List


def rescale_to_unit(numbers: List[float]) -> List[float]:
    """Given list of numbers (of at least two elements), apply a linear transform
    to that list, such that the smallest number will become 0 and the largest
    will become 1.

    >>> rescale_to_unit([1.0, 2.0, 3.0, 4.0, 5.0])
    [0.0, 0.25, 0.5, 0.75, 1.0]
    """
    if len(numbers) < 2:
        raise ValueError("numbers must contain at least two elements")

    min_val = min(numbers)
    max_val = max(numbers)

    if min_val == max_val:
        return [0.0 for _ in numbers]

    scale = max_val - min_val
    return [(x - min_val) / scale for x in numbers]
```

---

## Alternative: configurable policy

```python
from typing import List


def rescale_to_unit(numbers: List[float], on_constant: str = "raise") -> List[float]:
    """Rescale numbers so min becomes 0 and max becomes 1.

    on_constant:
        - "raise": raise ValueError if all values are equal
        - "zeros": return all 0.0
        - "mid": return all 0.5
    """
    if len(numbers) < 2:
        raise ValueError("numbers must contain at least two elements")

    min_val = min(numbers)
    max_val = max(numbers)

    if min_val == max_val:
        if on_constant == "raise":
            raise ValueError("cannot rescale a list where all values are equal")
        if on_constant == "zeros":
            return [0.0 for _ in numbers]
        if on_constant == "mid":
            return [0.5 for _ in numbers]
        raise ValueError(f"unknown on_constant policy: {on_constant}")

    scale = max_val - min_val
    return [(x - min_val) / scale for x in numbers]
```

If you want, I can also provide:
- a version with full type/value validation,
- doctests for edge cases,
- or a NumPy implementation.

class Test(unittest.TestCase):
    def test(self):
        assert candidate([99.9, 47.9]) == [1.0, 0.0]
        assert candidate([3.2, 51.8]) == [0.0, 1.0]
        assert candidate([100.7, 49.1]) == [1.0, 0.0]
        assert candidate([4.7, 51.3]) == [0.0, 1.0]
        assert candidate([2.8, 4.8, 4.5, 1.8, 1.7]) == [0.3548387096774194, 1.0, 0.903225806451613, 0.032258064516129066, 0.0]
        assert candidate([1.5, 1.4, 8.1, 4.2, 6.7]) == [0.014925373134328374, 0.0, 1.0, 0.4179104477611941, 0.7910447761194032]
        assert candidate([7.2, 8.7, 11.8, 16.6, 14.9]) == [0.0, 0.15957446808510625, 0.4893617021276595, 1.0, 0.8191489361702126]
        assert candidate([4.2, 54.2]) == [0.0, 1.0]
        assert candidate([15.4, 13.2, 13.8, 17.0, 17.9]) == [0.468085106382979, 0.0, 0.12765957446808543, 0.8085106382978726, 1.0]
        assert candidate([101.4, 46.5]) == [1.0, 0.0]
        assert candidate([5.0, 6.9, 8.3, 7.9, 6.9]) == [0.0, 0.5757575757575757, 1.0, 0.8787878787878787, 0.5757575757575757]
        assert candidate([104.6, 46.0]) == [1.0, 0.0]
        assert candidate([1.3, 46.5]) == [0.0, 1.0]
        assert candidate([1.2, 52.9]) == [0.0, 1.0]
        assert candidate([2.5, 54.9]) == [0.0, 1.0]
        assert candidate([4.2, 47.3]) == [0.0, 1.0]
        assert candidate([10.6, 9.8, 13.5, 15.4, 15.5]) == [0.14035087719298228, 0.0, 0.6491228070175438, 0.9824561403508772, 1.0]
        assert candidate([103.9, 51.6]) == [1.0, 0.0]
        assert candidate([10.3, 9.9, 18.2, 18.6, 15.0]) == [0.04597701149425291, 0.0, 0.9540229885057468, 1.0, 0.586206896551724]
        assert candidate([5.1, 5.6, 7.5, 4.7, 2.2]) == [0.5471698113207546, 0.6415094339622641, 1.0, 0.4716981132075472, 0.0]
        assert candidate([7.2, 49.3]) == [0.0, 1.0]
        assert candidate([99.6, 50.1]) == [1.0, 0.0]
        assert candidate([98.8, 50.6]) == [1.0, 0.0]
        assert candidate([13.5, 11.1, 16.3, 15.7, 14.2]) == [0.4615384615384615, 0.0, 1.0, 0.8846153846153844, 0.5961538461538459]
        assert candidate([11.4, 11.3, 14.4, 18.1, 9.6]) == [0.211764705882353, 0.2000000000000001, 0.5647058823529412, 1.0, 0.0]
        assert candidate([103.9, 44.1]) == [1.0, 0.0]
        assert candidate([12.0, 11.0, 15.0, 13.0, 14.0]) == [0.25, 0.0, 1.0, 0.5, 0.75]
        assert candidate([2.9, 1.1, 1.7, 7.1, 4.6]) == [0.3, 0.0, 0.09999999999999998, 1.0, 0.5833333333333333]
        assert candidate([6.5, 4.5, 8.2, 6.4, 10.1]) == [0.35714285714285715, 0.0, 0.6607142857142856, 0.33928571428571436, 1.0]
        assert candidate([4.5, 5.1, 8.1, 7.0, 8.3]) == [0.0, 0.15789473684210514, 0.9473684210526313, 0.6578947368421051, 1.0]
        assert candidate([4.9, 4.1, 7.1, 9.3, 10.0]) == [0.13559322033898316, 0.0, 0.5084745762711864, 0.8813559322033899, 1.0]
        assert candidate([2.6, 3.9, 10.6, 3.8, 9.3]) == [0.0, 0.16249999999999998, 1.0, 0.14999999999999997, 0.8375000000000001]
        assert candidate([98.3, 48.9]) == [1.0, 0.0]
        assert candidate([100.4, 49.3]) == [1.0, 0.0]
        assert candidate([2.9, 5.9, 10.7, 3.0, 3.1]) == [0.0, 0.38461538461538475, 1.0, 0.012820512820512834, 0.025641025641025668]
        assert candidate([7.5, 1.1, 2.9, 7.4, 5.1]) == [1.0, 0.0, 0.28124999999999994, 0.9843750000000001, 0.6249999999999999]
        assert candidate([6.3, 5.8, 7.5, 4.0, 9.7]) == [0.4035087719298246, 0.3157894736842105, 0.6140350877192983, 0.0, 1.0]
        assert candidate([95.7, 53.0]) == [1.0, 0.0]
        assert candidate([6.5, 2.9, 6.4, 6.8, 1.0]) == [0.9482758620689655, 0.3275862068965517, 0.9310344827586208, 1.0, 0.0]
        assert candidate([1.6, 3.4, 5.5, 9.4, 7.2]) == [0.0, 0.23076923076923073, 0.49999999999999994, 1.0, 0.7179487179487178]
        assert candidate([4.6, 5.9, 2.8, 5.2, 11.0]) == [0.21951219512195122, 0.378048780487805, 0.0, 0.2926829268292684, 1.0]
        assert candidate([6.2, 3.3, 2.1, 1.5, 5.7]) == [1.0, 0.38297872340425526, 0.12765957446808512, 0.0, 0.8936170212765957]
        assert candidate([16.2, 16.6, 16.6, 12.8, 18.2]) == [0.6296296296296295, 0.703703703703704, 0.703703703703704, 0.0, 1.0]
        assert candidate([100.4, 48.1]) == [1.0, 0.0]
        assert candidate([3.4, 7.5, 6.4, 5.1, 10.6]) == [0.0, 0.5694444444444444, 0.4166666666666668, 0.2361111111111111, 1.0]
        assert candidate([3.7, 1.2, 6.7, 3.4, 8.2]) == [0.3571428571428572, 0.0, 0.7857142857142858, 0.31428571428571433, 1.0]
        assert candidate([4.6, 4.5, 5.5, 2.4, 5.1]) == [0.7096774193548386, 0.6774193548387097, 1.0, 0.0, 0.8709677419354838]
        assert candidate([17.5, 17.0, 13.4, 10.5, 15.8]) == [1.0, 0.9285714285714286, 0.4142857142857143, 0.0, 0.7571428571428572]
        assert candidate([5.8, 6.5, 5.7, 1.4, 9.9]) == [0.5176470588235295, 0.6, 0.5058823529411766, 0.0, 1.0]
        assert candidate([7.1, 4.6, 6.9, 5.1, 4.6]) == [1.0, 0.0, 0.9200000000000003, 0.2, 0.0]
        assert candidate([6.2, 53.8]) == [0.0, 1.0]
        assert candidate([1.5, 44.9]) == [0.0, 1.0]
        assert candidate([11.6, 9.7, 12.4, 18.9, 9.4]) == [0.23157894736842102, 0.03157894736842095, 0.31578947368421056, 1.0, 0.0]
        assert candidate([1.3, 5.4, 1.8, 4.3, 8.7]) == [0.0, 0.5540540540540542, 0.06756756756756757, 0.40540540540540543, 1.0]
        assert candidate([5.7, 2.2, 4.7, 8.7, 7.8]) == [0.5384615384615385, 0.0, 0.3846153846153847, 1.0, 0.8615384615384616]
        assert candidate([1.6, 1.6, 4.7, 8.8, 6.6]) == [0.0, 0.0, 0.4305555555555555, 1.0, 0.6944444444444443]
        assert candidate([2.1, 51.4]) == [0.0, 1.0]
        assert candidate([2.0, 1.0, 5.0, 3.0, 4.0]) == [0.25, 0.0, 1.0, 0.5, 0.75]
        assert candidate([6.1, 50.2]) == [0.0, 1.0]
        assert candidate([97.0, 52.7]) == [1.0, 0.0]
        assert candidate([2.1, 3.9, 4.9, 8.0, 3.4]) == [0.0, 0.30508474576271183, 0.4745762711864407, 1.0, 0.22033898305084743]
        assert candidate([7.8, 52.2]) == [0.0, 1.0]
        assert candidate([5.9, 2.9, 8.4, 9.6, 6.9]) == [0.4477611940298509, 0.0, 0.8208955223880597, 1.0, 0.5970149253731344]
        assert candidate([2.0, 49.9]) == [0.0, 1.0]
        assert candidate([7.3, 7.5, 19.8, 18.8, 12.9]) == [0.0, 0.016000000000000014, 1.0, 0.92, 0.44800000000000006]
        assert candidate([5.0, 1.6, 9.0, 8.2, 7.2]) == [0.45945945945945943, 0.0, 1.0, 0.8918918918918918, 0.7567567567567567]
        assert candidate([3.5, 2.8, 8.2, 9.8, 6.8]) == [0.10000000000000002, 0.0, 0.7714285714285712, 1.0, 0.5714285714285714]
        assert candidate([8.0, 9.3, 17.1, 18.5, 10.5]) == [0.0, 0.12380952380952388, 0.8666666666666668, 1.0, 0.23809523809523808]
        assert candidate([6.6, 1.6, 1.3, 6.9, 2.3]) == [0.9464285714285713, 0.053571428571428575, 0.0, 1.0, 0.17857142857142852]
        assert candidate([7.4, 45.9]) == [0.0, 1.0]
        assert candidate([4.3, 2.5, 1.2, 4.0, 8.5]) == [0.4246575342465753, 0.17808219178082194, 0.0, 0.3835616438356164, 1.0]
        assert candidate([7.9, 50.7]) == [0.0, 1.0]
        assert candidate([4.9, 46.2]) == [0.0, 1.0]
        assert candidate([4.4, 2.6, 2.1, 7.0, 2.4]) == [0.46938775510204084, 0.1020408163265306, 0.0, 1.0, 0.061224489795918324]
        assert candidate([14.6, 6.7, 19.2, 13.8, 13.5]) == [0.632, 0.0, 1.0, 0.5680000000000001, 0.544]
        assert candidate([95.6, 46.0]) == [1.0, 0.0]
        assert candidate([2.5, 5.5, 10.2, 3.9, 4.4]) == [0.0, 0.38961038961038963, 1.0, 0.18181818181818182, 0.24675324675324684]
        assert candidate([12.4, 8.1, 15.5, 14.4, 15.1]) == [0.5810810810810811, 0.0, 1.0, 0.8513513513513514, 0.9459459459459459]
        assert candidate([105.5, 53.2]) == [1.0, 0.0]
        assert candidate([102.1, 48.9]) == [1.0, 0.0]
        assert candidate([6.1, 6.1, 8.0, 6.4, 8.7]) == [0.0, 0.0, 0.7307692307692311, 0.11538461538461567, 1.0]
        assert candidate([100.0, 49.9]) == [1.0, 0.0]
        assert candidate([12.2, 12.9, 12.4, 11.6, 16.9]) == [0.11320754716981128, 0.24528301886792472, 0.15094339622641526, 0.0, 1.0]
        assert candidate([10.9, 13.2, 20.2, 11.2, 11.2]) == [0.0, 0.24731182795698917, 1.0, 0.03225806451612892, 0.03225806451612892]
        assert candidate([96.2, 53.9]) == [1.0, 0.0]
        assert candidate([95.4, 48.0]) == [1.0, 0.0]
        assert candidate([5.7, 44.3]) == [0.0, 1.0]
        assert candidate([102.0, 48.9]) == [1.0, 0.0]
        assert candidate([2.4, 51.4]) == [0.0, 1.0]
        assert candidate([16.1, 13.0, 15.9, 9.1, 15.3]) == [1.0, 0.557142857142857, 0.9714285714285713, 0.0, 0.8857142857142857]
        assert candidate([2.5, 2.1, 4.3, 7.7, 9.7]) == [0.05263157894736841, 0.0, 0.28947368421052627, 0.7368421052631579, 1.0]
        assert candidate([1.0, 48.4]) == [0.0, 1.0]
        assert candidate([7.6, 6.9, 7.0, 2.7, 4.9]) == [1.0, 0.8571428571428573, 0.8775510204081634, 0.0, 0.4489795918367348]
        assert candidate([5.5, 5.6, 3.1, 8.0, 9.4]) == [0.3809523809523809, 0.3968253968253967, 0.0, 0.7777777777777778, 1.0]
        assert candidate([2.4, 3.2, 3.7, 8.2, 1.1]) == [0.18309859154929575, 0.295774647887324, 0.36619718309859156, 1.0, 0.0]
        assert candidate([7.3, 1.5, 9.5, 4.6, 1.2]) == [0.7349397590361445, 0.03614457831325302, 1.0, 0.40963855421686735, 0.0]
        assert candidate([105.8, 45.9]) == [1.0, 0.0]
        assert candidate([9.7, 7.6, 13.7, 8.1, 10.3]) == [0.34426229508196715, 0.0, 1.0, 0.0819672131147541, 0.44262295081967235]
        assert candidate([15.7, 12.5, 16.1, 8.7, 9.6]) == [0.9459459459459457, 0.5135135135135135, 1.0, 0.0, 0.12162162162162163]
        assert candidate([10.1, 14.1, 14.5, 9.1, 9.5]) == [0.18518518518518517, 0.9259259259259258, 1.0, 0.0, 0.07407407407407414]
        assert candidate([1.0, 2.0, 3.0, 4.0, 5.0]) == [0.0, 0.25, 0.5, 0.75, 1.0]
        assert candidate([6.7, 47.3]) == [0.0, 1.0]
        assert candidate([5.9, 4.4, 1.4, 3.4, 2.8]) == [1.0, 0.6666666666666667, 0.0, 0.4444444444444444, 0.3111111111111111]
        assert candidate([3.1, 6.8, 5.3, 5.4, 5.5]) == [0.0, 1.0, 0.5945945945945945, 0.6216216216216217, 0.6486486486486487]
        assert candidate([4.1, 51.2]) == [0.0, 1.0]
        assert candidate([5.0, 3.8, 8.2, 3.9, 1.1]) == [0.5492957746478874, 0.38028169014084506, 1.0, 0.39436619718309857, 0.0]
        assert candidate([1.9, 4.8, 3.2, 4.3, 1.4]) == [0.14705882352941177, 1.0, 0.5294117647058825, 0.8529411764705882, 0.0]
        assert candidate([10.1, 12.6, 10.2, 16.8, 11.1]) == [0.0, 0.3731343283582089, 0.014925373134328302, 1.0, 0.14925373134328357]
        assert candidate([4.6, 5.7, 10.7, 5.4, 4.4]) == [0.03174603174603164, 0.20634920634920637, 1.0, 0.15873015873015875, 0.0]
        assert candidate([7.0, 52.8]) == [0.0, 1.0]
        assert candidate([98.1, 46.8]) == [1.0, 0.0]
        assert candidate([4.4, 50.9]) == [0.0, 1.0]
        assert candidate([5.5, 46.2]) == [0.0, 1.0]
        assert candidate([3.2, 2.1, 1.6, 6.4, 3.7]) == [0.3333333333333333, 0.10416666666666666, 0.0, 1.0, 0.43749999999999994]
        assert candidate([7.0, 51.8]) == [0.0, 1.0]
        assert candidate([102.9, 44.8]) == [1.0, 0.0]
        assert candidate([3.3, 4.4, 8.8, 2.9, 1.7]) == [0.22535211267605632, 0.38028169014084506, 1.0, 0.16901408450704222, 0.0]
        assert candidate([17.6, 14.9, 12.4, 9.6, 14.2]) == [1.0, 0.6625, 0.35000000000000003, 0.0, 0.5749999999999998]
        assert candidate([102.4, 46.0]) == [1.0, 0.0]
        assert candidate([12.3, 14.5, 18.1, 18.3, 10.4]) == [0.24050632911392408, 0.5189873417721518, 0.9746835443037976, 1.0, 0.0]
        assert candidate([105.8, 45.3]) == [1.0, 0.0]
        assert candidate([5.4, 1.8, 4.4, 7.7, 2.8]) == [0.6101694915254238, 0.0, 0.44067796610169496, 1.0, 0.16949152542372878]
        assert candidate([3.7, 3.9, 1.2, 4.6, 7.1]) == [0.42372881355932207, 0.45762711864406785, 0.0, 0.5762711864406779, 1.0]
        assert candidate([9.7, 13.8, 18.7, 15.3, 14.7]) == [0.0, 0.4555555555555557, 1.0, 0.6222222222222223, 0.5555555555555556]
        assert candidate([17.6, 8.7, 12.8, 9.2, 17.0]) == [1.0, 0.0, 0.46067415730337086, 0.05617977528089886, 0.9325842696629212]
        assert candidate([2.5, 4.4, 8.0, 3.4, 10.2]) == [0.0, 0.24675324675324684, 0.7142857142857143, 0.11688311688311688, 1.0]
        assert candidate([2.3, 3.4, 7.0, 6.8, 4.4]) == [0.0, 0.23404255319148937, 1.0, 0.9574468085106382, 0.44680851063829796]
        assert candidate([4.3, 4.4, 6.1, 8.4, 1.2]) == [0.43055555555555547, 0.4444444444444445, 0.6805555555555555, 1.0, 0.0]
        assert candidate([7.3, 7.4, 16.1, 10.7, 18.0]) == [0.0, 0.009345794392523414, 0.8224299065420562, 0.3177570093457944, 1.0]
        assert candidate([102.3, 47.4]) == [1.0, 0.0]

if __name__ == '__main__':
    unittest.main()
