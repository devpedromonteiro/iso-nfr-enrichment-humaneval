
import unittest



def encode_cyclic(s: str):
    """
    returns encoded string by cycling groups of three characters.
    """
    # split string to groups. Each of length 3.
    groups = [s[(3 * i):min((3 * i + 3), len(s))] for i in range((len(s) + 2) // 3)]
    # cycle elements in each group. Unless group has fewer elements than 3.
    groups = [(group[1:] + group[0]) if len(group) == 3 else group for group in groups]
    return "".join(groups)


def decode_cyclic(s: str):
    """
    takes as input string encoded with encode_cyclic function. Returns decoded string.
    """
    # split string into groups of length 3
    groups = [s[(3 * i):min((3 * i + 3), len(s))] for i in range((len(s) + 2) // 3)]
    # reverse the cycle: last character moves to the front
    groups = [(group[-1] + group[:-1]) if len(group) == 3 else group for group in groups]
    return "".join(groups)
candidate = decode_cyclic


class Test(unittest.TestCase):
    def test(self):
        assert candidate("e=!@/xqg_^") == '!e=x@/_qg^'
        assert candidate("*mdhj^t+u_i") == 'd*m^hjut+_i'
        assert candidate("<pn?i*^") == 'n<p*?i^'
        assert candidate("&myrcmbmc~cl?*-") == 'y&mmrccbml~c-?*'
        assert candidate("<=*|$+gs%??pho") == '*<=+|$%gsp??ho'
        assert candidate("=thcxyop#") == 'h=tycx#op'
        assert candidate("/ljlot") == 'j/ltlo'
        assert candidate("w_#|_+") == '#w_+|_'
        assert candidate("p=^ear<") == '^p=rea<'
        assert candidate("+k#hl>/k$egnmh:") == '#+k>hl$/kneg:mh'
        assert candidate(">s>e#mhzx~=t") == '>>sme#xhzt~='
        assert candidate("ljj|uur") == 'jlju|ur'
        assert candidate("q$b~^$k&yicp-j!") == 'bq$$~^yk&pic!-j'
        assert candidate("bf$pkl") == '$bflpk'
        assert candidate("l#$tls&ku$") == '$l#stlu&k$'
        assert candidate("dx/h_qg<@_") == '/dxqh_@g<_'
        assert candidate("+e%+?h/y+j!n=g") == '%+eh+?+/ynj!=g'
        assert candidate("m-_e@g~$") == '_m-ge@~$'
        assert candidate("*i*j++#!h||xf->") == '**i+j+h#!x||>f-'
        assert candidate("d->:gb") == '>d-b:g'
        assert candidate("rhcdj%?") == 'crh%dj?'
        assert candidate("??_o#v@~@") == '_??vo#@@~'
        assert candidate("ec-cq<") == '-ec<cq'
        assert candidate("uiy&eph_vfj&zx") == 'yuip&evh_&fjzx'
        assert candidate("/p=^h@igqk^p$") == '=/p@^hqigpk^$'
        assert candidate("n>:!t$=-:s") == ':n>$!t:=-s'
        assert candidate("*@k$^o^!ec%e?-") == 'k*@o$^e^!ec%?-'
        assert candidate("jn&ez/k") == '&jn/ezk'
        assert candidate("ngic<+ev") == 'ing+c<ev'
        assert candidate("d<dhnl%tw?nh!c") == 'dd<lhnw%th?n!c'
        assert candidate("~zmcryla") == 'm~zycrla'
        assert candidate("v#^xr<azpfg") == '^v#<xrpazfg'
        assert candidate("b-lv^xz") == 'lb-xv^z'
        assert candidate("~v:|!$nk|b!") == ':~v$|!|nkb!'
        assert candidate("/chcd>pnpinprx") == 'h/c>cdppnpinrx'
        assert candidate("r*ah!t+>") == 'ar*th!+>'
        assert candidate("b!>+w!") == '>b!!+w'
        assert candidate("phk&!n|z") == 'kphn&!|z'
        assert candidate("|kikdr>") == 'i|krkd>'
        assert candidate("@tl:!j") == 'l@tj:!'
        assert candidate("%dpwenpl%~pu") == 'p%dnwe%plu~p'
        assert candidate("b~+!wjd") == '+b~j!wd'
        assert candidate("xh!_eujzv-&jxn") == '!xhu_evjzj-&xn'
        assert candidate("g&tf<^:fgj^!$am") == 'tg&^f<g:f!j^m$a'
        assert candidate("!-&xw~qyf>fp") == '&!-~xwfqyp>f'
        assert candidate(":pku_n#^") == 'k:pnu_#^'
        assert candidate("|@&*-q:") == '&|@q*-:'
        assert candidate("axxatp?/") == 'xaxpat?/'
        assert candidate("~jz<w+/cc@vxv") == 'z~j+<wc/cx@vv'
        assert candidate("$-$j/~c+&?d") == '$$-~j/&c+?d'
        assert candidate("|imyyy~g@^>pn") == 'm|iyyy@~gp^>n'
        assert candidate("k^%!|#") == '%k^#!|'
        assert candidate("a~>!-=zka$gil") == '>a~=!-azki$gl'
        assert candidate("#:$qqm=uppm") == '$#:mqqp=upm'
        assert candidate("#-ituqcsms?_qiy") == 'i#-qtumcs_s?yqi'
        assert candidate("pjltpcvzfkm:o") == 'lpjctpfvz:kmo'
        assert candidate("dm>lo&b") == '>dm&lob'
        assert candidate("n+hubb<") == 'hn+bub<'
        assert candidate("*~|bcx") == '|*~xbc'
        assert candidate("p&ect?/g") == 'ep&?ct/g'
        assert candidate("<fcvg^u@hgo%") == 'c<f^vghu@%go'
        assert candidate("-yf+y>l!z") == 'f-y>+yzl!'
        assert candidate("y-=x@>sb%") == '=y->x@%sb'
        assert candidate("<nebaz$qya=a_e") == 'e<nzbay$qaa=_e'
        assert candidate("^bd|&kh/e_?c") == 'd^bk|&eh/c_?'
        assert candidate("ol|vg<i^rlsh&f+") == '|ol<vgri^hls+&f'
        assert candidate("muku$t*=s") == 'kmutu$s*='
        assert candidate("u>$c~!m/^>!?pt~") == '$u>!c~^m/?>!~pt'
        assert candidate("*ayg++*dilv") == 'y*a+g+i*dlv'
        assert candidate("dmd_t?r_j-") == 'ddm?_tjr_-'
        assert candidate("i>aj?#$ri^h") == 'ai>#j?i$r^h'
        assert candidate("ycchfx") == 'cycxhf'
        assert candidate("~ovm|/#yzdr~f") == 'v~o/m|z#y~drf'
        assert candidate("$fv?>_~!h") == 'v$f_?>h~!'
        assert candidate("$qm~r?m^+^:m/p") == 'm$q?~r+m^m^:/p'
        assert candidate("+ywja:") == 'w+y:ja'
        assert candidate("uc^=hbemg") == '^ucb=hgem'
        assert candidate("?dvam-p$zv-tmd") == 'v?d-amzp$tv-md'
        assert candidate("+z^nl>fz_f") == '^+z>nl_fzf'
        assert candidate("y_@ak|c") == '@y_|akc'
        assert candidate("$lf/t@>&k") == 'f$l@/tk>&'
        assert candidate("l$g!bdrnc") == 'gl$d!bcrn'
        assert candidate("e$zmg#j*=v") == 'ze$#mg=j*v'
        assert candidate("||y<jf") == 'y||f<j'
        assert candidate(encoded_str) == str
        assert candidate("$$?ax#") == '?$$#ax'
        assert candidate("-:sanz") == 's-:zan'
        assert candidate("mi@usigtd%x") == '@miiusdgt%x'
        assert candidate(">#*s@f=j_k>ire") == '*>#fs@_=jik>re'
        assert candidate("tdalx=md") == 'atd=lxmd'
        assert candidate("z|~=#|") == '~z||=#'
        assert candidate("i>r^ene!ubcn") == 'ri>n^eue!nbc'
        assert candidate("~cqrk~x") == 'q~c~rkx'
        assert candidate("!fmfl:_") == 'm!f:fl_'
        assert candidate("?nu>#~bcc!:^") == 'u?n~>#cbc^!:'
        assert candidate("=alvmae#nmr") == 'l=aavmne#mr'
        assert candidate("l^ak_h") == 'al^hk_'
        assert candidate("l$|c@+&d>gz") == '|l$+c@>&dgz'
        assert candidate("*z/l^<=~y-dl") == '/*z<l^y=~l-d'
        assert candidate("p:dzowrxed-wl") == 'dp:wzoerxwd-l'
        assert candidate("#sm~vk|~fb") == 'm#sk~vf|~b'
        assert candidate("miznaoboo=ldsm") == 'zmionaobod=lsm'
        assert candidate("u|>xx:") == '>u|:xx'
        assert candidate("b|||fph_aprt") == '|b|p|fah_tpr'
        assert candidate("ev$/kd") == '$evd/k'
        assert candidate("e-gjag") == 'ge-gja'
        assert candidate("hrzgrwh$seba") == 'zhrwgrsh$aeb'
        assert candidate("j-yr^u") == 'yj-ur^'
        assert candidate("@=#rh?") == '#@=?rh'
        assert candidate("=cc-_?k^hfue") == 'c=c?-_hk^efu'
        assert candidate("=~k+vk^xmac") == 'k=~k+vm^xac'
        assert candidate("_><<kyjizz&") == '<_>y<kzjiz&'
        assert candidate("jn%@h+ot~q") == '%jn+@h~otq'
        assert candidate("*mou|t") == 'o*mtu|'
        assert candidate("w*+$%&o@~_or") == '+w*&$%~o@r_o'
        assert candidate("d=hudylp@?$n^^") == 'hd=yud@lpn?$^^'
        assert candidate("&eq=g#slc") == 'q&e#=gcsl'
        assert candidate("ha:c_+/#") == ':ha+c_/#'
        assert candidate("?:*~v~m>j") == '*?:~~vjm>'
        assert candidate("*|xw+>u_/?%") == 'x*|>w+/u_?%'
        assert candidate("doja$~??|&@t=") == 'jdo~a$|??t&@='
        assert candidate("xq=x$xf>") == '=xqxx$f>'
        assert candidate("q%##j*@e|-") == '#q%*#j|@e-'
        assert candidate("o*@qv-o+@nxyi") == '@o*-qv@o+ynxi'
        assert candidate("k>rz~s:ti") == 'rk>sz~i:t'
        assert candidate("jyozepoq-^az-&") == 'ojypze-oqz^a-&'

if __name__ == '__main__':
    unittest.main()
