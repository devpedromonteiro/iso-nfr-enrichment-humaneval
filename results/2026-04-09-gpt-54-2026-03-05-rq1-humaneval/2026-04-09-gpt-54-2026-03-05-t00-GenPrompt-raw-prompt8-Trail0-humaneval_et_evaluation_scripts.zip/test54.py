
import unittest



def same_chars(s0: str, s1: str):
    return set(s0) == set(s1)
candidate = same_chars


class Test(unittest.TestCase):
    def test(self):
        assert candidate('objfowzejfy', 'zeyzjobfowf') == True
        assert candidate('ubmrmlku', 'qisfiyequyz') == False
        assert candidate('ezudntyre', 'tvekvih') == False
        assert candidate('mrwkutmyimvf', 'iyrrmwkutvf') == True
        assert candidate('xjzpzvu', 'jxzpzvu') == True
        assert candidate('hbmm', 'hbmm') == True
        assert candidate('xmu', 'lvaqgoq') == False
        assert candidate('jput', 'mgvpck') == False
        assert candidate('oiqwnpdn', 'nsfujbetfyqubb') == False
        assert candidate('wvijnfvsq', 'inqvwjfs') == True
        assert candidate('dzjidxnvqgprdas', 'nqpprszvrzdjidxgda') == True
        assert candidate('kgqzyjnppwyzz', 'jpqqwngkzyyzz') == True
        assert candidate('uuxmctsf', 'ctumxsf') == True
        assert candidate('oky', 'nxwjwdmai') == False
        assert candidate('eabcdzzzz', 'dddzzzzzzzddddabc') == False
        assert candidate('vbsda', 'vabsd') == True
        assert candidate('sucbrppr', 'uggaytm') == False
        assert candidate('dbjwutowyvfdzu', 'ufcqvtqabnms') == False
        assert candidate('ddc', 'vumzpxsuaq') == False
        assert candidate('fhlmoajh', 'amfmqyxhgqr') == False
        assert candidate('put', 'qvciesjqbjxbk') == False
        assert candidate('dxtashvfjcxb', 'otazlddlhvewgc') == False
        assert candidate('eabcd', 'dddddddabc') == False
        assert candidate('pdickiiulerel', 'lczixuiwviocdignf') == False
        assert candidate('nsaqoelkjjkft', 'hmssntqlnezswkwpqiea') == False
        assert candidate('xndwjc', 'ndwxjc') == True
        assert candidate('nwmkkmpwjffude', 'nrnlispwgrwdos') == False
        assert candidate('cxzlswtvqg', 'xltwlxczsvqg') == True
        assert candidate('jbwdcvpoe', 'yhbgmdndzysquk') == False
        assert candidate('laifarc', 'quecnzwhrey') == False
        assert candidate('lsapqihofckb', 'fizrmzvjawlrumutonko') == False
        assert candidate('ylhtkwiy', 'yonkssjirviojkw') == False
        assert candidate('zcdi', 'cddzi') == True
        assert candidate('tbaxttbhlbtrwb', 'obcntywrzsmrfxge') == False
        assert candidate('ujje', 'tzdfdqu') == False
        assert candidate('hkfbz', 'zbfkh') == True
        assert candidate('lgyakhzvq', 'lvkakgllkgzlyzhq') == True
        assert candidate('yfbqkhoz', 'qbqhkkyfoz') == True
        assert candidate('hrrkrko', 'aukesht') == False
        assert candidate('ivoqjjcm', 'dojhevu') == False
        assert candidate('ktfjsyppbmors', 'jmrbfktsyppos') == True
        assert candidate('xbxz', 'bxz') == True
        assert candidate('jjjsnsz', 'snszj') == True
        assert candidate('daif', 'dffadi') == True
        assert candidate('gdmuhl', 'ghguldm') == True
        assert candidate('oooohiu', 'hiou') == True
        assert candidate('vyryrgltlsnfog', 'knphpotnilhbmhos') == False
        assert candidate('uti', 'uti') == True
        assert candidate('nae', 'willsvpshq') == False
        assert candidate('npp', 'cgtmavc') == False
        assert candidate('gljb', 'hqxweu') == False
        assert candidate('clvgq', 'lcvgq') == True
        assert candidate('illiunrngq', 'iunrnglq') == True
        assert candidate('eabcdzzzz', 'dddzzzzzzzddeddabc') == True
        assert candidate('kcbldngoxuv', 'cxbnnkoldguv') == True
        assert candidate('fid', 'fid') == True
        assert candidate('gza', 'gza') == True
        assert candidate('lqd', 'qmrsufhqso') == False
        assert candidate('yxtbgbkgvh', 'mmimzdektqoqtauqh') == False
        assert candidate('ntats', 'iamlgysuaabd') == False
        assert candidate('dddddddabc', 'abcd') == True
        assert candidate('aabb', 'aaccc') == False
        assert candidate('kqy', 'qqky') == True
        assert candidate('fggnnke', 'lhzpjthuecrwqj') == False
        assert candidate('xenuwtr', 'eqrkulyscs') == False
        assert candidate('iighzaehkhgcjex', 'kaohxylcpsoxxyrgqk') == False
        assert candidate('ucs', 'wsqgneblssg') == False
        assert candidate('hlhxby', 'yyhlhxb') == True
        assert candidate('kzbcxkca', 'zbxkckca') == True
        assert candidate('fpdwncxj', 'nxwnwwfpdcj') == True
        assert candidate('zkumyf', 'zkumyf') == True
        assert candidate('nyipkgvakv', 'vivnypkgak') == True
        assert candidate('orookv', 'hhaksalivzdzqfv') == False
        assert candidate('mleynuyyzswdzuv', 'vsdpbrorcqhcxghx') == False
        assert candidate('imshdpt', 'imshdpt') == True
        assert candidate('fsoasomzjty', 'zqhqdjmdtvunortpstin') == False
        assert candidate('cmnwjzbf', 'njmcwzbf') == True
        assert candidate('cwhns', 'wchnsc') == True
        assert candidate('wjkdijiow', 'wjdgzgw') == False
        assert candidate('yamsl', 'lmmyas') == True
        assert candidate('uvpu', 'uvpu') == True
        assert candidate('gbjzigq', 'qbjgzig') == True
        assert candidate('yth', 'htyy') == True
        assert candidate('jlxrnn', 'jxlrnn') == True
        assert candidate('dbgolwoy', 'afxzfgevecwdq') == False
        assert candidate('uuqewquic', 'qnzobuucujmobey') == False
        assert candidate('srlcva', 'lzmfagkvjnw') == False
        assert candidate('ixov', 'efpthcoryaoq') == False
        assert candidate('ylszs', 'lsyzys') == True
        assert candidate('ccuevv', 'ccuevv') == True
        assert candidate('qdeeaakqxegnj', 'qgdgjqeeaakxen') == True
        assert candidate('jvibe', 'xkjjfl') == False
        assert candidate('ffz', 'fz') == True
        assert candidate('ptpbpncav', 'pncatvb') == True
        assert candidate('iqka', 'iaqk') == True
        assert candidate('dodzqbqyrpkrus', 'brpskkkkrdodzqqyu') == True
        assert candidate('drznfnua', 'zrdnfnua') == True
        assert candidate('vwsbqhxhwdq', 'hfmzapuebmvvnzvf') == False
        assert candidate('tichmefdn', 'ecjogfwtfzmfnq') == False
        assert candidate('wmoaeu', 'oawmeu') == True
        assert candidate('devmt', 'qwiacgkmpuzfyxp') == False
        assert candidate('oabilyaa', 'hhadrtqyjgdezegoqhm') == False
        assert candidate('tuzhjcbpm', 'ynhrdqj') == False
        assert candidate('abazidbs', 'idsdabazb') == True
        assert candidate('qsvdcvudj', 'kouhdudxblhflg') == False
        assert candidate('wiqkmvl', 'xvoiramplmruwo') == False
        assert candidate('abcd', 'dddddddabcf') == False
        assert candidate('zyouqspqruthlr', 'qurqzruoyspthl') == True
        assert candidate('zfouccu', 'ifcfxz') == False
        assert candidate('abcd', 'dddddddabc') == True
        assert candidate('zhsudj', 'usuquf') == False
        assert candidate('vvwfvxwkghkqima', 'hfkxhivagwwqm') == True
        assert candidate('pejerlhu', 'npztfomldg') == False
        assert candidate('mlgtx', 'fijypmzey') == False
        assert candidate('hvrwgpvcnj', 'wnnrhvgpvcj') == True

if __name__ == '__main__':
    unittest.main()
