
import unittest
import re
import sys
import math
import copy


def special_factorial(n):
    result = 1
    factorial = 1

    for i in range(1, n + 1):
        factorial *= i
        result *= factorial

    return result
candidate = special_factorial


def check(candidate):

    # Check some simple cases
    assert candidate(4) == 288, "Test 4"
    assert candidate(5) == 34560, "Test 5"
    assert candidate(7) == 125411328000, "Test 7"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1) == 1, "Test 1"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
