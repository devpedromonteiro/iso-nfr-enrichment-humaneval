
import unittest
import re
import sys
import math
import copy


def get_odd_collatz(n):
    """
    Given a positive integer n, return a sorted list of the odd numbers
    in its Collatz sequence.

    Example:
    get_odd_collatz(5) -> [1, 5]
    """
    odds = []

    while True:
        if n % 2 == 1:
            odds.append(n)

        if n == 1:
            break

        if n % 2 == 0:
            n //= 2
        else:
            n = 3 * n + 1

    return sorted(odds)
candidate = get_odd_collatz


def check(candidate):

    # Check some simple cases
    assert candidate(14) == [1, 5, 7, 11, 13, 17]
    assert candidate(5) == [1, 5]
    assert candidate(12) == [1, 3, 5], "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1) == [1], "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
