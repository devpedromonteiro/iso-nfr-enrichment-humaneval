
import unittest
import re
import sys
import math
import copy


def encode(message):
    vowels = {'a', 'e', 'i', 'o', 'u'}
    result = []

    for ch in message:
        if ch.lower() in vowels:
            new_char = chr(ord(ch.lower()) + 2)
            ch = new_char.upper() if ch.isupper() else new_char
        else:
            ch = ch.swapcase()
        result.append(ch)

    return ''.join(result)
candidate = encode


def check(candidate):

    # Check some simple cases
    assert candidate('TEST') == 'tgst', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('Mudasir') == 'mWDCSKR', "This prints if this assert fails 2 (good for debugging!)"
    assert candidate('YES') == 'ygs', "This prints if this assert fails 3 (good for debugging!)"
    
    # Check some edge cases that are easy to work out by hand.
    assert candidate('This is a message') == 'tHKS KS C MGSSCGG', "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate("I DoNt KnOw WhAt tO WrItE") == 'k dQnT kNqW wHcT Tq wRkTg', "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
