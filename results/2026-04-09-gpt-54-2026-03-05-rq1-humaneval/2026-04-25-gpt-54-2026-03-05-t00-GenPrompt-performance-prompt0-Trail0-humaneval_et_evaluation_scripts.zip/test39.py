
import unittest



def prime_fib(n: int):
    """
    prime_fib returns n-th number that is a Fibonacci number and it's also prime.
    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """
    if n < 1:
        raise ValueError("n must be a positive integer")

    def is_prime(x: int) -> bool:
        if x < 2:
            return False
        if x in (2, 3):
            return True
        if x % 2 == 0 or x % 3 == 0:
            return False
        i = 5
        while i * i <= x:
            if x % i == 0 or x % (i + 2) == 0:
                return False
            i += 6
        return True

    # All prime Fibonacci numbers occur at prime indices,
    # except for F(4) = 3. We use that to skip most Fibonacci numbers.
    if n == 1:
        return 2  # F(3)
    if n == 2:
        return 3  # F(4)

    def fib_fast_doubling(k: int) -> tuple[int, int]:
        # Returns (F(k), F(k+1))
        if k == 0:
            return 0, 1
        a, b = fib_fast_doubling(k >> 1)
        c = a * ((b << 1) - a)
        d = a * a + b * b
        if k & 1:
            return d, c + d
        return c, d

    def prime_generator():
        yield 3
        yield 5
        primes = [3, 5]
        candidate = 7
        step = 4
        while True:
            is_p = True
            limit = int(candidate**0.5)
            for p in primes:
                if p > limit:
                    break
                if candidate % p == 0:
                    is_p = False
                    break
            if is_p:
                primes.append(candidate)
                yield candidate
            candidate += step
            step = 6 - step  # alternate 4, 2 => numbers of form 6k Â± 1

    count = 2  # already counted 2 and 3
    for idx in prime_generator():
        f, _ = fib_fast_doubling(idx)
        if is_prime(f):
            count += 1
            if count == n:
                return f
candidate = prime_fib


class Test(unittest.TestCase):
    def test(self):
        assert candidate(2) == 3
        assert candidate(12) == 99194853094755497
        assert candidate(6) == 233
        assert candidate(10) == 433494437
        assert candidate(3) == 5
        assert candidate(5) == 89
        assert candidate(8) == 28657
        assert candidate(11) == 2971215073
        assert candidate(1) == 2
        assert candidate(4) == 13
        assert candidate(9) == 514229
        assert candidate(7) == 1597

if __name__ == '__main__':
    unittest.main()
