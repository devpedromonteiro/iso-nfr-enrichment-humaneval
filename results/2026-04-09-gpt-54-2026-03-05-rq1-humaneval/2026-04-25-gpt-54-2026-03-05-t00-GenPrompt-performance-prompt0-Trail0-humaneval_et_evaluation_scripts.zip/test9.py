
import unittest

from typing import List, Tuple


from typing import List


def rolling_max(numbers: List[int]) -> List[int]:
    """From a given list of integers, generate a list of the rolling maximum
    element found up to each position in the sequence.

    >>> rolling_max([1, 2, 3, 2, 3, 4, 2])
    [1, 2, 3, 3, 3, 4, 4]
    """
    if not numbers:
        return []

    result = [0] * len(numbers)
    current_max = numbers[0]
    result[0] = current_max

    for i in range(1, len(numbers)):
        if numbers[i] > current_max:
            current_max = numbers[i]
        result[i] = current_max

    return result
candidate = rolling_max


class Test(unittest.TestCase):
    def test(self):
        assert candidate([1, 6, 7, 2]) == [1, 6, 7, 7]
        assert candidate([2, 7, 1, 1]) == [2, 7, 7, 7]
        assert candidate([2, 1, 2, 3]) == [2, 2, 2, 3]
        assert candidate([3, 2, 7, 4]) == [3, 3, 7, 7]
        assert candidate([1, 6, 3, 105, 7]) == [1, 6, 6, 105, 105]
        assert candidate([4, 4, 3, 103, 2]) == [4, 4, 4, 103, 103]
        assert candidate([5, 1, 4, 2]) == [5, 5, 5, 5]
        assert candidate([1, 6, 8, 5]) == [1, 6, 8, 8]
        assert candidate([8, 1, 4, 1]) == [8, 8, 8, 8]
        assert candidate([4, 7, 7, 5]) == [4, 7, 7, 7]
        assert candidate([3, 7, 7, 2]) == [3, 7, 7, 7]
        assert candidate([8, 2, 4, 100, 7]) == [8, 8, 8, 100, 100]
        assert candidate([2, 2, 5, 105, 2]) == [2, 2, 5, 105, 105]
        assert candidate([4, 1, 7, 101, 4]) == [4, 4, 7, 101, 101]
        assert candidate([6, 5, 4, 2]) == [6, 6, 6, 6]
        assert candidate([8, 5, 3, 95, 2]) == [8, 8, 8, 95, 95]
        assert candidate([3, 6, 2, 3]) == [3, 6, 6, 6]
        assert candidate([7, 4, 2, 103, 2]) == [7, 7, 7, 103, 103]
        assert candidate([1, 1, 1, 98, 4]) == [1, 1, 1, 98, 98]
        assert candidate([7, 7, 1, 105, 6]) == [7, 7, 7, 105, 105]
        assert candidate([4, 5, 7, 3]) == [4, 5, 7, 7]
        assert candidate([2, 2, 7, 5]) == [2, 2, 7, 7]
        assert candidate([5, 3, 2, 5]) == [5, 5, 5, 5]
        assert candidate([2, 4, 3, 102, 6]) == [2, 4, 4, 102, 102]
        assert candidate([5, 4, 5, 98, 2]) == [5, 5, 5, 98, 98]
        assert candidate([3, 2, 3, 1]) == [3, 3, 3, 3]
        assert candidate([7, 3, 6, 96, 1]) == [7, 7, 7, 96, 96]
        assert candidate([2, 7, 3, 7]) == [2, 7, 7, 7]
        assert candidate([7, 2, 2, 105, 8]) == [7, 7, 7, 105, 105]
        assert candidate([1, 4, 8, 100, 8]) == [1, 4, 8, 100, 100]
        assert candidate([9, 8, 4, 6]) == [9, 9, 9, 9]
        assert candidate([8, 6, 5, 6]) == [8, 8, 8, 8]
        assert candidate([3, 2, 7, 97, 6]) == [3, 3, 7, 97, 97]
        assert candidate([6, 2, 3, 101, 7]) == [6, 6, 6, 101, 101]
        assert candidate([7, 4, 3, 3]) == [7, 7, 7, 7]
        assert candidate([5, 5, 2, 7]) == [5, 5, 5, 7]
        assert candidate([7, 7, 7, 100, 4]) == [7, 7, 7, 100, 100]
        assert candidate([1, 8, 4, 6]) == [1, 8, 8, 8]
        assert candidate([2, 6, 8, 9]) == [2, 6, 8, 9]
        assert candidate([5, 5, 6, 6]) == [5, 5, 6, 6]
        assert candidate([6, 6, 4, 2]) == [6, 6, 6, 6]
        assert candidate([7, 4, 2, 1]) == [7, 7, 7, 7]
        assert candidate([5, 2, 5, 6]) == [5, 5, 5, 6]
        assert candidate([1, 3, 5, 2]) == [1, 3, 5, 5]
        assert candidate([2, 1, 6, 8]) == [2, 2, 6, 8]
        assert candidate([4, 1, 4, 7]) == [4, 4, 4, 7]
        assert candidate([3, 1, 2, 5]) == [3, 3, 3, 5]
        assert candidate([2, 5, 5, 100, 1]) == [2, 5, 5, 100, 100]
        assert candidate([1, 5, 6, 6]) == [1, 5, 6, 6]
        assert candidate([1, 5, 2, 9]) == [1, 5, 5, 9]
        assert candidate([9, 3, 7, 6]) == [9, 9, 9, 9]
        assert candidate([4, 3, 2, 1]) == [4, 4, 4, 4]
        assert candidate([1, 2, 1, 5]) == [1, 2, 2, 5]
        assert candidate([1, 3, 2, 3]) == [1, 3, 3, 3]
        assert candidate([6, 7, 3, 3]) == [6, 7, 7, 7]
        assert candidate([3, 5, 8, 102, 8]) == [3, 5, 8, 102, 102]
        assert candidate([6, 1, 4, 3]) == [6, 6, 6, 6]
        assert candidate([9, 7, 3, 5]) == [9, 9, 9, 9]
        assert candidate([7, 5, 8, 103, 6]) == [7, 7, 8, 103, 103]
        assert candidate([3, 1, 5, 1]) == [3, 3, 5, 5]
        assert candidate([6, 8, 3, 1]) == [6, 8, 8, 8]
        assert candidate([9, 4, 6, 6]) == [9, 9, 9, 9]
        assert candidate([3, 1, 2, 4]) == [3, 3, 3, 4]
        assert candidate([7, 3, 6, 96, 2]) == [7, 7, 7, 96, 96]
        assert candidate([1, 4, 2, 99, 4]) == [1, 4, 4, 99, 99]
        assert candidate([7, 1, 6, 6]) == [7, 7, 7, 7]
        assert candidate([1, 2, 3, 4]) == [1, 2, 3, 4]
        assert candidate([1, 1, 6, 2]) == [1, 1, 6, 6]
        assert candidate([2, 2, 1, 5]) == [2, 2, 2, 5]
        assert candidate([6, 3, 7, 99, 5]) == [6, 6, 7, 99, 99]
        assert candidate([1, 4, 6, 7]) == [1, 4, 6, 7]
        assert candidate([]) == []
        assert candidate([5, 6, 1, 4]) == [5, 6, 6, 6]
        assert candidate([3, 8, 2, 3]) == [3, 8, 8, 8]
        assert candidate([2, 4, 7, 96, 6]) == [2, 4, 7, 96, 96]
        assert candidate([5, 6, 5, 2]) == [5, 6, 6, 6]
        assert candidate([1, 3, 5, 97, 1]) == [1, 3, 5, 97, 97]
        assert candidate([3, 1, 5, 4]) == [3, 3, 5, 5]
        assert candidate([3, 6, 3, 9]) == [3, 6, 6, 9]
        assert candidate([2, 3, 4, 6]) == [2, 3, 4, 6]
        assert candidate([3, 2, 3, 100, 3]) == [3, 3, 3, 100, 100]
        assert candidate([8, 7, 2, 105, 1]) == [8, 8, 8, 105, 105]
        assert candidate([3, 4, 5, 4]) == [3, 4, 5, 5]
        assert candidate([7, 6, 6, 99, 2]) == [7, 7, 7, 99, 99]
        assert candidate([4, 1, 5, 5]) == [4, 4, 5, 5]
        assert candidate([3, 4, 3, 4]) == [3, 4, 4, 4]
        assert candidate([3, 6, 6, 104, 5]) == [3, 6, 6, 104, 104]
        assert candidate([6, 4, 8, 6]) == [6, 6, 8, 8]
        assert candidate([3, 7, 2, 100, 4]) == [3, 7, 7, 100, 100]
        assert candidate([6, 5, 2, 5]) == [6, 6, 6, 6]
        assert candidate([9, 7, 1, 5]) == [9, 9, 9, 9]
        assert candidate([3, 7, 1, 4]) == [3, 7, 7, 7]
        assert candidate([1, 7, 2, 1]) == [1, 7, 7, 7]
        assert candidate([4, 4, 7, 5]) == [4, 4, 7, 7]
        assert candidate([6, 1, 5, 8]) == [6, 6, 6, 8]
        assert candidate([5, 7, 6, 9]) == [5, 7, 7, 9]
        assert candidate([4, 2, 1, 105, 8]) == [4, 4, 4, 105, 105]
        assert candidate([8, 6, 4, 95, 4]) == [8, 8, 8, 95, 95]
        assert candidate([5, 7, 4, 96, 4]) == [5, 7, 7, 96, 96]

if __name__ == '__main__':
    unittest.main()
