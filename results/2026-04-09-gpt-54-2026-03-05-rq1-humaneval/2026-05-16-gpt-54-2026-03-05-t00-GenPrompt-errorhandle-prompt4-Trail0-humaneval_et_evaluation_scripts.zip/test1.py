
import unittest

from typing import List


from typing import List


def separate_paren_groups(paren_string: str) -> List[str]:
    """Input to this function is a string containing multiple groups of nested parentheses.
    Your goal is to separate those groups into separate strings and return them as a list.

    Separate groups are balanced (each open brace is properly closed) and not nested
    within each other. Ignore any spaces in the input string.

    >>> separate_paren_groups('( ) (( )) (( )( ))')
    ['()', '(())', '(()())']
    """
    if not isinstance(paren_string, str):
        raise TypeError("paren_string must be a string")

    result = []
    current_group = []
    balance = 0

    for i, ch in enumerate(paren_string):
        if ch.isspace():
            continue
        elif ch == '(':
            current_group.append(ch)
            balance += 1
        elif ch == ')':
            if balance == 0:
                raise ValueError(f"Unmatched closing parenthesis at position {i}")
            current_group.append(ch)
            balance -= 1

            if balance == 0:
                result.append(''.join(current_group))
                current_group = []
        else:
            raise ValueError(f"Invalid character {ch!r} at position {i}")

    if balance != 0:
        raise ValueError("Unmatched opening parenthesis in input")

    if current_group:
        raise ValueError("Incomplete parenthesis group detected")

    return result
candidate = separate_paren_groups


class Test(unittest.TestCase):
    def test(self):
        assert candidate("(()())(()())(())") == ['(()())', '(()())', '(())']
        assert candidate("(())(((())))(((())))(((())))") == ['(())', '(((())))', '(((())))', '(((())))']
        assert candidate("()(())((()))(())") == ['()', '(())', '((()))', '(())']
        assert candidate("(()())()((())()())((()))") == ['(()())', '()', '((())()())', '((()))']
        assert candidate("(()())(()())((()))((()))") == ['(()())', '(()())', '((()))', '((()))']
        assert candidate("((()))()()((())()())") == ['((()))', '()', '()', '((())()())']
        assert candidate("(())()()") == ['(())', '()', '()']
        assert candidate("(((())))((()))((()))(((())))") == ['(((())))', '((()))', '((()))', '(((())))']
        assert candidate("((()))(())((()))(((())))") == ['((()))', '(())', '((()))', '(((())))']
        assert candidate("(())()(())") == ['(())', '()', '(())']
        assert candidate("(())(()())(())") == ['(())', '(()())', '(())']
        assert candidate("()()(()())") == ['()', '()', '(()())']
        assert candidate("(())(())(())") == ['(())', '(())', '(())']
        assert candidate("((())()())((()))((())()())((())()())") == ['((())()())', '((()))', '((())()())', '((())()())']
        assert candidate("()((())()())((()))((())()())") == ['()', '((())()())', '((()))', '((())()())']
        assert candidate("()((())()())((())()())((()))") == ['()', '((())()())', '((())()())', '((()))']
        assert candidate("((()))()()(((())))") == ['((()))', '()', '()', '(((())))']
        assert candidate("()()()((()))") == ['()', '()', '()', '((()))']
        assert candidate("()(((())))(((())))(())") == ['()', '(((())))', '(((())))', '(())']
        assert candidate("((())()())((())()())((())()())()") == ['((())()())', '((())()())', '((())()())', '()']
        assert candidate("(((())))(((())))(())(())") == ['(((())))', '(((())))', '(())', '(())']
        assert candidate("()(())()") == ['()', '(())', '()']
        assert candidate("((()))()((())()())(()())") == ['((()))', '()', '((())()())', '(()())']
        assert candidate("((())()())(()())((())()())()") == ['((())()())', '(()())', '((())()())', '()']
        assert candidate("(((())))(())()()") == ['(((())))', '(())', '()', '()']
        assert candidate("()(()())(()())((()))") == ['()', '(()())', '(()())', '((()))']
        assert candidate("(())(())(()())") == ['(())', '(())', '(()())']
        assert candidate("()(()())(()())()") == ['()', '(()())', '(()())', '()']
        assert candidate("(()())()(()())") == ['(()())', '()', '(()())']
        assert candidate("(()())(()())()((())()())") == ['(()())', '(()())', '()', '((())()())']
        assert candidate("()(())(())") == ['()', '(())', '(())']
        assert candidate("()(()())(())") == ['()', '(()())', '(())']
        assert candidate('(()()) ((())) () ((())()())') == [
        '(()())', '((()))', '()', '((())()())'
    ]
        assert candidate("(())((()))()(((())))") == ['(())', '((()))', '()', '(((())))']
        assert candidate("((())()())((()))((()))((()))") == ['((())()())', '((()))', '((()))', '((()))']
        assert candidate('() (()) ((())) (((())))') == [
        '()', '(())', '((()))', '(((())))'
    ]
        assert candidate("()()()((())()())") == ['()', '()', '()', '((())()())']
        assert candidate("()(((())))(())((()))") == ['()', '(((())))', '(())', '((()))']
        assert candidate("(())(()())()") == ['(())', '(()())', '()']
        assert candidate("((()))(((())))(())()") == ['((()))', '(((())))', '(())', '()']
        assert candidate("(()())()((()))()") == ['(()())', '()', '((()))', '()']
        assert candidate('( ) (( )) (( )( ))') == ['()', '(())', '(()())']
        assert candidate("()(())(((())))(((())))") == ['()', '(())', '(((())))', '(((())))']
        assert candidate("((()))(((())))((()))((()))") == ['((()))', '(((())))', '((()))', '((()))']
        assert candidate("(((())))(())(())(((())))") == ['(((())))', '(())', '(())', '(((())))']
        assert candidate("((()))()(()())((()))") == ['((()))', '()', '(()())', '((()))']
        assert candidate("()(((())))()(())") == ['()', '(((())))', '()', '(())']
        assert candidate("(())()(()())") == ['(())', '()', '(()())']
        assert candidate("()()()") == ['()', '()', '()']
        assert candidate("((()))(()())((()))()") == ['((()))', '(()())', '((()))', '()']
        assert candidate("((()))(()())()((())()())") == ['((()))', '(()())', '()', '((())()())']
        assert candidate("(()())(()())(()())") == ['(()())', '(()())', '(()())']
        assert candidate('(()(())((())))') == [
        '(()(())((())))'
    ]
        assert candidate("()(())()(())") == ['()', '(())', '()', '(())']
        assert candidate("(())()(())(((())))") == ['(())', '()', '(())', '(((())))']
        assert candidate("()((())()())((())()())()") == ['()', '((())()())', '((())()())', '()']
        assert candidate("()()(())((()))") == ['()', '()', '(())', '((()))']
        assert candidate("(())((()))((()))(((())))") == ['(())', '((()))', '((()))', '(((())))']
        assert candidate("((()))(())(())(())") == ['((()))', '(())', '(())', '(())']
        assert candidate("((()))()()((()))") == ['((()))', '()', '()', '((()))']
        assert candidate("(()())((()))((())()())(()())") == ['(()())', '((()))', '((())()())', '(()())']
        assert candidate("(())(())()()") == ['(())', '(())', '()', '()']
        assert candidate("(()(())((())))") == ['(()(())((())))']
        assert candidate("(((())))((()))(((())))((()))") == ['(((())))', '((()))', '(((())))', '((()))']
        assert candidate("()()(())") == ['()', '()', '(())']
        assert candidate("()(())(()())") == ['()', '(())', '(()())']
        assert candidate("(()())()(()())(()())") == ['(()())', '()', '(()())', '(()())']
        assert candidate("(()())()(())") == ['(()())', '()', '(())']
        assert candidate("((()))(())(())()") == ['((()))', '(())', '(())', '()']

if __name__ == '__main__':
    unittest.main()
