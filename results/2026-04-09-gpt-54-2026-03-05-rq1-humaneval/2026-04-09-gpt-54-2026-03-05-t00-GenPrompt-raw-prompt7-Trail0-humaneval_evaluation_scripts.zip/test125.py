
import unittest
import re
import sys
import math
import copy


def split_words(txt):
    if any(ch.isspace() for ch in txt):
        return txt.split()
    elif ',' in txt:
        return txt.split(',')
    else:
        return sum(1 for ch in txt if ch.islower() and (ord(ch) - ord('a')) % 2 == 1)
candidate = split_words


def check(candidate):

    assert candidate("Hello world!") == ["Hello","world!"]
    assert candidate("Hello,world!") == ["Hello","world!"]
    assert candidate("Hello world,!") == ["Hello","world,!"]
    assert candidate("Hello,Hello,world !") == ["Hello,Hello,world","!"]
    assert candidate("abcdef") == 3
    assert candidate("aaabb") == 2
    assert candidate("aaaBb") == 1
    assert candidate("") == 0


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
