
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    # a[i] = i^2 - i + 1
    # modulo 3:
    # i % 3 == 0 -> a[i] % 3 = 1
    # i % 3 == 1 -> a[i] % 3 = 1
    # i % 3 == 2 -> a[i] % 3 = 0
    #
    # So values are only of type 0 or 1 mod 3.
    # A triple sum is divisible by 3 only when residues are (1,1,1) or (0,0,0).

    def comb3(x):
        return x * (x - 1) * (x - 2) // 6 if x >= 3 else 0

    count0 = n // 3              # indices i where i % 3 == 2
    count1 = n - count0          # remaining indices

    return comb3(count0) + comb3(count1)
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
