
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Given a grid with N rows and N columns (N >= 2) and a positive integer k, 
    each cell of the grid contains a value. Every integer in the range [1, N * N]
    inclusive appears exactly once on the cells of the grid.

    You have to find the minimum path of length k in the grid. You can start
    from any cell, and in each step you can move to any of the neighbor cells,
    in other words, you can go to cells which share an edge with you current
    cell.
    Please note that a path of length k means visiting exactly k cells (not
    necessarily distinct).
    You CANNOT go off the grid.
    A path A (of length k) is considered less than a path B (of length k) if
    after making the ordered lists of the values on the cells that A and B go
    through (let's call them lst_A and lst_B), lst_A is lexicographically less
    than lst_B, in other words, there exist an integer index i (1 <= i <= k)
    such that lst_A[i] < lst_B[i] and for any j (1 <= j < i) we have
    lst_A[j] = lst_B[j].
    It is guaranteed that the answer is unique.
    Return an ordered list of the values on the cells that the minimum path go through.

    Examples:

        Input: grid = [ [1,2,3], [4,5,6], [7,8,9]], k = 3
        Output: [1, 2, 1]

        Input: grid = [ [5,9,3], [4,1,6], [7,8,2]], k = 1
        Output: [1]
    """
    n = len(grid)

    # Map each value to its position for O(1) access by value.
    pos = [None] * (n * n + 1)
    for i in range(n):
        row = grid[i]
        for j in range(n):
            pos[row[j]] = (i, j)

    # Build adjacency by value, with neighbors sorted by cell value.
    neighbors = [[] for _ in range(n * n + 1)]
    for v in range(1, n * n + 1):
        i, j = pos[v]
        adj = []
        if i > 0:
            adj.append(grid[i - 1][j])
        if i + 1 < n:
            adj.append(grid[i + 1][j])
        if j > 0:
            adj.append(grid[i][j - 1])
        if j + 1 < n:
            adj.append(grid[i][j + 1])
        adj.sort()
        neighbors[v] = adj

    # dp_prev[v] = rank of the lexicographically smallest suffix of current length
    # starting from value v. For length 1, suffix is just [v], so rank is v-1.
    m = n * n
    dp_prev = list(range(m))

    # parent[length][v] = best next value after v for paths of given length
    # length ranges from 2..k
    parent = [[0] * (m + 1) for _ in range(k + 1)]

    # Build ranks for suffixes of increasing lengths.
    for length in range(2, k + 1):
        triples = []
        for v in range(1, m + 1):
            best_next = neighbors[v][0]
            best_rank = dp_prev[best_next - 1]
            for u in neighbors[v][1:]:
                r = dp_prev[u - 1]
                if r < best_rank:
                    best_rank = r
                    best_next = u
            parent[length][v] = best_next
            triples.append((v, best_rank, v))

        # Rank sequences by (first value, rank of best suffix after first value)
        triples.sort()
        dp_curr = [0] * m
        rank = 0
        dp_curr[triples[0][2] - 1] = 0
        for idx in range(1, m):
            if triples[idx][:2] != triples[idx - 1][:2]:
                rank += 1
            dp_curr[triples[idx][2] - 1] = rank
        dp_prev = dp_curr

    # Find best starting value for length k.
    best_start = 1
    best_rank = dp_prev[0]
    for v in range(2, m + 1):
        if dp_prev[v - 1] < best_rank:
            best_rank = dp_prev[v - 1]
            best_start = v

    # Reconstruct answer.
    ans = [best_start]
    cur = best_start
    for length in range(k, 1, -1):
        cur = parent[length][cur]
        ans.append(cur)

    return ans
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
