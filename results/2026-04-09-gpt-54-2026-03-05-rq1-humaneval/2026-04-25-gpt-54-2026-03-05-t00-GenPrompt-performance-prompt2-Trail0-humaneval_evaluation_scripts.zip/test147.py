
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    You are given a positive integer n. You have to create an integer array a of length n.
    For each i (1 â¤ i â¤ n), the value of a[i] = i * i - i + 1.

    Return the number of triples (a[i], a[j], a[k]) where i < j < k and
    a[i] + a[j] + a[k] is a multiple of 3.

    Example:
        Input: n = 5
        Output: 1
        Explanation:
        a = [1, 3, 7, 13, 21]
        The only valid triple is (1, 7, 13).
    """
    if n < 3:
        return 0

    # a[i] = i^2 - i + 1
    # Mod 3 pattern:
    # i % 3 == 0 -> a[i] % 3 == 1
    # i % 3 == 1 -> a[i] % 3 == 1
    # i % 3 == 2 -> a[i] % 3 == 0
    #
    # So values are only in residue classes 0 and 1 modulo 3.
    # To make sum divisible by 3, the only possible triple is:
    # 1 + 1 + 1 â¡ 0 (mod 3)
    #
    # Therefore, we only need count of indices i in [1..n] such that i % 3 != 2.

    count_mod_1 = n - ((n + 1) // 3)  # numbers with i % 3 == 2
    # Equivalent to count of i where a[i] % 3 == 1

    if count_mod_1 < 3:
        return 0

    return count_mod_1 * (count_mod_1 - 1) * (count_mod_1 - 2) // 6
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
