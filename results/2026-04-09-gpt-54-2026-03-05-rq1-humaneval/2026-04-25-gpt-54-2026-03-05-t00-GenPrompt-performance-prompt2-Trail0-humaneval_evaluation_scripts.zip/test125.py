
import unittest
import re
import sys
import math
import copy


def split_words(txt):
    '''
    Given a string of words, return a list of words split on whitespace.
    If no whitespaces exist in the text, split on commas ','.
    If no commas exist, return the number of lower-case letters with odd
    order in the alphabet, where ord('a') = 0, ord('b') = 1, ..., ord('z') = 25.

    Examples
    split_words("Hello world!") â ["Hello", "world!"]
    split_words("Hello,world!") â ["Hello", "world!"]
    split_words("abcdef") == 3
    '''
    if any(c.isspace() for c in txt):
        return txt.split()
    if ',' in txt:
        return txt.split(',')
    return sum((ord(c) - ord('a')) % 2 == 1 for c in txt if 'a' <= c <= 'z')
candidate = split_words


def check(candidate):

    assert candidate("Hello world!") == ["Hello","world!"]
    assert candidate("Hello,world!") == ["Hello","world!"]
    assert candidate("Hello world,!") == ["Hello","world,!"]
    assert candidate("Hello,Hello,world !") == ["Hello,Hello,world","!"]
    assert candidate("abcdef") == 3
    assert candidate("aaabb") == 2
    assert candidate("aaaBb") == 1
    assert candidate("") == 0


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
