
import unittest
import re
import sys
import math
import copy


def pluck(arr):
    """
    Given an array representing a branch of a tree that has non-negative integer nodes,
    return the node with the smallest even value as [value, index].

    If multiple nodes have the same smallest even value, return the one with
    the smallest index.

    If there are no even values or the array is empty, return [].

    Error handling:
    - If arr is None, return []
    - If arr is not a list/tuple, raise TypeError
    - If any element is not a non-negative integer, raise ValueError
    """
    try:
        if arr is None:
            return []

        if not isinstance(arr, (list, tuple)):
            raise TypeError("Input must be a list or tuple.")

        if len(arr) == 0:
            return []

        smallest_even = None
        smallest_index = -1

        for i, value in enumerate(arr):
            if not isinstance(value, int) or value < 0:
                raise ValueError("All elements must be non-negative integers.")

            if value % 2 == 0:
                if smallest_even is None or value < smallest_even:
                    smallest_even = value
                    smallest_index = i

        return [smallest_even, smallest_index] if smallest_even is not None else []

    except TypeError as te:
        print(f"Type error: {te}")
        return []
    except ValueError as ve:
        print(f"Value error: {ve}")
        return []
    except Exception as e:
        print(f"Unexpected error: {e}")
        return []
candidate = pluck


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([4,2,3]) == [2, 1], "Error"
    assert candidate([1,2,3]) == [2, 1], "Error"
    assert candidate([]) == [], "Error"
    assert candidate([5, 0, 3, 0, 4, 2]) == [0, 1], "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([1, 2, 3, 0, 5, 3]) == [0, 3], "Error"
    assert candidate([5, 4, 8, 4 ,8]) == [4, 1], "Error"
    assert candidate([7, 6, 7, 1]) == [6, 1], "Error"
    assert candidate([7, 9, 7, 1]) == [], "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
