
import unittest
import re
import sys
import math
import copy


def can_arrange(arr):
    """Return the largest index i such that arr[i] <= arr[i-1].
    If no such index exists, return -1.

    The array must contain no duplicate values.

    Examples:
    can_arrange([1, 2, 4, 3, 5]) -> 3
    can_arrange([1, 2, 3]) -> -1
    """
    try:
        if not isinstance(arr, list):
            raise TypeError("Input must be a list.")
        
        if len(arr) < 2:
            return -1

        if len(arr) != len(set(arr)):
            raise ValueError("Array must not contain duplicate values.")

        largest_index = -1

        for i in range(1, len(arr)):
            if arr[i] <= arr[i - 1]:
                largest_index = i

        return largest_index

    except TypeError as te:
        return f"TypeError: {te}"
    except ValueError as ve:
        return f"ValueError: {ve}"
    except Exception as e:
        return f"Unexpected error: {e}"
candidate = can_arrange


def check(candidate):

    # Check some simple cases
    assert candidate([1,2,4,3,5])==3
    assert candidate([1,2,4,5])==-1
    assert candidate([1,4,2,5,6,7,8,9,10])==2
    assert candidate([4,8,5,7,3])==4

    # Check some edge cases that are easy to work out by hand.
    assert candidate([])==-1



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
