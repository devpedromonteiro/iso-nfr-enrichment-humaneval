
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    You are given a positive integer n. Create an integer array a of length n where:
        a[i] = i * i - i + 1   for 1 <= i <= n

    Return the number of triples (a[i], a[j], a[k]) such that:
        i < j < k
        and (a[i] + a[j] + a[k]) is divisible by 3.

    Example:
        Input: n = 5
        Output: 1
    """
    # Error handling
    if n is None:
        raise ValueError("Input cannot be None.")

    if not isinstance(n, int):
        raise TypeError("Input must be an integer.")

    if n <= 0:
        raise ValueError("Input must be a positive integer.")

    try:
        # Pattern:
        # a[i] = i^2 - i + 1 = i(i-1) + 1
        # Since i(i-1) is always divisible by 2, but we care mod 3:
        # Check values modulo 3:
        # i % 3 == 0 -> a[i] % 3 = 1
        # i % 3 == 1 -> a[i] % 3 = 1
        # i % 3 == 2 -> a[i] % 3 = 0

        count_mod_0 = n // 3                  # indices where i % 3 == 2
        count_mod_1 = n - count_mod_0         # remaining indices

        # Valid triples whose sum is divisible by 3:
        # 1) (0, 0, 0)
        # 2) (1, 1, 1)
        # Since only residues 0 and 1 appear.

        def comb3(x):
            return x * (x - 1) * (x - 2) // 6 if x >= 3 else 0

        return comb3(count_mod_0) + comb3(count_mod_1)

    except OverflowError:
        raise OverflowError("Computation caused an overflow.")
    except Exception as e:
        raise RuntimeError(f"Unexpected error occurred: {e}")
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
