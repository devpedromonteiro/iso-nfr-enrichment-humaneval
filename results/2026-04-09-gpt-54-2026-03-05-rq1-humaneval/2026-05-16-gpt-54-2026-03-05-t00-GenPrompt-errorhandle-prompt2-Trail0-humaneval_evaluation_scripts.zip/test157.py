
import unittest
import re
import sys
import math
import copy


def right_angle_triangle(a, b, c):
    '''
    Given the lengths of the three sides of a triangle. Return True if the three
    sides form a right-angled triangle, False otherwise.
    A right-angled triangle is a triangle in which one angle is right angle or 
    90 degree.
    Example:
    right_angle_triangle(3, 4, 5) == True
    right_angle_triangle(1, 2, 3) == False
    '''
    try:
        # Convert inputs to numbers
        a = float(a)
        b = float(b)
        c = float(c)

        # Check for valid side lengths
        if a <= 0 or b <= 0 or c <= 0:
            raise ValueError("Triangle sides must be positive numbers.")

        # Check triangle inequality
        if a + b <= c or a + c <= b or b + c <= a:
            return False

        # Sort sides so the largest can be treated as hypotenuse
        sides = sorted([a, b, c])

        # Check Pythagorean theorem
        return sides[0] ** 2 + sides[1] ** 2 == sides[2] ** 2

    except ValueError as e:
        print(f"ValueError: {e}")
        return False
    except TypeError as e:
        print(f"TypeError: {e}")
        return False
candidate = right_angle_triangle


def check(candidate):

    # Check some simple cases
    assert candidate(3, 4, 5) == True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(1, 2, 3) == False
    assert candidate(10, 6, 8) == True
    assert candidate(2, 2, 2) == False
    assert candidate(7, 24, 25) == True
    assert candidate(10, 5, 7) == False
    assert candidate(5, 12, 13) == True
    assert candidate(15, 8, 17) == True
    assert candidate(48, 55, 73) == True

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1, 1, 1) == False, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate(2, 2, 10) == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
