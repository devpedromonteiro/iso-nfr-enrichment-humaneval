
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def rescale_to_unit(numbers: List[float]) -> List[float]:
    """Given a list of numbers, linearly rescale them so that:
    - the smallest value becomes 0
    - the largest value becomes 1

    Raises:
        TypeError: if numbers is not a list or contains non-numeric values
        ValueError: if the list has fewer than two elements or all values are equal

    >>> rescale_to_unit([1.0, 2.0, 3.0, 4.0, 5.0])
    [0.0, 0.25, 0.5, 0.75, 1.0]
    """
    if not isinstance(numbers, list):
        raise TypeError("Input must be a list.")

    if len(numbers) < 2:
        raise ValueError("List must contain at least two elements.")

    if not all(isinstance(x, (int, float)) for x in numbers):
        raise TypeError("All elements in the list must be numeric.")

    min_val = min(numbers)
    max_val = max(numbers)

    if min_val == max_val:
        raise ValueError("Cannot rescale a list where all values are equal.")

    return [(x - min_val) / (max_val - min_val) for x in numbers]
candidate = rescale_to_unit




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([2.0, 49.9]) == [0.0, 1.0]
    assert candidate([100.0, 49.9]) == [1.0, 0.0]
    assert candidate([1.0, 2.0, 3.0, 4.0, 5.0]) == [0.0, 0.25, 0.5, 0.75, 1.0]
    assert candidate([2.0, 1.0, 5.0, 3.0, 4.0]) == [0.25, 0.0, 1.0, 0.5, 0.75]
    assert candidate([12.0, 11.0, 15.0, 13.0, 14.0]) == [0.25, 0.0, 1.0, 0.5, 0.75]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
