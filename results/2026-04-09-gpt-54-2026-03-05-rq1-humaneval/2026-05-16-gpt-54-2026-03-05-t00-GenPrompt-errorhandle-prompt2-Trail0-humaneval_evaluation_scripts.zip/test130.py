
import unittest
import re
import sys
import math
import copy


def tri(n):
    """Return a list of the first n + 1 Tribonacci values.

    Sequence definition:
    tri(0) = 1
    tri(1) = 3
    tri(n) = 1 + n / 2, if n is even
    tri(n) = tri(n - 1) + tri(n - 2) + tri(n + 1), if n is odd

    Example:
    tri(3) -> [1, 3, 2, 8]
    """
    # Error handling: type check
    if not isinstance(n, int):
        raise TypeError("n must be an integer")

    # Error handling: value check
    if n < 0:
        raise ValueError("n must be a non-negative integer")

    try:
        result = [0] * (n + 1)

        # Base case
        result[0] = 1
        if n >= 1:
            result[1] = 3

        # Fill even indices first, since odd indices depend on n+1
        for i in range(2, n + 1):
            if i % 2 == 0:
                result[i] = 1 + i // 2

        # Fill odd indices using the recurrence
        for i in range(3, n + 1, 2):
            result[i] = result[i - 1] + result[i - 2] + result[i + 1]

        return result

    except IndexError:
        raise RuntimeError("Unexpected indexing error while building the sequence")
    except Exception as e:
        raise RuntimeError(f"An unexpected error occurred: {e}")
candidate = tri


def check(candidate):

    # Check some simple cases
    
    assert candidate(3) == [1, 3, 2.0, 8.0]
    assert candidate(4) == [1, 3, 2.0, 8.0, 3.0]
    assert candidate(5) == [1, 3, 2.0, 8.0, 3.0, 15.0]
    assert candidate(6) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0]
    assert candidate(7) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0]
    assert candidate(8) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0]
    assert candidate(9) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0]
    assert candidate(20) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0, 6.0, 48.0, 7.0, 63.0, 8.0, 80.0, 9.0, 99.0, 10.0, 120.0, 11.0]

    # Check some edge cases that are easy to work out by hand.
    assert candidate(0) == [1]
    assert candidate(1) == [1, 3]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
