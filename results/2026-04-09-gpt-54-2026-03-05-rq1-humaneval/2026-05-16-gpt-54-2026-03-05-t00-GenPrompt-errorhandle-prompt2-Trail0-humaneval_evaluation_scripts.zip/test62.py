
import unittest
import re
import sys
import math
import copy



def derivative(xs: list):
    """xs represent coefficients of a polynomial.
    xs[0] + xs[1] * x + xs[2] * x^2 + ....
    Return derivative of this polynomial in the same form.

    >>> derivative([3, 1, 2, 4, 5])
    [1, 4, 12, 20]
    >>> derivative([1, 2, 3])
    [2, 6]
    """
    if not isinstance(xs, list):
        raise TypeError("Input must be a list.")

    if len(xs) == 0:
        return []

    if not all(isinstance(x, (int, float)) for x in xs):
        raise ValueError("All coefficients must be numbers.")

    try:
        return [i * xs[i] for i in range(1, len(xs))]
    except Exception as e:
        raise RuntimeError(f"Unexpected error while computing derivative: {e}")
candidate = derivative




METADATA = {}


def check(candidate):
    assert candidate([3, 1, 2, 4, 5]) == [1, 4, 12, 20]
    assert candidate([1, 2, 3]) == [2, 6]
    assert candidate([3, 2, 1]) == [2, 2]
    assert candidate([3, 2, 1, 0, 4]) == [2, 2, 0, 16]
    assert candidate([1]) == []



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
