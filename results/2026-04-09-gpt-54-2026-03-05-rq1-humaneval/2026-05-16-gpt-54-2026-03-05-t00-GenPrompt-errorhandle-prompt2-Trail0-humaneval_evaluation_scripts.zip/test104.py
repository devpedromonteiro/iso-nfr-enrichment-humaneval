
import unittest
import re
import sys
import math
import copy


def unique_digits(x):
    """Given a list of positive integers x, return a sorted list of all
    elements that don't contain any even digit.

    Error handling:
    - Raises TypeError if x is not a list/tuple
    - Raises TypeError if any element is not an integer
    - Raises ValueError if any element is negative

    Examples:
    >>> unique_digits([15, 33, 1422, 1])
    [1, 15, 33]
    >>> unique_digits([152, 323, 1422, 10])
    []
    """
    try:
        if not isinstance(x, (list, tuple)):
            raise TypeError("Input must be a list or tuple of positive integers.")

        result = []

        for num in x:
            if not isinstance(num, int):
                raise TypeError(f"All elements must be integers, got {type(num).__name__}.")
            if num < 0:
                raise ValueError("All elements must be positive integers.")

            # Check that every digit is odd
            if all(int(digit) % 2 != 0 for digit in str(num)):
                result.append(num)

        return sorted(result)

    except (TypeError, ValueError) as e:
        print(f"Error: {e}")
        return []
candidate = unique_digits


def check(candidate):

    # Check some simple cases
    assert candidate([15, 33, 1422, 1]) == [1, 15, 33]
    assert candidate([152, 323, 1422, 10]) == []
    assert candidate([12345, 2033, 111, 151]) == [111, 151]
    assert candidate([135, 103, 31]) == [31, 135]

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
