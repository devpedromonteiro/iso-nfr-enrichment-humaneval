
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[2] * x^2 + .... + xs[n] * x^n
    """
    if not isinstance(xs, list):
        raise TypeError("xs must be a list of coefficients")
    if len(xs) == 0:
        raise ValueError("xs must not be empty")
    if not isinstance(x, (int, float)):
        raise TypeError("x must be a number")

    try:
        return sum(coeff * math.pow(x, i) for i, coeff in enumerate(xs))
    except TypeError:
        raise TypeError("all coefficients must be numbers")


def find_zero(xs: list):
    """ xs are coefficients of a polynomial.
    find_zero find x such that poly(x) = 0.
    find_zero returns only only zero point, even if there are many.
    Moreover, find_zero only takes list xs having even number of coefficients
    and largest non zero coefficient as it guarantees
    a solution.
    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3
    1.0
    """
    if not isinstance(xs, list):
        raise TypeError("xs must be a list")
    if len(xs) == 0:
        raise ValueError("xs must not be empty")

    try:
        if not all(isinstance(c, (int, float)) for c in xs):
            raise TypeError("all coefficients must be numbers")
    except TypeError:
        raise TypeError("xs must be iterable")

    # remove trailing zeros
    while len(xs) > 1 and xs[-1] == 0:
        xs = xs[:-1]

    if xs[-1] == 0:
        raise ValueError("polynomial must have a non-zero leading coefficient")

    # degree must be odd => number of coefficients must be even
    if len(xs) % 2 != 0:
        raise ValueError("xs must contain an even number of coefficients")

    def f(x):
        return poly(xs, x)

    # quick return if zero at x = 0
    if f(0) == 0:
        return 0.0

    # find interval [a, b] with sign change
    a, b = -1.0, 1.0
    fa, fb = f(a), f(b)

    try:
        while fa * fb > 0:
            a *= 2
            b *= 2
            fa, fb = f(a), f(b)
    except OverflowError:
        raise OverflowError("failed to find a bounded interval containing a root")

    # bisection method
    eps = 1e-10
    max_iter = 1000

    for _ in range(max_iter):
        mid = (a + b) / 2
        fm = f(mid)

        if abs(fm) < eps:
            return mid

        if fa * fm <= 0:
            b, fb = mid, fm
        else:
            a, fa = mid, fm

    raise RuntimeError("root finding did not converge")
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
