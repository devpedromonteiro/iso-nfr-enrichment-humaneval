
import unittest
import re
import sys
import math
import copy



def triangle_area(a, h):
    """Given length of a side and high return area for a triangle.
    >>> triangle_area(5, 3)
    7.5
    """
    try:
        a = float(a)
        h = float(h)
    except (TypeError, ValueError):
        raise TypeError("Both 'a' and 'h' must be numbers.")

    if a < 0 or h < 0:
        raise ValueError("'a' and 'h' must be non-negative.")

    return (a * h) / 2
candidate = triangle_area




METADATA = {}


def check(candidate):
    assert candidate(5, 3) == 7.5
    assert candidate(2, 2) == 2.0
    assert candidate(10, 8) == 40.0



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
