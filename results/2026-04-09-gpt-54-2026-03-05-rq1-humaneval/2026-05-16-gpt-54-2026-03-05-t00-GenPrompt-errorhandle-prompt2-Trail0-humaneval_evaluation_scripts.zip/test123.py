
import unittest
import re
import sys
import math
import copy


def get_odd_collatz(n):
    """
    Given a positive integer n, return a sorted list containing the odd numbers
    in the Collatz sequence for n.

    The returned list is sorted in increasing order.

    Examples:
        get_odd_collatz(1) -> [1]
        get_odd_collatz(5) -> [1, 5]
    """
    # Type checking
    if not isinstance(n, int):
        raise TypeError("n must be an integer")

    # Value checking
    if n <= 0:
        raise ValueError("n must be a positive integer")

    odd_numbers = []

    try:
        while n != 1:
            if n % 2 == 1:
                odd_numbers.append(n)

            if n % 2 == 0:
                n = n // 2
            else:
                n = 3 * n + 1

        # Include 1 since it is odd and always the last term
        odd_numbers.append(1)

    except OverflowError:
        raise OverflowError("Number became too large during Collatz computation")
    except Exception as e:
        raise RuntimeError(f"Unexpected error during Collatz computation: {e}")

    return sorted(odd_numbers)
candidate = get_odd_collatz


def check(candidate):

    # Check some simple cases
    assert candidate(14) == [1, 5, 7, 11, 13, 17]
    assert candidate(5) == [1, 5]
    assert candidate(12) == [1, 3, 5], "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1) == [1], "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
