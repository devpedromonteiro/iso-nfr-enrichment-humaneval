
import unittest
import re
import sys
import math
import copy


def hex_key(num):
    """You have been tasked to write a function that receives 
    a hexadecimal number as a string and counts the number of hexadecimal 
    digits that are primes.
    Prime hexadecimal digits: 2, 3, 5, 7, B, D
    """
    
    try:
        # Check if input is a string
        if not isinstance(num, str):
            raise TypeError("Input must be a string.")
        
        # Handle empty string
        if num == "":
            return 0
        
        prime_hex_digits = {"2", "3", "5", "7", "B", "D"}
        valid_hex_digits = set("0123456789ABCDEF")
        
        count = 0
        for ch in num:
            # Validate hexadecimal character
            if ch not in valid_hex_digits:
                raise ValueError(f"Invalid hexadecimal digit: {ch}")
            
            if ch in prime_hex_digits:
                count += 1
        
        return count
    
    except TypeError as te:
        return f"Type Error: {te}"
    
    except ValueError as ve:
        return f"Value Error: {ve}"
    
    except Exception as e:
        return f"Unexpected Error: {e}"
candidate = hex_key


def check(candidate):

    # Check some simple cases
    assert candidate("AB") == 1, "First test error: " + str(candidate("AB"))      
    assert candidate("1077E") == 2, "Second test error: " + str(candidate("1077E"))  
    assert candidate("ABED1A33") == 4, "Third test error: " + str(candidate("ABED1A33"))      
    assert candidate("2020") == 2, "Fourth test error: " + str(candidate("2020"))  
    assert candidate("123456789ABCDEF0") == 6, "Fifth test error: " + str(candidate("123456789ABCDEF0"))      
    assert candidate("112233445566778899AABBCCDDEEFF00") == 12, "Sixth test error: " + str(candidate("112233445566778899AABBCCDDEEFF00"))  


    # Check some edge cases that are easy to work out by hand.
    assert candidate([]) == 0



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
