
import unittest
import re
import sys
import math
import copy


def exchange(lst1, lst2):
    """Determine whether lst1 can be made all even by exchanging elements with lst2.

    Rules:
    - Any number of exchanges is allowed.
    - Return "YES" if lst1 can become all even, otherwise "NO".

    Error handling:
    - Raises TypeError if inputs are not lists.
    - Raises ValueError if either list is empty.
    - Raises TypeError if any element is not a number.
    """
    try:
        if not isinstance(lst1, list) or not isinstance(lst2, list):
            raise TypeError("Both inputs must be lists.")

        if len(lst1) == 0 or len(lst2) == 0:
            raise ValueError("Input lists must be non-empty.")

        for x in lst1 + lst2:
            if not isinstance(x, (int, float)):
                raise TypeError("All elements in both lists must be numbers.")

        odd_count_lst1 = sum(1 for x in lst1 if x % 2 != 0)
        even_count_lst2 = sum(1 for x in lst2 if x % 2 == 0)

        return "YES" if even_count_lst2 >= odd_count_lst1 else "NO"

    except TypeError as te:
        return f"TypeError: {te}"
    except ValueError as ve:
        return f"ValueError: {ve}"
    except Exception as e:
        return f"Unexpected error: {e}"
candidate = exchange


def check(candidate):

    # Check some simple cases
    assert candidate([1, 2, 3, 4], [1, 2, 3, 4]) == "YES"
    assert candidate([1, 2, 3, 4], [1, 5, 3, 4]) == "NO"
    assert candidate([1, 2, 3, 4], [2, 1, 4, 3]) == "YES" 
    assert candidate([5, 7, 3], [2, 6, 4]) == "YES"
    assert candidate([5, 7, 3], [2, 6, 3]) == "NO" 
    assert candidate([3, 2, 6, 1, 8, 9], [3, 5, 5, 1, 1, 1]) == "NO"

    # Check some edge cases that are easy to work out by hand.
    assert candidate([100, 200], [200, 200]) == "YES"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
