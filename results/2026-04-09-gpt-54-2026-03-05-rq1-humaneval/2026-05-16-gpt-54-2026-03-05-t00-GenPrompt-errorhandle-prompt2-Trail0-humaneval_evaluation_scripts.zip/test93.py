
import unittest
import re
import sys
import math
import copy


def encode(message):
    """
    Write a function that takes a message, and encodes it by:
    1. Swapping the case of all letters
    2. Replacing all vowels with the letter 2 places ahead in the alphabet

    Assumes input contains only letters and spaces.

    Examples:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """
    try:
        if not isinstance(message, str):
            raise TypeError("Input must be a string.")

        vowels = {
            'a': 'c', 'e': 'g', 'i': 'k', 'o': 'q', 'u': 'w',
            'A': 'C', 'E': 'G', 'I': 'K', 'O': 'Q', 'U': 'W'
        }

        encoded = []

        for char in message:
            if not (char.isalpha() or char.isspace()):
                raise ValueError("Message must contain only letters and spaces.")

            swapped = char.swapcase()
            encoded.append(vowels.get(swapped, swapped))

        return ''.join(encoded)

    except TypeError as te:
        return f"TypeError: {te}"
    except ValueError as ve:
        return f"ValueError: {ve}"
    except Exception as e:
        return f"Unexpected error: {e}"
candidate = encode


def check(candidate):

    # Check some simple cases
    assert candidate('TEST') == 'tgst', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('Mudasir') == 'mWDCSKR', "This prints if this assert fails 2 (good for debugging!)"
    assert candidate('YES') == 'ygs', "This prints if this assert fails 3 (good for debugging!)"
    
    # Check some edge cases that are easy to work out by hand.
    assert candidate('This is a message') == 'tHKS KS C MGSSCGG', "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate("I DoNt KnOw WhAt tO WrItE") == 'k dQnT kNqW wHcT Tq wRkTg', "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
