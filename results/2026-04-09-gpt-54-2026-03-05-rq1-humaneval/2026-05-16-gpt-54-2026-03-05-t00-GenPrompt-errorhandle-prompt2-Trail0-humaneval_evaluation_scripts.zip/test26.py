
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def remove_duplicates(numbers: List[int]) -> List[int]:
    """From a list of integers, remove all elements that occur more than once.
    Keep order of elements left the same as in the input.

    >>> remove_duplicates([1, 2, 3, 2, 4])
    [1, 3, 4]
    """
    # Error handling: validate input type
    if not isinstance(numbers, list):
        raise TypeError("Input must be a list of integers.")

    # Error handling: validate element types
    if not all(isinstance(n, int) for n in numbers):
        raise ValueError("All elements in the list must be integers.")

    try:
        counts = {}
        for n in numbers:
            counts[n] = counts.get(n, 0) + 1

        result = [n for n in numbers if counts[n] == 1]
        return result

    except Exception as e:
        # Generic fallback error handling
        raise RuntimeError(f"An unexpected error occurred: {e}")
candidate = remove_duplicates




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == []
    assert candidate([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert candidate([1, 2, 3, 2, 4, 3, 5]) == [1, 4, 5]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
