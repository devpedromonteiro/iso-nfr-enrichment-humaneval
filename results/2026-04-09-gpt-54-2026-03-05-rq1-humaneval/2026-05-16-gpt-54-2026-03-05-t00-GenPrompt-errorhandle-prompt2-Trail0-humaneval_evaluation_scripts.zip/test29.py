
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def filter_by_prefix(strings: List[str], prefix: str) -> List[str]:
    """Filter an input list of strings only for ones that start with a given prefix.

    >>> filter_by_prefix([], 'a')
    []
    >>> filter_by_prefix(['abc', 'bcd', 'cde', 'array'], 'a')
    ['abc', 'array']
    """
    # Type validation
    if not isinstance(strings, list):
        raise TypeError("strings must be a list of strings")
    if not isinstance(prefix, str):
        raise TypeError("prefix must be a string")

    result = []

    for i, s in enumerate(strings):
        try:
            if not isinstance(s, str):
                raise TypeError(f"Item at index {i} is not a string: {s!r}")
            if s.startswith(prefix):
                result.append(s)
        except AttributeError as e:
            raise TypeError(f"Invalid string element at index {i}: {s!r}") from e

    return result
candidate = filter_by_prefix




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([], 'john') == []
    assert candidate(['xxx', 'asd', 'xxy', 'john doe', 'xxxAAA', 'xxx'], 'xxx') == ['xxx', 'xxxAAA', 'xxx']


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
