
import unittest
import re
import sys
import math
import copy


def special_factorial(n):
    """The Brazilian factorial is defined as:
    brazilian_factorial(n) = n! * (n-1)! * (n-2)! * ... * 1!
    where n > 0

    For example:
    >>> special_factorial(4)
    288

    The function will receive an integer as input and should return the special
    factorial of this integer.
    """
    # Error handling
    if not isinstance(n, int):
        raise TypeError("Input must be an integer.")
    if isinstance(n, bool):
        raise TypeError("Input must be an integer, not a boolean.")
    if n <= 0:
        raise ValueError("Input must be greater than 0.")

    try:
        result = 1
        factorial = 1

        for i in range(1, n + 1):
            factorial *= i
            result *= factorial

        return result

    except OverflowError:
        raise OverflowError("The result is too large to compute.")
    except Exception as e:
        raise RuntimeError(f"An unexpected error occurred: {e}")
candidate = special_factorial


def check(candidate):

    # Check some simple cases
    assert candidate(4) == 288, "Test 4"
    assert candidate(5) == 34560, "Test 5"
    assert candidate(7) == 125411328000, "Test 7"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1) == 1, "Test 1"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
