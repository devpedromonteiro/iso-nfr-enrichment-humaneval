
import unittest
import re
import sys
import math
import copy



def prime_fib(n: int):
    """
    prime_fib returns n-th number that is a Fibonacci number and it's also prime.
    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """
    # Type checking
    if not isinstance(n, int):
        raise TypeError("n must be an integer")

    # Value checking
    if n <= 0:
        raise ValueError("n must be a positive integer")

    def is_prime(num: int) -> bool:
        """Return True if num is prime, otherwise False."""
        if num < 2:
            return False
        if num == 2:
            return True
        if num % 2 == 0:
            return False

        i = 3
        while i * i <= num:
            if num % i == 0:
                return False
            i += 2
        return True

    count = 0
    a, b = 0, 1

    try:
        while True:
            a, b = b, a + b
            if is_prime(a):
                count += 1
                if count == n:
                    return a
    except OverflowError:
        raise OverflowError("Number became too large during Fibonacci computation")
    except Exception as e:
        raise RuntimeError(f"Unexpected error occurred: {e}")
candidate = prime_fib




METADATA = {}


def check(candidate):
    assert candidate(1) == 2
    assert candidate(2) == 3
    assert candidate(3) == 5
    assert candidate(4) == 13
    assert candidate(5) == 89
    assert candidate(6) == 233
    assert candidate(7) == 1597
    assert candidate(8) == 28657
    assert candidate(9) == 514229
    assert candidate(10) == 433494437



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
