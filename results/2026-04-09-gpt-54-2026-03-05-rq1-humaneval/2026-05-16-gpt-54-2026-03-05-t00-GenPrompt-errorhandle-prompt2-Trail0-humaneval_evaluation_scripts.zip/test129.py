
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Given a grid with N rows and N columns (N >= 2) and a positive integer k,
    each cell of the grid contains a value. Every integer in the range [1, N * N]
    inclusive appears exactly once on the cells of the grid.

    Return the lexicographically smallest path of length k.

    Error handling:
    - Raises TypeError for invalid input types
    - Raises ValueError for invalid grid shape/content or invalid k
    """
    # Type checks
    if not isinstance(grid, list):
        raise TypeError("grid must be a list of lists")
    if not isinstance(k, int):
        raise TypeError("k must be an integer")

    # Value checks
    if k <= 0:
        raise ValueError("k must be a positive integer")
    if len(grid) < 2:
        raise ValueError("grid must have at least 2 rows")

    n = len(grid)

    # Check square grid
    for row in grid:
        if not isinstance(row, list):
            raise TypeError("each row in grid must be a list")
        if len(row) != n:
            raise ValueError("grid must be square (N x N)")

    # Check values are exactly 1..N*N
    values = []
    for row in grid:
        for val in row:
            if not isinstance(val, int):
                raise TypeError("all grid values must be integers")
            values.append(val)

    expected = set(range(1, n * n + 1))
    if set(values) != expected or len(values) != len(set(values)):
        raise ValueError("grid must contain each integer from 1 to N*N exactly once")

    # Map value -> position
    pos = {}
    for i in range(n):
        for j in range(n):
            pos[grid[i][j]] = (i, j)

    # Build neighbors for each value
    neighbors = {}
    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]

    for val in pos:
        i, j = pos[val]
        adj = []
        for di, dj in directions:
            ni, nj = i + di, j + dj
            if 0 <= ni < n and 0 <= nj < n:
                adj.append(grid[ni][nj])
        neighbors[val] = sorted(adj)

    # Start from the minimum value since lexicographically smallest path
    # must begin with the smallest possible starting cell.
    start = 1
    result = [start]
    current = start

    # Greedily choose the smallest neighbor each step
    for _ in range(k - 1):
        current = neighbors[current][0]
        result.append(current)

    return result
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
