
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def concatenate(strings: List[str]) -> str:
    """Concatenate list of strings into a single string.

    >>> concatenate([])
    ''
    >>> concatenate(['a', 'b', 'c'])
    'abc'
    >>> concatenate(['hello', ' ', 'world'])
    'hello world'
    """
    if strings is None:
        raise ValueError("Input cannot be None")

    if not isinstance(strings, list):
        raise TypeError("Input must be a list of strings")

    for i, item in enumerate(strings):
        if not isinstance(item, str):
            raise TypeError(f"Element at index {i} is not a string")

    try:
        return "".join(strings)
    except Exception as e:
        raise RuntimeError(f"Unexpected error during concatenation: {e}") from e
candidate = concatenate




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == ''
    assert candidate(['x', 'y', 'z']) == 'xyz'
    assert candidate(['x', 'y', 'z', 'w', 'k']) == 'xyzwk'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
