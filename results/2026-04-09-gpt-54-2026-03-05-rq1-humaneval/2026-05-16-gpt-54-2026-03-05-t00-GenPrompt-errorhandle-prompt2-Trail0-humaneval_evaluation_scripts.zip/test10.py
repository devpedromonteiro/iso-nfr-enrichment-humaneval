
import unittest
import re
import sys
import math
import copy



def is_palindrome(string: str) -> bool:
    """ Test if given string is a palindrome """
    return string == string[::-1]


def is_palindrome(string: str) -> bool:
    """Test if given string is a palindrome."""
    if not isinstance(string, str):
        raise TypeError("string must be of type str")
    return string == string[::-1]


def make_palindrome(string: str) -> str:
    """Find the shortest palindrome that begins with a supplied string.

    Algorithm:
    - Find the longest suffix of the supplied string that is a palindrome.
    - Append to the end of the string the reverse of the prefix that comes
      before that palindromic suffix.

    Error handling:
    - Raises TypeError if input is not a string.
    - Raises ValueError if input is None.

    >>> make_palindrome('')
    ''
    >>> make_palindrome('cat')
    'catac'
    >>> make_palindrome('cata')
    'catac'
    >>> make_palindrome('race')
    'racecar'
    >>> make_palindrome('madam')
    'madam'
    """
    if string is None:
        raise ValueError("string cannot be None")

    if not isinstance(string, str):
        raise TypeError("string must be of type str")

    if string == "":
        return ""

    try:
        for i in range(len(string)):
            suffix = string[i:]
            if is_palindrome(suffix):
                prefix = string[:i]
                return string + prefix[::-1]
    except Exception as e:
        raise RuntimeError(f"unexpected error while building palindrome: {e}") from e

    # Fallback, though loop always returns for valid strings
    return string + string[:-1][::-1]
candidate = make_palindrome




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == ''
    assert candidate('x') == 'x'
    assert candidate('xyz') == 'xyzyx'
    assert candidate('xyx') == 'xyx'
    assert candidate('jerry') == 'jerryrrej'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
