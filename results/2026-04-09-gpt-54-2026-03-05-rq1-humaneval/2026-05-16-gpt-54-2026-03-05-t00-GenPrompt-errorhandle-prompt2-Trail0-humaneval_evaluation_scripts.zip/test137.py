
import unittest
import re
import sys
import math
import copy


def compare_one(a, b):
    """
    Create a function that takes integers, floats, or strings representing
    real numbers, and returns the larger variable in its given variable type.
    Return None if the values are equal.
    Note: If a real number is represented as a string, the floating point might be . or ,

    compare_one(1, 2.5) â 2.5
    compare_one(1, "2,3") â "2,3"
    compare_one("5,1", "6") â "6"
    compare_one("1", 1) â None
    """

    def to_number(x):
        try:
            if isinstance(x, str):
                x = x.replace(",", ".")
            return float(x)
        except (ValueError, TypeError):
            return None

    num_a = to_number(a)
    num_b = to_number(b)

    if num_a is None or num_b is None:
        return None

    if num_a > num_b:
        return a
    elif num_b > num_a:
        return b
    else:
        return None
candidate = compare_one


def check(candidate):

    # Check some simple cases
    assert candidate(1, 2) == 2
    assert candidate(1, 2.5) == 2.5
    assert candidate(2, 3) == 3
    assert candidate(5, 6) == 6
    assert candidate(1, "2,3") == "2,3"
    assert candidate("5,1", "6") == "6"
    assert candidate("1", "2") == "2"
    assert candidate("1", 1) == None

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
