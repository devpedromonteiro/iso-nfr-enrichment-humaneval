
import unittest
import re
import sys
import math
import copy


def count_up_to(n):
    """
    Return a list of all prime numbers less than n.

    Examples:
    count_up_to(5)  => [2, 3]
    count_up_to(11) => [2, 3, 5, 7]
    count_up_to(0)  => []
    count_up_to(20) => [2, 3, 5, 7, 11, 13, 17, 19]
    count_up_to(1)  => []
    count_up_to(18) => [2, 3, 5, 7, 11, 13, 17]
    """
    # Error handling: type check
    if not isinstance(n, int):
        raise TypeError("Input must be a non-negative integer.")

    # Error handling: value check
    if n < 0:
        raise ValueError("Input must be a non-negative integer.")

    # Edge cases
    if n < 2:
        return []

    primes = []

    for num in range(2, n):
        is_prime = True
        for divisor in range(2, int(num ** 0.5) + 1):
            if num % divisor == 0:
                is_prime = False
                break
        if is_prime:
            primes.append(num)

    return primes
candidate = count_up_to


def check(candidate):

    assert candidate(5) == [2,3]
    assert candidate(6) == [2,3,5]
    assert candidate(7) == [2,3,5]
    assert candidate(10) == [2,3,5,7]
    assert candidate(0) == []
    assert candidate(22) == [2,3,5,7,11,13,17,19]
    assert candidate(1) == []
    assert candidate(18) == [2,3,5,7,11,13,17]
    assert candidate(47) == [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43]
    assert candidate(101) == [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
