
import unittest
import re
import sys
import math
import copy


def encrypt(s):
    """
    Encrypt a string by rotating each lowercase alphabet letter forward by 4.
    
    Examples:
    encrypt('hi') -> 'lm'
    encrypt('asdfghjkl') -> 'ewhjklnop'
    encrypt('gf') -> 'kj'
    encrypt('et') -> 'ix'
    """
    try:
        if not isinstance(s, str):
            raise TypeError("Input must be a string.")
        
        if s == "":
            raise ValueError("Input string cannot be empty.")
        
        result = []
        
        for char in s:
            if not char.isalpha() or not char.islower():
                raise ValueError("Input must contain only lowercase alphabetic characters.")
            
            shifted = ord(char) + 4
            if shifted > ord('z'):
                shifted = ord('a') + (shifted - ord('z') - 1)
            
            result.append(chr(shifted))
        
        return ''.join(result)
    
    except TypeError as te:
        return f"TypeError: {te}"
    
    except ValueError as ve:
        return f"ValueError: {ve}"
    
    except Exception as e:
        return f"Unexpected error: {e}"
candidate = encrypt


def check(candidate):

    # Check some simple cases
    assert candidate('hi') == 'lm', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('asdfghjkl') == 'ewhjklnop', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('gf') == 'kj', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('et') == 'ix', "This prints if this assert fails 1 (good for debugging!)"

    assert candidate('faewfawefaewg')=='jeiajeaijeiak', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('hellomyfriend')=='lippsqcjvmirh', "This prints if this assert fails 2 (good for debugging!)"
    assert candidate('dxzdlmnilfuhmilufhlihufnmlimnufhlimnufhfucufh')=='hbdhpqrmpjylqmpyjlpmlyjrqpmqryjlpmqryjljygyjl', "This prints if this assert fails 3 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate('a')=='e', "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
