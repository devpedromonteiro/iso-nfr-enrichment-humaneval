
import unittest
import re
import sys
import math
import copy


def even_odd_palindrome(n):
    """
    Given a positive integer n, return a tuple that has the number of even and odd
    integer palindromes that fall within the range(1, n), inclusive.

    Example 1:
        Input: 3
        Output: (1, 2)

    Example 2:
        Input: 12
        Output: (4, 6)

    Note:
        1. 1 <= n <= 10^3
        2. returned tuple has the number of even and odd integer palindromes respectively.
    """

    # Type validation
    if not isinstance(n, int):
        raise TypeError("Input must be an integer.")

    # Value validation
    if n < 1 or n > 10**3:
        raise ValueError("Input must be in the range 1 to 10^3 inclusive.")

    even_count = 0
    odd_count = 0

    try:
        for num in range(1, n + 1):
            if str(num) == str(num)[::-1]:
                if num % 2 == 0:
                    even_count += 1
                else:
                    odd_count += 1
    except Exception as e:
        raise RuntimeError(f"An unexpected error occurred while processing: {e}")

    return (even_count, odd_count)
candidate = even_odd_palindrome


def check(candidate):

    # Check some simple cases
    assert candidate(123) == (8, 13)
    assert candidate(12) == (4, 6)
    assert candidate(3) == (1, 2)
    assert candidate(63) == (6, 8)
    assert candidate(25) == (5, 6)
    assert candidate(19) == (4, 6)
    assert candidate(9) == (4, 5), "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1) == (0, 1), "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
