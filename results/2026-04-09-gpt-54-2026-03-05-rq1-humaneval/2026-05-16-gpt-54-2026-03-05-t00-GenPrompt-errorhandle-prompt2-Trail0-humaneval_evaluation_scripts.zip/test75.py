
import unittest
import re
import sys
import math
import copy


def is_multiply_prime(a):
    """Return True if `a` is the product of exactly 3 prime numbers, else False.

    Error handling:
    - Returns False for non-integers
    - Returns False for integers less than 2
    - Catches unexpected errors safely
    """
    try:
        if not isinstance(a, int):
            raise TypeError("Input must be an integer.")
        if a < 2:
            raise ValueError("Input must be greater than 1.")

        def is_prime(n):
            if n < 2:
                return False
            for i in range(2, int(n ** 0.5) + 1):
                if n % i == 0:
                    return False
            return True

        primes = [p for p in range(2, a + 1) if is_prime(p)]

        for i in primes:
            for j in primes:
                for k in primes:
                    if i * j * k == a:
                        return True
        return False

    except TypeError as te:
        print(f"Type error: {te}")
        return False
    except ValueError as ve:
        print(f"Value error: {ve}")
        return False
    except Exception as e:
        print(f"Unexpected error: {e}")
        return False
candidate = is_multiply_prime


def check(candidate):

    assert candidate(5) == False
    assert candidate(30) == True
    assert candidate(8) == True
    assert candidate(10) == False
    assert candidate(125) == True
    assert candidate(3 * 5 * 7) == True
    assert candidate(3 * 6 * 7) == False
    assert candidate(9 * 9 * 9) == False
    assert candidate(11 * 9 * 9) == False
    assert candidate(11 * 13 * 7) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
