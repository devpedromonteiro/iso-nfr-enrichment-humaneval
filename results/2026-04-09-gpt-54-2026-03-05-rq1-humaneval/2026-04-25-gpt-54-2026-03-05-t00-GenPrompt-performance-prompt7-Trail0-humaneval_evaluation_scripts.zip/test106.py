
import unittest
import re
import sys
import math
import copy


def f(n):
    res = [0] * n
    fact = 1
    odd_sum = 0

    for i in range(1, n + 1):
        fact *= i
        odd_sum += i
        res[i - 1] = fact if i % 2 == 0 else odd_sum

    return res
candidate = f


def check(candidate):

    assert candidate(5) == [1, 2, 6, 24, 15]
    assert candidate(7) == [1, 2, 6, 24, 15, 720, 28]
    assert candidate(1) == [1]
    assert candidate(3) == [1, 2, 6]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
