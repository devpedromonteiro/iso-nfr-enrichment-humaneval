
import unittest



def unique(l: list):
    """Return sorted unique elements in a list

    >>> unique([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [0, 2, 3, 5, 9, 123]
    """
    # Type check for the input itself
    if not isinstance(l, list):
        raise TypeError(f"Expected a list, got {type(l).__name__}")

    try:
        # Remove duplicates
        unique_items = list(set(l))
    except TypeError as e:
        # Handles unhashable elements like nested lists/dicts
        raise TypeError("All elements in the list must be hashable") from e

    try:
        # Sort the unique elements
        return sorted(unique_items)
    except TypeError as e:
        # Handles elements that cannot be compared with each other
        raise TypeError("All elements in the list must be mutually comparable for sorting") from e
candidate = unique


class Test(unittest.TestCase):
    def test(self):
        assert candidate([9, 6, 4, 3, 8, 4, 9, 5, 123]) == [3, 4, 5, 6, 8, 9, 123]
        assert candidate([5, 3, 9, 4, 2, 6, 12, 3, 123]) == [2, 3, 4, 5, 6, 9, 12, 123]
        assert candidate([2, 6, 1, 7, 5, 6, 5, 3, 121]) == [1, 2, 3, 5, 6, 7, 121]
        assert candidate([3, 3, 10, 3, 8, 4, 4, 1, 128]) == [1, 3, 4, 8, 10, 128]
        assert candidate([7, 5, 5, 1, 7, 8, 5, 5, 121]) == [1, 5, 7, 8, 121]
        assert candidate([9, 5, 5, 2, 6, 8, 5, 5, 119]) == [2, 5, 6, 8, 9, 119]
        assert candidate([10, 3, 4, 6, 3, 6, 6, 5, 123]) == [3, 4, 5, 6, 10, 123]
        assert candidate([8, 2, 10, 3, 3, 7, 12, 2, 122]) == [2, 3, 7, 8, 10, 12, 122]
        assert candidate([10, 4, 8, 3, 4, 8, 14, 1, 119]) == [1, 3, 4, 8, 10, 14, 119]
        assert candidate([3, 5, 1, 7, 1, 8, 4, 5, 120]) == [1, 3, 4, 5, 7, 8, 120]
        assert candidate([5, 5, 2, 7, 1, 3, 6, 2, 124]) == [1, 2, 3, 5, 6, 7, 124]
        assert candidate([7, 6, 10, 5, 4, 8, 8, 5, 125]) == [4, 5, 6, 7, 8, 10, 125]
        assert candidate([3, 4, 5, 4, 6, 8, 5, 5, 126]) == [3, 4, 5, 6, 8, 126]
        assert candidate([10, 8, 2, 3, 6, 5, 4, 3, 120]) == [2, 3, 4, 5, 6, 8, 10, 120]
        assert candidate([2, 1, 4, 6, 7, 7, 14, 2, 120]) == [1, 2, 4, 6, 7, 14, 120]
        assert candidate([10, 7, 9, 5, 5, 1, 14, 1, 119]) == [1, 5, 7, 9, 10, 14, 119]
        assert candidate([6, 4, 5, 1, 3, 2, 10, 3, 122]) == [1, 2, 3, 4, 5, 6, 10, 122]
        assert candidate([6, 5, 1, 7, 8, 8, 6, 5, 122]) == [1, 5, 6, 7, 8, 122]
        assert candidate([6, 2, 9, 7, 8, 3, 12, 3, 126]) == [2, 3, 6, 7, 8, 9, 12, 126]
        assert candidate([2, 2, 5, 1, 7, 6, 8, 1, 122]) == [1, 2, 5, 6, 7, 8, 122]
        assert candidate([8, 4, 3, 5, 3, 7, 5, 2, 127]) == [2, 3, 4, 5, 7, 8, 127]
        assert candidate([5, 4, 10, 4, 6, 1, 4, 4, 126]) == [1, 4, 5, 6, 10, 126]
        assert candidate([8, 2, 3, 5, 1, 2, 13, 4, 122]) == [1, 2, 3, 4, 5, 8, 13, 122]
        assert candidate([3, 3, 2, 4, 1, 7, 10, 2, 120]) == [1, 2, 3, 4, 7, 10, 120]
        assert candidate([10, 6, 1, 6, 1, 3, 13, 2, 128]) == [1, 2, 3, 6, 10, 13, 128]
        assert candidate([7, 5, 1, 4, 5, 7, 8, 5, 120]) == [1, 4, 5, 7, 8, 120]
        assert candidate([6, 2, 2, 1, 4, 1, 13, 4, 120]) == [1, 2, 4, 6, 13, 120]
        assert candidate([2, 3, 3, 6, 6, 6, 6, 1, 128]) == [1, 2, 3, 6, 128]
        assert candidate([6, 1, 8, 1, 5, 5, 8, 5, 121]) == [1, 5, 6, 8, 121]
        assert candidate([1, 2, 1, 7, 1, 6, 13, 4, 124]) == [1, 2, 4, 6, 7, 13, 124]
        assert candidate([4, 7, 2, 2, 5, 8, 5, 3, 124]) == [2, 3, 4, 5, 7, 8, 124]
        assert candidate([4, 2, 2, 5, 5, 2, 7, 5, 120]) == [2, 4, 5, 7, 120]
        assert candidate([4, 1, 1, 4, 7, 1, 13, 5, 124]) == [1, 4, 5, 7, 13, 124]
        assert candidate([10, 1, 2, 1, 1, 2, 13, 3, 121]) == [1, 2, 3, 10, 13, 121]
        assert candidate([10, 7, 2, 2, 6, 6, 6, 3, 120]) == [2, 3, 6, 7, 10, 120]
        assert candidate([8, 4, 3, 1, 1, 4, 13, 2, 118]) == [1, 2, 3, 4, 8, 13, 118]
        assert candidate([4, 7, 3, 7, 6, 5, 5, 2, 125]) == [2, 3, 4, 5, 6, 7, 125]
        assert candidate([2, 8, 10, 1, 4, 8, 10, 5, 127]) == [1, 2, 4, 5, 8, 10, 127]
        assert candidate([8, 5, 3, 7, 4, 1, 12, 1, 127]) == [1, 3, 4, 5, 7, 8, 12, 127]
        assert candidate([1, 8, 7, 7, 3, 3, 6, 2, 123]) == [1, 2, 3, 6, 7, 8, 123]
        assert candidate([7, 2, 10, 4, 5, 4, 5, 5, 128]) == [2, 4, 5, 7, 10, 128]
        assert candidate([6, 7, 3, 3, 1, 4, 9, 2, 121]) == [1, 2, 3, 4, 6, 7, 9, 121]
        assert candidate([2, 6, 7, 7, 7, 8, 12, 2, 118]) == [2, 6, 7, 8, 12, 118]
        assert candidate([5, 8, 3, 4, 8, 4, 8, 3, 124]) == [3, 4, 5, 8, 124]
        assert candidate([9, 1, 1, 1, 1, 4, 12, 5, 128]) == [1, 4, 5, 9, 12, 128]
        assert candidate([5, 3, 5, 2, 3, 3, 9, 0, 123]) == [0, 2, 3, 5, 9, 123]
        assert candidate([5, 5, 1, 3, 5, 8, 9, 4, 119]) == [1, 3, 4, 5, 8, 9, 119]
        assert candidate([1, 8, 3, 1, 8, 8, 13, 4, 118]) == [1, 3, 4, 8, 13, 118]
        assert candidate([9, 6, 4, 5, 1, 6, 12, 4, 124]) == [1, 4, 5, 6, 9, 12, 124]
        assert candidate([3, 6, 1, 5, 4, 7, 14, 2, 121]) == [1, 2, 3, 4, 5, 6, 7, 14, 121]
        assert candidate([9, 2, 3, 4, 2, 3, 13, 1, 128]) == [1, 2, 3, 4, 9, 13, 128]
        assert candidate([4, 8, 6, 7, 8, 5, 8, 4, 124]) == [4, 5, 6, 7, 8, 124]
        assert candidate([2, 8, 2, 1, 2, 3, 11, 2, 125]) == [1, 2, 3, 8, 11, 125]
        assert candidate([5, 8, 3, 5, 3, 3, 14, 5, 128]) == [3, 5, 8, 14, 128]
        assert candidate([3, 2, 1, 4, 2, 5, 5, 4, 119]) == [1, 2, 3, 4, 5, 119]
        assert candidate([7, 6, 6, 3, 5, 8, 12, 1, 128]) == [1, 3, 5, 6, 7, 8, 12, 128]
        assert candidate([3, 7, 5, 1, 5, 2, 10, 5, 119]) == [1, 2, 3, 5, 7, 10, 119]
        assert candidate([10, 8, 5, 2, 7, 2, 5, 2, 128]) == [2, 5, 7, 8, 10, 128]
        assert candidate([7, 7, 7, 6, 8, 8, 12, 1, 127]) == [1, 6, 7, 8, 12, 127]
        assert candidate([9, 8, 4, 2, 1, 2, 6, 1, 122]) == [1, 2, 4, 6, 8, 9, 122]
        assert candidate([10, 7, 4, 4, 7, 1, 11, 2, 122]) == [1, 2, 4, 7, 10, 11, 122]
        assert candidate([6, 4, 6, 2, 5, 1, 10, 2, 121]) == [1, 2, 4, 5, 6, 10, 121]
        assert candidate([2, 2, 5, 3, 7, 7, 11, 3, 119]) == [2, 3, 5, 7, 11, 119]
        assert candidate([7, 6, 7, 5, 1, 2, 5, 1, 128]) == [1, 2, 5, 6, 7, 128]
        assert candidate([10, 8, 7, 2, 1, 2, 4, 5, 124]) == [1, 2, 4, 5, 7, 8, 10, 124]
        assert candidate([5, 5, 1, 1, 5, 8, 6, 1, 122]) == [1, 5, 6, 8, 122]
        assert candidate([10, 3, 2, 1, 1, 2, 5, 4, 124]) == [1, 2, 3, 4, 5, 10, 124]
        assert candidate([10, 4, 8, 7, 6, 7, 5, 4, 123]) == [4, 5, 6, 7, 8, 10, 123]
        assert candidate([2, 7, 6, 1, 3, 1, 4, 4, 119]) == [1, 2, 3, 4, 6, 7, 119]
        assert candidate([9, 4, 6, 3, 1, 5, 8, 3, 121]) == [1, 3, 4, 5, 6, 8, 9, 121]
        assert candidate([5, 1, 4, 2, 4, 4, 8, 5, 123]) == [1, 2, 4, 5, 8, 123]
        assert candidate([10, 7, 3, 1, 4, 5, 5, 4, 123]) == [1, 3, 4, 5, 7, 10, 123]
        assert candidate([4, 8, 8, 7, 5, 1, 10, 4, 118]) == [1, 4, 5, 7, 8, 10, 118]
        assert candidate([2, 3, 5, 4, 4, 8, 4, 1, 118]) == [1, 2, 3, 4, 5, 8, 118]
        assert candidate([9, 6, 2, 2, 7, 2, 7, 3, 118]) == [2, 3, 6, 7, 9, 118]
        assert candidate([10, 4, 6, 3, 4, 2, 13, 5, 120]) == [2, 3, 4, 5, 6, 10, 13, 120]
        assert candidate([6, 8, 6, 1, 2, 1, 4, 5, 126]) == [1, 2, 4, 5, 6, 8, 126]
        assert candidate([3, 4, 9, 6, 3, 2, 7, 1, 119]) == [1, 2, 3, 4, 6, 7, 9, 119]
        assert candidate([4, 2, 9, 7, 7, 2, 9, 1, 123]) == [1, 2, 4, 7, 9, 123]
        assert candidate([4, 1, 5, 2, 1, 3, 4, 1, 118]) == [1, 2, 3, 4, 5, 118]
        assert candidate([7, 4, 2, 3, 5, 6, 12, 3, 120]) == [2, 3, 4, 5, 6, 7, 12, 120]
        assert candidate([6, 4, 7, 5, 5, 5, 8, 3, 120]) == [3, 4, 5, 6, 7, 8, 120]
        assert candidate([2, 3, 7, 1, 4, 1, 14, 1, 120]) == [1, 2, 3, 4, 7, 14, 120]
        assert candidate([9, 1, 5, 5, 6, 3, 14, 4, 123]) == [1, 3, 4, 5, 6, 9, 14, 123]
        assert candidate([8, 5, 9, 4, 3, 7, 12, 3, 123]) == [3, 4, 5, 7, 8, 9, 12, 123]
        assert candidate([4, 4, 5, 3, 3, 8, 11, 3, 126]) == [3, 4, 5, 8, 11, 126]
        assert candidate([9, 4, 8, 6, 2, 4, 14, 3, 125]) == [2, 3, 4, 6, 8, 9, 14, 125]
        assert candidate([7, 4, 7, 3, 4, 5, 4, 4, 126]) == [3, 4, 5, 7, 126]
        assert candidate([3, 7, 2, 6, 1, 3, 8, 1, 124]) == [1, 2, 3, 6, 7, 8, 124]
        assert candidate([3, 6, 10, 5, 2, 8, 8, 3, 118]) == [2, 3, 5, 6, 8, 10, 118]
        assert candidate([1, 2, 9, 6, 3, 7, 5, 4, 122]) == [1, 2, 3, 4, 5, 6, 7, 9, 122]
        assert candidate([1, 8, 5, 1, 1, 3, 10, 5, 126]) == [1, 3, 5, 8, 10, 126]
        assert candidate([3, 1, 8, 3, 3, 4, 9, 2, 123]) == [1, 2, 3, 4, 8, 9, 123]
        assert candidate([8, 4, 4, 2, 2, 6, 7, 4, 128]) == [2, 4, 6, 7, 8, 128]
        assert candidate([1, 5, 7, 5, 3, 4, 10, 3, 123]) == [1, 3, 4, 5, 7, 10, 123]
        assert candidate([8, 4, 3, 7, 5, 2, 4, 5, 125]) == [2, 3, 4, 5, 7, 8, 125]
        assert candidate([6, 8, 2, 5, 5, 8, 8, 5, 118]) == [2, 5, 6, 8, 118]
        assert candidate([2, 4, 2, 5, 1, 1, 8, 1, 125]) == [1, 2, 4, 5, 8, 125]
        assert candidate([7, 3, 8, 6, 6, 5, 8, 4, 119]) == [3, 4, 5, 6, 7, 8, 119]
        assert candidate([4, 2, 7, 7, 2, 7, 13, 1, 128]) == [1, 2, 4, 7, 13, 128]
        assert candidate([4, 5, 6, 2, 7, 2, 9, 3, 125]) == [2, 3, 4, 5, 6, 7, 9, 125]
        assert candidate([8, 5, 10, 7, 2, 5, 8, 4, 122]) == [2, 4, 5, 7, 8, 10, 122]
        assert candidate([3, 7, 2, 5, 8, 2, 11, 1, 121]) == [1, 2, 3, 5, 7, 8, 11, 121]
        assert candidate([9, 3, 10, 6, 8, 6, 12, 2, 121]) == [2, 3, 6, 8, 9, 10, 12, 121]
        assert candidate([7, 5, 10, 7, 2, 7, 9, 2, 119]) == [2, 5, 7, 9, 10, 119]
        assert candidate([5, 2, 1, 4, 3, 4, 11, 3, 119]) == [1, 2, 3, 4, 5, 11, 119]
        assert candidate([2, 6, 9, 1, 4, 1, 10, 2, 122]) == [1, 2, 4, 6, 9, 10, 122]
        assert candidate([9, 4, 3, 2, 2, 3, 11, 1, 119]) == [1, 2, 3, 4, 9, 11, 119]
        assert candidate([1, 4, 6, 1, 8, 5, 12, 5, 128]) == [1, 4, 5, 6, 8, 12, 128]
        assert candidate([2, 3, 6, 2, 7, 3, 10, 5, 127]) == [2, 3, 5, 6, 7, 10, 127]
        assert candidate([8, 5, 2, 2, 7, 3, 13, 2, 128]) == [2, 3, 5, 7, 8, 13, 128]
        assert candidate([10, 6, 6, 2, 2, 1, 6, 3, 125]) == [1, 2, 3, 6, 10, 125]
        assert candidate([6, 6, 6, 7, 5, 4, 13, 4, 119]) == [4, 5, 6, 7, 13, 119]
        assert candidate([1, 2, 6, 6, 7, 7, 8, 5, 128]) == [1, 2, 5, 6, 7, 8, 128]
        assert candidate([5, 4, 8, 2, 6, 8, 12, 3, 123]) == [2, 3, 4, 5, 6, 8, 12, 123]
        assert candidate([2, 1, 5, 1, 5, 3, 11, 2, 122]) == [1, 2, 3, 5, 11, 122]
        assert candidate([1, 3, 8, 2, 7, 8, 5, 3, 128]) == [1, 2, 3, 5, 7, 8, 128]
        assert candidate([10, 5, 7, 1, 2, 7, 10, 3, 128]) == [1, 2, 3, 5, 7, 10, 128]
        assert candidate([6, 5, 5, 4, 3, 2, 8, 3, 119]) == [2, 3, 4, 5, 6, 8, 119]
        assert candidate([5, 6, 5, 1, 6, 3, 12, 3, 123]) == [1, 3, 5, 6, 12, 123]
        assert candidate([6, 8, 9, 6, 5, 3, 11, 5, 124]) == [3, 5, 6, 8, 9, 11, 124]
        assert candidate([8, 6, 4, 5, 2, 7, 12, 4, 119]) == [2, 4, 5, 6, 7, 8, 12, 119]
        assert candidate([6, 8, 5, 2, 8, 1, 13, 2, 122]) == [1, 2, 5, 6, 8, 13, 122]
        assert candidate([8, 3, 10, 6, 8, 1, 5, 2, 122]) == [1, 2, 3, 5, 6, 8, 10, 122]
        assert candidate([7, 8, 8, 2, 8, 6, 9, 5, 125]) == [2, 5, 6, 7, 8, 9, 125]
        assert candidate([1, 8, 3, 7, 3, 1, 12, 1, 122]) == [1, 3, 7, 8, 12, 122]

if __name__ == '__main__':
    unittest.main()
