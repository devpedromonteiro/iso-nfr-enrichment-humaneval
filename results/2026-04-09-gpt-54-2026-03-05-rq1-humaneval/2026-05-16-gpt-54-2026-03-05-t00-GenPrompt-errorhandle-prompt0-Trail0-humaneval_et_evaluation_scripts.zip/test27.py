
import unittest



def flip_case(string: str) -> str:
    """For a given string, flip lowercase characters to uppercase and uppercase to lowercase.

    >>> flip_case('Hello')
    'hELLO'
    """
    # Type validation
    if string is None:
        raise ValueError("Input cannot be None.")

    if not isinstance(string, str):
        raise TypeError(f"Expected a string, got {type(string).__name__} instead.")

    try:
        # Main logic
        return string.swapcase()
    except Exception as exc:
        # Catch unexpected errors and re-raise with more context
        raise RuntimeError(f"Failed to flip case for input: {string!r}") from exc
candidate = flip_case


class Test(unittest.TestCase):
    def test(self):
        assert candidate("=Uft>^xAJt~M") == '=uFT>^XajT~m'
        assert candidate("CsgXBCATeQmYHhTMBoGuEM dGUDqazbndCFMtLL vmY") == 'cSGxbcatEqMyhHtmbOgUem DgudQAZBNDcfmTll VMy'
        assert candidate("w") == 'W'
        assert candidate("eIgaNO JtyWwkDSdVTrVoqClhNFrHNqDBl UInCVrviH") == 'EiGAno jTYwWKdsDvtRvOQcLHnfRhnQdbL uiNcvRVIh'
        assert candidate("FdR") == 'fDr'
        assert candidate("tR#Et^#") == 'Tr#eT^#'
        assert candidate("L@j:tM-_?Fgc") == 'l@J:Tm-_?fGC'
        assert candidate("ez") == 'EZ'
        assert candidate("F_LHcfxbO") == 'f_lhCFXBo'
        assert candidate("xDFZwXjexGGcNsQGWKFfWrVIoHZYFFhWCRQJpnfL") == 'XdfzWxJEXggCnSqgwkfFwRviOhzyffHwcrqjPNFl'
        assert candidate("CnpipxUmlSdCSmHdbyDoMlbssWpLHcyKnJlsulPxWNPHi") == 'cNPIPXuMLsDcsMhDBYdOmLBSSwPlhCYkNjLSULpXwnphI'
        assert candidate("vqp") == 'VQP'
        assert candidate("f<SH") == 'F<sh'
        assert candidate("tBDUC ZKFZKtFVvqmhzUltjFzOWNXldpEHOAKJIp") == 'Tbduc zkfzkTfvVQMHZuLTJfZownxLDPehoakjiP'
        assert candidate("+>gY~") == '+>Gy~'
        assert candidate("BlmIOOJIkOnKWOtKuudPt  sUUPPNZZbQKiIHsNzFe") == 'bLMioojiKoNkwoTkUUDpT  SuuppnzzBqkIihSnZfE'
        assert candidate("JXCxNsvL") == 'jxcXnSVl'
        assert candidate("gq") == 'GQ'
        assert candidate("v") == 'V'
        assert candidate("RkocroIYw pMJxfpXxLucXAIvDjwlkIeJBCXJsxMAH") == 'rKOCROiyW PmjXFPxXlUCxaiVdJWLKiEjbcxjSXmah'
        assert candidate("JVKSQnhMMEPEXaJBBgEbTmkMCSWcebmFckHoj") == 'jvksqNHmmepexAjbbGeBtMKmcswCEBMfCKhOJ'
        assert candidate("gif") == 'GIF'
        assert candidate("g gCvDFeq NvBvqUNjjIldrkmFZCCTkJACipqozhZZ") == 'G GcVdfEQ nVbVQunJJiLDRKMfzcctKjacIPQOZHzz'
        assert candidate("rPxMsdbinpIxuZkSMNhmkYSJ DaYPCubXFgtuGbdtUXBR") == 'RpXmSDBINPiXUzKsmnHMKysj dAypcUBxfGTUgBDTuxbr'
        assert candidate("vzhEUikjmBtxkJcpaTRiuEurpoJXgLCmmSGttGsfOv") == 'VZHeuIKJMbTXKjCPAtrIUeURPOjxGlcMMsgTTgSFoV'
        assert candidate("ishBtMJcStzZVLuiiCdRPaVgPIsPMZkvSjJna") == 'ISHbTmjCsTZzvlUIIcDrpAvGpiSpmzKVsJjNA'
        assert candidate("qn") == 'QN'
        assert candidate("pCKgJaaQZHzRwxdwpqCZvoRlbvqLfrtdHlSrrqyl") == 'PckGjAAqzhZrWXDWPQczVOrLBVQlFRTDhLsRRQYL'
        assert candidate("k") == 'K'
        assert candidate("xOEweGnFamRzetSvZkSCZbKrjxTcGdWzTWBsbETPk auL") == 'XoeWEgNfAMrZETsVzKsczBkRJXtCgDwZtwbSBetpK AUl'
        assert candidate("WVlvlJraPwOUwyOOhbDSADCInroOCMzpaSnUubOH") == 'wvLVLjRApWouWYooHBdsadciNROocmZPAsNuUBoh'
        assert candidate("lb") == 'LB'
        assert candidate("AjUCdQIZXemhRaQZOkgJVvpYPUDPNmjKIPhQzZmAQIX") == 'aJucDqizxEMHrAqzoKGjvVPypudpnMJkipHqZzMaqix'
        assert candidate("~S*VzmzMvqpR") == '~s*vZMZmVQPr'
        assert candidate("BBx~!|/^") == 'bbX~!|/^'
        assert candidate("zg") == 'ZG'
        assert candidate("kydGvfiOVOgOxStzNHakGRVZUzaeQtEDgWqRJJpfe") == 'KYDgVFIovoGoXsTZnhAKgrvzuZAEqTedGwQrjjPFE'
        assert candidate("lhp") == 'LHP'
        assert candidate("jfu") == 'JFU'
        assert candidate("jbTsYZxZTBwOTezydywllWFUrvTWBHXpvMsIY") == 'JBtSyzXztbWotEZYDYWLLwfuRVtwbhxPVmSiy'
        assert candidate("vVvmxSIyqihZXowcxzQxqSKxpnCpSSkCXeRBXTHyMl") == 'VvVMXsiYQIHzxOWCXZqXQskXPNcPssKcxErbxthYmL'
        assert candidate("QwnaAlMgJSZcTaBgprrbFezVmYCdMsWyxskaPqenOH") == 'qWNAaLmGjszCtAbGPRRBfEZvMycDmSwYXSKApQENoh'
        assert candidate("o=c_/?QU~q") == 'O=C_/?qu~Q'
        assert candidate("ds") == 'DS'
        assert candidate("zdp") == 'ZDP'
        assert candidate("hd") == 'HD'
        assert candidate("jBVXuMXKDuzctqITdcXyikINVSCmKdXbcxhnT") == 'JbvxUmxkdUZCTQitDCxYIKinvscMkDxBCXHNt'
        assert candidate("ugd") == 'UGD'
        assert candidate("LAszIcfMteqqYNwFzpJQolmECkmMmMLiyWgtidbdJUaaA") == 'laSZiCFmTEQQynWfZPjqOLMecKMmMmlIYwGTIDBDjuAAa'
        assert candidate("RbUFL/M") == 'rBufl/m'
        assert candidate('Hello!') == 'hELLO!'
        assert candidate("n") == 'N'
        assert candidate("WF~h/oG^") == 'wf~H/Og^'
        assert candidate("pzp") == 'PZP'
        assert candidate("+K|eG") == '+k|Eg'
        assert candidate("dzpm pZUpHNjdpIMw BmQd otqoasshKCFtpf") == 'DZPM PzuPhnJDPimW bMqD OTQOASSHkcfTPF'
        assert candidate("xmx") == 'XMX'
        assert candidate("*~=I") == '*~=i'
        assert candidate("d!C&e?Gl") == 'D!c&E?gL'
        assert candidate("QNANcSJRDzmQFD RdGOsUHyADvXPqBWXQQuDzqlQkYucV") == 'qnanCsjrdZMqfd rDgoSuhYadVxpQbwxqqUdZQLqKyUCv'
        assert candidate("#QSfHF:$&%") == '#qsFhf:$&%'
        assert candidate("?fTt><k") == '?FtT><K'
        assert candidate("rpd") == 'RPD'
        assert candidate("PnHqJfQuNAYhthlFbMAQuoFHTWWNssJuqEsyxCgEkcDUh") == 'pNhQjFqUnayHTHLfBmaqUOfhtwwnSSjUQeSYXcGeKCduH'
        assert candidate("j") == 'J'
        assert candidate("n|gOUwY~ruFD") == 'N|GouWy~RUfd'
        assert candidate("q") == 'Q'
        assert candidate("EELIBxoyBKMKLqdqCoaxKsaHDhVSyVFZKwIUD") == 'eelibXOYbkmklQDQcOAXkSAhdHvsYvfzkWiud'
        assert candidate("bRIcNFlGQxbUHHeXuOVT ZqmqxQEmgBrvEWGTokoHY") == 'BriCnfLgqXBuhhExUovt zQMQXqeMGbRVewgtOKOhy'
        assert candidate("a") == 'A'
        assert candidate("pez") == 'PEZ'
        assert candidate(" rWGZAlqccMZVGnZysgdSulExviJwKbbHiwV") == ' RwgzaLQCCmzvgNzYSGDsULeXVIjWkBBhIWv'
        assert candidate("SURWTdsMjFvXSnFJFytHymfgEiDcmZREKgXr") == 'surwtDSmJfVxsNfjfYThYMFGeIdCMzrekGxR'
        assert candidate("u") == 'U'
        assert candidate("~zUkkeFy") == '~ZuKKEfY'
        assert candidate("h*U*") == 'H*u*'
        assert candidate("yr") == 'YR'
        assert candidate("agwaVXOuq") == 'AGWAvxoUQ'
        assert candidate("p AAnXuPeBbeTnNHDDLhugfDzDoSnd KMLFYIppPFKSX") == 'P aaNxUpEbBEtNnhddlHUGFdZdOsND kmlfyiPPpfksx'
        assert candidate("d<gG") == 'D<Gg'
        assert candidate("oz") == 'OZ'
        assert candidate("fbc") == 'FBC'
        assert candidate("tu") == 'TU'
        assert candidate("NyMDTZqvnnQa TTfqNoInjRIaYeFtiLyYLvQJ") == 'nYmdtzQVNNqA ttFQnOiNJriAyEfTIlYylVqj'
        assert candidate("x") == 'X'
        assert candidate("RvQa%") == 'rVqA%'
        assert candidate("YpaJZKDmVIGTvH MGarufiqirhCbiKMToFjBUzotRH") == 'yPAjzkdMvigtVh mgARUFIQIRHcBIkmtOfJbuZOTrh'
        assert candidate("u=>c") == 'U=>C'
        assert candidate("&b_H") == '&B_h'
        assert candidate("$<y+") == '$<Y+'
        assert candidate("dWqb") == 'DwQB'
        assert candidate("xv") == 'XV'
        assert candidate("/zl") == '/ZL'
        assert candidate('') == ''
        assert candidate("lif") == 'LIF'
        assert candidate("pgj") == 'PGJ'
        assert candidate("DyMMLvwZlYNhTOjDhnsHoTNqrTRWSrFYFWaoimDxFFaiM") == 'dYmmlVWzLynHtoJdHNShOtnQRtrwsRfyfwAOIMdXffAIm'
        assert candidate("v*qeoJBLg<t&") == 'V*QEOjblG<T&'
        assert candidate("nVVa|^lsy") == 'NvvA|^LSY'
        assert candidate("MBsxRCmHzEltumRjfTmdmbspQjxySYLAQNAZPRyV") == 'mbSXrcMhZeLTUMrJFtMDMBSPqJXYsylaqnazprYv'
        assert candidate("NpFjCypU YkPuBLEfXMThREegzPXXT IgBpeyz ") == 'nPfJcYPu yKpUbleFxmtHreEGZpxxt iGbPEYZ '
        assert candidate("pG<wNz>Y/") == 'Pg<WnZ>y/'
        assert candidate("uRCphX cuIYmaTkfFCGBJrVUsjMustykG WqKcSc") == 'UrcPHx CUiyMAtKFfcgbjRvuSJmUSTYKg wQkCsC'
        assert candidate("haP!tD") == 'HAp!Td'
        assert candidate("NwHrkzMqZmOzyNBPhYuSIdBfm CjlBUkCXIeiH") == 'nWhRKZmQzMoZYnbpHyUsiDbFM cJLbuKcxiEIh'
        assert candidate("|l&:hE%&") == '|L&:He%&'
        assert candidate("wdWVLKaFVwzCSyfAbTLGDiVKlkTUSWhVBTcWaNoUaq") == 'WDwvlkAfvWZcsYFaBtlgdIvkLKtuswHvbtCwAnOuAQ'
        assert candidate("+$#d") == '+$#D'
        assert candidate("bq") == 'BQ'
        assert candidate('These violent delights have violent ends') == 'tHESE VIOLENT DELIGHTS HAVE VIOLENT ENDS'
        assert candidate("d") == 'D'
        assert candidate("rZLVWNROgXWjbDAxzXaGYLOqVnpKiMJLXAKpM") == 'RzlvwnroGxwJBdaXZxAgyloQvNPkImjlxakPm'
        assert candidate("r") == 'R'
        assert candidate("mka") == 'MKA'
        assert candidate("dTpPnvaddXtfDXGDaEPDaGkpESXxOLdIKySLcPdpU") == 'DtPpNVADDxTFdxgdAepdAgKPesxXolDikYslCpDPu'
        assert candidate("fy") == 'FY'
        assert candidate("lW|tBEn~^ri<") == 'Lw|TbeN~^RI<'
        assert candidate("qnwYFneaoNWuSxNXocoMEXDwcqVoGZdRInOEbC") == 'QNWyfNEAOnwUsXnxOCOmexdWCQvOgzDriNoeBc'
        assert candidate("hzy") == 'HZY'
        assert candidate("sqopQROxzNCHvAlaUuwHvOMsScjnCpmswtyi") == 'SQOPqroXZnchVaLAuUWhVomSsCJNcPMSWTYI'
        assert candidate("&Py@") == '&pY@'
        assert candidate("Q<x") == 'q<X'
        assert candidate("&|EuiuG") == '&|eUIUg'
        assert candidate("gO#yDMhnV") == 'Go#YdmHNv'
        assert candidate("GRb|DCu") == 'grB|dcU'
        assert candidate("pFEAIYkn|") == 'PfeaiyKN|'

if __name__ == '__main__':
    unittest.main()
