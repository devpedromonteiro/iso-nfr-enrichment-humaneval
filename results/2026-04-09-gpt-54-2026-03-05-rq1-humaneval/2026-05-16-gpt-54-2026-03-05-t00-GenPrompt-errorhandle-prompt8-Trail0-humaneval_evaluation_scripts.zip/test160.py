
import unittest
import re
import sys
import math
import copy


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and 
    the second list is a list of integers. Use the two given lists to build the algebraic 
    expression and return the evaluation of this expression.

    The basic algebra operations:
    Addition ( + ) 
    Subtraction ( - ) 
    Multiplication ( * ) 
    Floor division ( // ) 
    Exponentiation ( ** ) 
    """
    if len(operator) != len(operand) - 1:
        raise ValueError("operator list length must be operand list length minus one")

    valid_ops = {"+", "-", "*", "//", "**"}
    if any(op not in valid_ops for op in operator):
        raise ValueError("operator list contains invalid operator")

    expr = str(operand[0])
    for op, num in zip(operator, operand[1:]):
        expr += f" {op} {num}"

    try:
        return eval(expr)
    except ZeroDivisionError:
        raise ZeroDivisionError("division by zero in algebra expression")
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
