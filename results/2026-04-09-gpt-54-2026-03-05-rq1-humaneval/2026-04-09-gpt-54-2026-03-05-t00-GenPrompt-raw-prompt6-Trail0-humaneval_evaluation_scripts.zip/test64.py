
import unittest
import re
import sys
import math
import copy


FIX = """
Add more test cases.
"""

def check(candidate):
    # Basic examples
    assert candidate("abcde") == 2
    assert candidate("ACEDY") == 3

    # No vowels
    assert candidate("bcdfg") == 0
    assert candidate("rhythm") == 0

    # Standard vowels, mixed case
    assert candidate("aeiou") == 5
    assert candidate("AEIOU") == 5
    assert candidate("AaEeIiOoUu") == 10

    # 'y' counts only at the end
    assert candidate("y") == 1
    assert candidate("Y") == 1
    assert candidate("boy") == 2
    assert candidate("BOY") == 2
    assert candidate("yellow") == 2
    assert candidate("YELLOW") == 2
    assert candidate("rhythmy") == 1
    assert candidate("sky") == 1
    assert candidate("syzygy") == 1

    # Words ending with vowel and containing internal y
    assert candidate("happy") == 2
    assert candidate("Happy") == 2
    assert candidate("mystery") == 2
    assert candidate("MYSTERY") == 2

    # Edge cases
    assert candidate("") == 0
    assert candidate("b") == 0
    assert candidate("a") == 1
    assert candidate("why") == 1
candidate = check


def check(candidate):

    # Check some simple cases
    assert candidate("abcde") == 2, "Test 1"
    assert candidate("Alone") == 3, "Test 2"
    assert candidate("key") == 2, "Test 3"
    assert candidate("bye") == 1, "Test 4"
    assert candidate("keY") == 2, "Test 5"
    assert candidate("bYe") == 1, "Test 6"
    assert candidate("ACEDY") == 3, "Test 7"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
