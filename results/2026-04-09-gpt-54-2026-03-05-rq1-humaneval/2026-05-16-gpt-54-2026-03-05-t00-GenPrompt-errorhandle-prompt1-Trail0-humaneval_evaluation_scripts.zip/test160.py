
import unittest
import re
import sys
import math
import copy


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and 
    the second list is a list of integers. Use the two given lists to build the algebraic 
    expression and return the evaluation of this expression.

    Supported operations:
    +   Addition
    -   Subtraction
    *   Multiplication
    //  Floor division
    **  Exponentiation
    """
    try:
        if not isinstance(operator, list) or not isinstance(operand, list):
            raise TypeError("Both operator and operand must be lists.")

        if len(operator) != len(operand) - 1:
            raise ValueError("Length of operator must be exactly one less than length of operand.")

        if len(operator) < 1 or len(operand) < 2:
            raise ValueError("Operator must have at least one item and operand at least two items.")

        valid_ops = {"+", "-", "*", "//", "**"}
        if any(op not in valid_ops for op in operator):
            raise ValueError("Operator list contains unsupported operation.")

        if any(not isinstance(x, int) or x < 0 for x in operand):
            raise ValueError("Operand list must contain only non-negative integers.")

        expression = str(operand[0])
        for op, num in zip(operator, operand[1:]):
            expression += f" {op} {num}"

        return eval(expression)

    except ZeroDivisionError:
        return "Error: Division by zero."
    except TypeError as e:
        return f"Type Error: {e}"
    except ValueError as e:
        return f"Value Error: {e}"
    except Exception as e:
        return f"Unexpected Error: {e}"
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
