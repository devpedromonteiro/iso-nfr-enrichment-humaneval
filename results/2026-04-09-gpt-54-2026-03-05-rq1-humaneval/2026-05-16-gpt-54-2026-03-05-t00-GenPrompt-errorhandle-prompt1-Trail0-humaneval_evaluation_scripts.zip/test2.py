
import unittest
import re
import sys
import math
import copy



def truncate_number(number: float) -> float:
    """Given a positive floating point number, return its decimal part.

    The decimal part is the leftover after removing the integer part.

    >>> truncate_number(3.5)
    0.5
    """
    try:
        if not isinstance(number, (int, float)):
            raise TypeError("Input must be an int or float.")
        if number < 0:
            raise ValueError("Input must be a positive number.")

        return number - int(number)

    except TypeError as e:
        print(f"Type error: {e}")
        raise

    except ValueError as e:
        print(f"Value error: {e}")
        raise

    except Exception as e:
        print(f"Unexpected error: {e}")
        raise
candidate = truncate_number




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(3.5) == 0.5
    assert abs(candidate(1.33) - 0.33) < 1e-6
    assert abs(candidate(123.456) - 0.456) < 1e-6


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
