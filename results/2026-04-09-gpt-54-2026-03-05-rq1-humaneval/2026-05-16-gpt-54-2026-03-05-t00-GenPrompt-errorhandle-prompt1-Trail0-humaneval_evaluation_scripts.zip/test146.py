
import unittest
import re
import sys
import math
import copy


def specialFilter(nums):
    """
    Returns the count of numbers greater than 10 whose first and last digits are both odd.
    Includes basic exception handling for invalid inputs.
    """
    try:
        if not isinstance(nums, (list, tuple)):
            raise TypeError("Input must be a list or tuple of numbers.")

        count = 0

        for num in nums:
            try:
                if not isinstance(num, (int, float)):
                    continue

                if num <= 10:
                    continue

                n = str(abs(int(num)))
                first_digit = int(n[0])
                last_digit = int(n[-1])

                if first_digit % 2 == 1 and last_digit % 2 == 1:
                    count += 1

            except (ValueError, TypeError):
                continue

        return count

    except Exception as e:
        print(f"Error: {e}")
        return 0
candidate = specialFilter


def check(candidate):

    # Check some simple cases
    assert candidate([5, -2, 1, -5]) == 0  
    assert candidate([15, -73, 14, -15]) == 1
    assert candidate([33, -2, -3, 45, 21, 109]) == 2
    assert candidate([43, -12, 93, 125, 121, 109]) == 4
    assert candidate([71, -2, -33, 75, 21, 19]) == 3


    # Check some edge cases that are easy to work out by hand.
    assert candidate([1]) == 0              
    assert candidate([]) == 0                   



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
