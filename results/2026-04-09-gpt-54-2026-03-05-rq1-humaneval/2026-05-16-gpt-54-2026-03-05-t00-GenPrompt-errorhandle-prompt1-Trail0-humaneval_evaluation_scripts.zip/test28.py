
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def concatenate(strings: List[str]) -> str:
    """Concatenate list of strings into a single string.

    >>> concatenate([])
    ''
    >>> concatenate(['a', 'b', 'c'])
    'abc'
    """
    try:
        if strings is None:
            raise ValueError("Input cannot be None")
        if not isinstance(strings, list):
            raise TypeError("Input must be a list of strings")
        if not all(isinstance(s, str) for s in strings):
            raise TypeError("All elements must be strings")
        return "".join(strings)

    except TypeError as e:
        raise TypeError(f"Type error in concatenate: {e}") from e

    except ValueError as e:
        raise ValueError(f"Value error in concatenate: {e}") from e

    except Exception as e:
        raise RuntimeError(f"Unexpected error in concatenate: {e}") from e
candidate = concatenate




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == ''
    assert candidate(['x', 'y', 'z']) == 'xyz'
    assert candidate(['x', 'y', 'z', 'w', 'k']) == 'xyzwk'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
