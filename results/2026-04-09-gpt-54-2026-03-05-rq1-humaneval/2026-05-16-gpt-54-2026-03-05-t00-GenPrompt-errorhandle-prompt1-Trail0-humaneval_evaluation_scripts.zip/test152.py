
import unittest
import re
import sys
import math
import copy


def compare(game, guess):
    try:
        if len(game) != len(guess):
            raise ValueError("Both lists must have the same length.")
        return [abs(g - h) for g, h in zip(game, guess)]
    
    except TypeError:
        return "Invalid input: both arguments must be iterable collections of numbers."
    
    except ValueError as ve:
        return str(ve)
    
    except Exception as e:
        return f"An unexpected error occurred: {e}"
candidate = compare


def check(candidate):

    # Check some simple cases
    assert candidate([1,2,3,4,5,1],[1,2,3,4,2,-2])==[0,0,0,0,3,3], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([0,0,0,0,0,0],[0,0,0,0,0,0])==[0,0,0,0,0,0], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,2,3],[-1,-2,-3])==[2,4,6], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,2,3,5],[-1,2,3,4])==[2,0,0,1], "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
