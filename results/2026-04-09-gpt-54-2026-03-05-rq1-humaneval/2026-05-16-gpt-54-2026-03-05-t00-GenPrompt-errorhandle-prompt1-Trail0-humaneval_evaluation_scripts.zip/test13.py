
import unittest
import re
import sys
import math
import copy



def greatest_common_divisor(a: int, b: int) -> int:
    """Return the greatest common divisor of two integers a and b.

    >>> greatest_common_divisor(3, 5)
    1
    >>> greatest_common_divisor(25, 15)
    5
    """
    try:
        if not isinstance(a, int) or not isinstance(b, int):
            raise TypeError("Both arguments must be integers.")

        a, b = abs(a), abs(b)

        if a == 0 and b == 0:
            raise ValueError("GCD is undefined for a = 0 and b = 0.")

        while b != 0:
            a, b = b, a % b

        return a

    except TypeError as e:
        print(f"Type error: {e}")
        raise

    except ValueError as e:
        print(f"Value error: {e}")
        raise

    except Exception as e:
        print(f"Unexpected error: {e}")
        raise
candidate = greatest_common_divisor




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(3, 7) == 1
    assert candidate(10, 15) == 5
    assert candidate(49, 14) == 7
    assert candidate(144, 60) == 12


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
