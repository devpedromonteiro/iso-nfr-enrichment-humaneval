
import unittest
import re
import sys
import math
import copy


def get_odd_collatz(n):
    """
    Given a positive integer n, return a sorted list containing the odd numbers
    in the Collatz sequence of n.

    The returned list is sorted in increasing order.

    Examples:
        get_odd_collatz(1) -> [1]
        get_odd_collatz(5) -> [1, 5]
    """
    try:
        # Reject bool explicitly since bool is a subclass of int
        if isinstance(n, bool):
            raise TypeError("Input must be a positive integer.")

        if not isinstance(n, int):
            raise TypeError("Input must be a positive integer.")

        if n <= 0:
            raise ValueError("Input must be a positive integer greater than 0.")

        odd_nums = set()

        while True:
            if n % 2 == 1:
                odd_nums.add(n)

            if n == 1:
                break

            if n % 2 == 0:
                n //= 2
            else:
                n = 3 * n + 1

        return sorted(odd_nums)

    except TypeError as e:
        raise TypeError(f"Type error: {e}")
    except ValueError as e:
        raise ValueError(f"Value error: {e}")
    except Exception as e:
        raise RuntimeError(f"Unexpected error: {e}")
candidate = get_odd_collatz


def check(candidate):

    # Check some simple cases
    assert candidate(14) == [1, 5, 7, 11, 13, 17]
    assert candidate(5) == [1, 5]
    assert candidate(12) == [1, 3, 5], "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1) == [1], "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
