
import unittest
import re
import sys
import math
import copy


def even_odd_palindrome(n):
    """
    Given a positive integer n, return a tuple that has the number of even and odd
    integer palindromes that fall within the range(1, n), inclusive.

    Example 1:
        Input: 3
        Output: (1, 2)

    Example 2:
        Input: 12
        Output: (4, 6)
    """

    def is_palindrome(x):
        s = str(x)
        return s == s[::-1]

    try:
        if not isinstance(n, int):
            raise TypeError("Input must be an integer.")
        if n < 1:
            raise ValueError("Input must be a positive integer.")

        even_count = 0
        odd_count = 0

        for i in range(1, n + 1):
            if is_palindrome(i):
                if i % 2 == 0:
                    even_count += 1
                else:
                    odd_count += 1

        return (even_count, odd_count)

    except TypeError as te:
        raise TypeError(f"Type error: {te}")

    except ValueError as ve:
        raise ValueError(f"Value error: {ve}")

    except Exception as e:
        raise Exception(f"Unexpected error: {e}")
candidate = even_odd_palindrome


def check(candidate):

    # Check some simple cases
    assert candidate(123) == (8, 13)
    assert candidate(12) == (4, 6)
    assert candidate(3) == (1, 2)
    assert candidate(63) == (6, 8)
    assert candidate(25) == (5, 6)
    assert candidate(19) == (4, 6)
    assert candidate(9) == (4, 5), "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1) == (0, 1), "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
