
import unittest
import re
import sys
import math
import copy



def modp(n: int, p: int):
    """Return 2^n modulo p (be aware of numerics).

    >>> modp(3, 5)
    3
    >>> modp(1101, 101)
    2
    >>> modp(0, 101)
    1
    >>> modp(3, 11)
    8
    >>> modp(100, 101)
    1
    """
    try:
        if not isinstance(n, int) or not isinstance(p, int):
            raise TypeError("n and p must be integers")
        if p <= 0:
            raise ValueError("p must be a positive integer")
        if n < 0:
            raise ValueError("n must be non-negative")

        return pow(2, n, p)

    except TypeError as e:
        raise TypeError(f"Invalid argument type: {e}") from e
    except ValueError as e:
        raise ValueError(f"Invalid argument value: {e}") from e
    except Exception as e:
        raise RuntimeError(f"Unexpected error in modp: {e}") from e
candidate = modp




METADATA = {}


def check(candidate):
    assert candidate(3, 5) == 3
    assert candidate(1101, 101) == 2
    assert candidate(0, 101) == 1
    assert candidate(3, 11) == 8
    assert candidate(100, 101) == 1
    assert candidate(30, 5) == 4
    assert candidate(31, 5) == 3



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
