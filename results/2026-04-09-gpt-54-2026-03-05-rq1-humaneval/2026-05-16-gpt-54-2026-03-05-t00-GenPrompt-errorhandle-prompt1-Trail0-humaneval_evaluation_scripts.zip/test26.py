
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def remove_duplicates(numbers: List[int]) -> List[int]:
    """From a list of integers, remove all elements that occur more than once.
    Keep order of elements left the same as in the input.

    >>> remove_duplicates([1, 2, 3, 2, 4])
    [1, 3, 4]
    """
    try:
        counts = {}
        for num in numbers:
            counts[num] = counts.get(num, 0) + 1

        result = []
        for num in numbers:
            if counts[num] == 1:
                result.append(num)

        return result

    except TypeError:
        raise TypeError("Input must be a list of integers.")
    except Exception as e:
        raise RuntimeError(f"An unexpected error occurred: {e}")
candidate = remove_duplicates




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == []
    assert candidate([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert candidate([1, 2, 3, 2, 4, 3, 5]) == [1, 4, 5]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
