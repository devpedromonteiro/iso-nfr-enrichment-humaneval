
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[2] * x^2 + .... + xs[n] * x^n
    """
    try:
        if not isinstance(xs, list):
            raise TypeError("xs must be a list")
        if len(xs) == 0:
            raise ValueError("xs must not be empty")
        return sum(coeff * math.pow(x, i) for i, coeff in enumerate(xs))
    except TypeError:
        raise TypeError("Polynomial coefficients must be numeric")


def find_zero(xs: list):
    """ xs are coefficients of a polynomial.
    find_zero find x such that poly(x) = 0.
    find_zero returns only only zero point, even if there are many.
    Moreover, find_zero only takes list xs having even number of coefficients
    and largest non zero coefficient as it guarantees
    a solution.
    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3
    1.0
    """
    try:
        if not isinstance(xs, list):
            raise TypeError("xs must be a list")
        if len(xs) == 0:
            raise ValueError("xs must not be empty")

        # remove trailing zeros to determine actual degree
        while len(xs) > 1 and xs[-1] == 0:
            xs = xs[:-1]

        if xs[-1] == 0:
            raise ValueError("highest non-zero coefficient must exist")

        degree = len(xs) - 1
        if degree % 2 == 0:
            raise ValueError("polynomial degree must be odd")

        # handle linear case directly
        if degree == 1:
            return -xs[0] / xs[1]

        # search for interval with sign change
        left, right = -1.0, 1.0
        f_left = poly(xs, left)
        f_right = poly(xs, right)

        while f_left * f_right > 0:
            left *= 2
            right *= 2
            f_left = poly(xs, left)
            f_right = poly(xs, right)

        # bisection method
        for _ in range(100):
            mid = (left + right) / 2
            f_mid = poly(xs, mid)

            if abs(f_mid) < 1e-12:
                return mid

            if f_left * f_mid <= 0:
                right = mid
                f_right = f_mid
            else:
                left = mid
                f_left = f_mid

        return (left + right) / 2

    except ZeroDivisionError:
        raise ZeroDivisionError("Invalid polynomial: leading coefficient cannot be zero")
    except (TypeError, ValueError) as e:
        raise e
    except Exception as e:
        raise RuntimeError(f"Unexpected error: {e}")
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
