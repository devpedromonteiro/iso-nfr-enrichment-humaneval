
import unittest
import re
import sys
import math
import copy



def change_base(x: int, base: int):
    """Change numerical base of input number x to base.
    Return string representation after the conversion.
    Base numbers are less than 10.

    >>> change_base(8, 3)
    '22'
    >>> change_base(8, 2)
    '1000'
    >>> change_base(7, 2)
    '111'
    """
    try:
        if not isinstance(x, int) or not isinstance(base, int):
            raise TypeError("Both x and base must be integers.")
        if x < 0:
            raise ValueError("x must be non-negative.")
        if base < 2 or base >= 10:
            raise ValueError("base must be between 2 and 9.")

        if x == 0:
            return "0"

        digits = []
        while x > 0:
            digits.append(str(x % base))
            x //= base

        return ''.join(reversed(digits))

    except TypeError as te:
        print(f"Type error: {te}")
        raise
    except ValueError as ve:
        print(f"Value error: {ve}")
        raise
    except Exception as e:
        print(f"Unexpected error: {e}")
        raise
candidate = change_base




METADATA = {}


def check(candidate):
    assert candidate(8, 3) == "22"
    assert candidate(9, 3) == "100"
    assert candidate(234, 2) == "11101010"
    assert candidate(16, 2) == "10000"
    assert candidate(8, 2) == "1000"
    assert candidate(7, 2) == "111"
    for x in range(2, 8):
        assert candidate(x, x + 1) == str(x)



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
