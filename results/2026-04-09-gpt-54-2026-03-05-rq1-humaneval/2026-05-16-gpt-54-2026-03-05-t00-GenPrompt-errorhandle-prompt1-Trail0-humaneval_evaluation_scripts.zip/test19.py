
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def sort_numbers(numbers: str) -> str:
    """Input is a space-delimited string of numerals from 'zero' to 'nine'.
    Valid choices are 'zero', 'one', 'two', 'three', 'four', 'five',
    'six', 'seven', 'eight' and 'nine'.

    Return the string with numbers sorted from smallest to largest.

    >>> sort_numbers('three one five')
    'one three five'
    """
    number_order = {
        "zero": 0,
        "one": 1,
        "two": 2,
        "three": 3,
        "four": 4,
        "five": 5,
        "six": 6,
        "seven": 7,
        "eight": 8,
        "nine": 9,
    }

    try:
        if not isinstance(numbers, str):
            raise TypeError("Input must be a string.")

        words: List[str] = numbers.split()

        if not words:
            return ""

        invalid_words = [word for word in words if word not in number_order]
        if invalid_words:
            raise ValueError(
                f"Invalid numeral(s): {', '.join(invalid_words)}. "
                "Valid choices are zero to nine."
            )

        sorted_words = sorted(words, key=lambda word: number_order[word])
        return " ".join(sorted_words)

    except TypeError as e:
        raise TypeError(f"Type error: {e}") from e

    except ValueError as e:
        raise ValueError(f"Value error: {e}") from e

    except Exception as e:
        raise RuntimeError(f"Unexpected error: {e}") from e
candidate = sort_numbers




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == ''
    assert candidate('three') == 'three'
    assert candidate('three five nine') == 'three five nine'
    assert candidate('five zero four seven nine eight') == 'zero four five seven eight nine'
    assert candidate('six five four three two one zero') == 'zero one two three four five six'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
