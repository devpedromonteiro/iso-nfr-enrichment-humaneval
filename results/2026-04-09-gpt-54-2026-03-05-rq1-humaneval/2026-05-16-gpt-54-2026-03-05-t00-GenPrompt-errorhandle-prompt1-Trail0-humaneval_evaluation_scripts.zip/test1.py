
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def separate_paren_groups(paren_string: str) -> List[str]:
    """Input to this function is a string containing multiple groups of nested parentheses.
    Your goal is to separate those groups into separate strings and return them as a list.

    Separate groups are balanced (each open brace is properly closed) and not nested within each other.
    Ignore any spaces in the input string.

    >>> separate_paren_groups('( ) (( )) (( )( ))')
    ['()', '(())', '(()())']
    """
    if not isinstance(paren_string, str):
        raise TypeError("Input must be a string.")

    groups = []
    current = []
    balance = 0

    try:
        for ch in paren_string:
            if ch.isspace():
                continue

            if ch not in "()":
                raise ValueError(f"Invalid character found: {ch}")

            current.append(ch)

            if ch == "(":
                balance += 1
            else:
                balance -= 1

            if balance < 0:
                raise ValueError("Unbalanced parentheses: too many closing parentheses.")

            if balance == 0 and current:
                groups.append("".join(current))
                current = []

        if balance != 0:
            raise ValueError("Unbalanced parentheses: too many opening parentheses.")

    except TypeError as e:
        raise TypeError(f"Type error while processing input: {e}")
    except ValueError as e:
        raise ValueError(f"Value error while processing parentheses string: {e}")
    except Exception as e:
        raise RuntimeError(f"Unexpected error: {e}")

    return groups
candidate = separate_paren_groups




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('(()()) ((())) () ((())()())') == [
        '(()())', '((()))', '()', '((())()())'
    ]
    assert candidate('() (()) ((())) (((())))') == [
        '()', '(())', '((()))', '(((())))'
    ]
    assert candidate('(()(())((())))') == [
        '(()(())((())))'
    ]
    assert candidate('( ) (( )) (( )( ))') == ['()', '(())', '(()())']


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
