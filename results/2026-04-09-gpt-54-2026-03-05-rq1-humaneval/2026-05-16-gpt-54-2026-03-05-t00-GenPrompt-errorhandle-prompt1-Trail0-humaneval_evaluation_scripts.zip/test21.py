
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def rescale_to_unit(numbers: List[float]) -> List[float]:
    """Given list of numbers (of at least two elements), apply a linear transform
    such that the smallest number becomes 0 and the largest becomes 1.

    >>> rescale_to_unit([1.0, 2.0, 3.0, 4.0, 5.0])
    [0.0, 0.25, 0.5, 0.75, 1.0]
    """
    try:
        if not isinstance(numbers, list):
            raise TypeError("Input must be a list of numbers.")

        if len(numbers) < 2:
            raise ValueError("List must contain at least two elements.")

        min_val = min(numbers)
        max_val = max(numbers)

        if min_val == max_val:
            raise ValueError("Cannot rescale when all numbers are equal.")

        return [(x - min_val) / (max_val - min_val) for x in numbers]

    except TypeError as e:
        raise TypeError(f"Type error in rescale_to_unit: {e}")
    except ValueError as e:
        raise ValueError(f"Value error in rescale_to_unit: {e}")
    except Exception as e:
        raise RuntimeError(f"Unexpected error in rescale_to_unit: {e}")
candidate = rescale_to_unit




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([2.0, 49.9]) == [0.0, 1.0]
    assert candidate([100.0, 49.9]) == [1.0, 0.0]
    assert candidate([1.0, 2.0, 3.0, 4.0, 5.0]) == [0.0, 0.25, 0.5, 0.75, 1.0]
    assert candidate([2.0, 1.0, 5.0, 3.0, 4.0]) == [0.25, 0.0, 1.0, 0.5, 0.75]
    assert candidate([12.0, 11.0, 15.0, 13.0, 14.0]) == [0.25, 0.0, 1.0, 0.5, 0.75]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
