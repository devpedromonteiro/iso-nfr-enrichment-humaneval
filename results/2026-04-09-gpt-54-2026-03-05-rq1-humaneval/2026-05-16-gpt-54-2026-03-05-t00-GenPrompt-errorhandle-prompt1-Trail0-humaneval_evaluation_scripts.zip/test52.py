
import unittest
import re
import sys
import math
import copy



def below_threshold(l: list, t: int):
    """Return True if all numbers in the list l are below threshold t.
    >>> below_threshold([1, 2, 4, 10], 100)
    True
    >>> below_threshold([1, 20, 4, 10], 5)
    False
    """
    try:
        if not isinstance(l, list):
            raise TypeError("l must be a list")
        if not isinstance(t, (int, float)):
            raise TypeError("t must be a number")

        for x in l:
            if not isinstance(x, (int, float)):
                raise ValueError("all elements in l must be numbers")
            if x >= t:
                return False
        return True

    except TypeError as e:
        print(f"Type error: {e}")
        return False

    except ValueError as e:
        print(f"Value error: {e}")
        return False

    except Exception as e:
        print(f"Unexpected error: {e}")
        return False
candidate = below_threshold




METADATA = {}


def check(candidate):
    assert candidate([1, 2, 4, 10], 100)
    assert not candidate([1, 20, 4, 10], 5)
    assert candidate([1, 20, 4, 10], 21)
    assert candidate([1, 20, 4, 10], 22)
    assert candidate([1, 8, 4, 10], 11)
    assert not candidate([1, 8, 4, 10], 10)



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
