
import unittest
import re
import sys
import math
import copy


def is_nested(string):
    '''
    Create a function that takes a string as input which contains only square brackets.
    The function should return True if and only if there is a valid subsequence of brackets 
    where at least one bracket in the subsequence is nested.

    is_nested('[[]]') â True
    is_nested('[]]]]]]][[[[[]') â False
    is_nested('[][]') â False
    is_nested('[]') â False
    is_nested('[[][]]') â True
    is_nested('[[]][[') â True
    '''
    try:
        balance = 0
        nested_found = False

        for ch in string:
            if ch == '[':
                balance += 1
                if balance >= 2:
                    nested_found = True
            elif ch == ']':
                if balance > 0:
                    balance -= 1

        return nested_found

    except TypeError:
        return False
    except Exception:
        return False
candidate = is_nested


def check(candidate):

    # Check some simple cases
    assert candidate('[[]]') == True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('[]]]]]]][[[[[]') == False
    assert candidate('[][]') == False
    assert candidate(('[]')) == False
    assert candidate('[[[[]]]]') == True
    assert candidate('[]]]]]]]]]]') == False
    assert candidate('[][][[]]') == True
    assert candidate('[[]') == False
    assert candidate('[]]') == False
    assert candidate('[[]][[') == True
    assert candidate('[[][]]') == True

    # Check some edge cases that are easy to work out by hand.
    assert candidate('') == False, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate('[[[[[[[[') == False
    assert candidate(']]]]]]]]') == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
