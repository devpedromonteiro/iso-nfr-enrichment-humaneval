
import unittest
import re
import sys
import math
import copy


def smallest_change(arr):
    """
    Given an array arr of integers, find the minimum number of elements that
    need to be changed to make the array palindromic.

    A palindromic array reads the same forwards and backwards.
    In one change, you can change one element to any other element.

    Examples:
    smallest_change([1,2,3,5,4,7,9,6]) == 4
    smallest_change([1, 2, 3, 4, 3, 2, 2]) == 1
    smallest_change([1, 2, 3, 2, 1]) == 0
    """
    try:
        if arr is None:
            raise ValueError("Input cannot be None")
        if not isinstance(arr, list):
            raise TypeError("Input must be a list")

        changes = 0
        left, right = 0, len(arr) - 1

        while left < right:
            try:
                if arr[left] != arr[right]:
                    changes += 1
            except IndexError:
                raise IndexError("Array index out of range during comparison")
            except TypeError:
                raise TypeError("Array contains uncomparable elements")

            left += 1
            right -= 1

        return changes

    except Exception as e:
        raise e
candidate = smallest_change


def check(candidate):

    # Check some simple cases
    assert candidate([1,2,3,5,4,7,9,6]) == 4
    assert candidate([1, 2, 3, 4, 3, 2, 2]) == 1
    assert candidate([1, 4, 2]) == 1
    assert candidate([1, 4, 4, 2]) == 1

    # Check some edge cases that are easy to work out by hand.
    assert candidate([1, 2, 3, 2, 1]) == 0
    assert candidate([3, 1, 1, 3]) == 0
    assert candidate([1]) == 0
    assert candidate([0, 1]) == 1



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
