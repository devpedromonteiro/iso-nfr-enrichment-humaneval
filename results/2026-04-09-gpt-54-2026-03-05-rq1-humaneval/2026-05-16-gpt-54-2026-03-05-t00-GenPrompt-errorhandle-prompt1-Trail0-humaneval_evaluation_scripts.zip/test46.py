
import unittest
import re
import sys
import math
import copy



def fib4(n: int):
    """The Fib4 number sequence is a sequence similar to the Fibbonacci sequnece that's defined as follows:
    fib4(0) -> 0
    fib4(1) -> 0
    fib4(2) -> 2
    fib4(3) -> 0
    fib4(n) -> fib4(n-1) + fib4(n-2) + fib4(n-3) + fib4(n-4).
    Please write a function to efficiently compute the n-th element of the fib4 number sequence. Do not use recursion.

    >>> fib4(5)
    4
    >>> fib4(6)
    8
    >>> fib4(7)
    14
    """
    try:
        n = int(n)
    except (TypeError, ValueError) as e:
        raise TypeError("n must be an integer") from e

    if n < 0:
        raise ValueError("n must be non-negative")

    base_cases = [0, 0, 2, 0]
    try:
        return base_cases[n]
    except IndexError:
        pass

    a, b, c, d = 0, 0, 2, 0  # fib4(0), fib4(1), fib4(2), fib4(3)

    try:
        for _ in range(4, n + 1):
            a, b, c, d = b, c, d, a + b + c + d
    except OverflowError as e:
        raise OverflowError("number became too large during computation") from e

    return d
candidate = fib4




METADATA = {}


def check(candidate):
    assert candidate(5) == 4
    assert candidate(8) == 28
    assert candidate(10) == 104
    assert candidate(12) == 386



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
