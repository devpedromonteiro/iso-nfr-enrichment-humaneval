
import unittest
import re
import sys
import math
import copy



def unique(l: list):
    """Return sorted unique elements in a list
    >>> unique([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [0, 2, 3, 5, 9, 123]
    """
    try:
        return sorted(set(l))
    except TypeError:
        # Handles cases where elements are unhashable for set()
        try:
            result = []
            for item in l:
                if item not in result:
                    result.append(item)
            return sorted(result)
        except TypeError:
            # Handles cases where elements are not sortable
            return result
    except Exception as e:
        raise ValueError(f"Invalid input: {e}")
candidate = unique




METADATA = {}


def check(candidate):
    assert candidate([5, 3, 5, 2, 3, 3, 9, 0, 123]) == [0, 2, 3, 5, 9, 123]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
