
import unittest
import re
import sys
import math
import copy


def is_equal_to_sum_even(n):
    """Evaluate whether the given number n can be written as the sum of exactly 4 positive even numbers.
    
    Example:
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """
    try:
        # Strategy 1: validate type
        if not isinstance(n, int):
            raise TypeError("Input must be an integer")
        
        # Strategy 2: validate value
        if n <= 0:
            raise ValueError("Input must be a positive integer")
        
        # Smallest sum of 4 positive even numbers is 2 + 2 + 2 + 2 = 8
        return n >= 8 and n % 2 == 0

    except TypeError as te:
        print(f"Type error: {te}")
        return False

    except ValueError as ve:
        print(f"Value error: {ve}")
        return False

    except Exception as e:
        # Strategy 3: catch any unexpected exception
        print(f"Unexpected error: {e}")
        return False
candidate = is_equal_to_sum_even


def check(candidate):
    assert candidate(4) == False
    assert candidate(6) == False
    assert candidate(8) == True
    assert candidate(10) == True
    assert candidate(11) == False
    assert candidate(12) == True
    assert candidate(13) == False
    assert candidate(16) == True


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
