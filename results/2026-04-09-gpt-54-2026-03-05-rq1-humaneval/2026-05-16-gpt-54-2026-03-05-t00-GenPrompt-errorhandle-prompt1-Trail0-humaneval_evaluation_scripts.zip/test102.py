
import unittest
import re
import sys
import math
import copy


def choose_num(x, y):
    """This function takes two positive numbers x and y and returns the
    biggest even integer number that is in the range [x, y] inclusive. If 
    there's no such number, then the function should return -1.

    For example:
    choose_num(12, 15) = 14
    choose_num(13, 12) = -1
    """
    try:
        # Check if inputs are integers
        if not isinstance(x, int) or not isinstance(y, int):
            raise TypeError("Both x and y must be integers.")

        # Check if inputs are positive
        if x <= 0 or y <= 0:
            raise ValueError("Both x and y must be positive numbers.")

        # If range is invalid
        if x > y:
            return -1

        # Start from the largest number in range
        if y % 2 == 0:
            return y
        else:
            return y - 1 if y - 1 >= x else -1

    except TypeError as te:
        print(f"Type Error: {te}")
        return -1

    except ValueError as ve:
        print(f"Value Error: {ve}")
        return -1

    except Exception as e:
        print(f"Unexpected Error: {e}")
        return -1
candidate = choose_num


def check(candidate):

    # Check some simple cases
    assert candidate(12, 15) == 14
    assert candidate(13, 12) == -1
    assert candidate(33, 12354) == 12354
    assert candidate(5234, 5233) == -1
    assert candidate(6, 29) == 28
    assert candidate(27, 10) == -1

    # Check some edge cases that are easy to work out by hand.
    assert candidate(7, 7) == -1
    assert candidate(546, 546) == 546



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
