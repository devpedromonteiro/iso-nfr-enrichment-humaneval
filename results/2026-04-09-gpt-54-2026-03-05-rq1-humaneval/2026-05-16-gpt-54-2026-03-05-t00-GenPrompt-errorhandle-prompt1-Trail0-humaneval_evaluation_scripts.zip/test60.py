
import unittest
import re
import sys
import math
import copy



def sum_to_n(n: int):
    """sum_to_n is a function that sums numbers from 1 to n.
    >>> sum_to_n(30)
    465
    >>> sum_to_n(100)
    5050
    >>> sum_to_n(5)
    15
    >>> sum_to_n(10)
    55
    >>> sum_to_n(1)
    1
    """
    try:
        if not isinstance(n, int):
            raise TypeError("n must be an integer")
        if n < 1:
            raise ValueError("n must be greater than or equal to 1")
        return n * (n + 1) // 2

    except TypeError as e:
        raise TypeError(f"Invalid type: {e}")

    except ValueError as e:
        raise ValueError(f"Invalid value: {e}")

    except Exception as e:
        raise Exception(f"Unexpected error: {e}")
candidate = sum_to_n




METADATA = {}


def check(candidate):
    assert candidate(1) == 1
    assert candidate(6) == 21
    assert candidate(11) == 66
    assert candidate(30) == 465
    assert candidate(100) == 5050



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
