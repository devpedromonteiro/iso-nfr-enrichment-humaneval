
import unittest
import re
import sys
import math
import copy


def starts_one_ends(n):
    """
    Given a positive integer n, return the count of the numbers of n-digit
    positive integers that start or end with 1.

    Exception handling strategies:
    - TypeError: if n is not an integer
    - ValueError: if n is not positive
    """
    try:
        if not isinstance(n, int):
            raise TypeError("n must be an integer")
        if n <= 0:
            raise ValueError("n must be a positive integer")

        if n == 1:
            return 1

        # Count numbers that start with 1: 10^(n-1)
        start_with_1 = 10 ** (n - 1)

        # Count numbers that end with 1: 9 * 10^(n-2)
        end_with_1 = 9 * (10 ** (n - 2))

        # Count numbers counted twice (start and end with 1): 10^(n-2)
        both = 10 ** (n - 2)

        return start_with_1 + end_with_1 - both

    except TypeError as te:
        print(f"Type error: {te}")
        raise
    except ValueError as ve:
        print(f"Value error: {ve}")
        raise
    except Exception as e:
        print(f"Unexpected error: {e}")
        raise
candidate = starts_one_ends


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(1) == 1
    assert candidate(2) == 18
    assert candidate(3) == 180
    assert candidate(4) == 1800
    assert candidate(5) == 18000

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
