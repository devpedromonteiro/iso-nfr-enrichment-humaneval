
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    You are given a positive integer n. You have to create an integer array a of length n.
    For each i (1 â¤ i â¤ n), a[i] = i * i - i + 1.
    Return the number of triples (a[i], a[j], a[k]) where i < j < k
    and a[i] + a[j] + a[k] is a multiple of 3.

    Multiple exception handling strategies included:
    - TypeError for non-integer input
    - ValueError for invalid integer values
    - Generic Exception fallback if needed
    """
    try:
        if not isinstance(n, int):
            raise TypeError("Input must be an integer.")
        if n <= 0:
            raise ValueError("Input must be a positive integer.")

        # Pattern of a[i] mod 3:
        # a[i] = i^2 - i + 1 = i(i-1) + 1
        # Since i(i-1) is always divisible by 2, but modulo 3:
        # i % 3 == 0 -> a[i] % 3 = 1
        # i % 3 == 1 -> a[i] % 3 = 1
        # i % 3 == 2 -> a[i] % 3 = 0

        count_mod_0 = 0
        count_mod_1 = 0

        for i in range(1, n + 1):
            val_mod = (i * i - i + 1) % 3
            if val_mod == 0:
                count_mod_0 += 1
            else:
                count_mod_1 += 1

        def comb3(x):
            return x * (x - 1) * (x - 2) // 6 if x >= 3 else 0

        # Valid sums divisible by 3:
        # (0,0,0) -> sum % 3 == 0
        # (1,1,1) -> sum % 3 == 0
        result = comb3(count_mod_0) + comb3(count_mod_1)

        return result

    except TypeError as te:
        return f"TypeError: {te}"
    except ValueError as ve:
        return f"ValueError: {ve}"
    except Exception as e:
        return f"Unexpected error: {e}"
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
