
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def string_xor(a: str, b: str) -> str:
    """Input are two strings a and b consisting only of 1s and 0s.
    Perform binary XOR on these inputs and return result also as a string.

    >>> string_xor('010', '110')
    '100'
    """
    try:
        if not isinstance(a, str) or not isinstance(b, str):
            raise TypeError("Both inputs must be strings.")

        if len(a) != len(b):
            raise ValueError("Input strings must have the same length.")

        if any(ch not in "01" for ch in a) or any(ch not in "01" for ch in b):
            raise ValueError("Input strings must contain only '0' and '1'.")

        return "".join("0" if x == y else "1" for x, y in zip(a, b))

    except TypeError as e:
        raise TypeError(f"Type error: {e}")

    except ValueError as e:
        raise ValueError(f"Value error: {e}")

    except Exception as e:
        raise RuntimeError(f"Unexpected error: {e}")
candidate = string_xor




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('111000', '101010') == '010010'
    assert candidate('1', '1') == '0'
    assert candidate('0101', '0000') == '0101'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
