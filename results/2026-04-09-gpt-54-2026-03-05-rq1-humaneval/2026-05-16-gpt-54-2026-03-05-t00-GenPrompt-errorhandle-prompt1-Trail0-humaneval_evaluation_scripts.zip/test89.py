
import unittest
import re
import sys
import math
import copy


def encrypt(s):
    """Encrypt a string by shifting each lowercase letter forward by 4."""
    try:
        if not isinstance(s, str):
            raise TypeError("Input must be a string")

        result = []
        for ch in s:
            if not ch.isalpha() or not ch.islower():
                raise ValueError("Input must contain only lowercase alphabetic characters")

            shifted = chr((ord(ch) - ord('a') + 4) % 26 + ord('a'))
            result.append(shifted)

        return ''.join(result)

    except TypeError as te:
        return f"TypeError: {te}"
    except ValueError as ve:
        return f"ValueError: {ve}"
    except Exception as e:
        return f"Unexpected error: {e}"
candidate = encrypt


def check(candidate):

    # Check some simple cases
    assert candidate('hi') == 'lm', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('asdfghjkl') == 'ewhjklnop', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('gf') == 'kj', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('et') == 'ix', "This prints if this assert fails 1 (good for debugging!)"

    assert candidate('faewfawefaewg')=='jeiajeaijeiak', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('hellomyfriend')=='lippsqcjvmirh', "This prints if this assert fails 2 (good for debugging!)"
    assert candidate('dxzdlmnilfuhmilufhlihufnmlimnufhlimnufhfucufh')=='hbdhpqrmpjylqmpyjlpmlyjrqpmqryjlpmqryjljygyjl', "This prints if this assert fails 3 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate('a')=='e', "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
