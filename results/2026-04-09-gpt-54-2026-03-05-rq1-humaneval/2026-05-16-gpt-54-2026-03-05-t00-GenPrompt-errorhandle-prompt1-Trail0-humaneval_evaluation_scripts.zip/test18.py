
import unittest
import re
import sys
import math
import copy



def how_many_times(string: str, substring: str) -> int:
    """Find how many times a given substring appears in the original string.
    Overlapping matches are counted.

    >>> how_many_times('', 'a')
    0
    >>> how_many_times('aaa', 'a')
    3
    >>> how_many_times('aaaa', 'aa')
    3
    """
    try:
        if not isinstance(string, str) or not isinstance(substring, str):
            raise TypeError("Both arguments must be strings.")

        if substring == "":
            raise ValueError("Substring must not be empty.")

        count = 0
        start = 0

        while True:
            try:
                index = string.index(substring, start)
                count += 1
                start = index + 1  # allow overlapping matches
            except ValueError:
                break

        return count

    except TypeError as e:
        print(f"Type error: {e}")
        return 0
    except ValueError as e:
        print(f"Value error: {e}")
        return 0
    except Exception as e:
        print(f"Unexpected error: {e}")
        return 0
candidate = how_many_times




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('', 'x') == 0
    assert candidate('xyxyxyx', 'x') == 4
    assert candidate('cacacacac', 'cac') == 4
    assert candidate('john doe', 'john') == 1


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
