
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    """Insert `delimeter` between every two consecutive elements of `numbers`.

    >>> intersperse([], 4)
    []
    >>> intersperse([1, 2, 3], 4)
    [1, 4, 2, 4, 3]
    """
    try:
        if not isinstance(numbers, list):
            raise TypeError("numbers must be a list")
        if not all(isinstance(x, int) for x in numbers):
            raise ValueError("all elements in numbers must be integers")
        if not isinstance(delimeter, int):
            raise TypeError("delimeter must be an integer")

        if not numbers:
            return []

        result = []
        for i, num in enumerate(numbers):
            result.append(num)
            if i < len(numbers) - 1:
                result.append(delimeter)
        return result

    except TypeError as e:
        print(f"Type error: {e}")
        return []
    except ValueError as e:
        print(f"Value error: {e}")
        return []
    except Exception as e:
        print(f"Unexpected error: {e}")
        return []
candidate = intersperse




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([], 7) == []
    assert candidate([5, 6, 3, 2], 8) == [5, 8, 6, 8, 3, 8, 2]
    assert candidate([2, 2, 2], 2) == [2, 2, 2, 2, 2]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
