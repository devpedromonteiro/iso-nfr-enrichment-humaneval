
import unittest
import re
import sys
import math
import copy


def solve(N):
    """Given a positive integer N, return the total sum of its decimal digits in binary.
    
    Example
        For N = 1000, the sum of digits will be 1 the output should be "1".
        For N = 150, the sum of digits will be 6 the output should be "110".
        For N = 147, the sum of digits will be 12 the output should be "1100".
    
    Variables:
        @N integer
             Constraints: 0 â¤ N â¤ 10000.
    Output:
         a string of binary number
    """
    try:
        # Strategy 1: validate type
        if isinstance(N, bool):
            raise TypeError("Boolean is not a valid integer input.")
        if not isinstance(N, int):
            raise TypeError("Input must be an integer.")
        
        # Strategy 2: validate range
        if N < 0 or N > 10000:
            raise ValueError("Input must satisfy 0 â¤ N â¤ 10000.")
        
        # Compute sum of decimal digits
        digit_sum = sum(int(d) for d in str(N))
        
        # Convert to binary string
        return bin(digit_sum)[2:]
    
    except TypeError as te:
        return f"TypeError: {te}"
    
    except ValueError as ve:
        return f"ValueError: {ve}"
    
    except Exception as e:
        # Strategy 3: catch-all for unexpected errors
        return f"UnexpectedError: {e}"
candidate = solve


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(1000) == "1", "Error"
    assert candidate(150) == "110", "Error"
    assert candidate(147) == "1100", "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate(333) == "1001", "Error"
    assert candidate(963) == "10010", "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
