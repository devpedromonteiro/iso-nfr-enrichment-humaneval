
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def parse_music(music_string: str) -> List[int]:
    """Input to this function is a string representing musical notes in a special ASCII format.
    Your task is to parse this string and return list of integers corresponding to how many beats each
    note lasts.

    Legend:
    'o'  - whole note, lasts four beats
    'o|' - half note, lasts two beats
    '.|' - quarter note, lasts one beat

    >>> parse_music('o o| .| o| o| .| .| .| .| o o')
    [4, 2, 1, 2, 2, 1, 1, 1, 1, 4, 4]
    """
    if not isinstance(music_string, str):
        raise TypeError("music_string must be a string")

    music_string = music_string.strip()
    if not music_string:
        return []

    note_map = {
        'o': 4,
        'o|': 2,
        '.|': 1,
    }

    beats = []
    tokens = music_string.split()

    for i, token in enumerate(tokens):
        try:
            beats.append(note_map[token])
        except KeyError:
            raise ValueError(
                f"Invalid note {token!r} at position {i}. "
                f"Valid notes are: {', '.join(note_map.keys())}"
            ) from None

    return beats
candidate = parse_music




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == []
    assert candidate('o o o o') == [4, 4, 4, 4]
    assert candidate('.| .| .| .|') == [1, 1, 1, 1]
    assert candidate('o| o| .| .| o o o o') == [2, 2, 1, 1, 4, 4, 4, 4]
    assert candidate('o| .| o| .| o o| o o|') == [2, 1, 2, 1, 4, 2, 4, 2]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
