
import unittest
import re
import sys
import math
import copy



def below_threshold(l: list, t: int):
    """Return True if all numbers in the list l are below threshold t.
    
    >>> below_threshold([1, 2, 4, 10], 100)
    True
    >>> below_threshold([1, 20, 4, 10], 5)
    False
    """
    # Type check for the list input
    if not isinstance(l, list):
        raise TypeError("l must be a list")
    
    # Type check for the threshold
    if not isinstance(t, (int, float)):
        raise TypeError("t must be a number")
    
    try:
        for item in l:
            # Check each element is numeric
            if not isinstance(item, (int, float)):
                raise ValueError(f"List element {item!r} is not a number")
            if item >= t:
                return False
        return True
    except TypeError as e:
        raise TypeError(f"Comparison failed: {e}")
candidate = below_threshold




METADATA = {}


def check(candidate):
    assert candidate([1, 2, 4, 10], 100)
    assert not candidate([1, 20, 4, 10], 5)
    assert candidate([1, 20, 4, 10], 21)
    assert candidate([1, 20, 4, 10], 22)
    assert candidate([1, 8, 4, 10], 11)
    assert not candidate([1, 8, 4, 10], 10)



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
