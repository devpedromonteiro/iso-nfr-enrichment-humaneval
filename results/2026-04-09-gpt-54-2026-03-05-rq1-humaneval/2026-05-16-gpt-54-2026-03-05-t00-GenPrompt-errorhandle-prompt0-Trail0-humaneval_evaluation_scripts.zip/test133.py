
import unittest
import re
import sys
import math
import copy



import math

def sum_squares(lst):
    """Return the sum of squares of the elements in lst after applying ceil.

    Examples:
    >>> sum_squares([1, 2, 3])
    14
    >>> sum_squares([1, 4, 9])
    98
    >>> sum_squares([1, 3, 5, 7])
    84
    >>> sum_squares([1.4, 4.2, 0])
    29
    >>> sum_squares([-2.4, 1, 1])
    6
    """
    if lst is None:
        raise ValueError("Input cannot be None")

    if not isinstance(lst, (list, tuple)):
        raise TypeError("Input must be a list or tuple of numbers")

    total = 0

    for i, value in enumerate(lst):
        try:
            if isinstance(value, bool):
                raise TypeError(f"Boolean value at index {i} is not allowed")

            num = float(value)

            if math.isnan(num) or math.isinf(num):
                raise ValueError(f"Invalid numeric value at index {i}: {value}")

            total += math.ceil(num) ** 2

        except (TypeError, ValueError) as e:
            raise type(e)(f"Error processing element at index {i}: {e}")

    return total
candidate = sum_squares


def check(candidate):

    # Check some simple cases
    assert candidate([1,2,3])==14, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1.0,2,3])==14, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,3,5,7])==84, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1.4,4.2,0])==29, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([-2.4,1,1])==6, "This prints if this assert fails 1 (good for debugging!)"

    assert candidate([100,1,15,2])==10230, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([10000,10000])==200000000, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([-1.4,4.6,6.3])==75, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([-1.4,17.9,18.9,19.9])==1086, "This prints if this assert fails 1 (good for debugging!)"


    # Check some edge cases that are easy to work out by hand.
    assert candidate([0])==0, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([-1])==1, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([-1,1,0])==2, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
