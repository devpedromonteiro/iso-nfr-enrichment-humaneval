
import unittest
import re
import sys
import math
import copy



def correct_bracketing(brackets: str):
    """brackets is a string of "(" and ")".
    Return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("(")
    False
    >>> correct_bracketing("()")
    True
    >>> correct_bracketing("(()())")
    True
    >>> correct_bracketing(")(()")
    False
    """
    # Type check
    if not isinstance(brackets, str):
        raise TypeError("Input must be a string.")

    balance = 0

    for i, ch in enumerate(brackets):
        # Validate characters
        if ch not in ("(", ")"):
            raise ValueError(f"Invalid character at index {i}: {ch!r}")

        if ch == "(":
            balance += 1
        else:
            balance -= 1

        # Error handling for premature closing bracket
        if balance < 0:
            return False

    return balance == 0
candidate = correct_bracketing




METADATA = {}


def check(candidate):
    assert candidate("()")
    assert candidate("(()())")
    assert candidate("()()(()())()")
    assert candidate("()()((()()())())(()()(()))")
    assert not candidate("((()())))")
    assert not candidate(")(()")
    assert not candidate("(")
    assert not candidate("((((")
    assert not candidate(")")
    assert not candidate("(()")
    assert not candidate("()()(()())())(()")
    assert not candidate("()()(()())()))()")



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
