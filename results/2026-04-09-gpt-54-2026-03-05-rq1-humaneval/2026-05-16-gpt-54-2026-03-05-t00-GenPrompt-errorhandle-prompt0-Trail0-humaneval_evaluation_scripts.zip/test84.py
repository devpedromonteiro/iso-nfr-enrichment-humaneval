
import unittest
import re
import sys
import math
import copy


def solve(N):
    """Given a non-negative integer N, return the binary representation
    of the sum of its decimal digits.

    Examples:
        solve(1000) -> "1"
        solve(150)  -> "110"
        solve(147)  -> "1100"
    """

    # Type validation
    if N is None:
        raise ValueError("Input cannot be None.")

    if isinstance(N, bool):
        raise TypeError("Input must be an integer, not a boolean.")

    if not isinstance(N, int):
        raise TypeError("Input must be an integer.")

    # Range validation
    if N < 0:
        raise ValueError("Input must be a non-negative integer.")

    if N > 10000:
        raise ValueError("Input must satisfy 0 â¤ N â¤ 10000.")

    try:
        # Sum decimal digits
        digit_sum = sum(int(ch) for ch in str(N))

        # Convert to binary string
        return bin(digit_sum)[2:]

    except Exception as e:
        raise RuntimeError(f"Unexpected error while processing input: {e}")
candidate = solve


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(1000) == "1", "Error"
    assert candidate(150) == "110", "Error"
    assert candidate(147) == "1100", "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate(333) == "1001", "Error"
    assert candidate(963) == "10010", "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
