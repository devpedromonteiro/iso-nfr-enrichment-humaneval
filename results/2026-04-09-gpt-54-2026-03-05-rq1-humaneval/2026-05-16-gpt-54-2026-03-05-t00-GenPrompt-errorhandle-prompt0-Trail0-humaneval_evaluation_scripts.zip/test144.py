
import unittest
import re
import sys
import math
import copy


from fractions import Fraction

def simplify(x, n):
    """
    Return True if the product of two fraction strings evaluates to a whole number,
    otherwise return False.

    Fractions must be in the form "numerator/denominator" with positive integers.

    Examples:
        simplify("1/5", "5/1") -> True
        simplify("1/6", "2/1") -> False
        simplify("7/10", "10/2") -> False
    """
    try:
        # Validate input types
        if not isinstance(x, str) or not isinstance(n, str):
            raise TypeError("Both inputs must be strings.")

        # Convert strings to Fraction objects
        fx = Fraction(x)
        fn = Fraction(n)

        # Ensure fractions are positive and denominators are nonzero
        if fx <= 0 or fn <= 0:
            raise ValueError("Fractions must be positive.")

        product = fx * fn

        return product.denominator == 1

    except ZeroDivisionError:
        raise ValueError("Denominator cannot be zero.")
    except ValueError as e:
        raise ValueError(f"Invalid fraction input: {e}")
    except TypeError as e:
        raise TypeError(f"Type error: {e}")
candidate = simplify


def check(candidate):

    # Check some simple cases
    assert candidate("1/5", "5/1") == True, 'test1'
    assert candidate("1/6", "2/1") == False, 'test2'
    assert candidate("5/1", "3/1") == True, 'test3'
    assert candidate("7/10", "10/2") == False, 'test4'
    assert candidate("2/10", "50/10") == True, 'test5'
    assert candidate("7/2", "4/2") == True, 'test6'
    assert candidate("11/6", "6/1") == True, 'test7'
    assert candidate("2/3", "5/2") == False, 'test8'
    assert candidate("5/2", "3/5") == False, 'test9'
    assert candidate("2/4", "8/4") == True, 'test10'


    # Check some edge cases that are easy to work out by hand.
    assert candidate("2/4", "4/2") == True, 'test11'
    assert candidate("1/5", "5/1") == True, 'test12'
    assert candidate("1/5", "1/5") == False, 'test13'



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
