
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    """Insert `delimeter` between every two consecutive elements of `numbers`.

    Error handling included:
    - Raises TypeError if `numbers` is not a list
    - Raises TypeError if any element in `numbers` is not an int
    - Raises TypeError if `delimeter` is not an int

    >>> intersperse([], 4)
    []
    >>> intersperse([1, 2, 3], 4)
    [1, 4, 2, 4, 3]
    """
    if not isinstance(numbers, list):
        raise TypeError("numbers must be a list")

    if not isinstance(delimeter, int):
        raise TypeError("delimeter must be an int")

    for i, value in enumerate(numbers):
        if not isinstance(value, int):
            raise TypeError(f"numbers[{i}] must be an int, got {type(value).__name__}")

    if not numbers:
        return []

    result = []
    try:
        for i, num in enumerate(numbers):
            result.append(num)
            if i < len(numbers) - 1:
                result.append(delimeter)
    except Exception as e:
        raise RuntimeError(f"Unexpected error while interspersing list: {e}") from e

    return result
candidate = intersperse




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([], 7) == []
    assert candidate([5, 6, 3, 2], 8) == [5, 8, 6, 8, 3, 8, 2]
    assert candidate([2, 2, 2], 2) == [2, 2, 2, 2, 2]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
