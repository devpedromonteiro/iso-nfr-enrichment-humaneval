
import unittest
import re
import sys
import math
import copy


def get_row(lst, x):
    """
    You are given a 2 dimensional data, as nested lists,
    where each row may contain a different number of columns.
    Given lst and integer x, find all occurrences of x and return
    a list of tuples (row, column).

    Sorting rules:
    - rows in ascending order
    - columns within the same row in descending order

    Examples:
    get_row([
      [1,2,3,4,5,6],
      [1,2,3,4,1,6],
      [1,2,3,4,5,1]
    ], 1) == [(0, 0), (1, 4), (1, 0), (2, 5), (2, 0)]
    get_row([], 1) == []
    get_row([[], [1], [1, 2, 3]], 3) == [(2, 2)]
    """
    # Error handling: ensure lst is iterable
    if lst is None:
        return []

    if not isinstance(lst, list):
        raise TypeError("lst must be a list of lists")

    result = []

    try:
        for row_idx, row in enumerate(lst):
            # Error handling: skip invalid/non-list rows
            if not isinstance(row, list):
                continue

            cols = []
            for col_idx, value in enumerate(row):
                if value == x:
                    cols.append((row_idx, col_idx))

            # sort columns in descending order for the current row
            cols.sort(key=lambda coord: coord[1], reverse=True)
            result.extend(cols)

    except Exception as e:
        raise RuntimeError(f"An error occurred while processing the data: {e}")

    return result
candidate = get_row


def check(candidate):

    # Check some simple cases
    assert candidate([
        [1,2,3,4,5,6],
        [1,2,3,4,1,6],
        [1,2,3,4,5,1]
    ], 1) == [(0, 0), (1, 4), (1, 0), (2, 5), (2, 0)]
    assert candidate([
        [1,2,3,4,5,6],
        [1,2,3,4,5,6],
        [1,2,3,4,5,6],
        [1,2,3,4,5,6],
        [1,2,3,4,5,6],
        [1,2,3,4,5,6]
    ], 2) == [(0, 1), (1, 1), (2, 1), (3, 1), (4, 1), (5, 1)]
    assert candidate([
        [1,2,3,4,5,6],
        [1,2,3,4,5,6],
        [1,1,3,4,5,6],
        [1,2,1,4,5,6],
        [1,2,3,1,5,6],
        [1,2,3,4,1,6],
        [1,2,3,4,5,1]
    ], 1) == [(0, 0), (1, 0), (2, 1), (2, 0), (3, 2), (3, 0), (4, 3), (4, 0), (5, 4), (5, 0), (6, 5), (6, 0)]
    assert candidate([], 1) == []
    assert candidate([[1]], 2) == []
    assert candidate([[], [1], [1, 2, 3]], 3) == [(2, 2)]

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
