
import unittest
import re
import sys
import math
import copy



def largest_prime_factor(n: int):
    """Return the largest prime factor of n.

    Assumes n > 1 and n is not prime.

    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    # Type checking
    if not isinstance(n, int):
        raise TypeError("n must be an integer")

    # Value checking
    if n <= 1:
        raise ValueError("n must be greater than 1")

    # Handle factor 2 separately
    largest = None
    while n % 2 == 0:
        largest = 2
        n //= 2

    # Check odd factors from 3 upward
    factor = 3
    while factor * factor <= n:
        while n % factor == 0:
            largest = factor
            n //= factor
        factor += 2

    # If remaining n > 1, it is prime
    if n > 1:
        largest = n

    # Defensive fallback, though assumptions should prevent this
    if largest is None:
        raise ValueError("Input must not be prime")

    return largest
candidate = largest_prime_factor




METADATA = {}


def check(candidate):
    assert candidate(15) == 5
    assert candidate(27) == 3
    assert candidate(63) == 7
    assert candidate(330) == 11
    assert candidate(13195) == 29



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
