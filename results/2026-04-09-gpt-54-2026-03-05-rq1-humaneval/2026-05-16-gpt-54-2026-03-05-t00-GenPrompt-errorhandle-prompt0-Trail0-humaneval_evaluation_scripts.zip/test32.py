
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math
from numbers import Real


def poly(xs: list, x: float) -> float:
    """
    Evaluates polynomial with coefficients xs at point x.

    Returns:
        xs[0] + xs[1] * x + xs[2] * x^2 + ... + xs[n] * x^n

    Raises:
        TypeError: if xs is not a list/tuple or x is not numeric
        ValueError: if xs is empty
    """
    if not isinstance(xs, (list, tuple)):
        raise TypeError("xs must be a list or tuple of numeric coefficients")
    if len(xs) == 0:
        raise ValueError("xs must not be empty")
    if not isinstance(x, Real):
        raise TypeError("x must be a real number")

    for i, coeff in enumerate(xs):
        if not isinstance(coeff, Real):
            raise TypeError(f"coefficient at index {i} is not numeric: {coeff!r}")

    return sum(coeff * math.pow(x, i) for i, coeff in enumerate(xs))


def find_zero(xs: list) -> float:
    """
    xs are coefficients of a polynomial.

    find_zero finds x such that poly(xs, x) == 0.
    Returns only one zero point, even if there are many.

    Assumptions required by this implementation:
    - xs has even number of coefficients
    - the largest non-zero coefficient corresponds to an odd degree
      (which guarantees at least one real root)

    Examples:
    >>> round(find_zero([1, 2]), 2)   # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2)
    1.0
    """
    # Input validation
    if not isinstance(xs, (list, tuple)):
        raise TypeError("xs must be a list or tuple of numeric coefficients")

    if len(xs) == 0:
        raise ValueError("xs must not be empty")

    if len(xs) % 2 != 0:
        raise ValueError("xs must contain an even number of coefficients")

    for i, coeff in enumerate(xs):
        if not isinstance(coeff, Real):
            raise TypeError(f"coefficient at index {i} is not numeric: {coeff!r}")

    # Remove trailing zeros to determine actual degree
    ys = list(xs)
    while ys and ys[-1] == 0:
        ys.pop()

    if not ys:
        raise ValueError("zero polynomial has infinitely many roots")

    degree = len(ys) - 1
    if degree % 2 == 0:
        raise ValueError(
            "highest non-zero coefficient must correspond to an odd degree"
        )

    # Quick check: x = 0 is a root
    if poly(ys, 0) == 0:
        return 0.0

    # Find interval [lo, hi] with sign change
    lo, hi = -1.0, 1.0
    f_lo = poly(ys, lo)
    f_hi = poly(ys, hi)

    max_expand = 10_000
    steps = 0
    while f_lo * f_hi > 0:
        lo *= 2
        hi *= 2
        f_lo = poly(ys, lo)
        f_hi = poly(ys, hi)
        steps += 1
        if steps > max_expand:
            raise RuntimeError("failed to bracket a root")

    # Bisection method
    eps = 1e-12
    max_iter = 10_000

    for _ in range(max_iter):
        mid = (lo + hi) / 2
        f_mid = poly(ys, mid)

        if abs(f_mid) < eps or abs(hi - lo) < eps:
            return mid

        if f_lo * f_mid <= 0:
            hi = mid
            f_hi = f_mid
        else:
            lo = mid
            f_lo = f_mid

    raise RuntimeError("bisection did not converge")
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
