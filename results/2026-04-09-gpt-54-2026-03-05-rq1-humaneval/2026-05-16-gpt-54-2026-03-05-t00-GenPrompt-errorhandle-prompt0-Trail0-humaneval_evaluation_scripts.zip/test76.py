
import unittest
import re
import sys
import math
import copy


def is_simple_power(x, n):
    """
    Return True if x is an integer power of n, i.e. if there exists
    some non-negative integer k such that n**k == x. Otherwise return False.

    Examples:
        is_simple_power(1, 4) -> True
        is_simple_power(2, 2) -> True
        is_simple_power(8, 2) -> True
        is_simple_power(3, 2) -> False
        is_simple_power(3, 1) -> False
        is_simple_power(5, 3) -> False
    """

    # Type validation
    if not isinstance(x, int) or not isinstance(n, int):
        raise TypeError("Both x and n must be integers.")

    # Handle invalid / special cases
    if x < 1:
        return False

    if x == 1:
        return True

    if n == 0:
        return False  # only 0**k could work, but x >= 1 here and x != 1

    if n == 1:
        return False  # only 1**k == 1, already handled above

    if n == -1:
        return x == 1 or x == -1

    # For positive n > 1, repeatedly divide x by n
    try:
        while x % n == 0:
            x //= n
        return x == 1
    except ZeroDivisionError:
        return False
    except Exception:
        return False
candidate = is_simple_power


def check(candidate):

    # Check some simple cases
    assert candidate(16, 2)== True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(143214, 16)== False, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(4, 2)==True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(9, 3)==True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(16, 4)==True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(24, 2)==False, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(128, 4)==False, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(12, 6)==False, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1, 1)==True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate(1, 12)==True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
