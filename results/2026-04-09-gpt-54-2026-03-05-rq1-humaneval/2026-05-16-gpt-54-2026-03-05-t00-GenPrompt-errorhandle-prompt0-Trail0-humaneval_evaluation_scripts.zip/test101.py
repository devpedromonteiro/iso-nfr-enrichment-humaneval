
import unittest
import re
import sys
import math
import copy


import re

def words_string(s):
    """
    Split a string of words separated by commas and/or spaces into a list of words.

    Examples:
    words_string("Hi, my name is John") -> ["Hi", "my", "name", "is", "John"]
    words_string("One, two, three, four, five, six") -> ["One", "two", "three", "four", "five", "six"]
    """
    try:
        # Type check
        if s is None:
            raise ValueError("Input cannot be None.")
        if not isinstance(s, str):
            raise TypeError("Input must be a string.")

        # Remove leading/trailing whitespace
        s = s.strip()

        # Handle empty string
        if not s:
            return []

        # Split on one or more commas or whitespace characters
        words = re.split(r"[,\s]+", s)

        # Filter out any accidental empty strings
        return [word for word in words if word]

    except TypeError as te:
        print(f"Type error: {te}")
        return []
    except ValueError as ve:
        print(f"Value error: {ve}")
        return []
    except Exception as e:
        print(f"Unexpected error: {e}")
        return []
candidate = words_string


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate("Hi, my name is John") == ["Hi", "my", "name", "is", "John"]
    assert candidate("One, two, three, four, five, six") == ["One", "two", "three", "four", "five", "six"]
    assert candidate("Hi, my name") == ["Hi", "my", "name"]
    assert candidate("One,, two, three, four, five, six,") == ["One", "two", "three", "four", "five", "six"]

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate("") == []
    assert candidate("ahmed     , gamal") == ["ahmed", "gamal"]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
