
import unittest
import re
import sys
import math
import copy



def is_palindrome(text: str) -> bool:
    """
    Checks if given string is a palindrome.

    Error handling techniques used:
    - Type checking
    - Graceful handling of None
    - Defensive conversion for unexpected input issues

    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    """
    if text is None:
        raise ValueError("Input cannot be None")

    if not isinstance(text, str):
        raise TypeError(f"Expected a string, got {type(text).__name__}")

    try:
        return text == text[::-1]
    except Exception as exc:
        raise RuntimeError(f"Unexpected error while checking palindrome: {exc}") from exc
candidate = is_palindrome




METADATA = {}


def check(candidate):
    assert candidate('') == True
    assert candidate('aba') == True
    assert candidate('aaaaa') == True
    assert candidate('zbcd') == False
    assert candidate('xywyx') == True
    assert candidate('xywyz') == False
    assert candidate('xywzx') == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
