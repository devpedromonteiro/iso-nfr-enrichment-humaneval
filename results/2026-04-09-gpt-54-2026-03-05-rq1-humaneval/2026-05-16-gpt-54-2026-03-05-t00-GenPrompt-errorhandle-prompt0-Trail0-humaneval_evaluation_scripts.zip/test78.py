
import unittest
import re
import sys
import math
import copy


def hex_key(num):
    """Count how many hexadecimal digits in `num` are prime hex digits.

    Prime hex digits are: 2, 3, 5, 7, B, D

    Examples:
        hex_key("AB") -> 1
        hex_key("1077E") -> 2
        hex_key("ABED1A33") -> 4
    """
    prime_hex_digits = {"2", "3", "5", "7", "B", "D"}

    # Error handling: None input
    if num is None:
        return 0

    # Error handling: wrong type
    if not isinstance(num, str):
        raise TypeError("Input must be a string.")

    # Error handling: empty string
    if num == "":
        return 0

    # Error handling: invalid hexadecimal characters
    valid_hex_digits = set("0123456789ABCDEF")
    for ch in num:
        if ch not in valid_hex_digits:
            raise ValueError(f"Invalid hexadecimal digit: {ch}")

    return sum(1 for ch in num if ch in prime_hex_digits)
candidate = hex_key


def check(candidate):

    # Check some simple cases
    assert candidate("AB") == 1, "First test error: " + str(candidate("AB"))      
    assert candidate("1077E") == 2, "Second test error: " + str(candidate("1077E"))  
    assert candidate("ABED1A33") == 4, "Third test error: " + str(candidate("ABED1A33"))      
    assert candidate("2020") == 2, "Fourth test error: " + str(candidate("2020"))  
    assert candidate("123456789ABCDEF0") == 6, "Fifth test error: " + str(candidate("123456789ABCDEF0"))      
    assert candidate("112233445566778899AABBCCDDEEFF00") == 12, "Sixth test error: " + str(candidate("112233445566778899AABBCCDDEEFF00"))  


    # Check some edge cases that are easy to work out by hand.
    assert candidate([]) == 0



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
