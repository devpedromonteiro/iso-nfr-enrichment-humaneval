
import unittest
import re
import sys
import math
import copy


def choose_num(x, y):
    """Return the biggest even integer in the inclusive range [x, y].

    If there is no even integer in the range, return -1.

    Examples:
        choose_num(12, 15) -> 14
        choose_num(13, 12) -> -1
    """
    try:
        # Type validation
        if not isinstance(x, int) or not isinstance(y, int):
            raise TypeError("Both x and y must be integers.")

        # Value validation
        if x <= 0 or y <= 0:
            raise ValueError("Both x and y must be positive numbers.")

        # Invalid range
        if x > y:
            return -1

        # If y is even, it's the biggest even in the range
        if y % 2 == 0:
            return y

        # Otherwise, check the previous number
        if y - 1 >= x:
            return y - 1

        return -1

    except TypeError as te:
        print(f"Type error: {te}")
        return -1

    except ValueError as ve:
        print(f"Value error: {ve}")
        return -1

    except Exception as e:
        print(f"Unexpected error: {e}")
        return -1
candidate = choose_num


def check(candidate):

    # Check some simple cases
    assert candidate(12, 15) == 14
    assert candidate(13, 12) == -1
    assert candidate(33, 12354) == 12354
    assert candidate(5234, 5233) == -1
    assert candidate(6, 29) == 28
    assert candidate(27, 10) == -1

    # Check some edge cases that are easy to work out by hand.
    assert candidate(7, 7) == -1
    assert candidate(546, 546) == 546



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
