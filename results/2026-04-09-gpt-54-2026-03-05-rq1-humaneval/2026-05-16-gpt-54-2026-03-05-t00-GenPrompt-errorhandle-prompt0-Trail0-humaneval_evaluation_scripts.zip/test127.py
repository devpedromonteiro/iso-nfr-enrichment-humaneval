
import unittest
import re
import sys
import math
import copy


def intersection(interval1, interval2):
    """
    Determine whether the length of the intersection of two closed intervals
    is a prime number.

    Each interval must be a pair of integers: (start, end), with start <= end.

    Returns:
        "YES" if the intersection length is prime, otherwise "NO".

    Examples:
        intersection((1, 2), (2, 3)) -> "NO"
        intersection((-1, 1), (0, 4)) -> "NO"
        intersection((-3, -1), (-5, 5)) -> "YES"
    """

    def is_prime(n):
        """Check if n is a prime number."""
        if n < 2:
            return False
        if n == 2:
            return True
        if n % 2 == 0:
            return False
        i = 3
        while i * i <= n:
            if n % i == 0:
                return False
            i += 2
        return True

    try:
        # Validate interval structure
        if not isinstance(interval1, (tuple, list)) or not isinstance(interval2, (tuple, list)):
            raise TypeError("Both intervals must be tuples or lists.")

        if len(interval1) != 2 or len(interval2) != 2:
            raise ValueError("Each interval must contain exactly two elements.")

        start1, end1 = interval1
        start2, end2 = interval2

        # Validate element types
        if not all(isinstance(x, int) for x in (start1, end1, start2, end2)):
            raise TypeError("Interval bounds must be integers.")

        # Validate interval order
        if start1 > end1 or start2 > end2:
            raise ValueError("Each interval must satisfy start <= end.")

        # Find intersection
        inter_start = max(start1, start2)
        inter_end = min(end1, end2)

        # No intersection
        if inter_start > inter_end:
            return "NO"

        # Closed interval length: (end - start)
        length = inter_end - inter_start

        return "YES" if is_prime(length) else "NO"

    except (TypeError, ValueError) as e:
        return f"Error: {e}"
candidate = intersection


def check(candidate):

    # Check some simple cases
    assert candidate((1, 2), (2, 3)) == "NO"
    assert candidate((-1, 1), (0, 4)) == "NO"
    assert candidate((-3, -1), (-5, 5)) == "YES"
    assert candidate((-2, 2), (-4, 0)) == "YES"

    # Check some edge cases that are easy to work out by hand.
    assert candidate((-11, 2), (-1, -1)) == "NO"
    assert candidate((1, 2), (3, 5)) == "NO"
    assert candidate((1, 2), (1, 2)) == "NO"
    assert candidate((-2, -2), (-3, -2)) == "NO"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
