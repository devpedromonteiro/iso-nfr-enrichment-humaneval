
import unittest
import re
import sys
import math
import copy


def by_length(arr):
    """
    Given an array of integers, sort the integers that are between 1 and 9 inclusive,
    reverse the resulting array, and then replace each digit by its corresponding name.

    Valid mappings:
        1 -> "One"
        2 -> "Two"
        3 -> "Three"
        4 -> "Four"
        5 -> "Five"
        6 -> "Six"
        7 -> "Seven"
        8 -> "Eight"
        9 -> "Nine"

    Any invalid or "strange" values are ignored.
    If the input is empty, returns an empty list.
    """

    digit_names = {
        1: "One",
        2: "Two",
        3: "Three",
        4: "Four",
        5: "Five",
        6: "Six",
        7: "Seven",
        8: "Eight",
        9: "Nine"
    }

    # Error handling: input must be iterable
    try:
        if arr is None:
            return []

        # Keep only valid integers from 1 to 9
        valid_numbers = []
        for item in arr:
            try:
                if isinstance(item, int) and 1 <= item <= 9:
                    valid_numbers.append(item)
            except TypeError:
                # Ignore uncomparable/invalid items
                continue

        # Sort ascending, then reverse
        valid_numbers.sort(reverse=True)

        # Convert numbers to names
        return [digit_names[num] for num in valid_numbers]

    except TypeError:
        # If arr is not iterable
        return []
    except Exception:
        # Catch-all fallback for unexpected errors
        return []
candidate = by_length


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([2, 1, 1, 4, 5, 8, 2, 3]) == ["Eight", "Five", "Four", "Three", "Two", "Two", "One", "One"], "Error"
    assert candidate([]) == [], "Error"
    assert candidate([1, -1 , 55]) == ['One'], "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([1, -1, 3, 2]) == ["Three", "Two", "One"]
    assert candidate([9, 4, 8]) == ["Nine", "Eight", "Four"]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
