
import unittest
import re
import sys
import math
import copy



def sum_to_n(n: int):
    """sum_to_n is a function that sums numbers from 1 to n.

    >>> sum_to_n(30)
    465
    >>> sum_to_n(100)
    5050
    >>> sum_to_n(5)
    15
    >>> sum_to_n(10)
    55
    >>> sum_to_n(1)
    1
    """
    try:
        # Type validation
        if isinstance(n, bool):
            raise TypeError("n must be an integer, not a boolean")

        if not isinstance(n, int):
            raise TypeError("n must be an integer")

        # Value validation
        if n < 1:
            raise ValueError("n must be a positive integer greater than or equal to 1")

        # Use arithmetic series formula
        return n * (n + 1) // 2

    except TypeError as e:
        raise TypeError(f"Invalid type for sum_to_n: {e}") from e
    except ValueError as e:
        raise ValueError(f"Invalid value for sum_to_n: {e}") from e
    except OverflowError as e:
        raise OverflowError(f"Number too large to process: {e}") from e
    except Exception as e:
        raise RuntimeError(f"Unexpected error in sum_to_n: {e}") from e
candidate = sum_to_n




METADATA = {}


def check(candidate):
    assert candidate(1) == 1
    assert candidate(6) == 21
    assert candidate(11) == 66
    assert candidate(30) == 465
    assert candidate(100) == 5050



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
