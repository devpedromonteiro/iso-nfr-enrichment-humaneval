
import unittest
import re
import sys
import math
import copy


def words_in_sentence(sentence):
    """
    You are given a string representing a sentence,
    the sentence contains some words separated by a space,
    and you have to return a string that contains the words from the original sentence,
    whose lengths are prime numbers,
    the order of the words in the new string should be the same as the original one.

    Example 1:
        Input: sentence = "This is a test"
        Output: "is"

    Example 2:
        Input: sentence = "lets go for swimming"
        Output: "go for"

    Constraints:
        * 1 <= len(sentence) <= 100
        * sentence contains only letters
    """

    def is_prime(n):
        """Return True if n is a prime number, otherwise False."""
        try:
            if not isinstance(n, int):
                return False
            if n < 2:
                return False
            if n == 2:
                return True
            if n % 2 == 0:
                return False

            i = 3
            while i * i <= n:
                if n % i == 0:
                    return False
                i += 2
            return True
        except Exception:
            return False

    try:
        # Type validation
        if not isinstance(sentence, str):
            raise TypeError("Input must be a string.")

        # Empty or whitespace-only input handling
        if not sentence.strip():
            return ""

        # Length constraint check
        if len(sentence) > 100:
            raise ValueError("Sentence length must be between 1 and 100.")

        # Character validation:
        # allow letters and spaces only
        if not all(ch.isalpha() or ch.isspace() for ch in sentence):
            raise ValueError("Sentence must contain only letters and spaces.")

        words = sentence.split()
        prime_length_words = []

        for word in words:
            try:
                if is_prime(len(word)):
                    prime_length_words.append(word)
            except Exception:
                # Skip problematic words if any unexpected issue occurs
                continue

        return " ".join(prime_length_words)

    except TypeError as te:
        return f"TypeError: {te}"
    except ValueError as ve:
        return f"ValueError: {ve}"
    except Exception as e:
        return f"Unexpected error: {e}"
candidate = words_in_sentence


def check(candidate):

    # Check some simple cases
    assert candidate("This is a test") == "is"
    assert candidate("lets go for swimming") == "go for"
    assert candidate("there is no place available here") == "there is no place"
    assert candidate("Hi I am Hussein") == "Hi am Hussein"
    assert candidate("go for it") == "go for it"

    # Check some edge cases that are easy to work out by hand.
    assert candidate("here") == ""
    assert candidate("here is") == "is"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
