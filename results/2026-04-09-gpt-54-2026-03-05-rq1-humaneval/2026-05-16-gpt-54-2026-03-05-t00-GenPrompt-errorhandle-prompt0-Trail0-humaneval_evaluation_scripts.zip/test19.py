
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def sort_numbers(numbers: str) -> str:
    """Input is a space-delimited string of numerals from 'zero' to 'nine'.
    Valid choices are 'zero', 'one', 'two', 'three', 'four', 'five',
    'six', 'seven', 'eight' and 'nine'.

    Return the string with numbers sorted from smallest to largest.

    >>> sort_numbers('three one five')
    'one three five'
    >>> sort_numbers('nine zero two')
    'zero two nine'
    >>> sort_numbers('')
    ''
    """
    word_to_value = {
        "zero": 0,
        "one": 1,
        "two": 2,
        "three": 3,
        "four": 4,
        "five": 5,
        "six": 6,
        "seven": 7,
        "eight": 8,
        "nine": 9,
    }

    # Error handling: ensure input type is correct
    if not isinstance(numbers, str):
        raise TypeError("Input must be a string of space-delimited number words.")

    # Handle empty or whitespace-only input
    numbers = numbers.strip()
    if not numbers:
        return ""

    parts: List[str] = numbers.split()

    # Error handling: validate each token
    invalid_tokens = [token for token in parts if token not in word_to_value]
    if invalid_tokens:
        raise ValueError(
            f"Invalid number word(s): {', '.join(invalid_tokens)}. "
            "Valid choices are: zero, one, two, three, four, five, six, seven, eight, nine."
        )

    try:
        sorted_parts = sorted(parts, key=lambda word: word_to_value[word])
    except KeyError as e:
        # Defensive fallback, though validation above should prevent this
        raise ValueError(f"Unexpected invalid token encountered: {e.args[0]}") from e
    except Exception as e:
        # Generic safeguard for unexpected issues
        raise RuntimeError("An unexpected error occurred while sorting numbers.") from e

    return " ".join(sorted_parts)
candidate = sort_numbers




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == ''
    assert candidate('three') == 'three'
    assert candidate('three five nine') == 'three five nine'
    assert candidate('five zero four seven nine eight') == 'zero four five seven eight nine'
    assert candidate('six five four three two one zero') == 'zero one two three four five six'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
