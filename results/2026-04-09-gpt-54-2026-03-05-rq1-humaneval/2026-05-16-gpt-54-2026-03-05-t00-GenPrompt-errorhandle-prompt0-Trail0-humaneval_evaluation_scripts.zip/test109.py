
import unittest
import re
import sys
import math
import copy


def move_one_ball(arr):
    """Determine whether a list can be sorted in non-decreasing order
    using only cyclic right shifts.

    A right shift moves the last element to the front.

    Examples:
        move_one_ball([3, 4, 5, 1, 2]) -> True
        move_one_ball([3, 5, 4, 1, 2]) -> False
        move_one_ball([]) -> True
    """
    # Error handling: input must not be None
    if arr is None:
        raise ValueError("Input cannot be None.")

    # Error handling: input must be a list or tuple
    if not isinstance(arr, (list, tuple)):
        raise TypeError("Input must be a list or tuple of unique integers.")

    # Empty or single-element arrays are already sortable
    if len(arr) <= 1:
        return True

    # Error handling: ensure all elements are integers
    if not all(isinstance(x, int) for x in arr):
        raise TypeError("All elements in the input must be integers.")

    # Error handling: ensure elements are unique as stated in the problem
    if len(arr) != len(set(arr)):
        raise ValueError("All elements must be unique.")

    # Count how many times the order decreases
    # For a rotated sorted array with unique elements, this can happen at most once
    drops = 0
    n = len(arr)

    try:
        for i in range(n):
            if arr[i] > arr[(i + 1) % n]:
                drops += 1
                if drops > 1:
                    return False
    except Exception as e:
        raise RuntimeError(f"Unexpected error while processing array: {e}")

    return True
candidate = move_one_ball


def check(candidate):

    # Check some simple cases
    assert candidate([3, 4, 5, 1, 2])==True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([3, 5, 10, 1, 2])==True
    assert candidate([4, 3, 1, 2])==False
    # Check some edge cases that are easy to work out by hand.
    assert candidate([3, 5, 4, 1, 2])==False, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([])==True


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
