
import unittest
import re
import sys
import math
import copy



def fibfib(n: int):
    """Compute the n-th FibFib number.

    The FibFib sequence is defined as:
        fibfib(0) = 0
        fibfib(1) = 0
        fibfib(2) = 1
        fibfib(n) = fibfib(n-1) + fibfib(n-2) + fibfib(n-3) for n >= 3

    Examples:
    >>> fibfib(1)
    0
    >>> fibfib(5)
    4
    >>> fibfib(8)
    24
    """
    # Type validation
    if not isinstance(n, int):
        raise TypeError(f"n must be an integer, got {type(n).__name__}")

    # Value validation
    if n < 0:
        raise ValueError("n must be a non-negative integer")

    # Base cases
    if n == 0 or n == 1:
        return 0
    if n == 2:
        return 1

    # Iterative computation for efficiency: O(n) time, O(1) space
    a, b, c = 0, 0, 1
    try:
        for _ in range(3, n + 1):
            a, b, c = b, c, a + b + c
    except OverflowError as e:
        raise OverflowError("integer overflow occurred during FibFib computation") from e
    except Exception as e:
        raise RuntimeError("unexpected error during FibFib computation") from e

    return c
candidate = fibfib




METADATA = {}


def check(candidate):
    assert candidate(2) == 1
    assert candidate(1) == 0
    assert candidate(5) == 4
    assert candidate(8) == 24
    assert candidate(10) == 81
    assert candidate(12) == 274
    assert candidate(14) == 927



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
