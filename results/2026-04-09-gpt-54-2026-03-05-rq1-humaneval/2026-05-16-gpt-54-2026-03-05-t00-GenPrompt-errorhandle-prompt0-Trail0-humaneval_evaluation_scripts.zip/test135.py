
import unittest
import re
import sys
import math
import copy


def can_arrange(arr):
    """
    Return the largest index i such that arr[i] <= arr[i - 1].
    If no such index exists, return -1.

    The input array is expected to contain no duplicate values.

    Examples:
    can_arrange([1, 2, 4, 3, 5]) -> 3
    can_arrange([1, 2, 3]) -> -1
    """
    # Type validation
    if arr is None:
        raise ValueError("Input cannot be None.")

    if not isinstance(arr, (list, tuple)):
        raise TypeError("Input must be a list or tuple.")

    # Handle empty or single-element arrays
    if len(arr) < 2:
        return -1

    # Validate element comparability
    for i, val in enumerate(arr):
        if not isinstance(val, (int, float)):
            raise TypeError(f"Element at index {i} is not a number: {val!r}")

    # Find the largest index where current element is not greater than previous
    for i in range(len(arr) - 1, 0, -1):
        try:
            if arr[i] <= arr[i - 1]:
                return i
        except Exception as e:
            raise ValueError(f"Error comparing elements at indices {i-1} and {i}: {e}")

    return -1
candidate = can_arrange


def check(candidate):

    # Check some simple cases
    assert candidate([1,2,4,3,5])==3
    assert candidate([1,2,4,5])==-1
    assert candidate([1,4,2,5,6,7,8,9,10])==2
    assert candidate([4,8,5,7,3])==4

    # Check some edge cases that are easy to work out by hand.
    assert candidate([])==-1



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
