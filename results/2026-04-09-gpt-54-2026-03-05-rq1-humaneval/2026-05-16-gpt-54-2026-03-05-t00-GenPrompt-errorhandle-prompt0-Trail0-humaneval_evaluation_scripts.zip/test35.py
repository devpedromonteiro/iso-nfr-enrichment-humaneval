
import unittest
import re
import sys
import math
import copy



def max_element(l: list):
    """Return maximum element in the list.
    >>> max_element([1, 2, 3])
    3
    >>> max_element([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    123
    """
    # Type check
    if not isinstance(l, list):
        raise TypeError("Input must be a list.")

    # Empty list check
    if len(l) == 0:
        raise ValueError("List must not be empty.")

    # Validate elements and compute maximum
    try:
        maximum = l[0]
        for item in l:
            if not isinstance(item, (int, float)):
                raise TypeError("All elements in the list must be numbers.")
            if item > maximum:
                maximum = item
        return maximum
    except TypeError as e:
        raise TypeError(f"Error while processing list: {e}")
    except Exception as e:
        raise RuntimeError(f"Unexpected error: {e}")
candidate = max_element




METADATA = {}


def check(candidate):
    assert candidate([1, 2, 3]) == 3
    assert candidate([5, 3, -5, 2, -3, 3, 9, 0, 124, 1, -10]) == 124


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
