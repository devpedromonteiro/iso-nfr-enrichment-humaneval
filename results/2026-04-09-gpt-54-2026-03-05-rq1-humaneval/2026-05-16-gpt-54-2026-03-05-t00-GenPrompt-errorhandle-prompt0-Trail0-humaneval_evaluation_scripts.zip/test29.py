
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def filter_by_prefix(strings: List[str], prefix: str) -> List[str]:
    """Filter an input list of strings for ones that start with a given prefix.

    Error handling included:
    - Raises TypeError if `strings` is not a list
    - Raises TypeError if `prefix` is not a string
    - Raises TypeError if any element in `strings` is not a string

    >>> filter_by_prefix([], 'a')
    []
    >>> filter_by_prefix(['abc', 'bcd', 'cde', 'array'], 'a')
    ['abc', 'array']
    """
    if not isinstance(strings, list):
        raise TypeError(f"strings must be a list, got {type(strings).__name__}")

    if not isinstance(prefix, str):
        raise TypeError(f"prefix must be a string, got {type(prefix).__name__}")

    result = []
    for i, s in enumerate(strings):
        if not isinstance(s, str):
            raise TypeError(f"all items in strings must be str, item at index {i} is {type(s).__name__}")
        if s.startswith(prefix):
            result.append(s)

    return result
candidate = filter_by_prefix




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([], 'john') == []
    assert candidate(['xxx', 'asd', 'xxy', 'john doe', 'xxxAAA', 'xxx'], 'xxx') == ['xxx', 'xxxAAA', 'xxx']


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
