
import unittest
import re
import sys
import math
import copy


def smallest_change(arr):
    """
    Given an array arr of integers, find the minimum number of elements that
    need to be changed to make the array palindromic.

    A palindromic array reads the same forwards and backwards.
    In one change, you can change one element to any other element.

    Examples:
        smallest_change([1, 2, 3, 5, 4, 7, 9, 6]) == 4
        smallest_change([1, 2, 3, 4, 3, 2, 2]) == 1
        smallest_change([1, 2, 3, 2, 1]) == 0
    """
    # Error handling: input must not be None
    if arr is None:
        raise ValueError("Input cannot be None.")

    # Error handling: input must be a list or tuple
    if not isinstance(arr, (list, tuple)):
        raise TypeError("Input must be a list or tuple of integers.")

    # Error handling: all elements must be integers
    if not all(isinstance(x, int) for x in arr):
        raise TypeError("All elements in the input array must be integers.")

    changes = 0
    left = 0
    right = len(arr) - 1

    while left < right:
        try:
            if arr[left] != arr[right]:
                changes += 1
        except IndexError as e:
            raise IndexError("Unexpected indexing error while processing the array.") from e

        left += 1
        right -= 1

    return changes
candidate = smallest_change


def check(candidate):

    # Check some simple cases
    assert candidate([1,2,3,5,4,7,9,6]) == 4
    assert candidate([1, 2, 3, 4, 3, 2, 2]) == 1
    assert candidate([1, 4, 2]) == 1
    assert candidate([1, 4, 4, 2]) == 1

    # Check some edge cases that are easy to work out by hand.
    assert candidate([1, 2, 3, 2, 1]) == 0
    assert candidate([3, 1, 1, 3]) == 0
    assert candidate([1]) == 0
    assert candidate([0, 1]) == 1



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
