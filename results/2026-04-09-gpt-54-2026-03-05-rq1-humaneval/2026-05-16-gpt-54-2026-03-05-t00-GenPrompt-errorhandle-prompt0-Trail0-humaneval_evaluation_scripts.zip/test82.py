
import unittest
import re
import sys
import math
import copy


def prime_length(string):
    """Return True if the length of `string` is a prime number, else False.

    Examples:
        prime_length('Hello') == True
        prime_length('abcdcba') == True
        prime_length('kittens') == True
        prime_length('orange') == False
    """
    # Error handling: reject missing input
    if string is None:
        raise ValueError("Input cannot be None.")

    # Error handling: enforce correct type
    if not isinstance(string, str):
        raise TypeError("Input must be a string.")

    length = len(string)

    # Lengths less than 2 are not prime
    if length < 2:
        return False

    # 2 is prime
    if length == 2:
        return True

    # Even numbers greater than 2 are not prime
    if length % 2 == 0:
        return False

    # Check odd divisors up to sqrt(length)
    divisor = 3
    while divisor * divisor <= length:
        if length % divisor == 0:
            return False
        divisor += 2

    return True
candidate = prime_length


def check(candidate):

    # Check some simple cases
    assert candidate('Hello') == True
    assert candidate('abcdcba') == True
    assert candidate('kittens') == True
    assert candidate('orange') == False
    assert candidate('wow') == True
    assert candidate('world') == True
    assert candidate('MadaM') == True
    assert candidate('Wow') == True
    assert candidate('') == False
    assert candidate('HI') == True
    assert candidate('go') == True
    assert candidate('gogo') == False
    assert candidate('aaaaaaaaaaaaaaa') == False

    # Check some edge cases that are easy to work out by hand.
    assert candidate('Madam') == True
    assert candidate('M') == False
    assert candidate('0') == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
