
import unittest
import re
import sys
import math
import copy



def correct_bracketing(brackets: str):
    """brackets is a string of "<" and ">".
    return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("<")
    False
    >>> correct_bracketing("<>")
    True
    >>> correct_bracketing("<<><>>")
    True
    >>> correct_bracketing("><<>")
    False
    """
    try:
        if not isinstance(brackets, str):
            raise TypeError("Input must be a string.")

        balance = 0

        for char in brackets:
            if char == "<":
                balance += 1
            elif char == ">":
                balance -= 1
            else:
                raise ValueError("String must contain only '<' and '>' characters.")

            if balance < 0:
                return False

        return balance == 0

    except TypeError as te:
        print(f"Type error: {te}")
        return False
    except ValueError as ve:
        print(f"Value error: {ve}")
        return False
    except Exception as e:
        print(f"Unexpected error: {e}")
        return False
candidate = correct_bracketing




METADATA = {}


def check(candidate):
    assert candidate("<>")
    assert candidate("<<><>>")
    assert candidate("<><><<><>><>")
    assert candidate("<><><<<><><>><>><<><><<>>>")
    assert not candidate("<<<><>>>>")
    assert not candidate("><<>")
    assert not candidate("<")
    assert not candidate("<<<<")
    assert not candidate(">")
    assert not candidate("<<>")
    assert not candidate("<><><<><>><>><<>")
    assert not candidate("<><><<><>><>>><>")



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
