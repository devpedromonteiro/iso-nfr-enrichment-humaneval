
import unittest
import re
import sys
import math
import copy



def same_chars(s0: str, s1: str) -> bool:
    """
    Check if two words have the same unique characters, regardless of order
    or repetition.

    >>> same_chars('eabcdzzzz', 'dddzzzzzzzddeddabc')
    True
    >>> same_chars('abcd', 'dddddddabc')
    True
    >>> same_chars('dddddddabc', 'abcd')
    True
    >>> same_chars('eabcd', 'dddddddabc')
    False
    >>> same_chars('abcd', 'dddddddabce')
    False
    >>> same_chars('eabcdzzzz', 'dddzzzzzzzddddabc')
    False
    """
    try:
        if s0 is None or s1 is None:
            raise ValueError("Inputs cannot be None.")

        if not isinstance(s0, str) or not isinstance(s1, str):
            raise TypeError("Both inputs must be strings.")

        return set(s0) == set(s1)

    except TypeError as te:
        print(f"Type error: {te}")
        return False

    except ValueError as ve:
        print(f"Value error: {ve}")
        return False

    except Exception as e:
        print(f"Unexpected error: {e}")
        return False
candidate = same_chars




METADATA = {}


def check(candidate):
    assert candidate('eabcdzzzz', 'dddzzzzzzzddeddabc') == True
    assert candidate('abcd', 'dddddddabc') == True
    assert candidate('dddddddabc', 'abcd') == True
    assert candidate('eabcd', 'dddddddabc') == False
    assert candidate('abcd', 'dddddddabcf') == False
    assert candidate('eabcdzzzz', 'dddzzzzzzzddddabc') == False
    assert candidate('aabb', 'aaccc') == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
