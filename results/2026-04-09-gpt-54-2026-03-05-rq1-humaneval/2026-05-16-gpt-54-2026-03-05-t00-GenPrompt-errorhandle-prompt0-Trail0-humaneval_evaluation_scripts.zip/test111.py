
import unittest
import re
import sys
import math
import copy


def histogram(test):
    """Given a string representing space-separated lowercase letters, return a dictionary
    containing the letter(s) with the highest repetition and their count.

    Examples:
    histogram('a b c') == {'a': 1, 'b': 1, 'c': 1}
    histogram('a b b a') == {'a': 2, 'b': 2}
    histogram('a b c a b') == {'a': 2, 'b': 2}
    histogram('b b b b a') == {'b': 4}
    histogram('') == {}
    """
    try:
        # Type validation
        if not isinstance(test, str):
            raise TypeError("Input must be a string.")

        # Handle empty or whitespace-only input
        if not test.strip():
            return {}

        letters = test.split()
        counts = {}

        for letter in letters:
            # Value validation
            if not letter.isalpha() or not letter.islower() or len(letter) != 1:
                raise ValueError(
                    "Input must contain only space-separated lowercase single letters."
                )
            counts[letter] = counts.get(letter, 0) + 1

        max_count = max(counts.values())

        return {letter: count for letter, count in counts.items() if count == max_count}

    except TypeError as te:
        print(f"Type error: {te}")
        return {}
    except ValueError as ve:
        print(f"Value error: {ve}")
        return {}
    except Exception as e:
        print(f"Unexpected error: {e}")
        return {}
candidate = histogram


def check(candidate):

    # Check some simple cases
    assert candidate('a b b a') == {'a':2,'b': 2}, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('a b c a b') == {'a': 2, 'b': 2}, "This prints if this assert fails 2 (good for debugging!)"
    assert candidate('a b c d g') == {'a': 1, 'b': 1, 'c': 1, 'd': 1, 'g': 1}, "This prints if this assert fails 3 (good for debugging!)"
    assert candidate('r t g') == {'r': 1,'t': 1,'g': 1}, "This prints if this assert fails 4 (good for debugging!)"
    assert candidate('b b b b a') == {'b': 4}, "This prints if this assert fails 5 (good for debugging!)"
    assert candidate('r t g') == {'r': 1,'t': 1,'g': 1}, "This prints if this assert fails 6 (good for debugging!)"
    
    
    # Check some edge cases that are easy to work out by hand.
    assert candidate('') == {}, "This prints if this assert fails 7 (also good for debugging!)"
    assert candidate('a') == {'a': 1}, "This prints if this assert fails 8 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
