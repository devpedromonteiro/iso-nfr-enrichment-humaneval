
import unittest
import re
import sys
import math
import copy


def exchange(lst1, lst2):
    """Determine whether elements can be exchanged between two lists so that
    lst1 contains only even numbers.

    Rules:
    - Any number of exchanges is allowed.
    - Since only parity matters, each odd number in lst1 must be replaceable
      by an even number from lst2.
    - Return "YES" if possible, otherwise "NO".

    Error handling:
    - Returns "NO" for invalid inputs such as non-lists, empty lists,
      or lists containing non-numeric values.
    """
    try:
        # Validate input types
        if not isinstance(lst1, list) or not isinstance(lst2, list):
            raise TypeError("Both inputs must be lists.")

        # Validate non-empty lists
        if len(lst1) == 0 or len(lst2) == 0:
            raise ValueError("Input lists must be non-empty.")

        # Validate numeric contents
        if not all(isinstance(x, (int, float)) for x in lst1 + lst2):
            raise ValueError("All elements in both lists must be numbers.")

        # Count odd numbers in lst1
        odd_count_lst1 = sum(1 for x in lst1 if x % 2 != 0)

        # Count even numbers in lst2
        even_count_lst2 = sum(1 for x in lst2 if x % 2 == 0)

        return "YES" if even_count_lst2 >= odd_count_lst1 else "NO"

    except TypeError as te:
        print(f"Type error: {te}")
        return "NO"
    except ValueError as ve:
        print(f"Value error: {ve}")
        return "NO"
    except Exception as e:
        print(f"Unexpected error: {e}")
        return "NO"
candidate = exchange


def check(candidate):

    # Check some simple cases
    assert candidate([1, 2, 3, 4], [1, 2, 3, 4]) == "YES"
    assert candidate([1, 2, 3, 4], [1, 5, 3, 4]) == "NO"
    assert candidate([1, 2, 3, 4], [2, 1, 4, 3]) == "YES" 
    assert candidate([5, 7, 3], [2, 6, 4]) == "YES"
    assert candidate([5, 7, 3], [2, 6, 3]) == "NO" 
    assert candidate([3, 2, 6, 1, 8, 9], [3, 5, 5, 1, 1, 1]) == "NO"

    # Check some edge cases that are easy to work out by hand.
    assert candidate([100, 200], [200, 200]) == "YES"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
