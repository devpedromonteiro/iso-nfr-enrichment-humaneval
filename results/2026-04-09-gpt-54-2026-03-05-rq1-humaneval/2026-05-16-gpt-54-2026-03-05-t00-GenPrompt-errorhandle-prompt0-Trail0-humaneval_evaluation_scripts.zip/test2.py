
import unittest
import re
import sys
import math
import copy



def truncate_number(number: float) -> float:
    """Given a positive floating point number, return its decimal part.

    The decimal part is the leftover after removing the integer part.

    >>> truncate_number(3.5)
    0.5
    """
    try:
        if not isinstance(number, (int, float)):
            raise TypeError("Input must be an int or float.")

        if isinstance(number, bool):
            raise TypeError("Boolean values are not valid numbers here.")

        if number < 0:
            raise ValueError("Input must be a positive number.")

        return float(number) - int(number)

    except TypeError as e:
        raise TypeError(f"Type error in truncate_number: {e}")

    except ValueError as e:
        raise ValueError(f"Value error in truncate_number: {e}")

    except Exception as e:
        raise RuntimeError(f"Unexpected error in truncate_number: {e}")
candidate = truncate_number




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(3.5) == 0.5
    assert abs(candidate(1.33) - 0.33) < 1e-6
    assert abs(candidate(123.456) - 0.456) < 1e-6


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
