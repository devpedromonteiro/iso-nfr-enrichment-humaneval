
import unittest
import re
import sys
import math
import copy


def get_closest_vowel(word):
    """You are given a word. Your task is to find the closest vowel that stands between
    two consonants from the right side of the word (case sensitive).

    Vowels in the beginning and ending doesn't count. Return empty string if you didn't
    find any vowel met the above condition.

    You may assume that the given string contains English letter only.

    Example:
    get_closest_vowel("yogurt") ==> "u"
    get_closest_vowel("FULL") ==> "U"
    get_closest_vowel("quick") ==> ""
    get_closest_vowel("ab") ==> ""
    """
    vowels = "aeiouAEIOU"

    # Error handling: ensure input is a string
    if not isinstance(word, str):
        raise TypeError("Input must be a string.")

    # Error handling: handle short strings safely
    if len(word) < 3:
        return ""

    # Error handling: validate English letters only
    if not word.isalpha():
        raise ValueError("Input must contain English letters only.")

    # Search from right to left, excluding first and last characters
    for i in range(len(word) - 2, 0, -1):
        try:
            if (
                word[i] in vowels and
                word[i - 1] not in vowels and
                word[i + 1] not in vowels
            ):
                return word[i]
        except IndexError:
            # Defensive handling, though loop bounds already prevent this
            continue

    return ""
candidate = get_closest_vowel


def check(candidate):

    # Check some simple cases
    assert candidate("yogurt") == "u"
    assert candidate("full") == "u"
    assert candidate("easy") == ""
    assert candidate("eAsy") == ""
    assert candidate("ali") == ""
    assert candidate("bad") == "a"
    assert candidate("most") == "o"
    assert candidate("ab") == ""
    assert candidate("ba") == ""
    assert candidate("quick") == ""
    assert candidate("anime") == "i"
    assert candidate("Asia") == ""
    assert candidate("Above") == "o"

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
