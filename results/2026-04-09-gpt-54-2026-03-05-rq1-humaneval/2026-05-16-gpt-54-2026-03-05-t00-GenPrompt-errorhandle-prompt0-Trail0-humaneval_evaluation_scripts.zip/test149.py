
import unittest
import re
import sys
import math
import copy


def sorted_list_sum(lst):
    """
    Accepts a list of strings, removes strings with odd lengths,
    and returns the remaining strings sorted first by length,
    then alphabetically.

    Error handling:
    - Raises TypeError if input is not a list
    - Raises TypeError if any element is not a string
    - Returns [] for an empty list
    """
    try:
        if not isinstance(lst, list):
            raise TypeError("Input must be a list.")

        if not lst:
            return []

        for item in lst:
            if not isinstance(item, str):
                raise TypeError("All elements in the list must be strings.")

        even_length_strings = [s for s in lst if len(s) % 2 == 0]

        return sorted(even_length_strings, key=lambda x: (len(x), x))

    except TypeError as e:
        print(f"TypeError: {e}")
        return []
    except Exception as e:
        print(f"Unexpected error: {e}")
        return []
candidate = sorted_list_sum


def check(candidate):

    # Check some simple cases
    assert candidate(["aa", "a", "aaa"]) == ["aa"]
    assert candidate(["school", "AI", "asdf", "b"]) == ["AI", "asdf", "school"]
    assert candidate(["d", "b", "c", "a"]) == []
    assert candidate(["d", "dcba", "abcd", "a"]) == ["abcd", "dcba"]

    # Check some edge cases that are easy to work out by hand.
    assert candidate(["AI", "ai", "au"]) == ["AI", "ai", "au"]
    assert candidate(["a", "b", "b", "c", "c", "a"]) == []
    assert candidate(['aaaa', 'bbbb', 'dd', 'cc']) == ["cc", "dd", "aaaa", "bbbb"]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
