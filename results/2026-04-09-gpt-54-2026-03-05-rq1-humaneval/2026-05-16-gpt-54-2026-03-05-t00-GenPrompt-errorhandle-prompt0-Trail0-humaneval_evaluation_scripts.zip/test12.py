
import unittest
import re
import sys
import math
import copy

from typing import List, Optional


from typing import List, Optional


def longest(strings: List[str]) -> Optional[str]:
    """Out of list of strings, return the longest one.

    Return the first one in case of multiple strings of the same length.
    Return None in case the input list is empty.

    Error handling:
    - Raises TypeError if `strings` is not a list
    - Raises TypeError if any element in `strings` is not a string

    >>> longest([])
    >>> longest(['a', 'b', 'c'])
    'a'
    >>> longest(['a', 'bb', 'ccc'])
    'ccc'
    """
    if strings is None:
        return None

    if not isinstance(strings, list):
        raise TypeError("Input must be a list of strings.")

    if not strings:
        return None

    for i, s in enumerate(strings):
        if not isinstance(s, str):
            raise TypeError(f"Element at index {i} is not a string: {s!r}")

    try:
        return max(strings, key=len)
    except ValueError:
        # Defensive fallback, though empty list is already handled
        return None
    except Exception as e:
        raise RuntimeError(f"Unexpected error while finding longest string: {e}") from e
candidate = longest




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == None
    assert candidate(['x', 'y', 'z']) == 'x'
    assert candidate(['x', 'yyy', 'zzzz', 'www', 'kkkk', 'abc']) == 'zzzz'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
