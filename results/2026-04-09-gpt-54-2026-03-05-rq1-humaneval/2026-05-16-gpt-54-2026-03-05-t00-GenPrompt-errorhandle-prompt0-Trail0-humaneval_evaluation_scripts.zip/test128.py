
import unittest
import re
import sys
import math
import copy


def prod_signs(arr):
    """
    You are given an array arr of integers and you need to return
    sum of magnitudes of integers multiplied by product of all signs
    of each number in the array, represented by 1, -1 or 0.
    Note: return None for empty arr.

    Example:
    >>> prod_signs([1, 2, 2, -4]) == -9
    >>> prod_signs([0, 1]) == 0
    >>> prod_signs([]) == None
    """
    try:
        if arr is None:
            return None

        if not isinstance(arr, list):
            raise TypeError("Input must be a list.")

        if len(arr) == 0:
            return None

        sign_product = 1
        magnitude_sum = 0

        for x in arr:
            if not isinstance(x, int):
                raise TypeError("All elements in the array must be integers.")

            magnitude_sum += abs(x)

            if x == 0:
                sign_product = 0
            elif x < 0:
                sign_product *= -1

        return magnitude_sum * sign_product

    except TypeError as e:
        print(f"Type error: {e}")
        return None
    except Exception as e:
        print(f"Unexpected error: {e}")
        return None
candidate = prod_signs


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1, 2, 2, -4]) == -9
    assert candidate([0, 1]) == 0
    assert candidate([1, 1, 1, 2, 3, -1, 1]) == -10
    assert candidate([]) == None
    assert candidate([2, 4,1, 2, -1, -1, 9]) == 20
    assert candidate([-1, 1, -1, 1]) == 4
    assert candidate([-1, 1, 1, 1]) == -4
    assert candidate([-1, 1, 1, 0]) == 0

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
