
import unittest
import re
import sys
import math
import copy


def is_equal_to_sum_even(n):
    """Evaluate whether the given number n can be written as the sum of exactly 4 positive even numbers.

    A positive even number is one of: 2, 4, 6, ...
    The smallest possible sum of 4 positive even numbers is:
        2 + 2 + 2 + 2 = 8

    Therefore, n can be written as the sum of exactly 4 positive even numbers
    if and only if:
        1. n is an integer
        2. n is even
        3. n >= 8

    Examples:
        is_equal_to_sum_even(4) == False
        is_equal_to_sum_even(6) == False
        is_equal_to_sum_even(8) == True
    """
    try:
        # Reject booleans explicitly since bool is a subclass of int in Python
        if isinstance(n, bool):
            raise TypeError("Input must be an integer, not a boolean.")

        # Ensure input is an integer
        if not isinstance(n, int):
            raise TypeError("Input must be an integer.")

        # Negative numbers and odd numbers cannot satisfy the condition
        if n < 8:
            return False

        return n % 2 == 0

    except TypeError as e:
        print(f"Type error: {e}")
        return False
    except Exception as e:
        print(f"Unexpected error: {e}")
        return False
candidate = is_equal_to_sum_even


def check(candidate):
    assert candidate(4) == False
    assert candidate(6) == False
    assert candidate(8) == True
    assert candidate(10) == True
    assert candidate(11) == False
    assert candidate(12) == True
    assert candidate(13) == False
    assert candidate(16) == True


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
