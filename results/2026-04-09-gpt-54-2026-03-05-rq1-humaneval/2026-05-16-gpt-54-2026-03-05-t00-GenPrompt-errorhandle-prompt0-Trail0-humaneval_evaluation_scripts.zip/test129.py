
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Given an N x N grid containing each integer from 1 to N*N exactly once,
    return the lexicographically smallest path of length k, where each move
    goes to a 4-directionally adjacent cell.

    Error handling included for:
    - wrong input types
    - empty / malformed grid
    - non-square grid
    - invalid k
    - duplicate / missing values
    - values outside [1, N*N]
    """
    # ---------- Input validation ----------
    if not isinstance(grid, list):
        raise TypeError("grid must be a list of lists")

    if not grid:
        raise ValueError("grid must not be empty")

    if not all(isinstance(row, list) for row in grid):
        raise TypeError("grid must be a list of lists")

    n = len(grid)

    if n < 2:
        raise ValueError("grid must have at least 2 rows and 2 columns")

    if not all(len(row) == n for row in grid):
        raise ValueError("grid must be square (N x N)")

    if not isinstance(k, int):
        raise TypeError("k must be an integer")

    if k <= 0:
        raise ValueError("k must be a positive integer")

    # ---------- Validate grid values ----------
    values = []
    for i, row in enumerate(grid):
        for j, val in enumerate(row):
            if not isinstance(val, int):
                raise TypeError(f"grid[{i}][{j}] must be an integer")
            values.append(val)

    expected = set(range(1, n * n + 1))
    actual = set(values)

    if actual != expected:
        missing = sorted(expected - actual)
        extra = sorted(actual - expected)
        raise ValueError(
            f"grid must contain each integer from 1 to {n*n} exactly once. "
            f"Missing: {missing}, Extra/Invalid: {extra}"
        )

    if len(values) != len(set(values)):
        raise ValueError("grid contains duplicate values")

    # ---------- Build value -> position map ----------
    pos = {}
    for i in range(n):
        for j in range(n):
            pos[grid[i][j]] = (i, j)

    # ---------- Helper: neighbors ----------
    def neighbors(r, c):
        for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nr, nc = r + dr, c + dc
            if 0 <= nr < n and 0 <= nc < n:
                yield nr, nc

    # ---------- Dynamic lexicographic path construction ----------
    # Since values are unique, the smallest first value must be 1.
    start_r, start_c = pos[1]
    result = [1]
    current_positions = {(start_r, start_c)}

    for _ in range(1, k):
        next_candidates = []
        min_val = float('inf')

        # Find the minimum possible next value from all reachable positions
        for r, c in current_positions:
            for nr, nc in neighbors(r, c):
                val = grid[nr][nc]
                if val < min_val:
                    min_val = val

        # Collect all positions achieving that minimum value
        next_positions = set()
        for r, c in current_positions:
            for nr, nc in neighbors(r, c):
                if grid[nr][nc] == min_val:
                    next_positions.add((nr, nc))

        result.append(min_val)
        current_positions = next_positions

    return result
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
