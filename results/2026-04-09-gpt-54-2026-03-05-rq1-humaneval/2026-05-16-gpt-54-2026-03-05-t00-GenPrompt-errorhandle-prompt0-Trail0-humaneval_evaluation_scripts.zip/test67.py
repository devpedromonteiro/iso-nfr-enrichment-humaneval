
import unittest
import re
import sys
import math
import copy


import re

def fruit_distribution(s, n):
    """
    Given a string describing the number of apples and oranges in a basket,
    and an integer representing the total number of fruits, return the number
    of mangoes.

    Examples:
    fruit_distribution("5 apples and 6 oranges", 19) -> 8
    fruit_distribution("0 apples and 1 oranges", 3) -> 2
    fruit_distribution("2 apples and 3 oranges", 100) -> 95
    fruit_distribution("100 apples and 1 oranges", 120) -> 19
    """
    try:
        # Type validation
        if not isinstance(s, str):
            raise TypeError("The first argument must be a string.")
        if not isinstance(n, int):
            raise TypeError("The second argument must be an integer.")

        # Extract numbers from the string
        numbers = re.findall(r'\d+', s)
        if len(numbers) < 2:
            raise ValueError("The string must contain at least two numbers for apples and oranges.")

        apples = int(numbers[0])
        oranges = int(numbers[1])

        mangoes = n - apples - oranges

        # Logical validation
        if mangoes < 0:
            raise ValueError("Total fruits cannot be less than the sum of apples and oranges.")

        return mangoes

    except (TypeError, ValueError) as e:
        return f"Error: {e}"
    except Exception as e:
        return f"Unexpected error: {e}"
candidate = fruit_distribution


def check(candidate):

    # Check some simple cases
    assert candidate("5 apples and 6 oranges",19) == 8
    assert candidate("5 apples and 6 oranges",21) == 10
    assert candidate("0 apples and 1 oranges",3) == 2
    assert candidate("1 apples and 0 oranges",3) == 2
    assert candidate("2 apples and 3 oranges",100) == 95
    assert candidate("2 apples and 3 oranges",5) == 0
    assert candidate("1 apples and 100 oranges",120) == 19


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
