
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def rescale_to_unit(numbers: List[float]) -> List[float]:
    """Given a list of numbers, apply a linear transform so that the
    smallest number becomes 0 and the largest becomes 1.

    Requirements:
    - Input must be a list
    - List must contain at least two elements
    - All elements must be numeric
    - All values cannot be identical (would cause division by zero)

    >>> rescale_to_unit([1.0, 2.0, 3.0, 4.0, 5.0])
    [0.0, 0.25, 0.5, 0.75, 1.0]
    """
    if not isinstance(numbers, list):
        raise TypeError("Input must be a list.")

    if len(numbers) < 2:
        raise ValueError("List must contain at least two elements.")

    try:
        numbers = [float(x) for x in numbers]
    except (TypeError, ValueError) as e:
        raise TypeError("All elements in the list must be numeric.") from e

    minimum = min(numbers)
    maximum = max(numbers)

    if minimum == maximum:
        raise ValueError("Cannot rescale a list where all values are identical.")

    try:
        scale = maximum - minimum
        return [(x - minimum) / scale for x in numbers]
    except ZeroDivisionError as e:
        raise ValueError("Division by zero occurred during rescaling.") from e
    except Exception as e:
        raise RuntimeError(f"Unexpected error during rescaling: {e}") from e
candidate = rescale_to_unit




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([2.0, 49.9]) == [0.0, 1.0]
    assert candidate([100.0, 49.9]) == [1.0, 0.0]
    assert candidate([1.0, 2.0, 3.0, 4.0, 5.0]) == [0.0, 0.25, 0.5, 0.75, 1.0]
    assert candidate([2.0, 1.0, 5.0, 3.0, 4.0]) == [0.25, 0.0, 1.0, 0.5, 0.75]
    assert candidate([12.0, 11.0, 15.0, 13.0, 14.0]) == [0.25, 0.0, 1.0, 0.5, 0.75]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
