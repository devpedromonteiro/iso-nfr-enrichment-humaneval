
import unittest
import re
import sys
import math
import copy


def add(lst):
    """Given a non-empty list of integers lst, add the even elements
    that are at odd indices.

    Examples:
        add([4, 2, 6, 7]) ==> 2
    """
    try:
        # Check that input is a list
        if not isinstance(lst, list):
            raise TypeError("Input must be a list.")

        # Check that list is not empty
        if len(lst) == 0:
            raise ValueError("List must not be empty.")

        # Check that all elements are integers
        if not all(isinstance(x, int) for x in lst):
            raise TypeError("All elements in the list must be integers.")

        # Sum even elements at odd indices
        return sum(lst[i] for i in range(1, len(lst), 2) if lst[i] % 2 == 0)

    except Exception as e:
        return f"Error: {e}"
candidate = add


def check(candidate):

    # Check some simple cases
    assert candidate([4, 88]) == 88
    assert candidate([4, 5, 6, 7, 2, 122]) == 122
    assert candidate([4, 0, 6, 7]) == 0
    assert candidate([4, 4, 6, 8]) == 12

    # Check some edge cases that are easy to work out by hand.
    


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
