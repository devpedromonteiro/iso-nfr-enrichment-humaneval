
import unittest
import re
import sys
import math
import copy


def circular_shift(x, shift):
    """Circular shift the digits of the integer x, shifting right by `shift`
    and return the result as a string.

    Rules:
    - If `shift` is equal to the number of digits, the number is unchanged.
    - If `shift` is greater than the number of digits, return the digits reversed.

    Examples:
    >>> circular_shift(12, 1)
    '21'
    >>> circular_shift(12, 2)
    '12'
    """
    try:
        # Validate x
        if not isinstance(x, int):
            raise TypeError("x must be an integer")

        # Validate shift
        if not isinstance(shift, int):
            raise TypeError("shift must be an integer")

        # Handle negative values
        if x < 0:
            raise ValueError("x must be non-negative")
        if shift < 0:
            raise ValueError("shift must be non-negative")

        digits = str(x)
        n = len(digits)

        # Edge case: single digit
        if n == 1:
            return digits

        # If shift > number of digits, return reversed digits
        if shift > n:
            return digits[::-1]

        # Normalize shift when equal to or less than digit count
        shift = shift % n

        # Circular right shift
        if shift == 0:
            return digits
        return digits[-shift:] + digits[:-shift]

    except (TypeError, ValueError) as e:
        return f"Error: {e}"
candidate = circular_shift


def check(candidate):

    # Check some simple cases
    assert candidate(100, 2) == "001"
    assert candidate(12, 2) == "12"
    assert candidate(97, 8) == "79"
    assert candidate(12, 1) == "21", "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(11, 101) == "11", "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
