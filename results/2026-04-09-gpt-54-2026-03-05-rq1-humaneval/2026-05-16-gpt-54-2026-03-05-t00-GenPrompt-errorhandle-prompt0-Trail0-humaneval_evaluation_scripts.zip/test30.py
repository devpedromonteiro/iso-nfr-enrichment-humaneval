
import unittest
import re
import sys
import math
import copy



def get_positive(l: list):
    """Return only positive numbers in the list.
    >>> get_positive([-1, 2, -4, 5, 6])
    [2, 5, 6]
    >>> get_positive([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    [5, 3, 2, 3, 9, 123, 1]
    """
    if not isinstance(l, list):
        raise TypeError("Input must be a list.")

    positive_numbers = []

    for item in l:
        try:
            if isinstance(item, (int, float)) and item > 0:
                positive_numbers.append(item)
        except TypeError:
            # Skip items that cannot be compared to 0
            continue
        except Exception as e:
            print(f"Unexpected error processing {item}: {e}")

    return positive_numbers
candidate = get_positive




METADATA = {}


def check(candidate):
    assert candidate([-1, -2, 4, 5, 6]) == [4, 5, 6]
    assert candidate([5, 3, -5, 2, 3, 3, 9, 0, 123, 1, -10]) == [5, 3, 2, 3, 3, 9, 123, 1]
    assert candidate([-1, -2]) == []
    assert candidate([]) == []



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
