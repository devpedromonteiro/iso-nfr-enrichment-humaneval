
import unittest
import re
import sys
import math
import copy


def right_angle_triangle(a, b, c):
    '''
    Given the lengths of the three sides of a triangle, return True if the three
    sides form a right-angled triangle, False otherwise.

    A right-angled triangle is a triangle in which one angle is a right angle
    (90 degrees).

    Example:
    right_angle_triangle(3, 4, 5) == True
    right_angle_triangle(1, 2, 3) == False
    '''
    try:
        # Ensure inputs are numeric
        a = float(a)
        b = float(b)
        c = float(c)
    except (TypeError, ValueError):
        raise ValueError("All side lengths must be numbers.")

    # Side lengths must be positive
    if a <= 0 or b <= 0 or c <= 0:
        raise ValueError("Side lengths must be positive.")

    # Check triangle inequality
    sides = sorted([a, b, c])
    if sides[0] + sides[1] <= sides[2]:
        return False

    # Check Pythagorean theorem
    return sides[0] ** 2 + sides[1] ** 2 == sides[2] ** 2
candidate = right_angle_triangle


def check(candidate):

    # Check some simple cases
    assert candidate(3, 4, 5) == True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(1, 2, 3) == False
    assert candidate(10, 6, 8) == True
    assert candidate(2, 2, 2) == False
    assert candidate(7, 24, 25) == True
    assert candidate(10, 5, 7) == False
    assert candidate(5, 12, 13) == True
    assert candidate(15, 8, 17) == True
    assert candidate(48, 55, 73) == True

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1, 1, 1) == False, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate(2, 2, 10) == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
