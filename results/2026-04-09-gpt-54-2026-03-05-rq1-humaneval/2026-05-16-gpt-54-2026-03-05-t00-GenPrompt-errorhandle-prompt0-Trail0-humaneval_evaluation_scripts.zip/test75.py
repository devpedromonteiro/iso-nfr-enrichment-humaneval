
import unittest
import re
import sys
import math
import copy


def is_multiply_prime(a):
    """
    Return True if `a` can be written as the product of exactly 3 prime numbers,
    otherwise return False.

    Notes:
    - `a` should be an integer less than 100.
    - Repeated primes are allowed, e.g. 8 = 2 * 2 * 2 -> True
    - Includes basic error handling for invalid input.
    """

    # Error handling: reject None
    if a is None:
        return False

    # Error handling: reject non-integers
    if not isinstance(a, int):
        return False

    # Error handling: reject invalid range
    if a < 2 or a >= 100:
        return False

    def is_prime(n):
        """Check if a number is prime."""
        if n < 2:
            return False
        for i in range(2, int(n ** 0.5) + 1):
            if n % i == 0:
                return False
        return True

    try:
        primes = [i for i in range(2, a + 1) if is_prime(i)]

        # Check all combinations of 3 primes (including repeated ones)
        for p1 in primes:
            for p2 in primes:
                for p3 in primes:
                    if p1 * p2 * p3 == a:
                        return True

        return False

    except Exception:
        # Catch unexpected errors safely
        return False
candidate = is_multiply_prime


def check(candidate):

    assert candidate(5) == False
    assert candidate(30) == True
    assert candidate(8) == True
    assert candidate(10) == False
    assert candidate(125) == True
    assert candidate(3 * 5 * 7) == True
    assert candidate(3 * 6 * 7) == False
    assert candidate(9 * 9 * 9) == False
    assert candidate(11 * 9 * 9) == False
    assert candidate(11 * 13 * 7) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
