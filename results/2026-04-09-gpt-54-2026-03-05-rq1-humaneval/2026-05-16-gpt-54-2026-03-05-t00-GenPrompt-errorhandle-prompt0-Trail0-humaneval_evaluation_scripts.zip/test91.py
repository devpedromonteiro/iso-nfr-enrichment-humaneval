
import unittest
import re
import sys
import math
import copy


import re

def is_bored(S):
    """
    Count the number of sentences that start with the word "I".

    A boredom is defined as a sentence that begins with the standalone word "I".
    Sentences are delimited by '.', '?' or '!'.

    Examples:
    >>> is_bored("Hello world")
    0
    >>> is_bored("The sky is blue. The sun is shining. I love this weather")
    1
    >>> is_bored("I am bored. I am still bored!")
    2
    """

    # Error handling: ensure input is valid
    if S is None:
        return 0

    if not isinstance(S, str):
        raise TypeError("Input must be a string.")

    # Handle empty or whitespace-only strings
    if not S.strip():
        return 0

    try:
        # Split text into sentences using ., ?, !
        sentences = re.split(r'[.!?]', S)

        count = 0
        for sentence in sentences:
            sentence = sentence.strip()

            # Skip empty fragments
            if not sentence:
                continue

            # Check if sentence starts with standalone word "I"
            if re.match(r'^I', sentence):
                count += 1

        return count

    except re.error as e:
        raise ValueError(f"Regex processing failed: {e}")
    except Exception as e:
        raise RuntimeError(f"Unexpected error occurred: {e}")
candidate = is_bored


def check(candidate):

    # Check some simple cases
    assert candidate("Hello world") == 0, "Test 1"
    assert candidate("Is the sky blue?") == 0, "Test 2"
    assert candidate("I love It !") == 1, "Test 3"
    assert candidate("bIt") == 0, "Test 4"
    assert candidate("I feel good today. I will be productive. will kill It") == 2, "Test 5"
    assert candidate("You and I are going for a walk") == 0, "Test 6"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
