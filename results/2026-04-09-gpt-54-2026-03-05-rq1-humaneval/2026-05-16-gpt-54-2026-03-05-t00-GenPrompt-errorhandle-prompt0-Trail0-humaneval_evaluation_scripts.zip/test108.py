
import unittest
import re
import sys
import math
import copy


def count_nums(arr):
    """
    Write a function count_nums which takes an array of integers and returns
    the number of elements which has a sum of digits > 0.
    If a number is negative, then its first signed digit will be negative:
    e.g. -123 has signed digits -1, 2, and 3.

    >>> count_nums([]) == 0
    True
    >>> count_nums([-1, 11, -11]) == 1
    True
    >>> count_nums([1, 1, 2]) == 3
    True
    """
    # Error handling: input must be a list or tuple
    if not isinstance(arr, (list, tuple)):
        raise TypeError("Input must be a list or tuple of integers.")

    count = 0

    for num in arr:
        # Error handling: each element must be an integer
        if not isinstance(num, int):
            raise TypeError(f"All elements must be integers, got {type(num).__name__}.")

        try:
            # For negative numbers, the first digit is negative naturally
            digit_sum = sum(int(ch) for ch in str(num))
        except ValueError as e:
            raise ValueError(f"Invalid number encountered: {num}") from e

        if digit_sum > 0:
            count += 1

    return count
candidate = count_nums


def check(candidate):

    # Check some simple cases
    assert candidate([]) == 0
    assert candidate([-1, -2, 0]) == 0
    assert candidate([1, 1, 2, -2, 3, 4, 5]) == 6
    assert candidate([1, 6, 9, -6, 0, 1, 5]) == 5
    assert candidate([1, 100, 98, -7, 1, -1]) == 4
    assert candidate([12, 23, 34, -45, -56, 0]) == 5
    assert candidate([-0, 1**0]) == 1
    assert candidate([1]) == 1

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
