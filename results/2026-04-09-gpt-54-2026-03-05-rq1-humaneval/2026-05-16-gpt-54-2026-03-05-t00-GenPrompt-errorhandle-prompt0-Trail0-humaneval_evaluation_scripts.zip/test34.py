
import unittest
import re
import sys
import math
import copy



def unique(l: list):
    """Return sorted unique elements in a list

    >>> unique([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [0, 2, 3, 5, 9, 123]
    """
    # Type check for the input itself
    if not isinstance(l, list):
        raise TypeError(f"Expected a list, got {type(l).__name__}")

    try:
        # Remove duplicates
        unique_items = list(set(l))
    except TypeError as e:
        # Handles unhashable elements like nested lists/dicts
        raise TypeError("All elements in the list must be hashable") from e

    try:
        # Sort the unique elements
        return sorted(unique_items)
    except TypeError as e:
        # Handles elements that cannot be compared with each other
        raise TypeError("All elements in the list must be mutually comparable for sorting") from e
candidate = unique




METADATA = {}


def check(candidate):
    assert candidate([5, 3, 5, 2, 3, 3, 9, 0, 123]) == [0, 2, 3, 5, 9, 123]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
