
import unittest
import re
import sys
import math
import copy


def decimal_to_binary(decimal):
    """Convert a decimal number to a binary string wrapped with 'db'.

    Examples:
        decimal_to_binary(15) -> "db1111db"
        decimal_to_binary(32) -> "db100000db"
    """
    try:
        # Reject booleans explicitly since bool is a subclass of int
        if isinstance(decimal, bool):
            raise TypeError("Boolean values are not valid input.")

        # Ensure input is an integer
        if not isinstance(decimal, int):
            raise TypeError("Input must be an integer.")

        # Handle negative numbers
        if decimal < 0:
            raise ValueError("Input must be a non-negative integer.")

        # Special case for zero
        if decimal == 0:
            return "db0db"

        binary = ""
        while decimal > 0:
            binary = str(decimal % 2) + binary
            decimal //= 2

        return f"db{binary}db"

    except TypeError as te:
        return f"TypeError: {te}"
    except ValueError as ve:
        return f"ValueError: {ve}"
    except Exception as e:
        return f"Unexpected error: {e}"
candidate = decimal_to_binary


def check(candidate):

    # Check some simple cases
    assert candidate(0) == "db0db"
    assert candidate(32) == "db100000db"
    assert candidate(103) == "db1100111db"
    assert candidate(15) == "db1111db", "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
