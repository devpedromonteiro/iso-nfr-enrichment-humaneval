
import unittest
import re
import sys
import math
import copy

from typing import List, Tuple


from typing import List, Tuple


def sum_product(numbers: List[int]) -> Tuple[int, int]:
    """For a given list of integers, return a tuple consisting of the sum
    and the product of all the integers in the list.

    Empty sum is 0 and empty product is 1.

    >>> sum_product([])
    (0, 1)
    >>> sum_product([1, 2, 3, 4])
    (10, 24)
    """
    # Error handling: ensure input is actually a list
    if not isinstance(numbers, list):
        raise TypeError("numbers must be a list of integers")

    total_sum = 0
    total_product = 1

    for i, num in enumerate(numbers):
        # Error handling: ensure every element is an integer
        if not isinstance(num, int):
            raise TypeError(f"Element at index {i} is not an integer: {num!r}")

        total_sum += num
        total_product *= num

    return total_sum, total_product
candidate = sum_product




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == (0, 1)
    assert candidate([1, 1, 1]) == (3, 1)
    assert candidate([100, 0]) == (100, 0)
    assert candidate([3, 5, 7]) == (3 + 5 + 7, 3 * 5 * 7)
    assert candidate([10]) == (10, 10)


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
