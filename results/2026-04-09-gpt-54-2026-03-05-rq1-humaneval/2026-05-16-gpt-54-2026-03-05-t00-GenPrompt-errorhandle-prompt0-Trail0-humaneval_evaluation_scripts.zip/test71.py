
import unittest
import re
import sys
import math
import copy


import math

def triangle_area(a, b, c):
    '''
    Given the lengths of the three sides of a triangle, return the area of
    the triangle rounded to 2 decimal points if the three sides form a valid triangle.
    Otherwise return -1.

    Three sides make a valid triangle when the sum of any two sides is greater
    than the third side.

    Example:
    triangle_area(3, 4, 5) == 6.00
    triangle_area(1, 2, 10) == -1
    '''
    try:
        # Convert inputs to numbers in case strings like "3" are passed
        a = float(a)
        b = float(b)
        c = float(c)

        # Check for non-positive side lengths
        if a <= 0 or b <= 0 or c <= 0:
            return -1

        # Triangle inequality check
        if a + b <= c or a + c <= b or b + c <= a:
            return -1

        # Heron's formula
        s = (a + b + c) / 2
        area = math.sqrt(s * (s - a) * (s - b) * (s - c))

        return round(area, 2)

    except (ValueError, TypeError):
        # Handles invalid input types like letters, None, etc.
        return -1
    except Exception:
        # Catches any unexpected errors
        return -1
candidate = triangle_area


def check(candidate):

    # Check some simple cases
    assert candidate(3, 4, 5) == 6.00, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(1, 2, 10) == -1
    assert candidate(4, 8, 5) == 8.18
    assert candidate(2, 2, 2) == 1.73
    assert candidate(1, 2, 3) == -1
    assert candidate(10, 5, 7) == 16.25
    assert candidate(2, 6, 3) == -1

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1, 1, 1) == 0.43, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate(2, 2, 10) == -1



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
