
import unittest
import re
import sys
import math
import copy


def next_smallest(lst):
    """
    Return the 2nd smallest distinct integer in the list.
    Return None if there is no such element.

    Examples:
    next_smallest([1, 2, 3, 4, 5]) == 2
    next_smallest([5, 1, 4, 3, 2]) == 2
    next_smallest([]) == None
    next_smallest([1, 1]) == None
    """
    # Type check: input must be a list
    if not isinstance(lst, list):
        raise TypeError("Input must be a list.")

    # Empty or too-short list check
    if len(lst) < 2:
        return None

    # Validate all elements are integers
    for item in lst:
        if not isinstance(item, int):
            raise ValueError("All elements in the list must be integers.")

    try:
        # Remove duplicates and sort
        unique_sorted = sorted(set(lst))

        # If fewer than 2 distinct elements, no 2nd smallest exists
        if len(unique_sorted) < 2:
            return None

        return unique_sorted[1]

    except TypeError as e:
        # Handles unexpected comparison/sorting issues
        print(f"Type error occurred: {e}")
        return None
    except Exception as e:
        # Generic fallback for unexpected errors
        print(f"An unexpected error occurred: {e}")
        return None
candidate = next_smallest


def check(candidate):

    # Check some simple cases
    assert candidate([1, 2, 3, 4, 5]) == 2
    assert candidate([5, 1, 4, 3, 2]) == 2
    assert candidate([]) == None
    assert candidate([1, 1]) == None
    assert candidate([1,1,1,1,0]) == 1
    assert candidate([1, 0**0]) == None
    assert candidate([-35, 34, 12, -45]) == -35

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
