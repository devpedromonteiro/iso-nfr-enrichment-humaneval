
import unittest
import re
import sys
import math
import copy



def monotonic(l: list):
    """Return True if list elements are monotonically increasing or decreasing.

    A list is monotonic if it is entirely non-decreasing or non-increasing.

    >>> monotonic([1, 2, 4, 20])
    True
    >>> monotonic([1, 20, 4, 10])
    False
    >>> monotonic([4, 1, 0, -10])
    True
    >>> monotonic([])
    True
    >>> monotonic([5])
    True
    """
    # Type check for input
    if not isinstance(l, list):
        raise TypeError("Input must be a list.")

    # Empty or single-element lists are monotonic
    if len(l) <= 1:
        return True

    # Validate elements
    for i, item in enumerate(l):
        if not isinstance(item, (int, float)):
            raise TypeError(f"Element at index {i} is not a number: {item!r}")

    try:
        increasing = True
        decreasing = True

        for i in range(1, len(l)):
            if l[i] < l[i - 1]:
                increasing = False
            if l[i] > l[i - 1]:
                decreasing = False

        return increasing or decreasing

    except Exception as e:
        raise ValueError(f"Error while checking monotonicity: {e}")
candidate = monotonic




METADATA = {}


def check(candidate):
    assert candidate([1, 2, 4, 10]) == True
    assert candidate([1, 2, 4, 20]) == True
    assert candidate([1, 20, 4, 10]) == False
    assert candidate([4, 1, 0, -10]) == True
    assert candidate([4, 1, 1, 0]) == True
    assert candidate([1, 2, 3, 2, 5, 60]) == False
    assert candidate([1, 2, 3, 4, 5, 60]) == True
    assert candidate([9, 9, 9, 9]) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
