
import unittest
import re
import sys
import math
import copy



def is_prime(n):
    """Return True if a given number is prime, and False otherwise.

    >>> is_prime(6)
    False
    >>> is_prime(101)
    True
    >>> is_prime(11)
    True
    >>> is_prime(13441)
    True
    >>> is_prime(61)
    True
    >>> is_prime(4)
    False
    >>> is_prime(1)
    False
    """
    # Type validation
    if isinstance(n, bool):
        raise TypeError("Boolean values are not valid input for primality testing.")

    if not isinstance(n, int):
        raise TypeError("Input must be an integer.")

    # Value validation
    if n < 0:
        raise ValueError("Input must be a non-negative integer.")

    # Handle edge cases
    if n < 2:
        return False
    if n == 2:
        return True
    if n % 2 == 0:
        return False

    # Check odd divisors up to sqrt(n)
    try:
        i = 3
        while i * i <= n:
            if n % i == 0:
                return False
            i += 2
        return True
    except Exception as e:
        raise RuntimeError(f"Unexpected error while checking primality: {e}")
candidate = is_prime




METADATA = {}


def check(candidate):
    assert candidate(6) == False
    assert candidate(101) == True
    assert candidate(11) == True
    assert candidate(13441) == True
    assert candidate(61) == True
    assert candidate(4) == False
    assert candidate(1) == False
    assert candidate(5) == True
    assert candidate(11) == True
    assert candidate(17) == True
    assert candidate(5 * 17) == False
    assert candidate(11 * 7) == False
    assert candidate(13441 * 19) == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
