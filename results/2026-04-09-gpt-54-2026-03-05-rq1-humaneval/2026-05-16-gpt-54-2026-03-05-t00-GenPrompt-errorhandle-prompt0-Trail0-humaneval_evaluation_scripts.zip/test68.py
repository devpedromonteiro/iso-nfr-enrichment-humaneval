
import unittest
import re
import sys
import math
import copy


def pluck(arr):
    """
    Given an array of non-negative integers, return [smallest_even_value, index]
    for the smallest even value in the array. If multiple such values exist,
    return the one with the smallest index.

    If there are no even values or the array is empty, return [].

    Error handling:
    - Returns [] for None
    - Raises TypeError if input is not a list/tuple
    - Raises TypeError if any element is not an integer
    - Raises ValueError if any element is negative
    """
    try:
        if arr is None:
            return []

        if not isinstance(arr, (list, tuple)):
            raise TypeError("Input must be a list or tuple of non-negative integers.")

        if len(arr) == 0:
            return []

        smallest_even = None
        smallest_index = -1

        for i, value in enumerate(arr):
            if not isinstance(value, int):
                raise TypeError(f"All elements must be integers. Invalid element at index {i}: {value}")
            if value < 0:
                raise ValueError(f"All elements must be non-negative. Invalid element at index {i}: {value}")

            if value % 2 == 0:
                if smallest_even is None or value < smallest_even:
                    smallest_even = value
                    smallest_index = i

        return [smallest_even, smallest_index] if smallest_even is not None else []

    except (TypeError, ValueError) as e:
        print(f"Error: {e}")
        return []
    except Exception as e:
        print(f"Unexpected error: {e}")
        return []
candidate = pluck


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([4,2,3]) == [2, 1], "Error"
    assert candidate([1,2,3]) == [2, 1], "Error"
    assert candidate([]) == [], "Error"
    assert candidate([5, 0, 3, 0, 4, 2]) == [0, 1], "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([1, 2, 3, 0, 5, 3]) == [0, 3], "Error"
    assert candidate([5, 4, 8, 4 ,8]) == [4, 1], "Error"
    assert candidate([7, 6, 7, 1]) == [6, 1], "Error"
    assert candidate([7, 9, 7, 1]) == [], "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
