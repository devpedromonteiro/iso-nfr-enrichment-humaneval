
import unittest
import re
import sys
import math
import copy




def sum_squares(lst):
    """
    This function takes a list of integers. For each entry:
    - square it if its index is a multiple of 3
    - cube it if its index is a multiple of 4 and not a multiple of 3
    - otherwise leave it unchanged

    It then returns the sum of all resulting values.

    Examples:
    sum_squares([1, 2, 3]) -> 6
    sum_squares([]) -> 0
    sum_squares([-1, -5, 2, -1, -5]) -> -126
    """
    # Error handling: ensure input is a list
    if not isinstance(lst, list):
        raise TypeError("Input must be a list.")

    total = 0

    for i, val in enumerate(lst):
        # Error handling: ensure each element is an integer
        if not isinstance(val, int):
            raise TypeError(f"All elements must be integers. Invalid element at index {i}: {val}")

        try:
            if i % 3 == 0:
                total += val ** 2
            elif i % 4 == 0:
                total += val ** 3
            else:
                total += val
        except OverflowError:
            raise OverflowError(f"Numerical overflow occurred at index {i} with value {val}")
        except Exception as e:
            raise RuntimeError(f"Unexpected error at index {i}: {e}")

    return total
candidate = sum_squares


def check(candidate):

    # Check some simple cases
    
    assert candidate([1,2,3]) == 6
    assert candidate([1,4,9]) == 14
    assert candidate([]) == 0
    assert candidate([1,1,1,1,1,1,1,1,1]) == 9
    assert candidate([-1,-1,-1,-1,-1,-1,-1,-1,-1]) == -3
    assert candidate([0]) == 0
    assert candidate([-1,-5,2,-1,-5]) == -126
    assert candidate([-56,-99,1,0,-2]) == 3030
    assert candidate([-1,0,0,0,0,0,0,0,-1]) == 0
    assert candidate([-16, -9, -2, 36, 36, 26, -20, 25, -40, 20, -4, 12, -26, 35, 37]) == -14196
    assert candidate([-1, -3, 17, -1, -15, 13, -1, 14, -14, -12, -5, 14, -14, 6, 13, 11, 16, 16, 4, 10]) == -1448
    
    
    # Don't remove this line:


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
