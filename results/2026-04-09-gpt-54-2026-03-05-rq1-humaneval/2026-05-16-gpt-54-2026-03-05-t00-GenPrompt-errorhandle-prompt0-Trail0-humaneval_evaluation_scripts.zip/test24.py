
import unittest
import re
import sys
import math
import copy



def largest_divisor(n: int) -> int:
    """For a given integer n, return the largest proper divisor of n.

    A proper divisor is a positive integer smaller than n that divides n evenly.

    >>> largest_divisor(15)
    5
    >>> largest_divisor(13)
    1
    >>> largest_divisor(1)
    Traceback (most recent call last):
    ...
    ValueError: n must be greater than 1
    """
    # Type validation
    if not isinstance(n, int):
        raise TypeError("n must be an integer")

    # Value validation
    if n <= 1:
        raise ValueError("n must be greater than 1")

    try:
        # Search from n//2 downward for the largest proper divisor
        for i in range(n // 2, 0, -1):
            if n % i == 0:
                return i

        # This should never happen for valid integers > 1
        raise RuntimeError("Unexpected error: no divisor found")

    except ZeroDivisionError:
        # Defensive handling, though not expected here
        raise RuntimeError("Division by zero occurred unexpectedly")
    except Exception as e:
        # Re-raise unexpected errors with context
        raise RuntimeError(f"An unexpected error occurred: {e}") from e
candidate = largest_divisor




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(3) == 1
    assert candidate(7) == 1
    assert candidate(10) == 5
    assert candidate(100) == 50
    assert candidate(49) == 7


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
