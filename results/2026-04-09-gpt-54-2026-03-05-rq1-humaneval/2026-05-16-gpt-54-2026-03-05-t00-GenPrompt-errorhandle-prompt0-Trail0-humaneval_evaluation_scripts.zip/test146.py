
import unittest
import re
import sys
import math
import copy


def specialFilter(nums):
    """
    Takes a list of numbers and returns the count of elements that:
    1. are greater than 10
    2. have both first and last digits odd

    Examples:
    specialFilter([15, -73, 14, -15]) -> 1
    specialFilter([33, -2, -3, 45, 21, 109]) -> 2
    """
    # Error handling: input must be a list or tuple
    if not isinstance(nums, (list, tuple)):
        raise TypeError("Input must be a list or tuple of numbers.")

    count = 0
    odd_digits = {'1', '3', '5', '7', '9'}

    for i, num in enumerate(nums):
        try:
            # Ensure element is numeric
            if not isinstance(num, (int, float)):
                raise ValueError(f"Element at index {i} is not a number: {num}")

            # Ignore floats that are not whole numbers
            if isinstance(num, float):
                if not num.is_integer():
                    continue
                num = int(num)

            if num > 10:
                num_str = str(abs(num))
                if num_str[0] in odd_digits and num_str[-1] in odd_digits:
                    count += 1

        except Exception as e:
            # You can log the error or skip invalid entries
            print(f"Skipping invalid element at index {i}: {e}")
            continue

    return count
candidate = specialFilter


def check(candidate):

    # Check some simple cases
    assert candidate([5, -2, 1, -5]) == 0  
    assert candidate([15, -73, 14, -15]) == 1
    assert candidate([33, -2, -3, 45, 21, 109]) == 2
    assert candidate([43, -12, 93, 125, 121, 109]) == 4
    assert candidate([71, -2, -33, 75, 21, 19]) == 3


    # Check some edge cases that are easy to work out by hand.
    assert candidate([1]) == 0              
    assert candidate([]) == 0                   



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
