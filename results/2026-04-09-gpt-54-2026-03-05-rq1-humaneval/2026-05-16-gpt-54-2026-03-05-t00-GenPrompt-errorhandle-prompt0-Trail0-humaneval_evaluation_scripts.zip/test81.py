
import unittest
import re
import sys
import math
import copy


def numerical_letter_grade(grades):
    """Convert a list of GPA values to letter grades.

    Grading table:
         GPA       | Letter grade
          4.0      | A+
        > 3.7      | A
        > 3.3      | A-
        > 3.0      | B+
        > 2.7      | B
        > 2.3      | B-
        > 2.0      | C+
        > 1.7      | C
        > 1.3      | C-
        > 1.0      | D+
        > 0.7      | D
        > 0.0      | D-
          0.0      | E

    Example:
    numerical_letter_grade([4.0, 3, 1.7, 2, 3.5]) -> ['A+', 'B', 'C-', 'C', 'A-']
    """
    if grades is None:
        raise ValueError("grades cannot be None")

    if not isinstance(grades, (list, tuple)):
        raise TypeError("grades must be a list or tuple of numbers")

    result = []

    for i, grade in enumerate(grades):
        try:
            g = float(grade)
        except (TypeError, ValueError):
            raise ValueError(f"Invalid grade at index {i}: {grade!r}")

        if g < 0.0 or g > 4.0:
            raise ValueError(f"Grade out of valid GPA range [0.0, 4.0] at index {i}: {g}")

        if g == 4.0:
            result.append("A+")
        elif g > 3.7:
            result.append("A")
        elif g > 3.3:
            result.append("A-")
        elif g > 3.0:
            result.append("B+")
        elif g > 2.7:
            result.append("B")
        elif g > 2.3:
            result.append("B-")
        elif g > 2.0:
            result.append("C+")
        elif g > 1.7:
            result.append("C")
        elif g > 1.3:
            result.append("C-")
        elif g > 1.0:
            result.append("D+")
        elif g > 0.7:
            result.append("D")
        elif g > 0.0:
            result.append("D-")
        else:  # g == 0.0
            result.append("E")

    return result
candidate = numerical_letter_grade


def check(candidate):

    # Check some simple cases
    assert candidate([4.0, 3, 1.7, 2, 3.5]) == ['A+', 'B', 'C-', 'C', 'A-']
    assert candidate([1.2]) == ['D+']
    assert candidate([0.5]) == ['D-']
    assert candidate([0.0]) == ['E']
    assert candidate([1, 0.3, 1.5, 2.8, 3.3]) == ['D', 'D-', 'C-', 'B', 'B+']
    assert candidate([0, 0.7]) == ['E', 'D-']

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
