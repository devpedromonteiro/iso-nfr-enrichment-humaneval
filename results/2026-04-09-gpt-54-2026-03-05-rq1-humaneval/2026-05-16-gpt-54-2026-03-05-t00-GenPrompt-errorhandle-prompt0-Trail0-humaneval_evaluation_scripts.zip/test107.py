
import unittest
import re
import sys
import math
import copy


def even_odd_palindrome(n):
    """
    Given a positive integer n, return a tuple containing:
    (number_of_even_palindromes, number_of_odd_palindromes)
    in the inclusive range 1..n.

    Example:
        even_odd_palindrome(3) -> (1, 2)
        even_odd_palindrome(12) -> (4, 6)
    """

    # Type validation
    if not isinstance(n, int):
        raise TypeError("Input must be an integer.")

    # Value validation
    if n < 1:
        raise ValueError("Input must be a positive integer greater than or equal to 1.")

    # Optional constraint check based on prompt
    if n > 10**3:
        raise ValueError("Input must be less than or equal to 10^3.")

    even_count = 0
    odd_count = 0

    for num in range(1, n + 1):
        try:
            # Check if the number is a palindrome
            if str(num) == str(num)[::-1]:
                if num % 2 == 0:
                    even_count += 1
                else:
                    odd_count += 1
        except Exception as e:
            # General safeguard, though unlikely here
            raise RuntimeError(f"Unexpected error while processing {num}: {e}")

    return (even_count, odd_count)
candidate = even_odd_palindrome


def check(candidate):

    # Check some simple cases
    assert candidate(123) == (8, 13)
    assert candidate(12) == (4, 6)
    assert candidate(3) == (1, 2)
    assert candidate(63) == (6, 8)
    assert candidate(25) == (5, 6)
    assert candidate(19) == (4, 6)
    assert candidate(9) == (4, 5), "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1) == (0, 1), "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
