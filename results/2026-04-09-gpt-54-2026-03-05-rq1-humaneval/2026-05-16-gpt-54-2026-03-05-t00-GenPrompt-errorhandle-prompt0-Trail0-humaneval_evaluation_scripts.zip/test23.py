
import unittest
import re
import sys
import math
import copy



def strlen(string: str) -> int:
    """Return length of given string.

    Includes basic error handling:
    - Raises TypeError if input is not a string
    - Safely handles unexpected errors

    >>> strlen('')
    0
    >>> strlen('abc')
    3
    """
    try:
        if string is None:
            raise ValueError("Input cannot be None")

        if not isinstance(string, str):
            raise TypeError(f"Expected str, got {type(string).__name__}")

        return len(string)

    except (TypeError, ValueError):
        raise

    except Exception as e:
        raise RuntimeError(f"Unexpected error while calculating string length: {e}") from e
candidate = strlen




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == 0
    assert candidate('x') == 1
    assert candidate('asdasnakj') == 9


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
