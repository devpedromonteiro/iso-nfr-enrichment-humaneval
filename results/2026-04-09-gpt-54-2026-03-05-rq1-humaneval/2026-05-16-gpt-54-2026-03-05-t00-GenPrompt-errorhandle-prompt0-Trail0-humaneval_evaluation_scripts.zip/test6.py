
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """Input to this function is a string representing multiple groups of
    nested parentheses separated by spaces.

    For each group, return the deepest level of nesting.

    Examples:
    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    >>> parse_nested_parens('')
    []
    >>> parse_nested_parens('() (())')
    [1, 2]
    """
    # Type validation
    if not isinstance(paren_string, str):
        raise TypeError("paren_string must be a string")

    # Handle empty or whitespace-only input
    if not paren_string.strip():
        return []

    results: List[int] = []

    for group in paren_string.split():
        depth = 0
        max_depth = 0

        try:
            for char in group:
                if char == '(':
                    depth += 1
                    max_depth = max(max_depth, depth)
                elif char == ')':
                    depth -= 1
                    if depth < 0:
                        raise ValueError(f"Unbalanced parentheses in group: {group}")
                else:
                    raise ValueError(f"Invalid character '{char}' in group: {group}")

            if depth != 0:
                raise ValueError(f"Unbalanced parentheses in group: {group}")

            results.append(max_depth)

        except ValueError as e:
            # Re-raise with context for easier debugging
            raise ValueError(f"Error while parsing group '{group}': {e}") from e

    return results
candidate = parse_nested_parens




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('(()()) ((())) () ((())()())') == [2, 3, 1, 3]
    assert candidate('() (()) ((())) (((())))') == [1, 2, 3, 4]
    assert candidate('(()(())((())))') == [4]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
