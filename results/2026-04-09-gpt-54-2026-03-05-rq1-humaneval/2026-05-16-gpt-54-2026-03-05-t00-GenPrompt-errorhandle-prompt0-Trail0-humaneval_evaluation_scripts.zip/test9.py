
import unittest
import re
import sys
import math
import copy

from typing import List, Tuple


from typing import List


def rolling_max(numbers: List[int]) -> List[int]:
    """From a given list of integers, generate a list of rolling maximum
    element found until a given moment in the sequence.

    Error handling techniques used:
    - Type checking for the input container
    - Type checking for each element
    - Graceful handling of empty input

    >>> rolling_max([1, 2, 3, 2, 3, 4, 2])
    [1, 2, 3, 3, 3, 4, 4]
    >>> rolling_max([])
    []
    """
    if numbers is None:
        raise ValueError("Input cannot be None.")

    if not isinstance(numbers, list):
        raise TypeError("Input must be a list of integers.")

    if not numbers:
        return []

    result: List[int] = []
    current_max = None

    for i, num in enumerate(numbers):
        if not isinstance(num, int):
            raise TypeError(f"Element at index {i} is not an integer: {num!r}")

        if current_max is None or num > current_max:
            current_max = num

        result.append(current_max)

    return result
candidate = rolling_max




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == []
    assert candidate([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert candidate([4, 3, 2, 1]) == [4, 4, 4, 4]
    assert candidate([3, 2, 3, 100, 3]) == [3, 3, 3, 100, 100]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
