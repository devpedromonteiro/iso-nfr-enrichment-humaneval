
import unittest
import re
import sys
import math
import copy


def will_it_fly(q, w):
    '''
    Write a function that returns True if the object q will fly, and False otherwise.
    The object q will fly if it's balanced (it is a palindromic list) and the sum of its elements is less than or equal the maximum possible weight w.

    Example:
    will_it_fly([1, 2], 5) â False 
    # 1+2 is less than the maximum possible weight, but it's unbalanced.

    will_it_fly([3, 2, 3], 1) â False
    # it's balanced, but 3+2+3 is more than the maximum possible weight.

    will_it_fly([3, 2, 3], 9) â True
    # 3+2+3 is less than the maximum possible weight, and it's balanced.

    will_it_fly([3], 5) â True
    # 3 is less than the maximum possible weight, and it's balanced.
    '''
    try:
        if not isinstance(q, list):
            raise TypeError("q must be a list")
        if not isinstance(w, (int, float)):
            raise TypeError("w must be a number")
        if not all(isinstance(x, (int, float)) for x in q):
            raise ValueError("all elements in q must be numbers")

        balanced = q == q[::-1]
        total_weight = sum(q)

        return balanced and total_weight <= w

    except TypeError as te:
        print(f"Type error: {te}")
        return False
    except ValueError as ve:
        print(f"Value error: {ve}")
        return False
    except Exception as e:
        print(f"Unexpected error: {e}")
        return False
candidate = will_it_fly


def check(candidate):

    # Check some simple cases
    assert candidate([3, 2, 3], 9) is True
    assert candidate([1, 2], 5) is False
    assert candidate([3], 5) is True
    assert candidate([3, 2, 3], 1) is False


    # Check some edge cases that are easy to work out by hand.
    assert candidate([1, 2, 3], 6) is False
    assert candidate([5], 5) is True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
