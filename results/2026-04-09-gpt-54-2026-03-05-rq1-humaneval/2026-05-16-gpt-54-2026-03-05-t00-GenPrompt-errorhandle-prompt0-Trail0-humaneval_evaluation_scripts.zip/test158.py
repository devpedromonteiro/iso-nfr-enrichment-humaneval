
import unittest
import re
import sys
import math
import copy


def find_max(words):
    """
    Accepts a list of strings and returns the word with the maximum number
    of unique characters.

    If multiple words have the same maximum number of unique characters,
    the lexicographically smallest one is returned.

    Examples:
        find_max(["name", "of", "string"]) -> "string"
        find_max(["name", "enam", "game"]) -> "enam"
        find_max(["aaaaaaa", "bb", "cc"]) -> "aaaaaaa"
    """

    # Error handling: input must be a list
    if not isinstance(words, list):
        raise TypeError("Input must be a list of strings.")

    # Error handling: list must not be empty
    if not words:
        raise ValueError("Input list cannot be empty.")

    # Error handling: all elements must be strings
    if not all(isinstance(word, str) for word in words):
        raise TypeError("All elements in the list must be strings.")

    try:
        max_unique = -1
        result = None

        for word in words:
            unique_count = len(set(word))

            if unique_count > max_unique:
                max_unique = unique_count
                result = word
            elif unique_count == max_unique:
                if word < result:
                    result = word

        return result

    except Exception as e:
        raise RuntimeError(f"An unexpected error occurred: {e}")
candidate = find_max


def check(candidate):

    # Check some simple cases
    assert (candidate(["name", "of", "string"]) == "string"), "t1"
    assert (candidate(["name", "enam", "game"]) == "enam"), 't2'
    assert (candidate(["aaaaaaa", "bb", "cc"]) == "aaaaaaa"), 't3'
    assert (candidate(["abc", "cba"]) == "abc"), 't4'
    assert (candidate(["play", "this", "game", "of","footbott"]) == "footbott"), 't5'
    assert (candidate(["we", "are", "gonna", "rock"]) == "gonna"), 't6'
    assert (candidate(["we", "are", "a", "mad", "nation"]) == "nation"), 't7'
    assert (candidate(["this", "is", "a", "prrk"]) == "this"), 't8'

    # Check some edge cases that are easy to work out by hand.
    assert (candidate(["b"]) == "b"), 't9'
    assert (candidate(["play", "play", "play"]) == "play"), 't10'



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
