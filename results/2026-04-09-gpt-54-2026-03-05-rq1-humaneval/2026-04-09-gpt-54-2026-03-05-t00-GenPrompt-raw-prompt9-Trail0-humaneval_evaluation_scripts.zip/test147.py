
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    def comb3(x):
        return x * (x - 1) * (x - 2) // 6 if x >= 3 else 0

    count_0 = (n + 1) // 3   # indices where i % 3 == 2
    count_1 = n - count_0    # remaining indices

    return comb3(count_0) + comb3(count_1)
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
