
import unittest


def sort_array(array):
    if len(array) < 2:
        return array[:]
    return sorted(array, reverse=((array[0] + array[-1]) % 2 == 0))
candidate = sort_array


class Test(unittest.TestCase):
    def test(self):
        assert candidate([7, 6]) == [6, 7]
        assert candidate([3, 1]) == [3, 1]
        assert candidate([2, 4, 3, 0, 1, 5, 6]) == [6, 5, 4, 3, 2, 1, 0], "Error"

    # Check some edge cases that are easy to work out by hand.
        assert candidate([17, 42, 85, 34, 12, 2]) == [2, 12, 17, 34, 42, 85]
        assert candidate([5, 8, 7, 2, 3, 8, 5]) == [8, 8, 7, 5, 5, 3, 2]
        assert candidate([19, 43, 92, 29, 10, 5]) == [92, 43, 29, 19, 10, 5]
        assert candidate([5]) == [5], "Error"
        assert candidate([7, 2, 5, 1, 2, 8, 5]) == [8, 7, 5, 5, 2, 2, 1]
        assert candidate([4]) == [4]
        assert candidate([1, 3]) == [3, 1]
        assert candidate([2, 5]) == [2, 5]
        assert candidate([1, 4, 4, 3, 3, 7]) == [7, 4, 4, 3, 3, 1]
        assert candidate([5, 9, 5, 4, 1, 3, 3]) == [9, 5, 5, 4, 3, 3, 1]
        assert candidate([1, 1, 4, 1, 6, 3]) == [6, 4, 3, 1, 1, 1]
        assert candidate([4, 1]) == [1, 4]
        assert candidate([2, 7, 3, 3, 4, 1]) == [1, 2, 3, 3, 4, 7]
        assert candidate([6]) == [6]
        assert candidate([5, 7, 2, 3, 4, 5, 5]) == [7, 5, 5, 5, 4, 3, 2]
        assert candidate([12, 41, 88, 32, 15, 3]) == [3, 12, 15, 32, 41, 88]
        assert candidate([2, 6]) == [6, 2]
        assert candidate([2, 2, 2, 3, 5, 1]) == [1, 2, 2, 2, 3, 5]
        assert candidate([2, 3]) == [2, 3]
        assert candidate([5, 1, 5, 2, 3, 7]) == [7, 5, 5, 3, 2, 1]
        assert candidate([17, 41, 88, 37, 13, 5]) == [88, 41, 37, 17, 13, 5]
        assert candidate([7]) == [7]
        assert candidate([12, 44, 88, 34, 15, 4]) == [88, 44, 34, 15, 12, 4]
        assert candidate([3, 3, 6, 3, 3, 5]) == [6, 5, 3, 3, 3, 3]
        assert candidate([1, 3, 6, 3, 6, 8, 3]) == [8, 6, 6, 3, 3, 3, 1]
        assert candidate([3, 8, 1, 4, 3, 7]) == [8, 7, 4, 3, 3, 1]
        assert candidate([1, 4, 2, 3, 5, 1, 9]) == [9, 5, 4, 3, 2, 1, 1]
        assert candidate([2, 1]) == [1, 2], "Error"
        assert candidate([5, 2, 8, 5, 4, 9, 10]) == [2, 4, 5, 5, 8, 9, 10]
        assert candidate([17, 47, 91, 27, 9, 3]) == [91, 47, 27, 17, 9, 3]
        assert candidate([1, 4, 8, 5, 1, 3]) == [8, 5, 4, 3, 1, 1]
        assert candidate([5, 6, 6, 4, 4, 6]) == [4, 4, 5, 6, 6, 6]
        assert candidate([1, 1, 4, 4, 3, 5, 6]) == [1, 1, 3, 4, 4, 5, 6]
        assert candidate([4, 3, 8, 5, 3, 8, 4]) == [8, 8, 5, 4, 4, 3, 3]
        assert candidate([15, 39, 90, 27, 10, 4]) == [4, 10, 15, 27, 39, 90]
        assert candidate([7, 1, 4, 3, 3, 1, 2]) == [1, 1, 2, 3, 3, 4, 7]
        assert candidate([21, 14, 23, 11]) == [23, 21, 14, 11], "Error"
        assert candidate([2, 1, 7, 1, 4, 10, 10]) == [10, 10, 7, 4, 2, 1, 1]
        assert candidate([13, 42, 84, 33, 6, 4]) == [4, 6, 13, 33, 42, 84]
        assert candidate([8]) == [8]
        assert candidate([18, 42, 84, 33, 16, 2]) == [84, 42, 33, 18, 16, 2]
        assert candidate([7, 5, 7, 1, 3, 1, 5]) == [7, 7, 5, 5, 3, 1, 1]
        assert candidate([4, 7, 6, 5, 3, 2]) == [7, 6, 5, 4, 3, 2]
        assert candidate([7, 3, 3, 1, 1, 9, 7]) == [9, 7, 7, 3, 3, 1, 1]
        assert candidate([13, 40, 91, 32, 10, 4]) == [4, 10, 13, 32, 40, 91]
        assert candidate([3]) == [3]
        assert candidate([2, 2, 6, 5, 3, 7]) == [2, 2, 3, 5, 6, 7]
        assert candidate([2, 4]) == [4, 2]
        assert candidate([1, 2, 4, 3, 2, 8]) == [1, 2, 2, 3, 4, 8]
        assert candidate([]) == [], "Error"
        assert candidate([2, 4, 3, 0, 1, 5]) == [0, 1, 2, 3, 4, 5], "Error"
        assert candidate([4, 4]) == [4, 4]
        assert candidate([2, 2, 4, 3, 5, 2]) == [5, 4, 3, 2, 2, 2]
        assert candidate([3, 3, 1, 4, 5, 7]) == [7, 5, 4, 3, 3, 1]
        assert candidate([6, 5, 4, 4, 6, 1, 1]) == [1, 1, 4, 4, 5, 6, 6]
        assert candidate([5]) == [5]
        assert candidate([1, 4]) == [1, 4]
        assert candidate([5, 3]) == [5, 3]
        assert candidate([17, 40, 85, 33, 12, 2]) == [2, 12, 17, 33, 40, 85]
        assert candidate([1, 8, 7, 3, 5, 10]) == [1, 3, 5, 7, 8, 10]
        assert candidate([4, 6, 4, 2, 3, 10]) == [10, 6, 4, 4, 3, 2]
        assert candidate([20, 44, 88, 37, 6, 3]) == [3, 6, 20, 37, 44, 88]
        assert candidate([2, 8, 4, 2, 4, 2, 10]) == [10, 8, 4, 4, 2, 2, 2]
        assert candidate([5, 4]) == [4, 5]
        assert candidate([5, 7, 1, 3, 4, 4, 8]) == [1, 3, 4, 4, 5, 7, 8]
        assert candidate([7, 5]) == [7, 5]
        assert candidate([10]) == [10]
        assert candidate([19, 40, 90, 35, 14, 2]) == [2, 14, 19, 35, 40, 90]
        assert candidate([5, 7, 7, 4, 1, 7, 5]) == [7, 7, 7, 5, 5, 4, 1]
        assert candidate([15, 42, 87, 32 ,11, 0]) == [0, 11, 15, 32, 42, 87], "Error"
        assert candidate([19, 42, 86, 33, 14, 5]) == [86, 42, 33, 19, 14, 5]
        assert candidate([12, 42, 83, 36, 8, 4]) == [83, 42, 36, 12, 8, 4]
        assert candidate([9]) == [9]
        assert candidate([6, 9, 2, 5, 1, 10, 8]) == [10, 9, 8, 6, 5, 2, 1]
        assert candidate([]) == []
        assert candidate([13, 40, 91, 29, 15, 5]) == [91, 40, 29, 15, 13, 5]
        assert candidate([19, 41, 82, 29, 14, 1]) == [82, 41, 29, 19, 14, 1]
        assert candidate([4, 5, 6, 2, 1, 7]) == [1, 2, 4, 5, 6, 7]
        assert candidate([19, 37, 86, 36, 14, 5]) == [86, 37, 36, 19, 14, 5]
        assert candidate([6, 4, 8, 4, 2, 3]) == [2, 3, 4, 4, 6, 8]

if __name__ == '__main__':
    unittest.main()
