
import unittest
import re
import sys
import math
import copy


def even_odd_palindrome(n):
    even = odd = 0

    for i in range(1, n + 1):
        s = str(i)
        if s == s[::-1]:
            if i & 1:
                odd += 1
            else:
                even += 1

    return (even, odd)
candidate = even_odd_palindrome


def check(candidate):

    # Check some simple cases
    assert candidate(123) == (8, 13)
    assert candidate(12) == (4, 6)
    assert candidate(3) == (1, 2)
    assert candidate(63) == (6, 8)
    assert candidate(25) == (5, 6)
    assert candidate(19) == (4, 6)
    assert candidate(9) == (4, 5), "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1) == (0, 1), "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
