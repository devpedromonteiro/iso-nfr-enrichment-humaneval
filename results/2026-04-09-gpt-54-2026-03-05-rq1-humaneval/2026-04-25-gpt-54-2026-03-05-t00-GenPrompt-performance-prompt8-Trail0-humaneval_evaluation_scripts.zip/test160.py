
import unittest
import re
import sys
import math
import copy


def do_algebra(operator, operand):
    ops = {'+': 1, '-': 1, '*': 2, '//': 2, '**': 3}
    values = [operand[0]]
    operators = []

    for i, op in enumerate(operator):
        while operators and (
            ops[operators[-1]] > ops[op] or
            (ops[operators[-1]] == ops[op] and op != '**')
        ):
            b = values.pop()
            a = values.pop()
            top = operators.pop()

            if top == '+':
                values.append(a + b)
            elif top == '-':
                values.append(a - b)
            elif top == '*':
                values.append(a * b)
            elif top == '//':
                values.append(a // b)
            else:
                values.append(a ** b)

        operators.append(op)
        values.append(operand[i + 1])

    while operators:
        b = values.pop()
        a = values.pop()
        top = operators.pop()

        if top == '+':
            values.append(a + b)
        elif top == '-':
            values.append(a - b)
        elif top == '*':
            values.append(a * b)
        elif top == '//':
            values.append(a // b)
        else:
            values.append(a ** b)

    return values[0]
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
