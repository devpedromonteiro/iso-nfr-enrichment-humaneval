
import unittest
import re
import sys
import math
import copy


def is_bored(S):
    count = 0
    start = True

    for ch in S:
        if start:
            if ch == ' ':
                continue
            if ch == 'I':
                start = False
                continue
            while ch not in '.?!':
                start = False
                break

        if ch in '.?!':
            start = True

    return count + sum(
        1
        for i, ch in enumerate(S)
        if ch == 'I'
        and (i == 0 or S[i - 1] in '.?!')
        and (i + 1 == len(S) or S[i + 1] in ' .?!')
    )
candidate = is_bored


def check(candidate):

    # Check some simple cases
    assert candidate("Hello world") == 0, "Test 1"
    assert candidate("Is the sky blue?") == 0, "Test 2"
    assert candidate("I love It !") == 1, "Test 3"
    assert candidate("bIt") == 0, "Test 4"
    assert candidate("I feel good today. I will be productive. will kill It") == 2, "Test 5"
    assert candidate("You and I are going for a walk") == 0, "Test 6"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
