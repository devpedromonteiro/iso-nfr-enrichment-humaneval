
import unittest
import re
import sys
import math
import copy



def is_palindrome(string: str) -> bool:
    """ Test if given string is a palindrome """
    return string == string[::-1]


def is_palindrome(string: str) -> bool:
    """Test if given string is a palindrome."""
    return string == string[::-1]


def make_palindrome(string: str) -> str:
    """Find the shortest palindrome that begins with the supplied string.

    The result is formed by appending the fewest possible characters to the end
    of `string` so that the whole result becomes a palindrome.

    Strategy:
    - Find the earliest index `i` such that `string[i:]` is a palindrome.
    - Append the reverse of `string[:i]`.

    This is optimal because it preserves the original prefix and adds the
    minimum suffix needed.

    >>> make_palindrome('')
    ''
    >>> make_palindrome('cat')
    'catac'
    >>> make_palindrome('cata')
    'catac'
    >>> make_palindrome('race')
    'racecar'
    >>> make_palindrome('aba')
    'aba'
    """
    n = len(string)
    if n < 2:
        return string

    for i in range(n):
        suffix = string[i:]
        if suffix == suffix[::-1]:
            return string + string[:i][::-1]

    return string
candidate = make_palindrome




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == ''
    assert candidate('x') == 'x'
    assert candidate('xyz') == 'xyzyx'
    assert candidate('xyx') == 'xyx'
    assert candidate('jerry') == 'jerryrrej'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
