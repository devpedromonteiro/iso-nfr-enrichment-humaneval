
import unittest
import re
import sys
import math
import copy


def will_it_fly(q, w):
    total = 0
    n = len(q)

    for i in range((n + 1) // 2):
        if q[i] != q[n - 1 - i]:
            return False
        total += q[i]
        if i != n - 1 - i:
            total += q[n - 1 - i]
        if total > w:
            return False

    return True
candidate = will_it_fly


def check(candidate):

    # Check some simple cases
    assert candidate([3, 2, 3], 9) is True
    assert candidate([1, 2], 5) is False
    assert candidate([3], 5) is True
    assert candidate([3, 2, 3], 1) is False


    # Check some edge cases that are easy to work out by hand.
    assert candidate([1, 2, 3], 6) is False
    assert candidate([5], 5) is True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
