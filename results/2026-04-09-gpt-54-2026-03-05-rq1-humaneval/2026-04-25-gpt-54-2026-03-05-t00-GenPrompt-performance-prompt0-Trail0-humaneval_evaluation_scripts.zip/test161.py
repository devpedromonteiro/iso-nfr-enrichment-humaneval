
import unittest
import re
import sys
import math
import copy


def solve(s):
    has_alpha = False
    chars = []

    for ch in s:
        if 'a' <= ch <= 'z':
            chars.append(chr(ord(ch) - 32))
            has_alpha = True
        elif 'A' <= ch <= 'Z':
            chars.append(chr(ord(ch) + 32))
            has_alpha = True
        else:
            chars.append(ch)

    return ''.join(chars) if has_alpha else s[::-1]
candidate = solve


def check(candidate):

    # Check some simple cases
    assert candidate("AsDf") == "aSdF"
    assert candidate("1234") == "4321"
    assert candidate("ab") == "AB"
    assert candidate("#a@C") == "#A@c"
    assert candidate("#AsdfW^45") == "#aSDFw^45"
    assert candidate("#6@2") == "2@6#"

    # Check some edge cases that are easy to work out by hand.
    assert candidate("#$a^D") == "#$A^d"
    assert candidate("#ccc") == "#CCC"

    # Don't remove this line:


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
