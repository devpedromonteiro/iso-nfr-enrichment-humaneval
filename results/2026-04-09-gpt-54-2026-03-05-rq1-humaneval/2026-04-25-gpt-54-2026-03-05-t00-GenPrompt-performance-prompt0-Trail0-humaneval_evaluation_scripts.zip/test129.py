
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Given a grid with N rows and N columns (N >= 2) and a positive integer k,
    each cell of the grid contains a value. Every integer in the range [1, N * N]
    inclusive appears exactly once on the cells of the grid.

    Return the lexicographically smallest path of length k, where each move goes
    to a 4-directionally adjacent cell.
    """
    n = len(grid)

    # Position of each value: pos[v] = (r, c)
    pos = [None] * (n * n + 1)
    for r in range(n):
        row = grid[r]
        for c in range(n):
            pos[row[c]] = (r, c)

    # Precompute neighbors for each value, sorted by cell value.
    neighbors = [[] for _ in range(n * n + 1)]
    for v in range(1, n * n + 1):
        r, c = pos[v]
        cand = []
        if r > 0:
            cand.append(grid[r - 1][c])
        if r + 1 < n:
            cand.append(grid[r + 1][c])
        if c > 0:
            cand.append(grid[r][c - 1])
        if c + 1 < n:
            cand.append(grid[r][c + 1])
        cand.sort()
        neighbors[v] = cand

    # dp[t][v] = rank of the lexicographically smallest suffix of length t
    # starting from value v.
    #
    # For t = 1, suffix is just [v], so rank is v itself.
    prev_rank = list(range(n * n + 1))  # index 0 unused

    # Build ranks for lengths 2..k using pair compression:
    # sequence(v, t) = (v, rank(best next suffix of length t-1))
    for _ in range(2, k + 1):
        pairs = [None] * (n * n + 1)

        for v in range(1, n * n + 1):
            best_next = neighbors[v][0]
            best_rank = prev_rank[best_next]

            # Since neighbors are sorted by value, we still must compare by suffix rank
            # after the first differing element. So choose neighbor with minimum
            # sequence rank of length t-1.
            for u in neighbors[v][1:]:
                ru = prev_rank[u]
                if ru < best_rank:
                    best_rank = ru
                    best_next = u

            pairs[v] = (v, best_rank)

        # Compress pairs into ranks
        uniq = sorted((pairs[v], v) for v in range(1, n * n + 1))
        curr_rank = [0] * (n * n + 1)
        rank = 0
        last_pair = None
        for pair, v in uniq:
            if pair != last_pair:
                rank += 1
                last_pair = pair
            curr_rank[v] = rank

        prev_rank = curr_rank

    # Find best starting value
    best_start = 1
    for v in range(2, n * n + 1):
        if prev_rank[v] < prev_rank[best_start]:
            best_start = v

    # Reconstruct answer.
    # To do that efficiently, rebuild chosen next pointers.
    if k == 1:
        return [best_start]

    # Store best next choice for each length layer.
    next_choice_layers = []

    prev_rank = list(range(n * n + 1))
    for _ in range(2, k + 1):
        next_choice = [0] * (n * n + 1)
        pairs = [None] * (n * n + 1)

        for v in range(1, n * n + 1):
            best_next = neighbors[v][0]
            best_rank = prev_rank[best_next]
            for u in neighbors[v][1:]:
                ru = prev_rank[u]
                if ru < best_rank:
                    best_rank = ru
                    best_next = u
            next_choice[v] = best_next
            pairs[v] = (v, best_rank)

        uniq = sorted((pairs[v], v) for v in range(1, n * n + 1))
        curr_rank = [0] * (n * n + 1)
        rank = 0
        last_pair = None
        for pair, v in uniq:
            if pair != last_pair:
                rank += 1
                last_pair = pair
            curr_rank[v] = rank

        next_choice_layers.append(next_choice)
        prev_rank = curr_rank

    best_start = 1
    for v in range(2, n * n + 1):
        if prev_rank[v] < prev_rank[best_start]:
            best_start = v

    ans = [best_start]
    cur = best_start
    # next_choice_layers[i] corresponds to path length i+2
    for layer in range(k - 2, -1, -1):
        cur = next_choice_layers[layer][cur]
        ans.append(cur)

    return ans
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
