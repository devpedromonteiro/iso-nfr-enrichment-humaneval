
import unittest
import re
import sys
import math
import copy


def get_odd_collatz(n):
    """
    Given a positive integer n, return a sorted list containing the odd numbers
    that appear in the Collatz sequence of n.

    The returned list is sorted in increasing order.

    Example:
        get_odd_collatz(5) -> [1, 5]
    """
    odds = set()

    while True:
        if n & 1:  # faster odd check than n % 2
            odds.add(n)
            if n == 1:
                break
            n = 3 * n + 1
        else:
            n >>= 1  # faster than n // 2 for integers

    return sorted(odds)
candidate = get_odd_collatz


def check(candidate):

    # Check some simple cases
    assert candidate(14) == [1, 5, 7, 11, 13, 17]
    assert candidate(5) == [1, 5]
    assert candidate(12) == [1, 3, 5], "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1) == [1], "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
