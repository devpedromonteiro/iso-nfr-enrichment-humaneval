
import unittest
import re
import sys
import math
import copy


def solve(N):
    """Given a non-negative integer N, return the sum of its decimal digits,
    represented as a binary string.

    Examples:
        solve(1000) -> "1"      # 1+0+0+0 = 1 -> binary "1"
        solve(150)  -> "110"    # 1+5+0 = 6 -> binary "110"
        solve(147)  -> "1100"   # 1+4+7 = 12 -> binary "1100"
    """
    digit_sum = 0

    while N:
        digit_sum += N % 10
        N //= 10

    return bin(digit_sum)[2:]
candidate = solve


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(1000) == "1", "Error"
    assert candidate(150) == "110", "Error"
    assert candidate(147) == "1100", "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate(333) == "1001", "Error"
    assert candidate(963) == "10010", "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
