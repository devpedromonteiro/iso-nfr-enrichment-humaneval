
import unittest
import re
import sys
import math
import copy



def largest_divisor(n: int) -> int:
    """For a given number n, find the largest number that divides n evenly, smaller than n.

    >>> largest_divisor(15)
    5
    >>> largest_divisor(13)
    1
    >>> largest_divisor(1)
    0
    """
    if n <= 1:
        return 0

    # The largest proper divisor is n divided by its smallest divisor > 1.
    limit = int(n**0.5)
    for d in range(2, limit + 1):
        if n % d == 0:
            return n // d

    return 1
candidate = largest_divisor




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(3) == 1
    assert candidate(7) == 1
    assert candidate(10) == 5
    assert candidate(100) == 50
    assert candidate(49) == 7


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
