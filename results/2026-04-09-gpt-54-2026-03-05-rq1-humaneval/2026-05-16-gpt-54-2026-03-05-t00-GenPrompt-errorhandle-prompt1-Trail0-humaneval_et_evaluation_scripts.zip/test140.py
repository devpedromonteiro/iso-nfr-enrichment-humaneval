
import unittest


def fix_spaces(text):
    """
    Given a string text, replace all spaces in it with underscores,
    and if a string has more than 2 consecutive spaces,
    then replace all consecutive spaces with -

    fix_spaces("Example") == "Example"
    fix_spaces("Example 1") == "Example_1"
    fix_spaces(" Example 2") == "_Example_2"
    fix_spaces(" Example   3") == "_Example-3"
    """
    try:
        if not isinstance(text, str):
            raise TypeError("Input must be a string")

        result = []
        i = 0
        n = len(text)

        while i < n:
            if text[i] == ' ':
                count = 0
                while i < n and text[i] == ' ':
                    count += 1
                    i += 1
                result.append('-' if count > 2 else '_' * count)
            else:
                result.append(text[i])
                i += 1

        return ''.join(result)

    except TypeError as e:
        return f"TypeError: {e}"
    except Exception as e:
        return f"Unexpected error: {e}"
candidate = fix_spaces


class Test(unittest.TestCase):
    def test(self):
        assert candidate("tDl") == 'tDl'
        assert candidate("bgzrizRZMLul WO") == 'bgzrizRZMLul_WO'
        assert candidate("lfzgnYOWZP HeUYnmXviC  q u  ") == 'lfzgnYOWZP_HeUYnmXviC__q_u_'
        assert candidate(" Zh CENyelFfzphBIUN JhPibcsu") == '_Zh_CENyelFfzphBIUN_JhPibcsu'
        assert candidate("wfjZyDWmoOkq") == 'wfjZyDWmoOkq'
        assert candidate("s BqawCWXTPFuq") == 's_BqawCWXTPFuq'
        assert candidate("wSF") == 'wSF'
        assert candidate("zIWnI ZT qkPQGUt IWaReADRqGj qt") == 'zIWnI_ZT_qkPQGUt_IWaReADRqGj_qt'
        assert candidate("W8rOXLe qHiAd 1e") == 'W8rOXLe_qHiAd_1e'
        assert candidate("WcIJIkVqIuTy") == 'WcIJIkVqIuTy'
        assert candidate("KZLm zj V") == 'KZLm_zj_V'
        assert candidate("GWeAlrikrt") == 'GWeAlrikrt'
        assert candidate("XXXhd gvveQpx") == 'XXXhd_gvveQpx'
        assert candidate("jP ZMGh wL") == 'jP_ZMGh_wL'
        assert candidate("xPWFEb  Ds") == 'xPWFEb__Ds'
        assert candidate("LgsGYeLKpcGPxWdWWmYiwJk G") == 'LgsGYeLKpcGPxWdWWmYiwJk_G'
        assert candidate("KvPFFG DKS K") == 'KvPFFG_DKS_K'
        assert candidate("riAXMK0R dwwvuRuz0j0T") == 'riAXMK0R_dwwvuRuz0j0T'
        assert candidate("oA56m o vry8fF E") == 'oA56m_o_vry8fF_E'
        assert candidate("KADlzEo uSIfcAEx EcybDfB") == 'KADlzEo_uSIfcAEx_EcybDfB'
        assert candidate("c4NsVcWOuv9 I7NWmf") == 'c4NsVcWOuv9_I7NWmf'
        assert candidate("qvLUqajSLFlJvxi DihtmSpggA QL") == 'qvLUqajSLFlJvxi_DihtmSpggA_QL'
        assert candidate("Example") == "Example"
        assert candidate("aiCpCl ") == 'aiCpCl_'
        assert candidate("N3j2DEcS 8ZBJ GElo") == 'N3j2DEcS_8ZBJ_GElo'
        assert candidate("dQkgzwp WPy") == 'dQkgzwp_WPy'
        assert candidate("YSPlkBqcNOIzI  Gxs fQEBDDm   p") == 'YSPlkBqcNOIzI__Gxs_fQEBDDm-p'
        assert candidate("TMGVP9m  N CHor  ") == 'TMGVP9m__N_CHor_'
        assert candidate("euMbAQMiO WROXqYZ") == 'euMbAQMiO_WROXqYZ'
        assert candidate("LsQXjcCmJvpbRvF") == 'LsQXjcCmJvpbRvF'
        assert candidate("Pqq") == 'Pqq'
        assert candidate("rArrfeyPwoO") == 'rArrfeyPwoO'
        assert candidate("wgC  PGde TIhSTUCt ZrbtxPU") == 'wgC__PGde_TIhSTUCt_ZrbtxPU'
        assert candidate("DOg Vo n7KyT3JoV") == 'DOg_Vo_n7KyT3JoV'
        assert candidate("hMS MDFRVC LjX p") == 'hMS_MDFRVC_LjX_p'
        assert candidate("v5Ec0Im4 zEw") == 'v5Ec0Im4_zEw'
        assert candidate(" HlWByHxPC SJfWg") == '_HlWByHxPC_SJfWg'
        assert candidate("nNYBvpXg QGtbCs") == 'nNYBvpXg_QGtbCs'
        assert candidate("XL3zCHleZjf8 z fBra 2") == 'XL3zCHleZjf8_z_fBra_2'
        assert candidate("GaWyVZOS L  Vzzp Ppy  ZgK HbA") == 'GaWyVZOS_L__Vzzp_Ppy__ZgK_HbA'
        assert candidate("yGOxnEp wDjcEEWJOXWZdduncc") == 'yGOxnEp_wDjcEEWJOXWZdduncc'
        assert candidate("pooMg E 9QYWyjooC4YrR") == 'pooMg_E_9QYWyjooC4YrR'
        assert candidate("c8 PtkRMrGTuO PgY") == 'c8_PtkRMrGTuO_PgY'
        assert candidate("Yellow Yellow  Dirty  Fellow") == "Yellow_Yellow__Dirty__Fellow"
        assert candidate("LSvTJTWXIY6xd") == 'LSvTJTWXIY6xd'
        assert candidate("pEeOqcw") == 'pEeOqcw'
        assert candidate("GSsLIYNG") == 'GSsLIYNG'
        assert candidate("omKia Ds b") == 'omKia_Ds_b'
        assert candidate("LG PRlPytPxIp") == 'LG_PRlPytPxIp'
        assert candidate("6 Qi8F29fd0cusDXbco1B") == '6_Qi8F29fd0cusDXbco1B'
        assert candidate("H  TOi  ") == 'H__TOi_'
        assert candidate("WQaojTbrKEjIxu") == 'WQaojTbrKEjIxu'
        assert candidate("uhfatkgA") == 'uhfatkgA'
        assert candidate("DhZX wS0A 8 aRbr7") == 'DhZX_wS0A_8_aRbr7'
        assert candidate("CxwPCoxwy") == 'CxwPCoxwy'
        assert candidate("fvNwUQK iXFVvd xF") == 'fvNwUQK_iXFVvd_xF'
        assert candidate("DdQPEN") == 'DdQPEN'
        assert candidate("ro7QFhNH NIFU3r8") == 'ro7QFhNH_NIFU3r8'
        assert candidate("Mudasir Hanif ") == "Mudasir_Hanif_"
        assert candidate("IZUqpZhoHYqeW HDHQ5NC") == 'IZUqpZhoHYqeW_HDHQ5NC'
        assert candidate("Exa   mple") == "Exa-mple"
        assert candidate("juJj") == 'juJj'
        assert candidate("obSHyRNW K") == 'obSHyRNW_K'
        assert candidate("qWvJIpCwkJAC D") == 'qWvJIpCwkJAC_D'
        assert candidate("FPd Ry") == 'FPd_Ry'
        assert candidate(" hNrjmnT") == '_hNrjmnT'
        assert candidate("g5Os0N59EWK4O9SPhH") == 'g5Os0N59EWK4O9SPhH'
        assert candidate("mR t VWhN") == 'mR_t_VWhN'
        assert candidate("nsvNbyVkTqppn") == 'nsvNbyVkTqppn'
        assert candidate("MLqiYNDnirbdZPE  fNh DwRKg v") == 'MLqiYNDnirbdZPE__fNh_DwRKg_v'
        assert candidate("RrcD fuBdffFGBipShndUHBIxqo") == 'RrcD_fuBdffFGBipShndUHBIxqo'
        assert candidate("SSubQcHrtIhhkcEr") == 'SSubQcHrtIhhkcEr'
        assert candidate("UmwisBcJrND  ") == 'UmwisBcJrND_'
        assert candidate("m  7H uwEkuQ AsUJ2aE") == 'm__7H_uwEkuQ_AsUJ2aE'
        assert candidate("P HhjA") == 'P_HhjA'
        assert candidate("TimB h C  aDVBM") == 'TimB_h_C__aDVBM'
        assert candidate("sWs") == 'sWs'
        assert candidate("znaZRzT") == 'znaZRzT'
        assert candidate("IUaSHLXIWSpJSl fSZHMEluTSNml x ") == 'IUaSHLXIWSpJSl_fSZHMEluTSNml_x_'
        assert candidate("DLEMmv HNUx") == 'DLEMmv_HNUx'
        assert candidate("efSC ja0qnM ZRf") == 'efSC_ja0qnM_ZRf'
        assert candidate("bBp  L IkxCuj") == 'bBp__L_IkxCuj'
        assert candidate("RJcVkMFMyxQi") == 'RJcVkMFMyxQi'
        assert candidate("8ko7aW0  HWHDih") == '8ko7aW0__HWHDih'
        assert candidate("sRewqfQk VHqKAhEUby b XhSOxF") == 'sRewqfQk_VHqKAhEUby_b_XhSOxF'
        assert candidate("NjL AiGVzsLVW") == 'NjL_AiGVzsLVW'
        assert candidate("rsXd HjOLw") == 'rsXd_HjOLw'
        assert candidate("fWH qE MT  EfztB CCnwceQb") == 'fWH_qE_MT__EfztB_CCnwceQb'
        assert candidate("  X kMm mnlmqHa") == '__X_kMm_mnlmqHa'
        assert candidate("uo3B0 gh 0b8oi") == 'uo3B0_gh_0b8oi'
        assert candidate("tjDYCHG V") == 'tjDYCHG_V'
        assert candidate("lyjgnrJJ ") == 'lyjgnrJJ_'
        assert candidate("HSjqtRnWF") == 'HSjqtRnWF'
        assert candidate("   Exa 1 2 2 mple") == "-Exa_1_2_2_mple"
        assert candidate("kSccTcTibg Vg PASHng MRp znUHkIIQ") == 'kSccTcTibg_Vg_PASHng_MRp_znUHkIIQ'
        assert candidate("qVh w zm RiAz s PhWGCeyIYML") == 'qVh_w_zm_RiAz_s_PhWGCeyIYML'
        assert candidate("RDkyZASqhvaHN") == 'RDkyZASqhvaHN'
        assert candidate("kr gucwxhnoz") == 'kr_gucwxhnoz'
        assert candidate("DYBZQSXWP") == 'DYBZQSXWP'
        assert candidate("wr 4LHnnbC mmyOyNk2") == 'wr_4LHnnbC_mmyOyNk2'
        assert candidate("rAQ  Xm") == 'rAQ__Xm'
        assert candidate("TAuzNclZIjhA") == 'TAuzNclZIjhA'
        assert candidate("RcM") == 'RcM'
        assert candidate(" k GXdAvE  Dn") == '_k_GXdAvE__Dn'
        assert candidate("LKSlDrzITZYhZrJW  YxpWROBfcp") == 'LKSlDrzITZYhZrJW__YxpWROBfcp'
        assert candidate("p jHLnQ BJauZNVSUwvCFh mcEw") == 'p_jHLnQ_BJauZNVSUwvCFh_mcEw'
        assert candidate("ZFwIEQNtR") == 'ZFwIEQNtR'
        assert candidate("tBjbLSsExMkdPs") == 'tBjbLSsExMkdPs'
        assert candidate("bxkuPhTvbyl  CYNfNCXZxwuOuaoKZZFs") == 'bxkuPhTvbyl__CYNfNCXZxwuOuaoKZZFs'
        assert candidate("OXLry xvh") == 'OXLry_xvh'
        assert candidate(" n GGbKFbBumRIUx Q SFjH B") == '_n_GGbKFbBumRIUx_Q_SFjH_B'
        assert candidate("dTIDkOm ") == 'dTIDkOm_'
        assert candidate("ffEm") == 'ffEm'
        assert candidate("soVp hReG") == 'soVp_hReG'
        assert candidate("gqkoUqTmUpPwRXbTonDIONEBh") == 'gqkoUqTmUpPwRXbTonDIONEBh'
        assert candidate("KVke  LXJF") == 'KVke__LXJF'
        assert candidate("wyKYiiMDK") == 'wyKYiiMDK'
        assert candidate("dbAfQgom ") == 'dbAfQgom_'
        assert candidate("WE v Dn") == 'WE_v_Dn'
        assert candidate("xoqb VFXUhbvu") == 'xoqb_VFXUhbvu'
        assert candidate("hxUH rBGHCUKd BxK") == 'hxUH_rBGHCUKd_BxK'
        assert candidate("jS cxsGCWIjTmp R g  MqCzly ") == 'jS_cxsGCWIjTmp_R_g__MqCzly_'
        assert candidate("nP1 tfQl6xSaO o jdR") == 'nP1_tfQl6xSaO_o_jdR'
        assert candidate("zx renBYt") == 'zx_renBYt'
        assert candidate(" y zaGe  vla l XdzqSyQdPLLg") == '_y_zaGe__vla_l_XdzqSyQdPLLg'
        assert candidate("EcNnlfJxiovXtWBSzlRhRbnUKxpKjHP") == 'EcNnlfJxiovXtWBSzlRhRbnUKxpKjHP'
        assert candidate("ChYHX q K") == 'ChYHX_q_K'
        assert candidate("SgcoeYWildqH") == 'SgcoeYWildqH'
        assert candidate("cakZwxIKzRr") == 'cakZwxIKzRr'
        assert candidate(" R ") == '_R_'

if __name__ == '__main__':
    unittest.main()
