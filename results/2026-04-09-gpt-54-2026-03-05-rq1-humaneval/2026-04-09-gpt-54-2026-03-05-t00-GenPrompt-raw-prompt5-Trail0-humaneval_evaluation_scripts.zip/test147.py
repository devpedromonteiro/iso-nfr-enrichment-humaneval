
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    # a[i] = i^2 - i + 1
    # Mod 3 pattern depends only on i mod 3:
    # i % 3 == 0 -> a[i] % 3 == 1
    # i % 3 == 1 -> a[i] % 3 == 1
    # i % 3 == 2 -> a[i] % 3 == 0
    #
    # So counts are:
    # c0 = count of terms divisible by 3  -> indices i â¡ 2 (mod 3)
    # c1 = count of terms â¡ 1 (mod 3)     -> all others
    #
    # A triple sum is divisible by 3 only if residues are:
    # (0,0,0) or (1,1,1) or (0,1,2)
    # But residue 2 never occurs here, so only:
    # (0,0,0) and (1,1,1)

    c0 = (n + 1) // 3          # indices 2,5,8,...
    c1 = n - c0

    def comb3(x):
        return x * (x - 1) * (x - 2) // 6 if x >= 3 else 0

    return comb3(c0) + comb3(c1)
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
