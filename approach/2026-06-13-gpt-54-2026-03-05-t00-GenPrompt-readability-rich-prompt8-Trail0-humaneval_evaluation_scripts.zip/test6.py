
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """Return the maximum nesting depth for each space-separated parentheses group.

    Each group contains only parentheses. The result includes one integer per group,
    representing the deepest level of nested parentheses in that group.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """
    groups = paren_string.split()
    maximum_depths: List[int] = []

    for group in groups:
        current_depth = 0
        deepest_depth = 0

        for character in group:
            if character == "(":
                current_depth += 1
                if current_depth > deepest_depth:
                    deepest_depth = current_depth
            elif character == ")":
                current_depth -= 1

        maximum_depths.append(deepest_depth)

    return maximum_depths
candidate = parse_nested_parens




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('(()()) ((())) () ((())()())') == [2, 3, 1, 3]
    assert candidate('() (()) ((())) (((())))') == [1, 2, 3, 4]
    assert candidate('(()(())((())))') == [4]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
