
import unittest
import re
import sys
import math
import copy


def solve(text):
    """Return the transformed version of the input string.

    Rules:
    - If the string contains at least one letter, swap the case of each letter
      and leave all other characters unchanged.
    - If the string contains no letters, return the reversed string.

    Examples:
        solve("1234") -> "4321"
        solve("ab") -> "AB"
        solve("#a@C") -> "#A@c"
    """
    contains_letter = any(character.isalpha() for character in text)

    if not contains_letter:
        return text[::-1]

    transformed_characters = []
    for character in text:
        if character.isalpha():
            transformed_characters.append(character.swapcase())
        else:
            transformed_characters.append(character)

    return "".join(transformed_characters)
candidate = solve


def check(candidate):

    # Check some simple cases
    assert candidate("AsDf") == "aSdF"
    assert candidate("1234") == "4321"
    assert candidate("ab") == "AB"
    assert candidate("#a@C") == "#A@c"
    assert candidate("#AsdfW^45") == "#aSDFw^45"
    assert candidate("#6@2") == "2@6#"

    # Check some edge cases that are easy to work out by hand.
    assert candidate("#$a^D") == "#$A^d"
    assert candidate("#ccc") == "#CCC"

    # Don't remove this line:


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
