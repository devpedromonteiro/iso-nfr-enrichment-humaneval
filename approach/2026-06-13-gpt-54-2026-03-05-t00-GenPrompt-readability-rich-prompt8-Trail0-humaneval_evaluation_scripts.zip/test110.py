
import unittest
import re
import sys
import math
import copy


def exchange(first_list, second_list):
    """Return "YES" if first_list can be made all even by exchanging elements.

    Any number of elements may be exchanged between the two lists.
    The order of elements does not matter for this decision.

    The key observation:
    - Every odd number currently in first_list must be replaced.
    - A replacement must be an even number taken from second_list.
    - Therefore, the exchange is possible if second_list contains at least as
      many even numbers as first_list contains odd numbers.
    """
    odd_count_in_first_list = 0
    for number in first_list:
        if number % 2 != 0:
            odd_count_in_first_list += 1

    even_count_in_second_list = 0
    for number in second_list:
        if number % 2 == 0:
            even_count_in_second_list += 1

    if even_count_in_second_list >= odd_count_in_first_list:
        return "YES"

    return "NO"
candidate = exchange


def check(candidate):

    # Check some simple cases
    assert candidate([1, 2, 3, 4], [1, 2, 3, 4]) == "YES"
    assert candidate([1, 2, 3, 4], [1, 5, 3, 4]) == "NO"
    assert candidate([1, 2, 3, 4], [2, 1, 4, 3]) == "YES" 
    assert candidate([5, 7, 3], [2, 6, 4]) == "YES"
    assert candidate([5, 7, 3], [2, 6, 3]) == "NO" 
    assert candidate([3, 2, 6, 1, 8, 9], [3, 5, 5, 1, 1, 1]) == "NO"

    # Check some edge cases that are easy to work out by hand.
    assert candidate([100, 200], [200, 200]) == "YES"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
