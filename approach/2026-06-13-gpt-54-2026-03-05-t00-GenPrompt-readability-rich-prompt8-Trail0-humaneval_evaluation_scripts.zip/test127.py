
import unittest
import re
import sys
import math
import copy


def intersection(first_interval, second_interval):
    """
    Determine whether the length of the intersection of two closed intervals
    is a prime number.

    Each interval is a pair of integers: (start, end), with start <= end.
    Closed intervals include both endpoints.

    Returns:
        "YES" if the intersection length is prime, otherwise "NO".
    """

    first_start, first_end = first_interval
    second_start, second_end = second_interval

    intersection_start = max(first_start, second_start)
    intersection_end = min(first_end, second_end)

    if intersection_start > intersection_end:
        return "NO"

    intersection_length = intersection_end - intersection_start

    if is_prime(intersection_length):
        return "YES"

    return "NO"


def is_prime(number):
    """Return True if number is a prime number, otherwise False."""
    if number < 2:
        return False

    divisor = 2
    while divisor * divisor <= number:
        if number % divisor == 0:
            return False
        divisor += 1

    return True
candidate = intersection


def check(candidate):

    # Check some simple cases
    assert candidate((1, 2), (2, 3)) == "NO"
    assert candidate((-1, 1), (0, 4)) == "NO"
    assert candidate((-3, -1), (-5, 5)) == "YES"
    assert candidate((-2, 2), (-4, 0)) == "YES"

    # Check some edge cases that are easy to work out by hand.
    assert candidate((-11, 2), (-1, -1)) == "NO"
    assert candidate((1, 2), (3, 5)) == "NO"
    assert candidate((1, 2), (1, 2)) == "NO"
    assert candidate((-2, -2), (-3, -2)) == "NO"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
