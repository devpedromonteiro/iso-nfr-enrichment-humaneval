
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    Return the number of index triples (i, j, k) with i < j < k such that
    a[i] + a[j] + a[k] is divisible by 3, where:

        a[x] = x * x - x + 1   for 1 <= x <= n

    Example:
        n = 5
        a = [1, 3, 7, 13, 21]
        Valid triple count = 1
    """

    remainder_counts = [0, 0, 0]

    for index in range(1, n + 1):
        value = index * index - index + 1
        remainder = value % 3
        remainder_counts[remainder] += 1

    count_remainder_0 = remainder_counts[0]
    count_remainder_1 = remainder_counts[1]
    count_remainder_2 = remainder_counts[2]

    def combinations_of_three(count):
        if count < 3:
            return 0
        return count * (count - 1) * (count - 2) // 6

    triples_all_zeros = combinations_of_three(count_remainder_0)
    triples_all_ones = combinations_of_three(count_remainder_1)
    triples_all_twos = combinations_of_three(count_remainder_2)

    triples_one_of_each = (
        count_remainder_0 * count_remainder_1 * count_remainder_2
    )

    total_valid_triples = (
        triples_all_zeros
        + triples_all_ones
        + triples_all_twos
        + triples_one_of_each
    )

    return total_valid_triples
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
