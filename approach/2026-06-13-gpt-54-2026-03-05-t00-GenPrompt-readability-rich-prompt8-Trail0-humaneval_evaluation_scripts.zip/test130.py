
import unittest
import re
import sys
import math
import copy


def tri(count):
    """
    Return the first `count + 1` values of the Tribonacci sequence.

    Sequence definition:
    - tri(0) = 1
    - tri(1) = 3
    - tri(n) = 1 + n / 2, if n is even
    - tri(n) = tri(n - 1) + tri(n - 2) + tri(n + 1), if n is odd

    Example:
    tri(3) -> [1, 3, 2, 8]
    """

    def tribonacci_value(index):
        if index == 0:
            return 1
        if index == 1:
            return 3
        if index % 2 == 0:
            return 1 + index // 2

        previous_value = tribonacci_value(index - 1)
        two_steps_back_value = tribonacci_value(index - 2)
        next_even_value = tribonacci_value(index + 1)

        return previous_value + two_steps_back_value + next_even_value

    sequence = []

    for index in range(count + 1):
        sequence.append(tribonacci_value(index))

    return sequence
candidate = tri


def check(candidate):

    # Check some simple cases
    
    assert candidate(3) == [1, 3, 2.0, 8.0]
    assert candidate(4) == [1, 3, 2.0, 8.0, 3.0]
    assert candidate(5) == [1, 3, 2.0, 8.0, 3.0, 15.0]
    assert candidate(6) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0]
    assert candidate(7) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0]
    assert candidate(8) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0]
    assert candidate(9) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0]
    assert candidate(20) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0, 6.0, 48.0, 7.0, 63.0, 8.0, 80.0, 9.0, 99.0, 10.0, 120.0, 11.0]

    # Check some edge cases that are easy to work out by hand.
    assert candidate(0) == [1]
    assert candidate(1) == [1, 3]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
