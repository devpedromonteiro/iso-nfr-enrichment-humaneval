
import unittest
import re
import sys
import math
import copy


def compare(actual_scores, guessed_scores):
    """Return the absolute difference between each actual score and guessed score.

    For each match:
    - return 0 if the guess is correct
    - otherwise return the absolute difference between the actual score and the guess

    Examples:
        compare([1, 2, 3, 4, 5, 1], [1, 2, 3, 4, 2, -2]) -> [0, 0, 0, 0, 3, 3]
        compare([0, 5, 0, 0, 0, 4], [4, 1, 1, 0, 0, -2]) -> [4, 4, 1, 0, 0, 6]
    """
    score_differences = []

    for actual_score, guessed_score in zip(actual_scores, guessed_scores):
        difference = abs(actual_score - guessed_score)
        score_differences.append(difference)

    return score_differences
candidate = compare


def check(candidate):

    # Check some simple cases
    assert candidate([1,2,3,4,5,1],[1,2,3,4,2,-2])==[0,0,0,0,3,3], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([0,0,0,0,0,0],[0,0,0,0,0,0])==[0,0,0,0,0,0], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,2,3],[-1,-2,-3])==[2,4,6], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,2,3,5],[-1,2,3,4])==[2,0,0,1], "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
