
import unittest
import re
import sys
import math
import copy


def is_nested(bracket_string):
    """
    Return True if the string contains a valid bracket subsequence
    with at least one nested pair of square brackets.

    A nested structure exists when, while scanning left to right,
    we encounter an opening bracket while another opening bracket
    is already unmatched.

    Examples:
        is_nested('[[]]') -> True
        is_nested('[]]]]]]][[[[[]') -> False
        is_nested('[][]') -> False
        is_nested('[]') -> False
        is_nested('[[][]]') -> True
        is_nested('[[]][[') -> True
    """
    open_bracket_count = 0

    for bracket in bracket_string:
        if bracket == '[':
            if open_bracket_count > 0:
                return True
            open_bracket_count += 1
        elif bracket == ']' and open_bracket_count > 0:
            open_bracket_count -= 1

    return False
candidate = is_nested


def check(candidate):

    # Check some simple cases
    assert candidate('[[]]') == True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('[]]]]]]][[[[[]') == False
    assert candidate('[][]') == False
    assert candidate(('[]')) == False
    assert candidate('[[[[]]]]') == True
    assert candidate('[]]]]]]]]]]') == False
    assert candidate('[][][[]]') == True
    assert candidate('[[]') == False
    assert candidate('[]]') == False
    assert candidate('[[]][[') == True
    assert candidate('[[][]]') == True

    # Check some edge cases that are easy to work out by hand.
    assert candidate('') == False, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate('[[[[[[[[') == False
    assert candidate(']]]]]]]]') == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
