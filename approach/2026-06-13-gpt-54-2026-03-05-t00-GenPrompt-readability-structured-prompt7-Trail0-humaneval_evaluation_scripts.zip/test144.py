
import unittest
import re
import sys
import math
import copy


from math import gcd


def simplify(x, n):
    """
    Return True if the product of fractions x and n is a whole number, else False.

    Both inputs are strings in the form "numerator/denominator".
    """

    x_numerator, x_denominator = parse_fraction(x)
    n_numerator, n_denominator = parse_fraction(n)

    product_numerator = x_numerator * n_numerator
    product_denominator = x_denominator * n_denominator

    common_divisor = gcd(product_numerator, product_denominator)
    simplified_denominator = product_denominator // common_divisor

    return simplified_denominator == 1


def parse_fraction(fraction_text):
    """Convert a fraction string like '3/4' into a pair of integers."""
    numerator_text, denominator_text = fraction_text.split("/")
    return int(numerator_text), int(denominator_text)
candidate = simplify


def check(candidate):

    # Check some simple cases
    assert candidate("1/5", "5/1") == True, 'test1'
    assert candidate("1/6", "2/1") == False, 'test2'
    assert candidate("5/1", "3/1") == True, 'test3'
    assert candidate("7/10", "10/2") == False, 'test4'
    assert candidate("2/10", "50/10") == True, 'test5'
    assert candidate("7/2", "4/2") == True, 'test6'
    assert candidate("11/6", "6/1") == True, 'test7'
    assert candidate("2/3", "5/2") == False, 'test8'
    assert candidate("5/2", "3/5") == False, 'test9'
    assert candidate("2/4", "8/4") == True, 'test10'


    # Check some edge cases that are easy to work out by hand.
    assert candidate("2/4", "4/2") == True, 'test11'
    assert candidate("1/5", "5/1") == True, 'test12'
    assert candidate("1/5", "1/5") == False, 'test13'



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
