
import unittest
import re
import sys
import math
import copy


def intersection(interval1, interval2):
    """Return "YES" if the length of the intersection is a prime number, else "NO".

    Intervals are closed, so both endpoints are included.
    For example, the intersection of (1, 3) and (2, 4) is (2, 3),
    whose length is 1, and 1 is not prime.
    """
    start1, end1 = interval1
    start2, end2 = interval2

    intersection_start = max(start1, start2)
    intersection_end = min(end1, end2)

    if intersection_start > intersection_end:
        return "NO"

    intersection_length = intersection_end - intersection_start

    if is_prime(intersection_length):
        return "YES"
    return "NO"


def is_prime(number):
    """Return True if number is a prime number, else False."""
    if number < 2:
        return False

    divisor = 2
    while divisor * divisor <= number:
        if number % divisor == 0:
            return False
        divisor += 1

    return True
candidate = intersection


def check(candidate):

    # Check some simple cases
    assert candidate((1, 2), (2, 3)) == "NO"
    assert candidate((-1, 1), (0, 4)) == "NO"
    assert candidate((-3, -1), (-5, 5)) == "YES"
    assert candidate((-2, 2), (-4, 0)) == "YES"

    # Check some edge cases that are easy to work out by hand.
    assert candidate((-11, 2), (-1, -1)) == "NO"
    assert candidate((1, 2), (3, 5)) == "NO"
    assert candidate((1, 2), (1, 2)) == "NO"
    assert candidate((-2, -2), (-3, -2)) == "NO"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
