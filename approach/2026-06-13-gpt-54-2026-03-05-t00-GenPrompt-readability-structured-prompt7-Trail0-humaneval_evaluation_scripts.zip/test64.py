
import unittest
import re
import sys
import math
import copy


FIX = """
Add more test cases.
"""

FIX = """
Add more test cases.
"""

def vowels_count(word):
    """Return the number of vowels in a word.

    Count 'a', 'e', 'i', 'o', and 'u' anywhere in the word.
    Count 'y' only when it appears at the end of the word.

    Examples:
    >>> vowels_count("abcde")
    2
    >>> vowels_count("ACEDY")
    3
    >>> vowels_count("sky")
    1
    >>> vowels_count("yellow")
    2
    """
    normalized_word = word.lower()
    standard_vowels = {"a", "e", "i", "o", "u"}

    vowel_total = sum(1 for character in normalized_word if character in standard_vowels)

    if normalized_word.endswith("y"):
        vowel_total += 1

    return vowel_total
candidate = vowels_count


def check(candidate):

    # Check some simple cases
    assert candidate("abcde") == 2, "Test 1"
    assert candidate("Alone") == 3, "Test 2"
    assert candidate("key") == 2, "Test 3"
    assert candidate("bye") == 1, "Test 4"
    assert candidate("keY") == 2, "Test 5"
    assert candidate("bYe") == 1, "Test 6"
    assert candidate("ACEDY") == 3, "Test 7"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
