
import unittest
import re
import sys
import math
import copy


def f(count):
    """
    Return a list of length `count` where the value at position i
    (starting from 1) is:
    - factorial(i) if i is even
    - sum of numbers from 1 to i if i is odd

    Example:
        f(5) == [1, 2, 6, 24, 15]
    """
    result = []

    running_sum = 0
    running_factorial = 1

    for index in range(1, count + 1):
        running_sum += index
        running_factorial *= index

        if index % 2 == 0:
            result.append(running_factorial)
        else:
            result.append(running_sum)

    return result
candidate = f


def check(candidate):

    assert candidate(5) == [1, 2, 6, 24, 15]
    assert candidate(7) == [1, 2, 6, 24, 15, 720, 28]
    assert candidate(1) == [1]
    assert candidate(3) == [1, 2, 6]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
