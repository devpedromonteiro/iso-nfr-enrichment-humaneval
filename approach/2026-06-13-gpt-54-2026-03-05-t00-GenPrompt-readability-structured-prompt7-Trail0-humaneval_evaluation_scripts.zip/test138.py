
import unittest
import re
import sys
import math
import copy


def is_equal_to_sum_even(number):
    """Return True if `number` can be written as the sum of exactly 4 positive even numbers.

    A positive even number is at least 2, so the smallest possible sum of
    4 positive even numbers is:

        2 + 2 + 2 + 2 = 8

    Therefore, any even number greater than or equal to 8 satisfies the condition.

    Examples:
        is_equal_to_sum_even(4) -> False
        is_equal_to_sum_even(6) -> False
        is_equal_to_sum_even(8) -> True
    """
    minimum_sum_of_four_positive_evens = 8
    is_even_number = number % 2 == 0

    return is_even_number and number >= minimum_sum_of_four_positive_evens
candidate = is_equal_to_sum_even


def check(candidate):
    assert candidate(4) == False
    assert candidate(6) == False
    assert candidate(8) == True
    assert candidate(10) == True
    assert candidate(11) == False
    assert candidate(12) == True
    assert candidate(13) == False
    assert candidate(16) == True


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
