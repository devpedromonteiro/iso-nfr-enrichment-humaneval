
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List

WORD_TO_VALUE = {
    "zero": 0,
    "one": 1,
    "two": 2,
    "three": 3,
    "four": 4,
    "five": 5,
    "six": 6,
    "seven": 7,
    "eight": 8,
    "nine": 9,
}


def sort_numbers(numbers: str) -> str:
    """Sort space-delimited number words from smallest to largest.

    Input must contain number words from 'zero' to 'nine'.

    >>> sort_numbers('three one five')
    'one three five'
    """
    number_words: List[str] = numbers.split()
    sorted_number_words = sorted(number_words, key=word_to_value)
    return " ".join(sorted_number_words)


def word_to_value(number_word: str) -> int:
    """Convert a number word to its numeric value."""
    return WORD_TO_VALUE[number_word]
candidate = sort_numbers




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == ''
    assert candidate('three') == 'three'
    assert candidate('three five nine') == 'three five nine'
    assert candidate('five zero four seven nine eight') == 'zero four five seven eight nine'
    assert candidate('six five four three two one zero') == 'zero one two three four five six'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
