
import unittest
import re
import sys
import math
import copy


def _signed_digit_sum(num):
    """Return the sum of digits, treating the first digit as signed for negatives."""
    digits = str(num)
    if digits[0] != "-":
        return sum(int(ch) for ch in digits)

    first_digit = -int(digits[1])
    remaining_sum = sum(int(ch) for ch in digits[2:])
    return first_digit + remaining_sum


def count_nums(arr):
    """Count how many numbers in arr have a signed digit sum greater than 0."""
    return sum(1 for num in arr if _signed_digit_sum(num) > 0)
candidate = count_nums


def check(candidate):

    # Check some simple cases
    assert candidate([]) == 0
    assert candidate([-1, -2, 0]) == 0
    assert candidate([1, 1, 2, -2, 3, 4, 5]) == 6
    assert candidate([1, 6, 9, -6, 0, 1, 5]) == 5
    assert candidate([1, 100, 98, -7, 1, -1]) == 4
    assert candidate([12, 23, 34, -45, -56, 0]) == 5
    assert candidate([-0, 1**0]) == 1
    assert candidate([1]) == 1

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
