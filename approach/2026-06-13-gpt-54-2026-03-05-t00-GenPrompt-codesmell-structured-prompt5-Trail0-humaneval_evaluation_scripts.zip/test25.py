
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def _extract_factor(n: int, factor: int) -> tuple[int, List[int]]:
    """Extract all occurrences of a factor from n."""
    factors: List[int] = []
    while n % factor == 0:
        factors.append(factor)
        n //= factor
    return n, factors


def factorize(n: int) -> List[int]:
    """Return prime factors of a positive integer in ascending order.

    Each prime factor appears as many times as its multiplicity in the factorization.

    >>> factorize(8)
    [2, 2, 2]
    >>> factorize(25)
    [5, 5]
    >>> factorize(70)
    [2, 5, 7]
    """
    if n < 2:
        return []

    factors: List[int] = []

    n, twos = _extract_factor(n, 2)
    factors.extend(twos)

    divisor = 3
    while divisor * divisor <= n:
        n, extracted = _extract_factor(n, divisor)
        factors.extend(extracted)
        divisor += 2

    if n > 1:
        factors.append(n)

    return factors
candidate = factorize




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(2) == [2]
    assert candidate(4) == [2, 2]
    assert candidate(8) == [2, 2, 2]
    assert candidate(3 * 19) == [3, 19]
    assert candidate(3 * 19 * 3 * 19) == [3, 3, 19, 19]
    assert candidate(3 * 19 * 3 * 19 * 3 * 19) == [3, 3, 3, 19, 19, 19]
    assert candidate(3 * 19 * 19 * 19) == [3, 19, 19, 19]
    assert candidate(3 * 2 * 3) == [2, 3, 3]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
