
import unittest
import re
import sys
import math
import copy


def _count_by_modulo(n):
    """
    Count how many values of a[i] fall into each residue class modulo 3,
    where a[i] = i*i - i + 1 for 1 <= i <= n.
    """
    counts = [0, 0, 0]

    for i in range(1, n + 1):
        value_mod = (i * i - i + 1) % 3
        counts[value_mod] += 1

    return counts


def _n_choose_2(x):
    return x * (x - 1) // 2


def _n_choose_3(x):
    return x * (x - 1) * (x - 2) // 6


def get_max_triples(n):
    """
    You are given a positive integer n. You have to create an integer array a of length n.
    For each i (1 â¤ i â¤ n), the value of a[i] = i * i - i + 1.

    Return the number of triples (a[i], a[j], a[k]) where i < j < k and
    a[i] + a[j] + a[k] is a multiple of 3.

    Example:
        Input: n = 5
        Output: 1
        Explanation:
        a = [1, 3, 7, 13, 21]
        The only valid triple is (1, 7, 13).
    """
    if n < 3:
        return 0

    count_mod_0, count_mod_1, count_mod_2 = _count_by_modulo(n)

    triples_all_0 = _n_choose_3(count_mod_0)
    triples_all_1 = _n_choose_3(count_mod_1)
    triples_all_2 = _n_choose_3(count_mod_2)
    triples_one_each = count_mod_0 * count_mod_1 * count_mod_2

    return triples_all_0 + triples_all_1 + triples_all_2 + triples_one_each
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
