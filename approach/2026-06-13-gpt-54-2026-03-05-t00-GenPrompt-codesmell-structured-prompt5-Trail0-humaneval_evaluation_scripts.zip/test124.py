
import unittest
import re
import sys
import math
import copy


def valid_date(date):
    """Validate a date string in mm-dd-yyyy format.

    Rules:
    1. The date string must not be empty.
    2. Month must be between 1 and 12.
    3. Day must be valid for the given month.
    4. February allows up to 29 days.
    5. Format must be exactly mm-dd-yyyy.
    """
    if not _has_valid_format(date):
        return False

    month, day, year = _parse_date_parts(date)
    if month is None or day is None or year is None:
        return False

    return _is_valid_month(month) and _is_valid_day(month, day)


def _has_valid_format(date_string):
    if not isinstance(date_string, str) or not date_string:
        return False

    parts = date_string.split("-")
    if len(parts) != 3:
        return False

    month_str, day_str, year_str = parts
    return (
        len(month_str) == 2
        and len(day_str) == 2
        and len(year_str) == 4
        and month_str.isdigit()
        and day_str.isdigit()
        and year_str.isdigit()
    )


def _parse_date_parts(date_string):
    try:
        month_str, day_str, year_str = date_string.split("-")
        return int(month_str), int(day_str), int(year_str)
    except (ValueError, AttributeError):
        return None, None, None


def _is_valid_month(month):
    return 1 <= month <= 12


def _is_valid_day(month, day):
    if day < 1:
        return False

    days_in_month = {
        1: 31,
        2: 29,
        3: 31,
        4: 30,
        5: 31,
        6: 30,
        7: 31,
        8: 31,
        9: 30,
        10: 31,
        11: 30,
        12: 31,
    }

    return day <= days_in_month.get(month, 0)
candidate = valid_date


def check(candidate):

    # Check some simple cases
    assert candidate('03-11-2000') == True

    assert candidate('15-01-2012') == False

    assert candidate('04-0-2040') == False

    assert candidate('06-04-2020') == True

    assert candidate('01-01-2007') == True

    assert candidate('03-32-2011') == False

    assert candidate('') == False

    assert candidate('04-31-3000') == False

    assert candidate('06-06-2005') == True

    assert candidate('21-31-2000') == False

    assert candidate('04-12-2003') == True

    assert candidate('04122003') == False

    assert candidate('20030412') == False

    assert candidate('2003-04') == False

    assert candidate('2003-04-12') == False

    assert candidate('04-2003') == False


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
