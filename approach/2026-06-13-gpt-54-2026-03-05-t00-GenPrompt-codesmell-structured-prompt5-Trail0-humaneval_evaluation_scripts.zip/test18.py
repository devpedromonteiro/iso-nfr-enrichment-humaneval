
import unittest
import re
import sys
import math
import copy



def _match_at(text: str, pattern: str, start: int) -> bool:
    """Return True if pattern matches text starting at index start."""
    return text[start:start + len(pattern)] == pattern


def how_many_times(string: str, substring: str) -> int:
    """Find how many times a given substring appears in the original string.

    Overlapping occurrences are counted.

    >>> how_many_times('', 'a')
    0
    >>> how_many_times('aaa', 'a')
    3
    >>> how_many_times('aaaa', 'aa')
    3
    """
    if not string or not substring:
        return 0

    count = 0
    last_start = len(string) - len(substring)

    for index in range(last_start + 1):
        if _match_at(string, substring, index):
            count += 1

    return count
candidate = how_many_times




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('', 'x') == 0
    assert candidate('xyxyxyx', 'x') == 4
    assert candidate('cacacacac', 'cac') == 4
    assert candidate('john doe', 'john') == 1


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
