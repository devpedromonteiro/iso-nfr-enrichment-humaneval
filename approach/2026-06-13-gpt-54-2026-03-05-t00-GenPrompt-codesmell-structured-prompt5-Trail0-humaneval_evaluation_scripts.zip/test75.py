
import unittest
import re
import sys
import math
import copy


def _is_prime(n):
    """Return True if n is a prime number, otherwise False."""
    if n < 2:
        return False
    if n == 2:
        return True
    if n % 2 == 0:
        return False

    divisor = 3
    while divisor * divisor <= n:
        if n % divisor == 0:
            return False
        divisor += 2
    return True


def is_multiply_prime(a):
    """Return True if a is the product of exactly 3 prime numbers, otherwise False."""
    if a < 8:
        return False

    for first in range(2, a + 1):
        if not _is_prime(first) or a % first != 0:
            continue

        remaining_after_first = a // first
        for second in range(2, remaining_after_first + 1):
            if not _is_prime(second) or remaining_after_first % second != 0:
                continue

            third = remaining_after_first // second
            if _is_prime(third):
                return True

    return False
candidate = is_multiply_prime


def check(candidate):

    assert candidate(5) == False
    assert candidate(30) == True
    assert candidate(8) == True
    assert candidate(10) == False
    assert candidate(125) == True
    assert candidate(3 * 5 * 7) == True
    assert candidate(3 * 6 * 7) == False
    assert candidate(9 * 9 * 9) == False
    assert candidate(11 * 9 * 9) == False
    assert candidate(11 * 13 * 7) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
