
import unittest
import re
import sys
import math
import copy


def _count_start_with_one(n):
    """Count n-digit positive integers whose first digit is 1."""
    return 10 ** (n - 1)


def _count_end_with_one(n):
    """Count n-digit positive integers whose last digit is 1."""
    return 9 * (10 ** (n - 2)) if n > 1 else 1


def _count_start_and_end_with_one(n):
    """Count n-digit positive integers whose first and last digits are both 1."""
    return 10 ** (n - 2) if n > 1 else 1


def starts_one_ends(n):
    """
    Given a positive integer n, return the count of n-digit
    positive integers that start or end with 1.
    """
    if n <= 0:
        raise ValueError("n must be a positive integer")

    start_with_one = _count_start_with_one(n)
    end_with_one = _count_end_with_one(n)
    start_and_end_with_one = _count_start_and_end_with_one(n)

    return start_with_one + end_with_one - start_and_end_with_one
candidate = starts_one_ends


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(1) == 1
    assert candidate(2) == 18
    assert candidate(3) == 180
    assert candidate(4) == 1800
    assert candidate(5) == 18000

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
