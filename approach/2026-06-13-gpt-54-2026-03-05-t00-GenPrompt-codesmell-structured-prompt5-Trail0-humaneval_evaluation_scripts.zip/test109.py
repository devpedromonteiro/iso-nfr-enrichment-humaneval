
import unittest
import re
import sys
import math
import copy


def _count_descents(arr):
    """Return the number of positions where order decreases."""
    return sum(1 for i in range(1, len(arr)) if arr[i - 1] > arr[i])


def move_one_ball(arr):
    """Determine whether some number of right rotations can sort the array.

    A list can be transformed into non-decreasing order by right shifts iff
    it is already a rotation of a sorted list. With unique elements, this means
    there is at most one descent in the array, and if a descent exists, the last
    element must be less than or equal to the first to allow wraparound sorting.
    """
    if len(arr) < 2:
        return True

    descents = _count_descents(arr)

    if descents == 0:
        return True

    return descents == 1 and arr[-1] <= arr[0]
candidate = move_one_ball


def check(candidate):

    # Check some simple cases
    assert candidate([3, 4, 5, 1, 2])==True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([3, 5, 10, 1, 2])==True
    assert candidate([4, 3, 1, 2])==False
    # Check some edge cases that are easy to work out by hand.
    assert candidate([3, 5, 4, 1, 2])==False, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([])==True


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
