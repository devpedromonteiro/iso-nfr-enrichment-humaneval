
import unittest
import re
import sys
import math
import copy


def is_prime(number):
    """Return True if number is prime, otherwise False."""
    if number < 2:
        return False
    if number == 2:
        return True
    if number % 2 == 0:
        return False

    limit = int(number ** 0.5) + 1
    for divisor in range(3, limit, 2):
        if number % divisor == 0:
            return False
    return True


def count_up_to(n):
    """Return a list of prime numbers less than n."""
    if n <= 2:
        return []

    primes = []
    for candidate in range(2, n):
        if is_prime(candidate):
            primes.append(candidate)
    return primes
candidate = count_up_to


def check(candidate):

    assert candidate(5) == [2,3]
    assert candidate(6) == [2,3,5]
    assert candidate(7) == [2,3,5]
    assert candidate(10) == [2,3,5,7]
    assert candidate(0) == []
    assert candidate(22) == [2,3,5,7,11,13,17,19]
    assert candidate(1) == []
    assert candidate(18) == [2,3,5,7,11,13,17]
    assert candidate(47) == [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43]
    assert candidate(101) == [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
