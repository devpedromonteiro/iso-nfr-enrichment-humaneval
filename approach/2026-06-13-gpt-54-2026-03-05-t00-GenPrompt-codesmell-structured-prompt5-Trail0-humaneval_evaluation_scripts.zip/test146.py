
import unittest
import re
import sys
import math
import copy


def _first_and_last_digits_are_odd(number):
    digits = str(abs(number))
    odd_digits = {"1", "3", "5", "7", "9"}
    return digits[0] in odd_digits and digits[-1] in odd_digits


def _is_special_number(number):
    return number > 10 and _first_and_last_digits_are_odd(number)


def specialFilter(nums):
    """Return the count of numbers greater than 10 whose first and last digits are odd."""
    return sum(1 for num in nums if _is_special_number(num))
candidate = specialFilter


def check(candidate):

    # Check some simple cases
    assert candidate([5, -2, 1, -5]) == 0  
    assert candidate([15, -73, 14, -15]) == 1
    assert candidate([33, -2, -3, 45, 21, 109]) == 2
    assert candidate([43, -12, 93, 125, 121, 109]) == 4
    assert candidate([71, -2, -33, 75, 21, 19]) == 3


    # Check some edge cases that are easy to work out by hand.
    assert candidate([1]) == 0              
    assert candidate([]) == 0                   



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
