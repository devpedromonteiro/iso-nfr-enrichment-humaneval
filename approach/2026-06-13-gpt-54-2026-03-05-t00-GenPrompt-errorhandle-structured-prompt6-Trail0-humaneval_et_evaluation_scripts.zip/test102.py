
import unittest


def choose_num(x, y):
    """Return the biggest even integer in the inclusive range [x, y].

    The function expects two positive integers. If x > y, return -1.
    If there is no even integer in the range, return -1.

    Raises:
        TypeError: if x or y is not an integer.
        ValueError: if x or y is not positive.
    """
    if not isinstance(x, int) or not isinstance(y, int):
        raise TypeError("x and y must both be integers")

    if x <= 0 or y <= 0:
        raise ValueError("x and y must both be positive integers")

    if x > y:
        return -1

    return y if y % 2 == 0 else y - 1 if y - 1 >= x else -1
candidate = choose_num


class Test(unittest.TestCase):
    def test(self):
        assert candidate(4249, 4823) == 4822
        assert candidate(5373, 4639) == -1
        assert candidate(31, 6) == -1
        assert candidate(37, 13023) == 13022
        assert candidate(34, 13247) == 13246
        assert candidate(29, 15) == -1
        assert candidate(3, 9) == 8
        assert candidate(12, 15) == 14
        assert candidate(4, 4) == 4
        assert candidate(550, 543) == -1
        assert candidate(7, 34) == 34
        assert candidate(6, 11) == 10
        assert candidate(3, 12) == 12
        assert candidate(23, 10) == -1
        assert candidate(32, 11) == -1
        assert candidate(18, 16) == -1
        assert candidate(27, 10) == -1

    # Check some edge cases that are easy to work out by hand.
        assert candidate(8, 15) == 14
        assert candidate(545, 546) == 546
        assert candidate(547, 549) == 548
        assert candidate(9, 28) == 28
        assert candidate(34, 12634) == 12634
        assert candidate(550, 542) == -1
        assert candidate(7, 19) == 18
        assert candidate(2, 9) == 8
        assert candidate(4, 2) == -1
        assert candidate(11, 10) == -1
        assert candidate(542, 543) == 542
        assert candidate(11, 11) == -1
        assert candidate(5234, 5233) == -1
        assert candidate(17, 13) == -1
        assert candidate(28, 6) == -1
        assert candidate(36, 12359) == 12358
        assert candidate(547, 542) == -1
        assert candidate(4292, 5649) == 5648
        assert candidate(31, 13152) == 13152
        assert candidate(4796, 5300) == 5300
        assert candidate(29, 12690) == 12690
        assert candidate(9, 11) == 10
        assert candidate(4637, 5993) == 5992
        assert candidate(36, 11801) == 11800
        assert candidate(27, 6) == -1
        assert candidate(548, 542) == -1
        assert candidate(11, 30) == 30
        assert candidate(31, 13214) == 13214
        assert candidate(32, 13283) == 13282
        assert candidate(4494, 4861) == 4860
        assert candidate(9, 27) == 26
        assert candidate(13, 12) == -1
        assert candidate(8, 31) == 30
        assert candidate(14, 9) == -1
        assert candidate(7, 11) == 10
        assert candidate(36, 11976) == 11976
        assert candidate(10, 29) == 28
        assert candidate(17, 15) == -1
        assert candidate(13, 9) == -1
        assert candidate(547, 548) == 548
        assert candidate(10, 14) == 14
        assert candidate(549, 549) == -1
        assert candidate(542, 547) == 546
        assert candidate(541, 542) == 542
        assert candidate(34, 12261) == 12260
        assert candidate(8, 13) == 12
        assert candidate(3, 7) == 6
        assert candidate(33, 12354) == 12354
        assert candidate(12, 7) == -1
        assert candidate(31, 12815) == 12814
        assert candidate(4756, 5476) == 5476
        assert candidate(29, 10) == -1
        assert candidate(16, 17) == 16
        assert candidate(9, 24) == 24
        assert candidate(6, 3) == -1
        assert candidate(5338, 5267) == -1
        assert candidate(4547, 5362) == 5362
        assert candidate(8, 26) == 26
        assert candidate(11, 12) == 12
        assert candidate(25, 13) == -1
        assert candidate(7, 7) == -1
        assert candidate(7, 16) == 16
        assert candidate(4883, 5654) == 5654
        assert candidate(8, 32) == 32
        assert candidate(6, 29) == 28
        assert candidate(38, 12926) == 12926
        assert candidate(9, 7) == -1
        assert candidate(12, 6) == -1
        assert candidate(15, 14) == -1
        assert candidate(10, 8) == -1
        assert candidate(11, 29) == 28
        assert candidate(14, 11) == -1
        assert candidate(13, 17) == 16
        assert candidate(5, 8) == 8
        assert candidate(546, 549) == 548
        assert candidate(8, 14) == 14
        assert candidate(5, 26) == 26
        assert candidate(8, 12) == 12
        assert candidate(31, 12511) == 12510
        assert candidate(32, 10) == -1
        assert candidate(7, 10) == 10
        assert candidate(6087, 4359) == -1
        assert candidate(31, 10) == -1
        assert candidate(10, 11) == 10
        assert candidate(4386, 4651) == 4650
        assert candidate(27, 5) == -1
        assert candidate(546, 546) == 546
        assert candidate(30, 13282) == 13282
        assert candidate(6, 32) == 32
        assert candidate(14, 15) == 14
        assert candidate(11, 13) == 12
        assert candidate(5962, 4558) == -1
        assert candidate(543, 542) == -1
        assert candidate(1, 32) == 32
        assert candidate(5830, 5508) == -1
        assert candidate(4623, 5093) == 5092
        assert candidate(32, 7) == -1
        assert candidate(546, 550) == 550
        assert candidate(28, 13) == -1

if __name__ == '__main__':
    unittest.main()
