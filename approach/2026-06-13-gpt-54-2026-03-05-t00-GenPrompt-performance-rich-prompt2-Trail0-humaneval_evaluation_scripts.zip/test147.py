
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    You are given a positive integer n. You have to create an integer array a of length n.
        For each i (1 â¤ i â¤ n), the value of a[i] = i * i - i + 1.
        Return the number of triples (a[i], a[j], a[k]) of a where i < j < k,
    and a[i] + a[j] + a[k] is a multiple of 3.

    Example :
        Input: n = 5
        Output: 1
        Explanation:
        a = [1, 3, 7, 13, 21]
        The only valid triple is (1, 7, 13).
    """
    if n < 3:
        return 0

    # a[i] = i^2 - i + 1 for 1-based i
    # Modulo 3:
    # i % 3 == 0 -> a[i] % 3 == 1
    # i % 3 == 1 -> a[i] % 3 == 1
    # i % 3 == 2 -> a[i] % 3 == 0
    #
    # So array values only fall into residue classes:
    #   0 mod 3: count0 = number of i in [1..n] with i % 3 == 2
    #   1 mod 3: count1 = n - count0
    #
    # A triple sum is divisible by 3 only for residue combinations:
    #   (0, 0, 0) or (1, 1, 1)
    #
    # Therefore answer = C(count0, 3) + C(count1, 3)

    count0 = (n + 1) // 3   # indices congruent to 2 mod 3 in [1..n]
    count1 = n - count0

    def comb3(x):
        return x * (x - 1) * (x - 2) // 6 if x >= 3 else 0

    return comb3(count0) + comb3(count1)
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
