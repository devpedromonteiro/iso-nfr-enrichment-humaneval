
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[2] * x^2 + .... + xs[n] * x^n
    """
    # Horner's method: O(n), avoids repeated pow calls and extra allocations.
    result = 0.0
    for coeff in reversed(xs):
        result = result * x + coeff
    return result


def find_zero(xs: list):
    """ xs are coefficients of a polynomial.
    find_zero find x such that poly(x) = 0.
    find_zero returns only only zero point, even if there are many.
    Moreover, find_zero only takes list xs having even number of coefficients
    and largest non zero coefficient as it guarantees
    a solution.
    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3
    1.0
    """
    if not xs:
        raise ValueError("xs must not be empty")

    degree = len(xs) - 1
    while degree >= 0 and xs[degree] == 0:
        degree -= 1
    if degree < 1:
        raise ValueError("polynomial must have degree at least 1")

    xs = xs[:degree + 1]

    # Fast path for linear polynomial: a + bx = 0
    if degree == 1:
        return -xs[0] / xs[1]

    # Since degree is odd (even number of coefficients) and leading coefficient is non-zero,
    # the polynomial has at least one real root. First bracket a root, then use bisection.
    lead = xs[-1]

    left = -1.0
    right = 1.0
    f_left = poly(xs, left)
    f_right = poly(xs, right)

    # Expand interval until it brackets a root.
    while f_left != 0.0 and f_right != 0.0 and f_left * f_right > 0:
        left *= 2.0
        right *= 2.0
        f_left = poly(xs, left)
        f_right = poly(xs, right)

    if f_left == 0.0:
        return left
    if f_right == 0.0:
        return right

    # Bisection: bounded resource usage, robust convergence.
    for _ in range(100):
        mid = (left + right) / 2.0
        f_mid = poly(xs, mid)

        if f_mid == 0.0:
            return mid

        if f_left * f_mid <= 0:
            right = mid
            f_right = f_mid
        else:
            left = mid
            f_left = f_mid

    return (left + right) / 2.0
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
