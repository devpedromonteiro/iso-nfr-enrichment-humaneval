
import unittest
import re
import sys
import math
import copy


def digits(number):
    """Return the product of the odd digits in a positive integer.

    Return 0 if the number contains no odd digits.

    Examples:
        digits(1) == 1
        digits(4) == 0
        digits(235) == 15
    """
    product_of_odd_digits = 1
    found_odd_digit = False

    for digit_character in str(number):
        digit = int(digit_character)

        if digit % 2 == 1:
            product_of_odd_digits *= digit
            found_odd_digit = True

    if found_odd_digit:
        return product_of_odd_digits

    return 0
candidate = digits


def check(candidate):

    # Check some simple cases
    assert candidate(5) == 5
    assert candidate(54) == 5
    assert candidate(120) ==1
    assert candidate(5014) == 5
    assert candidate(98765) == 315
    assert candidate(5576543) == 2625

    # Check some edge cases that are easy to work out by hand.
    assert candidate(2468) == 0



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
