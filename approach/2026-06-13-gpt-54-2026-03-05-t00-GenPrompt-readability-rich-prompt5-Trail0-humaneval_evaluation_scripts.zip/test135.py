
import unittest
import re
import sys
import math
import copy


def can_arrange(numbers):
    """Return the largest index where the sequence stops increasing.

    The function finds the greatest index ``i`` such that
    ``numbers[i] <= numbers[i - 1]``.
    If every element is greater than the one before it, return -1.

    Examples:
        can_arrange([1, 2, 4, 3, 5]) -> 3
        can_arrange([1, 2, 3]) -> -1
    """
    last_non_increasing_index = -1

    for current_index in range(1, len(numbers)):
        current_value = numbers[current_index]
        previous_value = numbers[current_index - 1]

        if current_value <= previous_value:
            last_non_increasing_index = current_index

    return last_non_increasing_index
candidate = can_arrange


def check(candidate):

    # Check some simple cases
    assert candidate([1,2,4,3,5])==3
    assert candidate([1,2,4,5])==-1
    assert candidate([1,4,2,5,6,7,8,9,10])==2
    assert candidate([4,8,5,7,3])==4

    # Check some edge cases that are easy to work out by hand.
    assert candidate([])==-1



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
