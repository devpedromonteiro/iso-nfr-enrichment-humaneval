
import unittest
import re
import sys
import math
import copy



def largest_divisor(n: int) -> int:
    """Return the largest divisor of n that is smaller than n.

    >>> largest_divisor(15)
    5
    """
    for candidate_divisor in range(n // 2, 0, -1):
        if n % candidate_divisor == 0:
            return candidate_divisor

    return 1
candidate = largest_divisor




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(3) == 1
    assert candidate(7) == 1
    assert candidate(10) == 5
    assert candidate(100) == 50
    assert candidate(49) == 7


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
