
import unittest
import re
import sys
import math
import copy


def select_words(text, consonant_count):
    """Return words from text that contain exactly consonant_count consonants.

    Words are returned in the same order they appear in the input text.
    If the input text is empty, an empty list is returned.
    """
    if not text:
        return []

    vowels = {"a", "e", "i", "o", "u"}
    matching_words = []

    for word in text.split():
        consonants_in_word = 0

        for letter in word.lower():
            if letter not in vowels:
                consonants_in_word += 1

        if consonants_in_word == consonant_count:
            matching_words.append(word)

    return matching_words
candidate = select_words


def check(candidate):

    # Check some simple cases
    assert candidate("Mary had a little lamb", 4) == ["little"], "First test error: " + str(candidate("Mary had a little lamb", 4))      
    assert candidate("Mary had a little lamb", 3) == ["Mary", "lamb"], "Second test error: " + str(candidate("Mary had a little lamb", 3))  
    assert candidate("simple white space", 2) == [], "Third test error: " + str(candidate("simple white space", 2))      
    assert candidate("Hello world", 4) == ["world"], "Fourth test error: " + str(candidate("Hello world", 4))  
    assert candidate("Uncle sam", 3) == ["Uncle"], "Fifth test error: " + str(candidate("Uncle sam", 3))


    # Check some edge cases that are easy to work out by hand.
    assert candidate("", 4) == [], "1st edge test error: " + str(candidate("", 4))
    assert candidate("a b c d e f", 1) == ["b", "c", "d", "f"], "2nd edge test error: " + str(candidate("a b c d e f", 1))



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
