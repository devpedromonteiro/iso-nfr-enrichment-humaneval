
import unittest
import re
import sys
import math
import copy


def is_multiply_prime(number):
    """Return True if number is the product of exactly 3 prime numbers, else False."""

    def is_prime(candidate):
        if candidate < 2:
            return False

        divisor = 2
        while divisor * divisor <= candidate:
            if candidate % divisor == 0:
                return False
            divisor += 1

        return True

    prime_factors_found = 0
    remaining_value = number
    factor = 2

    while factor <= remaining_value and prime_factors_found < 3:
        while remaining_value % factor == 0:
            if not is_prime(factor):
                return False

            remaining_value //= factor
            prime_factors_found += 1

            if prime_factors_found > 3:
                return False

        factor += 1

    return prime_factors_found == 3 and remaining_value == 1
candidate = is_multiply_prime


def check(candidate):

    assert candidate(5) == False
    assert candidate(30) == True
    assert candidate(8) == True
    assert candidate(10) == False
    assert candidate(125) == True
    assert candidate(3 * 5 * 7) == True
    assert candidate(3 * 6 * 7) == False
    assert candidate(9 * 9 * 9) == False
    assert candidate(11 * 9 * 9) == False
    assert candidate(11 * 13 * 7) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
