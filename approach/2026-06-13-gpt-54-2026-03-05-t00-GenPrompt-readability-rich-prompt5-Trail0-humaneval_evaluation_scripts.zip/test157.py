
import unittest
import re
import sys
import math
import copy


def right_angle_triangle(side_a, side_b, side_c):
    '''
    Given the lengths of the three sides of a triangle, return True if the three
    sides form a right-angled triangle, False otherwise.

    A right-angled triangle is a triangle in which one angle is a right angle
    (90 degrees).

    Examples:
    right_angle_triangle(3, 4, 5) == True
    right_angle_triangle(1, 2, 3) == False
    '''
    sides = sorted([side_a, side_b, side_c])
    shortest_side, middle_side, longest_side = sides

    forms_valid_triangle = shortest_side + middle_side > longest_side
    satisfies_pythagorean_theorem = (
        shortest_side ** 2 + middle_side ** 2 == longest_side ** 2
    )

    return forms_valid_triangle and satisfies_pythagorean_theorem
candidate = right_angle_triangle


def check(candidate):

    # Check some simple cases
    assert candidate(3, 4, 5) == True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(1, 2, 3) == False
    assert candidate(10, 6, 8) == True
    assert candidate(2, 2, 2) == False
    assert candidate(7, 24, 25) == True
    assert candidate(10, 5, 7) == False
    assert candidate(5, 12, 13) == True
    assert candidate(15, 8, 17) == True
    assert candidate(48, 55, 73) == True

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1, 1, 1) == False, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate(2, 2, 10) == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
