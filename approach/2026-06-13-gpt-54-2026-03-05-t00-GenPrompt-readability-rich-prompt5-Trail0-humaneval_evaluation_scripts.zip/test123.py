
import unittest
import re
import sys
import math
import copy


def get_odd_collatz(n):
    """
    Given a positive integer n, return a sorted list of the odd numbers
    that appear in its Collatz sequence.

    The Collatz sequence is defined as:
    - if the current number is even, the next number is current // 2
    - if the current number is odd, the next number is current * 3 + 1

    The sequence ends when it reaches 1.

    Examples:
        get_odd_collatz(1) -> [1]
        get_odd_collatz(5) -> [1, 5]
    """
    odd_numbers = []
    current_number = n

    while True:
        if current_number % 2 != 0:
            odd_numbers.append(current_number)

        if current_number == 1:
            break

        if current_number % 2 == 0:
            current_number = current_number // 2
        else:
            current_number = current_number * 3 + 1

    return sorted(odd_numbers)
candidate = get_odd_collatz


def check(candidate):

    # Check some simple cases
    assert candidate(14) == [1, 5, 7, 11, 13, 17]
    assert candidate(5) == [1, 5]
    assert candidate(12) == [1, 3, 5], "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1) == [1], "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
