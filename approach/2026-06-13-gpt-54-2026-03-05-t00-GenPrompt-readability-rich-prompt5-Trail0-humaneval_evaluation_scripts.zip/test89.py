
import unittest
import re
import sys
import math
import copy


def encrypt(text):
    """Return a string with each lowercase letter shifted forward by 4.

    Examples:
        encrypt("hi") -> "lm"
        encrypt("asdfghjkl") -> "ewhjklnop"
        encrypt("gf") -> "kj"
        encrypt("et") -> "ix"
    """
    alphabet = "abcdefghijklmnopqrstuvwxyz"
    shift_amount = 4
    encrypted_characters = []

    for character in text:
        original_index = alphabet.index(character)
        shifted_index = (original_index + shift_amount) % len(alphabet)
        encrypted_character = alphabet[shifted_index]
        encrypted_characters.append(encrypted_character)

    return "".join(encrypted_characters)
candidate = encrypt


def check(candidate):

    # Check some simple cases
    assert candidate('hi') == 'lm', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('asdfghjkl') == 'ewhjklnop', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('gf') == 'kj', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('et') == 'ix', "This prints if this assert fails 1 (good for debugging!)"

    assert candidate('faewfawefaewg')=='jeiajeaijeiak', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('hellomyfriend')=='lippsqcjvmirh', "This prints if this assert fails 2 (good for debugging!)"
    assert candidate('dxzdlmnilfuhmilufhlihufnmlimnufhlimnufhfucufh')=='hbdhpqrmpjylqmpyjlpmlyjrqpmqryjlpmqryjljygyjl', "This prints if this assert fails 3 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate('a')=='e', "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
