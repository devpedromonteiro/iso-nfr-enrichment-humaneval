
import unittest
import re
import sys
import math
import copy


def compare_one(a, b):
    """
    Create a function that takes integers, floats, or strings representing
    real numbers, and returns the larger variable in its given variable type.
    Return None if the values are equal.

    compare_one(1, 2.5) â 2.5
    compare_one(1, "2,3") â "2,3"
    compare_one("5,1", "6") â "6"
    compare_one("1", 1) â None
    """
    first_value = _to_number(a)
    second_value = _to_number(b)

    if first_value == second_value:
        return None
    return a if first_value > second_value else b


def _to_number(value):
    """Convert supported input types to a comparable float."""
    if isinstance(value, str):
        return float(value.replace(",", "."))
    return float(value)
candidate = compare_one


def check(candidate):

    # Check some simple cases
    assert candidate(1, 2) == 2
    assert candidate(1, 2.5) == 2.5
    assert candidate(2, 3) == 3
    assert candidate(5, 6) == 6
    assert candidate(1, "2,3") == "2,3"
    assert candidate("5,1", "6") == "6"
    assert candidate("1", "2") == "2"
    assert candidate("1", 1) == None

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
