
import unittest
import re
import sys
import math
import copy



def _contains_digit_seven_count(value: int) -> int:
    """Return how many times digit 7 appears in the decimal representation of value."""
    return str(value).count("7")


def _is_divisible_by_11_or_13(value: int) -> bool:
    """Return True when value is divisible by 11 or 13."""
    return value % 11 == 0 or value % 13 == 0


def fizz_buzz(n: int):
    """Return the number of times the digit 7 appears in integers less than n
    which are divisible by 11 or 13.

    >>> fizz_buzz(50)
    0
    >>> fizz_buzz(78)
    2
    >>> fizz_buzz(79)
    3
    """
    total = 0
    for value in range(n):
        if _is_divisible_by_11_or_13(value):
            total += _contains_digit_seven_count(value)
    return total
candidate = fizz_buzz




METADATA = {}


def check(candidate):
    assert candidate(50) == 0
    assert candidate(78) == 2
    assert candidate(79) == 3
    assert candidate(100) == 3
    assert candidate(200) == 6
    assert candidate(4000) == 192
    assert candidate(10000) == 639
    assert candidate(100000) == 8026



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
