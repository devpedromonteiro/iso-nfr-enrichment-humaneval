
import unittest
import re
import sys
import math
import copy


def _has_valid_duplicate_count(lst):
    """Return True if no value appears more than twice."""
    counts = {}

    for value in lst:
        counts[value] = counts.get(value, 0) + 1
        if counts[value] > 2:
            return False

    return True


def _is_non_decreasing(lst):
    """Return True if the list is sorted in ascending order allowing duplicates."""
    for index in range(1, len(lst)):
        if lst[index] < lst[index - 1]:
            return False

    return True


def is_sorted(lst):
    '''
    Given a list of numbers, return whether or not they are sorted
    in ascending order. If list has more than 1 duplicate of the same
    number, return False. Assume no negative numbers and only integers.

    Examples
    is_sorted([5]) â True
    is_sorted([1, 2, 3, 4, 5]) â True
    is_sorted([1, 3, 2, 4, 5]) â False
    is_sorted([1, 2, 3, 4, 5, 6]) â True
    is_sorted([1, 2, 3, 4, 5, 6, 7]) â True
    is_sorted([1, 3, 2, 4, 5, 6, 7]) â False
    is_sorted([1, 2, 2, 3, 3, 4]) â True
    is_sorted([1, 2, 2, 2, 3, 4]) â False
    '''
    return _is_non_decreasing(lst) and _has_valid_duplicate_count(lst)
candidate = is_sorted


def check(candidate):

    # Check some simple cases
    assert candidate([5]) == True
    assert candidate([1, 2, 3, 4, 5]) == True
    assert candidate([1, 3, 2, 4, 5]) == False
    assert candidate([1, 2, 3, 4, 5, 6]) == True
    assert candidate([1, 2, 3, 4, 5, 6, 7]) == True
    assert candidate([1, 3, 2, 4, 5, 6, 7]) == False, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([]) == True, "This prints if this assert fails 2 (good for debugging!)"
    assert candidate([1]) == True, "This prints if this assert fails 3 (good for debugging!)"
    assert candidate([3, 2, 1]) == False, "This prints if this assert fails 4 (good for debugging!)"
    
    # Check some edge cases that are easy to work out by hand.
    assert candidate([1, 2, 2, 2, 3, 4]) == False, "This prints if this assert fails 5 (good for debugging!)"
    assert candidate([1, 2, 3, 3, 3, 4]) == False, "This prints if this assert fails 6 (good for debugging!)"
    assert candidate([1, 2, 2, 3, 3, 4]) == True, "This prints if this assert fails 7 (good for debugging!)"
    assert candidate([1, 2, 3, 4]) == True, "This prints if this assert fails 8 (good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
