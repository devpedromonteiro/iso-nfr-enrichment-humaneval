
import unittest
import re
import sys
import math
import copy


import operator as op


def _validate_inputs(operators, operands):
    if not isinstance(operators, list) or not isinstance(operands, list):
        raise TypeError("operator and operand must be lists")

    if len(operators) < 1:
        raise ValueError("operator list must contain at least one operator")

    if len(operands) < 2:
        raise ValueError("operand list must contain at least two operands")

    if len(operators) != len(operands) - 1:
        raise ValueError("operator list length must be equal to operand list length minus one")


def _build_expression(operators, operands):
    expression = [str(operands[0])]
    for current_operator, current_operand in zip(operators, operands[1:]):
        expression.append(current_operator)
        expression.append(str(current_operand))
    return " ".join(expression)


def _get_supported_operations():
    return {
        "+": op.add,
        "-": op.sub,
        "*": op.mul,
        "//": op.floordiv,
        "**": op.pow,
    }


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and
    the second list is a list of integers. Use the two given lists to build the algebric
    expression and return the evaluation of this expression.

    The basic algebra operations:
    Addition ( + )
    Subtraction ( - )
    Multiplication ( * )
    Floor division ( // )
    Exponentiation ( ** )

    Example:
    operator['+', '*', '-']
    array = [2, 3, 4, 5]
    result = 2 + 3 * 4 - 5
    => result = 9

    Note:
        The length of operator list is equal to the length of operand list minus one.
        Operand is a list of of non-negative integers.
        Operator list has at least one operator, and operand list has at least two operands.

    """
    _validate_inputs(operator, operand)

    supported_operations = _get_supported_operations()
    expression = _build_expression(operator, operand)

    for current_operator in operator:
        if current_operator not in supported_operations:
            raise ValueError(f"unsupported operator: {current_operator}")

    return eval(expression, {"__builtins__": {}}, {})
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
