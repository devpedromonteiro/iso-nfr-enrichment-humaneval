
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def _max_nesting_depth(group: str) -> int:
    """Return the maximum nesting depth for a single parentheses group."""
    depth = 0
    max_depth = 0

    for char in group:
        if char == "(":
            depth += 1
            max_depth = max(max_depth, depth)
        elif char == ")":
            depth -= 1

    return max_depth


def _split_groups(paren_string: str) -> List[str]:
    """Split the input string into individual parentheses groups."""
    return paren_string.split()


def parse_nested_parens(paren_string: str) -> List[int]:
    """Input to this function is a string represented multiple groups for nested
    parentheses separated by spaces. For each of the group, output the deepest
    level of nesting of parentheses.

    E.g. (()()) has maximum two levels of nesting while ((())) has three.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """
    groups = _split_groups(paren_string)
    return [_max_nesting_depth(group) for group in groups]
candidate = parse_nested_parens




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('(()()) ((())) () ((())()())') == [2, 3, 1, 3]
    assert candidate('() (()) ((())) (((())))') == [1, 2, 3, 4]
    assert candidate('(()(())((())))') == [4]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
