
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Given a grid with N rows and N columns (N >= 2) and a positive integer k,
    each cell of the grid contains a value. Every integer in the range [1, N * N]
    inclusive appears exactly once on the cells of the grid.

    Return the lexicographically smallest sequence of values obtainable by a path
    of length k, where each move goes to an edge-adjacent cell.
    """

    def build_positions(matrix):
        size = len(matrix)
        positions = {}
        for row in range(size):
            for col in range(size):
                positions[matrix[row][col]] = (row, col)
        return positions

    def get_neighbors(row, col, size):
        neighbors = []
        if row > 0:
            neighbors.append((row - 1, col))
        if row < size - 1:
            neighbors.append((row + 1, col))
        if col > 0:
            neighbors.append((row, col - 1))
        if col < size - 1:
            neighbors.append((row, col + 1))
        return neighbors

    def build_neighbor_values(matrix):
        size = len(matrix)
        neighbor_values = {}
        for row in range(size):
            for col in range(size):
                cell_value = matrix[row][col]
                values = []
                for nr, nc in get_neighbors(row, col, size):
                    values.append(matrix[nr][nc])
                neighbor_values[cell_value] = sorted(values)
        return neighbor_values

    def find_smallest_start_value(neighbor_map):
        for value in sorted(neighbor_map):
            if k == 1 or neighbor_map[value]:
                return value
        return None

    def build_min_path(start_value, neighbor_map, path_length):
        path = [start_value]
        current_value = start_value

        for _ in range(path_length - 1):
            next_value = neighbor_map[current_value][0]
            path.append(next_value)
            current_value = next_value

        return path

    if not grid or not grid[0] or k <= 0:
        return []

    build_positions(grid)  # kept separate for clarity of responsibilities

    neighbor_map = build_neighbor_values(grid)
    start_value = find_smallest_start_value(neighbor_map)

    if start_value is None:
        return []

    return build_min_path(start_value, neighbor_map, k)
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
