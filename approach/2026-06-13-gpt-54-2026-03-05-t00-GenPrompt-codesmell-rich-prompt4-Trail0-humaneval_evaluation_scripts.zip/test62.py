
import unittest
import re
import sys
import math
import copy



from typing import List


def _derivative_term(index: int, coefficient: int) -> int:
    """Return the derivative coefficient for a single polynomial term."""
    return index * coefficient


def derivative(xs: List[int]) -> List[int]:
    """Return the derivative coefficients of a polynomial.

    xs represents coefficients of a polynomial:
    xs[0] + xs[1] * x + xs[2] * x^2 + ...

    >>> derivative([3, 1, 2, 4, 5])
    [1, 4, 12, 20]
    >>> derivative([1, 2, 3])
    [2, 6]
    """
    return [_derivative_term(index, coefficient) for index, coefficient in enumerate(xs[1:], start=1)]
candidate = derivative




METADATA = {}


def check(candidate):
    assert candidate([3, 1, 2, 4, 5]) == [1, 4, 12, 20]
    assert candidate([1, 2, 3]) == [2, 6]
    assert candidate([3, 2, 1]) == [2, 2]
    assert candidate([3, 2, 1, 0, 4]) == [2, 2, 0, 16]
    assert candidate([1]) == []



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
