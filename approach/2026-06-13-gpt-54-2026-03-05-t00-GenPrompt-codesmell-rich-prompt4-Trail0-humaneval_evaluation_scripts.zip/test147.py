
import unittest
import re
import sys
import math
import copy


def _value_mod_3(index):
    """Return a[index] mod 3 where a[index] = index^2 - index + 1."""
    return (index * index - index + 1) % 3


def _count_mod_groups(n):
    """Count how many indices 1..n produce each remainder modulo 3."""
    counts = [0, 0, 0]
    for i in range(1, n + 1):
        counts[_value_mod_3(i)] += 1
    return counts


def _combinations_of_three(x):
    """Return C(x, 3)."""
    if x < 3:
        return 0
    return x * (x - 1) * (x - 2) // 6


def get_max_triples(n):
    """
    You are given a positive integer n. You have to create an integer array a of length n.
        For each i (1 â¤ i â¤ n), the value of a[i] = i * i - i + 1.
        Return the number of triples (a[i], a[j], a[k]) of a where i < j < k,
    and a[i] + a[j] + a[k] is a multiple of 3.

    Example :
        Input: n = 5
        Output: 1
        Explanation:
        a = [1, 3, 7, 13, 21]
        The only valid triple is (1, 7, 13).
    """
    if n < 3:
        return 0

    count_0, count_1, count_2 = _count_mod_groups(n)

    # Valid remainder combinations summing to a multiple of 3:
    # (0,0,0), (1,1,1), (2,2,2), and (0,1,2)
    all_same_remainder = (
        _combinations_of_three(count_0)
        + _combinations_of_three(count_1)
        + _combinations_of_three(count_2)
    )
    one_from_each_group = count_0 * count_1 * count_2

    return all_same_remainder + one_from_each_group
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
