
import unittest
import re
import sys
import math
import copy



def _validate_non_negative(value, name):
    """Validate that a numeric value is non-negative."""
    if value < 0:
        raise ValueError(f"{name} must be non-negative")


def _compute_triangle_area(base, height):
    """Compute the area of a triangle."""
    return (base * height) / 2


def triangle_area(a, h):
    """Given length of a side and high return area for a triangle.

    >>> triangle_area(5, 3)
    7.5
    """
    _validate_non_negative(a, "a")
    _validate_non_negative(h, "h")
    return _compute_triangle_area(a, h)
candidate = triangle_area




METADATA = {}


def check(candidate):
    assert candidate(5, 3) == 7.5
    assert candidate(2, 2) == 2.0
    assert candidate(10, 8) == 40.0



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
