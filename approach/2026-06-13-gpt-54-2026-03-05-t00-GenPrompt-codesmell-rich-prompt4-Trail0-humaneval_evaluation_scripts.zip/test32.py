
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math
from typing import Sequence


def poly(coefficients: Sequence[float], x: float) -> float:
    """
    Evaluate a polynomial with coefficients at point x.

    The polynomial is:
        coefficients[0] + coefficients[1] * x + ... + coefficients[n] * x^n
    """
    return sum(coeff * math.pow(x, power) for power, coeff in enumerate(coefficients))


def find_zero(coefficients: Sequence[float]) -> float:
    """
    Find one real zero of a polynomial.

    The input must satisfy the documented constraint:
    - it has an even number of coefficients
    - the highest non-zero coefficient guarantees existence of a real root

    Returns one root x such that poly(coefficients, x) == 0 approximately.

    >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2)  # (x - 1) * (x - 2) * (x - 3)
    1.0
    """
    _validate_coefficients(coefficients)

    if _is_zero(poly(coefficients, 0.0)):
        return 0.0

    left, right = _find_bracketing_interval(coefficients)
    return _bisect_root(coefficients, left, right)


def _validate_coefficients(coefficients: Sequence[float]) -> None:
    if not coefficients:
        raise ValueError("coefficients must not be empty")
    if len(coefficients) % 2 != 0:
        raise ValueError("coefficients must contain an even number of items")
    if _all_zero(coefficients):
        raise ValueError("polynomial must not be identically zero")


def _all_zero(coefficients: Sequence[float]) -> bool:
    return all(_is_zero(value) for value in coefficients)


def _is_zero(value: float, tolerance: float = 1e-12) -> bool:
    return abs(value) <= tolerance


def _find_bracketing_interval(
    coefficients: Sequence[float], initial_bound: float = 1.0
def _bisect_root(
    coefficients: Sequence[float],
    left: float,
    right: float,
    tolerance: float = 1e-12,
    max_iterations: int = 10_000,
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
