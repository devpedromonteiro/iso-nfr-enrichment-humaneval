
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import Iterable


def _running_balances(operations: Iterable[int]) -> Iterable[int]:
    """Yield the account balance after each operation."""
    balance = 0
    for operation in operations:
        balance += operation
        yield balance


def below_zero(operations: list[int]) -> bool:
    """Return True if the balance drops below zero at any point.

    The account starts with a zero balance and each value in `operations`
    represents a deposit (positive) or withdrawal (negative).

    >>> below_zero([1, 2, 3])
    False
    >>> below_zero([1, 2, -4, 5])
    True
    """
    return any(balance < 0 for balance in _running_balances(operations))
candidate = below_zero




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == False
    assert candidate([1, 2, -3, 1, 2, -3]) == False
    assert candidate([1, 2, -4, 5, 6]) == True
    assert candidate([1, -1, 2, -2, 5, -5, 4, -4]) == False
    assert candidate([1, -1, 2, -2, 5, -5, 4, -5]) == True
    assert candidate([1, -2, 2, -2, 5, -5, 4, -4]) == True


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
