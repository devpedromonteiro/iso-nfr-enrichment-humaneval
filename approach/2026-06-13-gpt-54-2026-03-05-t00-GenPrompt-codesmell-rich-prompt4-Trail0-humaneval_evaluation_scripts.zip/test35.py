
import unittest
import re
import sys
import math
import copy



def _validate_non_empty_list(values: list) -> None:
    """Validate that the input is a non-empty list."""
    if not isinstance(values, list):
        raise TypeError("values must be a list")
    if not values:
        raise ValueError("values must not be empty")


def _find_maximum(values: list):
    """Return the maximum element from a non-empty list."""
    maximum = values[0]
    for value in values[1:]:
        if value > maximum:
            maximum = value
    return maximum


def max_element(l: list):
    """Return maximum element in the list.
    >>> max_element([1, 2, 3])
    3
    >>> max_element([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    123
    """
    _validate_non_empty_list(l)
    return _find_maximum(l)
candidate = max_element




METADATA = {}


def check(candidate):
    assert candidate([1, 2, 3]) == 3
    assert candidate([5, 3, -5, 2, -3, 3, 9, 0, 124, 1, -10]) == 124


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
