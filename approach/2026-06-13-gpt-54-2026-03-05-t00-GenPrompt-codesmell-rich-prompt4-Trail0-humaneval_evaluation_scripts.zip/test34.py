
import unittest
import re
import sys
import math
import copy



def _sorted_items(items: list):
    """Return a sorted copy of the input items."""
    return sorted(items)


def _deduplicate_sorted_items(items: list):
    """Return unique items from an already sorted list."""
    if not items:
        return []

    unique_items = [items[0]]
    for item in items[1:]:
        if item != unique_items[-1]:
            unique_items.append(item)
    return unique_items


def unique(l: list):
    """Return sorted unique elements in a list
    >>> unique([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [0, 2, 3, 5, 9, 123]
    """
    sorted_items = _sorted_items(l)
    return _deduplicate_sorted_items(sorted_items)
candidate = unique




METADATA = {}


def check(candidate):
    assert candidate([5, 3, 5, 2, 3, 3, 9, 0, 123]) == [0, 2, 3, 5, 9, 123]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
