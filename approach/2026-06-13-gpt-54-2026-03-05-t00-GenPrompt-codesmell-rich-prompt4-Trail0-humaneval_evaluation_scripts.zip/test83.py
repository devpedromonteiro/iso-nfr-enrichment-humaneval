
import unittest
import re
import sys
import math
import copy


def _count_n_digit_numbers(n):
    """Return the total number of positive integers with exactly n digits."""
    return 9 * (10 ** (n - 1))


def _count_n_digit_numbers_not_starting_or_ending_with_one(n):
    """
    Return the count of n-digit positive integers that neither start nor end with 1.
    """
    if n == 1:
        return 8  # Digits 2-9

    first_digit_choices = 8   # 2-9
    middle_digit_choices = 10 ** (n - 2)
    last_digit_choices = 9    # 0-9 except 1
    return first_digit_choices * middle_digit_choices * last_digit_choices


def starts_one_ends(n):
    """
    Given a positive integer n, return the count of the numbers of n-digit
    positive integers that start or end with 1.
    """
    if not isinstance(n, int) or n <= 0:
        raise ValueError("n must be a positive integer")

    total_n_digit_numbers = _count_n_digit_numbers(n)
    excluded_numbers = _count_n_digit_numbers_not_starting_or_ending_with_one(n)
    return total_n_digit_numbers - excluded_numbers
candidate = starts_one_ends


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(1) == 1
    assert candidate(2) == 18
    assert candidate(3) == 180
    assert candidate(4) == 1800
    assert candidate(5) == 18000

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
