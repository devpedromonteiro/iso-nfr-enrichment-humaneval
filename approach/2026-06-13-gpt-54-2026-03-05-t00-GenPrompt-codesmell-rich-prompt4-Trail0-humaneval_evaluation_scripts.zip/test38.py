
import unittest
import re
import sys
import math
import copy



def encode_cyclic(s: str):
    """
    returns encoded string by cycling groups of three characters.
    """
    # split string to groups. Each of length 3.
    groups = [s[(3 * i):min((3 * i + 3), len(s))] for i in range((len(s) + 2) // 3)]
    # cycle elements in each group. Unless group has fewer elements than 3.
    groups = [(group[1:] + group[0]) if len(group) == 3 else group for group in groups]
    return "".join(groups)


def _split_into_groups(s: str, group_size: int = 3) -> list[str]:
    """
    Split a string into consecutive groups of the given size.
    """
    return [s[i:i + group_size] for i in range(0, len(s), group_size)]


def _rotate_left(group: str) -> str:
    """
    Rotate a 3-character group one position to the left.
    Groups shorter than 3 characters are returned unchanged.
    """
    return group[1:] + group[0] if len(group) == 3 else group


def _rotate_right(group: str) -> str:
    """
    Rotate a 3-character group one position to the right.
    Groups shorter than 3 characters are returned unchanged.
    """
    return group[-1] + group[:-1] if len(group) == 3 else group


def _transform_groups(s: str, transformer) -> str:
    """
    Apply a transformation to each 3-character group and join the result.
    """
    groups = _split_into_groups(s, 3)
    return "".join(transformer(group) for group in groups)


def encode_cyclic(s: str):
    """
    returns encoded string by cycling groups of three characters.
    """
    return _transform_groups(s, _rotate_left)


def decode_cyclic(s: str):
    """
    takes as input string encoded with encode_cyclic function. Returns decoded string.
    """
    return _transform_groups(s, _rotate_right)
candidate = decode_cyclic




METADATA = {}


def check(candidate):
    from random import randint, choice
    import string

    letters = string.ascii_lowercase
    for _ in range(100):
        str = ''.join(choice(letters) for i in range(randint(10, 20)))
        encoded_str = encode_cyclic(str)
        assert candidate(encoded_str) == str



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
