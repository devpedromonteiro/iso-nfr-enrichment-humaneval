
import unittest
import re
import sys
import math
import copy



def _validate_string(value: str) -> None:
    """Validate that the provided value is a string."""
    if not isinstance(value, str):
        raise TypeError("string must be of type str")


def _count_characters(value: str) -> int:
    """Count the number of characters in a string."""
    count = 0
    for _ in value:
        count += 1
    return count


def strlen(string: str) -> int:
    """Return length of given string.

    >>> strlen('')
    0
    >>> strlen('abc')
    3
    """
    _validate_string(string)
    return _count_characters(string)
candidate = strlen




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == 0
    assert candidate('x') == 1
    assert candidate('asdasnakj') == 9


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
