
import unittest
import re
import sys
import math
import copy


PRIME_HEX_DIGITS = {"2", "3", "5", "7", "B", "D"}


def is_prime_hex_digit(digit):
    """Return True if the hexadecimal digit represents a prime value."""
    return digit in PRIME_HEX_DIGITS


def hex_key(num):
    """Count prime-valued hexadecimal digits in the given string."""
    return sum(1 for digit in num if is_prime_hex_digit(digit))
candidate = hex_key


def check(candidate):

    # Check some simple cases
    assert candidate("AB") == 1, "First test error: " + str(candidate("AB"))      
    assert candidate("1077E") == 2, "Second test error: " + str(candidate("1077E"))  
    assert candidate("ABED1A33") == 4, "Third test error: " + str(candidate("ABED1A33"))      
    assert candidate("2020") == 2, "Fourth test error: " + str(candidate("2020"))  
    assert candidate("123456789ABCDEF0") == 6, "Fifth test error: " + str(candidate("123456789ABCDEF0"))      
    assert candidate("112233445566778899AABBCCDDEEFF00") == 12, "Sixth test error: " + str(candidate("112233445566778899AABBCCDDEEFF00"))  


    # Check some edge cases that are easy to work out by hand.
    assert candidate([]) == 0



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
