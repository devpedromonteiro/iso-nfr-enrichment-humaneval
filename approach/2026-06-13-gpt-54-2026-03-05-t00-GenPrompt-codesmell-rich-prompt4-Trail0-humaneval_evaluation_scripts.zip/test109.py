
import unittest
import re
import sys
import math
import copy


def _count_descending_breaks(arr):
    """Count positions where the non-decreasing order is broken cyclically."""
    if not arr:
        return 0

    breaks = 0
    size = len(arr)

    for index in range(size):
        current = arr[index]
        next_value = arr[(index + 1) % size]
        if current > next_value:
            breaks += 1

    return breaks


def move_one_ball(arr):
    """Return True if the array can be sorted by cyclic right shifts only.

    A list can be transformed into non-decreasing order by right shifts iff
    its cyclic sequence contains at most one descending break.
    Empty lists are considered sortable.
    """
    return _count_descending_breaks(arr) <= 1
candidate = move_one_ball


def check(candidate):

    # Check some simple cases
    assert candidate([3, 4, 5, 1, 2])==True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([3, 5, 10, 1, 2])==True
    assert candidate([4, 3, 1, 2])==False
    # Check some edge cases that are easy to work out by hand.
    assert candidate([3, 5, 4, 1, 2])==False, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([])==True


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
