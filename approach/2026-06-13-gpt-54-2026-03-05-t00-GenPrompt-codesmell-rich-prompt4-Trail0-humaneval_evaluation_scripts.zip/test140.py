
import unittest
import re
import sys
import math
import copy


def _space_replacement(space_count):
    """Return the replacement token for a run of spaces."""
    return "-" if space_count > 2 else "_" * space_count


def fix_spaces(text):
    """
    Given a string text, replace spaces using these rules:
    - single or double spaces become underscores
    - more than 2 consecutive spaces become a single '-'

    Examples:
        fix_spaces("Example") == "Example"
        fix_spaces("Example 1") == "Example_1"
        fix_spaces(" Example 2") == "_Example_2"
        fix_spaces(" Example   3") == "_Example-3"
    """
    result = []
    space_count = 0

    for char in text:
        if char == " ":
            space_count += 1
            continue

        if space_count:
            result.append(_space_replacement(space_count))
            space_count = 0

        result.append(char)

    if space_count:
        result.append(_space_replacement(space_count))

    return "".join(result)
candidate = fix_spaces


def check(candidate):

    # Check some simple cases
    assert candidate("Example") == "Example", "This prints if this assert fails 1 (good for debugging!)"
    assert candidate("Mudasir Hanif ") == "Mudasir_Hanif_", "This prints if this assert fails 2 (good for debugging!)"
    assert candidate("Yellow Yellow  Dirty  Fellow") == "Yellow_Yellow__Dirty__Fellow", "This prints if this assert fails 3 (good for debugging!)"
    
    # Check some edge cases that are easy to work out by hand.
    assert candidate("Exa   mple") == "Exa-mple", "This prints if this assert fails 4 (good for debugging!)"
    assert candidate("   Exa 1 2 2 mple") == "-Exa_1_2_2_mple", "This prints if this assert fails 4 (good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
