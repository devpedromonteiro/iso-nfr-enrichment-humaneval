
import unittest
import re
import sys
import math
import copy



def _normalize_text(text: str) -> str:
    return text


def _is_same_forward_and_backward(text: str) -> bool:
    return text == text[::-1]


def is_palindrome(text: str) -> bool:
    """
    Checks if given string is a palindrome
    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    """
    normalized_text = _normalize_text(text)
    return _is_same_forward_and_backward(normalized_text)
candidate = is_palindrome




METADATA = {}


def check(candidate):
    assert candidate('') == True
    assert candidate('aba') == True
    assert candidate('aaaaa') == True
    assert candidate('zbcd') == False
    assert candidate('xywyx') == True
    assert candidate('xywyz') == False
    assert candidate('xywzx') == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
