
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List, Dict


def _count_occurrences(numbers: List[int]) -> Dict[int, int]:
    counts: Dict[int, int] = {}
    for number in numbers:
        counts[number] = counts.get(number, 0) + 1
    return counts


def _filter_unique_in_order(numbers: List[int], counts: Dict[int, int]) -> List[int]:
    return [number for number in numbers if counts[number] == 1]


def remove_duplicates(numbers: List[int]) -> List[int]:
    """From a list of integers, remove all elements that occur more than once.
    Keep order of elements left the same as in the input.

    >>> remove_duplicates([1, 2, 3, 2, 4])
    [1, 3, 4]
    """
    counts = _count_occurrences(numbers)
    return _filter_unique_in_order(numbers, counts)
candidate = remove_duplicates




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == []
    assert candidate([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert candidate([1, 2, 3, 2, 4, 3, 5]) == [1, 4, 5]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
