
import unittest
import re
import sys
import math
import copy



def _sorted_values(values: list):
    """Return a sorted copy of the input list."""
    return sorted(values)


def _middle_indices(length: int):
    """Return the middle index or indices for a sequence length."""
    mid = length // 2
    if length % 2 == 1:
        return (mid,)
    return (mid - 1, mid)


def median(l: list):
    """Return median of elements in the list l.

    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    15.0
    """
    if not l:
        raise ValueError("median() arg is an empty list")

    sorted_list = _sorted_values(l)
    indices = _middle_indices(len(sorted_list))

    if len(indices) == 1:
        return sorted_list[indices[0]]

    left, right = indices
    return (sorted_list[left] + sorted_list[right]) / 2
candidate = median




METADATA = {}


def check(candidate):
    assert candidate([3, 1, 2, 4, 5]) == 3
    assert candidate([-10, 4, 6, 1000, 10, 20]) == 8.0
    assert candidate([5]) == 5
    assert candidate([6, 5]) == 5.5
    assert candidate([8, 1, 3, 9, 9, 2, 7]) == 7 



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
