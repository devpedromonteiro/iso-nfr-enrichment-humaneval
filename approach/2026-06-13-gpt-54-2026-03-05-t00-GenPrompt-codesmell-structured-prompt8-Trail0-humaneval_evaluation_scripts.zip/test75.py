
import unittest
import re
import sys
import math
import copy


def is_prime(n):
    """Return True if n is a prime number, otherwise False."""
    if n < 2:
        return False
    if n == 2:
        return True
    if n % 2 == 0:
        return False

    limit = int(n ** 0.5) + 1
    for divisor in range(3, limit, 2):
        if n % divisor == 0:
            return False
    return True


def prime_factors_count(n):
    """Return the count of prime factors of n, including repetitions."""
    count = 0
    divisor = 2

    while divisor * divisor <= n:
        while n % divisor == 0:
            if not is_prime(divisor):
                return -1
            count += 1
            n //= divisor
        divisor += 1

    if n > 1:
        count += 1

    return count


def is_multiply_prime(a):
    """Return True if a is the product of exactly 3 prime numbers."""
    if a < 2:
        return False
    return prime_factors_count(a) == 3
candidate = is_multiply_prime


def check(candidate):

    assert candidate(5) == False
    assert candidate(30) == True
    assert candidate(8) == True
    assert candidate(10) == False
    assert candidate(125) == True
    assert candidate(3 * 5 * 7) == True
    assert candidate(3 * 6 * 7) == False
    assert candidate(9 * 9 * 9) == False
    assert candidate(11 * 9 * 9) == False
    assert candidate(11 * 13 * 7) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
