
import unittest
import re
import sys
import math
import copy



def _divisors_below_n(n: int):
    """Yield divisors of n that are smaller than n."""
    for candidate in range(1, n):
        if n % candidate == 0:
            yield candidate


def largest_divisor(n: int) -> int:
    """For a given number n, find the largest number that divides n evenly, smaller than n.

    >>> largest_divisor(15)
    5
    """
    return max(_divisors_below_n(n))
candidate = largest_divisor




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(3) == 1
    assert candidate(7) == 1
    assert candidate(10) == 5
    assert candidate(100) == 50
    assert candidate(49) == 7


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
