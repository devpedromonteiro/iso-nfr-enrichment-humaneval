
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    You are given a positive integer n. You have to create an integer array a of length n.
    For each i (1 â¤ i â¤ n), the value of a[i] = i * i - i + 1.

    Return the number of triples (a[i], a[j], a[k]) where i < j < k and
    a[i] + a[j] + a[k] is a multiple of 3.

    Example:
        Input: n = 5
        Output: 1
    """

    def count_by_modulo(limit):
        counts = [0, 0, 0]
        for i in range(1, limit + 1):
            value_mod = (i * i - i + 1) % 3
            counts[value_mod] += 1
        return counts

    def combinations_of_three(x):
        if x < 3:
            return 0
        return x * (x - 1) * (x - 2) // 6

    counts = count_by_modulo(n)
    count_mod_0, count_mod_1, count_mod_2 = counts

    # Valid modulo combinations for sum divisible by 3:
    # (0,0,0), (1,1,1), (2,2,2), and (0,1,2)
    total = 0
    total += combinations_of_three(count_mod_0)
    total += combinations_of_three(count_mod_1)
    total += combinations_of_three(count_mod_2)
    total += count_mod_0 * count_mod_1 * count_mod_2

    return total
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
