
import unittest
import re
import sys
import math
import copy


def encode(message):
    vowels_to_replacement = {
        "a": "c",
        "e": "g",
        "i": "k",
        "o": "q",
        "u": "w",
    }

    encoded_characters = []

    for character in message:
        lowercase_character = character.lower()

        if lowercase_character in vowels_to_replacement:
            transformed_character = vowels_to_replacement[lowercase_character]
        else:
            transformed_character = lowercase_character

        encoded_characters.append(transformed_character.swapcase())

    return "".join(encoded_characters)
candidate = encode


def check(candidate):

    # Check some simple cases
    assert candidate('TEST') == 'tgst', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('Mudasir') == 'mWDCSKR', "This prints if this assert fails 2 (good for debugging!)"
    assert candidate('YES') == 'ygs', "This prints if this assert fails 3 (good for debugging!)"
    
    # Check some edge cases that are easy to work out by hand.
    assert candidate('This is a message') == 'tHKS KS C MGSSCGG', "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate("I DoNt KnOw WhAt tO WrItE") == 'k dQnT kNqW wHcT Tq wRkTg', "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
