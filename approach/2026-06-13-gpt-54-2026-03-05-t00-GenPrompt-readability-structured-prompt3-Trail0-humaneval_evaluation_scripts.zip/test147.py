
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    Return the number of index triples (i, j, k), with 1 <= i < j < k <= n,
    such that:
        a[i] = i^2 - i + 1
    and
        a[i] + a[j] + a[k]
    is divisible by 3.

    The sequence modulo 3 follows a simple pattern:
        i % 3 == 0 -> a[i] % 3 == 1
        i % 3 == 1 -> a[i] % 3 == 1
        i % 3 == 2 -> a[i] % 3 == 0

    So every value in the array is congruent to either 0 or 1 modulo 3.
    A sum of three values is divisible by 3 only when all three are 1 modulo 3.

    Therefore, the answer is:
        C(count_of_values_congruent_to_1_mod_3, 3)
    """

    def combinations_of_three(count):
        if count < 3:
            return 0
        return count * (count - 1) * (count - 2) // 6

    count_congruent_to_one = n - (n // 3)
    return combinations_of_three(count_congruent_to_one)
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
