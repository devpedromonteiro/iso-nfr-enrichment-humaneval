
import unittest
import re
import sys
import math
import copy


def starts_one_ends(digit_count):
    """
    Return how many positive integers with exactly ``digit_count`` digits
    start with 1 or end with 1.

    A number is counted if either of these is true:
    - its first digit is 1
    - its last digit is 1

    Parameters
    ----------
    digit_count : int
        The number of digits in the positive integers being counted.
        Must be greater than 0.

    Returns
    -------
    int
        The count of ``digit_count``-digit positive integers that start
        or end with 1.
    """
    if digit_count <= 0:
        raise ValueError("digit_count must be a positive integer")

    if digit_count == 1:
        return 1

    count_starting_with_1 = 10 ** (digit_count - 1)
    count_ending_with_1 = 9 * (10 ** (digit_count - 2))
    count_starting_and_ending_with_1 = 10 ** (digit_count - 2)

    total_count = (
        count_starting_with_1
        + count_ending_with_1
        - count_starting_and_ending_with_1
    )

    return total_count
candidate = starts_one_ends


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(1) == 1
    assert candidate(2) == 18
    assert candidate(3) == 180
    assert candidate(4) == 1800
    assert candidate(5) == 18000

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
