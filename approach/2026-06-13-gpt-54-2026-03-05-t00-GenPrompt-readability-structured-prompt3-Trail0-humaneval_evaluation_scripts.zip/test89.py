
import unittest
import re
import sys
import math
import copy


def encrypt(text):
    """Return a new string with each lowercase letter shifted forward by 4.

    The shift wraps around the alphabet:
    - 'a' -> 'e'
    - 'x' -> 'b'

    Examples:
        encrypt('hi') -> 'lm'
        encrypt('asdfghjkl') -> 'ewhjklnop'
        encrypt('gf') -> 'kj'
        encrypt('et') -> 'ix'
    """
    shift_amount = 4
    alphabet_start = ord('a')
    alphabet_size = 26

    encrypted_characters = []

    for character in text:
        original_position = ord(character) - alphabet_start
        shifted_position = (original_position + shift_amount) % alphabet_size
        encrypted_character = chr(alphabet_start + shifted_position)
        encrypted_characters.append(encrypted_character)

    return "".join(encrypted_characters)
candidate = encrypt


def check(candidate):

    # Check some simple cases
    assert candidate('hi') == 'lm', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('asdfghjkl') == 'ewhjklnop', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('gf') == 'kj', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('et') == 'ix', "This prints if this assert fails 1 (good for debugging!)"

    assert candidate('faewfawefaewg')=='jeiajeaijeiak', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('hellomyfriend')=='lippsqcjvmirh', "This prints if this assert fails 2 (good for debugging!)"
    assert candidate('dxzdlmnilfuhmilufhlihufnmlimnufhlimnufhfucufh')=='hbdhpqrmpjylqmpyjlpmlyjrqpmqryjlpmqryjljygyjl', "This prints if this assert fails 3 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate('a')=='e', "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
