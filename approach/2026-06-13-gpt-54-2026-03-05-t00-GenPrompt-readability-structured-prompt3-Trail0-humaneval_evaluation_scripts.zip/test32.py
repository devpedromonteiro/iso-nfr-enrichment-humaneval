
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math


def evaluate_polynomial(coefficients: list[float], x_value: float) -> float:
    """
    Evaluate a polynomial at the given x value.

    The polynomial is defined by its coefficients:
    coefficients[0] + coefficients[1] * x + coefficients[2] * x^2 + ...

    Example:
        coefficients = [1, 2, 3] represents 1 + 2x + 3x^2
    """
    return sum(
        coefficient * math.pow(x_value, power)
        for power, coefficient in enumerate(coefficients)
    )


def find_zero(coefficients: list[float]) -> float:
    """
    Find one real zero of a polynomial.

    The input must satisfy the assumptions described below:
    - the list contains an even number of coefficients
    - the highest-degree non-zero coefficient guarantees the existence
      of at least one real zero

    This function returns one zero, even if the polynomial has many.

    Examples:
        >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
        -0.5
        >>> round(find_zero([-6, 11, -6, 1]), 2)
        1.0
    """
    if not coefficients:
        raise ValueError("coefficients must not be empty")

    lower_bound = -1.0
    upper_bound = 1.0

    value_at_lower_bound = evaluate_polynomial(coefficients, lower_bound)
    value_at_upper_bound = evaluate_polynomial(coefficients, upper_bound)

    while value_at_lower_bound * value_at_upper_bound > 0:
        lower_bound *= 2
        upper_bound *= 2
        value_at_lower_bound = evaluate_polynomial(coefficients, lower_bound)
        value_at_upper_bound = evaluate_polynomial(coefficients, upper_bound)

    while abs(upper_bound - lower_bound) > 1e-7:
        midpoint = (lower_bound + upper_bound) / 2
        value_at_midpoint = evaluate_polynomial(coefficients, midpoint)

        if value_at_midpoint == 0:
            return midpoint

        if value_at_lower_bound * value_at_midpoint < 0:
            upper_bound = midpoint
            value_at_upper_bound = value_at_midpoint
        else:
            lower_bound = midpoint
            value_at_lower_bound = value_at_midpoint

    return (lower_bound + upper_bound) / 2
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
