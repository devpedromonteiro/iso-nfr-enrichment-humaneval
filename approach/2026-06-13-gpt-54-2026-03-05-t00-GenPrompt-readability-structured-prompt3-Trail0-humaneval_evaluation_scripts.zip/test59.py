
import unittest
import re
import sys
import math
import copy



def largest_prime_factor(n: int) -> int:
    """Return the largest prime factor of n. Assume n > 1 and n is not prime.

    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    remaining_value = n
    largest_factor = 1

    while remaining_value % 2 == 0:
        largest_factor = 2
        remaining_value //= 2

    candidate_factor = 3
    while candidate_factor * candidate_factor <= remaining_value:
        while remaining_value % candidate_factor == 0:
            largest_factor = candidate_factor
            remaining_value //= candidate_factor
        candidate_factor += 2

    if remaining_value > 1:
        largest_factor = remaining_value

    return largest_factor
candidate = largest_prime_factor




METADATA = {}


def check(candidate):
    assert candidate(15) == 5
    assert candidate(27) == 3
    assert candidate(63) == 7
    assert candidate(330) == 11
    assert candidate(13195) == 29



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
