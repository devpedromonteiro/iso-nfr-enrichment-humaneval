
import unittest

from typing import List


from typing import List


def string_xor(a: str, b: str) -> str:
    """Input are two strings a and b consisting only of 1s and 0s.
    Perform binary XOR on these inputs and return result also as a string.

    >>> string_xor('010', '110')
    '100'
    """
    if not isinstance(a, str):
        raise TypeError(f"a must be a str, got {type(a).__name__}")
    if not isinstance(b, str):
        raise TypeError(f"b must be a str, got {type(b).__name__}")

    if len(a) != len(b):
        raise ValueError("a and b must have the same length")

    invalid_a = set(a) - {"0", "1"}
    if invalid_a:
        raise ValueError("a must contain only '0' and '1' characters")

    invalid_b = set(b) - {"0", "1"}
    if invalid_b:
        raise ValueError("b must contain only '0' and '1' characters")

    result: List[str] = []
    for bit_a, bit_b in zip(a, b):
        result.append("0" if bit_a == bit_b else "1")

    return "".join(result)
candidate = string_xor


class Test(unittest.TestCase):
    def test(self):
        assert candidate('9899538', '0376864') == '1111111'
        assert candidate('969623', '400762') == '111111'
        assert candidate('188', '13905421') == '011'
        assert candidate('9', '6') == '1'
        assert candidate('78657', '1224857') == '11111'
        assert candidate('580832803496', '965967940') == '111111111'
        assert candidate('828885', '745813') == '111011'
        assert candidate('9970115', '917398033') == '0101111'
        assert candidate('71241', '7116729') == '00111'
        assert candidate('564339962', '449') == '111'
        assert candidate('111000', '101010') == '010010'
        assert candidate('7709390', '47300796') == '1011111'
        assert candidate('55807480', '832') == '111'
        assert candidate('8', '4') == '1'
        assert candidate('56057', '4625439') == '10101'
        assert candidate('8', '3') == '1'
        assert candidate('43059110372', '017') == '111'
        assert candidate('3', '3') == '0'
        assert candidate('9573751', '75368805939') == '1011111'
        assert candidate('5', '4') == '1'
        assert candidate('3354233639', '09534218574') == '1101111111'
        assert candidate('302502', '55997103') == '111111'
        assert candidate('63454936', '348894740') == '11111111'
        assert candidate('4231', '393022564') == '1101'
        assert candidate('262', '88203') == '110'
        assert candidate('2', '1') == '1'
        assert candidate('0', '0') == '0'
        assert candidate('062', '421') == '111'
        assert candidate('047134191178', '059757641') == '011111110'
        assert candidate('81716', '73979') == '11111'
        assert candidate('4', '3') == '1'
        assert candidate('087055037', '185352') == '101101'
        assert candidate('446018', '2463876') == '100111'
        assert candidate('5', '9') == '1'
        assert candidate('966', '709') == '111'
        assert candidate('740979023', '722542442') == '011111111'
        assert candidate('45138778', '911') == '110'
        assert candidate('8', '8') == '0'
        assert candidate('09325353248', '91364') == '11011'
        assert candidate('4', '5') == '1'
        assert candidate('5646686', '345080742') == '1111111'
        assert candidate('9753739', '294') == '111'
        assert candidate('1891385', '765985') == '111111'
        assert candidate('978782669', '48854526') == '11011110'
        assert candidate('143632', '98540370') == '111111'
        assert candidate('0101', '0000') == '0101'
        assert candidate('9', '7') == '1'
        assert candidate('4', '8') == '1'
        assert candidate('0', '9') == '1'
        assert candidate('7', '8') == '1'
        assert candidate('0596148', '368805') == '111111'
        assert candidate('02019515907', '87905461167') == '11111111110'
        assert candidate('581505516', '940241') == '111111'
        assert candidate('934724', '63870') == '10101'
        assert candidate('7936', '5693') == '1111'
        assert candidate('163', '213854') == '110'
        assert candidate('818407301754', '019251') == '101111'
        assert candidate('8431492', '610532216') == '1111110'
        assert candidate('899', '032215787') == '111'
        assert candidate('77682', '987') == '111'
        assert candidate('4912', '990') == '101'
        assert candidate('21309979', '2956795') == '0111101'
        assert candidate('784857', '858') == '111'
        assert candidate('9068664', '79920') == '11111'
        assert candidate('5227581', '061361100') == '1111110'
        assert candidate('81305', '9261') == '1111'
        assert candidate('7', '3') == '1'
        assert candidate('2981', '9889755') == '1101'
        assert candidate('3', '6') == '1'
        assert candidate('80747', '92881900875') == '11111'
        assert candidate('4', '6') == '1'
        assert candidate('5', '5') == '0'
        assert candidate('219748', '214571') == '001111'
        assert candidate('27159', '558123715') == '11111'
        assert candidate('65556467', '402342810') == '11111111'
        assert candidate('475556220', '9713') == '1011'
        assert candidate('525', '466409050') == '111'
        assert candidate('963723613', '61310046') == '11011111'
        assert candidate('341196', '68732979') == '111111'
        assert candidate('242706', '5764123') == '111111'
        assert candidate('4773', '6421') == '1111'
        assert candidate('8', '7') == '1'
        assert candidate('7', '1') == '1'
        assert candidate('8376875', '71354') == '11111'
        assert candidate('8', '6') == '1'
        assert candidate('308666', '1276408') == '111011'
        assert candidate('821475', '500530947158') == '111111'
        assert candidate('6', '3') == '1'
        assert candidate('920098', '233') == '111'
        assert candidate('6', '8') == '1'
        assert candidate('155', '668') == '111'
        assert candidate('57986', '889283') == '11011'
        assert candidate('6871809', '969729928') == '1111110'
        assert candidate('586252954', '887') == '101'
        assert candidate('3220495', '674784') == '111111'
        assert candidate('8', '5') == '1'
        assert candidate('502', '8992') == '111'
        assert candidate('009', '24212066790') == '111'
        assert candidate('68692', '9172861308') == '11111'
        assert candidate('065', '74271') == '111'
        assert candidate('7452630', '007') == '111'
        assert candidate('8949369', '71815551543') == '1111111'
        assert candidate('061320025', '0614320') == '0001110'
        assert candidate('688788780', '095726163') == '111011111'
        assert candidate('24156285', '30566576223') == '11110111'
        assert candidate('90100457', '5308') == '1111'
        assert candidate('7', '6') == '1'
        assert candidate('42050340', '79670144') == '11110101'
        assert candidate('32623710', '611798') == '111111'
        assert candidate('6', '6') == '0'
        assert candidate('30420', '432199542') == '11111'
        assert candidate('8056450', '074') == '111'
        assert candidate('3477', '68716') == '1101'
        assert candidate('3', '8') == '1'
        assert candidate('1', '1') == '0'
        assert candidate('7', '7') == '0'
        assert candidate('9', '3') == '1'

if __name__ == '__main__':
    unittest.main()
