
import unittest



def incr_list(l: list):
    """Return list with elements incremented by 1.

    >>> incr_list([1, 2, 3])
    [2, 3, 4]
    >>> incr_list([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [6, 4, 6, 3, 4, 4, 10, 1, 124]
    """
    if not isinstance(l, list):
        raise TypeError(f"Expected list, got {type(l).__name__}")

    result = []
    for i, item in enumerate(l):
        if not isinstance(item, (int, float)):
            raise TypeError(
                f"Element at index {i} must be a number, got {type(item).__name__}"
            )
        result.append(item + 1)

    return result
candidate = incr_list


class Test(unittest.TestCase):
    def test(self):
        assert candidate([3, 7, 3]) == [4, 8, 4]
        assert candidate([8, 1, 10, 4, 7, 2, 11, 3, 122]) == [9, 2, 11, 5, 8, 3, 12, 4, 123]
        assert candidate([10, 6, 7, 2, 5, 4, 14, 1, 125]) == [11, 7, 8, 3, 6, 5, 15, 2, 126]
        assert candidate([6, 7, 6]) == [7, 8, 7]
        assert candidate([9, 7, 8, 4, 6, 8, 13, 5, 119]) == [10, 8, 9, 5, 7, 9, 14, 6, 120]
        assert candidate([7, 6, 3]) == [8, 7, 4]
        assert candidate([2, 6, 6]) == [3, 7, 7]
        assert candidate([6, 7, 8, 4, 3, 1, 9, 3, 121]) == [7, 8, 9, 5, 4, 2, 10, 4, 122]
        assert candidate([6, 3, 4, 2, 1, 7, 7, 1, 123]) == [7, 4, 5, 3, 2, 8, 8, 2, 124]
        assert candidate([9, 1, 7, 1, 7, 5, 7, 1, 119]) == [10, 2, 8, 2, 8, 6, 8, 2, 120]
        assert candidate([4, 4, 2, 6, 5, 6, 9, 4, 122]) == [5, 5, 3, 7, 6, 7, 10, 5, 123]
        assert candidate([8, 4, 6]) == [9, 5, 7]
        assert candidate([1, 2, 6, 7, 8, 8, 6, 2, 125]) == [2, 3, 7, 8, 9, 9, 7, 3, 126]
        assert candidate([6, 7, 1]) == [7, 8, 2]
        assert candidate([9, 7, 3, 4, 8, 3, 13, 5, 124]) == [10, 8, 4, 5, 9, 4, 14, 6, 125]
        assert candidate([7, 1, 6, 7, 1, 5, 7, 1, 120]) == [8, 2, 7, 8, 2, 6, 8, 2, 121]
        assert candidate([8, 6, 5]) == [9, 7, 6]
        assert candidate([3, 3, 1]) == [4, 4, 2]
        assert candidate([]) == []
        assert candidate([4, 7, 6]) == [5, 8, 7]
        assert candidate([4, 5, 2]) == [5, 6, 3]
        assert candidate([3, 3, 1, 2, 4, 7, 14, 1, 124]) == [4, 4, 2, 3, 5, 8, 15, 2, 125]
        assert candidate([3, 4, 8, 7, 6, 7, 11, 3, 123]) == [4, 5, 9, 8, 7, 8, 12, 4, 124]
        assert candidate([1, 3, 9, 3, 7, 1, 11, 4, 128]) == [2, 4, 10, 4, 8, 2, 12, 5, 129]
        assert candidate([8, 7, 1]) == [9, 8, 2]
        assert candidate([10, 5, 6, 6, 7, 1, 6, 1, 125]) == [11, 6, 7, 7, 8, 2, 7, 2, 126]
        assert candidate([6, 5, 3]) == [7, 6, 4]
        assert candidate([1, 5, 8, 5, 1, 4, 4, 2, 126]) == [2, 6, 9, 6, 2, 5, 5, 3, 127]
        assert candidate([7, 6, 4, 2, 1, 1, 14, 2, 124]) == [8, 7, 5, 3, 2, 2, 15, 3, 125]
        assert candidate([8, 1, 5]) == [9, 2, 6]
        assert candidate([8, 3, 4, 2, 8, 7, 12, 5, 121]) == [9, 4, 5, 3, 9, 8, 13, 6, 122]
        assert candidate([8, 3, 5]) == [9, 4, 6]
        assert candidate([7, 1, 8, 3, 8, 2, 6, 4, 123]) == [8, 2, 9, 4, 9, 3, 7, 5, 124]
        assert candidate([3, 7, 5]) == [4, 8, 6]
        assert candidate([3, 1, 8, 5, 5, 3, 5, 4, 124]) == [4, 2, 9, 6, 6, 4, 6, 5, 125]
        assert candidate([2, 2, 10, 1, 5, 3, 4, 5, 120]) == [3, 3, 11, 2, 6, 4, 5, 6, 121]
        assert candidate([6, 4, 6]) == [7, 5, 7]
        assert candidate([5, 7, 3, 1, 7, 3, 7, 5, 125]) == [6, 8, 4, 2, 8, 4, 8, 6, 126]
        assert candidate([7, 2, 2, 6, 8, 2, 10, 2, 127]) == [8, 3, 3, 7, 9, 3, 11, 3, 128]
        assert candidate([7, 1, 1, 7, 5, 1, 9, 1, 119]) == [8, 2, 2, 8, 6, 2, 10, 2, 120]
        assert candidate([6, 7, 4]) == [7, 8, 5]
        assert candidate([5, 1, 6]) == [6, 2, 7]
        assert candidate([8, 7, 6]) == [9, 8, 7]
        assert candidate([2, 3, 10, 2, 6, 7, 8, 3, 122]) == [3, 4, 11, 3, 7, 8, 9, 4, 123]
        assert candidate([1, 5, 3, 4, 6, 3, 8, 1, 120]) == [2, 6, 4, 5, 7, 4, 9, 2, 121]
        assert candidate([10, 5, 9, 5, 3, 2, 4, 1, 122]) == [11, 6, 10, 6, 4, 3, 5, 2, 123]
        assert candidate([9, 6, 6, 3, 5, 4, 11, 1, 123]) == [10, 7, 7, 4, 6, 5, 12, 2, 124]
        assert candidate([5, 1, 5]) == [6, 2, 6]
        assert candidate([4, 4, 6]) == [5, 5, 7]
        assert candidate([3, 2, 1]) == [4, 3, 2]
        assert candidate([3, 1, 5]) == [4, 2, 6]
        assert candidate([10, 6, 6, 5, 4, 3, 4, 5, 128]) == [11, 7, 7, 6, 5, 4, 5, 6, 129]
        assert candidate([6, 3, 8, 1, 5, 6, 5, 5, 119]) == [7, 4, 9, 2, 6, 7, 6, 6, 120]
        assert candidate([6, 6, 6]) == [7, 7, 7]
        assert candidate([7, 2, 1]) == [8, 3, 2]
        assert candidate([10, 6, 9, 3, 5, 8, 7, 5, 126]) == [11, 7, 10, 4, 6, 9, 8, 6, 127]
        assert candidate([4, 7, 1]) == [5, 8, 2]
        assert candidate([8, 3, 4]) == [9, 4, 5]
        assert candidate([5, 4, 1]) == [6, 5, 2]
        assert candidate([6, 4, 2, 7, 8, 8, 9, 1, 124]) == [7, 5, 3, 8, 9, 9, 10, 2, 125]
        assert candidate([4, 2, 2]) == [5, 3, 3]
        assert candidate([4, 6, 6]) == [5, 7, 7]
        assert candidate([4, 7, 9, 2, 8, 6, 9, 2, 127]) == [5, 8, 10, 3, 9, 7, 10, 3, 128]
        assert candidate([5, 5, 4]) == [6, 6, 5]
        assert candidate([5, 2, 5, 2, 3, 3, 9, 0, 123]) == [6, 3, 6, 3, 4, 4, 10, 1, 124]
        assert candidate([3, 2, 6]) == [4, 3, 7]
        assert candidate([7, 5, 1]) == [8, 6, 2]
        assert candidate([4, 4, 3]) == [5, 5, 4]
        assert candidate([4, 5, 1]) == [5, 6, 2]
        assert candidate([3, 6, 6, 6, 5, 4, 9, 5, 125]) == [4, 7, 7, 7, 6, 5, 10, 6, 126]
        assert candidate([9, 6, 10, 2, 4, 2, 12, 1, 120]) == [10, 7, 11, 3, 5, 3, 13, 2, 121]
        assert candidate([8, 4, 3]) == [9, 5, 4]
        assert candidate([7, 6, 9, 3, 8, 3, 13, 4, 119]) == [8, 7, 10, 4, 9, 4, 14, 5, 120]
        assert candidate([8, 1, 4]) == [9, 2, 5]
        assert candidate([9, 2, 1, 1, 7, 6, 13, 5, 125]) == [10, 3, 2, 2, 8, 7, 14, 6, 126]
        assert candidate([5, 3, 10, 2, 3, 5, 7, 2, 118]) == [6, 4, 11, 3, 4, 6, 8, 3, 119]
        assert candidate([1, 2, 2, 7, 2, 3, 10, 3, 122]) == [2, 3, 3, 8, 3, 4, 11, 4, 123]
        assert candidate([3, 1, 3]) == [4, 2, 4]
        assert candidate([7, 4, 3, 5, 3, 3, 5, 2, 126]) == [8, 5, 4, 6, 4, 4, 6, 3, 127]
        assert candidate([2, 5, 5, 3, 3, 4, 5, 4, 119]) == [3, 6, 6, 4, 4, 5, 6, 5, 120]
        assert candidate([2, 4, 1, 7, 2, 6, 8, 4, 127]) == [3, 5, 2, 8, 3, 7, 9, 5, 128]
        assert candidate([3, 6, 6]) == [4, 7, 7]
        assert candidate([4, 7, 2]) == [5, 8, 3]
        assert candidate([7, 5, 3, 2, 7, 7, 12, 2, 118]) == [8, 6, 4, 3, 8, 8, 13, 3, 119]
        assert candidate([7, 2, 5]) == [8, 3, 6]

if __name__ == '__main__':
    unittest.main()
