
import unittest



def correct_bracketing(brackets: str) -> bool:
    """brackets is a string of "(" and ")".
    Return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("(")
    False
    >>> correct_bracketing("()")
    True
    >>> correct_bracketing("(()())")
    True
    >>> correct_bracketing(")(()")
    False
    """
    if not isinstance(brackets, str):
        raise TypeError("brackets must be a string")

    invalid_chars = set(brackets) - {"(", ")"}
    if invalid_chars:
        raise ValueError(
            f"brackets must contain only '(' and ')'; found: {sorted(invalid_chars)}"
        )

    balance = 0
    for ch in brackets:
        if ch == "(":
            balance += 1
        elif ch == ")":
            balance -= 1

        if balance < 0:
            return False

    return balance == 0
candidate = correct_bracketing


class Test(unittest.TestCase):
    def test(self):
        assert candidate("(") == False
        assert candidate("))()))((())((()()((((") == False
        assert candidate(")((((((()())())()(((") == False
        assert candidate(")((())))()(()))())") == False
        assert not candidate("(()")
        assert candidate("(()())") == True
        assert candidate("(()())()()((()()())())(()()(()))()") == True
        assert candidate("()))") == False
        assert not candidate(")")
        assert candidate("()()") == True
        assert candidate(")())()())))(((") == False
        assert candidate("))((((((()") == False
        assert candidate(")((((") == False
        assert candidate("()(()())") == True
        assert candidate("(()())()()((()()())())(()()(()))") == True
        assert candidate("((())()))") == False
        assert candidate("()()()(())(") == False
        assert candidate("))())") == False
        assert candidate("()()(()())()")
        assert candidate("()()(()())()") == True
        assert candidate(")") == False
        assert candidate("()()()") == True
        assert candidate("()))()(") == False
        assert candidate("(())") == True
        assert candidate("()()(()())()()()(()())()") == True
        assert candidate("()()(()())()()()(()())()()()((()()())())(()()(()))") == True
        assert candidate("(()())()(()())") == True
        assert candidate("(()))))()") == False
        assert candidate(")(()())(") == False
        assert candidate("((((") == False
        assert candidate("(()())")
        assert candidate("(((()") == False
        assert candidate("))()") == False
        assert candidate(")))((") == False
        assert candidate(")()())") == False
        assert candidate("(()") == False
        assert candidate("(()())(()())()") == True
        assert candidate("(()())()()(()())()") == True
        assert candidate("()()(()())()(()())()") == True
        assert not candidate("((((")
        assert candidate("))))") == False
        assert candidate("()") == True
        assert candidate("())") == False
        assert candidate(")()(())()((()())") == False
        assert candidate("))()))))(()()(") == False
        assert candidate("()())())(") == False
        assert candidate("()()()()(()())()") == True
        assert candidate(")()(") == False
        assert candidate("((((((") == False
        assert candidate("()()()((()()(") == False
        assert candidate("()()((()()())())(()()(()))()()(()())()()") == True
        assert not candidate("((()())))")
        assert candidate("()")
        assert not candidate("(")
        assert candidate("())())((()()))") == False
        assert candidate("(()())()") == True
        assert candidate(")(()))(((()((()") == False
        assert candidate("()))))") == False
        assert candidate("))())()))(())") == False
        assert candidate(")())())()") == False
        assert candidate(")((()))))((()(") == False
        assert candidate("()())())))(()(())()") == False
        assert candidate(")((((((") == False
        assert not candidate(")(()")
        assert candidate("((())()()") == False
        assert not candidate("()()(()())()))()")
        assert candidate(")(()(())((())((())") == False
        assert candidate(")(()") == False
        assert candidate(")()") == False
        assert candidate("()()(()())()()()((()()())())(()()(()))(()())") == True
        assert candidate("()()(()())()()") == True
        assert candidate("(()())()()((()()())())(()()(()))(()())") == True
        assert candidate("()()((()()())())(()()(()))")
        assert candidate("(((") == False
        assert candidate("") == True
        assert not candidate("()()(()())())(()")
        assert candidate("()(())()()()") == True
        assert candidate(")()()(()(())(") == False
        assert candidate("))()()())(())") == False

if __name__ == '__main__':
    unittest.main()
