
import unittest


def starts_one_ends(n: int) -> int:
    """
    Return the number of n-digit positive integers that start or end with 1.

    Uses inclusion-exclusion:
    - Start with 1: 10^(n-1)
    - End with 1:   10^(n-1)
    - Both:         10^(n-2)  (for n > 1)

    Therefore:
        count = 2 * 10^(n-1) - 10^(n-2)   for n > 1
        count = 1                          for n == 1

    Args:
        n: Number of digits. Must be a positive integer.

    Returns:
        The count of n-digit positive integers that start or end with 1.

    Raises:
        ValueError: If n is not a positive integer.
    """
    if not isinstance(n, int) or n <= 0:
        raise ValueError("n must be a positive integer")

    if n == 1:
        return 1

    return 2 * (10 ** (n - 1)) - (10 ** (n - 2))
candidate = starts_one_ends


class Test(unittest.TestCase):
    def test(self):
        assert candidate(12) == 180000000000
        assert candidate(2) == 18
        assert candidate(14) == 18000000000000
        assert candidate(3) == 180
        assert candidate(19) == 1800000000000000000
        assert candidate(1) == 1
        assert candidate(8) == 18000000
        assert candidate(13) == 1800000000000
        assert candidate(16) == 1800000000000000
        assert candidate(11) == 18000000000
        assert candidate(17) == 18000000000000000
        assert candidate(4) == 1800
        assert candidate(20) == 18000000000000000000
        assert candidate(9) == 180000000
        assert candidate(6) == 180000
        assert candidate(15) == 180000000000000
        assert candidate(5) == 18000
        assert candidate(18) == 180000000000000000
        assert candidate(5) == 18000

    # Check some edge cases that are easy to work out by hand.
        assert candidate(7) == 1800000
        assert candidate(10) == 1800000000

if __name__ == '__main__':
    unittest.main()
