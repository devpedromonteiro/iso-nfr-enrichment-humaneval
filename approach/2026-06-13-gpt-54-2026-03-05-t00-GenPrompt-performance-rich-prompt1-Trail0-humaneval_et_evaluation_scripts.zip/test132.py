
import unittest


def is_nested(string):
    """
    Return True iff the bracket string contains a valid bracket subsequence
    with nesting depth at least 2.

    Since the input contains only '[' and ']', this is equivalent to checking
    whether some prefix can reach depth 2 while scanning left to right.

    Examples:
    is_nested('[[]]') -> True
    is_nested('[]]]]]]][[[[[]') -> False
    is_nested('[][]') -> False
    is_nested('[]') -> False
    is_nested('[[][]]') -> True
    is_nested('[[]][[') -> True
    """
    depth = 0

    for ch in string:
        if ch == '[':
            depth += 1
            if depth >= 2:
                return True
        elif depth > 0:
            depth -= 1

    return False
candidate = is_nested


class Test(unittest.TestCase):
    def test(self):
        assert candidate('[[]') == False
        assert candidate("[]]]][[]") == False
        assert candidate('[]]]]]]][[[[[]') == False
        assert candidate("][[[[]]") == True
        assert candidate("[][[][][") == True
        assert candidate(('[]')) == False
        assert candidate("[][][[[[[]]") == True
        assert candidate('[[]][[') == True
        assert candidate("][][[") == False
        assert candidate('') == False
        assert candidate("[]][") == False
        assert candidate("][][][]]]") == True
        assert candidate("]][[[[][][]") == True
        assert candidate("[[[]][][[") == True
        assert candidate("b") == False
        assert candidate("][][][]") == True
        assert candidate("[[[][]]][") == True
        assert candidate("][]]]]]]]") == False
        assert candidate("[][[[]") == False
        assert candidate("]][][]]") == True
        assert candidate('[][][[]]') == True
        assert candidate("[]]][[[") == False
        assert candidate("[]][[[[]]") == True
        assert candidate("][][[][]") == True
        assert candidate("[][[]") == False
        assert candidate('[[[[[[[[') == False
        assert candidate("]]]]][][]][[[]") == True
        assert candidate("][[]]") == True
        assert candidate("][]]][][[][]") == True
        assert candidate("]]]][[]][") == True
        assert candidate("][[][]") == True
        assert candidate('[[]]') == True
        assert candidate("[]]]][") == False
        assert candidate("gv") == False
        assert candidate("[[[[][[[") == False
        assert candidate("]][][][]]") == True
        assert candidate("]]]][][]]]]") == True
        assert candidate("][]]]][[]]") == True
        assert candidate("][[[") == False
        assert candidate("][[[]]]") == True
        assert candidate("[[][]") == True
        assert candidate("][[[]") == False
        assert candidate("][]][]") == False
        assert candidate("]]][") == False
        assert candidate("[[[[]]][[[[]") == True
        assert candidate("ol") == False
        assert candidate("][[][][[") == True
        assert candidate("][[]]]") == True
        assert candidate("]][[") == False
        assert candidate("][]]") == False
        assert candidate("][][]][[[") == True
        assert candidate("ljv") == False
        assert candidate('[[[[]]]]') == True
        assert candidate("]]][[") == False
        assert candidate("[]]]]") == False
        assert candidate("][[]") == False
        assert candidate("][]]]]") == False
        assert candidate("]][[]]]][[][") == True
        assert candidate("][[][[]") == True
        assert candidate("[[[[[][][[") == True
        assert candidate("][]][][") == False
        assert candidate("adx") == False
        assert candidate("][]][") == False
        assert candidate("[[]][][]]") == True
        assert candidate("[][[[]][]]]") == True
        assert candidate("][[[]][") == True
        assert candidate("]]]") == False
        assert candidate("][[]]][][]][") == True
        assert candidate("[[]]]") == True
        assert candidate("uh") == False
        assert candidate("]][]][[][") == False
        assert candidate("]]]]]][]") == False
        assert candidate("]]]]]") == False
        assert candidate(']]]]]]]]') == False
        assert candidate("[]]][[]][") == True
        assert candidate("[[][]]]]") == True
        assert candidate("[]][][[]]") == True
        assert candidate("][]]][][]]") == True
        assert candidate("[]]][[[[[]") == False
        assert candidate("]]]]]][[[") == False
        assert candidate("]]][[][[[") == False
        assert candidate("]]][]]]]][[[][[") == False
        assert candidate("[[[[][") == False
        assert candidate("[][]][[[]][[[][") == True
        assert candidate("[[[]]]") == True
        assert candidate("]][]][]]][") == True
        assert candidate("[[][][]") == True
        assert candidate('[][]') == False
        assert candidate("]][") == False
        assert candidate("[]][[]]]") == True
        assert candidate("[][]]") == True
        assert candidate("][[") == False
        assert candidate("]][][[") == False
        assert candidate("]]][[]][][]][[][]]") == True
        assert candidate("]][[[[") == False
        assert candidate("]]][][[[[][]]") == True
        assert candidate("][[]][[[[") == True
        assert candidate("c") == False
        assert candidate("]][[]]") == True
        assert candidate("[]][][][]") == True
        assert candidate("][]][[[") == False
        assert candidate("[]]]][[]]][][]") == True
        assert candidate("]]]][[[[") == False
        assert candidate("[[[[[[[[][]]") == True
        assert candidate("[][][[") == False
        assert candidate("][[][[[[") == False
        assert candidate("]]]][]") == False
        assert candidate("]][[[][][[[") == True
        assert candidate("[[[[[[") == False
        assert candidate("[][[") == False
        assert candidate('[]]]]]]]]]]') == False
        assert candidate('[[][]]') == True

    # Check some edge cases that are easy to work out by hand.
        assert candidate("[][[][]]]]") == True
        assert candidate('[]]') == False
        assert candidate("][]]][[") == False
        assert candidate("[][[][[][") == True
        assert candidate("[]][[") == False
        assert candidate("[][]][]][") == True
        assert candidate("[[]][[") == True
        assert candidate("[[[[]]][[[[[") == True
        assert candidate("uz") == False
        assert candidate("]][]]]]") == False
        assert candidate("[[[]][][][]") == True
        assert candidate("]]][[]][[") == True
        assert candidate("[]][]") == False
        assert candidate("[][][[[[[][") == True
        assert candidate("h") == False
        assert candidate("[]]]]][[]") == False

if __name__ == '__main__':
    unittest.main()
