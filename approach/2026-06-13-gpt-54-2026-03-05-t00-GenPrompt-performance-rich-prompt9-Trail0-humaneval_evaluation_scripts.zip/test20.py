
import unittest
import re
import sys
import math
import copy

from typing import List, Tuple


from typing import List, Tuple


def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    """From a supplied list of numbers (of length at least two) select and return
    two that are the closest to each other and return them in order
    (smaller number, larger number).

    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.2])
    (2.0, 2.2)
    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.0])
    (2.0, 2.0)
    """
    sorted_numbers = sorted(numbers)
    best_a = sorted_numbers[0]
    best_b = sorted_numbers[1]
    min_diff = best_b - best_a

    if min_diff == 0:
        return best_a, best_b

    for i in range(1, len(sorted_numbers) - 1):
        a = sorted_numbers[i]
        b = sorted_numbers[i + 1]
        diff = b - a
        if diff < min_diff:
            min_diff = diff
            best_a = a
            best_b = b
            if diff == 0:
                return best_a, best_b

    return best_a, best_b
candidate = find_closest_elements




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([1.0, 2.0, 3.9, 4.0, 5.0, 2.2]) == (3.9, 4.0)
    assert candidate([1.0, 2.0, 5.9, 4.0, 5.0]) == (5.0, 5.9)
    assert candidate([1.0, 2.0, 3.0, 4.0, 5.0, 2.2]) == (2.0, 2.2)
    assert candidate([1.0, 2.0, 3.0, 4.0, 5.0, 2.0]) == (2.0, 2.0)
    assert candidate([1.1, 2.2, 3.1, 4.1, 5.1]) == (2.2, 3.1)



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
