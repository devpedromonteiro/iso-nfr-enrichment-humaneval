
import unittest
import re
import sys
import math
import copy


def compare_one(a, b):
    def to_number(x):
        if isinstance(x, str):
            return float(x.replace(',', '.'))
        return float(x)

    na = to_number(a)
    nb = to_number(b)

    if na > nb:
        return a
    if nb > na:
        return b
    return None
candidate = compare_one


def check(candidate):

    # Check some simple cases
    assert candidate(1, 2) == 2
    assert candidate(1, 2.5) == 2.5
    assert candidate(2, 3) == 3
    assert candidate(5, 6) == 6
    assert candidate(1, "2,3") == "2,3"
    assert candidate("5,1", "6") == "6"
    assert candidate("1", "2") == "2"
    assert candidate("1", 1) == None

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
