
import unittest
import re
import sys
import math
import copy



def prime_fib(n: int):
    """
    prime_fib returns n-th number that is a Fibonacci number and it's also prime.
    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """
    if n < 1:
        raise ValueError("n must be >= 1")

    def is_prime(x: int) -> bool:
        if x < 2:
            return False
        if x == 2:
            return True
        if x % 2 == 0:
            return False
        i = 3
        while i * i <= x:
            if x % i == 0:
                return False
            i += 2
        return True

    # Fibonacci sequence: 0, 1, 1, 2, 3, 5, 8, ...
    # All prime Fibonacci numbers (except 2 and 3) occur at prime indices,
    # so we only test Fibonacci numbers at prime indices after handling 2 and 3.
    if n == 1:
        return 2
    if n == 2:
        return 3

    count = 2
    a, b = 1, 1   # F1, F2
    index = 2

    while True:
        a, b = b, a + b
        index += 1  # b is now F_index

        if index % 2 == 0:
            continue

        if is_prime(index) and is_prime(b):
            count += 1
            if count == n:
                return b
candidate = prime_fib




METADATA = {}


def check(candidate):
    assert candidate(1) == 2
    assert candidate(2) == 3
    assert candidate(3) == 5
    assert candidate(4) == 13
    assert candidate(5) == 89
    assert candidate(6) == 233
    assert candidate(7) == 1597
    assert candidate(8) == 28657
    assert candidate(9) == 514229
    assert candidate(10) == 433494437



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
