
import unittest
import re
import sys
import math
import copy


def valid_date(date):
    """Validate a date string in mm-dd-yyyy format."""
    if not date or len(date) != 10:
        return False

    # Fast fixed-format checks: mm-dd-yyyy
    if date[2] != '-' or date[5] != '-':
        return False

    m1, m2 = date[0], date[1]
    d1, d2 = date[3], date[4]
    y1, y2, y3, y4 = date[6], date[7], date[8], date[9]

    # Avoid split/regex; validate digits directly
    if not ('0' <= m1 <= '9' and '0' <= m2 <= '9' and
            '0' <= d1 <= '9' and '0' <= d2 <= '9' and
            '0' <= y1 <= '9' and '0' <= y2 <= '9' and
            '0' <= y3 <= '9' and '0' <= y4 <= '9'):
        return False

    month = (ord(m1) - 48) * 10 + (ord(m2) - 48)
    day = (ord(d1) - 48) * 10 + (ord(d2) - 48)

    if month < 1 or month > 12:
        return False

    if day < 1:
        return False

    # Max day by month, with February capped at 29 per requirements
    if month == 2:
        return day <= 29
    if month == 4 or month == 6 or month == 9 or month == 11:
        return day <= 30
    return day <= 31
candidate = valid_date


def check(candidate):

    # Check some simple cases
    assert candidate('03-11-2000') == True

    assert candidate('15-01-2012') == False

    assert candidate('04-0-2040') == False

    assert candidate('06-04-2020') == True

    assert candidate('01-01-2007') == True

    assert candidate('03-32-2011') == False

    assert candidate('') == False

    assert candidate('04-31-3000') == False

    assert candidate('06-06-2005') == True

    assert candidate('21-31-2000') == False

    assert candidate('04-12-2003') == True

    assert candidate('04122003') == False

    assert candidate('20030412') == False

    assert candidate('2003-04') == False

    assert candidate('2003-04-12') == False

    assert candidate('04-2003') == False


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
