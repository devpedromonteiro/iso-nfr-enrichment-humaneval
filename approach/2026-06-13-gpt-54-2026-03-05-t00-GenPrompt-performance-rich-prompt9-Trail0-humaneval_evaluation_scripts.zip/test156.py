
import unittest
import re
import sys
import math
import copy


def int_to_mini_roman(number):
    """
    Given a positive integer, obtain its roman numeral equivalent as a string,
    and return it in lowercase.
    Restrictions: 1 <= num <= 1000

    Examples:
    >>> int_to_mini_roman(19) == 'xix'
    True
    >>> int_to_mini_roman(152) == 'clii'
    True
    >>> int_to_mini_roman(426) == 'cdxxvi'
    True
    """
    if not 1 <= number <= 1000:
        raise ValueError("number must be between 1 and 1000")

    thousands = ("", "m")
    hundreds = ("", "c", "cc", "ccc", "cd", "d", "dc", "dcc", "dccc", "cm")
    tens = ("", "x", "xx", "xxx", "xl", "l", "lx", "lxx", "lxxx", "xc")
    ones = ("", "i", "ii", "iii", "iv", "v", "vi", "vii", "viii", "ix")

    return (
        thousands[number // 1000] +
        hundreds[(number % 1000) // 100] +
        tens[(number % 100) // 10] +
        ones[number % 10]
    )
candidate = int_to_mini_roman


def check(candidate):

    # Check some simple cases
    assert candidate(19) == 'xix'
    assert candidate(152) == 'clii'
    assert candidate(251) == 'ccli'
    assert candidate(426) == 'cdxxvi'
    assert candidate(500) == 'd'
    assert candidate(1) == 'i'
    assert candidate(4) == 'iv'
    assert candidate(43) == 'xliii'
    assert candidate(90) == 'xc'
    assert candidate(94) == 'xciv'
    assert candidate(532) == 'dxxxii'
    assert candidate(900) == 'cm'
    assert candidate(994) == 'cmxciv'
    assert candidate(1000) == 'm'

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
