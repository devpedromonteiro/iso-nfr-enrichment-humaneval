
import unittest
import re
import sys
import math
import copy



def encode_shift(s: str):
    """
    returns encoded string by shifting every character by 5 in the alphabet.
    """
    return "".join([chr(((ord(ch) + 5 - ord("a")) % 26) + ord("a")) for ch in s])


SHIFT_AMOUNT = 5
ALPHABET_START = ord("a")
ALPHABET_SIZE = 26


def _shift_char(ch: str, shift: int) -> str:
    """
    Shift a single lowercase alphabetic character by the given amount.
    """
    return chr(((ord(ch) - ALPHABET_START + shift) % ALPHABET_SIZE) + ALPHABET_START)


def _shift_text(s: str, shift: int) -> str:
    """
    Shift every character in the string by the given amount.
    """
    return "".join(_shift_char(ch, shift) for ch in s)


def encode_shift(s: str) -> str:
    """
    Return an encoded string by shifting every character by 5 in the alphabet.
    """
    return _shift_text(s, SHIFT_AMOUNT)


def decode_shift(s: str) -> str:
    """
    Take as input a string encoded with encode_shift and return the decoded string.
    """
    return _shift_text(s, -SHIFT_AMOUNT)
candidate = decode_shift




METADATA = {}


def check(candidate):
    from random import randint, choice
    import copy
    import string

    letters = string.ascii_lowercase
    for _ in range(100):
        str = ''.join(choice(letters) for i in range(randint(10, 20)))
        encoded_str = encode_shift(str)
        assert candidate(copy.deepcopy(encoded_str)) == str



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
