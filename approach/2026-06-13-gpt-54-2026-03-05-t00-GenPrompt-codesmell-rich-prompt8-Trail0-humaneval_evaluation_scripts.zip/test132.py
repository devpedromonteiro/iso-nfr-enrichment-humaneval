
import unittest
import re
import sys
import math
import copy


def is_nested(string):
    """
    Return True if the string contains a valid bracket subsequence
    with at least one nested pair of square brackets.
    """

    balance = 0
    has_outer_open = False

    for char in string:
        if char == '[':
            if balance >= 1:
                has_outer_open = True
            balance += 1
        elif char == ']':
            if balance >= 2 and has_outer_open:
                return True
            if balance > 0:
                balance -= 1

    return False
candidate = is_nested


def check(candidate):

    # Check some simple cases
    assert candidate('[[]]') == True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('[]]]]]]][[[[[]') == False
    assert candidate('[][]') == False
    assert candidate(('[]')) == False
    assert candidate('[[[[]]]]') == True
    assert candidate('[]]]]]]]]]]') == False
    assert candidate('[][][[]]') == True
    assert candidate('[[]') == False
    assert candidate('[]]') == False
    assert candidate('[[]][[') == True
    assert candidate('[[][]]') == True

    # Check some edge cases that are easy to work out by hand.
    assert candidate('') == False, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate('[[[[[[[[') == False
    assert candidate(']]]]]]]]') == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
