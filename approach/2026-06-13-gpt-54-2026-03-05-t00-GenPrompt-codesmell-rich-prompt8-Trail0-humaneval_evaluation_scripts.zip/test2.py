
import unittest
import re
import sys
import math
import copy



import math


def _validate_number(number: float) -> None:
    """Validate the input according to the function contract."""
    if number < 0:
        raise ValueError("number must be positive")


def _integer_part(number: float) -> int:
    """Return the largest integer smaller than or equal to the number."""
    return math.floor(number)


def truncate_number(number: float) -> float:
    """Given a positive floating point number, return its decimal part.

    The decimal part is the leftover after removing the integer part.

    >>> truncate_number(3.5)
    0.5
    """
    _validate_number(number)
    return number - _integer_part(number)
candidate = truncate_number




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(3.5) == 0.5
    assert abs(candidate(1.33) - 0.33) < 1e-6
    assert abs(candidate(123.456) - 0.456) < 1e-6


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
