
import unittest
import re
import sys
import math
import copy



def _normalize_pair(a: int, b: int) -> tuple[int, int]:
    """Return non-negative values suitable for GCD calculation."""
    return abs(a), abs(b)


def _euclidean_gcd(a: int, b: int) -> int:
    """Compute GCD using the Euclidean algorithm."""
    while b != 0:
        a, b = b, a % b
    return a


def greatest_common_divisor(a: int, b: int) -> int:
    """Return the greatest common divisor of two integers a and b.

    >>> greatest_common_divisor(3, 5)
    1
    >>> greatest_common_divisor(25, 15)
    5
    """
    normalized_a, normalized_b = _normalize_pair(a, b)
    return _euclidean_gcd(normalized_a, normalized_b)
candidate = greatest_common_divisor




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(3, 7) == 1
    assert candidate(10, 15) == 5
    assert candidate(49, 14) == 7
    assert candidate(144, 60) == 12


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
