
import unittest
import re
import sys
import math
import copy


def _distinct_sorted_values(values):
    """Return the sorted distinct values from the input list."""
    return sorted(set(values))


def _second_item(values):
    """Return the second item from a sequence, or None if it does not exist."""
    return values[1] if len(values) > 1 else None


def next_smallest(lst):
    """
    Return the 2nd smallest distinct element of the list.
    Return None if there is no such element.
    """
    distinct_values = _distinct_sorted_values(lst)
    return _second_item(distinct_values)
candidate = next_smallest


def check(candidate):

    # Check some simple cases
    assert candidate([1, 2, 3, 4, 5]) == 2
    assert candidate([5, 1, 4, 3, 2]) == 2
    assert candidate([]) == None
    assert candidate([1, 1]) == None
    assert candidate([1,1,1,1,0]) == 1
    assert candidate([1, 0**0]) == None
    assert candidate([-35, 34, 12, -45]) == -35

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
