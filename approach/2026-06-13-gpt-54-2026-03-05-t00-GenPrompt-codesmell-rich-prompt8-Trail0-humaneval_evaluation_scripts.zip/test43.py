
import unittest
import re
import sys
import math
import copy



def _build_value_counts(values):
    """Return a frequency map for the given iterable of integers."""
    counts = {}
    for value in values:
        counts[value] = counts.get(value, 0) + 1
    return counts


def _has_zero_sum_pair(counts):
    """Return True if the frequency map contains two distinct elements summing to zero."""
    for value, count in counts.items():
        if value == 0:
            if count > 1:
                return True
            continue

        if -value in counts:
            return True

    return False


def pairs_sum_to_zero(l):
    """
    pairs_sum_to_zero takes a list of integers as an input.
    it returns True if there are two distinct elements in the list that
    sum to zero, and False otherwise.
    >>> pairs_sum_to_zero([1, 3, 5, 0])
    False
    >>> pairs_sum_to_zero([1, 3, -2, 1])
    False
    >>> pairs_sum_to_zero([1, 2, 3, 7])
    False
    >>> pairs_sum_to_zero([2, 4, -5, 3, 5, 7])
    True
    >>> pairs_sum_to_zero([1])
    False
    """
    counts = _build_value_counts(l)
    return _has_zero_sum_pair(counts)
candidate = pairs_sum_to_zero




METADATA = {}


def check(candidate):
    assert candidate([1, 3, 5, 0]) == False
    assert candidate([1, 3, -2, 1]) == False
    assert candidate([1, 2, 3, 7]) == False
    assert candidate([2, 4, -5, 3, 5, 7]) == True
    assert candidate([1]) == False

    assert candidate([-3, 9, -1, 3, 2, 30]) == True
    assert candidate([-3, 9, -1, 3, 2, 31]) == True
    assert candidate([-3, 9, -1, 4, 2, 30]) == False
    assert candidate([-3, 9, -1, 4, 2, 31]) == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
