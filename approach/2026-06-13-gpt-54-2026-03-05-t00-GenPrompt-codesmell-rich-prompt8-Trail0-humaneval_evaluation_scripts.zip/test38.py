
import unittest
import re
import sys
import math
import copy



def encode_cyclic(s: str):
    """
    returns encoded string by cycling groups of three characters.
    """
    # split string to groups. Each of length 3.
    groups = [s[(3 * i):min((3 * i + 3), len(s))] for i in range((len(s) + 2) // 3)]
    # cycle elements in each group. Unless group has fewer elements than 3.
    groups = [(group[1:] + group[0]) if len(group) == 3 else group for group in groups]
    return "".join(groups)


def _split_into_triplets(s: str) -> list[str]:
    """Split a string into consecutive groups of up to three characters."""
    return [s[i:i + 3] for i in range(0, len(s), 3)]


def _rotate_left_triplet(group: str) -> str:
    """Rotate a 3-character group left by one position."""
    return group[1:] + group[0] if len(group) == 3 else group


def _rotate_right_triplet(group: str) -> str:
    """Rotate a 3-character group right by one position."""
    return group[-1] + group[:-1] if len(group) == 3 else group


def _transform_cyclic(s: str, transformer) -> str:
    """Apply a group transformation to each triplet and join the result."""
    groups = _split_into_triplets(s)
    return "".join(transformer(group) for group in groups)


def encode_cyclic(s: str):
    """
    returns encoded string by cycling groups of three characters.
    """
    return _transform_cyclic(s, _rotate_left_triplet)


def decode_cyclic(s: str):
    """
    takes as input string encoded with encode_cyclic function. Returns decoded string.
    """
    return _transform_cyclic(s, _rotate_right_triplet)
candidate = decode_cyclic




METADATA = {}


def check(candidate):
    from random import randint, choice
    import string

    letters = string.ascii_lowercase
    for _ in range(100):
        str = ''.join(choice(letters) for i in range(randint(10, 20)))
        encoded_str = encode_cyclic(str)
        assert candidate(encoded_str) == str



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
