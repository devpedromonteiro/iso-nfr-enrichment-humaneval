
import unittest
import re
import sys
import math
import copy


DIGIT_NAMES = {
    1: "One",
    2: "Two",
    3: "Three",
    4: "Four",
    5: "Five",
    6: "Six",
    7: "Seven",
    8: "Eight",
    9: "Nine",
}


def _is_valid_digit(value):
    return value in DIGIT_NAMES


def _to_digit_name(value):
    return DIGIT_NAMES[value]


def by_length(arr):
    """
    Given an array of integers, sort the integers that are between 1 and 9 inclusive,
    reverse the resulting array, and then replace each digit by its corresponding name.

    Examples:
      [2, 1, 1, 4, 5, 8, 2, 3] -> ["Eight", "Five", "Four", "Three", "Two", "Two", "One", "One"]
      [] -> []
      [1, -1, 55] -> ["One"]
    """
    valid_digits = [value for value in arr if _is_valid_digit(value)]
    valid_digits.sort(reverse=True)
    return [_to_digit_name(value) for value in valid_digits]
candidate = by_length


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([2, 1, 1, 4, 5, 8, 2, 3]) == ["Eight", "Five", "Four", "Three", "Two", "Two", "One", "One"], "Error"
    assert candidate([]) == [], "Error"
    assert candidate([1, -1 , 55]) == ['One'], "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([1, -1, 3, 2]) == ["Three", "Two", "One"]
    assert candidate([9, 4, 8]) == ["Nine", "Eight", "Four"]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
