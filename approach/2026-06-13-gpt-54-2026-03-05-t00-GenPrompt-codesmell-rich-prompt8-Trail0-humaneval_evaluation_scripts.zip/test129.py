
import unittest
import re
import sys
import math
import copy


from functools import lru_cache


def minPath(grid, k):
    """
    Return the lexicographically smallest path of length k in the grid.
    """

    size = len(grid)
    positions = _build_value_positions(grid)
    best_start_value = _find_best_start_value(grid, positions, k, size)
    start_row, start_col = positions[best_start_value]

    return list(_best_path_from(start_row, start_col, k, grid, size))


def _build_value_positions(grid):
    positions = {}
    for row_index, row in enumerate(grid):
        for col_index, value in enumerate(row):
            positions[value] = (row_index, col_index)
    return positions


def _find_best_start_value(grid, positions, k, size):
    for value in range(1, size * size + 1):
        row, col = positions[value]
        if _can_build_path(row, col, k, grid, size):
            return value
    raise ValueError("No valid path found")


def _can_build_path(row, col, steps_remaining, grid, size):
    if steps_remaining == 1:
        return True

    for next_row, next_col in _neighbors(row, col, size):
        if _can_build_path(next_row, next_col, steps_remaining - 1, grid, size):
            return True
    return False


def _neighbors(row, col, size):
    if row > 0:
        yield row - 1, col
    if row < size - 1:
        yield row + 1, col
    if col > 0:
        yield row, col - 1
    if col < size - 1:
        yield row, col + 1


def _sorted_neighbors_by_value(row, col, grid, size):
    neighbors = list(_neighbors(row, col, size))
    neighbors.sort(key=lambda cell: grid[cell[0]][cell[1]])
    return neighbors


def _make_best_path_solver(grid, size):
    @lru_cache(maxsize=None)
    def solve(row, col, steps_remaining):
        current_value = grid[row][col]
        if steps_remaining == 1:
            return (current_value,)

        best_suffix = None
        for next_row, next_col in _sorted_neighbors_by_value(row, col, grid, size):
            candidate = solve(next_row, next_col, steps_remaining - 1)
            if best_suffix is None or candidate < best_suffix:
                best_suffix = candidate

        return (current_value,) + best_suffix

    return solve


def _best_path_from(row, col, k, grid, size):
    solver = _make_best_path_solver(grid, size)
    return solver(row, col, k)
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
