
import unittest
import re
import sys
import math
import copy


def _count_odds(values):
    """Return the number of odd values in the list."""
    return sum(1 for value in values if value % 2 != 0)


def _count_evens(values):
    """Return the number of even values in the list."""
    return sum(1 for value in values if value % 2 == 0)


def exchange(lst1, lst2):
    """Determine whether lst1 can be made entirely even by exchanging elements.

    Since any number of exchanges is allowed, the only thing that matters is
    whether there are enough even numbers across both lists to fill all
    positions in lst1.
    """
    required_even_count = len(lst1)
    available_even_count = _count_evens(lst1) + _count_evens(lst2)

    return "YES" if available_even_count >= required_even_count else "NO"
candidate = exchange


def check(candidate):

    # Check some simple cases
    assert candidate([1, 2, 3, 4], [1, 2, 3, 4]) == "YES"
    assert candidate([1, 2, 3, 4], [1, 5, 3, 4]) == "NO"
    assert candidate([1, 2, 3, 4], [2, 1, 4, 3]) == "YES" 
    assert candidate([5, 7, 3], [2, 6, 4]) == "YES"
    assert candidate([5, 7, 3], [2, 6, 3]) == "NO" 
    assert candidate([3, 2, 6, 1, 8, 9], [3, 5, 5, 1, 1, 1]) == "NO"

    # Check some edge cases that are easy to work out by hand.
    assert candidate([100, 200], [200, 200]) == "YES"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
