
import unittest
import re
import sys
import math
import copy



def _normalize_characters(text: str) -> str:
    """Return a case-insensitive representation of the input text."""
    return text.lower()


def _distinct_characters(text: str) -> set[str]:
    """Return the set of distinct characters in the given text."""
    return set(text)


def count_distinct_characters(string: str) -> int:
    """Given a string, return the number of distinct characters regardless of case.

    >>> count_distinct_characters('xyzXYZ')
    3
    >>> count_distinct_characters('Jerry')
    4
    """
    normalized = _normalize_characters(string)
    distinct = _distinct_characters(normalized)
    return len(distinct)
candidate = count_distinct_characters




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == 0
    assert candidate('abcde') == 5
    assert candidate('abcde' + 'cade' + 'CADE') == 5
    assert candidate('aaaaAAAAaaaa') == 1
    assert candidate('Jerry jERRY JeRRRY') == 5


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
