
import unittest
import re
import sys
import math
import copy



def _validate_index(n: int) -> None:
    """Validate the fibfib sequence index."""
    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if n < 0:
        raise ValueError("n must be non-negative")


def _fibfib_base_case(n: int):
    """Return the base-case value for n, or None if not a base case."""
    base_cases = {0: 0, 1: 0, 2: 1}
    return base_cases.get(n)


def fibfib(n: int):
    """Compute the n-th FibFib number efficiently.

    The FibFib sequence is defined as:
    - fibfib(0) = 0
    - fibfib(1) = 0
    - fibfib(2) = 1
    - fibfib(n) = fibfib(n-1) + fibfib(n-2) + fibfib(n-3) for n >= 3

    >>> fibfib(1)
    0
    >>> fibfib(5)
    4
    >>> fibfib(8)
    24
    """
    _validate_index(n)

    base_value = _fibfib_base_case(n)
    if base_value is not None:
        return base_value

    first, second, third = 0, 0, 1
    for _ in range(3, n + 1):
        first, second, third = second, third, first + second + third

    return third
candidate = fibfib




METADATA = {}


def check(candidate):
    assert candidate(2) == 1
    assert candidate(1) == 0
    assert candidate(5) == 4
    assert candidate(8) == 24
    assert candidate(10) == 81
    assert candidate(12) == 274
    assert candidate(14) == 927



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
