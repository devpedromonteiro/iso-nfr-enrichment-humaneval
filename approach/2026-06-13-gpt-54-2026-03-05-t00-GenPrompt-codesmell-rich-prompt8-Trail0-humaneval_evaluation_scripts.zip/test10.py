
import unittest
import re
import sys
import math
import copy



def is_palindrome(string: str) -> bool:
    """ Test if given string is a palindrome """
    return string == string[::-1]


def is_palindrome(string: str) -> bool:
    """Test if given string is a palindrome."""
    return string == string[::-1]


def _longest_palindromic_suffix_start(string: str) -> int:
    """Return the start index of the longest palindromic suffix."""
    for start in range(len(string)):
        if is_palindrome(string[start:]):
            return start
    return len(string)


def _missing_suffix_for_palindrome(string: str, suffix_start: int) -> str:
    """Return the characters that must be appended to make the string a palindrome."""
    prefix = string[:suffix_start]
    return prefix[::-1]


def make_palindrome(string: str) -> str:
    """Find the shortest palindrome that begins with a supplied string.

    Algorithm:
    - Find the longest suffix of the supplied string that is a palindrome.
    - Append the reverse of the prefix that comes before that palindromic suffix.

    >>> make_palindrome('')
    ''
    >>> make_palindrome('cat')
    'catac'
    >>> make_palindrome('cata')
    'catac'
    """
    suffix_start = _longest_palindromic_suffix_start(string)
    return string + _missing_suffix_for_palindrome(string, suffix_start)
candidate = make_palindrome




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == ''
    assert candidate('x') == 'x'
    assert candidate('xyz') == 'xyzyx'
    assert candidate('xyx') == 'xyx'
    assert candidate('jerry') == 'jerryrrej'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
