
import unittest
import re
import sys
import math
import copy


from collections import Counter
from math import comb


def _value_mod_3(index: int) -> int:
    """Return (i*i - i + 1) % 3 for a 1-based index."""
    return (index * index - index + 1) % 3


def _count_residue_frequencies(n: int) -> Counter:
    """Count how many array values fall into each residue class modulo 3."""
    residues = Counter()
    for i in range(1, n + 1):
        residues[_value_mod_3(i)] += 1
    return residues


def _count_valid_triples(residues: Counter) -> int:
    """
    Count triples whose sum is divisible by 3 based on residue frequencies.
    Valid residue combinations are:
    - (0, 0, 0)
    - (1, 1, 1)
    - (2, 2, 2)
    - (0, 1, 2)
    """
    c0 = residues[0]
    c1 = residues[1]
    c2 = residues[2]

    return (
        comb(c0, 3)
        + comb(c1, 3)
        + comb(c2, 3)
        + (c0 * c1 * c2)
    )


def get_max_triples(n):
    """
    You are given a positive integer n. You have to create an integer array a of length n.
        For each i (1 â¤ i â¤ n), the value of a[i] = i * i - i + 1.
        Return the number of triples (a[i], a[j], a[k]) of a where i < j < k,
    and a[i] + a[j] + a[k] is a multiple of 3.

    Example :
        Input: n = 5
        Output: 1
        Explanation:
        a = [1, 3, 7, 13, 21]
        The only valid triple is (1, 7, 13).
    """
    if n < 3:
        return 0

    residues = _count_residue_frequencies(n)
    return _count_valid_triples(residues)
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
