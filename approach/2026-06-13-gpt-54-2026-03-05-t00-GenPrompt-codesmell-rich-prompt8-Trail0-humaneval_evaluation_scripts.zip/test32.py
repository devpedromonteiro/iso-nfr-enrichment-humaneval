
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math
from typing import List


def poly(coefficients: List[float], x: float) -> float:
    """
    Evaluate a polynomial with coefficients at point x.

    coefficients[i] is the coefficient for x^i.
    """
    return sum(coeff * math.pow(x, i) for i, coeff in enumerate(coefficients))


def _validate_coefficients(coefficients: List[float]) -> None:
    """Validate the constraints required by find_zero."""
    if not coefficients:
        raise ValueError("coefficients must not be empty")

    if len(coefficients) % 2 != 0:
        raise ValueError("find_zero requires an even number of coefficients")

    if coefficients[-1] == 0:
        raise ValueError("largest coefficient must be non-zero")


def _derivative_coefficients(coefficients: List[float]) -> List[float]:
    """Return the coefficients of the derivative polynomial."""
    return [i * coeff for i, coeff in enumerate(coefficients)][1:]


def _find_bound(coefficients: List[float]) -> float:
    """
    Find a search bound large enough to bracket at least one root.

    For an odd-degree polynomial with non-zero leading coefficient,
    values at sufficiently large negative and positive x have opposite signs.
    """
    bound = 1.0
    left_value = poly(coefficients, -bound)
    right_value = poly(coefficients, bound)

    while left_value * right_value > 0:
        bound *= 2
        left_value = poly(coefficients, -bound)
        right_value = poly(coefficients, bound)

    return bound


def _bisect_zero(coefficients: List[float], left: float, right: float, tolerance: float = 1e-7) -> float:
    """Find a root in [left, right] using bisection."""
    left_value = poly(coefficients, left)
    right_value = poly(coefficients, right)

    if left_value == 0:
        return left
    if right_value == 0:
        return right

    while right - left > tolerance:
        middle = (left + right) / 2
        middle_value = poly(coefficients, middle)

        if middle_value == 0:
            return middle

        if left_value * middle_value <= 0:
            right = middle
            right_value = middle_value
        else:
            left = middle
            left_value = middle_value

    return (left + right) / 2


def find_zero(coefficients: List[float]) -> float:
    """Find one real zero of a polynomial.

    coefficients are ordered from the constant term upward.

    Preconditions:
    - coefficients has an even number of elements
    - the largest-order coefficient is non-zero

    >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2)
    1.0
    """
    _validate_coefficients(coefficients)
    bound = _find_bound(coefficients)
    return _bisect_zero(coefficients, -bound, bound)
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
