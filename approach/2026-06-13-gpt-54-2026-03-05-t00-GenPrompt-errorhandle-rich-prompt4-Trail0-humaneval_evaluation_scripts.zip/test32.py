
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[2] * x^2 + .... + xs[n] * x^n
    """
    if not isinstance(xs, list):
        raise TypeError("xs must be a list of numeric coefficients")
    if len(xs) == 0:
        raise ValueError("xs must not be empty")
    if not isinstance(x, (int, float)):
        raise TypeError("x must be a numeric value")

    for i, coeff in enumerate(xs):
        if not isinstance(coeff, (int, float)):
            raise TypeError(f"coefficient at index {i} must be numeric")

    return sum(coeff * math.pow(x, i) for i, coeff in enumerate(xs))


def find_zero(xs: list):
    """xs are coefficients of a polynomial.
    find_zero finds x such that poly(x) = 0.
    find_zero returns only one zero point, even if there are many.
    Moreover, find_zero only takes list xs having even number of coefficients
    and largest non-zero coefficient as it guarantees a solution.

    >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2)  # (x - 1) * (x - 2) * (x - 3)
    1.0
    """
    if not isinstance(xs, list):
        raise TypeError("xs must be a list of numeric coefficients")
    if len(xs) == 0:
        raise ValueError("xs must not be empty")
    if len(xs) % 2 != 0:
        raise ValueError("xs must contain an even number of coefficients")

    for i, coeff in enumerate(xs):
        if not isinstance(coeff, (int, float)):
            raise TypeError(f"coefficient at index {i} must be numeric")

    if xs[-1] == 0:
        raise ValueError("largest-degree coefficient must be non-zero")

    # Constant polynomial cannot have a guaranteed zero under these constraints.
    if len(xs) < 2:
        raise ValueError("polynomial degree must be at least 1")

    # Fast path for linear polynomial: a + bx = 0
    if len(xs) == 2:
        a, b = xs
        if b == 0:
            raise ValueError("linear coefficient must be non-zero")
        return -a / b

    def f(v):
        return poly(xs, v)

    # Since the polynomial has odd degree (even number of coefficients)
    # and non-zero leading coefficient, it must cross zero somewhere.
    left, right = -1.0, 1.0
    f_left, f_right = f(left), f(right)

    # Expand interval until it brackets a root.
    max_expansions = 10_000
    expansions = 0
    while f_left * f_right > 0:
        if expansions >= max_expansions:
            raise RuntimeError("failed to bracket a root within search bounds")
        left *= 2.0
        right *= 2.0
        f_left, f_right = f(left), f(right)
        expansions += 1

    if f_left == 0:
        return left
    if f_right == 0:
        return right

    # Bisection method on a valid bracket.
    tolerance = 1e-12
    max_iterations = 10_000

    for _ in range(max_iterations):
        mid = (left + right) / 2.0
        f_mid = f(mid)

        if abs(f_mid) < tolerance or abs(right - left) < tolerance:
            return mid

        if f_left * f_mid < 0:
            right = mid
            f_right = f_mid
        else:
            left = mid
            f_left = f_mid

    raise RuntimeError("bisection did not converge")
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
