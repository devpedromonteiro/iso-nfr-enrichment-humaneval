
import unittest
import re
import sys
import math
import copy


def valid_date(date):
    """Validate a date string in mm-dd-yyyy format.

    Returns:
        bool: True if the date is valid, otherwise False.

    Raises:
        TypeError: If date is not a string.
        ValueError: If date is an empty string.
    """
    if not isinstance(date, str):
        raise TypeError("date must be a string")

    if date == "":
        raise ValueError("date string must not be empty")

    parts = date.split("-")
    if len(parts) != 3:
        return False

    month_str, day_str, year_str = parts

    # Enforce exact mm-dd-yyyy structure
    if len(month_str) != 2 or len(day_str) != 2 or len(year_str) != 4:
        return False

    if not (month_str.isdigit() and day_str.isdigit() and year_str.isdigit()):
        return False

    try:
        month = int(month_str)
        day = int(day_str)
        year = int(year_str)
    except ValueError:
        # Defensive: should not happen after isdigit(), but kept explicit
        raise ValueError("date contains non-numeric components")

    if year < 0:
        return False

    if month < 1 or month > 12:
        return False

    if month in (1, 3, 5, 7, 8, 10, 12):
        max_day = 31
    elif month in (4, 6, 9, 11):
        max_day = 30
    else:  # February
        max_day = 29

    return 1 <= day <= max_day
candidate = valid_date


def check(candidate):

    # Check some simple cases
    assert candidate('03-11-2000') == True

    assert candidate('15-01-2012') == False

    assert candidate('04-0-2040') == False

    assert candidate('06-04-2020') == True

    assert candidate('01-01-2007') == True

    assert candidate('03-32-2011') == False

    assert candidate('') == False

    assert candidate('04-31-3000') == False

    assert candidate('06-06-2005') == True

    assert candidate('21-31-2000') == False

    assert candidate('04-12-2003') == True

    assert candidate('04122003') == False

    assert candidate('20030412') == False

    assert candidate('2003-04') == False

    assert candidate('2003-04-12') == False

    assert candidate('04-2003') == False


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
