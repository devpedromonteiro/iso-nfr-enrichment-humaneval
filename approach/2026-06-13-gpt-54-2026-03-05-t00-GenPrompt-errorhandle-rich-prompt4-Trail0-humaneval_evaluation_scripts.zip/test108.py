
import unittest
import re
import sys
import math
import copy


def count_nums(arr):
    """
    Return the number of integers in arr whose digit sum is greater than 0.

    For negative numbers, the first digit is treated as negative:
    -123 -> -1 + 2 + 3 = 4

    Examples:
    >>> count_nums([]) == 0
    True
    >>> count_nums([-1, 11, -11]) == 1
    True
    >>> count_nums([1, 1, 2]) == 3
    True
    """
    if arr is None:
        raise TypeError("arr must be an iterable of integers, got None")

    if not isinstance(arr, (list, tuple)):
        raise TypeError("arr must be a list or tuple of integers")

    def signed_digit_sum(n):
        if not isinstance(n, int):
            raise TypeError(f"all elements must be integers, got {type(n).__name__}")
        if n >= 0:
            return sum(int(d) for d in str(n))
        digits = str(abs(n))
        return -int(digits[0]) + sum(int(d) for d in digits[1:])

    count = 0
    for num in arr:
        if signed_digit_sum(num) > 0:
            count += 1
    return count
candidate = count_nums


def check(candidate):

    # Check some simple cases
    assert candidate([]) == 0
    assert candidate([-1, -2, 0]) == 0
    assert candidate([1, 1, 2, -2, 3, 4, 5]) == 6
    assert candidate([1, 6, 9, -6, 0, 1, 5]) == 5
    assert candidate([1, 100, 98, -7, 1, -1]) == 4
    assert candidate([12, 23, 34, -45, -56, 0]) == 5
    assert candidate([-0, 1**0]) == 1
    assert candidate([1]) == 1

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
