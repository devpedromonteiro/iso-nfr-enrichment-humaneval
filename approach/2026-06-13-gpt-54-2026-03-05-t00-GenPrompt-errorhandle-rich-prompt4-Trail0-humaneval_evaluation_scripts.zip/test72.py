
import unittest
import re
import sys
import math
import copy


def will_it_fly(q, w):
    '''
    Return True if the object q will fly, and False otherwise.

    The object q will fly if:
    - it is balanced (it is a palindromic list), and
    - the sum of its elements is less than or equal to the maximum possible weight w.

    Raises:
        TypeError: if q is not a list, or if w is not a number, or if any element of q is not a number.
        ValueError: if w is negative.
    '''
    if not isinstance(q, list):
        raise TypeError("q must be a list")

    if not isinstance(w, (int, float)):
        raise TypeError("w must be a number")

    if w < 0:
        raise ValueError("w must be non-negative")

    for i, item in enumerate(q):
        if not isinstance(item, (int, float)):
            raise TypeError(f"q[{i}] must be a number")

    is_balanced = q == q[::-1]
    total_weight = sum(q)

    return is_balanced and total_weight <= w
candidate = will_it_fly


def check(candidate):

    # Check some simple cases
    assert candidate([3, 2, 3], 9) is True
    assert candidate([1, 2], 5) is False
    assert candidate([3], 5) is True
    assert candidate([3, 2, 3], 1) is False


    # Check some edge cases that are easy to work out by hand.
    assert candidate([1, 2, 3], 6) is False
    assert candidate([5], 5) is True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
