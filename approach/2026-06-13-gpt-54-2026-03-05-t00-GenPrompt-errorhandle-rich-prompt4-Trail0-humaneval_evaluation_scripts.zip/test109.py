
import unittest
import re
import sys
import math
import copy


def move_one_ball(arr):
    """We have an array 'arr' of N integers arr[1], arr[2], ..., arr[N]. The
    numbers in the array will be randomly ordered. Your task is to determine if
    it is possible to get an array sorted in non-decreasing order by performing
    the following operation on the given array:
        You are allowed to perform right shift operation any number of times.

    One right shift operation means shifting all elements of the array by one
    position in the right direction. The last element of the array will be moved to
    the starting position in the array i.e. 0th index.

    If it is possible to obtain the sorted array by performing the above operation
    then return True else return False.
    If the given array is empty then return True.

    Note: The given list is guaranteed to have unique elements.
    """
    if arr is None:
        raise TypeError("arr must be a list or tuple of integers, got None")

    if not isinstance(arr, (list, tuple)):
        raise TypeError(f"arr must be a list or tuple of integers, got {type(arr).__name__}")

    if len(arr) == 0:
        return True

    for i, value in enumerate(arr):
        if not isinstance(value, int):
            raise TypeError(f"arr[{i}] must be an integer, got {type(value).__name__}")

    # Count how many times the order decreases.
    # A sortable-by-rotation array can have at most one such "drop".
    drops = 0
    n = len(arr)

    for i in range(n):
        try:
            if arr[i] > arr[(i + 1) % n]:
                drops += 1
                if drops > 1:
                    return False
        except IndexError as exc:
            # Defensive handling: should not occur due to modulo indexing,
            # but if the input is mutated unexpectedly, fail explicitly.
            raise IndexError("array indexing failed during rotation check") from exc
        except TypeError:
            # Re-raise with clearer context while preserving failure semantics.
            raise TypeError("array contains non-comparable elements")

    return True
candidate = move_one_ball


def check(candidate):

    # Check some simple cases
    assert candidate([3, 4, 5, 1, 2])==True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([3, 5, 10, 1, 2])==True
    assert candidate([4, 3, 1, 2])==False
    # Check some edge cases that are easy to work out by hand.
    assert candidate([3, 5, 4, 1, 2])==False, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([])==True


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
