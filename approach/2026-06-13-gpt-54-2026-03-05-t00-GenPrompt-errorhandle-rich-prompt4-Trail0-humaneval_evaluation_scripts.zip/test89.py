
import unittest
import re
import sys
import math
import copy


def encrypt(s):
    """Encrypt a lowercase alphabetic string by shifting each letter forward 4 places.

    The shift wraps around the alphabet:
    - encrypt('hi') -> 'lm'
    - encrypt('asdfghjkl') -> 'ewhjklnop'
    - encrypt('gf') -> 'kj'
    - encrypt('et') -> 'ix'

    Raises:
        TypeError: if s is not a string.
        ValueError: if s contains non-lowercase alphabetic characters.
    """
    if not isinstance(s, str):
        raise TypeError("encrypt() argument must be a string")

    if not s.isalpha() or not s.islower():
        raise ValueError("encrypt() argument must contain only lowercase alphabetic characters")

    shift = 4
    result = []

    for ch in s:
        offset = ord(ch) - ord('a')
        encrypted_char = chr(ord('a') + (offset + shift) % 26)
        result.append(encrypted_char)

    return ''.join(result)
candidate = encrypt


def check(candidate):

    # Check some simple cases
    assert candidate('hi') == 'lm', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('asdfghjkl') == 'ewhjklnop', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('gf') == 'kj', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('et') == 'ix', "This prints if this assert fails 1 (good for debugging!)"

    assert candidate('faewfawefaewg')=='jeiajeaijeiak', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('hellomyfriend')=='lippsqcjvmirh', "This prints if this assert fails 2 (good for debugging!)"
    assert candidate('dxzdlmnilfuhmilufhlihufnmlimnufhlimnufhfucufh')=='hbdhpqrmpjylqmpyjlpmlyjrqpmqryjlpmqryjljygyjl', "This prints if this assert fails 3 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate('a')=='e', "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
