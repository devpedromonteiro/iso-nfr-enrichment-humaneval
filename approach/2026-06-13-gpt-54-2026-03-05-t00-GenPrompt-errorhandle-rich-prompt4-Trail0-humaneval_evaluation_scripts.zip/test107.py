
import unittest
import re
import sys
import math
import copy


def even_odd_palindrome(n):
    """
    Given a positive integer n, return a tuple containing:
    (number_of_even_palindromes, number_of_odd_palindromes)
    for all integer palindromes in the inclusive range [1, n].

    Args:
        n (int): A positive integer such that 1 <= n <= 10^3.

    Returns:
        tuple[int, int]: Counts of even and odd palindromes respectively.

    Raises:
        TypeError: If n is not an integer.
        ValueError: If n is outside the allowed range [1, 10^3].
    """
    if isinstance(n, bool) or not isinstance(n, int):
        raise TypeError("n must be an integer")
    if n < 1 or n > 10**3:
        raise ValueError("n must be between 1 and 10^3 inclusive")

    even_count = 0
    odd_count = 0

    for value in range(1, n + 1):
        s = str(value)
        if s == s[::-1]:
            if value % 2 == 0:
                even_count += 1
            else:
                odd_count += 1

    return (even_count, odd_count)
candidate = even_odd_palindrome


def check(candidate):

    # Check some simple cases
    assert candidate(123) == (8, 13)
    assert candidate(12) == (4, 6)
    assert candidate(3) == (1, 2)
    assert candidate(63) == (6, 8)
    assert candidate(25) == (5, 6)
    assert candidate(19) == (4, 6)
    assert candidate(9) == (4, 5), "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1) == (0, 1), "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
