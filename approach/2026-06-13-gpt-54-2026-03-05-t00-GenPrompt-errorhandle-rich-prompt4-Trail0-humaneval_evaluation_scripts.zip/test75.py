
import unittest
import re
import sys
import math
import copy


def is_multiply_prime(a):
    """Return True if `a` is the product of exactly 3 prime numbers, else False.

    A prime factor may repeat, e.g. 8 = 2 * 2 * 2 -> True.

    Constraints handled:
    - validates input type explicitly
    - rejects invalid arguments with specific exceptions
    - does not silently swallow errors
    """
    if isinstance(a, bool) or not isinstance(a, int):
        raise TypeError("a must be an integer")
    if a < 0:
        raise ValueError("a must be non-negative")
    if a >= 100:
        raise ValueError("a must be less than 100")

    def is_prime(n):
        if n < 2:
            return False
        for i in range(2, int(n ** 0.5) + 1):
            if n % i == 0:
                return False
        return True

    for p1 in range(2, a + 1):
        if not is_prime(p1):
            continue
        if a % p1 != 0:
            continue

        for p2 in range(2, a + 1):
            if not is_prime(p2):
                continue
            if (a // p1) % p2 != 0:
                continue

            p3 = a // (p1 * p2)
            if p1 * p2 * p3 == a and is_prime(p3):
                return True

    return False
candidate = is_multiply_prime


def check(candidate):

    assert candidate(5) == False
    assert candidate(30) == True
    assert candidate(8) == True
    assert candidate(10) == False
    assert candidate(125) == True
    assert candidate(3 * 5 * 7) == True
    assert candidate(3 * 6 * 7) == False
    assert candidate(9 * 9 * 9) == False
    assert candidate(11 * 9 * 9) == False
    assert candidate(11 * 13 * 7) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
