
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def string_xor(a: str, b: str) -> str:
    """Input are two strings a and b consisting only of 1s and 0s.
    Perform binary XOR on these inputs and return result also as a string.

    >>> string_xor('010', '110')
    '100'
    """
    if not isinstance(a, str):
        raise TypeError(f"a must be a str, got {type(a).__name__}")
    if not isinstance(b, str):
        raise TypeError(f"b must be a str, got {type(b).__name__}")

    if len(a) != len(b):
        raise ValueError("a and b must have the same length")

    invalid_a = set(a) - {"0", "1"}
    if invalid_a:
        raise ValueError("a must contain only '0' and '1' characters")

    invalid_b = set(b) - {"0", "1"}
    if invalid_b:
        raise ValueError("b must contain only '0' and '1' characters")

    try:
        return "".join("1" if x != y else "0" for x, y in zip(a, b))
    except Exception as exc:
        raise RuntimeError("failed to compute XOR") from exc
candidate = string_xor




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('111000', '101010') == '010010'
    assert candidate('1', '1') == '0'
    assert candidate('0101', '0000') == '0101'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
