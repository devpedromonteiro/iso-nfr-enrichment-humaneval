
import unittest
import re
import sys
import math
import copy



def car_race_collision(n: int) -> int:
    """
    Return the number of collisions between two groups of cars.

    There are `n` cars moving left-to-right and `n` cars moving right-to-left.
    Every car from the first group collides exactly once with every car from
    the second group, so the total number of collisions is n * n.

    Args:
        n: Number of cars in each group. Must be a non-negative integer.

    Returns:
        The total number of collisions.

    Raises:
        TypeError: If `n` is not an integer.
        ValueError: If `n` is negative.
    """
    if isinstance(n, bool) or not isinstance(n, int):
        raise TypeError(
            f"n must be a non-negative integer, got {type(n).__name__}"
        )

    if n < 0:
        raise ValueError(f"n must be non-negative, got {n}")

    return n * n
candidate = car_race_collision




METADATA = {}


def check(candidate):
    assert candidate(2) == 4
    assert candidate(3) == 9
    assert candidate(4) == 16
    assert candidate(8) == 64
    assert candidate(10) == 100



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
