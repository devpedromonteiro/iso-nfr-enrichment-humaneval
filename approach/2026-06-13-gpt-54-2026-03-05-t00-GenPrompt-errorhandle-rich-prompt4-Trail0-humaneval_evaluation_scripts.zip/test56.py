
import unittest
import re
import sys
import math
import copy



def correct_bracketing(brackets: str) -> bool:
    """brackets is a string of "<" and ">".
    Return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("<")
    False
    >>> correct_bracketing("<>")
    True
    >>> correct_bracketing("<<><>>")
    True
    >>> correct_bracketing("><<>")
    False
    """
    if not isinstance(brackets, str):
        raise TypeError("brackets must be a string")

    invalid_chars = set(brackets) - {"<", ">"}
    if invalid_chars:
        raise ValueError(
            f"brackets must contain only '<' and '>', got invalid character(s): {sorted(invalid_chars)}"
        )

    balance = 0
    for ch in brackets:
        if ch == "<":
            balance += 1
        else:  # ch == ">"
            balance -= 1
            if balance < 0:
                return False

    return balance == 0
candidate = correct_bracketing




METADATA = {}


def check(candidate):
    assert candidate("<>")
    assert candidate("<<><>>")
    assert candidate("<><><<><>><>")
    assert candidate("<><><<<><><>><>><<><><<>>>")
    assert not candidate("<<<><>>>>")
    assert not candidate("><<>")
    assert not candidate("<")
    assert not candidate("<<<<")
    assert not candidate(">")
    assert not candidate("<<>")
    assert not candidate("<><><<><>><>><<>")
    assert not candidate("<><><<><>><>>><>")



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
