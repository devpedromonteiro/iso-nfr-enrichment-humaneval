
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    """Insert `delimeter` between every two consecutive elements of `numbers`.

    Args:
        numbers: A list of integers.
        delimeter: The integer to insert between elements.

    Returns:
        A new list with `delimeter` inserted between consecutive elements.

    Raises:
        TypeError: If `numbers` is not a list, or if any element in `numbers`
            is not an int, or if `delimeter` is not an int.

    >>> intersperse([], 4)
    []
    >>> intersperse([1, 2, 3], 4)
    [1, 4, 2, 4, 3]
    """
    if not isinstance(numbers, list):
        raise TypeError(
            f"numbers must be a list of integers, got {type(numbers).__name__}"
        )

    if not isinstance(delimeter, int):
        raise TypeError(
            f"delimeter must be an integer, got {type(delimeter).__name__}"
        )

    for index, value in enumerate(numbers):
        if not isinstance(value, int):
            raise TypeError(
                f"numbers[{index}] must be an integer, got {type(value).__name__}"
            )

    if not numbers:
        return []

    result: List[int] = []
    for i, number in enumerate(numbers):
        result.append(number)
        if i < len(numbers) - 1:
            result.append(delimeter)

    return result
candidate = intersperse




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([], 7) == []
    assert candidate([5, 6, 3, 2], 8) == [5, 8, 6, 8, 3, 8, 2]
    assert candidate([2, 2, 2], 2) == [2, 2, 2, 2, 2]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
