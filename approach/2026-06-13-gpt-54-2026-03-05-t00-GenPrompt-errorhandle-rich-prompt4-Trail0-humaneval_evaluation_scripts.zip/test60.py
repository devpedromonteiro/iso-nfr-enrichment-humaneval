
import unittest
import re
import sys
import math
import copy



def sum_to_n(n: int):
    """sum_to_n is a function that sums numbers from 1 to n.

    >>> sum_to_n(30)
    465
    >>> sum_to_n(100)
    5050
    >>> sum_to_n(5)
    15
    >>> sum_to_n(10)
    55
    >>> sum_to_n(1)
    1
    """
    if not isinstance(n, int):
        raise TypeError(f"n must be an int, got {type(n).__name__}")
    if n < 1:
        raise ValueError("n must be a positive integer greater than or equal to 1")

    try:
        return n * (n + 1) // 2
    except OverflowError as exc:
        raise OverflowError("integer value is too large to compute sum safely") from exc
candidate = sum_to_n




METADATA = {}


def check(candidate):
    assert candidate(1) == 1
    assert candidate(6) == 21
    assert candidate(11) == 66
    assert candidate(30) == 465
    assert candidate(100) == 5050



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
