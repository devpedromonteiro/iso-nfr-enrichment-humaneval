
import unittest
import re
import sys
import math
import copy


def solve(s):
    """Transform a string according to the following rules:
    - If the string contains at least one letter, reverse the case of each letter
      and leave all non-letter characters unchanged.
    - If the string contains no letters, return the reversed string.

    Args:
        s: Input string.

    Returns:
        Transformed string.

    Raises:
        TypeError: If s is not a string.
        ValueError: If s is None.
    """
    if s is None:
        raise ValueError("Input cannot be None.")
    if not isinstance(s, str):
        raise TypeError(f"Expected a string, got {type(s).__name__}.")

    try:
        has_letter = any(ch.isalpha() for ch in s)

        if not has_letter:
            return s[::-1]

        return ''.join(ch.swapcase() if ch.isalpha() else ch for ch in s)

    except Exception as exc:
        raise RuntimeError("Failed to process input string.") from exc
candidate = solve


def check(candidate):

    # Check some simple cases
    assert candidate("AsDf") == "aSdF"
    assert candidate("1234") == "4321"
    assert candidate("ab") == "AB"
    assert candidate("#a@C") == "#A@c"
    assert candidate("#AsdfW^45") == "#aSDFw^45"
    assert candidate("#6@2") == "2@6#"

    # Check some edge cases that are easy to work out by hand.
    assert candidate("#$a^D") == "#$A^d"
    assert candidate("#ccc") == "#CCC"

    # Don't remove this line:


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
