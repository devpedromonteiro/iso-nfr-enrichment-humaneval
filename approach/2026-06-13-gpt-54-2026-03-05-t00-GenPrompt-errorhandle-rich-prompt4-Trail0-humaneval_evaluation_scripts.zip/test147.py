
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    You are given a positive integer n. You have to create an integer array a of length n.
        For each i (1 â¤ i â¤ n), the value of a[i] = i * i - i + 1.
        Return the number of triples (a[i], a[j], a[k]) of a where i < j < k,
    and a[i] + a[j] + a[k] is a multiple of 3.

    Example :
        Input: n = 5
        Output: 1
        Explanation:
        a = [1, 3, 7, 13, 21]
        The only valid triple is (1, 7, 13).
    """
    if isinstance(n, bool):
        raise TypeError("n must be a positive integer, not bool")
    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if n <= 0:
        raise ValueError("n must be a positive integer")

    # For i = 1..n:
    # a[i] = i^2 - i + 1
    # modulo 3:
    # if i % 3 == 0 -> a[i] % 3 == 1
    # if i % 3 == 1 -> a[i] % 3 == 1
    # if i % 3 == 2 -> a[i] % 3 == 0
    #
    # So values fall into:
    #   residue 1: count1 = number of i where i % 3 != 2
    #   residue 0: count0 = number of i where i % 3 == 2
    #
    # A triple sum is divisible by 3 only for:
    #   (0,0,0) or (1,1,1)
    count0 = 0  # a[i] % 3 == 0
    count1 = 0  # a[i] % 3 == 1

    for i in range(1, n + 1):
        value_mod = (i * i - i + 1) % 3
        if value_mod == 0:
            count0 += 1
        elif value_mod == 1:
            count1 += 1
        else:
            raise RuntimeError("Unexpected modulo result while computing sequence")

    def comb3(x):
        if x < 3:
            return 0
        return x * (x - 1) * (x - 2) // 6

    return comb3(count0) + comb3(count1)
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
