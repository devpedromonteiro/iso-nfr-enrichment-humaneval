
import unittest
import re
import sys
import math
import copy


def f(n):
    """Return a list of length n where the value at 1-based index i is:
    - factorial(i) if i is even
    - sum(1..i) if i is odd

    Example:
        f(5) == [1, 2, 6, 24, 15]
    """
    if isinstance(n, bool):
        raise TypeError("n must be an integer, not bool")
    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if n < 0:
        raise ValueError("n must be non-negative")

    result = []
    factorial = 1

    for i in range(1, n + 1):
        if i % 2 == 0:
            factorial *= (i - 1) * i if i > 2 else i
            result.append(factorial)
        else:
            result.append(i * (i + 1) // 2)

    return result
candidate = f


def check(candidate):

    assert candidate(5) == [1, 2, 6, 24, 15]
    assert candidate(7) == [1, 2, 6, 24, 15, 720, 28]
    assert candidate(1) == [1]
    assert candidate(3) == [1, 2, 6]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
