
import unittest
import re
import sys
import math
import copy


def is_happy(s):
    """Return True if string s is happy, otherwise False.

    A string is happy if:
    - its length is at least 3
    - every 3 consecutive characters are all distinct

    Examples:
        is_happy("a") -> False
        is_happy("aa") -> False
        is_happy("abcd") -> True
        is_happy("aabb") -> False
        is_happy("adb") -> True
        is_happy("xyy") -> False
    """
    if s is None:
        raise TypeError("s must be a string, got None")
    if not isinstance(s, str):
        raise TypeError(f"s must be a string, got {type(s).__name__}")

    if len(s) < 3:
        return False

    for i in range(len(s) - 2):
        a, b, c = s[i], s[i + 1], s[i + 2]
        if len({a, b, c}) != 3:
            return False

    return True
candidate = is_happy


def check(candidate):

    # Check some simple cases
    assert candidate("a") == False , "a"
    assert candidate("aa") == False , "aa"
    assert candidate("abcd") == True , "abcd"
    assert candidate("aabb") == False , "aabb"
    assert candidate("adb") == True , "adb"
    assert candidate("xyy") == False , "xyy"
    assert candidate("iopaxpoi") == True , "iopaxpoi"
    assert candidate("iopaxioi") == False , "iopaxioi"


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
