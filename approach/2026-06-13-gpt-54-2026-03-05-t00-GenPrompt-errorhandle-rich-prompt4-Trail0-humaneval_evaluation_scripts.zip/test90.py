
import unittest
import re
import sys
import math
import copy


def next_smallest(lst):
    """
    Return the 2nd smallest distinct integer in the list.
    Return None if there is no such element.

    Raises:
        TypeError: if lst is not a list or contains non-integer elements.
        ValueError: if lst is None.
    """
    if lst is None:
        raise ValueError("lst must not be None")

    if not isinstance(lst, list):
        raise TypeError("lst must be a list of integers")

    for i, value in enumerate(lst):
        if not isinstance(value, int):
            raise TypeError(f"all elements must be integers; found {type(value).__name__} at index {i}")

    distinct_values = set(lst)
    if len(distinct_values) < 2:
        return None

    return sorted(distinct_values)[1]
candidate = next_smallest


def check(candidate):

    # Check some simple cases
    assert candidate([1, 2, 3, 4, 5]) == 2
    assert candidate([5, 1, 4, 3, 2]) == 2
    assert candidate([]) == None
    assert candidate([1, 1]) == None
    assert candidate([1,1,1,1,0]) == 1
    assert candidate([1, 0**0]) == None
    assert candidate([-35, 34, 12, -45]) == -35

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
