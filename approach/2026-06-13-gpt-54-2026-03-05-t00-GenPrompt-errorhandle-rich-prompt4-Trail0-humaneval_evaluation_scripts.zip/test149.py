
import unittest
import re
import sys
import math
import copy


def sorted_list_sum(lst):
    """Accept a list of strings, remove strings with odd lengths, and return
    a new sorted list.

    Sorting rules:
    - ascending by string length
    - if lengths are equal, alphabetical order

    Error handling:
    - raises TypeError if lst is not a list
    - raises TypeError if any element is not a string
    """
    if not isinstance(lst, list):
        raise TypeError("lst must be a list of strings")

    for i, item in enumerate(lst):
        if not isinstance(item, str):
            raise TypeError(f"lst[{i}] must be a string, got {type(item).__name__}")

    try:
        even_length_strings = [s for s in lst if len(s) % 2 == 0]
        return sorted(even_length_strings, key=lambda s: (len(s), s))
    except TypeError:
        # Re-raise specific sorting/type issues without swallowing them
        raise
candidate = sorted_list_sum


def check(candidate):

    # Check some simple cases
    assert candidate(["aa", "a", "aaa"]) == ["aa"]
    assert candidate(["school", "AI", "asdf", "b"]) == ["AI", "asdf", "school"]
    assert candidate(["d", "b", "c", "a"]) == []
    assert candidate(["d", "dcba", "abcd", "a"]) == ["abcd", "dcba"]

    # Check some edge cases that are easy to work out by hand.
    assert candidate(["AI", "ai", "au"]) == ["AI", "ai", "au"]
    assert candidate(["a", "b", "b", "c", "c", "a"]) == []
    assert candidate(['aaaa', 'bbbb', 'dd', 'cc']) == ["cc", "dd", "aaaa", "bbbb"]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
