
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def below_zero(operations: List[int]) -> bool:
    """You're given a list of deposit and withdrawal operations on a bank account
    that starts with zero balance. Return True if the balance falls below zero
    at any point, otherwise return False.

    Args:
        operations: A list of integer deposit/withdrawal operations.

    Returns:
        True if the running balance becomes negative, else False.

    Raises:
        TypeError: If operations is not a list or contains non-integer values.
        ValueError: If operations is None.

    >>> below_zero([1, 2, 3])
    False
    >>> below_zero([1, 2, -4, 5])
    True
    """
    if operations is None:
        raise ValueError("operations must not be None")

    if not isinstance(operations, list):
        raise TypeError("operations must be a list of integers")

    balance = 0

    for index, operation in enumerate(operations):
        if not isinstance(operation, int):
            raise TypeError(
                f"operation at index {index} must be an integer, got {type(operation).__name__}"
            )

        balance += operation
        if balance < 0:
            return True

    return False
candidate = below_zero




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == False
    assert candidate([1, 2, -3, 1, 2, -3]) == False
    assert candidate([1, 2, -4, 5, 6]) == True
    assert candidate([1, -1, 2, -2, 5, -5, 4, -4]) == False
    assert candidate([1, -1, 2, -2, 5, -5, 4, -5]) == True
    assert candidate([1, -2, 2, -2, 5, -5, 4, -4]) == True


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
