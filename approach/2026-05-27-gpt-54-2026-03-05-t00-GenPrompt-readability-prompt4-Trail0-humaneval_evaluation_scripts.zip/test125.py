
import unittest
import re
import sys
import math
import copy


def split_words(txt):
    """
    Given a string of words:
    - Split on whitespace if any whitespace exists.
    - Otherwise, split on commas if any commas exist.
    - Otherwise, return the count of lowercase letters whose
      alphabet index is odd:
        a -> 0, b -> 1, ..., z -> 25

    Examples:
        split_words("Hello world!") -> ["Hello", "world!"]
        split_words("Hello,world!") -> ["Hello", "world!"]
        split_words("abcdef") -> 3
    """
    if any(char.isspace() for char in txt):
        return txt.split()

    if "," in txt:
        return txt.split(",")

    odd_index_count = 0
    for char in txt:
        if char.islower():
            alphabet_index = ord(char) - ord("a")
            if alphabet_index % 2 == 1:
                odd_index_count += 1

    return odd_index_count
candidate = split_words


def check(candidate):

    assert candidate("Hello world!") == ["Hello","world!"]
    assert candidate("Hello,world!") == ["Hello","world!"]
    assert candidate("Hello world,!") == ["Hello","world,!"]
    assert candidate("Hello,Hello,world !") == ["Hello,Hello,world","!"]
    assert candidate("abcdef") == 3
    assert candidate("aaabb") == 2
    assert candidate("aaaBb") == 1
    assert candidate("") == 0


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
