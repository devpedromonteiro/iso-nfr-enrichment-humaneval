
import unittest
import re
import sys
import math
import copy



def monotonic(values: list) -> bool:
    """Return True if list elements are monotonically increasing or decreasing.

    >>> monotonic([1, 2, 4, 20])
    True
    >>> monotonic([1, 20, 4, 10])
    False
    >>> monotonic([4, 1, 0, -10])
    True
    """
    is_non_decreasing = all(
        values[index] <= values[index + 1]
        for index in range(len(values) - 1)
    )
    is_non_increasing = all(
        values[index] >= values[index + 1]
        for index in range(len(values) - 1)
    )

    return is_non_decreasing or is_non_increasing
candidate = monotonic




METADATA = {}


def check(candidate):
    assert candidate([1, 2, 4, 10]) == True
    assert candidate([1, 2, 4, 20]) == True
    assert candidate([1, 20, 4, 10]) == False
    assert candidate([4, 1, 0, -10]) == True
    assert candidate([4, 1, 1, 0]) == True
    assert candidate([1, 2, 3, 2, 5, 60]) == False
    assert candidate([1, 2, 3, 4, 5, 60]) == True
    assert candidate([9, 9, 9, 9]) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
