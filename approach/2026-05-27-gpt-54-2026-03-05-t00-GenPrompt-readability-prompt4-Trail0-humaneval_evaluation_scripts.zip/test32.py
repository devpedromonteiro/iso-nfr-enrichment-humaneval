
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math


def poly(coefficients: list[float], x: float) -> float:
    """
    Evaluate a polynomial with coefficients at point x.

    The polynomial is:
        coefficients[0]
        + coefficients[1] * x
        + coefficients[2] * x^2
        + ...
        + coefficients[n] * x^n
    """
    return sum(coefficient * math.pow(x, power) for power, coefficient in enumerate(coefficients))


def find_zero(coefficients: list[float]) -> float:
    """
    Find one zero of a polynomial.

    The input must contain an even number of coefficients and have a non-zero
    leading coefficient. Under the task assumptions, such a polynomial is
    guaranteed to have at least one real zero.

    Returns only one zero, even if multiple zeros exist.

    >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2)  # (x - 1)(x - 2)(x - 3)
    1.0
    """
    if len(coefficients) % 2 != 0:
        raise ValueError("The polynomial must have an even number of coefficients.")

    if not coefficients or coefficients[-1] == 0:
        raise ValueError("The leading coefficient must be non-zero.")

    def find_bracket() -> tuple[float, float]:
        """
        Find interval [left, right] such that poly(left) and poly(right)
        have opposite signs or one endpoint is already a root.
        """
        left = -1.0
        right = 1.0
        value_left = poly(coefficients, left)
        value_right = poly(coefficients, right)

        while value_left * value_right > 0:
            left *= 2
            right *= 2
            value_left = poly(coefficients, left)
            value_right = poly(coefficients, right)

        return left, right

    left, right = find_bracket()
    value_left = poly(coefficients, left)
    value_right = poly(coefficients, right)

    if value_left == 0:
        return left
    if value_right == 0:
        return right

    tolerance = 1e-12

    while right - left > tolerance:
        middle = (left + right) / 2
        value_middle = poly(coefficients, middle)

        if abs(value_middle) < tolerance:
            return middle

        if value_left * value_middle <= 0:
            right = middle
            value_right = value_middle
        else:
            left = middle
            value_left = value_middle

    return (left + right) / 2
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
