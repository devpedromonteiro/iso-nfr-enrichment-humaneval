
import unittest
import re
import sys
import math
import copy



def encode_cyclic(s: str):
    """
    returns encoded string by cycling groups of three characters.
    """
    # split string to groups. Each of length 3.
    groups = [s[(3 * i):min((3 * i + 3), len(s))] for i in range((len(s) + 2) // 3)]
    # cycle elements in each group. Unless group has fewer elements than 3.
    groups = [(group[1:] + group[0]) if len(group) == 3 else group for group in groups]
    return "".join(groups)


def encode_cyclic(s: str) -> str:
    """
    Return an encoded string by cycling each group of three characters left.

    Example:
        "abcdef" -> "bcaefd"
    """
    group_size = 3

    # Split the string into groups of length 3.
    groups = [
        s[i:i + group_size]
        for i in range(0, len(s), group_size)
    ]

    # Cycle each full group of 3 characters.
    encoded_groups = [
        group[1:] + group[0] if len(group) == group_size else group
        for group in groups
    ]

    return "".join(encoded_groups)


def decode_cyclic(s: str) -> str:
    """
    Decode a string that was encoded with encode_cyclic.

    Each full group of three characters is rotated right to restore
    the original order. Groups shorter than three characters are unchanged.

    Example:
        "bcaefd" -> "abcdef"
    """
    group_size = 3

    # Split the string into groups of length 3.
    groups = [
        s[i:i + group_size]
        for i in range(0, len(s), group_size)
    ]

    # Reverse the cycle for each full group of 3 characters.
    decoded_groups = [
        group[-1] + group[:-1] if len(group) == group_size else group
        for group in groups
    ]

    return "".join(decoded_groups)
candidate = decode_cyclic




METADATA = {}


def check(candidate):
    from random import randint, choice
    import string

    letters = string.ascii_lowercase
    for _ in range(100):
        str = ''.join(choice(letters) for i in range(randint(10, 20)))
        encoded_str = encode_cyclic(str)
        assert candidate(encoded_str) == str



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
