
import unittest
import re
import sys
import math
import copy



def triples_sum_to_zero(numbers: list[int]) -> bool:
    """
    triples_sum_to_zero takes a list of integers as an input.
    it returns True if there are three distinct elements in the list that
    sum to zero, and False otherwise.

    >>> triples_sum_to_zero([1, 3, 5, 0])
    False
    >>> triples_sum_to_zero([1, 3, -2, 1])
    True
    >>> triples_sum_to_zero([1, 2, 3, 7])
    False
    >>> triples_sum_to_zero([2, 4, -5, 3, 9, 7])
    True
    >>> triples_sum_to_zero([1])
    False
    """
    if len(numbers) < 3:
        return False

    sorted_numbers = sorted(numbers)
    n = len(sorted_numbers)

    for first_index in range(n - 2):
        left_index = first_index + 1
        right_index = n - 1

        while left_index < right_index:
            current_sum = (
                sorted_numbers[first_index]
                + sorted_numbers[left_index]
                + sorted_numbers[right_index]
            )

            if current_sum == 0:
                return True
            if current_sum < 0:
                left_index += 1
            else:
                right_index -= 1

    return False
candidate = triples_sum_to_zero




METADATA = {}


def check(candidate):
    assert candidate([1, 3, 5, 0]) == False
    assert candidate([1, 3, 5, -1]) == False
    assert candidate([1, 3, -2, 1]) == True
    assert candidate([1, 2, 3, 7]) == False
    assert candidate([1, 2, 5, 7]) == False
    assert candidate([2, 4, -5, 3, 9, 7]) == True
    assert candidate([1]) == False
    assert candidate([1, 3, 5, -100]) == False
    assert candidate([100, 3, 5, -100]) == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
