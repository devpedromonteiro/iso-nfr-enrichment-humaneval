
import unittest
import re
import sys
import math
import copy


def f(n):
    """
    Return a list of length n where:
    - at position i (starting from 1), the value is:
      - factorial(i) if i is even
      - sum from 1 to i if i is odd

    Example:
        f(5) == [1, 2, 6, 24, 15]
    """
    result = []

    for i in range(1, n + 1):
        if i % 2 == 0:
            factorial = 1
            for number in range(1, i + 1):
                factorial *= number
            result.append(factorial)
        else:
            total = i * (i + 1) // 2
            result.append(total)

    return result
candidate = f


def check(candidate):

    assert candidate(5) == [1, 2, 6, 24, 15]
    assert candidate(7) == [1, 2, 6, 24, 15, 720, 28]
    assert candidate(1) == [1]
    assert candidate(3) == [1, 2, 6]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
