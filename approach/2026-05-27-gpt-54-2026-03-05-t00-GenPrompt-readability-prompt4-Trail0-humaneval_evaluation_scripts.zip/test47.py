
import unittest
import re
import sys
import math
import copy



def median(values: list):
    """Return median of elements in the list values.
    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    8.0
    """
    sorted_values = sorted(values)
    length = len(sorted_values)
    middle_index = length // 2

    if length % 2 == 1:
        return sorted_values[middle_index]

    left_middle = sorted_values[middle_index - 1]
    right_middle = sorted_values[middle_index]
    return (left_middle + right_middle) / 2
candidate = median




METADATA = {}


def check(candidate):
    assert candidate([3, 1, 2, 4, 5]) == 3
    assert candidate([-10, 4, 6, 1000, 10, 20]) == 8.0
    assert candidate([5]) == 5
    assert candidate([6, 5]) == 5.5
    assert candidate([8, 1, 3, 9, 9, 2, 7]) == 7 



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
