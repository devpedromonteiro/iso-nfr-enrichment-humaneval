
import unittest


def starts_one_ends(n):
    """
    Given a positive integer n, return the count of n-digit positive integers
    that start or end with 1.
    """
    if n <= 0:
        return 0

    # Count numbers that start with 1:
    # first digit fixed to 1, remaining n-1 digits arbitrary
    start_with_1 = 10 ** (n - 1)

    # Count numbers that end with 1:
    # first digit 1-9, middle n-2 digits arbitrary, last digit fixed to 1
    end_with_1 = 9 * (10 ** (n - 2)) if n > 1 else 1

    # Count numbers counted twice (both start and end with 1):
    both = 10 ** (n - 2) if n > 1 else 1

    return start_with_1 + end_with_1 - both
candidate = starts_one_ends


class Test(unittest.TestCase):
    def test(self):
        assert candidate(12) == 180000000000
        assert candidate(2) == 18
        assert candidate(14) == 18000000000000
        assert candidate(3) == 180
        assert candidate(19) == 1800000000000000000
        assert candidate(1) == 1
        assert candidate(8) == 18000000
        assert candidate(13) == 1800000000000
        assert candidate(16) == 1800000000000000
        assert candidate(11) == 18000000000
        assert candidate(17) == 18000000000000000
        assert candidate(4) == 1800
        assert candidate(20) == 18000000000000000000
        assert candidate(9) == 180000000
        assert candidate(6) == 180000
        assert candidate(15) == 180000000000000
        assert candidate(5) == 18000
        assert candidate(18) == 180000000000000000
        assert candidate(5) == 18000

    # Check some edge cases that are easy to work out by hand.
        assert candidate(7) == 1800000
        assert candidate(10) == 1800000000

if __name__ == '__main__':
    unittest.main()
