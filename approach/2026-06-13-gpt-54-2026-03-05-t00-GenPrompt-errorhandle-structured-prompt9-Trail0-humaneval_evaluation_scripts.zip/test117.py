
import unittest
import re
import sys
import math
import copy


def select_words(s, n):
    """Given a string s and a natural number n, return a list of all words from s
    that contain exactly n consonants, preserving their original order.

    Args:
        s: A string containing only letters and spaces.
        n: A natural number representing the exact number of consonants.

    Returns:
        A list of matching words.

    Raises:
        TypeError: If s is not a string or n is not an integer.
        ValueError: If n is negative.
    """
    if not isinstance(s, str):
        raise TypeError("s must be a string")
    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if n < 0:
        raise ValueError("n must be a natural number (non-negative)")

    if s == "":
        return []

    vowels = {"a", "e", "i", "o", "u"}
    result = []

    for word in s.split():
        consonant_count = 0
        for char in word:
            if char.isalpha() and char.lower() not in vowels:
                consonant_count += 1
        if consonant_count == n:
            result.append(word)

    return result
candidate = select_words


def check(candidate):

    # Check some simple cases
    assert candidate("Mary had a little lamb", 4) == ["little"], "First test error: " + str(candidate("Mary had a little lamb", 4))      
    assert candidate("Mary had a little lamb", 3) == ["Mary", "lamb"], "Second test error: " + str(candidate("Mary had a little lamb", 3))  
    assert candidate("simple white space", 2) == [], "Third test error: " + str(candidate("simple white space", 2))      
    assert candidate("Hello world", 4) == ["world"], "Fourth test error: " + str(candidate("Hello world", 4))  
    assert candidate("Uncle sam", 3) == ["Uncle"], "Fifth test error: " + str(candidate("Uncle sam", 3))


    # Check some edge cases that are easy to work out by hand.
    assert candidate("", 4) == [], "1st edge test error: " + str(candidate("", 4))
    assert candidate("a b c d e f", 1) == ["b", "c", "d", "f"], "2nd edge test error: " + str(candidate("a b c d e f", 1))



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
