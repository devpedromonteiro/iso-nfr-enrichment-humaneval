
import unittest
import re
import sys
import math
import copy


def tri(n):
    """Return a list containing the first n + 1 Tribonacci values.

    Sequence definition:
    - tri(0) = 1
    - tri(1) = 3
    - tri(k) = 1 + k / 2, if k is even and k >= 2
    - tri(k) = tri(k - 1) + tri(k - 2) + tri(k + 1), if k is odd and k >= 3

    Examples:
    >>> tri(0)
    [1]
    >>> tri(3)
    [1, 3, 2, 8]
    """

    if isinstance(n, bool):
        raise TypeError("n must be a non-negative integer, not bool")
    if not isinstance(n, int):
        raise TypeError("n must be a non-negative integer")
    if n < 0:
        raise ValueError("n must be non-negative")

    result = [1]

    if n == 0:
        return result

    result.append(3)  # tri(1)

    if n == 1:
        return result

    for k in range(2, n + 1):
        if k % 2 == 0:
            value = 1 + k // 2
        else:
            # For odd k:
            # tri(k) = tri(k - 1) + tri(k - 2) + tri(k + 1)
            # and since k + 1 is even:
            # tri(k + 1) = 1 + (k + 1) / 2
            next_even_value = 1 + (k + 1) // 2
            value = result[k - 1] + result[k - 2] + next_even_value

        result.append(value)

    return result
candidate = tri


def check(candidate):

    # Check some simple cases
    
    assert candidate(3) == [1, 3, 2.0, 8.0]
    assert candidate(4) == [1, 3, 2.0, 8.0, 3.0]
    assert candidate(5) == [1, 3, 2.0, 8.0, 3.0, 15.0]
    assert candidate(6) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0]
    assert candidate(7) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0]
    assert candidate(8) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0]
    assert candidate(9) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0]
    assert candidate(20) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0, 6.0, 48.0, 7.0, 63.0, 8.0, 80.0, 9.0, 99.0, 10.0, 120.0, 11.0]

    # Check some edge cases that are easy to work out by hand.
    assert candidate(0) == [1]
    assert candidate(1) == [1, 3]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
