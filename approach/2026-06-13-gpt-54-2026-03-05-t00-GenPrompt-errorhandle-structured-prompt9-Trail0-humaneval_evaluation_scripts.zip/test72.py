
import unittest
import re
import sys
import math
import copy


def will_it_fly(q, w):
    '''
    Return True if q will fly, and False otherwise.

    An object q will fly if:
    - q is balanced (a palindromic list)
    - the sum of its elements is less than or equal to w

    Error handling:
    - q must be a list
    - w must be a number
    - all elements of q must be numbers
    '''
    if not isinstance(q, list):
        raise TypeError("q must be a list")

    if not isinstance(w, (int, float)):
        raise TypeError("w must be a number")

    for i, item in enumerate(q):
        if not isinstance(item, (int, float)):
            raise TypeError(f"q[{i}] must be a number")

    balanced = q == q[::-1]
    total_weight = sum(q)

    return balanced and total_weight <= w
candidate = will_it_fly


def check(candidate):

    # Check some simple cases
    assert candidate([3, 2, 3], 9) is True
    assert candidate([1, 2], 5) is False
    assert candidate([3], 5) is True
    assert candidate([3, 2, 3], 1) is False


    # Check some edge cases that are easy to work out by hand.
    assert candidate([1, 2, 3], 6) is False
    assert candidate([5], 5) is True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
