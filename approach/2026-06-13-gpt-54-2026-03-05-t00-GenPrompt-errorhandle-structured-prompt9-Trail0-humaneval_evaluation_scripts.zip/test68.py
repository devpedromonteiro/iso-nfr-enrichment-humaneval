
import unittest
import re
import sys
import math
import copy


def pluck(arr):
    """
    Given an array representing a branch of a tree that has non-negative integer nodes,
    return [smallest_even_value, index] for the smallest even value.
    If multiple nodes share that value, return the one with the smallest index.
    If the array is empty or contains no even values, return [].

    Error handling:
    - Raises TypeError if arr is not a list or tuple.
    - Raises TypeError if any element is not an integer.
    - Raises ValueError if any element is negative.
    """
    if arr is None:
        raise TypeError("arr must be a list or tuple, got None")

    if not isinstance(arr, (list, tuple)):
        raise TypeError(f"arr must be a list or tuple, got {type(arr).__name__}")

    smallest_even = None
    smallest_index = None

    for index, value in enumerate(arr):
        if not isinstance(value, int):
            raise TypeError(
                f"all elements must be integers; found {type(value).__name__} at index {index}"
            )
        if value < 0:
            raise ValueError(f"all elements must be non-negative; found {value} at index {index}")

        if value % 2 == 0:
            if smallest_even is None or value < smallest_even:
                smallest_even = value
                smallest_index = index

    if smallest_even is None:
        return []

    return [smallest_even, smallest_index]
candidate = pluck


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([4,2,3]) == [2, 1], "Error"
    assert candidate([1,2,3]) == [2, 1], "Error"
    assert candidate([]) == [], "Error"
    assert candidate([5, 0, 3, 0, 4, 2]) == [0, 1], "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([1, 2, 3, 0, 5, 3]) == [0, 3], "Error"
    assert candidate([5, 4, 8, 4 ,8]) == [4, 1], "Error"
    assert candidate([7, 6, 7, 1]) == [6, 1], "Error"
    assert candidate([7, 9, 7, 1]) == [], "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
