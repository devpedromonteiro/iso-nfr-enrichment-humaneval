
import unittest
import re
import sys
import math
import copy


def even_odd_palindrome(n):
    """
    Given a positive integer n, return a tuple containing the number of even and odd
    integer palindromes in the inclusive range [1, n].

    Example 1:
        Input: 3
        Output: (1, 2)

    Example 2:
        Input: 12
        Output: (4, 6)

    Constraints:
        1 <= n <= 10^3

    Raises:
        TypeError: If n is not an integer.
        ValueError: If n is outside the allowed range.
    """
    if not isinstance(n, int):
        raise TypeError(f"n must be an integer, got {type(n).__name__}")
    if isinstance(n, bool):
        raise TypeError("n must be an integer, not a boolean")
    if n < 1 or n > 10**3:
        raise ValueError("n must be between 1 and 10^3 inclusive")

    def is_palindrome(value):
        s = str(value)
        return s == s[::-1]

    even_count = 0
    odd_count = 0

    for i in range(1, n + 1):
        if is_palindrome(i):
            if i % 2 == 0:
                even_count += 1
            else:
                odd_count += 1

    return (even_count, odd_count)
candidate = even_odd_palindrome


def check(candidate):

    # Check some simple cases
    assert candidate(123) == (8, 13)
    assert candidate(12) == (4, 6)
    assert candidate(3) == (1, 2)
    assert candidate(63) == (6, 8)
    assert candidate(25) == (5, 6)
    assert candidate(19) == (4, 6)
    assert candidate(9) == (4, 5), "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1) == (0, 1), "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
