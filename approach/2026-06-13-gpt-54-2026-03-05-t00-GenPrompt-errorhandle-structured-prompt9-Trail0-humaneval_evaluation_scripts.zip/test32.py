
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[2] * x^2 + .... + xs[n] * x^n
    """
    if not isinstance(xs, list):
        raise TypeError("xs must be a list of numeric coefficients")
    if len(xs) == 0:
        raise ValueError("xs must not be empty")
    if not isinstance(x, (int, float)):
        raise TypeError("x must be a numeric value")

    for i, coeff in enumerate(xs):
        if not isinstance(coeff, (int, float)):
            raise TypeError(f"coefficient at index {i} must be numeric")

    return sum(coeff * math.pow(x, i) for i, coeff in enumerate(xs))


def find_zero(xs: list):
    """xs are coefficients of a polynomial.
    find_zero finds x such that poly(xs, x) == 0.
    find_zero returns only one zero point, even if there are many.

    Preconditions:
    - xs must be a non-empty list of numeric coefficients
    - xs must have an even number of coefficients
    - the leading coefficient (last coefficient) must be non-zero

    >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2)  # (x - 1) * (x - 2) * (x - 3)
    1.0
    """
    if not isinstance(xs, list):
        raise TypeError("xs must be a list of numeric coefficients")
    if len(xs) == 0:
        raise ValueError("xs must not be empty")
    if len(xs) % 2 != 0:
        raise ValueError("xs must contain an even number of coefficients")

    for i, coeff in enumerate(xs):
        if not isinstance(coeff, (int, float)):
            raise TypeError(f"coefficient at index {i} must be numeric")

    if xs[-1] == 0:
        raise ValueError("leading coefficient must be non-zero")

    # Degree is odd because number of coefficients is even.
    # Such a polynomial with non-zero leading coefficient must have at least one real root.
    # First, try to detect an exact root at x = 0.
    if poly(xs, 0.0) == 0:
        return 0.0

    # Find a bracketing interval [left, right] where the polynomial changes sign.
    left = -1.0
    right = 1.0

    try:
        f_left = poly(xs, left)
        f_right = poly(xs, right)
    except OverflowError as exc:
        raise OverflowError("polynomial evaluation overflowed while searching for a root") from exc

    max_iterations = 10_000
    iterations = 0

    while f_left * f_right > 0:
        iterations += 1
        if iterations > max_iterations:
            raise RuntimeError("failed to bracket a real root within iteration limit")

        left *= 2.0
        right *= 2.0

        try:
            f_left = poly(xs, left)
            f_right = poly(xs, right)
        except OverflowError as exc:
            raise OverflowError("polynomial evaluation overflowed while expanding search interval") from exc

    # Bisection method on the bracketing interval.
    tolerance = 1e-12
    max_bisection_iterations = 10_000

    for _ in range(max_bisection_iterations):
        mid = (left + right) / 2.0
        f_mid = poly(xs, mid)

        if abs(f_mid) < tolerance or abs(right - left) < tolerance:
            return mid

        if f_left * f_mid <= 0:
            right = mid
            f_right = f_mid
        else:
            left = mid
            f_left = f_mid

    raise RuntimeError("bisection did not converge to a root within iteration limit")
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
