
import unittest
import re
import sys
import math
import copy


def split_words(txt):
    '''
    Given a string of words, return a list of words split on whitespace, if no whitespaces exists in the text you
    should split on commas ',' if no commas exists you should return the number of lower-case letters with odd order in the
    alphabet, ord('a') = 0, ord('b') = 1, ... ord('z') = 25

    Examples
    split_words("Hello world!") â ["Hello", "world!"]
    split_words("Hello,world!") â ["Hello", "world!"]
    split_words("abcdef") == 3
    '''
    if not isinstance(txt, str):
        raise TypeError("txt must be a string")

    if txt == "":
        return 0

    if any(ch.isspace() for ch in txt):
        return txt.split()

    if "," in txt:
        return txt.split(",")

    count = 0
    for ch in txt:
        if 'a' <= ch <= 'z' and (ord(ch) - ord('a')) % 2 == 1:
            count += 1

    return count
candidate = split_words


def check(candidate):

    assert candidate("Hello world!") == ["Hello","world!"]
    assert candidate("Hello,world!") == ["Hello","world!"]
    assert candidate("Hello world,!") == ["Hello","world,!"]
    assert candidate("Hello,Hello,world !") == ["Hello,Hello,world","!"]
    assert candidate("abcdef") == 3
    assert candidate("aaabb") == 2
    assert candidate("aaaBb") == 1
    assert candidate("") == 0


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
