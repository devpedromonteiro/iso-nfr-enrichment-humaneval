
import unittest
import re
import sys
import math
import copy

from typing import List, Any


from typing import List, Any


def filter_integers(values: List[Any]) -> List[int]:
    """Filter a list of Python values, returning only integers.

    Args:
        values: A list containing arbitrary Python values.

    Returns:
        A list containing only integer values from the input.

    Raises:
        TypeError: If `values` is not a list.

    Notes:
        - Booleans are excluded, even though `bool` is a subclass of `int`.
        - Invalid input types are rejected explicitly.
    """
    if not isinstance(values, list):
        raise TypeError(
            f"values must be of type list, got {type(values).__name__}"
        )

    result: List[int] = []

    for value in values:
        if isinstance(value, bool):
            continue
        if isinstance(value, int):
            result.append(value)

    return result
candidate = filter_integers




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == []
    assert candidate([4, {}, [], 23.2, 9, 'adasd']) == [4, 9]
    assert candidate([3, 'c', 3, 3, 'a', 'b']) == [3, 3, 3]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
