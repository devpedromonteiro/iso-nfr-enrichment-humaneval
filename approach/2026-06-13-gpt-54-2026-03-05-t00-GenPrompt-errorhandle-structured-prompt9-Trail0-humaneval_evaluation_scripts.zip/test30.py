
import unittest
import re
import sys
import math
import copy



def get_positive(l: list):
    """Return only positive numbers in the list.

    >>> get_positive([-1, 2, -4, 5, 6])
    [2, 5, 6]
    >>> get_positive([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    [5, 3, 2, 3, 9, 123, 1]
    """
    if not isinstance(l, list):
        raise TypeError(f"Expected a list, got {type(l).__name__}")

    result = []
    for i, value in enumerate(l):
        if not isinstance(value, (int, float)):
            raise TypeError(
                f"All elements must be numeric; found {type(value).__name__} at index {i}"
            )
        if value > 0:
            result.append(value)

    return result
candidate = get_positive




METADATA = {}


def check(candidate):
    assert candidate([-1, -2, 4, 5, 6]) == [4, 5, 6]
    assert candidate([5, 3, -5, 2, 3, 3, 9, 0, 123, 1, -10]) == [5, 3, 2, 3, 3, 9, 123, 1]
    assert candidate([-1, -2]) == []
    assert candidate([]) == []



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
