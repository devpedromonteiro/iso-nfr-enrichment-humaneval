
import unittest
import re
import sys
import math
import copy


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and
    the second list is a list of integers. Use the two given lists to build the algebraic
    expression and return the evaluation of this expression.

    Supported operations:
        +   Addition
        -   Subtraction
        *   Multiplication
        //  Floor division
        **  Exponentiation

    Example:
        operator = ['+', '*', '-']
        operand = [2, 3, 4, 5]
        result = 2 + 3 * 4 - 5
        => 9
    """
    if not isinstance(operator, list):
        raise TypeError("operator must be a list")
    if not isinstance(operand, list):
        raise TypeError("operand must be a list")

    if len(operator) < 1:
        raise ValueError("operator list must contain at least one operator")
    if len(operand) < 2:
        raise ValueError("operand list must contain at least two operands")
    if len(operator) != len(operand) - 1:
        raise ValueError("length of operator must be exactly len(operand) - 1")

    valid_operators = {"+", "-", "*", "//", "**"}
    for op in operator:
        if not isinstance(op, str):
            raise TypeError("each operator must be a string")
        if op not in valid_operators:
            raise ValueError(f"unsupported operator: {op}")

    for value in operand:
        if not isinstance(value, int):
            raise TypeError("each operand must be an integer")
        if value < 0:
            raise ValueError("operands must be non-negative integers")

    expression_parts = [str(operand[0])]
    for op, value in zip(operator, operand[1:]):
        expression_parts.append(op)
        expression_parts.append(str(value))

    expression = " ".join(expression_parts)

    try:
        return eval(expression, {"__builtins__": None}, {})
    except ZeroDivisionError:
        raise ZeroDivisionError("floor division by zero in algebra expression")
    except OverflowError:
        raise OverflowError("numeric overflow while evaluating algebra expression")
    except SyntaxError as exc:
        raise ValueError(f"invalid algebra expression constructed: {expression}") from exc
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
