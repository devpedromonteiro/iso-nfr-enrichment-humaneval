
import unittest
import re
import sys
import math
import copy


def cycpattern_check(a, b):
    """Return True if b, or any cyclic rotation of b, is a substring of a.

    Examples:
        cycpattern_check("abcd", "abd") -> False
        cycpattern_check("hello", "ell") -> True
        cycpattern_check("whassup", "psus") -> False
        cycpattern_check("abab", "baa") -> True
        cycpattern_check("efef", "eeff") -> False
        cycpattern_check("himenss", "simen") -> True
    """
    if not isinstance(a, str):
        raise TypeError("Argument 'a' must be a string.")
    if not isinstance(b, str):
        raise TypeError("Argument 'b' must be a string.")

    if b == "":
        return True
    if len(b) > len(a):
        return False

    doubled = b + b
    for i in range(len(b)):
        rotation = doubled[i:i + len(b)]
        if rotation in a:
            return True

    return False
candidate = cycpattern_check


def check(candidate):

    # Check some simple cases
    #assert True, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    #assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert  candidate("xyzw","xyw") == False , "test #0"
    assert  candidate("yello","ell") == True , "test #1"
    assert  candidate("whattup","ptut") == False , "test #2"
    assert  candidate("efef","fee") == True , "test #3"
    assert  candidate("abab","aabb") == False , "test #4"
    assert  candidate("winemtt","tinem") == True , "test #5"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
