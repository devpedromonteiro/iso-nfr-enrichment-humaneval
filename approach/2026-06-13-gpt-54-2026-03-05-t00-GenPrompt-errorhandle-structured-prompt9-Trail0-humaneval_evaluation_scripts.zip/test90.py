
import unittest
import re
import sys
import math
import copy


def next_smallest(lst):
    """
    Return the 2nd smallest distinct integer in the list.

    Returns None if there is no such element.

    Examples:
        next_smallest([1, 2, 3, 4, 5]) == 2
        next_smallest([5, 1, 4, 3, 2]) == 2
        next_smallest([]) == None
        next_smallest([1, 1]) == None
    """
    if lst is None:
        raise TypeError("lst must be a list of integers, got None")

    if not isinstance(lst, list):
        raise TypeError(f"lst must be a list, got {type(lst).__name__}")

    if len(lst) == 0:
        return None

    for i, value in enumerate(lst):
        if not isinstance(value, int):
            raise TypeError(
                f"all elements must be integers; element at index {i} is {type(value).__name__}"
            )

    smallest = None
    second_smallest = None

    for value in lst:
        if smallest is None or value < smallest:
            if value != smallest:
                second_smallest = smallest
                smallest = value
        elif value != smallest and (second_smallest is None or value < second_smallest):
            second_smallest = value

    return second_smallest
candidate = next_smallest


def check(candidate):

    # Check some simple cases
    assert candidate([1, 2, 3, 4, 5]) == 2
    assert candidate([5, 1, 4, 3, 2]) == 2
    assert candidate([]) == None
    assert candidate([1, 1]) == None
    assert candidate([1,1,1,1,0]) == 1
    assert candidate([1, 0**0]) == None
    assert candidate([-35, 34, 12, -45]) == -35

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
