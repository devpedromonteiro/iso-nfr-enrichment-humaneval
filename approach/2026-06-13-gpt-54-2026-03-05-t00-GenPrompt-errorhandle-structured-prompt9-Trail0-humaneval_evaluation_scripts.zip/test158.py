
import unittest
import re
import sys
import math
import copy


def find_max(words):
    """Return the word with the highest number of unique characters.

    If multiple words have the same maximum number of unique characters,
    return the lexicographically smallest one.

    Args:
        words: A list of strings.

    Returns:
        A string from the input list.

    Raises:
        TypeError: If words is not a list or contains non-string elements.
        ValueError: If words is empty.
    """
    if not isinstance(words, list):
        raise TypeError("words must be a list of strings")

    if not words:
        raise ValueError("words must not be empty")

    for word in words:
        if not isinstance(word, str):
            raise TypeError("all elements in words must be strings")

    best_word = None
    best_unique_count = -1

    for word in words:
        unique_count = len(set(word))

        if unique_count > best_unique_count:
            best_word = word
            best_unique_count = unique_count
        elif unique_count == best_unique_count and word < best_word:
            best_word = word

    return best_word
candidate = find_max


def check(candidate):

    # Check some simple cases
    assert (candidate(["name", "of", "string"]) == "string"), "t1"
    assert (candidate(["name", "enam", "game"]) == "enam"), 't2'
    assert (candidate(["aaaaaaa", "bb", "cc"]) == "aaaaaaa"), 't3'
    assert (candidate(["abc", "cba"]) == "abc"), 't4'
    assert (candidate(["play", "this", "game", "of","footbott"]) == "footbott"), 't5'
    assert (candidate(["we", "are", "gonna", "rock"]) == "gonna"), 't6'
    assert (candidate(["we", "are", "a", "mad", "nation"]) == "nation"), 't7'
    assert (candidate(["this", "is", "a", "prrk"]) == "this"), 't8'

    # Check some edge cases that are easy to work out by hand.
    assert (candidate(["b"]) == "b"), 't9'
    assert (candidate(["play", "play", "play"]) == "play"), 't10'



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
