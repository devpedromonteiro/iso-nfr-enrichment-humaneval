
import unittest
import re
import sys
import math
import copy



def is_palindrome(text: str) -> bool:
    """
    Checks if given string is a palindrome.

    A palindrome reads the same forwards and backwards.

    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    >>> is_palindrome('abba')
    True
    >>> is_palindrome('abcba')
    True
    >>> is_palindrome(None)
    Traceback (most recent call last):
    ...
    TypeError: text must be a string
    >>> is_palindrome(123)
    Traceback (most recent call last):
    ...
    TypeError: text must be a string
    """
    if not isinstance(text, str):
        raise TypeError("text must be a string")

    return text == text[::-1]
candidate = is_palindrome




METADATA = {}


def check(candidate):
    assert candidate('') == True
    assert candidate('aba') == True
    assert candidate('aaaaa') == True
    assert candidate('zbcd') == False
    assert candidate('xywyx') == True
    assert candidate('xywyz') == False
    assert candidate('xywzx') == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
