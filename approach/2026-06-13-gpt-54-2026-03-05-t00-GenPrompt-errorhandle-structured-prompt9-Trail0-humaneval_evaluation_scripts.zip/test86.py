
import unittest
import re
import sys
import math
import copy


def anti_shuffle(s):
    """
    Write a function that takes a string and returns an ordered version of it.
    Ordered version of string, is a string where all words (separated by space)
    are replaced by a new word where all the characters arranged in
    ascending order based on ascii value.
    Note: You should keep the order of words and blank spaces in the sentence.

    For example:
    anti_shuffle('Hi') returns 'Hi'
    anti_shuffle('hello') returns 'ehllo'
    anti_shuffle('Hello World!!!') returns 'Hello !!!Wdlor'
    """
    if not isinstance(s, str):
        raise TypeError("anti_shuffle expects a string input")

    try:
        # split(' ') preserves the exact number and placement of spaces
        words = s.split(' ')
        sorted_words = [''.join(sorted(word)) for word in words]
        return ' '.join(sorted_words)
    except TypeError:
        # Re-raise specific sorting/type issues without swallowing them
        raise
    except Exception as exc:
        raise RuntimeError("anti_shuffle failed while processing the input") from exc
candidate = anti_shuffle


def check(candidate):

    # Check some simple cases
    assert candidate('Hi') == 'Hi'
    assert candidate('hello') == 'ehllo'
    assert candidate('number') == 'bemnru'
    assert candidate('abcd') == 'abcd'
    assert candidate('Hello World!!!') == 'Hello !!!Wdlor'
    assert candidate('') == ''
    assert candidate('Hi. My name is Mister Robot. How are you?') == '.Hi My aemn is Meirst .Rboot How aer ?ouy'
    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
