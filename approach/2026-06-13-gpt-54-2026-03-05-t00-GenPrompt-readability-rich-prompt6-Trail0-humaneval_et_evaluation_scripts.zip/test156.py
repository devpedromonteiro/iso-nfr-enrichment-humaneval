
import unittest


def int_to_mini_roman(number):
    """
    Convert a positive integer to its lowercase Roman numeral representation.

    Restrictions:
        1 <= number <= 1000

    Examples:
    >>> int_to_mini_roman(19)
    'xix'
    >>> int_to_mini_roman(152)
    'clii'
    >>> int_to_mini_roman(426)
    'cdxxvi'
    """
    if not 1 <= number <= 1000:
        raise ValueError("number must be between 1 and 1000")

    roman_value_pairs = [
        (1000, "m"),
        (900, "cm"),
        (500, "d"),
        (400, "cd"),
        (100, "c"),
        (90, "xc"),
        (50, "l"),
        (40, "xl"),
        (10, "x"),
        (9, "ix"),
        (5, "v"),
        (4, "iv"),
        (1, "i"),
    ]

    remaining_value = number
    roman_parts = []

    for value, symbol in roman_value_pairs:
        while remaining_value >= value:
            roman_parts.append(symbol)
            remaining_value -= value

    return "".join(roman_parts)
candidate = int_to_mini_roman


class Test(unittest.TestCase):
    def test(self):
        assert candidate(1000) == 'm'

    # Check some edge cases that are easy to work out by hand.
        assert candidate(641) == 'dcxli'
        assert candidate(520) == 'dxx'
        assert candidate(309) == 'cccix'
        assert candidate(600) == 'dc'
        assert candidate(892) == 'dcccxcii'
        assert candidate(94) == 'xciv'
        assert candidate(392) == 'cccxcii'
        assert candidate(991) == 'cmxci'
        assert candidate(894) == 'dcccxciv'
        assert candidate(426) == 'cdxxvi'
        assert candidate(43) == 'xliii'
        assert candidate(471) == 'cdlxxi'
        assert candidate(934) == 'cmxxxiv'
        assert candidate(555) == 'dlv'
        assert candidate(585) == 'dlxxxv'
        assert candidate(55) == 'lv'
        assert candidate(666) == 'dclxvi'
        assert candidate(563) == 'dlxiii'
        assert candidate(251) == 'ccli'
        assert candidate(394) == 'cccxciv'
        assert candidate(718) == 'dccxviii'
        assert candidate(50) == 'l'
        assert candidate(194) == 'cxciv'
        assert candidate(401) == 'cdi'
        assert candidate(90) == 'xc'
        assert candidate(667) == 'dclxvii'
        assert candidate(755) == 'dcclv'
        assert candidate(407) == 'cdvii'
        assert candidate(500) == 'd'
        assert candidate(162) == 'clxii'
        assert candidate(751) == 'dccli'
        assert candidate(543) == 'dxliii'
        assert candidate(899) == 'dcccxcix'
        assert candidate(907) == 'cmvii'
        assert candidate(883) == 'dccclxxxiii'
        assert candidate(526) == 'dxxvi'
        assert candidate(294) == 'ccxciv'
        assert candidate(333) == 'cccxxxiii'
        assert candidate(997) == 'cmxcvii'
        assert candidate(723) == 'dccxxiii'
        assert candidate(212) == 'ccxii'
        assert candidate(621) == 'dcxxi'
        assert candidate(970) == 'cmlxx'
        assert candidate(698) == 'dcxcviii'
        assert candidate(744) == 'dccxliv'
        assert candidate(533) == 'dxxxiii'
        assert candidate(152) == 'clii'
        assert candidate(958) == 'cmlviii'
        assert candidate(798) == 'dccxcviii'
        assert candidate(825) == 'dcccxxv'
        assert candidate(455) == 'cdlv'
        assert candidate(92) == 'xcii'
        assert candidate(662) == 'dclxii'
        assert candidate(772) == 'dcclxxii'
        assert candidate(887) == 'dccclxxxvii'
        assert candidate(315) == 'cccxv'
        assert candidate(115) == 'cxv'
        assert candidate(983) == 'cmlxxxiii'
        assert candidate(262) == 'cclxii'
        assert candidate(620) == 'dcxx'
        assert candidate(914) == 'cmxiv'
        assert candidate(153) == 'cliii'
        assert candidate(893) == 'dcccxciii'
        assert candidate(339) == 'cccxxxix'
        assert candidate(649) == 'dcxlix'
        assert candidate(290) == 'ccxc'
        assert candidate(820) == 'dcccxx'
        assert candidate(110) == 'cx'
        assert candidate(658) == 'dclviii'
        assert candidate(240) == 'ccxl'
        assert candidate(994) == 'cmxciv'
        assert candidate(7) == 'vii'
        assert candidate(629) == 'dcxxix'
        assert candidate(291) == 'ccxci'
        assert candidate(488) == 'cdlxxxviii'
        assert candidate(4) == 'iv'
        assert candidate(516) == 'dxvi'
        assert candidate(143) == 'cxliii'
        assert candidate(19) == 'xix'
        assert candidate(1) == 'i'
        assert candidate(556) == 'dlvi'
        assert candidate(679) == 'dclxxix'
        assert candidate(286) == 'cclxxxvi'
        assert candidate(964) == 'cmlxiv'
        assert candidate(99) == 'xcix'
        assert candidate(741) == 'dccxli'
        assert candidate(422) == 'cdxxii'
        assert candidate(149) == 'cxlix'
        assert candidate(756) == 'dcclvi'
        assert candidate(900) == 'cm'
        assert candidate(938) == 'cmxxxviii'
        assert candidate(663) == 'dclxiii'
        assert candidate(374) == 'ccclxxiv'
        assert candidate(377) == 'ccclxxvii'
        assert candidate(137) == 'cxxxvii'
        assert candidate(512) == 'dxii'
        assert candidate(897) == 'dcccxcvii'
        assert candidate(64) == 'lxiv'
        assert candidate(450) == 'cdl'
        assert candidate(464) == 'cdlxiv'
        assert candidate(218) == 'ccxviii'
        assert candidate(70) == 'lxx'
        assert candidate(918) == 'cmxviii'
        assert candidate(640) == 'dcxl'
        assert candidate(345) == 'cccxlv'
        assert candidate(875) == 'dccclxxv'
        assert candidate(40) == 'xl'
        assert candidate(990) == 'cmxc'
        assert candidate(470) == 'cdlxx'
        assert candidate(532) == 'dxxxii'
        assert candidate(209) == 'ccix'
        assert candidate(219) == 'ccxix'
        assert candidate(578) == 'dlxxviii'
        assert candidate(112) == 'cxii'
        assert candidate(166) == 'clxvi'
        assert candidate(904) == 'cmiv'
        assert candidate(221) == 'ccxxi'
        assert candidate(478) == 'cdlxxviii'
        assert candidate(398) == 'cccxcviii'
        assert candidate(233) == 'ccxxxiii'
        assert candidate(848) == 'dcccxlviii'
        assert candidate(623) == 'dcxxiii'
        assert candidate(727) == 'dccxxvii'
        assert candidate(165) == 'clxv'
        assert candidate(545) == 'dxlv'
        assert candidate(895) == 'dcccxcv'
        assert candidate(1000) == 'm'
        assert candidate(872) == 'dccclxxii'
        assert candidate(801) == 'dccci'
        assert candidate(320) == 'cccxx'
        assert candidate(766) == 'dcclxvi'

if __name__ == '__main__':
    unittest.main()
