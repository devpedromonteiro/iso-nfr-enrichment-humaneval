
import unittest
import re
import sys
import math
import copy


def specialFilter(numbers):
    """Return how many numbers are greater than 10 and have odd first and last digits."""

    def has_odd_first_and_last_digit(number):
        digit_text = str(abs(number))
        first_digit = int(digit_text[0])
        last_digit = int(digit_text[-1])

        return first_digit % 2 == 1 and last_digit % 2 == 1

    matching_count = 0

    for number in numbers:
        if number > 10 and has_odd_first_and_last_digit(number):
            matching_count += 1

    return matching_count
candidate = specialFilter


def check(candidate):

    # Check some simple cases
    assert candidate([5, -2, 1, -5]) == 0  
    assert candidate([15, -73, 14, -15]) == 1
    assert candidate([33, -2, -3, 45, 21, 109]) == 2
    assert candidate([43, -12, 93, 125, 121, 109]) == 4
    assert candidate([71, -2, -33, 75, 21, 19]) == 3


    # Check some edge cases that are easy to work out by hand.
    assert candidate([1]) == 0              
    assert candidate([]) == 0                   



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
