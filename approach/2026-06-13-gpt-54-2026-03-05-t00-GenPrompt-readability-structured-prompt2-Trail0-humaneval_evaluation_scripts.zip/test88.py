
import unittest
import re
import sys
import math
import copy


def sort_array(numbers):
    """
    Return a sorted copy of the input list.

    The sort order depends on the sum of the first and last elements:
    - ascending if the sum is odd
    - descending if the sum is even

    The original list is not modified.
    """
    if len(numbers) <= 1:
        return numbers.copy()

    first_value = numbers[0]
    last_value = numbers[-1]
    edge_sum = first_value + last_value
    should_sort_descending = edge_sum % 2 == 0

    return sorted(numbers, reverse=should_sort_descending)
candidate = sort_array


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([]) == [], "Error"
    assert candidate([5]) == [5], "Error"
    assert candidate([2, 4, 3, 0, 1, 5]) == [0, 1, 2, 3, 4, 5], "Error"
    assert candidate([2, 4, 3, 0, 1, 5, 6]) == [6, 5, 4, 3, 2, 1, 0], "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([2, 1]) == [1, 2], "Error"
    assert candidate([15, 42, 87, 32 ,11, 0]) == [0, 11, 15, 32, 42, 87], "Error"
    assert candidate([21, 14, 23, 11]) == [23, 21, 14, 11], "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
