
import unittest
import re
import sys
import math
import copy


def special_factorial(n):
    """Return the Brazilian factorial of a positive integer.

    The Brazilian factorial is defined as:
        n! * (n-1)! * (n-2)! * ... * 1!

    Example:
    >>> special_factorial(4)
    288
    """
    product_of_factorials = 1
    current_factorial = 1

    for number in range(1, n + 1):
        current_factorial *= number
        product_of_factorials *= current_factorial

    return product_of_factorials
candidate = special_factorial


def check(candidate):

    # Check some simple cases
    assert candidate(4) == 288, "Test 4"
    assert candidate(5) == 34560, "Test 5"
    assert candidate(7) == 125411328000, "Test 7"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1) == 1, "Test 1"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
