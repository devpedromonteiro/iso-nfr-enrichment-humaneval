
import unittest
import re
import sys
import math
import copy



def strlen(text: str) -> int:
    """Return the number of characters in the given string.

    >>> strlen('')
    0
    >>> strlen('abc')
    3
    """
    return len(text)
candidate = strlen




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == 0
    assert candidate('x') == 1
    assert candidate('asdasnakj') == 9


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
