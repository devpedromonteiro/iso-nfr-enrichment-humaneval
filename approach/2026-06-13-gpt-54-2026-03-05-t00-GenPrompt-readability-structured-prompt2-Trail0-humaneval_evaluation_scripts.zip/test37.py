
import unittest
import re
import sys
import math
import copy



def sort_even(values: list):
    """Return a list where values at even indices are sorted, while odd indices stay unchanged.

    The elements at indices 0, 2, 4, ... are collected, sorted, and then placed back into
    their original even positions. Elements at odd indices are left untouched.

    >>> sort_even([1, 2, 3])
    [1, 2, 3]
    >>> sort_even([5, 6, 3, 4])
    [3, 6, 5, 4]
    """
    result = values.copy()
    even_index_values = sorted(values[::2])
    result[::2] = even_index_values
    return result
candidate = sort_even




METADATA = {}


def check(candidate):
    assert tuple(candidate([1, 2, 3])) == tuple([1, 2, 3])
    assert tuple(candidate([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])) == tuple([-10, 3, -5, 2, -3, 3, 5, 0, 9, 1, 123])
    assert tuple(candidate([5, 8, -12, 4, 23, 2, 3, 11, 12, -10])) == tuple([-12, 8, 3, 4, 5, 2, 12, 11, 23, -10])



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
