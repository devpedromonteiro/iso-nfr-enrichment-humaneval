
import unittest
import re
import sys
import math
import copy



def is_palindrome(string: str) -> bool:
    """ Test if given string is a palindrome """
    return string == string[::-1]


def is_palindrome(text: str) -> bool:
    """Return True if the given text reads the same forwards and backwards."""
    return text == text[::-1]


def make_palindrome(text: str) -> str:
    """Return the shortest palindrome that starts with the given text.

    The function finds the longest suffix of ``text`` that is already a
    palindrome. It then appends the reverse of the remaining prefix.

    Examples:
        >>> make_palindrome('')
        ''
        >>> make_palindrome('cat')
        'catac'
        >>> make_palindrome('cata')
        'catac'
    """
    for suffix_start in range(len(text)):
        suffix = text[suffix_start:]
        if is_palindrome(suffix):
            prefix = text[:suffix_start]
            return text + prefix[::-1]

    return text
candidate = make_palindrome




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == ''
    assert candidate('x') == 'x'
    assert candidate('xyz') == 'xyzyx'
    assert candidate('xyx') == 'xyx'
    assert candidate('jerry') == 'jerryrrej'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
