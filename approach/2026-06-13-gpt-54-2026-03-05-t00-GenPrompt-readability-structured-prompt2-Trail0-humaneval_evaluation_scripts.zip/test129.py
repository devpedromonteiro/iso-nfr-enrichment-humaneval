
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Given a grid with N rows and N columns (N >= 2) and a positive integer k,
    each cell of the grid contains a unique value from 1 to N * N.

    Return the lexicographically smallest sequence of values obtainable by
    walking through exactly k cells, starting from any cell and moving only
    up, down, left, or right at each step.
    """
    grid_size = len(grid)

    value_to_position = {}
    for row_index in range(grid_size):
        for column_index in range(grid_size):
            cell_value = grid[row_index][column_index]
            value_to_position[cell_value] = (row_index, column_index)

    def get_neighbors(row, column):
        neighbors = []

        if row > 0:
            neighbors.append((row - 1, column))
        if row < grid_size - 1:
            neighbors.append((row + 1, column))
        if column > 0:
            neighbors.append((row, column - 1))
        if column < grid_size - 1:
            neighbors.append((row, column + 1))

        return neighbors

    smallest_value = 1
    start_row, start_column = value_to_position[smallest_value]

    path_values = [smallest_value]
    current_positions = {(start_row, start_column)}

    for _ in range(k - 1):
        next_value = None
        next_positions = set()

        for row, column in current_positions:
            for neighbor_row, neighbor_column in get_neighbors(row, column):
                neighbor_value = grid[neighbor_row][neighbor_column]

                if next_value is None or neighbor_value < next_value:
                    next_value = neighbor_value
                    next_positions = {(neighbor_row, neighbor_column)}
                elif neighbor_value == next_value:
                    next_positions.add((neighbor_row, neighbor_column))

        path_values.append(next_value)
        current_positions = next_positions

    return path_values
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
