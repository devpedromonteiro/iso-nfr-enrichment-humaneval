
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    Return the number of index triples (i, j, k), with 1 <= i < j < k <= n,
    such that:

        a[x] = x^2 - x + 1
        a[i] + a[j] + a[k] is divisible by 3

    Observation:
    For any index x:
        x^2 - x = x(x - 1)

    Since x and x - 1 are consecutive integers, one of them is even, and
    modulo 3 the pattern of a[x] repeats every 3 indices:

        x % 3 == 0 -> a[x] % 3 == 1
        x % 3 == 1 -> a[x] % 3 == 1
        x % 3 == 2 -> a[x] % 3 == 0

    So:
        - indices congruent to 2 mod 3 contribute values divisible by 3
        - all other indices contribute values congruent to 1 mod 3

    A triple sum is divisible by 3 only when:
        1) all three values are 0 mod 3
        2) all three values are 1 mod 3

    Therefore, the answer is:
        C(count_zero_mod_3, 3) + C(count_one_mod_3, 3)
    """

    def combinations_of_three(count):
        """Return the number of ways to choose 3 items from count items."""
        if count < 3:
            return 0
        return count * (count - 1) * (count - 2) // 6

    count_zero_mod_3 = n // 3
    count_one_mod_3 = n - count_zero_mod_3

    return (
        combinations_of_three(count_zero_mod_3)
        + combinations_of_three(count_one_mod_3)
    )
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
