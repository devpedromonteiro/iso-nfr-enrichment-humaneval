
import unittest
import re
import sys
import math
import copy


def split_words(text):
    """
    Return words from a string based on the first available separator.

    Rules:
    1. If the string contains whitespace, split on whitespace.
    2. Otherwise, if the string contains commas, split on commas.
    3. Otherwise, return the count of lowercase letters whose alphabet index is odd:
       a=0, b=1, ..., z=25.

    Examples:
        split_words("Hello world!") -> ["Hello", "world!"]
        split_words("Hello,world!") -> ["Hello", "world!"]
        split_words("abcdef") -> 3
    """
    contains_whitespace = any(character.isspace() for character in text)
    if contains_whitespace:
        return text.split()

    contains_comma = "," in text
    if contains_comma:
        return text.split(",")

    odd_index_lowercase_count = 0
    for character in text:
        if character.islower():
            alphabet_index = ord(character) - ord("a")
            if alphabet_index % 2 == 1:
                odd_index_lowercase_count += 1

    return odd_index_lowercase_count
candidate = split_words


def check(candidate):

    assert candidate("Hello world!") == ["Hello","world!"]
    assert candidate("Hello,world!") == ["Hello","world!"]
    assert candidate("Hello world,!") == ["Hello","world,!"]
    assert candidate("Hello,Hello,world !") == ["Hello,Hello,world","!"]
    assert candidate("abcdef") == 3
    assert candidate("aaabb") == 2
    assert candidate("aaaBb") == 1
    assert candidate("") == 0


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
