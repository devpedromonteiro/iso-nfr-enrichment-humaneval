
import unittest
import re
import sys
import math
import copy


def encode(message):
    """
    Encode a message by:
    1. Swapping the case of every letter.
    2. Replacing vowels with the letter two positions ahead
       in the alphabet, preserving the swapped case.

    Assumes the input contains only letters and spaces.

    Examples:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """
    vowel_replacements = {
        "a": "c",
        "e": "g",
        "i": "k",
        "o": "q",
        "u": "w",
        "A": "C",
        "E": "G",
        "I": "K",
        "O": "Q",
        "U": "W",
    }

    encoded_characters = []

    for character in message:
        swapped_character = character.swapcase()
        encoded_character = vowel_replacements.get(
            swapped_character, swapped_character
        )
        encoded_characters.append(encoded_character)

    return "".join(encoded_characters)
candidate = encode


def check(candidate):

    # Check some simple cases
    assert candidate('TEST') == 'tgst', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('Mudasir') == 'mWDCSKR', "This prints if this assert fails 2 (good for debugging!)"
    assert candidate('YES') == 'ygs', "This prints if this assert fails 3 (good for debugging!)"
    
    # Check some edge cases that are easy to work out by hand.
    assert candidate('This is a message') == 'tHKS KS C MGSSCGG', "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate("I DoNt KnOw WhAt tO WrItE") == 'k dQnT kNqW wHcT Tq wRkTg', "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
