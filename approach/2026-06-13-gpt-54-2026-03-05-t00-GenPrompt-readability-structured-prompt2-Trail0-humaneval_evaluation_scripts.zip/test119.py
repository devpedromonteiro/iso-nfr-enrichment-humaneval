
import unittest
import re
import sys
import math
import copy


def match_parens(strings):
    """
    Determine whether two parentheses strings can be concatenated in some order
    to form a balanced parentheses string.

    A balanced string must:
    - never have more closing parentheses than opening parentheses at any point
    - end with the same number of opening and closing parentheses

    Args:
        strings: A list containing exactly two strings made of '(' and ')'.

    Returns:
        'Yes' if either concatenation order forms a balanced string, otherwise 'No'.
    """

    def is_balanced(parentheses_string):
        open_count = 0

        for character in parentheses_string:
            if character == '(':
                open_count += 1
            else:
                open_count -= 1

            if open_count < 0:
                return False

        return open_count == 0

    first_string, second_string = strings

    if is_balanced(first_string + second_string):
        return 'Yes'

    if is_balanced(second_string + first_string):
        return 'Yes'

    return 'No'
candidate = match_parens


def check(candidate):

    # Check some simple cases
    assert candidate(['()(', ')']) == 'Yes'
    assert candidate([')', ')']) == 'No'
    assert candidate(['(()(())', '())())']) == 'No'
    assert candidate([')())', '(()()(']) == 'Yes'
    assert candidate(['(())))', '(()())((']) == 'Yes'
    assert candidate(['()', '())']) == 'No'
    assert candidate(['(()(', '()))()']) == 'Yes'
    assert candidate(['((((', '((())']) == 'No'
    assert candidate([')(()', '(()(']) == 'No'
    assert candidate([')(', ')(']) == 'No'
    

    # Check some edge cases that are easy to work out by hand.
    assert candidate(['(', ')']) == 'Yes'
    assert candidate([')', '(']) == 'Yes' 



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
