
import unittest
import re
import sys
import math
import copy


def make_a_pile(number_of_levels):
    """
    Given a positive integer n, build a pile with n levels of stones.

    The first level has n stones.
    Each following level has 2 more stones than the previous one, which keeps
    the parity (odd/even) consistent with the starting value.

    Examples:
    >>> make_a_pile(3)
    [3, 5, 7]
    >>> make_a_pile(4)
    [4, 6, 8, 10]
    """
    pile = []

    for level_index in range(number_of_levels):
        stones_in_level = number_of_levels + (2 * level_index)
        pile.append(stones_in_level)

    return pile
candidate = make_a_pile


def check(candidate):

    # Check some simple cases
    assert candidate(3) == [3, 5, 7], "Test 3"
    assert candidate(4) == [4,6,8,10], "Test 4"
    assert candidate(5) == [5, 7, 9, 11, 13]
    assert candidate(6) == [6, 8, 10, 12, 14, 16]
    assert candidate(8) == [8, 10, 12, 14, 16, 18, 20, 22]

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
