
import unittest
import re
import sys
import math
import copy


def is_multiply_prime(number):
    """Return True if number is the product of exactly 3 prime numbers, else False."""
    
    def is_prime(value):
        if value < 2:
            return False
        for divisor in range(2, int(value ** 0.5) + 1):
            if value % divisor == 0:
                return False
        return True

    prime_factor_count = 0
    remaining_value = number

    for candidate_factor in range(2, number + 1):
        while remaining_value % candidate_factor == 0:
            if not is_prime(candidate_factor):
                return False
            prime_factor_count += 1
            remaining_value //= candidate_factor

            if prime_factor_count > 3:
                return False

        if remaining_value == 1:
            break

    return prime_factor_count == 3
candidate = is_multiply_prime


def check(candidate):

    assert candidate(5) == False
    assert candidate(30) == True
    assert candidate(8) == True
    assert candidate(10) == False
    assert candidate(125) == True
    assert candidate(3 * 5 * 7) == True
    assert candidate(3 * 6 * 7) == False
    assert candidate(9 * 9 * 9) == False
    assert candidate(11 * 9 * 9) == False
    assert candidate(11 * 13 * 7) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
