
import unittest
import re
import sys
import math
import copy


import re


def is_bored(text):
    """
    Count how many sentences start with the word "I".

    A sentence is delimited by '.', '?' or '!'.

    Examples:
    >>> is_bored("Hello world")
    0
    >>> is_bored("The sky is blue. The sun is shining. I love this weather")
    1
    """
    sentence_delimiters = r"[.!?]"
    sentences = re.split(sentence_delimiters, text)

    boredom_count = 0

    for sentence in sentences:
        stripped_sentence = sentence.strip()
        if stripped_sentence.startswith("I " ) or stripped_sentence == "I":
            boredom_count += 1

    return boredom_count
candidate = is_bored


def check(candidate):

    # Check some simple cases
    assert candidate("Hello world") == 0, "Test 1"
    assert candidate("Is the sky blue?") == 0, "Test 2"
    assert candidate("I love It !") == 1, "Test 3"
    assert candidate("bIt") == 0, "Test 4"
    assert candidate("I feel good today. I will be productive. will kill It") == 2, "Test 5"
    assert candidate("You and I are going for a walk") == 0, "Test 6"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
