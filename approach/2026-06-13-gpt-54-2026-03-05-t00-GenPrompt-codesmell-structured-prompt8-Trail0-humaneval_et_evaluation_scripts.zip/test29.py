
import unittest

from typing import List


from typing import List


def _starts_with_prefix(value: str, prefix: str) -> bool:
    """Return True if value starts with prefix."""
    return value.startswith(prefix)


def filter_by_prefix(strings: List[str], prefix: str) -> List[str]:
    """Filter strings that start with the given prefix.

    >>> filter_by_prefix([], 'a')
    []
    >>> filter_by_prefix(['abc', 'bcd', 'cde', 'array'], 'a')
    ['abc', 'array']
    """
    return [string for string in strings if _starts_with_prefix(string, prefix)]
candidate = filter_by_prefix


class Test(unittest.TestCase):
    def test(self):
        assert candidate(['wbcyhow', 'othmuu', 'qstccywt', 'kzzzvqn q', 'NyK', 'boroja'], 'k') == ['kzzzvqn q']
        assert candidate(['xdse', 'ugcr', 'ryodayvs', 'kszuzounvl', 'oYzwIJ', 'wtzwmn'], 'ry') == ['ryodayvs']
        assert candidate(['toiqdq', 'zruhovo', 'ywpfnzjn', 'jccetilhqn', 'vjV', 'kaccrqxfh'], 'to') == ['toiqdq']
        assert candidate(['qyoihv', 'yteiiholb', 'uwu', 'a q', 'CHmYVyhgIJ', 'juvxhncva'], 'C') == ['CHmYVyhgIJ']
        assert candidate(['fwlkekpt', 'vfm', 'hqh', 'xgnhled n xh', 'rOGoIPc', 'quiulyxju'], 'r') == ['rOGoIPc']
        assert candidate(['peyspr', 'qvcoz', 'fmrriodo', 'kjots', 'oCgS', 'nyl'], 'n') == ['nyl']
        assert candidate(['txy', 'usf', 'zmzujred', 'pecojrvylq', 'yJYdIxZ', 'bpmfxnkhf'], 'z') == ['zmzujred']
        assert candidate(['fchencp', 'wmj', 'jykg', 'jftlcgnzejjx', 'fhSQ', 'hqclz'], 'wm') == ['wmj']
        assert candidate(['zlcm', 'vjs', 'cdmwpyhhq', 'wyrhjezju', 'cGhAevMA', 'rupqmt'], 'c') == ['cdmwpyhhq', 'cGhAevMA']
        assert candidate([], 'hc') == []
        assert candidate(['nqgktjn', 'xtxpk', 'lkfbr', 'vmiehvntp', 'cYAkCvcpNa', 'rtoi'], 'x') == ['xtxpk']
        assert candidate(['cpgg', 'zrjalcpcq', 'wmlssl', 'yvakkcbfgixw', 'gwIKDjSr', 'pkfxygez'], 'pk') == ['pkfxygez']
        assert candidate([], 'gie') == []
        assert candidate(['tyv', 'nhl', 'wazvpsyy', 'qqkonlxaxvq', 'bnhl', 'uoropiqs'], 'wa') == ['wazvpsyy']
        assert candidate(['afu', 'pyp', 'gsrfiuns', 'rnbbkq', 'tGioT', 'qqe'], 'tG') == ['tGioT']
        assert candidate(['irzdwce', 'bnhe', 'rkqwvkq', 'y coftmixsda', 'xbWDAJt', 'uhqao'], 'uh') == ['uhqao']
        assert candidate(['sqys', 'uox', 'oyacj', 'vic', 'FNqEzTW', 'sdwwffrnz'], 'v') == ['vic']
        assert candidate(['tgv', 'zoqjzxz', 'ggag', 'svcyybsowr', 'cyrevICpiBew', 'ehk'], 'eh') == ['ehk']
        assert candidate(['mgidnv', 'fymr', 'eibxot', 'isyoucwqx', 'mVOnTZURbGo', 'ydmyf'], 'i') == ['isyoucwqx']
        assert candidate(['ejvijw', 'eoxwtu', 'umqxd', 'sdmtayil', 'QgHN', 'ifcnud'], 'um') == ['umqxd']
        assert candidate(['fxg', 'jukpejtka', 'rpmwg', 'ilqottxzh', 'PLG', 'bzdkq'], 'PL') == ['PLG']
        assert candidate(['hdnssea', 'xgfsteg', 'zzneoai', 'lazplbekb', 'XZw', 'iarfshq'], 'z') == ['zzneoai']
        assert candidate(['cqvkhvmb', 'vaa', 'wczaocewv', 'ycl', 'XgktBQUCCPDB', 'lcxq'], 'w') == ['wczaocewv']
        assert candidate(['jyhbqgw', 'htupvoy', 'eckf', 'opbkslrajig', 'tmYxwj', 'meblapkay'], 'm') == ['meblapkay']
        assert candidate(['qqzyx', 'ovmjsvswm', 'naqo', 'usnzwotzfjcc', 'NSJBG', 'ses'], 'N') == ['NSJBG']
        assert candidate(['bli', 'jqadqid', 'hxrer', ' elgpsxj', 'iTjWqdTbg', 'mizoj'], 'jq') == ['jqadqid']
        assert candidate(['igzsmxi', 'oxpaalwcz', 'pzjt', 'rqdkukrz', 'xskN', 'pdyqbxmc'], 'o') == ['oxpaalwcz']
        assert candidate(['gsoetlwn', 'ttj', 'objeem', 'tkbykjgfy', 'YbI', 'bkim'], 'Y') == ['YbI']
        assert candidate([], 's') == []
        assert candidate(['casok', 'zxh', 'jub', 'dliq', 'HgnRd', 'wyulic'], 'ju') == ['jub']
        assert candidate(['udf', 'rfghktjte', 'lobb', 'sxmkvlpy', 'HIoTNeRQWfmv', 'cgro'], 'H') == ['HIoTNeRQWfmv']
        assert candidate(['mfwzfsmby', 'dwuzmct', 'ruthl', 'j imluth cl', 'nuvGiAJLP', 'craa'], 'm') == ['mfwzfsmby']
        assert candidate(['seokdz', 'lpolypj', 'ppzsdn', 'uahan', 'cYuJalGKw', 'irggysg'], 'cY') == ['cYuJalGKw']
        assert candidate(['ssbkamkk', 'lgpsyakx', 'aqmrmmuyv', 'ofhe', 'cTuIVLXWsW', 'ixf'], 'i') == ['ixf']
        assert candidate(['dmqz', 'ttabgee', 'zihftohzc', 'deq', 'UnRUHV', 'zukgpwfv'], 'dm') == ['dmqz']
        assert candidate(['tqlmggeoh', 'chbwix', 'gviiyy', 'tsjuuu', 'vmFVBNr', 'wwscnomb'], 'ts') == ['tsjuuu']
        assert candidate(['lcwnaov', 'uxw', 'lkihigyv', 'dqmjseye', 'BJn', 'vrndtlalh'], 'B') == ['BJn']
        assert candidate([], 'john') == []
        assert candidate(['qtzxo', 'viico', 'qofoy', 'xyjnzdf', 'qTQG', 'meksggu'], 'me') == ['meksggu']
        assert candidate(['sqkfcgh', 'oixs', 'rudfiv', 'vmsmqh', 'DZEQsnr', 'yrzygmwu'], 'sq') == ['sqkfcgh']
        assert candidate(['nsg', 'wawe', 'cqthmr', 'uwwmlsbk', 'YnQJuXrcT', 'omsppagp'], 'w') == ['wawe']
        assert candidate(['kyuxiq', 'wyfepirq', 'cehrtir', 'wfzh', 'FrcId', 'himyfdqie'], 'k') == ['kyuxiq']
        assert candidate(['gqbsehnje', 'qztb', 'likrhcml', 'rytnjkrgifvk', 'qbb', 'ezbppjfp'], 'l') == ['likrhcml']
        assert candidate(['wwt', 'dgrwpdu', 'gawfftfjx', 'jjztu', 'TPqzQrODL', 'bds'], 'j') == ['jjztu']
        assert candidate(['awshlaxo', 'gctskq', 'bowsrq', 'nnaqclkpv', 'xjEeDyISwmKk', 'cloohvs'], 'aw') == ['awshlaxo']
        assert candidate(['szqdfjr', 'zbyjp', 'ikquotia', 'hojzypa', 'eIABxMPRoXm', 'bua'], 'eI') == ['eIABxMPRoXm']
        assert candidate(['fcxaqtk', 'kiq', 'vyjv', 'kvr p', 'tUyaOR', 'iuddamr'], 'fc') == ['fcxaqtk']
        assert candidate(['uanqtt', 'fmpmtbsl', 'zqplbgx', 'tchhyvij', 'bEDBxyFFDy', 'pickhvpek'], 'fm') == ['fmpmtbsl']
        assert candidate(['zvai', 'kifq', 'hkoctip', 'dvwygdwurwv', 'LXihHXCqSoU', 'aqeahjcen'], 'h') == ['hkoctip']
        assert candidate(['byzhtjgiz', 'onwb', 'dchcrk', 'gu utuxthdp', 'beDiG', 'uhqw'], 'u') == ['uhqw']
        assert candidate([], 'c') == []
        assert candidate([], 'qw') == []
        assert candidate(['oabealcy', 'ccwuzfcoc', 'rehkhtg', 'gxakvg hani', 'UhGHg', 'zisfdy'], 'oa') == ['oabealcy']
        assert candidate(['uvbohls', 'jbazmg', 'yxgaiuqqi', 'eqyhjffvaco', 'Jmpqhvo', 'mlyxv'], 'yx') == ['yxgaiuqqi']
        assert candidate(['ibyvdglgi', 'wkaqgyqeh', 'inzobsq', 'etqomfbislt', 'JtEBq', 'dsrsoz'], 'e') == ['etqomfbislt']
        assert candidate(['qgiibqz', 'vykph', 'letgrjnd', 'cedd', 'MeWkrjScxDrn', 'vdxohuy'], 'c') == ['cedd']
        assert candidate(['kblytu', 'bvvgfhhbe', 'zxjgedvs', 'nvux x', 'uhlGguXAf', 'mvial'], 'n') == ['nvux x']
        assert candidate(['jbneyqsj', 'gviykjdu', 'pswphm', 'cnt', 'lyKbacda', 'oicpibhjx'], 'jb') == ['jbneyqsj']
        assert candidate(['jwijiho', 'evcrpanw', 'lrkn', 'usiz', 'oYjwjgzErc', 'tpwwjq'], 't') == ['tpwwjq']
        assert candidate(['hbarvrcrl', 'eviehxs', 'wwtdcu', 'r ono', 'GfbsHgsBFv', 'dyotymgx'], 'hb') == ['hbarvrcrl']
        assert candidate(['pgjcmrqlw', 'ztspgrrhd', 'swsc', 'mydvh', 'oks', 'zjczfp'], 'ok') == ['oks']
        assert candidate(['bia', 'egbiz', 'klpwxcmha', 'bdob', 'jJxddYQzNYs', 'vjp'], 'kl') == ['klpwxcmha']
        assert candidate(['wxgbz', 'xngcbuox', 'ssxncvux', 'rdrfy', 'sJAru', 'xzvprs'], 'x') == ['xngcbuox', 'xzvprs']
        assert candidate([], 'odh') == []
        assert candidate(['qeqokuci', 'colz', 'tpj', 'auulejia ', 'rVKO', 'znvm'], 'a') == ['auulejia ']
        assert candidate(['cnpqa', 'uhaarqbbh', 'qobuyyx', 'xulkcyte', 'hPr', 'zqkiyijo'], 'qo') == ['qobuyyx']
        assert candidate([], 'kck') == []
        assert candidate(['rmffwoz', 'rcbutsfc', 'vyf', 'tkakwlrrtp', 'cFDAlaxwO', 'eoi'], 'e') == ['eoi']
        assert candidate(['mxi', 'xtngipq', 'ngipl', 'mqrsjitry', 'GHdKrX', 'wdccw'], 'G') == ['GHdKrX']
        assert candidate(['ikvxcd', 'mkamr', 'unpsh', 'fzdlqxm gkg', 'BKtwnDFeEBX', 'lletpc'], 'BK') == ['BKtwnDFeEBX']
        assert candidate(['txjkaklfe', 'gksvm', 'xvhe', 'rwwmcmnjjcvx', 'rhfs', 'mnvskyq'], 'r') == ['rwwmcmnjjcvx', 'rhfs']
        assert candidate(['muw', 'rpnwajd', 'seu', 'yjnnvaonjgci', 'BpSOmnYGSyg', 'ltyqaalcg'], 'l') == ['ltyqaalcg']
        assert candidate(['xfu', 'ipy', 'zfz', 'fzpznw', 'FHoQrwGqZ', 'abjfkg'], 'xf') == ['xfu']
        assert candidate(['fpwrcpro', 'hhyvnr', 'mvpncphvq', 'ttpqh', 'ZQXxpmdqP', 'vezzw'], 'v') == ['vezzw']
        assert candidate(['flsefr', 'glfgtb', 'fdgmgvt', 'lwmg lppmxh', 'dxAHGqRsF', 'lrhgvxd'], 'g') == ['glfgtb']
        assert candidate(['rvuscib', 'unkejbwq', 'hvsvw', 'qzgijxtkbqt', 'zbuxOcWiHonS', 'qdhzmxxwf'], 'u') == ['unkejbwq']
        assert candidate(['btyxi', 'oku', 'rchkjlhjo', 'xtj', 'azAL', 'cfxm'], 'x') == ['xtj']
        assert candidate(['uujdfeu', 'jmzwsdlgk', 'hxc', 'wwda', 'IsUPEstl', 'zvhglg'], 'w') == ['wwda']
        assert candidate(['xxevx', 'vknumn', 'jqhnzqsq', 'bsc', 'uSSKZoCNFV', 'kdows'], 'uS') == ['uSSKZoCNFV']
        assert candidate(['abvpkzf', 'fcirpc', 'gxnrata', 'dtcutzv', 'ScIYWrBEF', 'vguow'], 'gx') == ['gxnrata']
        assert candidate(['uqfnmzuj', 'oyzhjseob', 'vizqz', 'pgc', 'tuxAjQLZ', 'qiutw'], 'vi') == ['vizqz']
        assert candidate([], 'dx') == []
        assert candidate(['owgus', 'jsfluk', 'axhpsdxnb', 'ujokse', 'uKLzdIVSCU', 'nyapgx'], 'uj') == ['ujokse']
        assert candidate(['uaon', 'gykyot', 'xxbq', 'kibuvgizegwt', 'MWxf', 'byimdy'], 'u') == ['uaon']
        assert candidate(['zlburwim', 'dzfs', 'jsj', 'cpdlqaeptiev', 'hXmqAdUOU', 'wsvuncog'], 'c') == ['cpdlqaeptiev']
        assert candidate(['jmdmbzu', 'zgzgzqkq', 'aorlwyw', 'rbab', 'kaqkeYHk', 'vkogvkp'], 'a') == ['aorlwyw']
        assert candidate(['cgzso', 'ivppapd', 'kkeqpfkl', ' inzrjwhfm', 'GRtJkYLV', 'tuopqbq'], 'c') == ['cgzso']
        assert candidate(['ztdsuik', 'gcqvc', 'vjhedlu', 'smqctzfc', 'TsBKZPed', 'daqggucw'], 'zt') == ['ztdsuik']
        assert candidate(['inefoe', 'xzsz', 'linopmjk', 'ryijajsshzv', 'gHlWOUCmA', 'xyajofu'], 'xy') == ['xyajofu']
        assert candidate(['urfzx', 'vhmtbb', 'gqvdtr', 'jjx', 'VZgaaGz', 'esp'], 'jj') == ['jjx']
        assert candidate(['cthx', 'evksuu', 'srblluzch', 'lqo', 'DWdb', 'nbdirmt'], 'D') == ['DWdb']
        assert candidate(['qbsmz', 'ilote', 'tob', 'ulzmxw', 'VPmoaDr', 'ywojsi'], 'to') == ['tob']
        assert candidate(['takt', 'mtomfj', 'cdklj', 'cxajdd', 'DxahSoeqKi', 'lstxs'], 't') == ['takt']
        assert candidate(['tglaob', 'nyi', 'itxdcu', 'bzovjkcdz', 'knXz', 'tqonafkf'], 'tg') == ['tglaob']
        assert candidate(['vgtiqmb', 'eqmpymk', 'gzsybf', 'stdajypfavzx', 'IoUJeghCvc', 'cutliglim'], 'eq') == ['eqmpymk']
        assert candidate(['rtndcjyk', 'oaqr', 'scebutbql', 'kmkiqgrjy', 'laBRYkQAQOIO', 'oakw'], 'la') == ['laBRYkQAQOIO']
        assert candidate(['wawon', 'wsmuwzw', 'fuuslu', 'zeij', 'nicryZgyEFvc', 'fjp'], 'w') == ['wawon', 'wsmuwzw']
        assert candidate(['hczszwml', 'ugp', 'lzaey', 'ziyikv', 'AclMUxFaNSQt', 'tufpegwem'], 't') == ['tufpegwem']
        assert candidate(['qxkneuoa', 'tkvgceljq', 'bilgbt', 'ofjglm', 'MqU', 'gtqvtdknr'], 'Mq') == ['MqU']
        assert candidate(['nyaydhh', 'hkhslt', 'hfdv', 'flxfent', 'CVKIJI', 'erunhk'], 'h') == ['hkhslt', 'hfdv']
        assert candidate(['apyhwl', 'roiy', 'lat', 'dkleltc', 'UvSqf', 'lqxywthua'], 'la') == ['lat']
        assert candidate(['mdwukqmpo', 'oetsc', 'esfoei', 'itpxdewm', 'ajArhWSi', 'metufl'], 'it') == ['itpxdewm']
        assert candidate(['pfdgvqag', 'hmiqxmpkj', 'efvmuanp', 'tibjohy', 'AlLcUQZWTRcQ', 'eocerqij'], 'Al') == ['AlLcUQZWTRcQ']
        assert candidate(['moylvee', 'qaiist', 'pdcyxad', 'etfun', 'vXGPRQlcP', 'yihwxms'], 'p') == ['pdcyxad']
        assert candidate(['xxx', 'asd', 'xxy', 'john doe', 'xxxAAA', 'xxx'], 'xxx') == ['xxx', 'xxxAAA', 'xxx']
        assert candidate([], 'rqq') == []
        assert candidate(['trk', 'rnkkzfmt', 'keu', 'abtxfqezq', 'XAIdEaH', 'vjggq'], 'ke') == ['keu']
        assert candidate([], 'b') == []
        assert candidate(['sywqmszik', 'gwucwa', 'oowgn', 'evxovemkzh', 'rcOPuCiS', 'uqetyh'], 'ev') == ['evxovemkzh']
        assert candidate(['qosr', 'wtrc', 'rac', 'zmcag', 'nyUGvIfC', 'ptnnknp'], 'w') == ['wtrc']
        assert candidate(['xkjgxyv', 'yff', 'jvwayhssp', 'qmv', 'YeGMxVUOXDrO', 'trgiwtz'], 'tr') == ['trgiwtz']
        assert candidate(['hnrppxq', 'uxf', 'ief', 'ebuycg l', 'MyxeZXPwM', 'pbet'], 'eb') == ['ebuycg l']

if __name__ == '__main__':
    unittest.main()
