
import unittest
import re
import sys
import math
import copy



def max_element(values: list):
    """Return the maximum element in the list.

    >>> max_element([1, 2, 3])
    3
    >>> max_element([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    123
    """
    maximum_value = values[0]

    for value in values[1:]:
        if value > maximum_value:
            maximum_value = value

    return maximum_value
candidate = max_element




METADATA = {}


def check(candidate):
    assert candidate([1, 2, 3]) == 3
    assert candidate([5, 3, -5, 2, -3, 3, 9, 0, 124, 1, -10]) == 124


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
