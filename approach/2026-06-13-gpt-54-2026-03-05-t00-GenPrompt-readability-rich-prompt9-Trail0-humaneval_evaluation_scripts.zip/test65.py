
import unittest
import re
import sys
import math
import copy


def circular_shift(number, shift_amount):
    """Return the digits of ``number`` circularly shifted to the right.

    The result is returned as a string.

    Rules:
    - Shift the digits of ``number`` to the right by ``shift_amount``.
    - If ``shift_amount`` is greater than the number of digits, return the digits reversed.

    >>> circular_shift(12, 1)
    '21'
    >>> circular_shift(12, 2)
    '12'
    """
    digits = str(number)
    digit_count = len(digits)

    if shift_amount > digit_count:
        return digits[::-1]

    effective_shift = shift_amount % digit_count

    if effective_shift == 0:
        return digits

    right_part = digits[-effective_shift:]
    left_part = digits[:-effective_shift]

    return right_part + left_part
candidate = circular_shift


def check(candidate):

    # Check some simple cases
    assert candidate(100, 2) == "001"
    assert candidate(12, 2) == "12"
    assert candidate(97, 8) == "79"
    assert candidate(12, 1) == "21", "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(11, 101) == "11", "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
