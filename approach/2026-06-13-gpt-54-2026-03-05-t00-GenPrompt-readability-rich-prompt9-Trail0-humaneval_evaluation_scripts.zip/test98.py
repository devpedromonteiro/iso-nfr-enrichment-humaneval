
import unittest
import re
import sys
import math
import copy


def count_upper(text):
    """
    Count uppercase vowels that appear at even indices in a string.

    Examples:
        count_upper("aBCdEf") -> 1
        count_upper("abcdefg") -> 0
        count_upper("dBBE") -> 0
    """
    uppercase_vowels = {"A", "E", "I", "O", "U"}
    uppercase_vowel_count = 0

    for index, character in enumerate(text):
        is_even_index = index % 2 == 0
        is_uppercase_vowel = character in uppercase_vowels

        if is_even_index and is_uppercase_vowel:
            uppercase_vowel_count += 1

    return uppercase_vowel_count
candidate = count_upper


def check(candidate):

    # Check some simple cases
    assert candidate('aBCdEf')  == 1
    assert candidate('abcdefg') == 0
    assert candidate('dBBE') == 0
    assert candidate('B')  == 0
    assert candidate('U')  == 1
    assert candidate('') == 0
    assert candidate('EEEE') == 2

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
