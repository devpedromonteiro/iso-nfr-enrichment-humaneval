
import unittest
import re
import sys
import math
import copy


def prod_signs(numbers):
    """
    Return the sum of absolute values multiplied by the combined sign.

    The combined sign is:
    - 1 if all numbers are positive
    - -1 if there is an odd number of negative values
    - 0 if any value is zero

    Return None for an empty list.

    Examples:
    >>> prod_signs([1, 2, 2, -4])
    -9
    >>> prod_signs([0, 1])
    0
    >>> prod_signs([])
    None
    """
    if not numbers:
        return None

    total_magnitude = 0
    overall_sign = 1

    for number in numbers:
        total_magnitude += abs(number)

        if number == 0:
            overall_sign = 0
        elif number < 0:
            overall_sign *= -1

    return total_magnitude * overall_sign
candidate = prod_signs


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1, 2, 2, -4]) == -9
    assert candidate([0, 1]) == 0
    assert candidate([1, 1, 1, 2, 3, -1, 1]) == -10
    assert candidate([]) == None
    assert candidate([2, 4,1, 2, -1, -1, 9]) == 20
    assert candidate([-1, 1, -1, 1]) == 4
    assert candidate([-1, 1, 1, 1]) == -4
    assert candidate([-1, 1, 1, 0]) == 0

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
