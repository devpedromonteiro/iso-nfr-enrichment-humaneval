
import unittest
import re
import sys
import math
import copy


def even_odd_palindrome(n):
    """
    Given a positive integer n, return a tuple containing:
    - the number of even integer palindromes in the range 1 to n, inclusive
    - the number of odd integer palindromes in the range 1 to n, inclusive

    Example 1:
        Input: 3
        Output: (1, 2)

    Example 2:
        Input: 12
        Output: (4, 6)
    """

    def is_palindrome(number):
        number_as_text = str(number)
        return number_as_text == number_as_text[::-1]

    even_palindrome_count = 0
    odd_palindrome_count = 0

    for number in range(1, n + 1):
        if not is_palindrome(number):
            continue

        if number % 2 == 0:
            even_palindrome_count += 1
        else:
            odd_palindrome_count += 1

    return even_palindrome_count, odd_palindrome_count
candidate = even_odd_palindrome


def check(candidate):

    # Check some simple cases
    assert candidate(123) == (8, 13)
    assert candidate(12) == (4, 6)
    assert candidate(3) == (1, 2)
    assert candidate(63) == (6, 8)
    assert candidate(25) == (5, 6)
    assert candidate(19) == (4, 6)
    assert candidate(9) == (4, 5), "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1) == (0, 1), "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
