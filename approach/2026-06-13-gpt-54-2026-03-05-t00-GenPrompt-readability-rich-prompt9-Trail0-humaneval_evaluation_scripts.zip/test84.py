
import unittest
import re
import sys
import math
import copy


def solve(number):
    """Return the binary representation of the sum of decimal digits of ``number``.

    Examples:
        solve(1000) -> "1"
        solve(150)  -> "110"
        solve(147)  -> "1100"
    """
    digit_sum = sum(int(digit) for digit in str(number))
    binary_representation = bin(digit_sum)[2:]
    return binary_representation
candidate = solve


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(1000) == "1", "Error"
    assert candidate(150) == "110", "Error"
    assert candidate(147) == "1100", "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate(333) == "1001", "Error"
    assert candidate(963) == "10010", "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
