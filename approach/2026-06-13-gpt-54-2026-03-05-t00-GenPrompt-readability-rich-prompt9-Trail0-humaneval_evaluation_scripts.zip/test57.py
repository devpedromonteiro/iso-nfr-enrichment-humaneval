
import unittest
import re
import sys
import math
import copy



def monotonic(values: list) -> bool:
    """Return True if the list is monotonically increasing or decreasing.

    A list is considered monotonic when its elements never switch direction:
    they only stay the same or increase, or only stay the same or decrease.

    >>> monotonic([1, 2, 4, 20])
    True
    >>> monotonic([1, 20, 4, 10])
    False
    >>> monotonic([4, 1, 0, -10])
    True
    """
    is_non_decreasing = True
    is_non_increasing = True

    for index in range(1, len(values)):
        previous_value = values[index - 1]
        current_value = values[index]

        if current_value < previous_value:
            is_non_decreasing = False

        if current_value > previous_value:
            is_non_increasing = False

    return is_non_decreasing or is_non_increasing
candidate = monotonic




METADATA = {}


def check(candidate):
    assert candidate([1, 2, 4, 10]) == True
    assert candidate([1, 2, 4, 20]) == True
    assert candidate([1, 20, 4, 10]) == False
    assert candidate([4, 1, 0, -10]) == True
    assert candidate([4, 1, 1, 0]) == True
    assert candidate([1, 2, 3, 2, 5, 60]) == False
    assert candidate([1, 2, 3, 4, 5, 60]) == True
    assert candidate([9, 9, 9, 9]) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
