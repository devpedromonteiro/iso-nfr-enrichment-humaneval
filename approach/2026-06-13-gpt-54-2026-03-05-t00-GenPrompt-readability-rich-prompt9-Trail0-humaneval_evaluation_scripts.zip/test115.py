
import unittest
import re
import sys
import math
import copy


import math

def max_fill(grid, capacity):
    """
    Return the total number of bucket lowers needed to empty all wells.

    Each row in `grid` represents one well.
    Each `1` in a row represents one unit of water in that well.
    A well with `n` units of water requires `ceil(n / capacity)` bucket lowers.

    Example:
        grid = [[0, 0, 1, 0], [0, 1, 0, 0], [1, 1, 1, 1]]
        capacity = 1
        result = 6
    """
    total_bucket_lowers = 0

    for well in grid:
        water_units_in_well = sum(well)
        bucket_lowers_for_well = math.ceil(water_units_in_well / capacity)
        total_bucket_lowers += bucket_lowers_for_well

    return total_bucket_lowers
candidate = max_fill


def check(candidate):


    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([[0,0,1,0], [0,1,0,0], [1,1,1,1]], 1) == 6, "Error"
    assert candidate([[0,0,1,1], [0,0,0,0], [1,1,1,1], [0,1,1,1]], 2) == 5, "Error"
    assert candidate([[0,0,0], [0,0,0]], 5) == 0, "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([[1,1,1,1], [1,1,1,1]], 2) == 4, "Error"
    assert candidate([[1,1,1,1], [1,1,1,1]], 9) == 2, "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
