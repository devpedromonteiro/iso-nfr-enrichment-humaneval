
import unittest
import re
import sys
import math
import copy


def count_nums(numbers):
    """
    Return the count of integers whose digit sum is greater than 0.

    For negative numbers, the first digit keeps the negative sign.
    Example:
    -123 -> -1 + 2 + 3 = 4

    >>> count_nums([]) == 0
    True
    >>> count_nums([-1, 11, -11]) == 1
    True
    >>> count_nums([1, 1, 2]) == 3
    True
    """

    def signed_digit_sum(number):
        digit_text = str(number)

        if digit_text[0] == "-":
            total = -int(digit_text[1])
            remaining_digits = digit_text[2:]
        else:
            total = int(digit_text[0])
            remaining_digits = digit_text[1:]

        for digit in remaining_digits:
            total += int(digit)

        return total

    count = 0

    for number in numbers:
        if signed_digit_sum(number) > 0:
            count += 1

    return count
candidate = count_nums


def check(candidate):

    # Check some simple cases
    assert candidate([]) == 0
    assert candidate([-1, -2, 0]) == 0
    assert candidate([1, 1, 2, -2, 3, 4, 5]) == 6
    assert candidate([1, 6, 9, -6, 0, 1, 5]) == 5
    assert candidate([1, 100, 98, -7, 1, -1]) == 4
    assert candidate([12, 23, 34, -45, -56, 0]) == 5
    assert candidate([-0, 1**0]) == 1
    assert candidate([1]) == 1

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
