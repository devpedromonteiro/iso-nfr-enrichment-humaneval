
import unittest
import re
import sys
import math
import copy



import math


def sum_squares(numbers):
    """Return the sum of squares after rounding each number up.

    Each value in the input list is first rounded using math.ceil,
    then squared, and finally all squared values are summed.

    Examples:
        [1, 2, 3] -> 14
        [1, 4, 9] -> 98
        [1, 3, 5, 7] -> 84
        [1.4, 4.2, 0] -> 29
        [-2.4, 1, 1] -> 6
    """
    total_sum = 0

    for number in numbers:
        rounded_number = math.ceil(number)
        squared_number = rounded_number ** 2
        total_sum += squared_number

    return total_sum
candidate = sum_squares


def check(candidate):

    # Check some simple cases
    assert candidate([1,2,3])==14, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1.0,2,3])==14, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,3,5,7])==84, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1.4,4.2,0])==29, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([-2.4,1,1])==6, "This prints if this assert fails 1 (good for debugging!)"

    assert candidate([100,1,15,2])==10230, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([10000,10000])==200000000, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([-1.4,4.6,6.3])==75, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([-1.4,17.9,18.9,19.9])==1086, "This prints if this assert fails 1 (good for debugging!)"


    # Check some edge cases that are easy to work out by hand.
    assert candidate([0])==0, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([-1])==1, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([-1,1,0])==2, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
