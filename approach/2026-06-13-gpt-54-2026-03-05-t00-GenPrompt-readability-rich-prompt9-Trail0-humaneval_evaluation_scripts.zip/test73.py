
import unittest
import re
import sys
import math
import copy


def smallest_change(numbers):
    """
    Return the minimum number of element changes needed to make `numbers` a palindrome.

    A palindrome reads the same forwards and backwards. For each mirrored pair,
    if the values differ, one change is enough to make them match.

    Examples:
        smallest_change([1, 2, 3, 5, 4, 7, 9, 6]) == 4
        smallest_change([1, 2, 3, 4, 3, 2, 2]) == 1
        smallest_change([1, 2, 3, 2, 1]) == 0
    """
    change_count = 0
    left_index = 0
    right_index = len(numbers) - 1

    while left_index < right_index:
        if numbers[left_index] != numbers[right_index]:
            change_count += 1

        left_index += 1
        right_index -= 1

    return change_count
candidate = smallest_change


def check(candidate):

    # Check some simple cases
    assert candidate([1,2,3,5,4,7,9,6]) == 4
    assert candidate([1, 2, 3, 4, 3, 2, 2]) == 1
    assert candidate([1, 4, 2]) == 1
    assert candidate([1, 4, 4, 2]) == 1

    # Check some edge cases that are easy to work out by hand.
    assert candidate([1, 2, 3, 2, 1]) == 0
    assert candidate([3, 1, 1, 3]) == 0
    assert candidate([1]) == 0
    assert candidate([0, 1]) == 1



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
