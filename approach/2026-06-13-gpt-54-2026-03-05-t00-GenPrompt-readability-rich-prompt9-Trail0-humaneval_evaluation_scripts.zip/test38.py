
import unittest
import re
import sys
import math
import copy



def encode_cyclic(s: str):
    """
    returns encoded string by cycling groups of three characters.
    """
    # split string to groups. Each of length 3.
    groups = [s[(3 * i):min((3 * i + 3), len(s))] for i in range((len(s) + 2) // 3)]
    # cycle elements in each group. Unless group has fewer elements than 3.
    groups = [(group[1:] + group[0]) if len(group) == 3 else group for group in groups]
    return "".join(groups)


def encode_cyclic(text: str) -> str:
    """
    Encode a string by rotating each group of three characters to the left.

    Example:
        "abcdef" -> "bcaefd"
    """
    group_size = 3
    encoded_groups = []

    for start_index in range(0, len(text), group_size):
        group = text[start_index:start_index + group_size]

        if len(group) == group_size:
            rotated_group = group[1:] + group[0]
            encoded_groups.append(rotated_group)
        else:
            encoded_groups.append(group)

    return "".join(encoded_groups)


def decode_cyclic(text: str) -> str:
    """
    Decode a string produced by encode_cyclic.

    Each full group of three characters is rotated one position to the right.
    Groups shorter than three characters are left unchanged.

    Example:
        "bcaefd" -> "abcdef"
    """
    group_size = 3
    decoded_groups = []

    for start_index in range(0, len(text), group_size):
        group = text[start_index:start_index + group_size]

        if len(group) == group_size:
            restored_group = group[-1] + group[:-1]
            decoded_groups.append(restored_group)
        else:
            decoded_groups.append(group)

    return "".join(decoded_groups)
candidate = decode_cyclic




METADATA = {}


def check(candidate):
    from random import randint, choice
    import string

    letters = string.ascii_lowercase
    for _ in range(100):
        str = ''.join(choice(letters) for i in range(randint(10, 20)))
        encoded_str = encode_cyclic(str)
        assert candidate(encoded_str) == str



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
