
import unittest
import re
import sys
import math
import copy


def check_if_last_char_is_a_letter(text):
    """
    Return True if the last character of the string is a letter
    and forms a single-character word. Otherwise, return False.

    A word is defined as a group of characters separated by spaces.

    Examples:
    check_if_last_char_is_a_letter("apple pie")   -> False
    check_if_last_char_is_a_letter("apple pi e")  -> True
    check_if_last_char_is_a_letter("apple pi e ") -> False
    check_if_last_char_is_a_letter("")            -> False
    """
    if text == "":
        return False

    last_character = text[-1]

    if not last_character.isalpha():
        return False

    if len(text) == 1:
        return True

    character_before_last = text[-2]
    return character_before_last == " "
candidate = check_if_last_char_is_a_letter


def check(candidate):

    # Check some simple cases
    assert candidate("apple") == False
    assert candidate("apple pi e") == True
    assert candidate("eeeee") == False
    assert candidate("A") == True
    assert candidate("Pumpkin pie ") == False
    assert candidate("Pumpkin pie 1") == False
    assert candidate("") == False
    assert candidate("eeeee e ") == False
    assert candidate("apple pie") == False
    assert candidate("apple pi e ") == False

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
