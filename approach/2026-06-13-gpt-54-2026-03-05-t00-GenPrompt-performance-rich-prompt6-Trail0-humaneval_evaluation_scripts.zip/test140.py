
import unittest
import re
import sys
import math
import copy


def fix_spaces(text):
    result = []
    i = 0
    n = len(text)

    while i < n:
        if text[i] != ' ':
            result.append(text[i])
            i += 1
            continue

        j = i
        while j < n and text[j] == ' ':
            j += 1

        count = j - i
        if count > 2:
            result.append('-')
        else:
            result.extend('_' for _ in range(count))

        i = j

    return ''.join(result)
candidate = fix_spaces


def check(candidate):

    # Check some simple cases
    assert candidate("Example") == "Example", "This prints if this assert fails 1 (good for debugging!)"
    assert candidate("Mudasir Hanif ") == "Mudasir_Hanif_", "This prints if this assert fails 2 (good for debugging!)"
    assert candidate("Yellow Yellow  Dirty  Fellow") == "Yellow_Yellow__Dirty__Fellow", "This prints if this assert fails 3 (good for debugging!)"
    
    # Check some edge cases that are easy to work out by hand.
    assert candidate("Exa   mple") == "Exa-mple", "This prints if this assert fails 4 (good for debugging!)"
    assert candidate("   Exa 1 2 2 mple") == "-Exa_1_2_2_mple", "This prints if this assert fails 4 (good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
