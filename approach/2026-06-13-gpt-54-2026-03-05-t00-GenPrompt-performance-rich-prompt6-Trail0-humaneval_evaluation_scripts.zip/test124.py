
import unittest
import re
import sys
import math
import copy


def valid_date(date):
    """Validate a date string in mm-dd-yyyy format."""
    if not date or len(date) != 10:
        return False

    # Required format: mm-dd-yyyy
    if date[2] != '-' or date[5] != '-':
        return False

    mm = date[:2]
    dd = date[3:5]
    yyyy = date[6:10]

    # Ensure all numeric parts contain only digits
    if not (mm.isdigit() and dd.isdigit() and yyyy.isdigit()):
        return False

    month = int(mm)
    day = int(dd)

    if month < 1 or month > 12:
        return False

    # Days per month, with February allowed up to 29 as specified
    if month == 2:
        max_day = 29
    elif month in (4, 6, 9, 11):
        max_day = 30
    else:
        max_day = 31

    return 1 <= day <= max_day
candidate = valid_date


def check(candidate):

    # Check some simple cases
    assert candidate('03-11-2000') == True

    assert candidate('15-01-2012') == False

    assert candidate('04-0-2040') == False

    assert candidate('06-04-2020') == True

    assert candidate('01-01-2007') == True

    assert candidate('03-32-2011') == False

    assert candidate('') == False

    assert candidate('04-31-3000') == False

    assert candidate('06-06-2005') == True

    assert candidate('21-31-2000') == False

    assert candidate('04-12-2003') == True

    assert candidate('04122003') == False

    assert candidate('20030412') == False

    assert candidate('2003-04') == False

    assert candidate('2003-04-12') == False

    assert candidate('04-2003') == False


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
