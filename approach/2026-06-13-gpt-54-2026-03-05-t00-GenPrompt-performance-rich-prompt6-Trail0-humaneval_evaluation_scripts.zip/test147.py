
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    You are given a positive integer n. You have to create an integer array a of length n.
    For each i (1 â¤ i â¤ n), the value of a[i] = i * i - i + 1.
    Return the number of triples (a[i], a[j], a[k]) where i < j < k and
    a[i] + a[j] + a[k] is a multiple of 3.

    Optimized approach:
    - Observe a[i] mod 3 depends only on i mod 3:
        i = 1 -> 1
        i = 2 -> 0
        i = 0 -> 1
      So values are only congruent to 0 or 1 modulo 3.
    - A triple sum is divisible by 3 only when residues are:
        (0, 0, 0) or (1, 1, 1)
    - Count how many terms fall into each residue class, then compute combinations.

    Time complexity: O(1)
    Space complexity: O(1)
    """
    if n < 3:
        return 0

    # Count indices i in [1..n] such that a[i] % 3 == 0.
    # This happens exactly when i % 3 == 2.
    count0 = (n + 1) // 3

    # All remaining terms have residue 1 modulo 3.
    count1 = n - count0

    def comb3(x):
        return x * (x - 1) * (x - 2) // 6 if x >= 3 else 0

    return comb3(count0) + comb3(count1)
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
