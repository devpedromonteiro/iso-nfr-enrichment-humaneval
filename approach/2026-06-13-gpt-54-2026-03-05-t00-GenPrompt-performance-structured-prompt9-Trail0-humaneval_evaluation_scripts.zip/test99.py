
import unittest
import re
import sys
import math
import copy


def closest_integer(value):
    s = value.strip()

    if '.' not in s:
        return int(s)

    neg = s[0] == '-'
    if s[0] in '+-':
        body = s[1:]
    else:
        body = s

    int_part, frac_part = body.split('.', 1)

    if not int_part:
        int_part = '0'

    base = int(int_part)

    if not frac_part or all(ch == '0' for ch in frac_part):
        return -base if neg else base

    first = frac_part[0]
    rest = frac_part[1:]

    if first < '5':
        return -base if neg else base

    if first > '5':
        return -(base + 1) if neg else (base + 1)

    if any(ch != '0' for ch in rest):
        return -(base + 1) if neg else (base + 1)

    return -(base + 1) if neg else (base + 1)
candidate = closest_integer


def check(candidate):

    # Check some simple cases
    assert candidate("10") == 10, "Test 1"
    assert candidate("14.5") == 15, "Test 2"
    assert candidate("-15.5") == -16, "Test 3"
    assert candidate("15.3") == 15, "Test 3"

    # Check some edge cases that are easy to work out by hand.
    assert candidate("0") == 0, "Test 0"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
