
import unittest
import re
import sys
import math
import copy


def count_nums(arr):
    count = 0
    for n in arr:
        x = abs(n)
        digit_sum = 0

        if x == 0:
            digit_sum = 0
        else:
            digit_sum = -(x % 10) if n < 0 else (x % 10)
            x //= 10
            while x:
                digit_sum += x % 10
                x //= 10

        if digit_sum > 0:
            count += 1

    return count
candidate = count_nums


def check(candidate):

    # Check some simple cases
    assert candidate([]) == 0
    assert candidate([-1, -2, 0]) == 0
    assert candidate([1, 1, 2, -2, 3, 4, 5]) == 6
    assert candidate([1, 6, 9, -6, 0, 1, 5]) == 5
    assert candidate([1, 100, 98, -7, 1, -1]) == 4
    assert candidate([12, 23, 34, -45, -56, 0]) == 5
    assert candidate([-0, 1**0]) == 1
    assert candidate([1]) == 1

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
