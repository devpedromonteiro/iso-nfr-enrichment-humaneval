
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Given a grid with N rows and N columns (N >= 2) and a positive integer k,
    each cell of the grid contains a value. Every integer in the range [1, N * N]
    inclusive appears exactly once on the cells of the grid.

    Return the lexicographically minimum path of length k, where moves are allowed
    between edge-adjacent cells and cells may be revisited.
    """
    n = len(grid)

    # Map each value to its position for O(1) access by value.
    pos = [None] * (n * n + 1)
    for i in range(n):
        row = grid[i]
        for j in range(n):
            pos[row[j]] = (i, j)

    # The first value of the optimal path must be 1, since all values are unique
    # and lexicographic order is minimized first by the first element.
    start_val = 1
    x, y = pos[start_val]

    if k == 1:
        return [start_val]

    # Precompute the minimum-valued neighbor for every cell.
    # Then repeatedly following that choice is optimal:
    # after fixing the current prefix, the next element should be as small as possible,
    # and future moves are independent because revisiting is allowed.
    best_neighbor = [[0] * n for _ in range(n)]

    for i in range(n):
        for j in range(n):
            best = float('inf')
            if i > 0:
                v = grid[i - 1][j]
                if v < best:
                    best = v
            if i + 1 < n:
                v = grid[i + 1][j]
                if v < best:
                    best = v
            if j > 0:
                v = grid[i][j - 1]
                if v < best:
                    best = v
            if j + 1 < n:
                v = grid[i][j + 1]
                if v < best:
                    best = v
            best_neighbor[i][j] = best

    result = [0] * k
    result[0] = start_val

    for idx in range(1, k):
        nxt = best_neighbor[x][y]
        result[idx] = nxt
        x, y = pos[nxt]

    return result
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
