
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def rescale_to_unit(numbers: List[float]) -> List[float]:
    """Given a list of numbers (of at least two elements), apply a linear transform
    such that the smallest number becomes 0 and the largest becomes 1.

    >>> rescale_to_unit([1.0, 2.0, 3.0, 4.0, 5.0])
    [0.0, 0.25, 0.5, 0.75, 1.0]
    """
    if numbers is None:
        raise TypeError("numbers must be a list of numeric values, got None")

    if not isinstance(numbers, list):
        raise TypeError(f"numbers must be of type list, got {type(numbers).__name__}")

    if len(numbers) < 2:
        raise ValueError("numbers must contain at least two elements")

    for i, value in enumerate(numbers):
        if not isinstance(value, (int, float)):
            raise TypeError(
                f"all elements must be numeric (int or float); "
                f"element at index {i} is {type(value).__name__}"
            )

    minimum = min(numbers)
    maximum = max(numbers)

    if minimum == maximum:
        raise ValueError("cannot rescale a list where all values are equal")

    scale = maximum - minimum
    return [(value - minimum) / scale for value in numbers]
candidate = rescale_to_unit




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([2.0, 49.9]) == [0.0, 1.0]
    assert candidate([100.0, 49.9]) == [1.0, 0.0]
    assert candidate([1.0, 2.0, 3.0, 4.0, 5.0]) == [0.0, 0.25, 0.5, 0.75, 1.0]
    assert candidate([2.0, 1.0, 5.0, 3.0, 4.0]) == [0.25, 0.0, 1.0, 0.5, 0.75]
    assert candidate([12.0, 11.0, 15.0, 13.0, 14.0]) == [0.25, 0.0, 1.0, 0.5, 0.75]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
