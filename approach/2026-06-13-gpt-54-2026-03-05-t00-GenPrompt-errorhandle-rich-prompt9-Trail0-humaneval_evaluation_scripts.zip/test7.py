
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    """Filter an input list of strings for ones that contain the given substring.

    Args:
        strings: A list of strings to search.
        substring: The substring to match.

    Returns:
        A new list containing only the strings that include `substring`.

    Raises:
        TypeError: If `strings` is not a list, if `substring` is not a string,
            or if any element in `strings` is not a string.

    >>> filter_by_substring([], 'a')
    []
    >>> filter_by_substring(['abc', 'bacd', 'cde', 'array'], 'a')
    ['abc', 'bacd', 'array']
    """
    if not isinstance(strings, list):
        raise TypeError(
            f"strings must be of type list, got {type(strings).__name__}"
        )

    if not isinstance(substring, str):
        raise TypeError(
            f"substring must be of type str, got {type(substring).__name__}"
        )

    result = []
    for index, value in enumerate(strings):
        if not isinstance(value, str):
            raise TypeError(
                f"all elements in strings must be of type str; "
                f"element at index {index} is {type(value).__name__}"
            )
        if substring in value:
            result.append(value)

    return result
candidate = filter_by_substring




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([], 'john') == []
    assert candidate(['xxx', 'asd', 'xxy', 'john doe', 'xxxAAA', 'xxx'], 'xxx') == ['xxx', 'xxxAAA', 'xxx']
    assert candidate(['xxx', 'asd', 'aaaxxy', 'john doe', 'xxxAAA', 'xxx'], 'xx') == ['xxx', 'aaaxxy', 'xxxAAA', 'xxx']
    assert candidate(['grunt', 'trumpet', 'prune', 'gruesome'], 'run') == ['grunt', 'prune']


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
