
import unittest
import re
import sys
import math
import copy


def next_smallest(lst):
    """
    Return the 2nd smallest distinct integer in the list.

    Returns:
        int | None: The second smallest distinct value, or None if it does not exist.

    Raises:
        TypeError: If lst is not a list, or if any element is not an integer.
    """
    if not isinstance(lst, list):
        raise TypeError("lst must be a list")

    if not all(isinstance(x, int) for x in lst):
        raise TypeError("all elements in lst must be integers")

    unique_values = set(lst)

    if len(unique_values) < 2:
        return None

    return sorted(unique_values)[1]
candidate = next_smallest


def check(candidate):

    # Check some simple cases
    assert candidate([1, 2, 3, 4, 5]) == 2
    assert candidate([5, 1, 4, 3, 2]) == 2
    assert candidate([]) == None
    assert candidate([1, 1]) == None
    assert candidate([1,1,1,1,0]) == 1
    assert candidate([1, 0**0]) == None
    assert candidate([-35, 34, 12, -45]) == -35

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
