
import unittest
import re
import sys
import math
import copy


import re


def fruit_distribution(s, n):
    """
    Return the number of mangoes in the basket.

    The input string must contain exactly two non-negative integers:
    the number of apples and the number of oranges, e.g.
    "5 apples and 6 oranges".

    Args:
        s: A string describing apples and oranges.
        n: Total number of fruits in the basket.

    Returns:
        The number of mangoes as an integer.

    Raises:
        TypeError: If `s` is not a string or `n` is not an integer.
        ValueError: If the string format is invalid, counts are negative,
                    or total fruits is less than apples + oranges.
    """
    if not isinstance(s, str):
        raise TypeError("s must be a string")
    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if n < 0:
        raise ValueError("n must be non-negative")

    matches = re.findall(r"\d+", s)
    if len(matches) != 2:
        raise ValueError(
            "s must contain exactly two non-negative integer counts for apples and oranges"
        )

    apples, oranges = map(int, matches)

    used_fruits = apples + oranges
    if used_fruits > n:
        raise ValueError(
            "total fruits cannot be less than the sum of apples and oranges"
        )

    return n - used_fruits
candidate = fruit_distribution


def check(candidate):

    # Check some simple cases
    assert candidate("5 apples and 6 oranges",19) == 8
    assert candidate("5 apples and 6 oranges",21) == 10
    assert candidate("0 apples and 1 oranges",3) == 2
    assert candidate("1 apples and 0 oranges",3) == 2
    assert candidate("2 apples and 3 oranges",100) == 95
    assert candidate("2 apples and 3 oranges",5) == 0
    assert candidate("1 apples and 100 oranges",120) == 19


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
