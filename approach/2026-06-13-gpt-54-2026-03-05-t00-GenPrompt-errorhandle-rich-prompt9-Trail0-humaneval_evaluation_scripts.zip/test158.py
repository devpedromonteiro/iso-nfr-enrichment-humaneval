
import unittest
import re
import sys
import math
import copy


def find_max(words):
    """Return the word with the maximum number of unique characters.

    If multiple words have the same maximum number of unique characters,
    return the lexicographically smallest one.

    Args:
        words: A list of strings.

    Returns:
        The selected string.

    Raises:
        TypeError: If `words` is not a list or any element is not a string.
        ValueError: If `words` is empty.
    """
    if not isinstance(words, list):
        raise TypeError("words must be a list of strings")

    if not words:
        raise ValueError("words must not be empty")

    for i, word in enumerate(words):
        if not isinstance(word, str):
            raise TypeError(f"words[{i}] must be a string")

    try:
        return min(words, key=lambda word: (-len(set(word)), word))
    except TypeError as exc:
        # Defensive handling in case comparison fails unexpectedly.
        raise TypeError("failed to evaluate words due to invalid input types") from exc
candidate = find_max


def check(candidate):

    # Check some simple cases
    assert (candidate(["name", "of", "string"]) == "string"), "t1"
    assert (candidate(["name", "enam", "game"]) == "enam"), 't2'
    assert (candidate(["aaaaaaa", "bb", "cc"]) == "aaaaaaa"), 't3'
    assert (candidate(["abc", "cba"]) == "abc"), 't4'
    assert (candidate(["play", "this", "game", "of","footbott"]) == "footbott"), 't5'
    assert (candidate(["we", "are", "gonna", "rock"]) == "gonna"), 't6'
    assert (candidate(["we", "are", "a", "mad", "nation"]) == "nation"), 't7'
    assert (candidate(["this", "is", "a", "prrk"]) == "this"), 't8'

    # Check some edge cases that are easy to work out by hand.
    assert (candidate(["b"]) == "b"), 't9'
    assert (candidate(["play", "play", "play"]) == "play"), 't10'



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
