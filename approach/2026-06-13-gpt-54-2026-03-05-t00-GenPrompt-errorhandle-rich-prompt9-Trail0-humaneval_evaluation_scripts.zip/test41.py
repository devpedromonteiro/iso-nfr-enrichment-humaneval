
import unittest
import re
import sys
import math
import copy



def car_race_collision(n: int) -> int:
    """
    Calculate the number of collisions between two groups of cars.

    Imagine a straight infinitely long road:
    - n cars travel from left to right
    - n different cars travel from right to left
    - all cars move at the same speed
    - every left-to-right car collides exactly once with every right-to-left car

    Therefore, the total number of collisions is n * n.

    Args:
        n: The number of cars in each group. Must be a non-negative integer.

    Returns:
        The total number of collisions.

    Raises:
        TypeError: If n is not an integer.
        ValueError: If n is negative.
    """
    if isinstance(n, bool):
        raise TypeError("n must be a non-negative integer, not bool")

    if not isinstance(n, int):
        raise TypeError(f"n must be an integer, got {type(n).__name__}")

    if n < 0:
        raise ValueError("n must be non-negative")

    return n * n
candidate = car_race_collision




METADATA = {}


def check(candidate):
    assert candidate(2) == 4
    assert candidate(3) == 9
    assert candidate(4) == 16
    assert candidate(8) == 64
    assert candidate(10) == 100



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
