
import unittest
import re
import sys
import math
import copy


def by_length(arr):
    """
    Given an array of integers, sort the integers that are between 1 and 9 inclusive,
    reverse the resulting array, and then replace each digit by its corresponding name.

    Valid digits:
        1 -> "One"
        2 -> "Two"
        3 -> "Three"
        4 -> "Four"
        5 -> "Five"
        6 -> "Six"
        7 -> "Seven"
        8 -> "Eight"
        9 -> "Nine"

    Rules:
    - If arr is empty, return [].
    - Ignore values outside the range 1..9.
    - Validate inputs explicitly.
    - Raise specific exceptions for invalid arguments.
    """
    if arr is None:
        raise TypeError("arr must be an iterable of integers, got None")

    if not isinstance(arr, list):
        raise TypeError(f"arr must be a list of integers, got {type(arr).__name__}")

    digit_names = {
        1: "One",
        2: "Two",
        3: "Three",
        4: "Four",
        5: "Five",
        6: "Six",
        7: "Seven",
        8: "Eight",
        9: "Nine",
    }

    if not arr:
        return []

    validated = []
    for i, value in enumerate(arr):
        if isinstance(value, bool) or not isinstance(value, int):
            raise TypeError(
                f"arr[{i}] must be an integer, got {type(value).__name__}"
            )
        validated.append(value)

    try:
        sorted_values = sorted(validated, reverse=True)
    except TypeError as exc:
        raise TypeError("arr contains values that cannot be sorted as integers") from exc

    return [digit_names[n] for n in sorted_values if n in digit_names]
candidate = by_length


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([2, 1, 1, 4, 5, 8, 2, 3]) == ["Eight", "Five", "Four", "Three", "Two", "Two", "One", "One"], "Error"
    assert candidate([]) == [], "Error"
    assert candidate([1, -1 , 55]) == ['One'], "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([1, -1, 3, 2]) == ["Three", "Two", "One"]
    assert candidate([9, 4, 8]) == ["Nine", "Eight", "Four"]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
