
import unittest
import re
import sys
import math
import copy



def max_element(l: list):
    """Return maximum element in the list.

    >>> max_element([1, 2, 3])
    3
    >>> max_element([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    123
    """
    if not isinstance(l, list):
        raise TypeError(f"Expected a list, got {type(l).__name__}")
    if not l:
        raise ValueError("max_element() arg is an empty list")

    try:
        maximum = l[0]
        for item in l[1:]:
            if item > maximum:
                maximum = item
        return maximum
    except TypeError as e:
        raise TypeError(
            "All elements in the list must be mutually comparable"
        ) from e
candidate = max_element




METADATA = {}


def check(candidate):
    assert candidate([1, 2, 3]) == 3
    assert candidate([5, 3, -5, 2, -3, 3, 9, 0, 124, 1, -10]) == 124


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
