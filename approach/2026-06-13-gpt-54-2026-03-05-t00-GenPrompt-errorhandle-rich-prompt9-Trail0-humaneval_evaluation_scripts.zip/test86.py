
import unittest
import re
import sys
import math
import copy


def anti_shuffle(s):
    """
    Return a version of the input string where each word's characters are sorted
    in ascending ASCII order, while preserving the original positions of spaces.

    A "word" is any maximal sequence of non-space characters.

    Examples:
        anti_shuffle('Hi') -> 'Hi'
        anti_shuffle('hello') -> 'ehllo'
        anti_shuffle('Hello World!!!') -> 'Hello !!!Wdlor'

    Raises:
        TypeError: If s is not a string.
    """
    if not isinstance(s, str):
        raise TypeError(f"anti_shuffle expected a string, got {type(s).__name__}")

    try:
        parts = s.split(' ')
        sorted_parts = [''.join(sorted(part)) for part in parts]
        return ' '.join(sorted_parts)
    except TypeError:
        # Re-raise specific sorting/type-related issues without swallowing them.
        raise
    except Exception as exc:
        # Wrap unexpected failures in a specific runtime exception.
        raise RuntimeError("Failed to anti-shuffle the input string") from exc
candidate = anti_shuffle


def check(candidate):

    # Check some simple cases
    assert candidate('Hi') == 'Hi'
    assert candidate('hello') == 'ehllo'
    assert candidate('number') == 'bemnru'
    assert candidate('abcd') == 'abcd'
    assert candidate('Hello World!!!') == 'Hello !!!Wdlor'
    assert candidate('') == ''
    assert candidate('Hi. My name is Mister Robot. How are you?') == '.Hi My aemn is Meirst .Rboot How aer ?ouy'
    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
