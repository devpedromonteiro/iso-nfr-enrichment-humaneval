
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def sort_numbers(numbers: str) -> str:
    """Input is a space-delimited string of numerals from 'zero' to 'nine'.
    Valid choices are 'zero', 'one', 'two', 'three', 'four', 'five',
    'six', 'seven', 'eight' and 'nine'.

    Return the string with numbers sorted from smallest to largest.

    >>> sort_numbers('three one five')
    'one three five'
    """
    if not isinstance(numbers, str):
        raise TypeError("numbers must be a string")

    word_to_value = {
        "zero": 0,
        "one": 1,
        "two": 2,
        "three": 3,
        "four": 4,
        "five": 5,
        "six": 6,
        "seven": 7,
        "eight": 8,
        "nine": 9,
    }

    value_to_word = {value: word for word, value in word_to_value.items()}

    stripped = numbers.strip()
    if not stripped:
        raise ValueError("numbers must be a non-empty space-delimited string of numerals")

    tokens = stripped.split()
    invalid_tokens: List[str] = [token for token in tokens if token not in word_to_value]
    if invalid_tokens:
        raise ValueError(
            f"invalid numeral(s): {', '.join(invalid_tokens)}; "
            f"valid values are: {', '.join(word_to_value.keys())}"
        )

    sorted_values = sorted(word_to_value[token] for token in tokens)
    return " ".join(value_to_word[value] for value in sorted_values)
candidate = sort_numbers




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == ''
    assert candidate('three') == 'three'
    assert candidate('three five nine') == 'three five nine'
    assert candidate('five zero four seven nine eight') == 'zero four five seven eight nine'
    assert candidate('six five four three two one zero') == 'zero one two three four five six'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
