
import unittest


def numerical_letter_grade(grades):
    """Convert a list of GPA values to their corresponding letter grades.

    Grade scale:
        4.0  -> A+
        >3.7 -> A
        >3.3 -> A-
        >3.0 -> B+
        >2.7 -> B
        >2.3 -> B-
        >2.0 -> C+
        >1.7 -> C
        >1.3 -> C-
        >1.0 -> D+
        >0.7 -> D
        >0.0 -> D-
        0.0  -> E
    """
    letter_grades = []

    for gpa in grades:
        if gpa == 4.0:
            letter_grade = "A+"
        elif gpa > 3.7:
            letter_grade = "A"
        elif gpa > 3.3:
            letter_grade = "A-"
        elif gpa > 3.0:
            letter_grade = "B+"
        elif gpa > 2.7:
            letter_grade = "B"
        elif gpa > 2.3:
            letter_grade = "B-"
        elif gpa > 2.0:
            letter_grade = "C+"
        elif gpa > 1.7:
            letter_grade = "C"
        elif gpa > 1.3:
            letter_grade = "C-"
        elif gpa > 1.0:
            letter_grade = "D+"
        elif gpa > 0.7:
            letter_grade = "D"
        elif gpa > 0.0:
            letter_grade = "D-"
        else:
            letter_grade = "E"

        letter_grades.append(letter_grade)

    return letter_grades
candidate = numerical_letter_grade


class Test(unittest.TestCase):
    def test(self):
        assert candidate([3.367]) == ['A-']
        assert candidate([3.709]) == ['A']
        assert candidate([1.501]) == ['C-']
        assert candidate([6.042, 3, 5.935, 5, 5.423]) == ['A', 'B', 'A', 'A', 'A']
        assert candidate([1.511]) == ['C-']
        assert candidate([6, 4.502, 2.77, 6.757, 4.66]) == ['A', 'A', 'B', 'A', 'A']
        assert candidate([5.309, 3, 3.031, 4, 3.721]) == ['A', 'B', 'B+', 'A+', 'A']
        assert candidate([1, 1.067, 5.544, 2.104, 6.994]) == ['D', 'D+', 'A', 'C+', 'A']
        assert candidate([3, 3.93, 1.74, 2.791, 2.576]) == ['B', 'A', 'C', 'B', 'B-']
        assert candidate([4.799]) == ['A']
        assert candidate([4.104]) == ['A']
        assert candidate([6, 2.642, 5.179, 5.542, 7.925]) == ['A', 'B-', 'A', 'A', 'A']
        assert candidate([7.75, 2, 6.21, 4, 7.481]) == ['A', 'C', 'A', 'A+', 'A']
        assert candidate([3, 1.608, 4.584, 1.801, 5.528]) == ['B', 'C-', 'A', 'C', 'A']
        assert candidate([2.259]) == ['C+']
        assert candidate([4, 2.626, 2.824, 7.424, 5.83]) == ['A+', 'B-', 'B', 'A', 'A']
        assert candidate([0, 0.7]) == ['E', 'D-']

    # Check some edge cases that are easy to work out by hand.
        assert candidate([4.84, 4, 4.974, 6, 5.319]) == ['A', 'A+', 'A', 'A', 'A']
        assert candidate([2.033]) == ['C+']
        assert candidate([2.516]) == ['B-']
        assert candidate([9.54, 5, 6.671, 1, 5.784]) == ['A', 'A', 'A', 'D', 'A']
        assert candidate([1, 5.293, 4.749, 7.907, 5.656]) == ['D', 'A', 'A', 'A', 'A']
        assert candidate([6.463, 2, 3.954, 5, 7.145]) == ['A', 'C', 'A', 'A', 'A']
        assert candidate([3.826]) == ['A']
        assert candidate([3, 3.758, 2.783, 2.733, 7.605]) == ['B', 'A', 'B', 'B', 'A']
        assert candidate([2.597]) == ['B-']
        assert candidate([4, 1.435, 5.824, 1.539, 7.492]) == ['A+', 'C-', 'A', 'C-', 'A']
        assert candidate([6.423]) == ['A']
        assert candidate([1.143]) == ['D+']
        assert candidate([1.891]) == ['C']
        assert candidate([5.065, 4, 5.911, 2, 4.43]) == ['A', 'A+', 'A', 'C', 'A']
        assert candidate([4.477, 7, 6.699, 6, 7.022]) == ['A', 'A', 'A', 'A', 'A']
        assert candidate([5, 2.658, 2.151, 6.268, 5.527]) == ['A', 'B-', 'C+', 'A', 'A']
        assert candidate([3, 4.558, 2.072, 3.712, 5.809]) == ['B', 'A', 'C+', 'A', 'A']
        assert candidate([3, 4.425, 6.207, 4.631, 3.821]) == ['B', 'A', 'A', 'A', 'A']
        assert candidate([1.878]) == ['C']
        assert candidate([3.81]) == ['A']
        assert candidate([5.976, 4, 1.433, 7, 3.077]) == ['A', 'A+', 'C-', 'A', 'B+']
        assert candidate([2.226]) == ['C+']
        assert candidate([5.364]) == ['A']
        assert candidate([4.946]) == ['A']
        assert candidate([4, 3.251, 2.546, 1.98, 3.082]) == ['A+', 'B+', 'B-', 'C', 'B+']
        assert candidate([3.189]) == ['B+']
        assert candidate([6.618]) == ['A']
        assert candidate([4.835]) == ['A']
        assert candidate([1, 0.3, 1.5, 2.8, 3.3]) == ['D', 'D-', 'C-', 'B', 'B+']
        assert candidate([5.356]) == ['A']
        assert candidate([3.612]) == ['A-']
        assert candidate([2.601]) == ['B-']
        assert candidate([1.978]) == ['C']
        assert candidate([5, 3.231, 4.961, 5.91, 4.348]) == ['A', 'B+', 'A', 'A', 'A']
        assert candidate([0.5]) == ['D-']
        assert candidate([2.412]) == ['B-']
        assert candidate([1.699]) == ['C-']
        assert candidate([9.553, 3, 1.754, 7, 7.712]) == ['A', 'B', 'C', 'A', 'A']
        assert candidate([5.909, 4, 3.917, 4, 2.236]) == ['A', 'A+', 'A', 'A+', 'C+']
        assert candidate([5, 4.675, 6.301, 3.928, 5.804]) == ['A', 'A', 'A', 'A', 'A']
        assert candidate([4.845]) == ['A']
        assert candidate([2.091]) == ['C+']
        assert candidate([4.822]) == ['A']
        assert candidate([1, 1.556, 6.189, 3.588, 1.625]) == ['D', 'C-', 'A', 'A-', 'C-']
        assert candidate([6.134, 3, 6.155, 3, 2.084]) == ['A', 'B', 'A', 'B', 'C+']
        assert candidate([5, 3.839, 3.698, 4.34, 1.955]) == ['A', 'A', 'A-', 'A', 'C']
        assert candidate([4.813]) == ['A']
        assert candidate([1.266, 7, 4.913, 2, 1.115]) == ['D+', 'A', 'A', 'C', 'D+']
        assert candidate([4.381]) == ['A']
        assert candidate([2.985]) == ['B']
        assert candidate([4.314]) == ['A']
        assert candidate([9.317, 8, 3.7, 6, 2.483]) == ['A', 'A', 'A-', 'A', 'B-']
        assert candidate([2.169]) == ['C+']
        assert candidate([3.925]) == ['A']
        assert candidate([1.275]) == ['D+']
        assert candidate([1.076]) == ['D+']
        assert candidate([1.906]) == ['C']
        assert candidate([6, 5.144, 4.622, 7.362, 8.196]) == ['A', 'A', 'A', 'A', 'A']
        assert candidate([5.778]) == ['A']
        assert candidate([5.012]) == ['A']
        assert candidate([0.0]) == ['E']
        assert candidate([4.873, 3, 2.438, 6, 5.365]) == ['A', 'B', 'B-', 'A', 'A']
        assert candidate([1.169]) == ['D+']
        assert candidate([4.454]) == ['A']
        assert candidate([1, 1.181, 4.176, 7.002, 5.356]) == ['D', 'D+', 'A', 'A', 'A']
        assert candidate([1.412]) == ['C-']
        assert candidate([3.054]) == ['B+']
        assert candidate([5.401]) == ['A']
        assert candidate([5.559]) == ['A']
        assert candidate([2.454, 8, 1.163, 2, 3.831]) == ['B-', 'A', 'D+', 'C', 'A']
        assert candidate([4.0, 3, 1.7, 2, 3.5]) == ['A+', 'B', 'C-', 'C', 'A-']
        assert candidate([5.288]) == ['A']
        assert candidate([3.516]) == ['A-']
        assert candidate([3.111]) == ['B+']
        assert candidate([3.411]) == ['A-']
        assert candidate([1.415]) == ['C-']
        assert candidate([4.682]) == ['A']
        assert candidate([4.152, 7, 2.102, 5, 8.879]) == ['A', 'A', 'C+', 'A', 'A']
        assert candidate([6, 2.172, 3.849, 1.272, 6.298]) == ['A', 'C+', 'A', 'D+', 'A']
        assert candidate([4.697]) == ['A']
        assert candidate([4.86]) == ['A']
        assert candidate([1.2]) == ['D+']
        assert candidate([6.363]) == ['A']
        assert candidate([5.886]) == ['A']
        assert candidate([4.202]) == ['A']
        assert candidate([8.911, 1, 5.562, 6, 1.001]) == ['A', 'D', 'A', 'A', 'D+']
        assert candidate([5.442]) == ['A']
        assert candidate([1.32, 8, 4.236, 1, 5.296]) == ['C-', 'A', 'A', 'D', 'A']
        assert candidate([1.058, 4, 5.349, 2, 4.304]) == ['D+', 'A+', 'A', 'C', 'A']

if __name__ == '__main__':
    unittest.main()
