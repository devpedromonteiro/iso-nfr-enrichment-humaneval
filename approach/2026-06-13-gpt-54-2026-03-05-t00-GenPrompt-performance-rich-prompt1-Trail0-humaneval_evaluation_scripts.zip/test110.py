
import unittest
import re
import sys
import math
import copy


def exchange(lst1, lst2):
    """Determine whether lst1 can be made all-even by exchanging elements with lst2.

    Since any number of exchanges is allowed, each odd number currently in lst1
    must be replaceable by an even number from lst2. Thus, it is possible iff
    the number of even elements in lst2 is at least the number of odd elements
    in lst1.
    """
    odd_in_lst1 = 0
    even_in_lst2 = 0

    for x in lst1:
        if x % 2 != 0:
            odd_in_lst1 += 1

    for x in lst2:
        if x % 2 == 0:
            even_in_lst2 += 1

    return "YES" if even_in_lst2 >= odd_in_lst1 else "NO"
candidate = exchange


def check(candidate):

    # Check some simple cases
    assert candidate([1, 2, 3, 4], [1, 2, 3, 4]) == "YES"
    assert candidate([1, 2, 3, 4], [1, 5, 3, 4]) == "NO"
    assert candidate([1, 2, 3, 4], [2, 1, 4, 3]) == "YES" 
    assert candidate([5, 7, 3], [2, 6, 4]) == "YES"
    assert candidate([5, 7, 3], [2, 6, 3]) == "NO" 
    assert candidate([3, 2, 6, 1, 8, 9], [3, 5, 5, 1, 1, 1]) == "NO"

    # Check some edge cases that are easy to work out by hand.
    assert candidate([100, 200], [200, 200]) == "YES"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
