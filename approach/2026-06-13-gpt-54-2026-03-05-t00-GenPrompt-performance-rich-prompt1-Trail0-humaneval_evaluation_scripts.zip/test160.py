
import unittest
import re
import sys
import math
import copy


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and
    the second list is a list of integers. Use the two given lists to build the algebraic
    expression and return the evaluation of this expression.

    Supported operations:
    +, -, *, //, **

    The expression follows normal Python operator precedence.
    """
    n = len(operand)
    if n == 0:
        return 0
    if n == 1:
        return operand[0]

    values = [operand[0]]
    low_ops = []

    for i, op in enumerate(operator):
        right = operand[i + 1]

        if op == '**':
            values[-1] = values[-1] ** right
        elif op == '*':
            values[-1] = values[-1] * right
        elif op == '//':
            values[-1] = values[-1] // right
        elif op == '+':
            low_ops.append('+')
            values.append(right)
        else:  # op == '-'
            low_ops.append('-')
            values.append(right)

    result = values[0]
    for i, op in enumerate(low_ops):
        if op == '+':
            result += values[i + 1]
        else:
            result -= values[i + 1]

    return result
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
