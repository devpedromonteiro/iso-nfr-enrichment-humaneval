
import unittest
import re
import sys
import math
import copy


def get_odd_collatz(n):
    """
    Given a positive integer n, return a sorted list containing the odd numbers
    that appear in the Collatz sequence of n.

    The returned list is sorted in increasing order and contains each odd value
    only once.

    Examples:
        get_odd_collatz(1) -> [1]
        get_odd_collatz(5) -> [1, 5]
    """
    if not isinstance(n, int) or n <= 0:
        raise ValueError("n must be a positive integer")

    odd_values = set()

    while True:
        if n & 1:
            odd_values.add(n)
            if n == 1:
                break
            n = 3 * n + 1
        else:
            n //= 2

    return sorted(odd_values)
candidate = get_odd_collatz


def check(candidate):

    # Check some simple cases
    assert candidate(14) == [1, 5, 7, 11, 13, 17]
    assert candidate(5) == [1, 5]
    assert candidate(12) == [1, 3, 5], "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1) == [1], "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
