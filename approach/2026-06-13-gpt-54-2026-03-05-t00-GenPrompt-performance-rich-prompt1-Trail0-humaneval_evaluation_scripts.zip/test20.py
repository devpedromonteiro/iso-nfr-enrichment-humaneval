
import unittest
import re
import sys
import math
import copy

from typing import List, Tuple


from typing import List, Tuple


def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    """From a supplied list of numbers (of length at least two) select and return
    two that are the closest to each other and return them in order
    (smaller number, larger number).

    The implementation sorts once, then scans adjacent pairs, which is
    asymptotically better than comparing every pair.

    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.2])
    (2.0, 2.2)
    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.0])
    (2.0, 2.0)
    """
    sorted_numbers = sorted(numbers)

    best_left = sorted_numbers[0]
    best_right = sorted_numbers[1]
    best_diff = best_right - best_left

    for i in range(1, len(sorted_numbers) - 1):
        left = sorted_numbers[i]
        right = sorted_numbers[i + 1]
        diff = right - left

        if diff < best_diff:
            best_diff = diff
            best_left = left
            best_right = right
            if best_diff == 0:
                break

    return best_left, best_right
candidate = find_closest_elements




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([1.0, 2.0, 3.9, 4.0, 5.0, 2.2]) == (3.9, 4.0)
    assert candidate([1.0, 2.0, 5.9, 4.0, 5.0]) == (5.0, 5.9)
    assert candidate([1.0, 2.0, 3.0, 4.0, 5.0, 2.2]) == (2.0, 2.2)
    assert candidate([1.0, 2.0, 3.0, 4.0, 5.0, 2.0]) == (2.0, 2.0)
    assert candidate([1.1, 2.2, 3.1, 4.1, 5.1]) == (2.2, 3.1)



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
