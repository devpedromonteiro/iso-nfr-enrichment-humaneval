
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    You are given a positive integer n. You have to create an integer array a of length n.
        For each i (1 â¤ i â¤ n), the value of a[i] = i * i - i + 1.
        Return the number of triples (a[i], a[j], a[k]) of a where i < j < k,
    and a[i] + a[j] + a[k] is a multiple of 3.

    Example :
        Input: n = 5
        Output: 1
        Explanation:
        a = [1, 3, 7, 13, 21]
        The only valid triple is (1, 7, 13).
    """
    if n < 3:
        return 0

    # a[i] = i^2 - i + 1 = i(i-1) + 1
    # Since i(i-1) is always divisible by 2 consecutive parity doesn't help,
    # but modulo 3:
    # i = 0,1 mod 3 -> a[i] â¡ 1 mod 3
    # i = 2 mod 3     -> a[i] â¡ 0 mod 3
    #
    # A triple sum is divisible by 3 only when residues are:
    # (0,0,0) or (1,1,1)
    #
    # Count how many indices i in [1..n] produce each residue.

    q, r = divmod(n, 3)

    # Among 1..n:
    # count of i % 3 == 1 or 0 gives a[i] % 3 == 1
    # count of i % 3 == 2 gives a[i] % 3 == 0
    count_zero = q + (1 if r >= 2 else 0)   # i % 3 == 2
    count_one = n - count_zero              # remaining indices

    def comb3(x):
        return x * (x - 1) * (x - 2) // 6 if x >= 3 else 0

    return comb3(count_zero) + comb3(count_one)
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
