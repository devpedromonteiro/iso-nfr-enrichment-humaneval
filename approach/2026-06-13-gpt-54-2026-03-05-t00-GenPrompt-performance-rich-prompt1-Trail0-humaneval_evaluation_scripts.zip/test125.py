
import unittest
import re
import sys
import math
import copy


def split_words(txt):
    """
    Given a string of words, return a list of words split on whitespace.
    If no whitespace exists in the text, split on commas ','.
    If no commas exist, return the number of lower-case letters with odd
    order in the alphabet, where ord('a') = 0, ..., ord('z') = 25.

    Examples
    split_words("Hello world!") -> ["Hello", "world!"]
    split_words("Hello,world!") -> ["Hello", "world!"]
    split_words("abcdef") -> 3
    """
    # Fast path: split on any whitespace if present.
    if any(ch.isspace() for ch in txt):
        return txt.split()

    # Next: split on commas if present.
    if ',' in txt:
        return txt.split(',')

    # Otherwise count lowercase letters with odd alphabet index:
    # b(1), d(3), ..., z(25)
    count = 0
    for ch in txt:
        o = ord(ch) - ord('a')
        if 0 <= o < 26 and (o & 1):
            count += 1
    return count
candidate = split_words


def check(candidate):

    assert candidate("Hello world!") == ["Hello","world!"]
    assert candidate("Hello,world!") == ["Hello","world!"]
    assert candidate("Hello world,!") == ["Hello","world,!"]
    assert candidate("Hello,Hello,world !") == ["Hello,Hello,world","!"]
    assert candidate("abcdef") == 3
    assert candidate("aaabb") == 2
    assert candidate("aaaBb") == 1
    assert candidate("") == 0


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
