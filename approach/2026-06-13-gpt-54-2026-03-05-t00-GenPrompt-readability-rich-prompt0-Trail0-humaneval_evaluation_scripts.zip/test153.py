
import unittest
import re
import sys
import math
import copy


def Strongest_Extension(class_name, extensions):
    def calculate_strength(extension_name):
        uppercase_count = sum(1 for character in extension_name if character.isupper())
        lowercase_count = sum(1 for character in extension_name if character.islower())
        return uppercase_count - lowercase_count

    strongest_extension = extensions[0]
    strongest_strength = calculate_strength(strongest_extension)

    for extension_name in extensions[1:]:
        current_strength = calculate_strength(extension_name)
        if current_strength > strongest_strength:
            strongest_extension = extension_name
            strongest_strength = current_strength

    return f"{class_name}.{strongest_extension}"
candidate = Strongest_Extension


def check(candidate):

    # Check some simple cases
    assert candidate('Watashi', ['tEN', 'niNE', 'eIGHt8OKe']) == 'Watashi.eIGHt8OKe'
    assert candidate('Boku123', ['nani', 'NazeDa', 'YEs.WeCaNe', '32145tggg']) == 'Boku123.YEs.WeCaNe'
    assert candidate('__YESIMHERE', ['t', 'eMptY', 'nothing', 'zeR00', 'NuLl__', '123NoooneB321']) == '__YESIMHERE.NuLl__'
    assert candidate('K', ['Ta', 'TAR', 't234An', 'cosSo']) == 'K.TAR'
    assert candidate('__HAHA', ['Tab', '123', '781345', '-_-']) == '__HAHA.123'
    assert candidate('YameRore', ['HhAas', 'okIWILL123', 'WorkOut', 'Fails', '-_-']) == 'YameRore.okIWILL123'
    assert candidate('finNNalLLly', ['Die', 'NowW', 'Wow', 'WoW']) == 'finNNalLLly.WoW'

    # Check some edge cases that are easy to work out by hand.
    assert candidate('_', ['Bb', '91245']) == '_.Bb'
    assert candidate('Sp', ['671235', 'Bb']) == 'Sp.671235'
    


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
