
import unittest
import re
import sys
import math
import copy



def greatest_common_divisor(first_number: int, second_number: int) -> int:
    """Return the greatest common divisor of two integers.

    >>> greatest_common_divisor(3, 5)
    1
    >>> greatest_common_divisor(25, 15)
    5
    """
    first_number = abs(first_number)
    second_number = abs(second_number)

    while second_number != 0:
        remainder = first_number % second_number
        first_number = second_number
        second_number = remainder

    return first_number
candidate = greatest_common_divisor




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(3, 7) == 1
    assert candidate(10, 15) == 5
    assert candidate(49, 14) == 7
    assert candidate(144, 60) == 12


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
