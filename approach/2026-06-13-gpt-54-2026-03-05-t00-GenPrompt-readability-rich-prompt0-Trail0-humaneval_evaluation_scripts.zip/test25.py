
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def factorize(number: int) -> List[int]:
    """Return the prime factors of ``number`` from smallest to largest.

    Each prime factor appears as many times as it occurs in the factorization.

    >>> factorize(8)
    [2, 2, 2]
    >>> factorize(25)
    [5, 5]
    >>> factorize(70)
    [2, 5, 7]
    """
    factors: List[int] = []
    divisor = 2
    remaining_number = number

    while divisor * divisor <= remaining_number:
        while remaining_number % divisor == 0:
            factors.append(divisor)
            remaining_number //= divisor
        divisor += 1

    if remaining_number > 1:
        factors.append(remaining_number)

    return factors
candidate = factorize




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(2) == [2]
    assert candidate(4) == [2, 2]
    assert candidate(8) == [2, 2, 2]
    assert candidate(3 * 19) == [3, 19]
    assert candidate(3 * 19 * 3 * 19) == [3, 3, 19, 19]
    assert candidate(3 * 19 * 3 * 19 * 3 * 19) == [3, 3, 3, 19, 19, 19]
    assert candidate(3 * 19 * 19 * 19) == [3, 19, 19, 19]
    assert candidate(3 * 2 * 3) == [2, 3, 3]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
