
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    You are given a positive integer n. Create an array a of length n where:
        a[i] = i * i - i + 1   for 1 <= i <= n

    Return the number of triples (a[i], a[j], a[k]) such that:
        i < j < k
        a[i] + a[j] + a[k] is divisible by 3

    Example:
        Input: n = 5
        Output: 1
    """

    def count_combinations(total_items):
        if total_items < 3:
            return 0
        return total_items * (total_items - 1) * (total_items - 2) // 6

    remainder_counts = [0, 0, 0]

    for index in range(1, n + 1):
        value = index * index - index + 1
        remainder = value % 3
        remainder_counts[remainder] += 1

    count_remainder_0 = remainder_counts[0]
    count_remainder_1 = remainder_counts[1]
    count_remainder_2 = remainder_counts[2]

    triples_with_all_same_remainder = (
        count_combinations(count_remainder_0)
        + count_combinations(count_remainder_1)
        + count_combinations(count_remainder_2)
    )

    triples_with_one_of_each_remainder = (
        count_remainder_0 * count_remainder_1 * count_remainder_2
    )

    total_valid_triples = (
        triples_with_all_same_remainder + triples_with_one_of_each_remainder
    )

    return total_valid_triples
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
