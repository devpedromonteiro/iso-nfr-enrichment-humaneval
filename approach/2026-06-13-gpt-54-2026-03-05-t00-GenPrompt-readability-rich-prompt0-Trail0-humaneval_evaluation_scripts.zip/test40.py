
import unittest
import re
import sys
import math
import copy



def triples_sum_to_zero(numbers: list[int]) -> bool:
    """
    Return True if there are three distinct elements in the list whose sum is zero.

    >>> triples_sum_to_zero([1, 3, 5, 0])
    False
    >>> triples_sum_to_zero([1, 3, -2, 1])
    True
    >>> triples_sum_to_zero([1, 2, 3, 7])
    False
    >>> triples_sum_to_zero([2, 4, -5, 3, 9, 7])
    True
    >>> triples_sum_to_zero([1])
    False
    """
    number_count = len(numbers)

    if number_count < 3:
        return False

    for first_index in range(number_count - 2):
        first_number = numbers[first_index]

        for second_index in range(first_index + 1, number_count - 1):
            second_number = numbers[second_index]

            for third_index in range(second_index + 1, number_count):
                third_number = numbers[third_index]

                if first_number + second_number + third_number == 0:
                    return True

    return False
candidate = triples_sum_to_zero




METADATA = {}


def check(candidate):
    assert candidate([1, 3, 5, 0]) == False
    assert candidate([1, 3, 5, -1]) == False
    assert candidate([1, 3, -2, 1]) == True
    assert candidate([1, 2, 3, 7]) == False
    assert candidate([1, 2, 5, 7]) == False
    assert candidate([2, 4, -5, 3, 9, 7]) == True
    assert candidate([1]) == False
    assert candidate([1, 3, 5, -100]) == False
    assert candidate([100, 3, 5, -100]) == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
