
import unittest
import re
import sys
import math
import copy



def add(first_number: int, second_number: int) -> int:
    """Return the sum of two numbers.

    >>> add(2, 3)
    5
    >>> add(5, 7)
    12
    """
    return first_number + second_number
candidate = add




METADATA = {}


def check(candidate):
    import random

    assert candidate(0, 1) == 1
    assert candidate(1, 0) == 1
    assert candidate(2, 3) == 5
    assert candidate(5, 7) == 12
    assert candidate(7, 5) == 12

    for i in range(100):
        x, y = random.randint(0, 1000), random.randint(0, 1000)
        assert candidate(x, y) == x + y



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
