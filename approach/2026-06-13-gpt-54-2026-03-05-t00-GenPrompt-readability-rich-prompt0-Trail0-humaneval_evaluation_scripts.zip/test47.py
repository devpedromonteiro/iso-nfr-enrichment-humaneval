
import unittest
import re
import sys
import math
import copy



def median(numbers: list):
    """Return the median of the elements in numbers.

    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    15.0
    """
    sorted_numbers = sorted(numbers)
    number_count = len(sorted_numbers)
    middle_index = number_count // 2

    if number_count % 2 == 1:
        return sorted_numbers[middle_index]

    left_middle = sorted_numbers[middle_index - 1]
    right_middle = sorted_numbers[middle_index]
    return (left_middle + right_middle) / 2
candidate = median




METADATA = {}


def check(candidate):
    assert candidate([3, 1, 2, 4, 5]) == 3
    assert candidate([-10, 4, 6, 1000, 10, 20]) == 8.0
    assert candidate([5]) == 5
    assert candidate([6, 5]) == 5.5
    assert candidate([8, 1, 3, 9, 9, 2, 7]) == 7 



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
