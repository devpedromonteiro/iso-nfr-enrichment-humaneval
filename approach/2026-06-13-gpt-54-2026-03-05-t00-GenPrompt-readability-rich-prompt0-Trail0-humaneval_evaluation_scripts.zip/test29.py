
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def filter_by_prefix(strings: List[str], prefix: str) -> List[str]:
    """Filter strings that start with the given prefix.

    >>> filter_by_prefix([], "a")
    []
    >>> filter_by_prefix(["abc", "bcd", "cde", "array"], "a")
    ['abc', 'array']
    """
    matching_strings: List[str] = []

    for current_string in strings:
        if current_string.startswith(prefix):
            matching_strings.append(current_string)

    return matching_strings
candidate = filter_by_prefix




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([], 'john') == []
    assert candidate(['xxx', 'asd', 'xxy', 'john doe', 'xxxAAA', 'xxx'], 'xxx') == ['xxx', 'xxxAAA', 'xxx']


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
