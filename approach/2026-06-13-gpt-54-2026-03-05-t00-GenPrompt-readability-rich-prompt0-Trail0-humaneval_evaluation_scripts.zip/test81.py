
import unittest
import re
import sys
import math
import copy


def numerical_letter_grade(grades):
    """Convert a list of GPA values into letter grades.

    Grading scale:
        4.0   -> A+
        > 3.7 -> A
        > 3.3 -> A-
        > 3.0 -> B+
        > 2.7 -> B
        > 2.3 -> B-
        > 2.0 -> C+
        > 1.7 -> C
        > 1.3 -> C-
        > 1.0 -> D+
        > 0.7 -> D
        > 0.0 -> D-
        0.0   -> E
    """
    letter_grades = []

    for gpa in grades:
        if gpa == 4.0:
            letter_grade = "A+"
        elif gpa > 3.7:
            letter_grade = "A"
        elif gpa > 3.3:
            letter_grade = "A-"
        elif gpa > 3.0:
            letter_grade = "B+"
        elif gpa > 2.7:
            letter_grade = "B"
        elif gpa > 2.3:
            letter_grade = "B-"
        elif gpa > 2.0:
            letter_grade = "C+"
        elif gpa > 1.7:
            letter_grade = "C"
        elif gpa > 1.3:
            letter_grade = "C-"
        elif gpa > 1.0:
            letter_grade = "D+"
        elif gpa > 0.7:
            letter_grade = "D"
        elif gpa > 0.0:
            letter_grade = "D-"
        else:
            letter_grade = "E"

        letter_grades.append(letter_grade)

    return letter_grades
candidate = numerical_letter_grade


def check(candidate):

    # Check some simple cases
    assert candidate([4.0, 3, 1.7, 2, 3.5]) == ['A+', 'B', 'C-', 'C', 'A-']
    assert candidate([1.2]) == ['D+']
    assert candidate([0.5]) == ['D-']
    assert candidate([0.0]) == ['E']
    assert candidate([1, 0.3, 1.5, 2.8, 3.3]) == ['D', 'D-', 'C-', 'B', 'B+']
    assert candidate([0, 0.7]) == ['E', 'D-']

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
