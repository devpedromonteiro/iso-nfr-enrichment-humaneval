
import unittest
import re
import sys
import math
import copy


def multiply(first_number, second_number):
    """Return the product of the unit digits of two integers.

    Examples:
    multiply(148, 412) -> 16
    multiply(19, 28) -> 72
    multiply(2020, 1851) -> 0
    multiply(14, -15) -> 20
    """
    first_unit_digit = abs(first_number) % 10
    second_unit_digit = abs(second_number) % 10

    return first_unit_digit * second_unit_digit
candidate = multiply


def check(candidate):

    # Check some simple cases
    assert candidate(148, 412) == 16, "First test error: " + str(candidate(148, 412))                    
    assert candidate(19, 28) == 72, "Second test error: " + str(candidate(19, 28))           
    assert candidate(2020, 1851) == 0, "Third test error: " + str(candidate(2020, 1851))
    assert candidate(14,-15) == 20, "Fourth test error: " + str(candidate(14,-15))      
    assert candidate(76, 67) == 42, "Fifth test error: " + str(candidate(76, 67))      
    assert candidate(17, 27) == 49, "Sixth test error: " + str(candidate(17, 27))      


    # Check some edge cases that are easy to work out by hand.
    assert candidate(0, 1) == 0, "1st edge test error: " + str(candidate(0, 1))
    assert candidate(0, 0) == 0, "2nd edge test error: " + str(candidate(0, 0))



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
