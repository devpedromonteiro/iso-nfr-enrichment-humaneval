
import unittest
import re
import sys
import math
import copy


def count_nums(numbers):
    """
    Return how many integers have a digit sum greater than 0.

    For negative numbers, only the first digit is treated as negative.
    Example:
    -123 -> -1 + 2 + 3 = 4

    >>> count_nums([]) == 0
    True
    >>> count_nums([-1, 11, -11]) == 1
    True
    >>> count_nums([1, 1, 2]) == 3
    True
    """

    def signed_digit_sum(number):
        digit_text = str(number)

        if digit_text[0] == "-":
            first_digit_value = -int(digit_text[1])
            remaining_digit_values = [int(digit) for digit in digit_text[2:]]
            return first_digit_value + sum(remaining_digit_values)

        return sum(int(digit) for digit in digit_text)

    count_of_positive_sums = 0

    for number in numbers:
        if signed_digit_sum(number) > 0:
            count_of_positive_sums += 1

    return count_of_positive_sums
candidate = count_nums


def check(candidate):

    # Check some simple cases
    assert candidate([]) == 0
    assert candidate([-1, -2, 0]) == 0
    assert candidate([1, 1, 2, -2, 3, 4, 5]) == 6
    assert candidate([1, 6, 9, -6, 0, 1, 5]) == 5
    assert candidate([1, 100, 98, -7, 1, -1]) == 4
    assert candidate([12, 23, 34, -45, -56, 0]) == 5
    assert candidate([-0, 1**0]) == 1
    assert candidate([1]) == 1

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
