
import unittest
import re
import sys
import math
import copy


def make_a_pile(level_count):
    """
    Given a positive integer n, make a pile of n levels of stones.

    The first level has n stones.
    Each following level increases by 2, keeping the same parity
    (odd/even) as the starting number.

    Examples:
    >>> make_a_pile(3)
    [3, 5, 7]
    >>> make_a_pile(4)
    [4, 6, 8, 10]
    """
    pile = []
    stones_in_level = level_count

    for _ in range(level_count):
        pile.append(stones_in_level)
        stones_in_level += 2

    return pile
candidate = make_a_pile


def check(candidate):

    # Check some simple cases
    assert candidate(3) == [3, 5, 7], "Test 3"
    assert candidate(4) == [4,6,8,10], "Test 4"
    assert candidate(5) == [5, 7, 9, 11, 13]
    assert candidate(6) == [6, 8, 10, 12, 14, 16]
    assert candidate(8) == [8, 10, 12, 14, 16, 18, 20, 22]

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
