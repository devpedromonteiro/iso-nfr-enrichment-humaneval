
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math


def evaluate_polynomial(coefficients: list[float], x_value: float) -> float:
    """
    Evaluate a polynomial at the given x value.

    The polynomial is defined by its coefficients:
    coefficients[0] + coefficients[1] * x + coefficients[2] * x^2 + ...

    Example:
        coefficients = [1, 2, 3] represents 1 + 2x + 3x^2
    """
    return sum(coefficient * math.pow(x_value, power) for power, coefficient in enumerate(coefficients))


def poly(xs: list, x: float):
    """
    Backward-compatible wrapper for polynomial evaluation.
    """
    return evaluate_polynomial(xs, x)


def find_zero(coefficients: list[float]) -> float:
    """
    Find one real zero of a polynomial.

    The polynomial is defined by its coefficients:
    coefficients[0] + coefficients[1] * x + coefficients[2] * x^2 + ...

    Assumptions:
    - The list contains an even number of coefficients.
    - The highest non-zero coefficient guarantees the existence of a real zero.

    Returns:
        One x value such that the polynomial evaluates to approximately zero.

    Examples:
        >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
        -0.5
        >>> round(find_zero([-6, 11, -6, 1]), 2)
        1.0
    """
    def polynomial_value(x_value: float) -> float:
        return evaluate_polynomial(coefficients, x_value)

    left = -1.0
    right = 1.0
    left_value = polynomial_value(left)
    right_value = polynomial_value(right)

    while left_value * right_value > 0:
        left *= 2
        right *= 2
        left_value = polynomial_value(left)
        right_value = polynomial_value(right)

    tolerance = 1e-7

    while abs(right - left) > tolerance:
        midpoint = (left + right) / 2
        midpoint_value = polynomial_value(midpoint)

        if midpoint_value == 0:
            return midpoint

        if left_value * midpoint_value < 0:
            right = midpoint
            right_value = midpoint_value
        else:
            left = midpoint
            left_value = midpoint_value

    return (left + right) / 2
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
