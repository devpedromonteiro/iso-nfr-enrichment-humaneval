
import unittest
import re
import sys
import math
import copy


def f(n):
    """Return a list of length n based on each position's 1-based index.

    For each index i from 1 to n:
    - if i is even, include factorial(i)
    - if i is odd, include the sum of numbers from 1 to i

    Example:
        f(5) == [1, 2, 6, 24, 15]
    """

    def factorial(number):
        result = 1
        for current in range(1, number + 1):
            result *= current
        return result

    def sum_from_1_to(number):
        return number * (number + 1) // 2

    values = []

    for index in range(1, n + 1):
        if index % 2 == 0:
            values.append(factorial(index))
        else:
            values.append(sum_from_1_to(index))

    return values
candidate = f


def check(candidate):

    assert candidate(5) == [1, 2, 6, 24, 15]
    assert candidate(7) == [1, 2, 6, 24, 15, 720, 28]
    assert candidate(1) == [1]
    assert candidate(3) == [1, 2, 6]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
