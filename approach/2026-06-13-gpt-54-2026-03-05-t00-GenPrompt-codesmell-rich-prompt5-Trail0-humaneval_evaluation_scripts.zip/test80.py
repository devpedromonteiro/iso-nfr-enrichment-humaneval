
import unittest
import re
import sys
import math
import copy


def _has_minimum_length(text, minimum=3):
    """Return True when text length is at least the required minimum."""
    return len(text) >= minimum


def _triplet_is_distinct(triplet):
    """Return True when all characters in the 3-letter window are distinct."""
    return len(set(triplet)) == 3


def _all_consecutive_triplets_are_distinct(text):
    """Check that every 3-character window contains distinct letters."""
    for index in range(len(text) - 2):
        if not _triplet_is_distinct(text[index:index + 3]):
            return False
    return True


def is_happy(s):
    """You are given a string s.
    Your task is to check if the string is happy or not.
    A string is happy if its length is at least 3 and every 3 consecutive letters are distinct
    For example:
    is_happy(a) => False
    is_happy(aa) => False
    is_happy(abcd) => True
    is_happy(aabb) => False
    is_happy(adb) => True
    is_happy(xyy) => False
    """
    if not _has_minimum_length(s):
        return False

    return _all_consecutive_triplets_are_distinct(s)
candidate = is_happy


def check(candidate):

    # Check some simple cases
    assert candidate("a") == False , "a"
    assert candidate("aa") == False , "aa"
    assert candidate("abcd") == True , "abcd"
    assert candidate("aabb") == False , "aabb"
    assert candidate("adb") == True , "adb"
    assert candidate("xyy") == False , "xyy"
    assert candidate("iopaxpoi") == True , "iopaxpoi"
    assert candidate("iopaxioi") == False , "iopaxioi"


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
