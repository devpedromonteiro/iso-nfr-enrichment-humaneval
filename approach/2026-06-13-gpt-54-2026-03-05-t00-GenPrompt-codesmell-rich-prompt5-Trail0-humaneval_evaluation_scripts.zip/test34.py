
import unittest
import re
import sys
import math
import copy



def _deduplicate(items: list):
    """Return unique elements from items, preserving first occurrence order."""
    return list(dict.fromkeys(items))


def _sort_items(items: list):
    """Return a sorted copy of items."""
    return sorted(items)


def unique(l: list):
    """Return sorted unique elements in a list
    >>> unique([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [0, 2, 3, 5, 9, 123]
    """
    unique_items = _deduplicate(l)
    return _sort_items(unique_items)
candidate = unique




METADATA = {}


def check(candidate):
    assert candidate([5, 3, 5, 2, 3, 3, 9, 0, 123]) == [0, 2, 3, 5, 9, 123]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
