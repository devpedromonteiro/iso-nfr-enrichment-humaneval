
import unittest
import re
import sys
import math
import copy



def _is_match_at(text: str, pattern: str, start: int) -> bool:
    """Return True if pattern matches text starting at index start."""
    return text[start:start + len(pattern)] == pattern


def how_many_times(string: str, substring: str) -> int:
    """Find how many times a given substring appears in the original string.

    Overlapping matches are counted.

    >>> how_many_times('', 'a')
    0
    >>> how_many_times('aaa', 'a')
    3
    >>> how_many_times('aaaa', 'aa')
    3
    """
    if not string or not substring:
        return 0

    max_start = len(string) - len(substring)
    if max_start < 0:
        return 0

    return sum(
        1
        for index in range(max_start + 1)
        if _is_match_at(string, substring, index)
    )
candidate = how_many_times




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('', 'x') == 0
    assert candidate('xyxyxyx', 'x') == 4
    assert candidate('cacacacac', 'cac') == 4
    assert candidate('john doe', 'john') == 1


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
