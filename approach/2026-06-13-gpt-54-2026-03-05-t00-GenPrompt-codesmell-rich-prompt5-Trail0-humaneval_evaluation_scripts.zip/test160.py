
import unittest
import re
import sys
import math
import copy


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and
    the second list is a list of integers. Use the two given lists to build the algebraic
    expression and return the evaluation of this expression.

    Supported operations:
    Addition ( + )
    Subtraction ( - )
    Multiplication ( * )
    Floor division ( // )
    Exponentiation ( ** )
    """
    _validate_inputs(operator, operand)
    tokens = _build_tokens(operator, operand)
    return _evaluate_expression(tokens)


def _validate_inputs(operator, operand):
    if len(operator) != len(operand) - 1:
        raise ValueError("operator length must be operand length minus one")
    if len(operator) < 1 or len(operand) < 2:
        raise ValueError("operator must have at least one item and operand at least two items")


def _build_tokens(operator, operand):
    tokens = [operand[0]]
    for op, value in zip(operator, operand[1:]):
        tokens.extend([op, value])
    return tokens


def _evaluate_expression(tokens):
    precedence_groups = [
        {"**"},
        {"*", "//"},
        {"+", "-"},
    ]

    current_tokens = tokens
    for operators in precedence_groups:
        current_tokens = _reduce_operations(current_tokens, operators)

    return current_tokens[0]


def _reduce_operations(tokens, target_operators):
    reduced = [tokens[0]]
    index = 1

    while index < len(tokens):
        op = tokens[index]
        value = tokens[index + 1]

        if op in target_operators:
            left = reduced.pop()
            reduced.append(_apply_operator(op, left, value))
        else:
            reduced.extend([op, value])

        index += 2

    return reduced


def _apply_operator(op, left, right):
    operations = {
        "+": lambda a, b: a + b,
        "-": lambda a, b: a - b,
        "*": lambda a, b: a * b,
        "//": lambda a, b: a // b,
        "**": lambda a, b: a ** b,
    }

    if op not in operations:
        raise ValueError(f"Unsupported operator: {op}")

    return operations[op](left, right)
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
