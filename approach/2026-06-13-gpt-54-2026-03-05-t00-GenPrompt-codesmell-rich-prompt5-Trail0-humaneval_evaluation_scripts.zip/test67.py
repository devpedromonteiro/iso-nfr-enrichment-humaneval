
import unittest
import re
import sys
import math
import copy


import re


def _extract_counts(description):
    """Extract all integer counts from the fruit description string."""
    return [int(value) for value in re.findall(r"\d+", description)]


def _count_known_fruits(description):
    """Return the total number of apples and oranges mentioned in the description."""
    return sum(_extract_counts(description))


def fruit_distribution(s, n):
    """
    Given a string describing apples and oranges in a basket and the total
    number of fruits, return the number of mangoes.

    Examples:
    fruit_distribution("5 apples and 6 oranges", 19) -> 8
    fruit_distribution("0 apples and 1 oranges", 3) -> 2
    """
    known_fruits = _count_known_fruits(s)
    return n - known_fruits
candidate = fruit_distribution


def check(candidate):

    # Check some simple cases
    assert candidate("5 apples and 6 oranges",19) == 8
    assert candidate("5 apples and 6 oranges",21) == 10
    assert candidate("0 apples and 1 oranges",3) == 2
    assert candidate("1 apples and 0 oranges",3) == 2
    assert candidate("2 apples and 3 oranges",100) == 95
    assert candidate("2 apples and 3 oranges",5) == 0
    assert candidate("1 apples and 100 oranges",120) == 19


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
