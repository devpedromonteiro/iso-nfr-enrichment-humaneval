
import unittest
import re
import sys
import math
import copy


from math import comb


def _count_residues_mod_3(n):
    """
    Count how many values of a[i] = i*i - i + 1, for 1 <= i <= n,
    fall into each residue class modulo 3.

    Returns:
        A tuple (c0, c1, c2) where:
        - c0 is the count of values congruent to 0 mod 3
        - c1 is the count of values congruent to 1 mod 3
        - c2 is the count of values congruent to 2 mod 3
    """
    counts = [0, 0, 0]

    for i in range(1, n + 1):
        residue = (i * i - i + 1) % 3
        counts[residue] += 1

    return counts[0], counts[1], counts[2]


def _count_valid_triples(c0, c1, c2):
    """
    Count triples whose sum is divisible by 3 based on residue counts.

    Valid residue combinations are:
    - (0, 0, 0)
    - (1, 1, 1)
    - (2, 2, 2)
    - (0, 1, 2)
    """
    return (
        comb(c0, 3)
        + comb(c1, 3)
        + comb(c2, 3)
        + (c0 * c1 * c2)
    )


def get_max_triples(n):
    """
    You are given a positive integer n. You have to create an integer array a of length n.
    For each i (1 â¤ i â¤ n), the value of a[i] = i * i - i + 1.
    Return the number of triples (a[i], a[j], a[k]) of a where i < j < k,
    and a[i] + a[j] + a[k] is a multiple of 3.

    Example:
        Input: n = 5
        Output: 1
        Explanation:
        a = [1, 3, 7, 13, 21]
        The only valid triple is (1, 7, 13).
    """
    if n < 3:
        return 0

    c0, c1, c2 = _count_residues_mod_3(n)
    return _count_valid_triples(c0, c1, c2)
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
