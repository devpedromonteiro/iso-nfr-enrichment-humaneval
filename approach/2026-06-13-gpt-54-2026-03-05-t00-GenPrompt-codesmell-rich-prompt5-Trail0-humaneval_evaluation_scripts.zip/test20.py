
import unittest
import re
import sys
import math
import copy

from typing import List, Tuple


from typing import List, Tuple


def _sorted_numbers(numbers: List[float]) -> List[float]:
    """Return a sorted copy of the input numbers."""
    return sorted(numbers)


def _closest_pair_in_sorted(numbers: List[float]) -> Tuple[float, float]:
    """Return the closest pair from an already sorted list."""
    closest_pair = (numbers[0], numbers[1])
    smallest_difference = numbers[1] - numbers[0]

    for index in range(1, len(numbers) - 1):
        left = numbers[index]
        right = numbers[index + 1]
        difference = right - left

        if difference < smallest_difference:
            smallest_difference = difference
            closest_pair = (left, right)

    return closest_pair


def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    """From a supplied list of numbers (of length at least two) select and return
    two that are the closest to each other and return them in order
    (smaller number, larger number).

    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.2])
    (2.0, 2.2)
    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.0])
    (2.0, 2.0)
    """
    sorted_numbers = _sorted_numbers(numbers)
    return _closest_pair_in_sorted(sorted_numbers)
candidate = find_closest_elements




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([1.0, 2.0, 3.9, 4.0, 5.0, 2.2]) == (3.9, 4.0)
    assert candidate([1.0, 2.0, 5.9, 4.0, 5.0]) == (5.0, 5.9)
    assert candidate([1.0, 2.0, 3.0, 4.0, 5.0, 2.2]) == (2.0, 2.2)
    assert candidate([1.0, 2.0, 3.0, 4.0, 5.0, 2.0]) == (2.0, 2.0)
    assert candidate([1.1, 2.2, 3.1, 4.1, 5.1]) == (2.2, 3.1)



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
