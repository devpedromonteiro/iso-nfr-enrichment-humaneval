
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Given a grid with N rows and N columns (N >= 2) and a positive integer k,
    return the lexicographically smallest path of length k, where each move
    goes to an edge-adjacent cell.

    The answer is guaranteed to be unique.
    """

    positions = _build_value_positions(grid)
    start_value = 1

    if k == 1:
        return [start_value]

    path = [start_value]
    current_value = start_value

    for _ in range(k - 1):
        current_value = _best_next_value(current_value, positions)
        path.append(current_value)

    return path


def _build_value_positions(grid):
    """Map each cell value to its (row, col) position."""
    positions = {}
    for row_index, row in enumerate(grid):
        for col_index, value in enumerate(row):
            positions[value] = (row_index, col_index)
    return positions


def _best_next_value(value, positions):
    """Return the smallest-valued neighbor of the given cell value."""
    row, col = positions[value]
    best = None

    for neighbor_row, neighbor_col in _neighbor_coordinates(row, col):
        neighbor_value = _value_at_position(neighbor_row, neighbor_col, positions)
        if neighbor_value is not None and (best is None or neighbor_value < best):
            best = neighbor_value

    return best


def _neighbor_coordinates(row, col):
    """Yield coordinates of the four edge-adjacent neighbors."""
    return (
        (row - 1, col),
        (row + 1, col),
        (row, col - 1),
        (row, col + 1),
    )


def _value_at_position(target_row, target_col, positions):
    """Return the cell value at the given position, or None if absent."""
    for value, (row, col) in positions.items():
        if row == target_row and col == target_col:
            return value
    return None
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
