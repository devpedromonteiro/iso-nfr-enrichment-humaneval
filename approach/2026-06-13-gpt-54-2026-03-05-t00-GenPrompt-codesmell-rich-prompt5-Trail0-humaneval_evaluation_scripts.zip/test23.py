
import unittest
import re
import sys
import math
import copy



def _validate_string(value: str) -> None:
    """Validate that the provided value is a string."""
    if not isinstance(value, str):
        raise TypeError("value must be a string")


def strlen(string: str) -> int:
    """Return length of given string.

    >>> strlen('')
    0
    >>> strlen('abc')
    3
    """
    _validate_string(string)
    return len(string)
candidate = strlen




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == 0
    assert candidate('x') == 1
    assert candidate('asdasnakj') == 9


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
