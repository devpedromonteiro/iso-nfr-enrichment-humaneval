
import unittest
import re
import sys
import math
import copy


def _get_last_character(txt):
    """Return the last character of the string, or None if unavailable."""
    if not txt:
        return None
    return txt[-1]


def _get_last_word(txt):
    """Return the last space-separated word, or an empty string if none exists."""
    parts = txt.split(" ")
    return parts[-1] if parts else ""


def check_if_last_char_is_a_letter(txt):
    '''
    Create a function that returns True if the last character
    of a given string is an alphabetical character and is not
    a part of a word, and False otherwise.
    Note: "word" is a group of characters separated by space.

    Examples:
    check_if_last_char_is_a_letter("apple pie") â False
    check_if_last_char_is_a_letter("apple pi e") â True
    check_if_last_char_is_a_letter("apple pi e ") â False
    check_if_last_char_is_a_letter("") â False 
    '''
    last_char = _get_last_character(txt)
    if last_char is None or not last_char.isalpha():
        return False

    last_word = _get_last_word(txt)
    return len(last_word) == 1
candidate = check_if_last_char_is_a_letter


def check(candidate):

    # Check some simple cases
    assert candidate("apple") == False
    assert candidate("apple pi e") == True
    assert candidate("eeeee") == False
    assert candidate("A") == True
    assert candidate("Pumpkin pie ") == False
    assert candidate("Pumpkin pie 1") == False
    assert candidate("") == False
    assert candidate("eeeee e ") == False
    assert candidate("apple pie") == False
    assert candidate("apple pi e ") == False

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
