
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def below_zero(operations: List[int]) -> bool:
    """Return True if the running balance ever drops below zero.

    The account starts with a balance of 0. Each value in `operations`
    represents a deposit (positive int) or withdrawal (negative int).

    Args:
        operations: A list of integer account operations.

    Returns:
        True if the balance becomes negative at any point, otherwise False.

    Raises:
        TypeError: If `operations` is not a list or contains non-integer values.

    Examples:
        >>> below_zero([1, 2, 3])
        False
        >>> below_zero([1, 2, -4, 5])
        True
    """
    if not isinstance(operations, list):
        raise TypeError("operations must be a list of integers")

    balance = 0

    for index, operation in enumerate(operations):
        if not isinstance(operation, int):
            raise TypeError(
                f"operation at index {index} must be an int, got {type(operation).__name__}"
            )

        balance += operation
        if balance < 0:
            return True

    return False
candidate = below_zero




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == False
    assert candidate([1, 2, -3, 1, 2, -3]) == False
    assert candidate([1, 2, -4, 5, 6]) == True
    assert candidate([1, -1, 2, -2, 5, -5, 4, -4]) == False
    assert candidate([1, -1, 2, -2, 5, -5, 4, -5]) == True
    assert candidate([1, -2, 2, -2, 5, -5, 4, -4]) == True


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
