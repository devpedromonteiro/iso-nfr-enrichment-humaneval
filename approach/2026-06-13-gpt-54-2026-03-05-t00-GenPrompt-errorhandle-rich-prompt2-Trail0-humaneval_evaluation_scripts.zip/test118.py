
import unittest
import re
import sys
import math
import copy


def get_closest_vowel(word):
    """Return the rightmost vowel that is between two consonants.

    A vowel at the beginning or end of the word does not count.
    The search is case sensitive in the sense that the original character
    is returned unchanged.

    Args:
        word: A string containing only English letters.

    Returns:
        The closest vowel from the right side that stands between two
        consonants, or an empty string if none exists.

    Raises:
        TypeError: If word is not a string.
        ValueError: If word contains non-alphabetic characters.
    """
    if not isinstance(word, str):
        raise TypeError("word must be a string")

    if not word.isalpha():
        raise ValueError("word must contain only English letters")

    if len(word) < 3:
        return ""

    vowels = set("aeiouAEIOU")

    def is_vowel(ch):
        return ch in vowels

    for i in range(len(word) - 2, 0, -1):
        current = word[i]
        if (
            is_vowel(current)
            and not is_vowel(word[i - 1])
            and not is_vowel(word[i + 1])
        ):
            return current

    return ""
candidate = get_closest_vowel


def check(candidate):

    # Check some simple cases
    assert candidate("yogurt") == "u"
    assert candidate("full") == "u"
    assert candidate("easy") == ""
    assert candidate("eAsy") == ""
    assert candidate("ali") == ""
    assert candidate("bad") == "a"
    assert candidate("most") == "o"
    assert candidate("ab") == ""
    assert candidate("ba") == ""
    assert candidate("quick") == ""
    assert candidate("anime") == "i"
    assert candidate("Asia") == ""
    assert candidate("Above") == "o"

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
