
import unittest
import re
import sys
import math
import copy

from typing import List, Any


from typing import List, Any


def filter_integers(values: List[Any]) -> List[int]:
    """Filter given list of any python values only for integers.

    Rules:
    - `values` must be a list, otherwise a TypeError is raised.
    - Only values whose exact type is `int` are kept.
      (`bool` is excluded even though it is a subclass of `int`.)

    >>> filter_integers(['a', 3.14, 5])
    [5]
    >>> filter_integers([1, 2, 3, 'abc', {}, []])
    [1, 2, 3]
    """
    if values is None:
        raise TypeError("values must be a list, got None")

    if not isinstance(values, list):
        raise TypeError(f"values must be a list, got {type(values).__name__}")

    result: List[int] = []
    for value in values:
        if type(value) is int:
            result.append(value)

    return result
candidate = filter_integers




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == []
    assert candidate([4, {}, [], 23.2, 9, 'adasd']) == [4, 9]
    assert candidate([3, 'c', 3, 3, 'a', 'b']) == [3, 3, 3]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
