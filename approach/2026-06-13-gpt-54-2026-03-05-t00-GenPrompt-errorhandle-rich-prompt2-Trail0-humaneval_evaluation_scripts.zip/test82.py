
import unittest
import re
import sys
import math
import copy


def prime_length(string):
    """Return True if the input string's length is prime, else False.

    Raises:
        TypeError: If `string` is not a str.
    """
    if not isinstance(string, str):
        raise TypeError("prime_length expects a string argument")

    length = len(string)

    if length < 2:
        return False

    if length == 2:
        return True

    if length % 2 == 0:
        return False

    divisor = 3
    while divisor * divisor <= length:
        if length % divisor == 0:
            return False
        divisor += 2

    return True
candidate = prime_length


def check(candidate):

    # Check some simple cases
    assert candidate('Hello') == True
    assert candidate('abcdcba') == True
    assert candidate('kittens') == True
    assert candidate('orange') == False
    assert candidate('wow') == True
    assert candidate('world') == True
    assert candidate('MadaM') == True
    assert candidate('Wow') == True
    assert candidate('') == False
    assert candidate('HI') == True
    assert candidate('go') == True
    assert candidate('gogo') == False
    assert candidate('aaaaaaaaaaaaaaa') == False

    # Check some edge cases that are easy to work out by hand.
    assert candidate('Madam') == True
    assert candidate('M') == False
    assert candidate('0') == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
