
import unittest
import re
import sys
import math
import copy


def sorted_list_sum(lst):
    """Return a sorted list containing only the even-length strings from lst.

    Sorting rules:
    - primary: ascending by string length
    - secondary: alphabetical order for strings of the same length

    Args:
        lst: A list of strings.

    Returns:
        A new sorted list of even-length strings.

    Raises:
        TypeError: If lst is not a list or contains non-string elements.
        ValueError: If lst is None.
    """
    if lst is None:
        raise ValueError("lst cannot be None")

    if not isinstance(lst, list):
        raise TypeError(f"lst must be a list, got {type(lst).__name__}")

    for i, item in enumerate(lst):
        if not isinstance(item, str):
            raise TypeError(
                f"all elements of lst must be strings; "
                f"found {type(item).__name__} at index {i}"
            )

    try:
        even_length_strings = [s for s in lst if len(s) % 2 == 0]
        return sorted(even_length_strings, key=lambda s: (len(s), s))
    except TypeError:
        # Re-raise specific sorting/type issues without swallowing them.
        raise
candidate = sorted_list_sum


def check(candidate):

    # Check some simple cases
    assert candidate(["aa", "a", "aaa"]) == ["aa"]
    assert candidate(["school", "AI", "asdf", "b"]) == ["AI", "asdf", "school"]
    assert candidate(["d", "b", "c", "a"]) == []
    assert candidate(["d", "dcba", "abcd", "a"]) == ["abcd", "dcba"]

    # Check some edge cases that are easy to work out by hand.
    assert candidate(["AI", "ai", "au"]) == ["AI", "ai", "au"]
    assert candidate(["a", "b", "b", "c", "c", "a"]) == []
    assert candidate(['aaaa', 'bbbb', 'dd', 'cc']) == ["cc", "dd", "aaaa", "bbbb"]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
