
import unittest
import re
import sys
import math
import copy


def hex_key(num):
    """Count prime hexadecimal digits in a hexadecimal string.

    Prime hex digits are: 2, 3, 5, 7, B, D.

    Args:
        num: A hexadecimal number represented as a string.

    Returns:
        The count of prime hexadecimal digits in the input string.

    Raises:
        TypeError: If num is not a string.
        ValueError: If num contains non-hexadecimal characters or lowercase letters.
    """
    if not isinstance(num, str):
        raise TypeError("num must be a string")

    if num == "":
        return 0

    valid_digits = set("0123456789ABCDEF")
    prime_digits = set("2357BD")

    invalid_chars = [ch for ch in num if ch not in valid_digits]
    if invalid_chars:
        raise ValueError(
            f"num contains invalid hexadecimal characters: {invalid_chars}"
        )

    return sum(1 for ch in num if ch in prime_digits)
candidate = hex_key


def check(candidate):

    # Check some simple cases
    assert candidate("AB") == 1, "First test error: " + str(candidate("AB"))      
    assert candidate("1077E") == 2, "Second test error: " + str(candidate("1077E"))  
    assert candidate("ABED1A33") == 4, "Third test error: " + str(candidate("ABED1A33"))      
    assert candidate("2020") == 2, "Fourth test error: " + str(candidate("2020"))  
    assert candidate("123456789ABCDEF0") == 6, "Fifth test error: " + str(candidate("123456789ABCDEF0"))      
    assert candidate("112233445566778899AABBCCDDEEFF00") == 12, "Sixth test error: " + str(candidate("112233445566778899AABBCCDDEEFF00"))  


    # Check some edge cases that are easy to work out by hand.
    assert candidate([]) == 0



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
