
import unittest
import re
import sys
import math
import copy


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and
    the second list is a list of integers. Use the two given lists to build the algebraic
    expression and return the evaluation of this expression.

    Supported operators:
        +   Addition
        -   Subtraction
        *   Multiplication
        //  Floor division
        **  Exponentiation

    Validation rules:
        - operator and operand must be lists
        - operator must contain at least one operator
        - operand must contain at least two operands
        - len(operator) must equal len(operand) - 1
        - operands must be non-negative integers
        - operators must be one of the supported symbols

    Raises:
        TypeError: for invalid argument types
        ValueError: for invalid values or unsupported operators
        ZeroDivisionError: when floor division by zero is attempted
    """
    if not isinstance(operator, list):
        raise TypeError("operator must be a list")
    if not isinstance(operand, list):
        raise TypeError("operand must be a list")

    if len(operator) < 1:
        raise ValueError("operator list must contain at least one operator")
    if len(operand) < 2:
        raise ValueError("operand list must contain at least two operands")
    if len(operator) != len(operand) - 1:
        raise ValueError("len(operator) must be equal to len(operand) - 1")

    supported_operators = {"+", "-", "*", "//", "**"}

    for op in operator:
        if not isinstance(op, str):
            raise TypeError(f"operator entries must be strings, got {type(op).__name__}")
        if op not in supported_operators:
            raise ValueError(f"unsupported operator: {op}")

    for value in operand:
        if not isinstance(value, int):
            raise TypeError(f"operand entries must be integers, got {type(value).__name__}")
        if value < 0:
            raise ValueError(f"operand entries must be non-negative, got {value}")

    expression = str(operand[0])
    for op, value in zip(operator, operand[1:]):
        expression += f" {op} {value}"

    try:
        return eval(expression)
    except ZeroDivisionError:
        raise
    except OverflowError:
        raise
    except SyntaxError as exc:
        raise ValueError(f"failed to build a valid algebraic expression: {expression}") from exc
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
