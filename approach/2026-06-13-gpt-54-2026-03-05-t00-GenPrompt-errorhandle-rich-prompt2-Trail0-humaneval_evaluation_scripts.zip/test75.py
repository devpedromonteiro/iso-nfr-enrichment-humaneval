
import unittest
import re
import sys
import math
import copy


def is_multiply_prime(a):
    """Return True if `a` is the product of exactly 3 prime numbers, else False.

    A prime factor may repeat, e.g. 8 = 2 * 2 * 2 -> True.

    Constraints handled:
    - validates input type and value explicitly
    - raises specific exceptions for invalid arguments
    - does not silently swallow errors
    """
    if not isinstance(a, int):
        raise TypeError("a must be an integer")
    if a < 0:
        raise ValueError("a must be non-negative")
    if a >= 100:
        raise ValueError("a must be less than 100")

    def is_prime(n):
        if n < 2:
            return False
        for i in range(2, int(n ** 0.5) + 1):
            if n % i == 0:
                return False
        return True

    prime_factors = []

    remaining = a
    for i in range(2, a + 1):
        while remaining % i == 0:
            if is_prime(i):
                prime_factors.append(i)
                remaining //= i
                if len(prime_factors) > 3:
                    return False
            else:
                break

        if remaining == 1:
            break

    return len(prime_factors) == 3 and remaining == 1
candidate = is_multiply_prime


def check(candidate):

    assert candidate(5) == False
    assert candidate(30) == True
    assert candidate(8) == True
    assert candidate(10) == False
    assert candidate(125) == True
    assert candidate(3 * 5 * 7) == True
    assert candidate(3 * 6 * 7) == False
    assert candidate(9 * 9 * 9) == False
    assert candidate(11 * 9 * 9) == False
    assert candidate(11 * 13 * 7) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
