
import unittest
import re
import sys
import math
import copy


from fractions import Fraction


def simplify(x, n):
    """Return True if x * n evaluates to a whole number, otherwise False.

    Both x and n must be strings in the form "<numerator>/<denominator>",
    where numerator and denominator are positive whole numbers.

    Raises:
        TypeError: if x or n is not a string.
        ValueError: if x or n is not in the expected fraction format or contains
                    non-positive values.
        ZeroDivisionError: if a denominator is zero.
    """
    def parse_fraction(value, name):
        if not isinstance(value, str):
            raise TypeError(f"{name} must be a string, got {type(value).__name__}")

        parts = value.split("/")
        if len(parts) != 2:
            raise ValueError(
                f"{name} must be in the format '<numerator>/<denominator>'"
            )

        numerator_str, denominator_str = parts

        if not numerator_str.isdigit() or not denominator_str.isdigit():
            raise ValueError(
                f"{name} must contain positive whole numbers only"
            )

        numerator = int(numerator_str)
        denominator = int(denominator_str)

        if numerator <= 0:
            raise ValueError(f"{name} numerator must be a positive whole number")
        if denominator == 0:
            raise ZeroDivisionError(f"{name} denominator cannot be zero")
        if denominator < 0:
            raise ValueError(f"{name} denominator must be a positive whole number")

        return Fraction(numerator, denominator)

    frac_x = parse_fraction(x, "x")
    frac_n = parse_fraction(n, "n")

    product = frac_x * frac_n
    return product.denominator == 1
candidate = simplify


def check(candidate):

    # Check some simple cases
    assert candidate("1/5", "5/1") == True, 'test1'
    assert candidate("1/6", "2/1") == False, 'test2'
    assert candidate("5/1", "3/1") == True, 'test3'
    assert candidate("7/10", "10/2") == False, 'test4'
    assert candidate("2/10", "50/10") == True, 'test5'
    assert candidate("7/2", "4/2") == True, 'test6'
    assert candidate("11/6", "6/1") == True, 'test7'
    assert candidate("2/3", "5/2") == False, 'test8'
    assert candidate("5/2", "3/5") == False, 'test9'
    assert candidate("2/4", "8/4") == True, 'test10'


    # Check some edge cases that are easy to work out by hand.
    assert candidate("2/4", "4/2") == True, 'test11'
    assert candidate("1/5", "5/1") == True, 'test12'
    assert candidate("1/5", "1/5") == False, 'test13'



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
