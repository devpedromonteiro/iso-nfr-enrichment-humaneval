
import unittest
import re
import sys
import math
import copy


def total_match(lst1, lst2):
    '''
    Write a function that accepts two lists of strings and returns the list that has 
    total number of chars in the all strings of the list less than the other list.

    if the two lists have the same number of chars, return the first list.

    Examples
    total_match([], []) â []
    total_match(['hi', 'admin'], ['hI', 'Hi']) â ['hI', 'Hi']
    total_match(['hi', 'admin'], ['hi', 'hi', 'admin', 'project']) â ['hi', 'admin']
    total_match(['hi', 'admin'], ['hI', 'hi', 'hi']) â ['hI', 'hi', 'hi']
    total_match(['4'], ['1', '2', '3', '4', '5']) â ['4']
    '''
    if not isinstance(lst1, list):
        raise TypeError("lst1 must be a list of strings")
    if not isinstance(lst2, list):
        raise TypeError("lst2 must be a list of strings")

    for i, item in enumerate(lst1):
        if not isinstance(item, str):
            raise TypeError(f"lst1[{i}] must be a string, got {type(item).__name__}")
    for i, item in enumerate(lst2):
        if not isinstance(item, str):
            raise TypeError(f"lst2[{i}] must be a string, got {type(item).__name__}")

    total1 = sum(len(s) for s in lst1)
    total2 = sum(len(s) for s in lst2)

    return lst1 if total1 <= total2 else lst2
candidate = total_match


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([], []) == []
    assert candidate(['hi', 'admin'], ['hi', 'hi']) == ['hi', 'hi']
    assert candidate(['hi', 'admin'], ['hi', 'hi', 'admin', 'project']) == ['hi', 'admin']
    assert candidate(['4'], ['1', '2', '3', '4', '5']) == ['4']
    assert candidate(['hi', 'admin'], ['hI', 'Hi']) == ['hI', 'Hi']
    assert candidate(['hi', 'admin'], ['hI', 'hi', 'hi']) == ['hI', 'hi', 'hi']
    assert candidate(['hi', 'admin'], ['hI', 'hi', 'hii']) == ['hi', 'admin']


    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([], ['this']) == []
    assert candidate(['this'], []) == []



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
