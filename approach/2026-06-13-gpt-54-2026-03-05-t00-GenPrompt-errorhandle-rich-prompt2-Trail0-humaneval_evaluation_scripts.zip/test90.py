
import unittest
import re
import sys
import math
import copy


def next_smallest(lst):
    """
    Return the 2nd smallest distinct integer in the list.

    Rules:
    - Return None if there is no 2nd smallest distinct value.
    - Raise TypeError if lst is not a list.
    - Raise ValueError if any element is not an integer.
    """
    if not isinstance(lst, list):
        raise TypeError("lst must be a list")

    if not lst:
        return None

    for item in lst:
        if not isinstance(item, int):
            raise ValueError("all elements in lst must be integers")

    unique_values = set(lst)
    if len(unique_values) < 2:
        return None

    try:
        return sorted(unique_values)[1]
    except IndexError as exc:
        # Defensive safeguard: preserves explicit error handling
        raise RuntimeError("failed to determine the second smallest element") from exc
candidate = next_smallest


def check(candidate):

    # Check some simple cases
    assert candidate([1, 2, 3, 4, 5]) == 2
    assert candidate([5, 1, 4, 3, 2]) == 2
    assert candidate([]) == None
    assert candidate([1, 1]) == None
    assert candidate([1,1,1,1,0]) == 1
    assert candidate([1, 0**0]) == None
    assert candidate([-35, 34, 12, -45]) == -35

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
