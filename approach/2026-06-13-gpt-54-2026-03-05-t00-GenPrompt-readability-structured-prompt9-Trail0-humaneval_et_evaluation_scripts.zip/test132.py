
import unittest


def is_nested(bracket_string):
    """
    Return True if the string contains a valid bracket subsequence
    with at least one nested pair of square brackets.

    A nested structure exists when, while scanning left to right,
    we encounter an opening bracket while another opening bracket
    is already unmatched.

    Examples:
        is_nested('[[]]') -> True
        is_nested('[]]]]]]][[[[[]') -> False
        is_nested('[][]') -> False
        is_nested('[]') -> False
        is_nested('[[][]]') -> True
        is_nested('[[]][[') -> True
    """
    open_bracket_count = 0

    for bracket in bracket_string:
        if bracket == '[':
            if open_bracket_count > 0:
                return True
            open_bracket_count += 1
        else:  # bracket == ']'
            if open_bracket_count > 0:
                open_bracket_count -= 1

    return False
candidate = is_nested


class Test(unittest.TestCase):
    def test(self):
        assert candidate('[[]') == False
        assert candidate("[]]]][[]") == False
        assert candidate('[]]]]]]][[[[[]') == False
        assert candidate("][[[[]]") == True
        assert candidate("[][[][][") == True
        assert candidate(('[]')) == False
        assert candidate("[][][[[[[]]") == True
        assert candidate('[[]][[') == True
        assert candidate("][][[") == False
        assert candidate('') == False
        assert candidate("[]][") == False
        assert candidate("][][][]]]") == True
        assert candidate("]][[[[][][]") == True
        assert candidate("[[[]][][[") == True
        assert candidate("b") == False
        assert candidate("][][][]") == True
        assert candidate("[[[][]]][") == True
        assert candidate("][]]]]]]]") == False
        assert candidate("[][[[]") == False
        assert candidate("]][][]]") == True
        assert candidate('[][][[]]') == True
        assert candidate("[]]][[[") == False
        assert candidate("[]][[[[]]") == True
        assert candidate("][][[][]") == True
        assert candidate("[][[]") == False
        assert candidate('[[[[[[[[') == False
        assert candidate("]]]]][][]][[[]") == True
        assert candidate("][[]]") == True
        assert candidate("][]]][][[][]") == True
        assert candidate("]]]][[]][") == True
        assert candidate("][[][]") == True
        assert candidate('[[]]') == True
        assert candidate("[]]]][") == False
        assert candidate("gv") == False
        assert candidate("[[[[][[[") == False
        assert candidate("]][][][]]") == True
        assert candidate("]]]][][]]]]") == True
        assert candidate("][]]]][[]]") == True
        assert candidate("][[[") == False
        assert candidate("][[[]]]") == True
        assert candidate("[[][]") == True
        assert candidate("][[[]") == False
        assert candidate("][]][]") == False
        assert candidate("]]][") == False
        assert candidate("[[[[]]][[[[]") == True
        assert candidate("ol") == False
        assert candidate("][[][][[") == True
        assert candidate("][[]]]") == True
        assert candidate("]][[") == False
        assert candidate("][]]") == False
        assert candidate("][][]][[[") == True
        assert candidate("ljv") == False
        assert candidate('[[[[]]]]') == True
        assert candidate("]]][[") == False
        assert candidate("[]]]]") == False
        assert candidate("][[]") == False
        assert candidate("][]]]]") == False
        assert candidate("]][[]]]][[][") == True
        assert candidate("][[][[]") == True
        assert candidate("[[[[[][][[") == True
        assert candidate("][]][][") == False
        assert candidate("adx") == False
        assert candidate("][]][") == False
        assert candidate("[[]][][]]") == True
        assert candidate("[][[[]][]]]") == True
        assert candidate("][[[]][") == True
        assert candidate("]]]") == False
        assert candidate("][[]]][][]][") == True
        assert candidate("[[]]]") == True
        assert candidate("uh") == False
        assert candidate("]][]][[][") == False
        assert candidate("]]]]]][]") == False
        assert candidate("]]]]]") == False
        assert candidate(']]]]]]]]') == False
        assert candidate("[]]][[]][") == True
        assert candidate("[[][]]]]") == True
        assert candidate("[]][][[]]") == True
        assert candidate("][]]][][]]") == True
        assert candidate("[]]][[[[[]") == False
        assert candidate("]]]]]][[[") == False
        assert candidate("]]][[][[[") == False
        assert candidate("]]][]]]]][[[][[") == False
        assert candidate("[[[[][") == False
        assert candidate("[][]][[[]][[[][") == True
        assert candidate("[[[]]]") == True
        assert candidate("]][]][]]][") == True
        assert candidate("[[][][]") == True
        assert candidate('[][]') == False
        assert candidate("]][") == False
        assert candidate("[]][[]]]") == True
        assert candidate("[][]]") == True
        assert candidate("][[") == False
        assert candidate("]][][[") == False
        assert candidate("]]][[]][][]][[][]]") == True
        assert candidate("]][[[[") == False
        assert candidate("]]][][[[[][]]") == True
        assert candidate("][[]][[[[") == True
        assert candidate("c") == False
        assert candidate("]][[]]") == True
        assert candidate("[]][][][]") == True
        assert candidate("][]][[[") == False
        assert candidate("[]]]][[]]][][]") == True
        assert candidate("]]]][[[[") == False
        assert candidate("[[[[[[[[][]]") == True
        assert candidate("[][][[") == False
        assert candidate("][[][[[[") == False
        assert candidate("]]]][]") == False
        assert candidate("]][[[][][[[") == True
        assert candidate("[[[[[[") == False
        assert candidate("[][[") == False
        assert candidate('[]]]]]]]]]]') == False
        assert candidate('[[][]]') == True

    # Check some edge cases that are easy to work out by hand.
        assert candidate("[][[][]]]]") == True
        assert candidate('[]]') == False
        assert candidate("][]]][[") == False
        assert candidate("[][[][[][") == True
        assert candidate("[]][[") == False
        assert candidate("[][]][]][") == True
        assert candidate("[[]][[") == True
        assert candidate("[[[[]]][[[[[") == True
        assert candidate("uz") == False
        assert candidate("]][]]]]") == False
        assert candidate("[[[]][][][]") == True
        assert candidate("]]][[]][[") == True
        assert candidate("[]][]") == False
        assert candidate("[][][[[[[][") == True
        assert candidate("h") == False
        assert candidate("[]]]]][[]") == False

if __name__ == '__main__':
    unittest.main()
