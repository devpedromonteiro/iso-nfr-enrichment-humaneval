
import unittest


def generate_integers(a, b):
    """
    Given two positive integers a and b, return the even digits between a
    and b, in ascending order.

    For example:
    generate_integers(2, 8) => [2, 4, 6, 8]
    generate_integers(8, 2) => [2, 4, 6, 8]
    generate_integers(10, 14) => []
    """
    lower_bound = min(a, b)
    upper_bound = max(a, b)
    even_digits = []

    for number in range(lower_bound, upper_bound + 1):
        is_even = number % 2 == 0
        is_single_digit = 0 <= number <= 9

        if is_even and is_single_digit:
            even_digits.append(number)

    return even_digits
candidate = generate_integers


class Test(unittest.TestCase):
    def test(self):
        assert candidate(5, 9) == [6, 8]
        assert candidate(16, 88) == []
        assert candidate(8, 5) == [6, 8]
        assert candidate(16, 84) == []
        assert candidate(9, 5) == [6, 8]
        assert candidate(5, 5) == []
        assert candidate(130, 1) == [2, 4, 6, 8]
        assert candidate(9, 4) == [4, 6, 8]
        assert candidate(17,89) == [], "Test 4"

    # Check some edge cases that are easy to work out by hand.
        assert candidate(11, 5) == [6, 8]
        assert candidate(127, 7) == [8]
        assert candidate(4, 15) == [4, 6, 8]
        assert candidate(6, 9) == [6, 8]
        assert candidate(131, 3) == [4, 6, 8]
        assert candidate(135, 4) == [4, 6, 8]
        assert candidate(19, 93) == []
        assert candidate(9, 6) == [6, 8]
        assert candidate(15, 86) == []
        assert candidate(13, 86) == []
        assert candidate(5, 4) == [4]
        assert candidate(3, 12) == [4, 6, 8]
        assert candidate(135, 5) == [6, 8]
        assert candidate(22, 91) == []
        assert candidate(3, 14) == [4, 6, 8]
        assert candidate(15, 92) == []
        assert candidate(7, 7) == []
        assert candidate(13, 90) == []
        assert candidate(5, 15) == [6, 8]
        assert candidate(133, 3) == [4, 6, 8]
        assert candidate(4, 13) == [4, 6, 8]
        assert candidate(6, 3) == [4, 6]
        assert candidate(128, 3) == [4, 6, 8]
        assert candidate(2, 15) == [2, 4, 6, 8]
        assert candidate(7, 15) == [8]
        assert candidate(17, 86) == []
        assert candidate(14, 85) == []
        assert candidate(5, 6) == [6]
        assert candidate(16, 92) == []
        assert candidate(11, 4) == [4, 6, 8]
        assert candidate(1, 15) == [2, 4, 6, 8]
        assert candidate(130, 3) == [4, 6, 8]
        assert candidate(12, 89) == []
        assert candidate(21, 92) == []
        assert candidate(131, 1) == [2, 4, 6, 8]
        assert candidate(19, 89) == []
        assert candidate(10, 4) == [4, 6, 8]
        assert candidate(3, 13) == [4, 6, 8]
        assert candidate(1, 14) == [2, 4, 6, 8]
        assert candidate(10, 2) == [2, 4, 6, 8], "Test 2"
        assert candidate(15, 91) == []
        assert candidate(135, 3) == [4, 6, 8]
        assert candidate(6, 7) == [6]
        assert candidate(16, 89) == []
        assert candidate(6, 12) == [6, 8]
        assert candidate(7, 1) == [2, 4, 6]
        assert candidate(12, 88) == []
        assert candidate(6, 6) == [6]
        assert candidate(16, 86) == []
        assert candidate(14, 4) == [4, 6, 8]
        assert candidate(12, 91) == []
        assert candidate(3, 7) == [4, 6]
        assert candidate(134, 7) == [8]
        assert candidate(20, 93) == []
        assert candidate(11, 7) == [8]
        assert candidate(18, 92) == []
        assert candidate(6, 15) == [6, 8]
        assert candidate(132, 2) == [2, 4, 6, 8]
        assert candidate(10, 6) == [6, 8]
        assert candidate(137, 6) == [6, 8]
        assert candidate(128, 7) == [8]
        assert candidate(14, 92) == []
        assert candidate(133, 1) == [2, 4, 6, 8]
        assert candidate(14, 89) == []
        assert candidate(4, 12) == [4, 6, 8]
        assert candidate(13, 2) == [2, 4, 6, 8]
        assert candidate(133, 2) == [2, 4, 6, 8]
        assert candidate(136, 3) == [4, 6, 8]
        assert candidate(17, 93) == []
        assert candidate(132, 2) == [2, 4, 6, 8], "Test 3"
        assert candidate(129, 7) == [8]
        assert candidate(7, 6) == [6]
        assert candidate(22, 92) == []
        assert candidate(132, 3) == [4, 6, 8]
        assert candidate(5, 8) == [6, 8]
        assert candidate(14, 6) == [6, 8]
        assert candidate(132, 4) == [4, 6, 8]
        assert candidate(2, 10) == [2, 4, 6, 8], "Test 1"
        assert candidate(133, 5) == [6, 8]
        assert candidate(15, 4) == [4, 6, 8]
        assert candidate(127, 2) == [2, 4, 6, 8]
        assert candidate(134, 5) == [6, 8]
        assert candidate(137, 5) == [6, 8]
        assert candidate(136, 2) == [2, 4, 6, 8]
        assert candidate(8, 2) == [2, 4, 6, 8]
        assert candidate(134, 1) == [2, 4, 6, 8]
        assert candidate(1, 13) == [2, 4, 6, 8]
        assert candidate(129, 4) == [4, 6, 8]
        assert candidate(22, 86) == []
        assert candidate(11, 2) == [2, 4, 6, 8]
        assert candidate(137, 7) == [8]
        assert candidate(15, 7) == [8]
        assert candidate(6, 11) == [6, 8]
        assert candidate(4, 8) == [4, 6, 8]
        assert candidate(12, 6) == [6, 8]
        assert candidate(130, 7) == [8]
        assert candidate(4, 11) == [4, 6, 8]
        assert candidate(6, 5) == [6]
        assert candidate(8, 7) == [8]
        assert candidate(21, 85) == []

if __name__ == '__main__':
    unittest.main()
