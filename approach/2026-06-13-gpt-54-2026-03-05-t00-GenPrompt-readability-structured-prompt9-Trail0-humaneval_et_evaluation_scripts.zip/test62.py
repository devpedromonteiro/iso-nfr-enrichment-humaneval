
import unittest



def derivative(coefficients: list):
    """Return the derivative coefficients of a polynomial.

    The input list represents a polynomial in ascending powers of x:
    coefficients[0] + coefficients[1] * x + coefficients[2] * x^2 + ...

    The returned list uses the same representation for the derivative.

    >>> derivative([3, 1, 2, 4, 5])
    [1, 4, 12, 20]
    >>> derivative([1, 2, 3])
    [2, 6]
    """
    derivative_coefficients = []

    for power, coefficient in enumerate(coefficients[1:], start=1):
        derivative_coefficients.append(power * coefficient)

    return derivative_coefficients
candidate = derivative


class Test(unittest.TestCase):
    def test(self):
        assert candidate([1, 2, 3, 1, 10]) == [2, 6, 3, 40]
        assert candidate([7, 5, 4, 2, 7]) == [5, 8, 6, 28]
        assert candidate([6, 7, 1]) == [7, 2]
        assert candidate([6, 4, 7]) == [4, 14]
        assert candidate([2, 1, 2]) == [1, 4]
        assert candidate([7, 7, 1, 1, 6]) == [7, 2, 3, 24]
        assert candidate([2, 1, 4, 8, 10]) == [1, 8, 24, 40]
        assert candidate([3, 7, 6, 1, 8]) == [7, 12, 3, 32]
        assert candidate([5, 6, 5]) == [6, 10]
        assert candidate([1, 5, 3, 5, 9]) == [5, 6, 15, 36]
        assert candidate([2, 5, 5, 5, 6]) == [5, 10, 15, 24]
        assert candidate([3, 1, 2, 4, 5]) == [1, 4, 12, 20]
        assert candidate([3, 2, 3, 9, 3]) == [2, 6, 27, 12]
        assert candidate([1, 1, 1, 2, 6]) == [1, 2, 6, 24]
        assert candidate([4, 4, 3, 6, 10]) == [4, 6, 18, 40]
        assert candidate([2, 2, 1, 1, 9]) == [2, 2, 3, 36]
        assert candidate([6, 7, 4]) == [7, 8]
        assert candidate([8, 5, 3, 1, 4]) == [5, 6, 3, 16]
        assert candidate([4, 2, 3, 8, 1]) == [2, 6, 24, 4]
        assert candidate([5, 7, 3]) == [7, 6]
        assert candidate([6, 7, 2]) == [7, 4]
        assert candidate([5, 5, 2, 5, 6]) == [5, 4, 15, 24]
        assert candidate([4, 4, 4, 1, 5]) == [4, 8, 3, 20]
        assert candidate([4, 1, 4, 6, 4]) == [1, 8, 18, 16]
        assert candidate([1, 6, 5, 4, 2]) == [6, 10, 12, 8]
        assert candidate([2, 4, 5]) == [4, 10]
        assert candidate([5, 6, 2, 5, 3]) == [6, 4, 15, 12]
        assert candidate([2, 6, 1]) == [6, 2]
        assert candidate([8, 7, 2]) == [7, 4]
        assert candidate([4, 3, 3, 8, 9]) == [3, 6, 24, 36]
        assert candidate([4, 5, 3]) == [5, 6]
        assert candidate([6, 6, 4, 1, 4]) == [6, 8, 3, 16]
        assert candidate([6, 3, 5, 2, 7]) == [3, 10, 6, 28]
        assert candidate([1, 2, 3]) == [2, 6]
        assert candidate([6, 3, 2]) == [3, 4]
        assert candidate([3, 4, 5, 2, 2]) == [4, 10, 6, 8]
        assert candidate([6, 7, 6]) == [7, 12]
        assert candidate([2, 4, 5, 4, 1]) == [4, 10, 12, 4]
        assert candidate([1, 7, 7]) == [7, 14]
        assert candidate([5, 2, 2, 3, 7]) == [2, 4, 9, 28]
        assert candidate([6, 3, 2, 2, 9]) == [3, 4, 6, 36]
        assert candidate([6, 2, 2]) == [2, 4]
        assert candidate([7, 3, 6, 4, 6]) == [3, 12, 12, 24]
        assert candidate([4, 3, 1]) == [3, 2]
        assert candidate([6, 5, 6, 3, 3]) == [5, 12, 9, 12]
        assert candidate([5, 2, 6, 7, 8]) == [2, 12, 21, 32]
        assert candidate([1, 1, 5]) == [1, 10]
        assert candidate([4, 4, 2]) == [4, 4]
        assert candidate([5, 6, 5, 1, 3]) == [6, 10, 3, 12]
        assert candidate([1]) == []
        assert candidate([5, 4, 6]) == [4, 12]
        assert candidate([7, 3, 5, 5, 7]) == [3, 10, 15, 28]
        assert candidate([1, 2, 1]) == [2, 2]
        assert candidate([4, 1, 4, 5, 3]) == [1, 8, 15, 12]
        assert candidate([1, 6, 1]) == [6, 2]
        assert candidate([2, 2, 2]) == [2, 4]
        assert candidate([6, 4, 6, 8, 10]) == [4, 12, 24, 40]
        assert candidate([4, 5, 1]) == [5, 2]
        assert candidate([4, 1, 3, 4, 9]) == [1, 6, 12, 36]
        assert candidate([7, 4, 6, 8, 6]) == [4, 12, 24, 24]
        assert candidate([4, 2, 6]) == [2, 12]
        assert candidate([3, 4, 6]) == [4, 12]
        assert candidate([4, 4, 3, 4, 6]) == [4, 6, 12, 24]
        assert candidate([6, 2, 5]) == [2, 10]
        assert candidate([4, 4, 1, 5, 1]) == [4, 2, 15, 4]
        assert candidate([7, 5, 4, 2, 9]) == [5, 8, 6, 36]
        assert candidate([2, 7, 1]) == [7, 2]
        assert candidate([5, 3, 3]) == [3, 6]
        assert candidate([4, 2, 4]) == [2, 8]
        assert candidate([2, 4, 2]) == [4, 4]
        assert candidate([6, 5, 1]) == [5, 2]
        assert candidate([6, 4, 6]) == [4, 12]
        assert candidate([7, 5, 6]) == [5, 12]
        assert candidate([3, 3, 4, 1, 6]) == [3, 8, 3, 24]
        assert candidate([8, 5, 5, 3, 9]) == [5, 10, 9, 36]
        assert candidate([1, 4, 4, 1, 7]) == [4, 8, 3, 28]
        assert candidate([5, 1, 7, 8, 10]) == [1, 14, 24, 40]
        assert candidate([4, 1, 4]) == [1, 8]
        assert candidate([1, 3, 3]) == [3, 6]
        assert candidate([1, 7, 3, 2, 8]) == [7, 6, 6, 32]
        assert candidate([3, 1, 8]) == [1, 16]
        assert candidate([1, 2, 4]) == [2, 8]
        assert candidate([2, 6, 3, 4, 1]) == [6, 6, 12, 4]
        assert candidate([7, 4, 6, 4, 6]) == [4, 12, 12, 24]
        assert candidate([2, 3, 3]) == [3, 6]
        assert candidate([3, 2, 4, 4, 2]) == [2, 8, 12, 8]
        assert candidate([3, 2, 1]) == [2, 2]
        assert candidate([3, 3, 3]) == [3, 6]
        assert candidate([2, 7, 5, 3, 4]) == [7, 10, 9, 16]
        assert candidate([1, 1, 7]) == [1, 14]
        assert candidate([2, 6, 2, 6, 2]) == [6, 4, 18, 8]
        assert candidate([5, 6, 4]) == [6, 8]
        assert candidate([8, 6, 3]) == [6, 6]
        assert candidate([5, 5, 5, 2, 2]) == [5, 10, 6, 8]
        assert candidate([1, 6, 6]) == [6, 12]
        assert candidate([6, 3, 4, 2, 1]) == [3, 8, 6, 4]
        assert candidate([4, 2, 5]) == [2, 10]
        assert candidate([6, 5, 5]) == [5, 10]
        assert candidate([3, 2, 1, 0, 4]) == [2, 2, 0, 16]

if __name__ == '__main__':
    unittest.main()
