
import unittest



def modp(n: int, p: int):
    """Return 2^n modulo p using fast modular exponentiation.

    >>> modp(3, 5)
    3
    >>> modp(1101, 101)
    2
    >>> modp(0, 101)
    1
    >>> modp(3, 11)
    8
    >>> modp(100, 101)
    1
    """
    if p <= 0:
        raise ValueError("p must be a positive integer")
    if n < 0:
        raise ValueError("n must be a non-negative integer")

    result = 1
    base = 2 % p
    exponent = n

    while exponent > 0:
        if exponent % 2 == 1:
            result = (result * base) % p
        base = (base * base) % p
        exponent //= 2

    return result
candidate = modp


class Test(unittest.TestCase):
    def test(self):
        assert candidate(104, 97) == 62
        assert candidate(97, 102) == 2
        assert candidate(28, 9) == 7
        assert candidate(4, 8) == 0
        assert candidate(3, 11) == 8
        assert candidate(1, 106) == 2
        assert candidate(4, 12) == 4
        assert candidate(102, 104) == 64
        assert candidate(6, 9) == 1
        assert candidate(1, 103) == 2
        assert candidate(26, 9) == 4
        assert candidate(1101, 101) == 2
        assert candidate(34, 8) == 0
        assert candidate(35, 8) == 0
        assert candidate(1376, 99) == 31
        assert candidate(25, 3) == 2
        assert candidate(7, 7) == 2
        assert candidate(100, 101) == 1
        assert candidate(2, 100) == 4
        assert candidate(102, 105) == 64
        assert candidate(1, 9) == 2
        assert candidate(33, 7) == 1
        assert candidate(3, 101) == 8
        assert candidate(892, 106) == 44
        assert candidate(4, 14) == 2
        assert candidate(31, 6) == 2
        assert candidate(1950, 97) == 33
        assert candidate(6, 7) == 1
        assert candidate(101, 99) == 68
        assert candidate(31, 3) == 2
        assert candidate(1257, 99) == 62
        assert candidate(6, 3) == 1
        assert candidate(32, 7) == 4
        assert candidate(8, 6) == 4
        assert candidate(1, 7) == 2
        assert candidate(3, 104) == 8
        assert candidate(96, 99) == 64
        assert candidate(497, 96) == 32
        assert candidate(33, 8) == 0
        assert candidate(30, 10) == 4
        assert candidate(2, 9) == 4
        assert candidate(36, 3) == 1
        assert candidate(1357, 101) == 74
        assert candidate(1670, 104) == 56
        assert candidate(125, 96) == 32
        assert candidate(6, 1) == 0
        assert candidate(35, 2) == 0
        assert candidate(32, 9) == 4
        assert candidate(1625, 103) == 33
        assert candidate(7, 2) == 0
        assert candidate(102, 100) == 4
        assert candidate(8, 13) == 9
        assert candidate(27, 7) == 1
        assert candidate(280, 98) == 30
        assert candidate(597, 102) == 32
        assert candidate(2, 8) == 4
        assert candidate(1, 98) == 2
        assert candidate(104, 106) == 54
        assert candidate(33, 10) == 2
        assert candidate(2, 101) == 4
        assert candidate(1000, 105) == 16
        assert candidate(2, 96) == 4
        assert candidate(29, 5) == 2
        assert candidate(28, 6) == 4
        assert candidate(1, 105) == 2
        assert candidate(95, 106) == 50
        assert candidate(97, 99) == 29
        assert candidate(7, 11) == 7
        assert candidate(3, 13) == 8
        assert candidate(3, 14) == 8
        assert candidate(95, 101) == 60
        assert candidate(4, 99) == 16
        assert candidate(4, 7) == 2
        assert candidate(31, 1) == 0
        assert candidate(5, 16) == 0
        assert candidate(5, 102) == 32
        assert candidate(26, 5) == 4
        assert candidate(4, 16) == 0
        assert candidate(0, 101) == 1
        assert candidate(104, 104) == 48
        assert candidate(96, 100) == 36
        assert candidate(32, 6) == 4
        assert candidate(26, 8) == 0
        assert candidate(103, 97) == 31
        assert candidate(1, 4) == 2
        assert candidate(2, 97) == 4
        assert candidate(25, 8) == 0
        assert candidate(5, 12) == 8
        assert candidate(2, 104) == 4
        assert candidate(1, 14) == 2
        assert candidate(34, 6) == 4
        assert candidate(1161, 104) == 96
        assert candidate(1999, 96) == 32
        assert candidate(3, 103) == 8
        assert candidate(30, 3) == 1
        assert candidate(4, 6) == 4
        assert candidate(7, 8) == 0
        assert candidate(30, 5) == 4
        assert candidate(457, 101) == 74
        assert candidate(36, 2) == 0
        assert candidate(4, 104) == 16
        assert candidate(1, 104) == 2
        assert candidate(35, 7) == 4
        assert candidate(4, 5) == 1
        assert candidate(26, 2) == 0
        assert candidate(100, 105) == 16
        assert candidate(102, 103) == 1
        assert candidate(377, 99) == 95
        assert candidate(1262, 98) == 4
        assert candidate(1, 101) == 2
        assert candidate(1, 1) == 0
        assert candidate(30, 8) == 0
        assert candidate(28, 5) == 1
        assert candidate(99, 104) == 8
        assert candidate(3, 5) == 3
        assert candidate(31, 5) == 3
        assert candidate(7, 10) == 8
        assert candidate(33, 9) == 8
        assert candidate(5, 15) == 2
        assert candidate(3, 4) == 0

if __name__ == '__main__':
    unittest.main()
