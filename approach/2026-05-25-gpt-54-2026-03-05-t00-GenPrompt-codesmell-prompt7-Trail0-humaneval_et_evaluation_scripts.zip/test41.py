
import unittest



def car_race_collision(n: int) -> int:
    """
    Return the total number of collisions between two groups of cars.

    There are:
    - n cars moving left to right
    - n cars moving right to left

    Every left-to-right car collides exactly once with every right-to-left car,
    so the total number of collisions is n * n.

    Args:
        n: Number of cars in each group. Must be a non-negative integer.

    Returns:
        Total number of collisions.

    Raises:
        TypeError: If n is not an integer.
        ValueError: If n is negative.
    """
    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if n < 0:
        raise ValueError("n must be non-negative")

    return n * n
candidate = car_race_collision


class Test(unittest.TestCase):
    def test(self):
        assert candidate(79) == 6241
        assert candidate(125) == 15625
        assert candidate(169) == 28561
        assert candidate(195) == 38025
        assert candidate(85) == 7225
        assert candidate(199) == 39601
        assert candidate(77) == 5929
        assert candidate(108) == 11664
        assert candidate(23) == 529
        assert candidate(8) == 64
        assert candidate(78) == 6084
        assert candidate(10) == 100
        assert candidate(155) == 24025
        assert candidate(16) == 256
        assert candidate(7) == 49
        assert candidate(156) == 24336
        assert candidate(164) == 26896
        assert candidate(56) == 3136
        assert candidate(17) == 289
        assert candidate(106) == 11236
        assert candidate(157) == 24649
        assert candidate(14) == 196
        assert candidate(13) == 169
        assert candidate(99) == 9801
        assert candidate(88) == 7744
        assert candidate(123) == 15129
        assert candidate(45) == 2025
        assert candidate(41) == 1681
        assert candidate(103) == 10609
        assert candidate(63) == 3969
        assert candidate(37) == 1369
        assert candidate(60) == 3600
        assert candidate(139) == 19321
        assert candidate(100) == 10000
        assert candidate(39) == 1521
        assert candidate(133) == 17689
        assert candidate(191) == 36481
        assert candidate(174) == 30276
        assert candidate(66) == 4356
        assert candidate(48) == 2304
        assert candidate(72) == 5184
        assert candidate(185) == 34225
        assert candidate(111) == 12321
        assert candidate(97) == 9409
        assert candidate(81) == 6561
        assert candidate(102) == 10404
        assert candidate(178) == 31684
        assert candidate(180) == 32400
        assert candidate(42) == 1764
        assert candidate(183) == 33489
        assert candidate(5) == 25
        assert candidate(134) == 17956
        assert candidate(31) == 961
        assert candidate(146) == 21316
        assert candidate(136) == 18496
        assert candidate(166) == 27556
        assert candidate(118) == 13924
        assert candidate(70) == 4900
        assert candidate(121) == 14641
        assert candidate(149) == 22201
        assert candidate(105) == 11025
        assert candidate(90) == 8100
        assert candidate(46) == 2116
        assert candidate(114) == 12996
        assert candidate(3) == 9
        assert candidate(67) == 4489
        assert candidate(19) == 361
        assert candidate(2) == 4
        assert candidate(73) == 5329
        assert candidate(109) == 11881
        assert candidate(175) == 30625
        assert candidate(198) == 39204
        assert candidate(50) == 2500
        assert candidate(11) == 121
        assert candidate(122) == 14884
        assert candidate(117) == 13689
        assert candidate(151) == 22801
        assert candidate(184) == 33856
        assert candidate(4) == 16
        assert candidate(135) == 18225
        assert candidate(147) == 21609
        assert candidate(181) == 32761
        assert candidate(142) == 20164
        assert candidate(0) == 0
        assert candidate(130) == 16900
        assert candidate(172) == 29584
        assert candidate(98) == 9604
        assert candidate(65) == 4225
        assert candidate(94) == 8836
        assert candidate(28) == 784
        assert candidate(120) == 14400
        assert candidate(167) == 27889

if __name__ == '__main__':
    unittest.main()
