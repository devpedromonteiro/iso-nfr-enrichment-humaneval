
import unittest

from typing import List


from typing import List


def mean_absolute_deviation(numbers: List[float]) -> float:
    """Calculate the mean absolute deviation around the mean.

    Mean Absolute Deviation (MAD) is the average absolute difference between
    each value and the mean of the dataset.

    Formula:
        MAD = average(|x - mean|)

    Args:
        numbers: A non-empty list of numeric values.

    Returns:
        The mean absolute deviation as a float.

    Raises:
        ValueError: If the input list is empty.

    Examples:
        >>> mean_absolute_deviation([1.0, 2.0, 3.0, 4.0])
        1.0
        >>> mean_absolute_deviation([5.0, 5.0, 5.0])
        0.0
    """
    if not numbers:
        raise ValueError("numbers must not be empty")

    mean = sum(numbers) / len(numbers)
    absolute_deviations = [abs(number - mean) for number in numbers]
    return sum(absolute_deviations) / len(numbers)
candidate = mean_absolute_deviation


class Test(unittest.TestCase):
    def test(self):
        assert abs(candidate([1.072, 7.932, 1.603]) - 2.930888888888889) < 1e-6
        assert abs(candidate([6.905, 4.276, 7.62]) - 1.3273333333333335) < 1e-6
        assert abs(candidate([5.715, 1.823, 2.733, 2.205]) - 1.298) < 1e-6
        assert abs(candidate([3.071, 1.821, 6.663, 1.323]) - 1.7217500000000001) < 1e-6
        assert abs(candidate([2.352, 7.444, 7.771, 6.842, 8.993]) - 1.7313599999999993) < 1e-6
        assert abs(candidate([1.365, 3.175, 7.112]) - 2.152) < 1e-6
        assert abs(candidate([3.156, 6.037, 4.086, 6.855]) - 1.4125) < 1e-6
        assert abs(candidate([6.904, 1.522, 2.54, 1.428, 9.385]) - 3.03096) < 1e-6
        assert abs(candidate([6.334, 2.502, 1.314]) - 1.9671111111111108) < 1e-6
        assert abs(candidate([3.218, 6.486, 3.24]) - 1.4475555555555555) < 1e-6
        assert abs(candidate([6.47, 1.402, 2.375, 5.578, 3.395]) - 1.7439999999999998) < 1e-6
        assert abs(candidate([5.557, 2.033, 6.596, 2.564, 6.797]) - 1.9287199999999998) < 1e-6
        assert abs(candidate([1.5, 6.835, 3.272, 3.778]) - 1.4943750000000002) < 1e-6
        assert abs(candidate([6.935, 1.103, 4.883, 5.494, 2.559]) - 1.8910399999999998) < 1e-6
        assert abs(candidate([1.201, 6.398, 4.668]) - 1.9253333333333333) < 1e-6
        assert abs(candidate([6.103, 1.842, 5.241, 8.913]) - 1.98325) < 1e-6
        assert abs(candidate([2.162, 5.196, 2.849]) - 1.1957777777777776) < 1e-6
        assert abs(candidate([6.503, 6.003, 4.306, 2.398]) - 1.4505) < 1e-6
        assert abs(candidate([1.0, 2.0, 3.0, 4.0]) - 1.0) < 1e-6
        assert abs(candidate([6.921, 4.487, 2.158, 9.268, 3.207]) - 2.3090400000000004) < 1e-6
        assert abs(candidate([2.822, 3.485, 2.02, 4.886]) - 0.88225) < 1e-6
        assert abs(candidate([5.866, 6.158, 7.344]) - 0.5920000000000002) < 1e-6
        assert abs(candidate([5.611, 2.87, 4.169, 8.861, 2.969]) - 1.8720000000000003) < 1e-6
        assert abs(candidate([4.579, 5.65, 8.117]) - 1.3344444444444445) < 1e-6
        assert abs(candidate([3.501, 4.457, 1.897, 9.743, 1.554]) - 2.29568) < 1e-6
        assert abs(candidate([6.48, 6.424, 8.908, 9.679]) - 1.4207499999999997) < 1e-6
        assert abs(candidate([1.068, 4.416, 3.773]) - 1.3451111111111114) < 1e-6
        assert abs(candidate([2.475, 4.764, 6.711, 7.07]) - 1.6355) < 1e-6
        assert abs(candidate([3.017, 5.558, 4.927, 4.258, 4.896]) - 0.7149599999999998) < 1e-6
        assert abs(candidate([4.504, 5.554, 5.393, 5.307]) - 0.3427499999999999) < 1e-6
        assert abs(candidate([2.941, 3.028, 7.351, 6.737]) - 2.02975) < 1e-6
        assert abs(candidate([1.538, 4.35, 3.523, 7.16]) - 1.61225) < 1e-6
        assert abs(candidate([2.293, 4.158, 8.639]) - 2.4059999999999997) < 1e-6
        assert abs(candidate([4.419, 6.879, 5.546]) - 0.8428888888888885) < 1e-6
        assert abs(candidate([1.889, 4.382, 7.368, 4.469]) - 1.4205) < 1e-6
        assert abs(candidate([6.866, 1.964, 3.841, 3.379]) - 1.4267499999999997) < 1e-6
        assert abs(candidate([6.438, 3.306, 2.939]) - 1.4735555555555555) < 1e-6
        assert abs(candidate([4.295, 2.957, 7.726, 8.063, 6.212]) - 1.7796800000000002) < 1e-6
        assert abs(candidate([3.797, 3.293, 7.963]) - 1.9635555555555555) < 1e-6
        assert abs(candidate([1.823, 6.795, 4.377, 3.145]) - 1.5509999999999997) < 1e-6
        assert abs(candidate([6.371, 5.636, 7.318]) - 0.5842222222222221) < 1e-6
        assert abs(candidate([1.716, 1.016, 1.491, 9.966]) - 3.2093749999999996) < 1e-6
        assert abs(candidate([2.649, 7.143, 7.35, 9.295, 6.463]) - 1.6192) < 1e-6
        assert abs(candidate([3.155, 1.562, 2.414, 8.498]) - 2.295375) < 1e-6
        assert abs(candidate([6.223, 1.079, 3.91, 2.576]) - 1.6195) < 1e-6
        assert abs(candidate([3.777, 1.975, 1.126]) - 0.9895555555555556) < 1e-6
        assert abs(candidate([6.208, 3.403, 3.513]) - 1.2222222222222225) < 1e-6
        assert abs(candidate([4.215, 6.868, 4.05, 3.261, 1.001]) - 1.3984) < 1e-6
        assert abs(candidate([3.299, 5.332, 4.944]) - 0.8173333333333335) < 1e-6
        assert abs(candidate([5.436, 1.382, 8.487, 5.687, 5.147]) - 1.57064) < 1e-6
        assert abs(candidate([5.521, 5.29, 2.955]) - 1.0891111111111111) < 1e-6
        assert abs(candidate([1.186, 1.223, 1.403, 8.277, 8.143]) - 3.3308800000000005) < 1e-6
        assert abs(candidate([5.877, 5.357, 6.245]) - 0.31288888888888877) < 1e-6
        assert abs(candidate([4.482, 6.455, 1.707]) - 1.6717777777777778) < 1e-6
        assert abs(candidate([1.247, 4.364, 4.975, 2.538, 4.499]) - 1.3056800000000002) < 1e-6
        assert abs(candidate([3.595, 6.803, 5.859]) - 1.216) < 1e-6
        assert abs(candidate([6.22, 4.123, 6.62, 6.217, 10.481]) - 1.4995200000000004) < 1e-6
        assert abs(candidate([3.79, 4.519, 3.372, 7.178, 5.007]) - 1.05544) < 1e-6
        assert abs(candidate([6.612, 3.985, 3.563, 6.937]) - 1.50025) < 1e-6
        assert abs(candidate([5.426, 7.471, 7.9, 4.558, 4.081]) - 1.43864) < 1e-6
        assert abs(candidate([1.0, 2.0, 3.0]) - 2.0/3.0) < 1e-6
        assert abs(candidate([1.641, 1.957, 2.739, 5.261]) - 1.18075) < 1e-6
        assert abs(candidate([2.808, 3.733, 8.094, 6.666]) - 2.05475) < 1e-6
        assert abs(candidate([2.43, 7.782, 6.339]) - 2.0580000000000003) < 1e-6
        assert abs(candidate([4.315, 7.752, 6.635, 2.185]) - 1.9717499999999997) < 1e-6
        assert abs(candidate([4.025, 3.243, 5.996, 8.911, 2.083]) - 2.08152) < 1e-6
        assert abs(candidate([1.827, 1.173, 8.198]) - 2.976888888888889) < 1e-6
        assert abs(candidate([1.932, 3.403, 4.123]) - 0.8137777777777778) < 1e-6
        assert abs(candidate([2.611, 4.02, 3.642, 3.825]) - 0.45675) < 1e-6
        assert abs(candidate([3.012, 7.473, 3.499, 1.909, 4.031]) - 1.41376) < 1e-6
        assert abs(candidate([1.278, 4.873, 8.221, 6.073]) - 2.03575) < 1e-6
        assert abs(candidate([2.406, 5.44, 4.974, 1.02]) - 1.7469999999999999) < 1e-6
        assert abs(candidate([1.141, 7.371, 5.09, 1.221, 9.528]) - 2.95136) < 1e-6
        assert abs(candidate([6.732, 1.192, 1.701, 5.665]) - 2.3760000000000003) < 1e-6
        assert abs(candidate([6.829, 2.274, 2.632]) - 1.9448888888888887) < 1e-6
        assert abs(candidate([1.718, 4.386, 8.465, 9.25, 9.928]) - 2.95792) < 1e-6
        assert abs(candidate([1.0, 2.0, 3.0, 4.0, 5.0]) - 6.0/5.0) < 1e-6
        assert abs(candidate([2.041, 5.084, 4.81, 6.736]) - 1.3133749999999997) < 1e-6
        assert abs(candidate([3.246, 7.22, 6.875, 9.07, 6.818]) - 1.3599200000000002) < 1e-6
        assert abs(candidate([2.92, 2.002, 3.512]) - 0.5395555555555557) < 1e-6
        assert abs(candidate([1.017, 1.427, 8.362]) - 3.1733333333333333) < 1e-6
        assert abs(candidate([3.52, 3.083, 6.273, 1.685]) - 1.3163749999999999) < 1e-6
        assert abs(candidate([2.369, 4.943, 8.069, 8.133, 5.553]) - 1.8300800000000002) < 1e-6
        assert abs(candidate([5.546, 5.238, 1.512]) - 1.7244444444444447) < 1e-6
        assert abs(candidate([5.804, 6.445, 4.783, 2.401, 7.536]) - 1.4414399999999998) < 1e-6
        assert abs(candidate([2.584, 6.102, 4.252, 3.817, 2.516]) - 1.05824) < 1e-6
        assert abs(candidate([2.032, 4.824, 5.987, 1.135]) - 1.9109999999999998) < 1e-6
        assert abs(candidate([3.665, 3.226, 2.664]) - 0.34733333333333327) < 1e-6
        assert abs(candidate([5.083, 6.03, 2.298, 9.735, 6.256]) - 1.7519200000000001) < 1e-6
        assert abs(candidate([4.697, 5.287, 6.064, 1.699]) - 1.3688749999999996) < 1e-6
        assert abs(candidate([1.109, 5.965, 6.433, 1.122]) - 2.54175) < 1e-6
        assert abs(candidate([4.178, 1.224, 4.525, 8.032, 10.558]) - 2.8732800000000003) < 1e-6
        assert abs(candidate([4.584, 2.973, 6.993, 8.123, 9.672]) - 2.1524) < 1e-6
        assert abs(candidate([6.54, 2.924, 8.969, 9.453, 8.89]) - 2.09856) < 1e-6
        assert abs(candidate([4.682, 2.3, 8.052, 3.885]) - 1.6611249999999995) < 1e-6
        assert abs(candidate([1.571, 7.684, 6.591]) - 2.474) < 1e-6
        assert abs(candidate([6.334, 4.613, 2.515, 5.143, 2.894]) - 1.2762399999999998) < 1e-6
        assert abs(candidate([4.703, 4.126, 1.222]) - 1.4188888888888893) < 1e-6
        assert abs(candidate([2.06, 4.802, 6.758, 1.587]) - 1.97825) < 1e-6
        assert abs(candidate([6.889, 3.96, 3.317]) - 1.4446666666666668) < 1e-6
        assert abs(candidate([3.071, 4.731, 1.166, 6.255, 6.163]) - 1.72696) < 1e-6
        assert abs(candidate([5.802, 7.502, 3.419]) - 1.4368888888888887) < 1e-6
        assert abs(candidate([4.262, 7.982, 5.256, 1.889, 4.523]) - 1.4692800000000001) < 1e-6
        assert abs(candidate([5.742, 1.661, 2.618, 3.89, 5.531]) - 1.39912) < 1e-6
        assert abs(candidate([4.537, 1.0, 4.818, 6.514]) - 1.608625) < 1e-6

if __name__ == '__main__':
    unittest.main()
