
import unittest
import re
import sys
import math
import copy


def solve(N):
    """Return the sum of the binary digits of N, encoded as a binary string.

    The function:
    1. Converts N to its binary representation.
    2. Sums the digits in that binary representation (i.e., counts the number of 1s).
    3. Returns that sum as a binary string.

    Examples:
        solve(1000) -> "1"
        solve(150)  -> "110"
        solve(147)  -> "1100"
    """
    binary_representation = bin(N)[2:]
    digit_sum = sum(int(bit) for bit in binary_representation)
    return bin(digit_sum)[2:]
candidate = solve


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(1000) == "1", "Error"
    assert candidate(150) == "110", "Error"
    assert candidate(147) == "1100", "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate(333) == "1001", "Error"
    assert candidate(963) == "10010", "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
