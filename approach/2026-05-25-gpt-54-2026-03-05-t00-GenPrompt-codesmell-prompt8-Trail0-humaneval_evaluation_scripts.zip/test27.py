
import unittest
import re
import sys
import math
import copy



def flip_case(string: str) -> str:
    """Flip lowercase characters to uppercase and uppercase to lowercase.

    Non-alphabetic characters are left unchanged.

    >>> flip_case('Hello')
    'hELLO'
    """
    return string.swapcase()
candidate = flip_case




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == ''
    assert candidate('Hello!') == 'hELLO!'
    assert candidate('These violent delights have violent ends') == 'tHESE VIOLENT DELIGHTS HAVE VIOLENT ENDS'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
