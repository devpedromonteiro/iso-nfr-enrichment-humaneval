
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math
from typing import Sequence


def poly(coefficients: Sequence[float], x: float) -> float:
    """
    Evaluate a polynomial at point ``x``.

    The polynomial is defined by coefficients in ascending power order:
    coefficients[0] + coefficients[1] * x + coefficients[2] * x^2 + ...

    Example:
        [1, 2, 3] represents 1 + 2x + 3x^2
    """
    return sum(coeff * (x ** power) for power, coeff in enumerate(coefficients))


def find_zero(coefficients: Sequence[float], tolerance: float = 1e-10) -> float:
    """
    Find one real zero of a polynomial.

    The input polynomial must:
    - have an even number of coefficients
    - have a non-zero leading coefficient

    Under these conditions, the polynomial degree is odd, which guarantees
    at least one real root.

    The function returns one real root using interval expansion
    and bisection.

    >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2)  # (x - 1) * (x - 2) * (x - 3)
    1.0
    """
    if len(coefficients) % 2 != 0:
        raise ValueError("Polynomial must have an even number of coefficients.")

    if not coefficients:
        raise ValueError("Coefficient list must not be empty.")

    if coefficients[-1] == 0:
        raise ValueError("Leading coefficient must be non-zero.")

    def f(x: float) -> float:
        return poly(coefficients, x)

    left = -1.0
    right = 1.0
    f_left = f(left)
    f_right = f(right)

    while f_left * f_right > 0:
        left *= 2
        right *= 2
        f_left = f(left)
        f_right = f(right)

    if abs(f_left) <= tolerance:
        return left
    if abs(f_right) <= tolerance:
        return right

    while right - left > tolerance:
        middle = (left + right) / 2
        f_middle = f(middle)

        if abs(f_middle) <= tolerance:
            return middle

        if f_left * f_middle <= 0:
            right = middle
            f_right = f_middle
        else:
            left = middle
            f_left = f_middle

    return (left + right) / 2
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
