
import unittest
import re
import sys
import math
import copy


def starts_one_ends(n):
    """
    Return the count of n-digit positive integers that start or end with 1.

    An n-digit positive integer:
    - starts with 1: 10^(n-1) such numbers
    - ends with 1:   9 * 10^(n-2) such numbers (for n >= 2)
    - both start and end with 1 are counted twice, so subtract them once

    For n == 1, only the number 1 qualifies.

    Args:
        n: A positive integer representing the number of digits.

    Returns:
        The count of n-digit positive integers that start or end with 1.

    Raises:
        ValueError: If n is not a positive integer.
    """
    if not isinstance(n, int) or n <= 0:
        raise ValueError("n must be a positive integer")

    if n == 1:
        return 1

    start_with_one = 10 ** (n - 1)
    end_with_one = 9 * (10 ** (n - 2))
    start_and_end_with_one = 10 ** (n - 2)

    return start_with_one + end_with_one - start_and_end_with_one
candidate = starts_one_ends


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(1) == 1
    assert candidate(2) == 18
    assert candidate(3) == 180
    assert candidate(4) == 1800
    assert candidate(5) == 18000

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
