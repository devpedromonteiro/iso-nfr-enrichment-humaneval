
import unittest
import re
import sys
import math
import copy



from typing import Iterable, TypeVar

T = TypeVar("T")


def max_element(items: Iterable[T]) -> T:
    """Return the maximum element in a non-empty iterable.

    >>> max_element([1, 2, 3])
    3
    >>> max_element([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    123
    """
    iterator = iter(items)

    try:
        maximum = next(iterator)
    except StopIteration as exc:
        raise ValueError("max_element() arg is an empty iterable") from exc

    for item in iterator:
        if item > maximum:
            maximum = item

    return maximum
candidate = max_element




METADATA = {}


def check(candidate):
    assert candidate([1, 2, 3]) == 3
    assert candidate([5, 3, -5, 2, -3, 3, 9, 0, 124, 1, -10]) == 124


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
