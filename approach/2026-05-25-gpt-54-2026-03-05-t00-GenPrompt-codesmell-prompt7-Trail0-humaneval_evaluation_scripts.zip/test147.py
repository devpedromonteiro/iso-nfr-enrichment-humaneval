
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    Return the number of triples (a[i], a[j], a[k]) such that i < j < k
    and a[i] + a[j] + a[k] is divisible by 3, where:

        a[i] = i*i - i + 1   for 1 <= i <= n

    Observation:
    a[i] % 3 depends only on i % 3:
        i % 3 == 0 -> a[i] % 3 == 1
        i % 3 == 1 -> a[i] % 3 == 1
        i % 3 == 2 -> a[i] % 3 == 0

    So values are only in residue classes:
        0 mod 3  -> count = number of i where i % 3 == 2
        1 mod 3  -> count = remaining indices
        2 mod 3  -> count = 0

    Valid triple residue combinations:
        (0, 0, 0)
        (1, 1, 1)
        (0, 1, 2) -> impossible since residue 2 never occurs

    Therefore answer is:
        C(count_0, 3) + C(count_1, 3)
    """
    if n < 3:
        return 0

    def combinations_of_three(count):
        """Return C(count, 3) safely."""
        if count < 3:
            return 0
        return count * (count - 1) * (count - 2) // 6

    count_mod_0 = (n + 1) // 3   # indices where i % 3 == 2
    count_mod_1 = n - count_mod_0

    return combinations_of_three(count_mod_0) + combinations_of_three(count_mod_1)
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
