
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """Return the maximum nesting depth for each space-separated parentheses group.

    Each group must contain only '(' and ')' characters and be balanced.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """
    if not paren_string.strip():
        return []

    return [_max_nesting_depth(group) for group in paren_string.split()]


def _max_nesting_depth(group: str) -> int:
    """Compute the maximum nesting depth of a single parentheses group."""
    depth = 0
    max_depth = 0

    for char in group:
        if char == "(":
            depth += 1
            max_depth = max(max_depth, depth)
        elif char == ")":
            depth -= 1
            if depth < 0:
                raise ValueError(f"Unbalanced parentheses group: {group!r}")
        else:
            raise ValueError(f"Invalid character {char!r} in group: {group!r}")

    if depth != 0:
        raise ValueError(f"Unbalanced parentheses group: {group!r}")

    return max_depth
candidate = parse_nested_parens




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('(()()) ((())) () ((())()())') == [2, 3, 1, 3]
    assert candidate('() (()) ((())) (((())))') == [1, 2, 3, 4]
    assert candidate('(()(())((())))') == [4]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
