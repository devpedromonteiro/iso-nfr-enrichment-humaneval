
import unittest
import re
import sys
import math
import copy



def greatest_common_divisor(a: int, b: int) -> int:
    """Return the greatest common divisor of two integers.

    >>> greatest_common_divisor(3, 5)
    1
    >>> greatest_common_divisor(25, 15)
    5
    """
    # Normalize inputs to avoid issues with negative numbers.
    a, b = abs(a), abs(b)

    # Handle edge cases explicitly for clarity.
    if a == 0:
        return b
    if b == 0:
        return a

    # Euclidean algorithm: efficient and avoids unnecessary complexity.
    while b != 0:
        a, b = b, a % b

    return a
candidate = greatest_common_divisor




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(3, 7) == 1
    assert candidate(10, 15) == 5
    assert candidate(49, 14) == 7
    assert candidate(144, 60) == 12


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
