
import unittest
import re
import sys
import math
import copy



from typing import Sequence, Any


def monotonic(values: Sequence[Any]) -> bool:
    """Return True if elements are monotonically increasing or decreasing.

    A sequence is considered monotonic if it never changes direction:
    it is either entirely non-decreasing or entirely non-increasing.

    >>> monotonic([1, 2, 4, 20])
    True
    >>> monotonic([1, 20, 4, 10])
    False
    >>> monotonic([4, 1, 0, -10])
    True
    >>> monotonic([1, 1, 2, 2])
    True
    >>> monotonic([3, 3, 3])
    True
    >>> monotonic([])
    True
    """
    if len(values) < 2:
        return True

    is_non_decreasing = True
    is_non_increasing = True

    for previous, current in zip(values, values[1:]):
        if current < previous:
            is_non_decreasing = False
        if current > previous:
            is_non_increasing = False

        if not is_non_decreasing and not is_non_increasing:
            return False

    return True
candidate = monotonic




METADATA = {}


def check(candidate):
    assert candidate([1, 2, 4, 10]) == True
    assert candidate([1, 2, 4, 20]) == True
    assert candidate([1, 20, 4, 10]) == False
    assert candidate([4, 1, 0, -10]) == True
    assert candidate([4, 1, 1, 0]) == True
    assert candidate([1, 2, 3, 2, 5, 60]) == False
    assert candidate([1, 2, 3, 4, 5, 60]) == True
    assert candidate([9, 9, 9, 9]) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
