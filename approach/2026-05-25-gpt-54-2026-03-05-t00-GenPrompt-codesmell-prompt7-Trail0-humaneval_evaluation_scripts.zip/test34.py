
import unittest
import re
import sys
import math
import copy



from typing import Iterable, TypeVar, List

T = TypeVar("T")


def unique(items: Iterable[T]) -> List[T]:
    """Return sorted unique elements from an iterable.

    >>> unique([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [0, 2, 3, 5, 9, 123]
    """
    return sorted(set(items))
candidate = unique




METADATA = {}


def check(candidate):
    assert candidate([5, 3, 5, 2, 3, 3, 9, 0, 123]) == [0, 2, 3, 5, 9, 123]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
