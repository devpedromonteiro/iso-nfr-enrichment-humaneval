
import unittest
import re
import sys
import math
import copy


FIX = """
Add more test cases.
"""

FIX = """
Add more test cases.
"""

def vowels_count(s):
    """Return the number of vowels in a word.

    Vowels are: 'a', 'e', 'i', 'o', 'u'.
    The letter 'y' counts as a vowel only when it appears at the end
    of the word.

    Examples:
    >>> vowels_count("abcde")
    2
    >>> vowels_count("ACEDY")
    3
    >>> vowels_count("")
    0
    >>> vowels_count("sky")
    1
    >>> vowels_count("yellow")
    2
    >>> vowels_count("AEIOU")
    5
    """
    if not s:
        return 0

    word = s.lower()
    vowels = {"a", "e", "i", "o", "u"}

    count = sum(1 for char in word if char in vowels)

    if word.endswith("y"):
        count += 1

    return count
candidate = vowels_count


def check(candidate):

    # Check some simple cases
    assert candidate("abcde") == 2, "Test 1"
    assert candidate("Alone") == 3, "Test 2"
    assert candidate("key") == 2, "Test 3"
    assert candidate("bye") == 1, "Test 4"
    assert candidate("keY") == 2, "Test 5"
    assert candidate("bYe") == 1, "Test 6"
    assert candidate("ACEDY") == 3, "Test 7"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
