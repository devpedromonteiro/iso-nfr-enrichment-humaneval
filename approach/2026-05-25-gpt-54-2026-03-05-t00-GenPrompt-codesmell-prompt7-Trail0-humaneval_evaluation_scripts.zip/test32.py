
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math
from typing import List


def poly(coefficients: List[float], x: float) -> float:
    """
    Evaluate a polynomial with given coefficients at point x.

    The polynomial is:
        coefficients[0] + coefficients[1] * x + coefficients[2] * x^2 + ... + coefficients[n] * x^n
    """
    return sum(coeff * math.pow(x, power) for power, coeff in enumerate(coefficients))


def find_zero(coefficients: List[float], tolerance: float = 1e-10, max_iterations: int = 10_000) -> float:
    """
    Find one real zero of a polynomial defined by coefficients.

    Assumptions:
    - coefficients has even length
    - the highest non-zero coefficient guarantees existence of at least one real root

    Uses binary search after finding an interval where the polynomial changes sign.

    >>> round(find_zero([1, 2]), 2)
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2)
    1.0
    """
    if not coefficients:
        raise ValueError("coefficients must not be empty")

    if len(coefficients) % 2 != 0:
        raise ValueError("coefficients must contain an even number of elements")

    def f(value: float) -> float:
        return poly(coefficients, value)

    left = -1.0
    right = 1.0
    f_left = f(left)
    f_right = f(right)

    while f_left * f_right > 0:
        left *= 2
        right *= 2
        f_left = f(left)
        f_right = f(right)

    for _ in range(max_iterations):
        middle = (left + right) / 2
        f_middle = f(middle)

        if abs(f_middle) < tolerance:
            return middle

        if f_left * f_middle <= 0:
            right = middle
            f_right = f_middle
        else:
            left = middle
            f_left = f_middle

    return (left + right) / 2
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
