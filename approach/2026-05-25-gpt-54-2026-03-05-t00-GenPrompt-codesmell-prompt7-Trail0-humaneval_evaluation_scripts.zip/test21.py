
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def rescale_to_unit(numbers: List[float]) -> List[float]:
    """Given a list of numbers, linearly rescale them to the [0, 1] range.

    The smallest value becomes 0.0 and the largest becomes 1.0.

    Args:
        numbers: A list of at least two float values.

    Returns:
        A new list with all values rescaled to the [0, 1] interval.

    Raises:
        ValueError: If fewer than two numbers are provided.
        ValueError: If all numbers are equal, so rescaling is undefined.

    >>> rescale_to_unit([1.0, 2.0, 3.0, 4.0, 5.0])
    [0.0, 0.25, 0.5, 0.75, 1.0]
    """
    if len(numbers) < 2:
        raise ValueError("numbers must contain at least two elements")

    minimum = min(numbers)
    maximum = max(numbers)
    value_range = maximum - minimum

    if value_range == 0:
        raise ValueError("cannot rescale when all numbers are equal")

    return [(number - minimum) / value_range for number in numbers]
candidate = rescale_to_unit




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([2.0, 49.9]) == [0.0, 1.0]
    assert candidate([100.0, 49.9]) == [1.0, 0.0]
    assert candidate([1.0, 2.0, 3.0, 4.0, 5.0]) == [0.0, 0.25, 0.5, 0.75, 1.0]
    assert candidate([2.0, 1.0, 5.0, 3.0, 4.0]) == [0.25, 0.0, 1.0, 0.5, 0.75]
    assert candidate([12.0, 11.0, 15.0, 13.0, 14.0]) == [0.25, 0.0, 1.0, 0.5, 0.75]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
