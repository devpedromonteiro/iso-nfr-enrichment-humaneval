
import unittest
import re
import sys
import math
import copy


def is_multiply_prime(a):
    """Return True if a is the product of exactly 3 primes, else False.

    Examples:
        is_multiply_prime(30) -> True   # 2 * 3 * 5
        is_multiply_prime(8)  -> True   # 2 * 2 * 2
        is_multiply_prime(12) -> True   # 2 * 2 * 3
        is_multiply_prime(7)  -> False
    """

    def is_prime(n):
        if n < 2:
            return False
        for i in range(2, int(n ** 0.5) + 1):
            if n % i == 0:
                return False
        return True

    prime_factors_count = 0
    divisor = 2

    while a > 1 and divisor * divisor <= a:
        while a % divisor == 0:
            if not is_prime(divisor):
                return False
            prime_factors_count += 1
            a //= divisor
            if prime_factors_count > 3:
                return False
        divisor += 1

    if a > 1:
        if not is_prime(a):
            return False
        prime_factors_count += 1

    return prime_factors_count == 3
candidate = is_multiply_prime


def check(candidate):

    assert candidate(5) == False
    assert candidate(30) == True
    assert candidate(8) == True
    assert candidate(10) == False
    assert candidate(125) == True
    assert candidate(3 * 5 * 7) == True
    assert candidate(3 * 6 * 7) == False
    assert candidate(9 * 9 * 9) == False
    assert candidate(11 * 9 * 9) == False
    assert candidate(11 * 13 * 7) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
