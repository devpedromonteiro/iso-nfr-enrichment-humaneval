
import unittest
import re
import sys
import math
import copy



def triangle_area(base: float, height: float) -> float:
    """Return the area of a triangle.

    The area is calculated as:
        (base * height) / 2

    Args:
        base: Length of the triangle's base.
        height: Height of the triangle.

    Returns:
        The triangle's area as a float.

    Raises:
        TypeError: If base or height is not a number.
        ValueError: If base or height is negative.

    >>> triangle_area(5, 3)
    7.5
    """
    if not isinstance(base, (int, float)) or not isinstance(height, (int, float)):
        raise TypeError("base and height must be numbers")

    if base < 0 or height < 0:
        raise ValueError("base and height must be non-negative")

    return (base * height) / 2
candidate = triangle_area




METADATA = {}


def check(candidate):
    assert candidate(5, 3) == 7.5
    assert candidate(2, 2) == 2.0
    assert candidate(10, 8) == 40.0



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
