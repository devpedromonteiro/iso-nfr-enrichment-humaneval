
import unittest
import re
import sys
import math
import copy


def exchange(lst1, lst2):
    """Determine whether lst1 can be made all-even by exchanging elements with lst2.

    Any number of exchanges is allowed. Since exchanged elements can be chosen
    freely, lst1 can be made all-even if and only if there are at least
    len(lst1) even numbers in total across both lists.

    Args:
        lst1: A non-empty list of numbers.
        lst2: A non-empty list of numbers.

    Returns:
        "YES" if lst1 can be made to contain only even numbers, otherwise "NO".
    """
    required_evens = len(lst1)
    available_evens = sum(1 for value in lst1 if value % 2 == 0)
    available_evens += sum(1 for value in lst2 if value % 2 == 0)

    return "YES" if available_evens >= required_evens else "NO"
candidate = exchange


def check(candidate):

    # Check some simple cases
    assert candidate([1, 2, 3, 4], [1, 2, 3, 4]) == "YES"
    assert candidate([1, 2, 3, 4], [1, 5, 3, 4]) == "NO"
    assert candidate([1, 2, 3, 4], [2, 1, 4, 3]) == "YES" 
    assert candidate([5, 7, 3], [2, 6, 4]) == "YES"
    assert candidate([5, 7, 3], [2, 6, 3]) == "NO" 
    assert candidate([3, 2, 6, 1, 8, 9], [3, 5, 5, 1, 1, 1]) == "NO"

    # Check some edge cases that are easy to work out by hand.
    assert candidate([100, 200], [200, 200]) == "YES"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
