
import unittest
import re
import sys
import math
import copy


def numerical_letter_grade(grades):
    """Convert a list of GPA values to letter grades.

    Mapping:
         4.0 -> A+
        >3.7 -> A
        >3.3 -> A-
        >3.0 -> B+
        >2.7 -> B
        >2.3 -> B-
        >2.0 -> C+
        >1.7 -> C
        >1.3 -> C-
        >1.0 -> D+
        >0.7 -> D
        >0.0 -> D-
         0.0 -> E
    """
    grade_scale = [
        (4.0, "A+"),
        (3.7, "A"),
        (3.3, "A-"),
        (3.0, "B+"),
        (2.7, "B"),
        (2.3, "B-"),
        (2.0, "C+"),
        (1.7, "C"),
        (1.3, "C-"),
        (1.0, "D+"),
        (0.7, "D"),
        (0.0, "D-"),
    ]

    def to_letter(gpa):
        if gpa == 4.0:
            return "A+"
        if gpa == 0.0:
            return "E"

        for threshold, letter in grade_scale[1:]:
            if gpa > threshold:
                return letter

        return "E"

    return [to_letter(gpa) for gpa in grades]
candidate = numerical_letter_grade


def check(candidate):

    # Check some simple cases
    assert candidate([4.0, 3, 1.7, 2, 3.5]) == ['A+', 'B', 'C-', 'C', 'A-']
    assert candidate([1.2]) == ['D+']
    assert candidate([0.5]) == ['D-']
    assert candidate([0.0]) == ['E']
    assert candidate([1, 0.3, 1.5, 2.8, 3.3]) == ['D', 'D-', 'C-', 'B', 'B+']
    assert candidate([0, 0.7]) == ['E', 'D-']

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
