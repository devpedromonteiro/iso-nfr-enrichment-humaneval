
import unittest
import re
import sys
import math
import copy



def is_palindrome(string: str) -> bool:
    """ Test if given string is a palindrome """
    return string == string[::-1]


def is_palindrome(string: str) -> bool:
    """Test whether the given string is a palindrome."""
    return string == string[::-1]


def make_palindrome(string: str) -> str:
    """Return the shortest palindrome that starts with the supplied string.

    The function finds the longest suffix of ``string`` that is already
    a palindrome, then appends the reverse of the remaining prefix.

    Examples:
        >>> make_palindrome('')
        ''
        >>> make_palindrome('cat')
        'catac'
        >>> make_palindrome('cata')
        'catac'
    """
    if not string:
        return ""

    for start_index in range(len(string)):
        suffix = string[start_index:]
        if is_palindrome(suffix):
            prefix = string[:start_index]
            return string + prefix[::-1]

    return string
candidate = make_palindrome




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == ''
    assert candidate('x') == 'x'
    assert candidate('xyz') == 'xyzyx'
    assert candidate('xyx') == 'xyx'
    assert candidate('jerry') == 'jerryrrej'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
