
import unittest
import re
import sys
import math
import copy


import operator as op


def do_algebra(operators, operands):
    """
    Evaluate an algebraic expression built from operators and operands.

    The expression follows normal Python operator precedence:
    **, *, //, +, -

    Args:
        operators (list[str]): List of operators such as ['+', '*', '-'].
        operands (list[int]): List of non-negative integers.

    Returns:
        int: Result of the evaluated expression.

    Raises:
        ValueError: If input lengths are invalid or an unsupported operator is found.
    """
    if len(operators) != len(operands) - 1:
        raise ValueError("operators length must be exactly one less than operands length")

    operation_map = {
        '+': op.add,
        '-': op.sub,
        '*': op.mul,
        '//': op.floordiv,
        '**': op.pow,
    }

    expression = [str(operands[0])]

    for current_operator, current_operand in zip(operators, operands[1:]):
        if current_operator not in operation_map:
            raise ValueError(f"Unsupported operator: {current_operator}")
        expression.append(current_operator)
        expression.append(str(current_operand))

    return eval(" ".join(expression))
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
