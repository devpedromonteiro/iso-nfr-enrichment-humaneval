
import unittest
import re
import sys
import math
import copy



def fizz_buzz(n: int) -> int:
    """Return the number of times the digit 7 appears in integers less than n
    which are divisible by 11 or 13.

    >>> fizz_buzz(50)
    0
    >>> fizz_buzz(78)
    2
    >>> fizz_buzz(79)
    3
    """
    if n <= 0:
        return 0

    def is_valid(number: int) -> bool:
        return number % 11 == 0 or number % 13 == 0

    def count_sevens(number: int) -> int:
        return str(number).count("7")

    total = 0
    for value in range(n):
        if is_valid(value):
            total += count_sevens(value)

    return total
candidate = fizz_buzz




METADATA = {}


def check(candidate):
    assert candidate(50) == 0
    assert candidate(78) == 2
    assert candidate(79) == 3
    assert candidate(100) == 3
    assert candidate(200) == 6
    assert candidate(4000) == 192
    assert candidate(10000) == 639
    assert candidate(100000) == 8026



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
