
import unittest
import re
import sys
import math
import copy



from typing import List, TypeVar

T = TypeVar("T")


def sort_even(items: List[T]) -> List[T]:
    """Return a new list where values at even indices are sorted.

    The values at odd indices remain in their original positions.

    Examples:
        >>> sort_even([1, 2, 3])
        [1, 2, 3]
        >>> sort_even([5, 6, 3, 4])
        [3, 6, 5, 4]
        >>> sort_even([8, 7, 6, 5, 4])
        [4, 7, 6, 5, 8]
    """
    if not items:
        return []

    result = items.copy()
    even_values = sorted(result[::2])
    result[::2] = even_values
    return result
candidate = sort_even




METADATA = {}


def check(candidate):
    assert tuple(candidate([1, 2, 3])) == tuple([1, 2, 3])
    assert tuple(candidate([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])) == tuple([-10, 3, -5, 2, -3, 3, 5, 0, 9, 1, 123])
    assert tuple(candidate([5, 8, -12, 4, 23, 2, 3, 11, 12, -10])) == tuple([-12, 8, 3, 4, 5, 2, 12, 11, 23, -10])



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
