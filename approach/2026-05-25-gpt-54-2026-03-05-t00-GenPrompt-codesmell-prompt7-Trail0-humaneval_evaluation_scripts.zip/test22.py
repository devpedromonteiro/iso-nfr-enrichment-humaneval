
import unittest
import re
import sys
import math
import copy

from typing import List, Any


from typing import Any, Iterable, List


def filter_integers(values: Iterable[Any]) -> List[int]:
    """Return only integer values from the given iterable.

    Notes:
        - `bool` values are excluded, even though `bool` is a subclass of `int`.
        - The function is pure and does not mutate the input.

    >>> filter_integers(['a', 3.14, 5])
    [5]
    >>> filter_integers([1, 2, 3, 'abc', {}, []])
    [1, 2, 3]
    >>> filter_integers([True, False, 1, 0, 7])
    [1, 0, 7]
    """
    return [value for value in values if isinstance(value, int) and not isinstance(value, bool)]
candidate = filter_integers




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == []
    assert candidate([4, {}, [], 23.2, 9, 'adasd']) == [4, 9]
    assert candidate([3, 'c', 3, 3, 'a', 'b']) == [3, 3, 3]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
