
import unittest

from typing import List, Tuple


from typing import List, Tuple


def _sum_numbers(numbers: List[int]) -> int:
    return sum(numbers)


def _product_numbers(numbers: List[int]) -> int:
    product = 1
    for number in numbers:
        product *= number
    return product


def sum_product(numbers: List[int]) -> Tuple[int, int]:
    """For a given list of integers, return a tuple consisting of the sum
    and the product of all the integers in the list.

    Empty sum should be equal to 0 and empty product should be equal to 1.

    >>> sum_product([])
    (0, 1)
    >>> sum_product([1, 2, 3, 4])
    (10, 24)
    """
    total = _sum_numbers(numbers)
    product = _product_numbers(numbers)
    return total, product
candidate = sum_product


class Test(unittest.TestCase):
    def test(self):
        assert candidate([7, 1, 12]) == (20, 84)
        assert candidate([99, 2]) == (101, 198)
        assert candidate([6, 5, 1]) == (12, 30)
        assert candidate([5, 1, 6]) == (12, 30)
        assert candidate([9]) == (9, 9)
        assert candidate([97, 2]) == (99, 194)
        assert candidate([104, 5]) == (109, 520)
        assert candidate([101, 3]) == (104, 303)
        assert candidate([3, 6, 7]) == (16, 126)
        assert candidate([1, 3, 3]) == (7, 9)
        assert candidate([5, 3, 6]) == (14, 90)
        assert candidate([2, 6, 10]) == (18, 120)
        assert candidate([8]) == (8, 8)
        assert candidate([7, 6, 3]) == (16, 126)
        assert candidate([98, 5]) == (103, 490)
        assert candidate([6, 3, 6]) == (15, 108)
        assert candidate([5, 5, 5]) == (15, 125)
        assert candidate([1, 4, 2]) == (7, 8)
        assert candidate([3, 5, 6]) == (14, 90)
        assert candidate([8, 4, 8]) == (20, 256)
        assert candidate([2, 6, 3]) == (11, 36)
        assert candidate([7, 6, 8]) == (21, 336)
        assert candidate([98, 1]) == (99, 98)
        assert candidate([8, 5, 2]) == (15, 80)
        assert candidate([5, 5, 1]) == (11, 25)
        assert candidate([7, 4, 10]) == (21, 280)
        assert candidate([5, 1, 2]) == (8, 10)
        assert candidate([1, 3, 5]) == (9, 15)
        assert candidate([99, 1]) == (100, 99)
        assert candidate([7, 9, 8]) == (24, 504)
        assert candidate([100, 1]) == (101, 100)
        assert candidate([3, 1, 10]) == (14, 30)
        assert candidate([5, 2, 1]) == (8, 10)
        assert candidate([96, 4]) == (100, 384)
        assert candidate([98, 4]) == (102, 392)
        assert candidate([105, 5]) == (110, 525)
        assert candidate([101, 1]) == (102, 101)
        assert candidate([105, 4]) == (109, 420)
        assert candidate([2, 1, 6]) == (9, 12)
        assert candidate([4, 1, 6]) == (11, 24)
        assert candidate([2, 2, 5]) == (9, 20)
        assert candidate([1, 5, 12]) == (18, 60)
        assert candidate([103, 1]) == (104, 103)
        assert candidate([1, 1, 1]) == (3, 1)
        assert candidate([102, 3]) == (105, 306)
        assert candidate([98, 3]) == (101, 294)
        assert candidate([3, 3, 5]) == (11, 45)
        assert candidate([8, 9, 9]) == (26, 648)
        assert candidate([6]) == (6, 6)
        assert candidate([5, 2, 8]) == (15, 80)
        assert candidate([4, 6, 3]) == (13, 72)
        assert candidate([5]) == (5, 5)
        assert candidate([102, 1]) == (103, 102)
        assert candidate([8, 7, 11]) == (26, 616)
        assert candidate([100, 0]) == (100, 0)
        assert candidate([3, 1, 3]) == (7, 9)
        assert candidate([13]) == (13, 13)
        assert candidate([5, 4, 1]) == (10, 20)
        assert candidate([3, 6, 3]) == (12, 54)
        assert candidate([2, 2, 6]) == (10, 24)
        assert candidate([5, 8, 12]) == (25, 480)
        assert candidate([6, 2, 5]) == (13, 60)
        assert candidate([2, 5, 3]) == (10, 30)
        assert candidate([6, 5, 4]) == (15, 120)
        assert candidate([8, 8, 4]) == (20, 256)
        assert candidate([]) == (0, 1)
        assert candidate([14]) == (14, 14)
        assert candidate([8, 7, 7]) == (22, 392)
        assert candidate([1, 2, 12]) == (15, 24)
        assert candidate([4, 2, 9]) == (15, 72)
        assert candidate([3, 2, 2]) == (7, 12)
        assert candidate([102, 4]) == (106, 408)
        assert candidate([103, 2]) == (105, 206)
        assert candidate([104, 1]) == (105, 104)
        assert candidate([5, 8, 9]) == (22, 360)
        assert candidate([2, 5, 5]) == (12, 50)
        assert candidate([12]) == (12, 12)
        assert candidate([2, 1, 2]) == (5, 4)
        assert candidate([11]) == (11, 11)
        assert candidate([2, 9, 4]) == (15, 72)
        assert candidate([6, 2, 2]) == (10, 24)
        assert candidate([2, 9, 3]) == (14, 54)
        assert candidate([4, 2, 6]) == (12, 48)
        assert candidate([95, 4]) == (99, 380)
        assert candidate([6, 4, 4]) == (14, 96)
        assert candidate([102, 2]) == (104, 204)
        assert candidate([2, 7, 3]) == (12, 42)
        assert candidate([10]) == (10, 10)
        assert candidate([95, 3]) == (98, 285)
        assert candidate([7, 7, 2]) == (16, 98)
        assert candidate([7]) == (7, 7)
        assert candidate([15]) == (15, 15)
        assert candidate([3, 5, 7]) == (3 + 5 + 7, 3 * 5 * 7)
        assert candidate([1, 8, 12]) == (21, 96)

if __name__ == '__main__':
    unittest.main()
