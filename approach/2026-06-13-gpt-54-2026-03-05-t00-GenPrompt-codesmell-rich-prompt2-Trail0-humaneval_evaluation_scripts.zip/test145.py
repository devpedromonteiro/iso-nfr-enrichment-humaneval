
import unittest
import re
import sys
import math
import copy


def digit_sum(value):
    """Return the sum of the digits of an integer, ignoring its sign."""
    return sum(int(char) for char in str(abs(value)))


def sort_key(item):
    """Build the sorting key using digit sum and original index."""
    index, value = item
    return digit_sum(value), index


def order_by_points(nums):
    """
    Sort integers in ascending order by the sum of their digits.
    If multiple numbers have the same digit sum, preserve their
    original order from the input list.

    For example:
    >>> order_by_points([1, 11, -1, -11, -12]) == [-1, -11, 1, -12, 11]
    >>> order_by_points([]) == []
    """
    indexed_nums = enumerate(nums)
    sorted_items = sorted(indexed_nums, key=sort_key)
    return [value for _, value in sorted_items]
candidate = order_by_points


def check(candidate):

    # Check some simple cases
    assert candidate([1, 11, -1, -11, -12]) == [-1, -11, 1, -12, 11]
    assert candidate([1234,423,463,145,2,423,423,53,6,37,3457,3,56,0,46]) == [0, 2, 3, 6, 53, 423, 423, 423, 1234, 145, 37, 46, 56, 463, 3457]
    assert candidate([]) == []
    assert candidate([1, -11, -32, 43, 54, -98, 2, -3]) == [-3, -32, -98, -11, 1, 2, 43, 54]
    assert candidate([1,2,3,4,5,6,7,8,9,10,11]) == [1, 10, 2, 11, 3, 4, 5, 6, 7, 8, 9]
    assert candidate([0,6,6,-76,-21,23,4]) == [-76, -21, 0, 4, 23, 6, 6]

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
