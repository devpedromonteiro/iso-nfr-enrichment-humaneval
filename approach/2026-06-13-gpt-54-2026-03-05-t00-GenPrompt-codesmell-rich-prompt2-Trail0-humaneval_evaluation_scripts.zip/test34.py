
import unittest
import re
import sys
import math
import copy



def _sorted_unique_values(values: list):
    """Build a sorted list of unique values from the input sequence."""
    return sorted(set(values))


def unique(l: list):
    """Return sorted unique elements in a list.

    >>> unique([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [0, 2, 3, 5, 9, 123]
    """
    return _sorted_unique_values(l)
candidate = unique




METADATA = {}


def check(candidate):
    assert candidate([5, 3, 5, 2, 3, 3, 9, 0, 123]) == [0, 2, 3, 5, 9, 123]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
