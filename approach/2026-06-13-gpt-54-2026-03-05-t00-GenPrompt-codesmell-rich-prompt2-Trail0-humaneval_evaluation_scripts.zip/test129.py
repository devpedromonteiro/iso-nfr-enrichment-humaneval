
import unittest
import re
import sys
import math
import copy


from functools import lru_cache


def minPath(grid, k):
    """
    Return the lexicographically smallest path of length k in the grid.
    """
    size = len(grid)
    positions = _build_value_positions(grid)
    neighbors = _build_neighbors(size)

    @lru_cache(maxsize=None)
    def best_suffix(row, col, steps_remaining):
        if steps_remaining == 1:
            return (grid[row][col],)

        best_next = None
        for next_row, next_col in neighbors[(row, col)]:
            candidate = best_suffix(next_row, next_col, steps_remaining - 1)
            if best_next is None or candidate < best_next:
                best_next = candidate

        return (grid[row][col],) + best_next

    best_path = None
    for value in range(1, size * size + 1):
        row, col = positions[value]
        candidate = best_suffix(row, col, k)
        if best_path is None or candidate < best_path:
            best_path = candidate

    return list(best_path)


def _build_value_positions(grid):
    positions = {}
    for row_index, row in enumerate(grid):
        for col_index, value in enumerate(row):
            positions[value] = (row_index, col_index)
    return positions


def _build_neighbors(size):
    neighbors = {}
    directions = ((1, 0), (-1, 0), (0, 1), (0, -1))

    for row in range(size):
        for col in range(size):
            cell_neighbors = []
            for d_row, d_col in directions:
                next_row = row + d_row
                next_col = col + d_col
                if _is_inside(next_row, next_col, size):
                    cell_neighbors.append((next_row, next_col))
            neighbors[(row, col)] = cell_neighbors

    return neighbors


def _is_inside(row, col, size):
    return 0 <= row < size and 0 <= col < size
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
