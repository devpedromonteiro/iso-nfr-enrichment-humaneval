
import unittest
import re
import sys
import math
import copy


def get_closest_vowel(word):
    """Return the rightmost vowel that is between two consonants.

    A vowel qualifies only if:
    - it is not at the beginning or end of the word
    - the characters immediately before and after it are consonants

    If no such vowel exists, return an empty string.
    """
    for index in range(len(word) - 2, 0, -1):
        if _is_qualified_vowel(word, index):
            return word[index]
    return ""


def _is_qualified_vowel(word, index):
    """Check whether the character at index is a vowel between two consonants."""
    return (
        _is_vowel(word[index])
        and _is_consonant(word[index - 1])
        and _is_consonant(word[index + 1])
    )


def _is_vowel(char):
    """Return True if char is an English vowel."""
    return char in "aeiouAEIOU"


def _is_consonant(char):
    """Return True if char is an English consonant."""
    return char.isalpha() and not _is_vowel(char)
candidate = get_closest_vowel


def check(candidate):

    # Check some simple cases
    assert candidate("yogurt") == "u"
    assert candidate("full") == "u"
    assert candidate("easy") == ""
    assert candidate("eAsy") == ""
    assert candidate("ali") == ""
    assert candidate("bad") == "a"
    assert candidate("most") == "o"
    assert candidate("ab") == ""
    assert candidate("ba") == ""
    assert candidate("quick") == ""
    assert candidate("anime") == "i"
    assert candidate("Asia") == ""
    assert candidate("Above") == "o"

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
