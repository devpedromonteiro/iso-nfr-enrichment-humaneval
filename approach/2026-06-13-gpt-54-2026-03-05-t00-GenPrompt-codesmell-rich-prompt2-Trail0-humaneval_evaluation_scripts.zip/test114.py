
import unittest
import re
import sys
import math
import copy


def minSubArraySum(nums):
    """
    Given an array of integers nums, find the minimum sum of any non-empty sub-array
    of nums.

    Example:
        minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
        minSubArraySum([-1, -2, -3]) == -6
    """
    _validate_input(nums)
    return _min_subarray_sum(nums)


def _validate_input(nums):
    """Validate that nums is a non-empty sequence."""
    if not nums:
        raise ValueError("nums must be a non-empty list of integers")


def _min_subarray_sum(nums):
    """
    Compute the minimum sub-array sum using Kadane's algorithm variant.
    """
    current_min = global_min = nums[0]

    for value in nums[1:]:
        current_min = min(value, current_min + value)
        global_min = min(global_min, current_min)

    return global_min
candidate = minSubArraySum


def check(candidate):

    # Check some simple cases
    assert candidate([2, 3, 4, 1, 2, 4]) == 1, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([-1, -2, -3]) == -6
    assert candidate([-1, -2, -3, 2, -10]) == -14
    assert candidate([-9999999999999999]) == -9999999999999999
    assert candidate([0, 10, 20, 1000000]) == 0
    assert candidate([-1, -2, -3, 10, -5]) == -6
    assert candidate([100, -1, -2, -3, 10, -5]) == -6
    assert candidate([10, 11, 13, 8, 3, 4]) == 3
    assert candidate([100, -33, 32, -1, 0, -2]) == -33

    # Check some edge cases that are easy to work out by hand.
    assert candidate([-10]) == -10, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([7]) == 7
    assert candidate([1, -1]) == -1


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
