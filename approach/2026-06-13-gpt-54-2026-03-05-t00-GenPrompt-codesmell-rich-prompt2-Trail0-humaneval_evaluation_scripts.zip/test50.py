
import unittest
import re
import sys
import math
import copy



def encode_shift(s: str):
    """
    returns encoded string by shifting every character by 5 in the alphabet.
    """
    return "".join([chr(((ord(ch) + 5 - ord("a")) % 26) + ord("a")) for ch in s])


_SHIFT = 5
_ALPHABET_START = ord("a")
_ALPHABET_SIZE = 26


def _shift_char(ch: str, offset: int) -> str:
    """Shift a lowercase alphabetic character by the given offset."""
    return chr(((ord(ch) - _ALPHABET_START + offset) % _ALPHABET_SIZE) + _ALPHABET_START)


def _transform_text(text: str, offset: int) -> str:
    """Apply a character shift transformation to the entire string."""
    return "".join(_shift_char(ch, offset) for ch in text)


def encode_shift(s: str) -> str:
    """
    Return an encoded string by shifting every character by 5 in the alphabet.
    """
    return _transform_text(s, _SHIFT)


def decode_shift(s: str) -> str:
    """
    Take as input a string encoded with encode_shift and return the decoded string.
    """
    return _transform_text(s, -_SHIFT)
candidate = decode_shift




METADATA = {}


def check(candidate):
    from random import randint, choice
    import copy
    import string

    letters = string.ascii_lowercase
    for _ in range(100):
        str = ''.join(choice(letters) for i in range(randint(10, 20)))
        encoded_str = encode_shift(str)
        assert candidate(copy.deepcopy(encoded_str)) == str



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
