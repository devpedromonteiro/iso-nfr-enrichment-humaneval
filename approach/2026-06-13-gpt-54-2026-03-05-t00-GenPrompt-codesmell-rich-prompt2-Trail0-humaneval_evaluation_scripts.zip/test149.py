
import unittest
import re
import sys
import math
import copy


def _is_even_length(text):
    return len(text) % 2 == 0


def _sort_key(text):
    return (len(text), text)


def _filter_even_length_strings(strings):
    return [text for text in strings if _is_even_length(text)]


def sorted_list_sum(lst):
    """Accept a list of strings, remove strings with odd lengths,
    and return the remaining strings sorted by length, then alphabetically.

    Examples:
        sorted_list_sum(["aa", "a", "aaa"]) == ["aa"]
        sorted_list_sum(["ab", "a", "aaa", "cd"]) == ["ab", "cd"]
    """
    even_length_strings = _filter_even_length_strings(lst)
    return sorted(even_length_strings, key=_sort_key)
candidate = sorted_list_sum


def check(candidate):

    # Check some simple cases
    assert candidate(["aa", "a", "aaa"]) == ["aa"]
    assert candidate(["school", "AI", "asdf", "b"]) == ["AI", "asdf", "school"]
    assert candidate(["d", "b", "c", "a"]) == []
    assert candidate(["d", "dcba", "abcd", "a"]) == ["abcd", "dcba"]

    # Check some edge cases that are easy to work out by hand.
    assert candidate(["AI", "ai", "au"]) == ["AI", "ai", "au"]
    assert candidate(["a", "b", "b", "c", "c", "a"]) == []
    assert candidate(['aaaa', 'bbbb', 'dd', 'cc']) == ["cc", "dd", "aaaa", "bbbb"]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
