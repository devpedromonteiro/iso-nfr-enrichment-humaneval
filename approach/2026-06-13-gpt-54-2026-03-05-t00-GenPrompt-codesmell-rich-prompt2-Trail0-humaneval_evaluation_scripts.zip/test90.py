
import unittest
import re
import sys
import math
import copy


def _unique_sorted_values(values):
    """Return the sorted unique values from the input iterable."""
    return sorted(set(values))


def _has_second_smallest(values):
    """Return True when at least two distinct values exist."""
    return len(values) >= 2


def next_smallest(lst):
    """
    Return the second smallest distinct element in the list.

    Returns None if there is no second smallest distinct value.
    """
    unique_values = _unique_sorted_values(lst)

    if not _has_second_smallest(unique_values):
        return None

    return unique_values[1]
candidate = next_smallest


def check(candidate):

    # Check some simple cases
    assert candidate([1, 2, 3, 4, 5]) == 2
    assert candidate([5, 1, 4, 3, 2]) == 2
    assert candidate([]) == None
    assert candidate([1, 1]) == None
    assert candidate([1,1,1,1,0]) == 1
    assert candidate([1, 0**0]) == None
    assert candidate([-35, 34, 12, -45]) == -35

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
