
import unittest
import re
import sys
import math
import copy


def _digit_parity_counts(digits):
    """Return counts of even and odd digits from an iterable of digit characters."""
    even_count = 0
    odd_count = 0

    for digit_char in digits:
        if int(digit_char) % 2 == 0:
            even_count += 1
        else:
            odd_count += 1

    return even_count, odd_count


def even_odd_count(num):
    """Given an integer, return a tuple with the number of even and odd digits respectively.

    Example:
        even_odd_count(-12) ==> (1, 1)
        even_odd_count(123) ==> (1, 2)
    """
    digit_chars = str(abs(num))
    return _digit_parity_counts(digit_chars)
candidate = even_odd_count


def check(candidate):

    # Check some simple cases
    assert candidate(7) == (0, 1)
    assert candidate(-78) == (1, 1)
    assert candidate(3452) == (2, 2)
    assert candidate(346211) == (3, 3)
    assert candidate(-345821) == (3, 3)
    assert candidate(-2) == (1, 0)
    assert candidate(-45347) == (2, 3)
    assert candidate(0) == (1, 0)


    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
