
import unittest
import re
import sys
import math
import copy


from math import comb


def _count_residues_mod_3(n):
    """
    Count how many values of a[i] = i*i - i + 1, for 1 <= i <= n,
    fall into each residue class modulo 3.

    Returns:
        tuple: (count_mod_0, count_mod_1, count_mod_2)
    """
    counts = [0, 0, 0]

    for i in range(1, n + 1):
        residue = (i * i - i + 1) % 3
        counts[residue] += 1

    return counts[0], counts[1], counts[2]


def _count_valid_triples(count_mod_0, count_mod_1, count_mod_2):
    """
    Count triples whose sum is divisible by 3 based on residue counts.
    Valid residue combinations are:
      - (0, 0, 0)
      - (1, 1, 1)
      - (2, 2, 2)
      - (0, 1, 2)
    """
    return (
        comb(count_mod_0, 3)
        + comb(count_mod_1, 3)
        + comb(count_mod_2, 3)
        + count_mod_0 * count_mod_1 * count_mod_2
    )


def get_max_triples(n):
    """
    You are given a positive integer n. You have to create an integer array a of length n.
        For each i (1 â¤ i â¤ n), the value of a[i] = i * i - i + 1.
        Return the number of triples (a[i], a[j], a[k]) of a where i < j < k,
    and a[i] + a[j] + a[k] is a multiple of 3.

    Example :
        Input: n = 5
        Output: 1
        Explanation:
        a = [1, 3, 7, 13, 21]
        The only valid triple is (1, 7, 13).
    """
    if n < 3:
        return 0

    count_mod_0, count_mod_1, count_mod_2 = _count_residues_mod_3(n)
    return _count_valid_triples(count_mod_0, count_mod_1, count_mod_2)
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
