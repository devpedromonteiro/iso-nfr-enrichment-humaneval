
import unittest
import re
import sys
import math
import copy


import operator as op


def _get_operation_map():
    """Return the supported algebra operations."""
    return {
        "+": op.add,
        "-": op.sub,
        "*": op.mul,
        "//": op.floordiv,
        "**": op.pow,
    }


def _validate_inputs(operators, operands):
    """Validate input structure and constraints."""
    if len(operators) != len(operands) - 1:
        raise ValueError("The number of operators must be exactly one less than the number of operands.")

    if len(operators) < 1 or len(operands) < 2:
        raise ValueError("At least one operator and two operands are required.")


def _build_expression(operators, operands):
    """Build the algebraic expression as a string."""
    expression_parts = [str(operands[0])]
    for current_operator, current_operand in zip(operators, operands[1:]):
        expression_parts.append(current_operator)
        expression_parts.append(str(current_operand))
    return " ".join(expression_parts)


def _validate_operators(operators, operation_map):
    """Ensure all operators are supported."""
    unsupported = [symbol for symbol in operators if symbol not in operation_map]
    if unsupported:
        raise ValueError(f"Unsupported operator(s): {', '.join(unsupported)}")


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and
    the second list is a list of integers. Use the two given lists to build the algebraic
    expression and return the evaluation of this expression.

    The basic algebra operations:
    Addition ( + )
    Subtraction ( - )
    Multiplication ( * )
    Floor division ( // )
    Exponentiation ( ** )

    Example:
    operator = ['+', '*', '-']
    operand = [2, 3, 4, 5]
    result = 2 + 3 * 4 - 5
    => result = 9
    """
    operation_map = _get_operation_map()
    _validate_inputs(operator, operand)
    _validate_operators(operator, operation_map)

    expression = _build_expression(operator, operand)
    return eval(expression)
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
