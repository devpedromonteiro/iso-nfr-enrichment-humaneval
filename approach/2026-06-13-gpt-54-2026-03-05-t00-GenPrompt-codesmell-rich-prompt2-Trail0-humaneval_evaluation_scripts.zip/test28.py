
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def _normalize_strings(strings: List[str]) -> List[str]:
    """Return a normalized list of strings for concatenation."""
    return list(strings)


def concatenate(strings: List[str]) -> str:
    """Concatenate list of strings into a single string.

    >>> concatenate([])
    ''
    >>> concatenate(['a', 'b', 'c'])
    'abc'
    """
    normalized_strings = _normalize_strings(strings)
    return "".join(normalized_strings)
candidate = concatenate




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == ''
    assert candidate(['x', 'y', 'z']) == 'xyz'
    assert candidate(['x', 'y', 'z', 'w', 'k']) == 'xyzwk'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
