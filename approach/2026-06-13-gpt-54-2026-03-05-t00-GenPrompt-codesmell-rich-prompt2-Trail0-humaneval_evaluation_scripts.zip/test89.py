
import unittest
import re
import sys
import math
import copy


SHIFT = 4
LOWER_A = ord('a')
LOWER_Z = ord('z')
ALPHABET_SIZE = 26


def _rotate_lowercase_char(char, shift=SHIFT):
    """Rotate a lowercase character forward by the given shift."""
    offset = ord(char) - LOWER_A
    rotated = (offset + shift) % ALPHABET_SIZE
    return chr(LOWER_A + rotated)


def encrypt(s):
    """Return a string with each lowercase letter rotated forward by 4.

    Examples:
        encrypt('hi') -> 'lm'
        encrypt('asdfghjkl') -> 'ewhjklnop'
        encrypt('gf') -> 'kj'
        encrypt('et') -> 'ix'
    """
    return ''.join(_rotate_lowercase_char(char) for char in s)
candidate = encrypt


def check(candidate):

    # Check some simple cases
    assert candidate('hi') == 'lm', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('asdfghjkl') == 'ewhjklnop', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('gf') == 'kj', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('et') == 'ix', "This prints if this assert fails 1 (good for debugging!)"

    assert candidate('faewfawefaewg')=='jeiajeaijeiak', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('hellomyfriend')=='lippsqcjvmirh', "This prints if this assert fails 2 (good for debugging!)"
    assert candidate('dxzdlmnilfuhmilufhlihufnmlimnufhlimnufhfucufh')=='hbdhpqrmpjylqmpyjlpmlyjrqpmqryjlpmqryjljygyjl', "This prints if this assert fails 3 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate('a')=='e', "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
