
import unittest
import re
import sys
import math
import copy



def _is_match_at(text: str, pattern: str, start: int) -> bool:
    """Return True if pattern matches text starting at index start."""
    return text[start:start + len(pattern)] == pattern


def _count_overlapping_occurrences(text: str, pattern: str) -> int:
    """Count overlapping occurrences of pattern in text."""
    pattern_length = len(pattern)
    max_start = len(text) - pattern_length
    count = 0

    for index in range(max_start + 1):
        if _is_match_at(text, pattern, index):
            count += 1

    return count


def how_many_times(string: str, substring: str) -> int:
    """Find how many times a given substring can be found in the original string.

    Overlapping cases are counted.

    >>> how_many_times('', 'a')
    0
    >>> how_many_times('aaa', 'a')
    3
    >>> how_many_times('aaaa', 'aa')
    3
    """
    if not string or not substring or len(substring) > len(string):
        return 0

    return _count_overlapping_occurrences(string, substring)
candidate = how_many_times




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('', 'x') == 0
    assert candidate('xyxyxyx', 'x') == 4
    assert candidate('cacacacac', 'cac') == 4
    assert candidate('john doe', 'john') == 1


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
