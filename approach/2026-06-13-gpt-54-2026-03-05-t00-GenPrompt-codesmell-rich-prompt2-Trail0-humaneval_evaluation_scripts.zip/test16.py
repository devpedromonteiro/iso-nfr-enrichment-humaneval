
import unittest
import re
import sys
import math
import copy



def _normalize_characters(string: str) -> set[str]:
    """Return the set of case-insensitive characters in the string."""
    return set(string.lower())


def count_distinct_characters(string: str) -> int:
    """Given a string, return how many distinct characters it contains, ignoring case.

    >>> count_distinct_characters('xyzXYZ')
    3
    >>> count_distinct_characters('Jerry')
    4
    """
    return len(_normalize_characters(string))
candidate = count_distinct_characters




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == 0
    assert candidate('abcde') == 5
    assert candidate('abcde' + 'cade' + 'CADE') == 5
    assert candidate('aaaaAAAAaaaa') == 1
    assert candidate('Jerry jERRY JeRRRY') == 5


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
