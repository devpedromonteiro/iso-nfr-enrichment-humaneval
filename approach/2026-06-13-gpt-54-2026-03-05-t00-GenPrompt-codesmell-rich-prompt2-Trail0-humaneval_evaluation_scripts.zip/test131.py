
import unittest
import re
import sys
import math
import copy


def is_odd_digit(digit):
    """Return True if the digit is odd."""
    return digit % 2 == 1


def odd_digits_of(n):
    """Yield the odd digits in n."""
    for ch in str(n):
        digit = int(ch)
        if is_odd_digit(digit):
            yield digit


def product(values):
    """Return the product of the given iterable of numbers."""
    result = 1
    found_any = False

    for value in values:
        result *= value
        found_any = True

    return result if found_any else 0


def digits(n):
    """Given a positive integer n, return the product of the odd digits.
    Return 0 if all digits are even.
    For example:
    digits(1) == 1
    digits(4) == 0
    digits(235) == 15
    """
    return product(odd_digits_of(n))
candidate = digits


def check(candidate):

    # Check some simple cases
    assert candidate(5) == 5
    assert candidate(54) == 5
    assert candidate(120) ==1
    assert candidate(5014) == 5
    assert candidate(98765) == 315
    assert candidate(5576543) == 2625

    # Check some edge cases that are easy to work out by hand.
    assert candidate(2468) == 0



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
