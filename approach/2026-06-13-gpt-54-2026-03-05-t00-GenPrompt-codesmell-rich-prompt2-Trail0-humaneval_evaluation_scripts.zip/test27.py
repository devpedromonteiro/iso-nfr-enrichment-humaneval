
import unittest
import re
import sys
import math
import copy



def _flip_character_case(char: str) -> str:
    """Return the character with its case flipped when applicable."""
    if char.islower():
        return char.upper()
    if char.isupper():
        return char.lower()
    return char


def flip_case(string: str) -> str:
    """For a given string, flip lowercase characters to uppercase and uppercase to lowercase.

    >>> flip_case('Hello')
    'hELLO'
    """
    return "".join(_flip_character_case(char) for char in string)
candidate = flip_case




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == ''
    assert candidate('Hello!') == 'hELLO!'
    assert candidate('These violent delights have violent ends') == 'tHESE VIOLENT DELIGHTS HAVE VIOLENT ENDS'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
