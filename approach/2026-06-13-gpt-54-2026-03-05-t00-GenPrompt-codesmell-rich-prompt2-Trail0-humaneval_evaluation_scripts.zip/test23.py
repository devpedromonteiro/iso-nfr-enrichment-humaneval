
import unittest
import re
import sys
import math
import copy



def _validate_string(value: str) -> str:
    """Validate and return the input string."""
    if not isinstance(value, str):
        raise TypeError("value must be a string")
    return value


def strlen(string: str) -> int:
    """Return the length of the given string.

    >>> strlen('')
    0
    >>> strlen('abc')
    3
    """
    validated_string = _validate_string(string)
    return len(validated_string)
candidate = strlen




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == 0
    assert candidate('x') == 1
    assert candidate('asdasnakj') == 9


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
