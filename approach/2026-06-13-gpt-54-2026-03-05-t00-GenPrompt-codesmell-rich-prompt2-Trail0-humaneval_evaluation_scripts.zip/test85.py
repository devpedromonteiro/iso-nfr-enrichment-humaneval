
import unittest
import re
import sys
import math
import copy


def is_odd_index(index):
    return index % 2 == 1


def is_even_number(value):
    return value % 2 == 0


def should_add(index, value):
    return is_odd_index(index) and is_even_number(value)


def add(lst):
    """Given a non-empty list of integers lst, add the even elements at odd indices.

    Examples:
        add([4, 2, 6, 7]) ==> 2
    """
    total = 0
    for index, value in enumerate(lst):
        if should_add(index, value):
            total += value
    return total
candidate = add


def check(candidate):

    # Check some simple cases
    assert candidate([4, 88]) == 88
    assert candidate([4, 5, 6, 7, 2, 122]) == 122
    assert candidate([4, 0, 6, 7]) == 0
    assert candidate([4, 4, 6, 8]) == 12

    # Check some edge cases that are easy to work out by hand.
    


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
