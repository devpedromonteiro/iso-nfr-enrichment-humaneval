
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def concatenate(strings: List[str]) -> str:
    """Concatenate list of strings into a single string.

    Uses ``str.join`` for efficient linear-time concatenation, avoiding
    repeated intermediate string allocations.

    >>> concatenate([])
    ''
    >>> concatenate(['a', 'b', 'c'])
    'abc'
    """
    return "".join(strings)
candidate = concatenate




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == ''
    assert candidate(['x', 'y', 'z']) == 'xyz'
    assert candidate(['x', 'y', 'z', 'w', 'k']) == 'xyzwk'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
