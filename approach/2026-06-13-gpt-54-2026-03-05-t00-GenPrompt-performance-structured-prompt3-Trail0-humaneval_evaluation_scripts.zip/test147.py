
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    You are given a positive integer n. You have to create an integer array a of length n.
        For each i (1 â¤ i â¤ n), the value of a[i] = i * i - i + 1.
        Return the number of triples (a[i], a[j], a[k]) of a where i < j < k,
    and a[i] + a[j] + a[k] is a multiple of 3.

    Example :
        Input: n = 5
        Output: 1
        Explanation:
        a = [1, 3, 7, 13, 21]
        The only valid triple is (1, 7, 13).
    """
    # a[i] = i^2 - i + 1
    # Modulo 3:
    # if i % 3 == 0 -> a[i] % 3 = 1
    # if i % 3 == 1 -> a[i] % 3 = 1
    # if i % 3 == 2 -> a[i] % 3 = 0
    #
    # So array values are only congruent to 0 or 1 modulo 3.
    # A triple sum is divisible by 3 only when residues are (1,1,1) or (0,0,0).

    def comb3(x):
        return x * (x - 1) * (x - 2) // 6 if x >= 3 else 0

    count_0 = n // 3              # indices i where i % 3 == 2
    count_1 = n - count_0         # remaining indices

    return comb3(count_0) + comb3(count_1)
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
