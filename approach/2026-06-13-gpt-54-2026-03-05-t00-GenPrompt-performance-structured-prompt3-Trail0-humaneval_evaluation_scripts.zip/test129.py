
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Given a grid with N rows and N columns (N >= 2) and a positive integer k,
    each cell of the grid contains a value. Every integer in the range [1, N * N]
    inclusive appears exactly once on the cells of the grid.

    Return the lexicographically smallest path of length k, where each move goes
    to a 4-directionally adjacent cell.
    """
    n = len(grid)

    # Map value -> position for O(1) access in value order.
    pos = [None] * (n * n + 1)
    for i in range(n):
        row = grid[i]
        for j in range(n):
            pos[row[j]] = (i, j)

    if k == 1:
        return [1]

    # Precompute neighbors for each value to avoid repeated boundary checks.
    neighbors = [[] for _ in range(n * n + 1)]
    for v in range(1, n * n + 1):
        i, j = pos[v]
        adj = neighbors[v]
        if i > 0:
            adj.append(grid[i - 1][j])
        if i + 1 < n:
            adj.append(grid[i + 1][j])
        if j > 0:
            adj.append(grid[i][j - 1])
        if j + 1 < n:
            adj.append(grid[i][j + 1])

    # The first value in the lexicographically smallest path must be 1.
    path = [1]
    current = {1}

    # At each step, among all neighbors reachable from current frontier,
    # choose the minimum value; keep only positions having that value.
    for _ in range(1, k):
        best = n * n + 1

        for v in current:
            for nv in neighbors[v]:
                if nv < best:
                    best = nv

        path.append(best)

        next_current = set()
        for v in current:
            for nv in neighbors[v]:
                if nv == best:
                    next_current.add(nv)

        current = next_current

    return path
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
