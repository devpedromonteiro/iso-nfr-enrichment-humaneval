
import unittest



def prime_fib(n: int) -> int:
    """
    Return the n-th Fibonacci number that is also prime.

    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """
    if n < 1:
        raise ValueError("n must be a positive integer")

    def is_prime(number: int) -> bool:
        if number < 2:
            return False
        if number == 2:
            return True
        if number % 2 == 0:
            return False

        divisor = 3
        while divisor * divisor <= number:
            if number % divisor == 0:
                return False
            divisor += 2

        return True

    found_prime_fibonacci_numbers = 0
    previous_fibonacci = 0
    current_fibonacci = 1

    while True:
        previous_fibonacci, current_fibonacci = (
            current_fibonacci,
            previous_fibonacci + current_fibonacci,
        )

        if is_prime(current_fibonacci):
            found_prime_fibonacci_numbers += 1
            if found_prime_fibonacci_numbers == n:
                return current_fibonacci
candidate = prime_fib


class Test(unittest.TestCase):
    def test(self):
        assert candidate(2) == 3
        assert candidate(12) == 99194853094755497
        assert candidate(6) == 233
        assert candidate(10) == 433494437
        assert candidate(3) == 5
        assert candidate(5) == 89
        assert candidate(8) == 28657
        assert candidate(11) == 2971215073
        assert candidate(1) == 2
        assert candidate(4) == 13
        assert candidate(9) == 514229
        assert candidate(7) == 1597

if __name__ == '__main__':
    unittest.main()
