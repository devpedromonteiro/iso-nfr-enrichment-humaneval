
import unittest



def is_palindrome(string: str) -> bool:
    """ Test if given string is a palindrome """
    return string == string[::-1]


def is_palindrome(text: str) -> bool:
    """Return True when the given text reads the same forwards and backwards."""
    return text == text[::-1]


def make_palindrome(text: str) -> str:
    """Return the shortest palindrome that starts with the given text.

    The function finds the longest suffix of ``text`` that is already a
    palindrome. It then appends the reverse of the remaining prefix.

    >>> make_palindrome('')
    ''
    >>> make_palindrome('cat')
    'catac'
    >>> make_palindrome('cata')
    'catac'
    """
    for suffix_start_index in range(len(text)):
        suffix = text[suffix_start_index:]

        if is_palindrome(suffix):
            prefix = text[:suffix_start_index]
            missing_suffix = prefix[::-1]
            return text + missing_suffix

    return text
candidate = make_palindrome


class Test(unittest.TestCase):
    def test(self):
        assert candidate('') == ''
        assert candidate("ukbpbbvnc") == 'ukbpbbvncnvbbpbku'
        assert candidate("o") == 'o'
        assert candidate("nlaicsl") == 'nlaicslscialn'
        assert candidate("zv") == 'zvz'
        assert candidate("bgwn") == 'bgwnwgb'
        assert candidate("zihdusrx") == 'zihdusrxrsudhiz'
        assert candidate("lfc") == 'lfcfl'
        assert candidate("fpb") == 'fpbpf'
        assert candidate("kwfpofsz") == 'kwfpofszsfopfwk'
        assert candidate("dbncrsylw") == 'dbncrsylwlysrcnbd'
        assert candidate("iznzp") == 'iznzpznzi'
        assert candidate("cclsf") == 'cclsfslcc'
        assert candidate("fr") == 'frf'
        assert candidate("h") == 'h'
        assert candidate("qslfkgk") == 'qslfkgkflsq'
        assert candidate("dqkl") == 'dqklkqd'
        assert candidate("t") == 't'
        assert candidate("bhrxp") == 'bhrxpxrhb'
        assert candidate("poskeolrb") == 'poskeolrbrloeksop'
        assert candidate("g") == 'g'
        assert candidate("l") == 'l'
        assert candidate("giixmks") == 'giixmkskmxiig'
        assert candidate("xai") == 'xaiax'
        assert candidate("mh") == 'mhm'
        assert candidate("iisoijdkd") == 'iisoijdkdjiosii'
        assert candidate("ezypllk") == 'ezypllkllpyze'
        assert candidate("enn") == 'enne'
        assert candidate("cd") == 'cdc'
        assert candidate("ikdnighc") == 'ikdnighchgindki'
        assert candidate("redcb") == 'redcbcder'
        assert candidate("x") == 'x'
        assert candidate("wcu") == 'wcucw'
        assert candidate("e") == 'e'
        assert candidate("w") == 'w'
        assert candidate("mxace") == 'mxacecaxm'
        assert candidate("sgwvugnmr") == 'sgwvugnmrmnguvwgs'
        assert candidate("uilrh") == 'uilrhrliu'
        assert candidate("fwr") == 'fwrwf'
        assert candidate("z") == 'z'
        assert candidate("k") == 'k'
        assert candidate("ydbxwvdbp") == 'ydbxwvdbpbdvwxbdy'
        assert candidate("xkfc") == 'xkfcfkx'
        assert candidate("bcdeipay") == 'bcdeipayapiedcb'
        assert candidate("zjrfpqn") == 'zjrfpqnqpfrjz'
        assert candidate("xkpirzwh") == 'xkpirzwhwzripkx'
        assert candidate("hobey") == 'hobeyeboh'
        assert candidate("anqudz") == 'anqudzduqna'
        assert candidate("yreb") == 'yrebery'
        assert candidate("pql") == 'pqlqp'
        assert candidate("vychrbm") == 'vychrbmbrhcyv'
        assert candidate('xyz') == 'xyzyx'
        assert candidate("y") == 'y'
        assert candidate("yccs") == 'yccsccy'
        assert candidate("oeb") == 'oebeo'
        assert candidate("q") == 'q'
        assert candidate("qiaxze") == 'qiaxzezxaiq'
        assert candidate("gosuwndv") == 'gosuwndvdnwusog'
        assert candidate("i") == 'i'
        assert candidate("hgvsmppn") == 'hgvsmppnppmsvgh'
        assert candidate("riu") == 'riuir'
        assert candidate("cnlux") == 'cnluxulnc'
        assert candidate("j") == 'j'
        assert candidate("fmi") == 'fmimf'
        assert candidate("yaqebnv") == 'yaqebnvnbeqay'
        assert candidate("naraxn") == 'naraxnxaran'
        assert candidate("nraxigdb") == 'nraxigdbdgixarn'
        assert candidate("mtnhaw") == 'mtnhawahntm'
        assert candidate("u") == 'u'
        assert candidate("rdcue") == 'rdcueucdr'
        assert candidate("idq") == 'idqdi'
        assert candidate("xm") == 'xmx'
        assert candidate("m") == 'm'
        assert candidate("wdqqutcmz") == 'wdqqutcmzmctuqqdw'
        assert candidate("cyg") == 'cygyc'
        assert candidate("xemqb") == 'xemqbqmex'
        assert candidate("f") == 'f'
        assert candidate("bhwjzmju") == 'bhwjzmjujmzjwhb'
        assert candidate("vps") == 'vpspv'
        assert candidate("gbxhqvrck") == 'gbxhqvrckcrvqhxbg'
        assert candidate("riokijrc") == 'riokijrcrjikoir'
        assert candidate("wytdpdao") == 'wytdpdaoadpdtyw'
        assert candidate("jxjzbt") == 'jxjzbtbzjxj'
        assert candidate("qlpr") == 'qlprplq'
        assert candidate("xcplmfsu") == 'xcplmfsusfmlpcx'
        assert candidate('x') == 'x'
        assert candidate("bemb") == 'bembmeb'
        assert candidate("fwdtrdgjx") == 'fwdtrdgjxjgdrtdwf'
        assert candidate('xyx') == 'xyx'
        assert candidate("baef") == 'baefeab'
        assert candidate("mx") == 'mxm'
        assert candidate("a") == 'a'
        assert candidate("mtxdbdpe") == 'mtxdbdpepdbdxtm'
        assert candidate("jjinkb") == 'jjinkbknijj'
        assert candidate("xywku") == 'xywkukwyx'
        assert candidate("yxgb") == 'yxgbgxy'
        assert candidate("etrh") == 'etrhrte'
        assert candidate("cq") == 'cqc'
        assert candidate("spydxujck") == 'spydxujckcjuxdyps'
        assert candidate("wqgac") == 'wqgacagqw'
        assert candidate("ryo") == 'ryoyr'
        assert candidate("zevojmfv") == 'zevojmfvfmjovez'
        assert candidate("n") == 'n'
        assert candidate("txeb") == 'txebext'
        assert candidate("cgd") == 'cgdgc'
        assert candidate("lu") == 'lul'
        assert candidate('jerry') == 'jerryrrej'
        assert candidate("wyht") == 'wyhthyw'
        assert candidate("kb") == 'kbk'
        assert candidate("ucc") == 'uccu'
        assert candidate("lvevy") == 'lvevyvevl'
        assert candidate("qemoea") == 'qemoeaeomeq'
        assert candidate("qafsnlmj") == 'qafsnlmjmlnsfaq'
        assert candidate("v") == 'v'

if __name__ == '__main__':
    unittest.main()
