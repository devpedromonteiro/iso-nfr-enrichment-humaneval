
import unittest


def match_parens(lst):
    '''
    You are given a list of two strings, both strings consist of open
    parentheses '(' or close parentheses ')' only.
    Your job is to check if it is possible to concatenate the two strings in
    some order, that the resulting string will be good.
    A string S is considered to be good if and only if all parentheses in S
    are balanced. For example: the string '(())()' is good, while the string
    '())' is not.
    Return 'Yes' if there's a way to make a good string, and return 'No' otherwise.

    Examples:
    match_parens(['()(', ')']) == 'Yes'
    match_parens([')', ')']) == 'No'
    '''
    a, b = lst

    def stats(s):
        balance = 0
        min_balance = 0
        for ch in s:
            if ch == '(':
                balance += 1
            else:
                balance -= 1
            if balance < min_balance:
                min_balance = balance
        return balance, min_balance

    bal_a, min_a = stats(a)
    bal_b, min_b = stats(b)

    def can_concat(first_bal, first_min, second_bal, second_min):
        total = first_bal + second_bal
        if total != 0:
            return False
        if first_min < 0:
            return False
        if first_bal + second_min < 0:
            return False
        return True

    return 'Yes' if (
        can_concat(bal_a, min_a, bal_b, min_b) or
        can_concat(bal_b, min_b, bal_a, min_a)
    ) else 'No'
candidate = match_parens


class Test(unittest.TestCase):
    def test(self):
        assert candidate((')())', '(()()(')) == 'Yes'
        assert candidate(('((((', ')')) == 'No'
        assert candidate(('()(', '())')) == 'Yes'
        assert candidate(('())', '((((')) == 'No'
        assert candidate(('(()(', '()(')) == 'No'
        assert candidate(('())', '(()()(')) == 'No'
        assert candidate([')', ')']) == 'No'
        assert candidate(('()(', ')')) == 'Yes'
        assert candidate(('(()(())', '()(')) == 'No'
        assert candidate(('(()()(', '())())')) == 'Yes'
        assert candidate(('())', ')())')) == 'No'
        assert candidate(('((((', '((((')) == 'No'
        assert candidate((')(', '(()()(')) == 'No'
        assert candidate((')())', ')())')) == 'No'
        assert candidate((')())', '((())')) == 'No'
        assert candidate(('()', '()(')) == 'No'
        assert candidate(('(()(())', '())())')) == 'No'
        assert candidate(('(', ')')) == 'Yes'
        assert candidate(('(())))', '()(')) == 'No'
        assert candidate(('()', '(()())((')) == 'No'
        assert candidate(('())())', '()(')) == 'No'
        assert candidate(('())())', '(()()(')) == 'Yes'
        assert candidate(('()(', '())())')) == 'No'
        assert candidate(('()))()', '())')) == 'No'
        assert candidate(('(())))', '((())')) == 'No'
        assert candidate(['()', '())']) == 'No'
        assert candidate(['(())))', '(()())((']) == 'Yes'
        assert candidate((')', '(())))')) == 'No'
        assert candidate([')())', '(()()(']) == 'Yes'
        assert candidate(('(()()(', '(()()(')) == 'No'
        assert candidate((')', '(()(())')) == 'Yes'
        assert candidate([')(()', '(()(']) == 'No'
        assert candidate(('(()(())', ')')) == 'Yes'
        assert candidate((')(', '()(')) == 'No'
        assert candidate(('(()()(', ')(()')) == 'No'
        assert candidate(('()(', '(()(())')) == 'No'
        assert candidate((')', '()(')) == 'Yes'
        assert candidate(('())', ')')) == 'No'
        assert candidate(('(()())((', '(()(())')) == 'No'
        assert candidate(('(()(', ')(()')) == 'No'
        assert candidate(('())())', ')())')) == 'No'
        assert candidate(('())', ')(')) == 'No'
        assert candidate(('(()(())', ')(')) == 'No'
        assert candidate(('()', '())')) == 'No'
        assert candidate((')())', '()(')) == 'No'
        assert candidate([')(', ')(']) == 'No'
    

    # Check some edge cases that are easy to work out by hand.
        assert candidate(('(()(', '(()())((')) == 'No'
        assert candidate((')', '(()()(')) == 'No'
        assert candidate(('()(', '(()())((')) == 'No'
        assert candidate(('((())', '(()(')) == 'No'
        assert candidate((')', '())())')) == 'No'
        assert candidate(('()(', '()(')) == 'No'
        assert candidate(['()(', ')']) == 'Yes'
        assert candidate(('(()()(', '(()(())')) == 'No'
        assert candidate(('())())', '()')) == 'No'
        assert candidate(('(()(())', '())')) == 'Yes'
        assert candidate(['(()(', '()))()']) == 'Yes'
        assert candidate(('(()(', '(()(')) == 'No'
        assert candidate(('(())))', '(())))')) == 'No'
        assert candidate(('()(', '(()(')) == 'No'
        assert candidate(('(', '(()())((')) == 'No'
        assert candidate(['(', ')']) == 'Yes'
        assert candidate(['((((', '((())']) == 'No'
        assert candidate(('())())', '(()(())')) == 'No'
        assert candidate(('())', '()')) == 'No'
        assert candidate(('(', '()))()')) == 'No'
        assert candidate(('())())', '(()(')) == 'Yes'
        assert candidate(('(()(())', ')())')) == 'No'
        assert candidate(('((((', '()')) == 'No'
        assert candidate((')())', '(())))')) == 'No'
        assert candidate(('(()())((', ')')) == 'No'
        assert candidate(('()(', ')())')) == 'No'
        assert candidate(('())', '()(')) == 'Yes'
        assert candidate(('()', '(()(())')) == 'No'
        assert candidate((')(()', '(())))')) == 'No'
        assert candidate(('(()()(', '()(')) == 'No'
        assert candidate(('())())', ')')) == 'No'
        assert candidate(['(()(())', '())())']) == 'No'
        assert candidate((')', ')')) == 'No'
        assert candidate(('())())', ')(()')) == 'No'
        assert candidate(('()))()', '(()(')) == 'Yes'
        assert candidate((')())', '((((')) == 'No'
        assert candidate(('(()(())', '(()()(')) == 'No'
        assert candidate(('()', ')())')) == 'No'
        assert candidate(('(())))', '(()()(')) == 'Yes'
        assert candidate((')(', ')(()')) == 'No'
        assert candidate(('(()()(', '(())))')) == 'Yes'
        assert candidate(('(())))', '(()(())')) == 'No'
        assert candidate(('((((', '(()(')) == 'No'
        assert candidate([')', '(']) == 'Yes'
        assert candidate((')(()', '())')) == 'No'
        assert candidate((')())', '())())')) == 'No'

if __name__ == '__main__':
    unittest.main()
