
import unittest


def anti_shuffle(s):
    """
    Write a function that takes a string and returns an ordered version of it.
    Ordered version of string, is a string where all words (separated by space)
    are replaced by a new word where all the characters arranged in
    ascending order based on ascii value.
    Note: You should keep the order of words and blank spaces in the sentence.

    For example:
    anti_shuffle('Hi') returns 'Hi'
    anti_shuffle('hello') returns 'ehllo'
    anti_shuffle('Hello World!!!') returns 'Hello !!!Wdlor'
    """
    parts = []
    word = []

    for ch in s:
        if ch == ' ':
            if word:
                parts.append(''.join(sorted(word)))
                word.clear()
            parts.append(' ')
        else:
            word.append(ch)

    if word:
        parts.append(''.join(sorted(word)))

    return ''.join(parts)
candidate = anti_shuffle


class Test(unittest.TestCase):
    def test(self):
        assert candidate("mik") == 'ikm'
        assert candidate("zpvls") == 'lpsvz'
        assert candidate("+*ppiETg/Q/eT@S") == '*+//@EQSTTegipp'
        assert candidate("nnlqs") == 'lnnqs'
        assert candidate("*Q*J@CV#c ") == '#**@CJQVc '
        assert candidate("Vhp") == 'Vhp'
        assert candidate("lJtH") == 'HJlt'
        assert candidate("ffe") == 'eff'
        assert candidate("mdnilma") == 'adilmmn'
        assert candidate("|hYh/gEdoS|YIN|qp|") == '/EINSYYdghhopq||||'
        assert candidate("ihnrb") == 'bhinr'
        assert candidate("iqi") == 'iiq'
        assert candidate('hello') == 'ehllo'
        assert candidate("q|GJBtlum__|oHCjO") == 'BCGHJO__jlmoqtu||'
        assert candidate("$m@#cT-luArr+fG+") == '#$++-@AGTcflmrru'
        assert candidate('Hi') == 'Hi'
        assert candidate("femlxfmmd") == 'defflmmmx'
        assert candidate("mNXEj") == 'ENXjm'
        assert candidate('abcd') == 'abcd'
        assert candidate("npcpS") == 'Scnpp'
        assert candidate("duiofqtyq") == 'dfioqqtuy'
        assert candidate("orpb") == 'bopr'
        assert candidate("xenh") == 'ehnx'
        assert candidate("kcivkln") == 'cikklnv'
        assert candidate("p") == 'p'
        assert candidate("zraxgcjms") == 'acgjmrsxz'
        assert candidate("eGCr") == 'CGer'
        assert candidate("byg") == 'bgy'
        assert candidate("iabx$?GN%vn-TuM~v ") == '$%-?GMNTabinuvvx~ '
        assert candidate("GuRhW") == 'GRWhu'
        assert candidate("jnvizowzn") == 'ijnnovwzz'
        assert candidate("SXZKbBnNGkoJ") == 'BGJKNSXZbkno'
        assert candidate("cMwLojCFt UZ!Ounjg") == 'CFLMcjotw !OUZgjnu'
        assert candidate("ouf") == 'fou'
        assert candidate("ckUS") == 'SUck'
        assert candidate("dqsix") == 'diqsx'
        assert candidate("g") == 'g'
        assert candidate("tyvbaqgq") == 'abgqqtvy'
        assert candidate("faefoaekmj") == 'aaeeffjkmo'
        assert candidate("bdbqgf") == 'bbdfgq'
        assert candidate("zpdggq") == 'dggpqz'
        assert candidate("jzmfq") == 'fjmqz'
        assert candidate("noefzjcyz") == 'cefjnoyzz'
        assert candidate("nkeipi") == 'eiiknp'
        assert candidate("veftsplp") == 'eflppstv'
        assert candidate('Hello World!!!') == 'Hello !!!Wdlor'
        assert candidate("+@^^iM%^Bi") == '%+@BM^^^ii'
        assert candidate("q") == 'q'
        assert candidate("wxmksuy") == 'kmsuwxy'
        assert candidate("eyotuudlk") == 'deklotuuy'
        assert candidate("PLl") == 'LPl'
        assert candidate("rmkoahewjtxh") == 'aehhjkmortwx'
        assert candidate("mugrj") == 'gjmru'
        assert candidate('number') == 'bemnru'
        assert candidate("pgj") == 'gjp'
        assert candidate("%aTGjg|^!Wsm/B") == '!%/BGTW^agjms|'
        assert candidate("zyptehc") == 'cehptyz'
        assert candidate("SATigd") == 'ASTdgi'
        assert candidate("geu") == 'egu'
        assert candidate("D%kt +F_hYz") == '%Dkt +FY_hz'
        assert candidate("AtD") == 'ADt'
        assert candidate("ivwo") == 'iovw'
        assert candidate("?a~s$ J+rMt!MzNQ~J") == '$?as~ !+JJMMNQrtz~'
        assert candidate("uh") == 'hu'
        assert candidate("gyvvyfnxeabw") == 'abefgnvvwxyy'
        assert candidate("^F|FQbJWYLysYdQj") == 'FFJLQQWYY^bdjsy|'
        assert candidate("ffi") == 'ffi'
        assert candidate("bogba") == 'abbgo'
        assert candidate("jylaidovu") == 'adijlouvy'
        assert candidate("pyqinvmjl") == 'ijlmnpqvy'
        assert candidate("hjg") == 'ghj'
        assert candidate("oosnf") == 'fnoos'
        assert candidate("wfnhodec") == 'cdefhnow'
        assert candidate("per") == 'epr'
        assert candidate('Hi. My name is Mister Robot. How are you?') == '.Hi My aemn is Meirst .Rboot How aer ?ouy'
    # Check some edge cases that are easy to work out by hand.
        assert candidate("t") == 't'
        assert candidate("n") == 'n'
        assert candidate("xscw") == 'cswx'
        assert candidate("yU!G+xMXm?") == '!+?GMUXmxy'
        assert candidate("NeETP") == 'ENPTe'
        assert candidate("dbrynL") == 'Lbdnry'
        assert candidate("ntcnv") == 'cnntv'
        assert candidate("dsh") == 'dhs'
        assert candidate("k") == 'k'
        assert candidate("vubglcl") == 'bcglluv'
        assert candidate("wvF") == 'Fvw'
        assert candidate("vHZc:ls!!|/+p/t") == '!!+//:HZclpstv|'
        assert candidate("ubd") == 'bdu'
        assert candidate("bi") == 'bi'
        assert candidate("ej") == 'ej'
        assert candidate("ao") == 'ao'
        assert candidate("tfc") == 'cft'
        assert candidate("a") == 'a'
        assert candidate("biiohmoi") == 'bhiiimoo'
        assert candidate("vywlbywvzgq") == 'bglqvvwwyyz'
        assert candidate("d_^BpZ!S:J#") == '!#:BJSZ^_dp'
        assert candidate("dbevtyqlk") == 'bdeklqtvy'
        assert candidate('') == ''
        assert candidate("hnbO") == 'Obhn'
        assert candidate("dj") == 'dj'
        assert candidate("rpapvxs") == 'apprsvx'
        assert candidate("iuvjpx") == 'ijpuvx'
        assert candidate("bnsvtwdz") == 'bdnstvwz'
        assert candidate("ZUvIbBJNtqA~") == 'ABIJNUZbqtv~'
        assert candidate("tJ%sMi-jRu") == '%-JMRijstu'
        assert candidate("bzri") == 'birz'
        assert candidate("jva") == 'ajv'
        assert candidate("oo") == 'oo'
        assert candidate("celklujiw") == 'ceijklluw'
        assert candidate("vfvqwbwo") == 'bfoqvvww'
        assert candidate("iKQEO") == 'EKOQi'
        assert candidate("CRkYEb") == 'CERYbk'
        assert candidate("ylyd") == 'dlyy'
        assert candidate("OhAOix") == 'AOOhix'
        assert candidate("zhjdgioa") == 'adghijoz'

if __name__ == '__main__':
    unittest.main()
