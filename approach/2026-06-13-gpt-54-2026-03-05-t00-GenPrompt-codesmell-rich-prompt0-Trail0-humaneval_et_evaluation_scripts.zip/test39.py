
import unittest



from math import isqrt


def is_prime(value: int) -> bool:
    """Return True if value is prime, otherwise False."""
    if value < 2:
        return False
    if value == 2:
        return True
    if value % 2 == 0:
        return False

    limit = isqrt(value)
    for divisor in range(3, limit + 1, 2):
        if value % divisor == 0:
            return False
    return True


def fibonacci_numbers():
    """Yield Fibonacci numbers in ascending order."""
    previous, current = 0, 1
    while True:
        previous, current = current, previous + current
        yield previous


def prime_fib(n: int):
    """
    prime_fib returns n-th number that is a Fibonacci number and it's also prime.
    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """
    if n < 1:
        raise ValueError("n must be a positive integer")

    found = 0
    for number in fibonacci_numbers():
        if is_prime(number):
            found += 1
            if found == n:
                return number
candidate = prime_fib


class Test(unittest.TestCase):
    def test(self):
        assert candidate(2) == 3
        assert candidate(12) == 99194853094755497
        assert candidate(6) == 233
        assert candidate(10) == 433494437
        assert candidate(3) == 5
        assert candidate(5) == 89
        assert candidate(8) == 28657
        assert candidate(11) == 2971215073
        assert candidate(1) == 2
        assert candidate(4) == 13
        assert candidate(9) == 514229
        assert candidate(7) == 1597

if __name__ == '__main__':
    unittest.main()
