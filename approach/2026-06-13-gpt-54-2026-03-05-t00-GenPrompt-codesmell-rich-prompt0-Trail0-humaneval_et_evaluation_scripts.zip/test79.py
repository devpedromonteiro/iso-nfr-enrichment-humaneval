
import unittest


def decimal_to_binary(decimal):
    """Convert a non-negative decimal integer to the required binary string format.

    The returned value is wrapped with 'db' at the beginning and end.

    Examples:
        decimal_to_binary(15) -> "db1111db"
        decimal_to_binary(32) -> "db100000db"
    """
    binary = _to_binary_string(decimal)
    return _wrap_with_db(binary)


def _to_binary_string(decimal):
    """Convert a non-negative integer to its binary representation."""
    if decimal == 0:
        return "0"

    bits = []
    current = decimal

    while current > 0:
        bits.append(str(current % 2))
        current //= 2

    return "".join(reversed(bits))


def _wrap_with_db(binary_string):
    """Wrap a binary string with the required 'db' markers."""
    return f"db{binary_string}db"
candidate = decimal_to_binary


class Test(unittest.TestCase):
    def test(self):
        assert candidate(103) == "db1100111db"
        assert candidate(107) == 'db1101011db'
        assert candidate(4) == 'db100db'
        assert candidate(108) == 'db1101100db'
        assert candidate(99) == 'db1100011db'
        assert candidate(27) == 'db11011db'
        assert candidate(0) == "db0db"
        assert candidate(29) == 'db11101db'
        assert candidate(15) == "db1111db"
        assert candidate(100) == 'db1100100db'
        assert candidate(103) == 'db1100111db'
        assert candidate(32) == 'db100000db'
        assert candidate(3) == 'db11db'
        assert candidate(104) == 'db1101000db'
        assert candidate(32) == "db100000db"
        assert candidate(30) == 'db11110db'
        assert candidate(35) == 'db100011db'
        assert candidate(31) == 'db11111db'
        assert candidate(37) == 'db100101db'
        assert candidate(36) == 'db100100db'
        assert candidate(28) == 'db11100db'
        assert candidate(5) == 'db101db'
        assert candidate(102) == 'db1100110db'
        assert candidate(98) == 'db1100010db'
        assert candidate(101) == 'db1100101db'
        assert candidate(33) == 'db100001db'
        assert candidate(2) == 'db10db'
        assert candidate(34) == 'db100010db'
        assert candidate(106) == 'db1101010db'
        assert candidate(1) == 'db1db'

if __name__ == '__main__':
    unittest.main()
