
import unittest



def prime_fib(n: int):
    """
    prime_fib returns n-th number that is a Fibonacci number and it's also prime.
    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """
    if n < 1:
        raise ValueError("n must be a positive integer")

    def is_prime(x: int) -> bool:
        if x < 2:
            return False
        if x == 2:
            return True
        if x % 2 == 0:
            return False
        d = 3
        while d * d <= x:
            if x % d == 0:
                return False
            d += 2
        return True

    # Fibonacci sequence: 0, 1, 1, 2, 3, 5, ...
    # All prime Fibonacci numbers have prime indices, except F(4)=3.
    count = 0

    # Handle the first two prime Fibonacci numbers directly.
    prime_fibs = (2, 3)
    if n <= len(prime_fibs):
        return prime_fibs[n - 1]
    count = 2

    # Start from F(5)=5
    a, b = 2, 3   # F(3), F(4)
    index = 4

    while count < n:
        a, b = b, a + b
        index += 1

        # Skip composite indices; only prime indices can yield prime Fibonacci
        # numbers, except index 4 which was already handled.
        if index > 4 and not is_prime(index):
            continue

        if is_prime(b):
            count += 1

    return b
candidate = prime_fib


class Test(unittest.TestCase):
    def test(self):
        assert candidate(2) == 3
        assert candidate(12) == 99194853094755497
        assert candidate(6) == 233
        assert candidate(10) == 433494437
        assert candidate(3) == 5
        assert candidate(5) == 89
        assert candidate(8) == 28657
        assert candidate(11) == 2971215073
        assert candidate(1) == 2
        assert candidate(4) == 13
        assert candidate(9) == 514229
        assert candidate(7) == 1597

if __name__ == '__main__':
    unittest.main()
