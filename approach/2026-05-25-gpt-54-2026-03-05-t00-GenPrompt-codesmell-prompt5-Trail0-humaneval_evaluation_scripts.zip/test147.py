
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    You are given a positive integer n. Create an array a of length n where:
        a[i] = i*i - i + 1   for 1 <= i <= n

    Return the number of triples (a[i], a[j], a[k]) such that:
        i < j < k
        and (a[i] + a[j] + a[k]) % 3 == 0

    Example:
        n = 5
        a = [1, 3, 7, 13, 21]
        Valid triple count = 1
    """
    if n < 3:
        return 0

    # For i >= 1:
    # a[i] = i^2 - i + 1 = i(i - 1) + 1
    # Since i(i - 1) is always divisible by 2, but we only care mod 3:
    # Check pattern modulo 3:
    # i % 3 == 0 -> a[i] % 3 == 1
    # i % 3 == 1 -> a[i] % 3 == 1
    # i % 3 == 2 -> a[i] % 3 == 0
    #
    # So values fall into residue classes:
    # residue 0: indices i where i % 3 == 2
    # residue 1: all other indices
    #
    # A triple sums to 0 mod 3 only if residues are:
    # (0,0,0) or (1,1,1)

    count_mod_0 = n // 3                  # indices 2, 5, 8, ...
    count_mod_1 = n - count_mod_0         # remaining indices

    def comb3(x):
        return x * (x - 1) * (x - 2) // 6 if x >= 3 else 0

    return comb3(count_mod_0) + comb3(count_mod_1)
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
