
import unittest
import re
import sys
import math
import copy



def encode_shift(s: str):
    """
    returns encoded string by shifting every character by 5 in the alphabet.
    """
    return "".join([chr(((ord(ch) + 5 - ord("a")) % 26) + ord("a")) for ch in s])


def _shift_char(ch: str, offset: int) -> str:
    return chr(((ord(ch) - ord("a") + offset) % 26) + ord("a"))


def _shift_string(s: str, offset: int) -> str:
    return "".join(_shift_char(ch, offset) for ch in s)


def encode_shift(s: str) -> str:
    """
    Return a string encoded by shifting every lowercase character by 5.
    """
    return _shift_string(s, 5)


def decode_shift(s: str) -> str:
    """
    Decode a string produced by encode_shift.
    """
    return _shift_string(s, -5)
candidate = decode_shift




METADATA = {}


def check(candidate):
    from random import randint, choice
    import copy
    import string

    letters = string.ascii_lowercase
    for _ in range(100):
        str = ''.join(choice(letters) for i in range(randint(10, 20)))
        encoded_str = encode_shift(str)
        assert candidate(copy.deepcopy(encoded_str)) == str



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
