
import unittest
import re
import sys
import math
import copy


def exchange(lst1, lst2):
    """Return "YES" if lst1 can be made all even by exchanging elements with lst2.

    Since any number of exchanges is allowed, each odd number in lst1 must be
    replaced by an even number from lst2. Therefore, it is possible exactly when
    lst2 contains at least as many even numbers as lst1 contains odd numbers.
    """
    odd_count_lst1 = sum(1 for value in lst1 if value % 2 != 0)
    even_count_lst2 = sum(1 for value in lst2 if value % 2 == 0)

    return "YES" if even_count_lst2 >= odd_count_lst1 else "NO"
candidate = exchange


def check(candidate):

    # Check some simple cases
    assert candidate([1, 2, 3, 4], [1, 2, 3, 4]) == "YES"
    assert candidate([1, 2, 3, 4], [1, 5, 3, 4]) == "NO"
    assert candidate([1, 2, 3, 4], [2, 1, 4, 3]) == "YES" 
    assert candidate([5, 7, 3], [2, 6, 4]) == "YES"
    assert candidate([5, 7, 3], [2, 6, 3]) == "NO" 
    assert candidate([3, 2, 6, 1, 8, 9], [3, 5, 5, 1, 1, 1]) == "NO"

    # Check some edge cases that are easy to work out by hand.
    assert candidate([100, 200], [200, 200]) == "YES"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
