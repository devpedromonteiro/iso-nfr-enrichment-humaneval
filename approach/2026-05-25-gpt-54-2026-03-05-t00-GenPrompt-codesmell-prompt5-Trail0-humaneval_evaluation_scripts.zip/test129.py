
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Return the lexicographically smallest path of length k in the grid.

    A path:
    - starts at any cell
    - moves only up/down/left/right
    - visits exactly k cells
    - may revisit cells

    Since all values from 1..N*N appear exactly once, the smallest possible
    first value is always 1, so the optimal path must start from the cell
    containing 1. After that, at each step, to keep the whole sequence
    lexicographically minimal, we should move to the neighboring cell with the
    smallest value.

    This greedy choice is optimal because lexicographic order is determined by
    the earliest differing element.
    """
    if not grid or not grid[0] or k <= 0:
        return []

    rows = len(grid)
    cols = len(grid[0])

    # Find the starting cell containing value 1.
    start_row = start_col = -1
    for r in range(rows):
        for c in range(cols):
            if grid[r][c] == 1:
                start_row, start_col = r, c
                break
        if start_row != -1:
            break

    path = [1]
    row, col = start_row, start_col

    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]

    for _ in range(k - 1):
        best_row = best_col = -1
        best_value = float("inf")

        for dr, dc in directions:
            nr, nc = row + dr, col + dc
            if 0 <= nr < rows and 0 <= nc < cols:
                if grid[nr][nc] < best_value:
                    best_value = grid[nr][nc]
                    best_row, best_col = nr, nc

        path.append(best_value)
        row, col = best_row, best_col

    return path
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
