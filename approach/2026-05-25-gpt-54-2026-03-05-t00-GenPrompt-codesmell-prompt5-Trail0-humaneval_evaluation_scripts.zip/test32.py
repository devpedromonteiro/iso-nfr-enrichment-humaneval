
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math
from typing import Sequence


def poly(xs: Sequence[float], x: float) -> float:
    """
    Evaluate a polynomial with coefficients xs at point x.

    The polynomial is:
        xs[0] + xs[1] * x + xs[2] * x^2 + ... + xs[n] * x^n
    """
    # Horner's method: faster and avoids repeated pow calls
    result = 0.0
    for coeff in reversed(xs):
        result = result * x + coeff
    return result


def find_zero(xs: Sequence[float], eps: float = 1e-12, max_iter: int = 10_000) -> float:
    """
    xs are coefficients of a polynomial.

    Return one x such that poly(xs, x) == 0 approximately.

    Assumptions from the task:
    - xs has an even number of coefficients
    - the largest non-zero coefficient guarantees existence of a real root
      (equivalently, the polynomial has odd degree)

    The function returns one root, even if there are many.

    >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2)  # (x - 1) * (x - 2) * (x - 3)
    1.0
    """
    if not xs:
        raise ValueError("xs must not be empty")

    # Remove trailing zeros so degree is correct
    coeffs = list(xs)
    while coeffs and coeffs[-1] == 0:
        coeffs.pop()

    if not coeffs:
        raise ValueError("zero polynomial has infinitely many roots")

    degree = len(coeffs) - 1
    if degree % 2 == 0:
        raise ValueError("polynomial degree must be odd to guarantee a real root")

    def f(x: float) -> float:
        return poly(coeffs, x)

    # Quick success for x = 0
    f0 = f(0.0)
    if abs(f0) <= eps:
        return 0.0

    # Find a bracket [left, right] with opposite signs
    left, right = -1.0, 1.0
    f_left, f_right = f(left), f(right)

    expand_steps = 0
    while f_left * f_right > 0:
        left *= 2.0
        right *= 2.0
        f_left, f_right = f(left), f(right)
        expand_steps += 1
        if expand_steps > max_iter:
            raise RuntimeError("failed to bracket a root")

    # If one endpoint is already a root
    if abs(f_left) <= eps:
        return left
    if abs(f_right) <= eps:
        return right

    # Bisection method
    for _ in range(max_iter):
        mid = (left + right) / 2.0
        f_mid = f(mid)

        if abs(f_mid) <= eps or abs(right - left) <= eps:
            return mid

        if f_left * f_mid <= 0:
            right = mid
            f_right = f_mid
        else:
            left = mid
            f_left = f_mid

    return (left + right) / 2.0
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
