
import unittest
import re
import sys
import math
import copy



def is_palindrome(string: str) -> bool:
    """ Test if given string is a palindrome """
    return string == string[::-1]


def is_palindrome(string: str) -> bool:
    """Return True if the given string is a palindrome."""
    return string == string[::-1]


def make_palindrome(string: str) -> str:
    """Return the shortest palindrome that starts with the supplied string.

    The algorithm:
    - Find the earliest suffix that is a palindrome.
    - Mirror the non-palindromic prefix onto the end.

    >>> make_palindrome('')
    ''
    >>> make_palindrome('cat')
    'catac'
    >>> make_palindrome('cata')
    'catac'
    >>> make_palindrome('race')
    'racecar'
    >>> make_palindrome('aba')
    'aba'
    """
    for index in range(len(string)):
        suffix = string[index:]
        if is_palindrome(suffix):
            prefix = string[:index]
            return string + prefix[::-1]

    return string
candidate = make_palindrome




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == ''
    assert candidate('x') == 'x'
    assert candidate('xyz') == 'xyzyx'
    assert candidate('xyx') == 'xyx'
    assert candidate('jerry') == 'jerryrrej'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
