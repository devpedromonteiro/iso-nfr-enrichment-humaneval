
import unittest
import re
import sys
import math
import copy



def triples_sum_to_zero(numbers: list[int]) -> bool:
    """
    Return True if there are three distinct elements in the list whose sum is 0,
    and False otherwise.

    >>> triples_sum_to_zero([1, 3, 5, 0])
    False
    >>> triples_sum_to_zero([1, 3, -2, 1])
    True
    >>> triples_sum_to_zero([1, 2, 3, 7])
    False
    >>> triples_sum_to_zero([2, 4, -5, 3, 9, 7])
    True
    >>> triples_sum_to_zero([1])
    False
    """
    if len(numbers) < 3:
        return False

    numbers = sorted(numbers)

    for i in range(len(numbers) - 2):
        left = i + 1
        right = len(numbers) - 1

        while left < right:
            total = numbers[i] + numbers[left] + numbers[right]

            if total == 0:
                return True
            if total < 0:
                left += 1
            else:
                right -= 1

    return False
candidate = triples_sum_to_zero




METADATA = {}


def check(candidate):
    assert candidate([1, 3, 5, 0]) == False
    assert candidate([1, 3, 5, -1]) == False
    assert candidate([1, 3, -2, 1]) == True
    assert candidate([1, 2, 3, 7]) == False
    assert candidate([1, 2, 5, 7]) == False
    assert candidate([2, 4, -5, 3, 9, 7]) == True
    assert candidate([1]) == False
    assert candidate([1, 3, 5, -100]) == False
    assert candidate([100, 3, 5, -100]) == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
