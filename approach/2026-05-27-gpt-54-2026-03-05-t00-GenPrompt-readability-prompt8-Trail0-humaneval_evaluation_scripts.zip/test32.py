
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math


def poly(coeffs: list[float], x: float) -> float:
    """
    Evaluate a polynomial at point x.

    The polynomial is defined by coefficients:
        coeffs[0] + coeffs[1] * x + coeffs[2] * x^2 + ... + coeffs[n] * x^n
    """
    return sum(coeff * (x ** power) for power, coeff in enumerate(coeffs))


def find_zero(coeffs: list[float]) -> float:
    """
    Find one real zero of a polynomial.

    The input must satisfy:
    - coeffs has even length
    - the highest non-zero coefficient corresponds to an odd degree

    Under these assumptions, the polynomial is guaranteed to have at least
    one real root.

    Returns one root using binary search after finding an interval where the
    polynomial changes sign.

    >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2)  # (x - 1)(x - 2)(x - 3)
    1.0
    """
    if not coeffs:
        raise ValueError("Coefficient list must not be empty.")

    left = -1.0
    right = 1.0
    f_left = poly(coeffs, left)
    f_right = poly(coeffs, right)

    if f_left == 0:
        return left
    if f_right == 0:
        return right

    while f_left * f_right > 0:
        left *= 2
        right *= 2
        f_left = poly(coeffs, left)
        f_right = poly(coeffs, right)

    eps = 1e-12
    while right - left > eps:
        mid = (left + right) / 2
        f_mid = poly(coeffs, mid)

        if f_mid == 0:
            return mid

        if f_left * f_mid < 0:
            right = mid
            f_right = f_mid
        else:
            left = mid
            f_left = f_mid

    return (left + right) / 2
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
