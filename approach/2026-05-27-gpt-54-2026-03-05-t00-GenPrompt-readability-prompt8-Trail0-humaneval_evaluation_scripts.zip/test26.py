
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List
from collections import Counter


def remove_duplicates(numbers: List[int]) -> List[int]:
    """Remove all integers that appear more than once, preserving order.

    >>> remove_duplicates([1, 2, 3, 2, 4])
    [1, 3, 4]
    """
    counts = Counter(numbers)
    return [number for number in numbers if counts[number] == 1]
candidate = remove_duplicates




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == []
    assert candidate([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert candidate([1, 2, 3, 2, 4, 3, 5]) == [1, 4, 5]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
