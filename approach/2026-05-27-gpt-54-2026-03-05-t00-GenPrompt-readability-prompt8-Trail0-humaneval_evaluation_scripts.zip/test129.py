
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Return the lexicographically smallest path of length k in the grid.

    A path:
    - starts at any cell
    - moves only up/down/left/right
    - visits exactly k cells
    - may revisit cells

    Since all values from 1 to N*N appear exactly once, the smallest possible
    first value is always the globally smallest reachable starting value.
    To build the lexicographically smallest path, we keep track of all positions
    that can produce the current best prefix, then extend them step by step
    using the smallest possible next value.

    Args:
        grid: NxN matrix containing each integer from 1 to N*N exactly once
        k: length of the path (number of visited cells)

    Returns:
        List[int]: values along the lexicographically smallest path
    """
    n = len(grid)

    if not grid or not grid[0] or k <= 0:
        return []

    # Directions: up, down, left, right
    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]

    def neighbors(r, c):
        """Yield valid neighboring cells of (r, c)."""
        for dr, dc in directions:
            nr, nc = r + dr, c + dc
            if 0 <= nr < n and 0 <= nc < n:
                yield nr, nc

    # Step 1: choose the smallest starting value
    min_value = min(min(row) for row in grid)
    current_positions = {
        (r, c)
        for r in range(n)
        for c in range(n)
        if grid[r][c] == min_value
    }

    result = [min_value]

    # Step 2: greedily extend the path
    for _ in range(k - 1):
        next_positions = set()
        best_next_value = float("inf")

        # Find the minimum possible next value among all valid moves
        for r, c in current_positions:
            for nr, nc in neighbors(r, c):
                value = grid[nr][nc]
                if value < best_next_value:
                    best_next_value = value
                    next_positions = {(nr, nc)}
                elif value == best_next_value:
                    next_positions.add((nr, nc))

        result.append(best_next_value)
        current_positions = next_positions

    return result
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
