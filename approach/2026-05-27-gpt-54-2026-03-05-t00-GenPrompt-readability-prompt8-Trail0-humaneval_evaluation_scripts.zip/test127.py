
import unittest
import re
import sys
import math
import copy


def intersection(interval1, interval2):
    """Return "YES" if the length of the intersection of two closed intervals
    is a prime number, otherwise return "NO".
    """

    def is_prime(n):
        if n < 2:
            return False
        i = 2
        while i * i <= n:
            if n % i == 0:
                return False
            i += 1
        return True

    start1, end1 = interval1
    start2, end2 = interval2

    # Find the overlapping interval
    overlap_start = max(start1, start2)
    overlap_end = min(end1, end2)

    # No intersection
    if overlap_start >= overlap_end:
        return "NO"

    # Length of intersection for closed intervals (a, b) is b - a
    overlap_length = overlap_end - overlap_start

    return "YES" if is_prime(overlap_length) else "NO"
candidate = intersection


def check(candidate):

    # Check some simple cases
    assert candidate((1, 2), (2, 3)) == "NO"
    assert candidate((-1, 1), (0, 4)) == "NO"
    assert candidate((-3, -1), (-5, 5)) == "YES"
    assert candidate((-2, 2), (-4, 0)) == "YES"

    # Check some edge cases that are easy to work out by hand.
    assert candidate((-11, 2), (-1, -1)) == "NO"
    assert candidate((1, 2), (3, 5)) == "NO"
    assert candidate((1, 2), (1, 2)) == "NO"
    assert candidate((-2, -2), (-3, -2)) == "NO"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
