
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    Return the number of triples (a[i], a[j], a[k]) such that:
      - 1 <= i < j < k <= n
      - a[i] + a[j] + a[k] is divisible by 3
    where:
      a[i] = i*i - i + 1

    Observation:
      a[i] % 3 depends only on i % 3:
        i % 3 == 0 -> a[i] % 3 == 1
        i % 3 == 1 -> a[i] % 3 == 1
        i % 3 == 2 -> a[i] % 3 == 0

    So values fall into two groups:
      - remainder 1: count = number of indices i where i % 3 != 2
      - remainder 0: count = number of indices i where i % 3 == 2

    A triple sum is divisible by 3 only in these cases:
      - (0, 0, 0)
      - (1, 1, 1)

    Therefore answer = C(count0, 3) + C(count1, 3)
    """

    def comb3(x):
        return x * (x - 1) * (x - 2) // 6 if x >= 3 else 0

    count0 = (n + 1) // 3          # indices with i % 3 == 2
    count1 = n - count0            # remaining indices

    return comb3(count0) + comb3(count1)
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
