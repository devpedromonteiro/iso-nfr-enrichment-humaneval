
import unittest
import re
import sys
import math
import copy


def specialFilter(nums):
    def first_and_last_digits_are_odd(n):
        s = str(abs(n))
        return int(s[0]) % 2 == 1 and int(s[-1]) % 2 == 1

    count = 0
    for num in nums:
        if num > 10 and first_and_last_digits_are_odd(num):
            count += 1
    return count
candidate = specialFilter


def check(candidate):

    # Check some simple cases
    assert candidate([5, -2, 1, -5]) == 0  
    assert candidate([15, -73, 14, -15]) == 1
    assert candidate([33, -2, -3, 45, 21, 109]) == 2
    assert candidate([43, -12, 93, 125, 121, 109]) == 4
    assert candidate([71, -2, -33, 75, 21, 19]) == 3


    # Check some edge cases that are easy to work out by hand.
    assert candidate([1]) == 0              
    assert candidate([]) == 0                   



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
