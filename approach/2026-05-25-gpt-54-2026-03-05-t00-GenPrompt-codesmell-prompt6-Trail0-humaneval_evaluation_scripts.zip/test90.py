
import unittest
import re
import sys
import math
import copy


def next_smallest(lst):
    """
    Return the 2nd smallest distinct element in the list.
    Return None if there is no such element.
    """
    if not lst:
        return None

    smallest = None
    second_smallest = None

    for num in lst:
        if smallest is None or num < smallest:
            if num != smallest:
                second_smallest = smallest
                smallest = num
        elif num != smallest and (second_smallest is None or num < second_smallest):
            second_smallest = num

    return second_smallest
candidate = next_smallest


def check(candidate):

    # Check some simple cases
    assert candidate([1, 2, 3, 4, 5]) == 2
    assert candidate([5, 1, 4, 3, 2]) == 2
    assert candidate([]) == None
    assert candidate([1, 1]) == None
    assert candidate([1,1,1,1,0]) == 1
    assert candidate([1, 0**0]) == None
    assert candidate([-35, 34, 12, -45]) == -35

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
