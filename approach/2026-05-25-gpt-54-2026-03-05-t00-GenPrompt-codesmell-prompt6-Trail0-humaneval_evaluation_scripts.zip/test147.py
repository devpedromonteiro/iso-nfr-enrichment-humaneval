
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    Return the number of triples (a[i], a[j], a[k]) with i < j < k such that
    a[i] + a[j] + a[k] is divisible by 3, where:

        a[i] = i*i - i + 1   for 1 <= i <= n

    Observation:
    Since only divisibility by 3 matters, we only need:
        a[i] mod 3 = (i*i - i + 1) mod 3

    Checking i mod 3:
        i % 3 == 0 -> a[i] % 3 == 1
        i % 3 == 1 -> a[i] % 3 == 1
        i % 3 == 2 -> a[i] % 3 == 0

    So array values are only of two residue types:
        residue 0: indices where i % 3 == 2
        residue 1: all other indices

    A triple sum is divisible by 3 only when residues are:
        (0, 0, 0) or (1, 1, 1)

    Therefore answer is:
        C(count0, 3) + C(count1, 3)
    """
    if n < 3:
        return 0

    count0 = (n + 1) // 3          # numbers in [1..n] with i % 3 == 2
    count1 = n - count0

    def comb3(x):
        return x * (x - 1) * (x - 2) // 6 if x >= 3 else 0

    return comb3(count0) + comb3(count1)
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
