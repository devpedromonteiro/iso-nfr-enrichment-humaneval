
import unittest
import re
import sys
import math
import copy


import math

def max_fill(grid, capacity):
    """
    You are given a rectangular grid of wells. Each row represents a single well,
    and each 1 in a row represents a single unit of water.
    Each well has a corresponding bucket that can be used to extract water from it,
    and all buckets have the same capacity.
    Return the total number of times the buckets must be lowered to empty all wells.

    For each row:
        lowers_needed = ceil(number_of_1s / capacity)

    Example 1:
        grid = [[0,0,1,0], [0,1,0,0], [1,1,1,1]], capacity = 1
        -> 1 + 1 + 4 = 6

    Example 2:
        grid = [[0,0,1,1], [0,0,0,0], [1,1,1,1], [0,1,1,1]], capacity = 2
        -> 1 + 0 + 2 + 2 = 5

    Example 3:
        grid = [[0,0,0], [0,0,0]], capacity = 5
        -> 0
    """
    total_lowers = 0

    for row in grid:
        water_units = sum(row)
        total_lowers += math.ceil(water_units / capacity)

    return total_lowers
candidate = max_fill


def check(candidate):


    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([[0,0,1,0], [0,1,0,0], [1,1,1,1]], 1) == 6, "Error"
    assert candidate([[0,0,1,1], [0,0,0,0], [1,1,1,1], [0,1,1,1]], 2) == 5, "Error"
    assert candidate([[0,0,0], [0,0,0]], 5) == 0, "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([[1,1,1,1], [1,1,1,1]], 2) == 4, "Error"
    assert candidate([[1,1,1,1], [1,1,1,1]], 9) == 2, "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
