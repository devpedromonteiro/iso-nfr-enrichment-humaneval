
import unittest
import re
import sys
import math
import copy



def largest_divisor(n: int) -> int:
    """Return the largest proper divisor of n.

    A proper divisor divides n evenly and is smaller than n.

    >>> largest_divisor(15)
    5
    >>> largest_divisor(12)
    6
    >>> largest_divisor(13)
    1
    """
    if n <= 1:
        raise ValueError("n must be greater than 1")

    for divisor in range(n // 2, 0, -1):
        if n % divisor == 0:
            return divisor
candidate = largest_divisor




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(3) == 1
    assert candidate(7) == 1
    assert candidate(10) == 5
    assert candidate(100) == 50
    assert candidate(49) == 7


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
