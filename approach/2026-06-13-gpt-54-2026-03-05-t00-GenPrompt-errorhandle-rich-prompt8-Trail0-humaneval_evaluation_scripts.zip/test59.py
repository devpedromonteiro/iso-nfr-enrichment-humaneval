
import unittest
import re
import sys
import math
import copy



def largest_prime_factor(n: int):
    """Return the largest prime factor of n.

    Assumptions:
    - n must be an integer
    - n must be greater than 1
    - n must not be prime

    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if n <= 1:
        raise ValueError("n must be greater than 1")

    original_n = n
    largest = None

    while n % 2 == 0:
        largest = 2
        n //= 2

    factor = 3
    while factor * factor <= n:
        while n % factor == 0:
            largest = factor
            n //= factor
        factor += 2

    if n > 1:
        if largest is None:
            raise ValueError(f"n must not be prime: {original_n}")
        largest = n

    if largest is None:
        raise ValueError(f"could not determine a largest prime factor for: {original_n}")

    return largest
candidate = largest_prime_factor




METADATA = {}


def check(candidate):
    assert candidate(15) == 5
    assert candidate(27) == 3
    assert candidate(63) == 7
    assert candidate(330) == 11
    assert candidate(13195) == 29



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
