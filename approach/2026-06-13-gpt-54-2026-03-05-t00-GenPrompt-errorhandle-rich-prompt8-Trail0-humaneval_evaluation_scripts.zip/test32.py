
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[2] * x^2 + .... + xs[n] * x^n
    """
    if not isinstance(xs, list):
        raise TypeError("xs must be a list of numeric coefficients")
    if not xs:
        raise ValueError("xs must not be empty")
    if not isinstance(x, (int, float)):
        raise TypeError("x must be a numeric value")

    for i, coeff in enumerate(xs):
        if not isinstance(coeff, (int, float)):
            raise TypeError(f"coefficient at index {i} must be numeric")

    return sum(coeff * math.pow(x, i) for i, coeff in enumerate(xs))


def find_zero(xs: list):
    """ xs are coefficients of a polynomial.
    find_zero find x such that poly(x) = 0.
    find_zero returns only only zero point, even if there are many.
    Moreover, find_zero only takes list xs having even number of coefficients
    and largest non zero coefficient as it guarantees
    a solution.

    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3
    1.0
    """
    if not isinstance(xs, list):
        raise TypeError("xs must be a list of numeric coefficients")
    if not xs:
        raise ValueError("xs must not be empty")

    for i, coeff in enumerate(xs):
        if not isinstance(coeff, (int, float)):
            raise TypeError(f"coefficient at index {i} must be numeric")

    non_zero_indices = [i for i, coeff in enumerate(xs) if coeff != 0]
    if not non_zero_indices:
        raise ValueError("zero polynomial has no well-defined single root")

    degree = non_zero_indices[-1]
    leading_coeff = xs[degree]

    if degree % 2 == 0:
        raise ValueError("polynomial degree must be odd to guarantee a real root")

    if leading_coeff == 0:
        raise ValueError("leading coefficient must be non-zero")

    # Handle constant and linear cases explicitly
    if degree == 0:
        raise ValueError("constant non-zero polynomial has no root")
    if degree == 1:
        if xs[1] == 0:
            raise ValueError("invalid linear polynomial: leading coefficient is zero")
        return -xs[0] / xs[1]

    def f(x):
        return poly(xs, x)

    # Find a bracketing interval [left, right] such that f(left) and f(right)
    # have opposite signs or one endpoint is exactly a root.
    left, right = -1.0, 1.0
    max_expand = 100
    try:
        f_left = f(left)
        f_right = f(right)
    except (OverflowError, ValueError) as exc:
        raise ArithmeticError("failed to evaluate polynomial during bracketing") from exc

    for _ in range(max_expand):
        if f_left == 0:
            return left
        if f_right == 0:
            return right
        if f_left * f_right < 0:
            break

        left *= 2
        right *= 2
        try:
            f_left = f(left)
            f_right = f(right)
        except OverflowError as exc:
            raise ArithmeticError("numeric overflow while searching for root bracket") from exc
    else:
        raise RuntimeError("failed to bracket a root for the polynomial")

    # Bisection method: robust and keeps state consistent on failure.
    tolerance = 1e-12
    max_iter = 1000

    for _ in range(max_iter):
        mid = (left + right) / 2.0
        try:
            f_mid = f(mid)
        except OverflowError as exc:
            raise ArithmeticError("numeric overflow during root refinement") from exc

        if abs(f_mid) < tolerance or abs(right - left) < tolerance:
            return mid

        if f_left * f_mid < 0:
            right = mid
            f_right = f_mid
        else:
            left = mid
            f_left = f_mid

    raise RuntimeError("bisection did not converge within the iteration limit")
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
