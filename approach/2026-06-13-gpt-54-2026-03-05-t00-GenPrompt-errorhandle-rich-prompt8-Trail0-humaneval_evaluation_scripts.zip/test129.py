
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Given a grid with N rows and N columns (N >= 2) and a positive integer k,
    return the lexicographically smallest path of length k, where each move
    goes to an edge-adjacent cell.

    Error handling:
    - Raises TypeError for incorrect argument types.
    - Raises ValueError for invalid argument values or malformed grid content.
    """

    # Validate k
    if not isinstance(k, int):
        raise TypeError("k must be an integer")
    if k <= 0:
        raise ValueError("k must be a positive integer")

    # Validate grid container
    if not isinstance(grid, list):
        raise TypeError("grid must be a list of lists")
    if len(grid) < 2:
        raise ValueError("grid must have at least 2 rows")

    n = len(grid)

    # Validate square grid and contents
    seen = set()
    expected_values = set(range(1, n * n + 1))

    for i, row in enumerate(grid):
        if not isinstance(row, list):
            raise TypeError(f"grid row {i} must be a list")
        if len(row) != n:
            raise ValueError("grid must be square (N x N)")
        for j, val in enumerate(row):
            if not isinstance(val, int):
                raise TypeError(f"grid[{i}][{j}] must be an integer")
            if val in seen:
                raise ValueError(f"duplicate value found in grid: {val}")
            seen.add(val)

    if seen != expected_values:
        missing = expected_values - seen
        extra = seen - expected_values
        details = []
        if missing:
            details.append(f"missing values: {sorted(missing)}")
        if extra:
            details.append(f"out-of-range values: {sorted(extra)}")
        raise ValueError(
            "grid must contain each integer in [1, N*N] exactly once"
            + (f" ({'; '.join(details)})" if details else "")
        )

    # Map each value to its position
    positions = {}
    for i in range(n):
        for j in range(n):
            positions[grid[i][j]] = (i, j)

    # Build adjacency by value
    neighbors = {}
    for val, (r, c) in positions.items():
        adj = []
        for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nr, nc = r + dr, c + dc
            if 0 <= nr < n and 0 <= nc < n:
                adj.append(grid[nr][nc])
        neighbors[val] = adj

    # Dynamic programming:
    # best_seq[v][length] conceptually means the lexicographically smallest
    # sequence of given length starting from value v.
    current = {v: [v] for v in positions}

    for length in range(2, k + 1):
        nxt = {}
        for v in positions:
            best_candidate = None
            for nb in neighbors[v]:
                candidate = [v] + current[nb]
                if best_candidate is None or candidate < best_candidate:
                    best_candidate = candidate
            nxt[v] = best_candidate
        current = nxt

    # Choose best starting point
    result = None
    for v in positions:
        if result is None or current[v] < result:
            result = current[v]

    return result
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
