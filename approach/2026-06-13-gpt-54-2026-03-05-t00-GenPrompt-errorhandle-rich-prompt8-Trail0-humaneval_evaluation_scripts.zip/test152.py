
import unittest
import re
import sys
import math
import copy


def compare(game, guess):
    """Compare actual scores to guessed scores.

    Returns a list where each element is:
    - 0 if the guess matches the score
    - otherwise the absolute difference between score and guess

    Raises:
        TypeError: if inputs are not lists/tuples or contain non-numeric values
        ValueError: if inputs are of different lengths
    """
    if game is None or guess is None:
        raise TypeError("game and guess must not be None")

    if not isinstance(game, (list, tuple)):
        raise TypeError("game must be a list or tuple")
    if not isinstance(guess, (list, tuple)):
        raise TypeError("guess must be a list or tuple")

    if len(game) != len(guess):
        raise ValueError("game and guess must have the same length")

    result = []

    for i, (actual, predicted) in enumerate(zip(game, guess)):
        if not isinstance(actual, (int, float)) or isinstance(actual, bool):
            raise TypeError(f"game[{i}] must be a numeric value")
        if not isinstance(predicted, (int, float)) or isinstance(predicted, bool):
            raise TypeError(f"guess[{i}] must be a numeric value")

        result.append(abs(actual - predicted))

    return result
candidate = compare


def check(candidate):

    # Check some simple cases
    assert candidate([1,2,3,4,5,1],[1,2,3,4,2,-2])==[0,0,0,0,3,3], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([0,0,0,0,0,0],[0,0,0,0,0,0])==[0,0,0,0,0,0], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,2,3],[-1,-2,-3])==[2,4,6], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,2,3,5],[-1,2,3,4])==[2,0,0,1], "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
