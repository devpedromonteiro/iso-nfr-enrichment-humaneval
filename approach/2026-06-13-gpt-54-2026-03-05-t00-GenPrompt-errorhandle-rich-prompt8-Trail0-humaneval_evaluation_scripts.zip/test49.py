
import unittest
import re
import sys
import math
import copy



def modp(n: int, p: int):
    """Return 2^n modulo p (be aware of numerics).

    >>> modp(3, 5)
    3
    >>> modp(1101, 101)
    2
    >>> modp(0, 101)
    1
    >>> modp(3, 11)
    8
    >>> modp(100, 101)
    1
    """
    if not isinstance(n, int):
        raise TypeError(f"n must be an int, got {type(n).__name__}")
    if not isinstance(p, int):
        raise TypeError(f"p must be an int, got {type(p).__name__}")
    if n < 0:
        raise ValueError("n must be non-negative")
    if p <= 0:
        raise ValueError("p must be a positive integer")

    try:
        return pow(2, n, p)
    except OverflowError as exc:
        raise OverflowError("numeric overflow while computing modular exponentiation") from exc
    except ValueError:
        # Re-raise ValueError unchanged to preserve specific argument errors.
        raise
candidate = modp




METADATA = {}


def check(candidate):
    assert candidate(3, 5) == 3
    assert candidate(1101, 101) == 2
    assert candidate(0, 101) == 1
    assert candidate(3, 11) == 8
    assert candidate(100, 101) == 1
    assert candidate(30, 5) == 4
    assert candidate(31, 5) == 3



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
