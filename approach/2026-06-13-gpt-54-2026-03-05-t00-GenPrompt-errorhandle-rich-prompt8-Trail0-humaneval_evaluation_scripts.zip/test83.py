
import unittest
import re
import sys
import math
import copy


def starts_one_ends(n):
    """
    Given a positive integer n, return the count of the n-digit positive
    integers that start or end with 1.

    Rules:
    - n must be an integer
    - n must be positive

    Examples:
    - n = 1 -> 1   (only "1")
    - n = 2 -> 18
    """
    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if isinstance(n, bool):
        raise TypeError("n must be an integer, not bool")
    if n <= 0:
        raise ValueError("n must be a positive integer")

    try:
        if n == 1:
            return 1

        # Count numbers that start with 1:
        # first digit fixed as 1, remaining n-1 digits arbitrary
        starts_with_1 = 10 ** (n - 1)

        # Count numbers that end with 1:
        # first digit: 1-9 (9 choices)
        # middle n-2 digits: 10 choices each
        # last digit fixed as 1
        ends_with_1 = 9 * (10 ** (n - 2))

        # Count overlap: numbers that both start and end with 1
        # first and last fixed as 1, middle n-2 digits arbitrary
        both = 10 ** (n - 2)

        return starts_with_1 + ends_with_1 - both

    except OverflowError as e:
        raise OverflowError(f"calculation overflowed for n={n}") from e
candidate = starts_one_ends


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(1) == 1
    assert candidate(2) == 18
    assert candidate(3) == 180
    assert candidate(4) == 1800
    assert candidate(5) == 18000

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
