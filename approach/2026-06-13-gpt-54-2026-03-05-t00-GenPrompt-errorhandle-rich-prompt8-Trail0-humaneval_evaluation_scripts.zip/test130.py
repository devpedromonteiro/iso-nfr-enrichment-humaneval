
import unittest
import re
import sys
import math
import copy


def tri(n):
    """Return the first n + 1 values of the Tribonacci sequence.

    Sequence definition:
    - tri(0) = 1
    - tri(1) = 3
    - tri(n) = 1 + n / 2, if n is even and n >= 2
    - tri(n) = tri(n - 1) + tri(n - 2) + tri(n + 1), if n is odd and n >= 3

    Args:
        n: Non-negative integer index.

    Returns:
        A list containing tri(0) through tri(n).

    Raises:
        TypeError: If n is not an integer.
        ValueError: If n is negative.
    """
    if isinstance(n, bool) or not isinstance(n, int):
        raise TypeError("n must be a non-negative integer")
    if n < 0:
        raise ValueError("n must be a non-negative integer")

    try:
        result = [0] * (n + 1)
        result[0] = 1

        if n >= 1:
            result[1] = 3

        for i in range(2, n + 1):
            if i % 2 == 0:
                result[i] = 1 + i // 2
            else:
                # For odd i:
                # tri(i) = tri(i - 1) + tri(i - 2) + tri(i + 1)
                # and tri(i + 1) is even, so:
                # tri(i + 1) = 1 + (i + 1) / 2
                result[i] = result[i - 1] + result[i - 2] + 1 + ((i + 1) // 2)

        return result

    except MemoryError:
        # Re-raise specific critical exceptions without swallowing them.
        raise
candidate = tri


def check(candidate):

    # Check some simple cases
    
    assert candidate(3) == [1, 3, 2.0, 8.0]
    assert candidate(4) == [1, 3, 2.0, 8.0, 3.0]
    assert candidate(5) == [1, 3, 2.0, 8.0, 3.0, 15.0]
    assert candidate(6) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0]
    assert candidate(7) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0]
    assert candidate(8) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0]
    assert candidate(9) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0]
    assert candidate(20) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0, 6.0, 48.0, 7.0, 63.0, 8.0, 80.0, 9.0, 99.0, 10.0, 120.0, 11.0]

    # Check some edge cases that are easy to work out by hand.
    assert candidate(0) == [1]
    assert candidate(1) == [1, 3]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
