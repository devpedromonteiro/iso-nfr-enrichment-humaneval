
import unittest
import re
import sys
import math
import copy



def is_palindrome(string: str) -> bool:
    """ Test if given string is a palindrome """
    return string == string[::-1]


def is_palindrome(string: str) -> bool:
    """Test if given string is a palindrome.

    Raises:
        TypeError: If string is not a str.
    """
    if not isinstance(string, str):
        raise TypeError(
            f"is_palindrome expected 'str', got '{type(string).__name__}'"
        )
    return string == string[::-1]


def make_palindrome(string: str) -> str:
    """Find the shortest palindrome that begins with a supplied string.

    Algorithm:
    - Find the longest suffix of the supplied string that is a palindrome.
    - Append to the end of the string the reverse of the prefix that comes
      before that palindromic suffix.

    Args:
        string: Input string.

    Returns:
        The shortest palindrome starting with the supplied string.

    Raises:
        TypeError: If string is not a str.

    >>> make_palindrome('')
    ''
    >>> make_palindrome('cat')
    'catac'
    >>> make_palindrome('cata')
    'catac'
    """
    if not isinstance(string, str):
        raise TypeError(
            f"make_palindrome expected 'str', got '{type(string).__name__}'"
        )

    if string == "":
        return ""

    for i in range(len(string)):
        suffix = string[i:]
        if is_palindrome(suffix):
            prefix = string[:i]
            return string + prefix[::-1]

    # This path should never be reached because any 1-character suffix
    # is a palindrome, but keep an explicit failure mode for robustness.
    raise RuntimeError("Failed to construct palindrome from valid input")
candidate = make_palindrome




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == ''
    assert candidate('x') == 'x'
    assert candidate('xyz') == 'xyzyx'
    assert candidate('xyx') == 'xyx'
    assert candidate('jerry') == 'jerryrrej'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
