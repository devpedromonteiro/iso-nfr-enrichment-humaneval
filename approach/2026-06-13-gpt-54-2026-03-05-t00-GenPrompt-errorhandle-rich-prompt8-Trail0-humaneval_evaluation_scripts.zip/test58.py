
import unittest
import re
import sys
import math
import copy



def common(l1: list, l2: list):
    """Return sorted unique common elements for two lists.

    >>> common([1, 4, 3, 34, 653, 2, 5], [5, 7, 1, 5, 9, 653, 121])
    [1, 5, 653]
    >>> common([5, 3, 2, 8], [3, 2])
    [2, 3]
    """
    if not isinstance(l1, list):
        raise TypeError(f"l1 must be a list, got {type(l1).__name__}")
    if not isinstance(l2, list):
        raise TypeError(f"l2 must be a list, got {type(l2).__name__}")

    try:
        return sorted(set(l1).intersection(l2))
    except TypeError as exc:
        raise TypeError(
            "Both lists must contain hashable and mutually comparable elements"
        ) from exc
candidate = common




METADATA = {}


def check(candidate):
    assert candidate([1, 4, 3, 34, 653, 2, 5], [5, 7, 1, 5, 9, 653, 121]) == [1, 5, 653]
    assert candidate([5, 3, 2, 8], [3, 2]) == [2, 3]
    assert candidate([4, 3, 2, 8], [3, 2, 4]) == [2, 3, 4]
    assert candidate([4, 3, 2, 8], []) == []



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
