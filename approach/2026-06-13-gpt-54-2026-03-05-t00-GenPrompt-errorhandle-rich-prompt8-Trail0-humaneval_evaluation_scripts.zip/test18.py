
import unittest
import re
import sys
import math
import copy



def how_many_times(string: str, substring: str) -> int:
    """Find how many times a given substring occurs in the original string.

    Overlapping matches are counted.

    Args:
        string: The string to search in.
        substring: The substring to search for.

    Returns:
        The number of occurrences of substring in string, including overlaps.

    Raises:
        TypeError: If either argument is not a string.
        ValueError: If substring is empty.

    >>> how_many_times('', 'a')
    0
    >>> how_many_times('aaa', 'a')
    3
    >>> how_many_times('aaaa', 'aa')
    3
    """
    if not isinstance(string, str):
        raise TypeError(f"string must be of type str, got {type(string).__name__}")
    if not isinstance(substring, str):
        raise TypeError(f"substring must be of type str, got {type(substring).__name__}")
    if substring == "":
        raise ValueError("substring must not be empty")

    count = 0
    sub_len = len(substring)

    for i in range(len(string) - sub_len + 1):
        if string[i:i + sub_len] == substring:
            count += 1

    return count
candidate = how_many_times




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('', 'x') == 0
    assert candidate('xyxyxyx', 'x') == 4
    assert candidate('cacacacac', 'cac') == 4
    assert candidate('john doe', 'john') == 1


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
