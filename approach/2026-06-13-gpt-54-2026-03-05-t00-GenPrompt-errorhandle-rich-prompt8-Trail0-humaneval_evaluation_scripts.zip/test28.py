
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def concatenate(strings: List[str]) -> str:
    """Concatenate list of strings into a single string.

    Validates input explicitly and raises specific exceptions for invalid
    arguments.

    >>> concatenate([])
    ''
    >>> concatenate(['a', 'b', 'c'])
    'abc'
    """
    if strings is None:
        raise TypeError("strings must be a list of strings, got None")

    if not isinstance(strings, list):
        raise TypeError(f"strings must be of type list, got {type(strings).__name__}")

    for i, value in enumerate(strings):
        if not isinstance(value, str):
            raise TypeError(
                f"all elements must be of type str; element at index {i} "
                f"is {type(value).__name__}"
            )

    return "".join(strings)
candidate = concatenate




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == ''
    assert candidate(['x', 'y', 'z']) == 'xyz'
    assert candidate(['x', 'y', 'z', 'w', 'k']) == 'xyzwk'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
