
import unittest
import re
import sys
import math
import copy


def add(lst):
    """Given a non-empty list of integers lst, add the even elements at odd indices.

    Examples:
        add([4, 2, 6, 7]) ==> 2
    """
    if not isinstance(lst, list):
        raise TypeError("lst must be a list")
    if not lst:
        raise ValueError("lst must be a non-empty list")

    total = 0
    for i, value in enumerate(lst):
        if not isinstance(value, int):
            raise TypeError(f"all elements must be integers, got {type(value).__name__} at index {i}")
        if i % 2 == 1 and value % 2 == 0:
            total += value

    return total
candidate = add


def check(candidate):

    # Check some simple cases
    assert candidate([4, 88]) == 88
    assert candidate([4, 5, 6, 7, 2, 122]) == 122
    assert candidate([4, 0, 6, 7]) == 0
    assert candidate([4, 4, 6, 8]) == 12

    # Check some edge cases that are easy to work out by hand.
    


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
