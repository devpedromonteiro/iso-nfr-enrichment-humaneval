
import unittest
import re
import sys
import math
import copy



def incr_list(l: list):
    """Return list with elements incremented by 1.

    >>> incr_list([1, 2, 3])
    [2, 3, 4]
    >>> incr_list([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [6, 4, 6, 3, 4, 4, 10, 1, 124]
    """
    if not isinstance(l, list):
        raise TypeError(f"Expected list, got {type(l).__name__}")

    result = []
    for i, item in enumerate(l):
        if not isinstance(item, (int, float)):
            raise TypeError(
                f"All elements must be numeric; invalid element at index {i}: "
                f"{item!r} ({type(item).__name__})"
            )
        result.append(item + 1)

    return result
candidate = incr_list




METADATA = {}


def check(candidate):
    assert candidate([]) == []
    assert candidate([3, 2, 1]) == [4, 3, 2]
    assert candidate([5, 2, 5, 2, 3, 3, 9, 0, 123]) == [6, 3, 6, 3, 4, 4, 10, 1, 124]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
