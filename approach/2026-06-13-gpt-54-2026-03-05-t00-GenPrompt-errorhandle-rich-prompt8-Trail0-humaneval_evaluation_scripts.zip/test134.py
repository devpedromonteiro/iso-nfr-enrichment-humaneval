
import unittest
import re
import sys
import math
import copy


def check_if_last_char_is_a_letter(txt):
    '''
    Create a function that returns True if the last character
    of a given string is an alphabetical character and is not
    a part of a word, and False otherwise.
    Note: "word" is a group of characters separated by space.

    Examples:
    check_if_last_char_is_a_letter("apple pie") â False
    check_if_last_char_is_a_letter("apple pi e") â True
    check_if_last_char_is_a_letter("apple pi e ") â False
    check_if_last_char_is_a_letter("") â False 
    '''
    if txt is None:
        raise TypeError("txt must be a string, got None")
    if not isinstance(txt, str):
        raise TypeError(f"txt must be a string, got {type(txt).__name__}")

    if txt == "":
        return False

    # If the string ends with a space, the last character is not a letter.
    if txt[-1] == " ":
        return False

    # Last character must be alphabetical.
    if not txt[-1].isalpha():
        return False

    # It is not part of a word only if it is the only character
    # in the last space-separated token.
    parts = txt.split(" ")
    last_token = parts[-1]

    return len(last_token) == 1 and last_token.isalpha()
candidate = check_if_last_char_is_a_letter


def check(candidate):

    # Check some simple cases
    assert candidate("apple") == False
    assert candidate("apple pi e") == True
    assert candidate("eeeee") == False
    assert candidate("A") == True
    assert candidate("Pumpkin pie ") == False
    assert candidate("Pumpkin pie 1") == False
    assert candidate("") == False
    assert candidate("eeeee e ") == False
    assert candidate("apple pie") == False
    assert candidate("apple pi e ") == False

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
