
import unittest
import re
import sys
import math
import copy



def unique(l: list):
    """Return sorted unique elements in a list.

    >>> unique([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [0, 2, 3, 5, 9, 123]
    """
    if not isinstance(l, list):
        raise TypeError(f"unique() expected a list, got {type(l).__name__}")

    try:
        return sorted(set(l))
    except TypeError as e:
        raise TypeError(
            "unique() requires all list elements to be hashable and mutually comparable for sorting"
        ) from e
candidate = unique




METADATA = {}


def check(candidate):
    assert candidate([5, 3, 5, 2, 3, 3, 9, 0, 123]) == [0, 2, 3, 5, 9, 123]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
