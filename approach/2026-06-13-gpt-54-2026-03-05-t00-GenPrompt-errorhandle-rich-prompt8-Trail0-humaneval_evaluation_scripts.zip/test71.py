
import unittest
import re
import sys
import math
import copy


import math


def triangle_area(a, b, c):
    '''
    Given the lengths of the three sides of a triangle. Return the area of
    the triangle rounded to 2 decimal points if the three sides form a valid triangle. 
    Otherwise return -1
    Three sides make a valid triangle when the sum of any two sides is greater 
    than the third side.
    Example:
    triangle_area(3, 4, 5) == 6.00
    triangle_area(1, 2, 10) == -1
    '''
    # Validate presence/type explicitly
    for name, value in (("a", a), ("b", b), ("c", c)):
        if value is None:
            raise ValueError(f"Side '{name}' cannot be None.")
        if not isinstance(value, (int, float)):
            raise TypeError(f"Side '{name}' must be a number, got {type(value).__name__}.")
        if value <= 0:
            raise ValueError(f"Side '{name}' must be greater than 0.")

    # Triangle inequality check
    if a + b <= c or a + c <= b or b + c <= a:
        return -1

    # Heron's formula
    s = (a + b + c) / 2
    area_term = s * (s - a) * (s - b) * (s - c)

    # Defensive check against floating-point edge cases
    if area_term < 0:
        raise ArithmeticError("Computed invalid area term for triangle.")

    return round(math.sqrt(area_term), 2)
candidate = triangle_area


def check(candidate):

    # Check some simple cases
    assert candidate(3, 4, 5) == 6.00, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(1, 2, 10) == -1
    assert candidate(4, 8, 5) == 8.18
    assert candidate(2, 2, 2) == 1.73
    assert candidate(1, 2, 3) == -1
    assert candidate(10, 5, 7) == 16.25
    assert candidate(2, 6, 3) == -1

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1, 1, 1) == 0.43, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate(2, 2, 10) == -1



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
