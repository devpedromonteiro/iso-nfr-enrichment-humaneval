
import unittest
import re
import sys
import math
import copy


def is_multiply_prime(a):
    """Return True if `a` is the product of exactly 3 prime numbers, else False.

    A prime factor may repeat, so values like 8 = 2 * 2 * 2 return True.

    Constraints handled:
    - Input must be an integer.
    - Negative numbers, 0, and 1 are valid inputs but return False.
    - Invalid argument types raise specific exceptions.

    Examples:
        is_multiply_prime(30) -> True   # 2 * 3 * 5
        is_multiply_prime(8)  -> True   # 2 * 2 * 2
        is_multiply_prime(12) -> True   # 2 * 2 * 3
        is_multiply_prime(16) -> False  # 2 * 2 * 2 * 2
    """
    if isinstance(a, bool):
        raise TypeError("Input must be an integer, not bool.")
    if not isinstance(a, int):
        raise TypeError("Input must be an integer.")
    if a < 0:
        raise ValueError("Input must be a non-negative integer.")
    if a < 2:
        return False

    def is_prime(n):
        if n < 2:
            return False
        for i in range(2, int(n ** 0.5) + 1):
            if n % i == 0:
                return False
        return True

    prime_factors_count = 0
    remaining = a

    for i in range(2, a + 1):
        while remaining % i == 0:
            if not is_prime(i):
                return False
            prime_factors_count += 1
            remaining //= i
            if prime_factors_count > 3:
                return False
        if remaining == 1:
            break

    return prime_factors_count == 3
candidate = is_multiply_prime


def check(candidate):

    assert candidate(5) == False
    assert candidate(30) == True
    assert candidate(8) == True
    assert candidate(10) == False
    assert candidate(125) == True
    assert candidate(3 * 5 * 7) == True
    assert candidate(3 * 6 * 7) == False
    assert candidate(9 * 9 * 9) == False
    assert candidate(11 * 9 * 9) == False
    assert candidate(11 * 13 * 7) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
