
import unittest
import re
import sys
import math
import copy


def count_nums(arr):
    """
    Return the number of integers whose signed digit sum is greater than 0.

    A negative number contributes a negative first digit and positive remaining
    digits, e.g. -123 -> -1 + 2 + 3 = 4.

    >>> count_nums([]) == 0
    True
    >>> count_nums([-1, 11, -11]) == 1
    True
    >>> count_nums([1, 1, 2]) == 3
    True
    """
    if arr is None:
        raise TypeError("arr must be an iterable of integers, got None")

    if not isinstance(arr, (list, tuple)):
        raise TypeError("arr must be a list or tuple of integers")

    count = 0

    for i, num in enumerate(arr):
        if not isinstance(num, int):
            raise TypeError(f"arr[{i}] must be an integer, got {type(num).__name__}")

        digit_sum = _signed_digit_sum(num)
        if digit_sum > 0:
            count += 1

    return count


def _signed_digit_sum(num):
    """Compute the signed digit sum for an integer."""
    if num >= 0:
        return sum(int(ch) for ch in str(num))

    s = str(num)
    return -int(s[1]) + sum(int(ch) for ch in s[2:])
candidate = count_nums


def check(candidate):

    # Check some simple cases
    assert candidate([]) == 0
    assert candidate([-1, -2, 0]) == 0
    assert candidate([1, 1, 2, -2, 3, 4, 5]) == 6
    assert candidate([1, 6, 9, -6, 0, 1, 5]) == 5
    assert candidate([1, 100, 98, -7, 1, -1]) == 4
    assert candidate([12, 23, 34, -45, -56, 0]) == 5
    assert candidate([-0, 1**0]) == 1
    assert candidate([1]) == 1

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
