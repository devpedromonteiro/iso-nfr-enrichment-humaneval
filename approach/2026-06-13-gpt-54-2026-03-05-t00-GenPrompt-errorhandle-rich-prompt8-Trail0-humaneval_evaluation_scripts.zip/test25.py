
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def factorize(n: int) -> List[int]:
    """Return list of prime factors of given integer in ascending order.

    Each factor appears as many times as it occurs in the prime factorization.

    >>> factorize(8)
    [2, 2, 2]
    >>> factorize(25)
    [5, 5]
    >>> factorize(70)
    [2, 5, 7]
    """
    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if isinstance(n, bool):
        raise TypeError("n must be an integer, not bool")
    if n <= 0:
        raise ValueError("n must be a positive integer greater than 0")
    if n == 1:
        return []

    factors: List[int] = []
    remainder = n

    while remainder % 2 == 0:
        factors.append(2)
        remainder //= 2

    divisor = 3
    while divisor * divisor <= remainder:
        while remainder % divisor == 0:
            factors.append(divisor)
            remainder //= divisor
        divisor += 2

    if remainder > 1:
        factors.append(remainder)

    product = 1
    for factor in factors:
        product *= factor
    if product != n:
        raise ArithmeticError("factorization failed: product of factors does not match input")

    return factors
candidate = factorize




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(2) == [2]
    assert candidate(4) == [2, 2]
    assert candidate(8) == [2, 2, 2]
    assert candidate(3 * 19) == [3, 19]
    assert candidate(3 * 19 * 3 * 19) == [3, 3, 19, 19]
    assert candidate(3 * 19 * 3 * 19 * 3 * 19) == [3, 3, 3, 19, 19, 19]
    assert candidate(3 * 19 * 19 * 19) == [3, 19, 19, 19]
    assert candidate(3 * 2 * 3) == [2, 3, 3]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
