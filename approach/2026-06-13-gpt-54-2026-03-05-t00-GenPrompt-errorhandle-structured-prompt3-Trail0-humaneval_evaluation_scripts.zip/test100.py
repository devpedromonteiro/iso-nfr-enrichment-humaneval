
import unittest
import re
import sys
import math
import copy


def make_a_pile(n):
    """
    Given a positive integer n, make a pile of n levels of stones.

    The first level has n stones.
    Each next level has the next number with the same parity as n:
      - odd sequence if n is odd
      - even sequence if n is even

    Args:
        n: A positive integer.

    Returns:
        A list where the element at index i is the number of stones
        in level i + 1.

    Raises:
        TypeError: If n is not an integer.
        ValueError: If n is not a positive integer.

    Examples:
        >>> make_a_pile(3)
        [3, 5, 7]
        >>> make_a_pile(4)
        [4, 6, 8, 10]
    """
    if isinstance(n, bool) or not isinstance(n, int):
        raise TypeError("n must be an integer")
    if n <= 0:
        raise ValueError("n must be a positive integer")

    try:
        return [n + 2 * i for i in range(n)]
    except OverflowError:
        # Explicitly re-raise specific exceptions without swallowing them.
        raise
candidate = make_a_pile


def check(candidate):

    # Check some simple cases
    assert candidate(3) == [3, 5, 7], "Test 3"
    assert candidate(4) == [4,6,8,10], "Test 4"
    assert candidate(5) == [5, 7, 9, 11, 13]
    assert candidate(6) == [6, 8, 10, 12, 14, 16]
    assert candidate(8) == [8, 10, 12, 14, 16, 18, 20, 22]

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
