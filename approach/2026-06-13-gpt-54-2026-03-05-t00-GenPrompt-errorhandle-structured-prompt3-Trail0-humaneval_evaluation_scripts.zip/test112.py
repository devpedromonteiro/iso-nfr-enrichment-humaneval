
import unittest
import re
import sys
import math
import copy


def reverse_delete(s, c):
    """Remove from s every character that appears in c, then check whether the result is a palindrome.

    Returns:
        tuple[str, bool]: (filtered_string, is_palindrome)

    Raises:
        TypeError: If s or c is not a string.
        ValueError: If s or c is None.
    """
    if s is None or c is None:
        raise ValueError("Inputs 's' and 'c' must not be None.")

    if not isinstance(s, str):
        raise TypeError(f"Input 's' must be of type str, got {type(s).__name__}.")
    if not isinstance(c, str):
        raise TypeError(f"Input 'c' must be of type str, got {type(c).__name__}.")

    chars_to_delete = set(c)
    result = "".join(ch for ch in s if ch not in chars_to_delete)
    is_palindrome = result == result[::-1]

    return result, is_palindrome
candidate = reverse_delete


def check(candidate):

    assert candidate("abcde","ae") == ('bcd',False)
    assert candidate("abcdef", "b") == ('acdef',False)
    assert candidate("abcdedcba","ab") == ('cdedc',True)
    assert candidate("dwik","w") == ('dik',False)
    assert candidate("a","a") == ('',True)
    assert candidate("abcdedcba","") == ('abcdedcba',True)
    assert candidate("abcdedcba","v") == ('abcdedcba',True)
    assert candidate("vabba","v") == ('abba',True)
    assert candidate("mamma", "mia") == ("", True)


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
