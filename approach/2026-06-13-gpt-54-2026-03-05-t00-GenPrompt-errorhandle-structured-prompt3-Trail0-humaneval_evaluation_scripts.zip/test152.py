
import unittest
import re
import sys
import math
import copy


def compare(game, guess):
    """Return per-match absolute differences between actual scores and guesses.

    Args:
        game: Sequence of numeric match results.
        guess: Sequence of numeric guessed results.

    Returns:
        A list of absolute differences for each corresponding pair.

    Raises:
        TypeError: If either argument is not a list or tuple, or contains non-numeric values.
        ValueError: If the input sequences do not have the same length.
    """
    if not isinstance(game, (list, tuple)):
        raise TypeError("game must be a list or tuple of numbers")
    if not isinstance(guess, (list, tuple)):
        raise TypeError("guess must be a list or tuple of numbers")

    if len(game) != len(guess):
        raise ValueError("game and guess must have the same length")

    differences = []

    for index, (actual, predicted) in enumerate(zip(game, guess)):
        if not isinstance(actual, (int, float)) or isinstance(actual, bool):
            raise TypeError(f"game[{index}] must be a number")
        if not isinstance(predicted, (int, float)) or isinstance(predicted, bool):
            raise TypeError(f"guess[{index}] must be a number")

        differences.append(abs(actual - predicted))

    return differences
candidate = compare


def check(candidate):

    # Check some simple cases
    assert candidate([1,2,3,4,5,1],[1,2,3,4,2,-2])==[0,0,0,0,3,3], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([0,0,0,0,0,0],[0,0,0,0,0,0])==[0,0,0,0,0,0], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,2,3],[-1,-2,-3])==[2,4,6], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,2,3,5],[-1,2,3,4])==[2,0,0,1], "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
