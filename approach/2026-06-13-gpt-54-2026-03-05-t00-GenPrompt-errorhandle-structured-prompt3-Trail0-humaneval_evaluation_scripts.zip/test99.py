
import unittest
import re
import sys
import math
import copy


from decimal import Decimal, InvalidOperation, ROUND_HALF_UP


def closest_integer(value):
    '''
    Create a function that takes a value (string) representing a number
    and returns the closest integer to it. If the number is equidistant
    from two integers, round it away from zero.

    Examples
    >>> closest_integer("10")
    10
    >>> closest_integer("15.3")
    15

    Note:
    Rounding away from zero means that if the given number is equidistant
    from two integers, the one you should return is the one that is the
    farthest from zero. For example closest_integer("14.5") should
    return 15 and closest_integer("-14.5") should return -15.
    '''
    if not isinstance(value, str):
        raise TypeError("value must be a string representing a number")

    stripped = value.strip()
    if not stripped:
        raise ValueError("value must not be empty")

    try:
        number = Decimal(stripped)
    except InvalidOperation as exc:
        raise ValueError(f"invalid numeric string: {value!r}") from exc

    if not number.is_finite():
        raise ValueError("value must represent a finite number")

    rounded = number.quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    return int(rounded)
candidate = closest_integer


def check(candidate):

    # Check some simple cases
    assert candidate("10") == 10, "Test 1"
    assert candidate("14.5") == 15, "Test 2"
    assert candidate("-15.5") == -16, "Test 3"
    assert candidate("15.3") == 15, "Test 3"

    # Check some edge cases that are easy to work out by hand.
    assert candidate("0") == 0, "Test 0"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
