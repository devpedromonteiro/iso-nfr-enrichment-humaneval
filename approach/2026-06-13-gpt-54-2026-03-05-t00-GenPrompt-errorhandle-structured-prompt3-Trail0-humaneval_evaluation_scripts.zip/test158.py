
import unittest
import re
import sys
import math
import copy


def find_max(words):
    """Return the word with the highest number of unique characters.

    If multiple words have the same maximum number of unique characters,
    return the lexicographically smallest one.

    Examples:
        find_max(["name", "of", "string"]) == "string"
        find_max(["name", "enam", "game"]) == "enam"
        find_max(["aaaaaaa", "bb", "cc"]) == "aaaaaaa"
    """
    if words is None:
        raise TypeError("words must be a list of strings, got None")

    if not isinstance(words, list):
        raise TypeError(f"words must be a list of strings, got {type(words).__name__}")

    if not words:
        raise ValueError("words must not be empty")

    max_word = None
    max_unique_count = -1

    for index, word in enumerate(words):
        if not isinstance(word, str):
            raise TypeError(
                f"all items in words must be strings; item at index {index} "
                f"is {type(word).__name__}"
            )

        unique_count = len(set(word))

        if unique_count > max_unique_count:
            max_unique_count = unique_count
            max_word = word
        elif unique_count == max_unique_count:
            if word < max_word:
                max_word = word

    return max_word
candidate = find_max


def check(candidate):

    # Check some simple cases
    assert (candidate(["name", "of", "string"]) == "string"), "t1"
    assert (candidate(["name", "enam", "game"]) == "enam"), 't2'
    assert (candidate(["aaaaaaa", "bb", "cc"]) == "aaaaaaa"), 't3'
    assert (candidate(["abc", "cba"]) == "abc"), 't4'
    assert (candidate(["play", "this", "game", "of","footbott"]) == "footbott"), 't5'
    assert (candidate(["we", "are", "gonna", "rock"]) == "gonna"), 't6'
    assert (candidate(["we", "are", "a", "mad", "nation"]) == "nation"), 't7'
    assert (candidate(["this", "is", "a", "prrk"]) == "this"), 't8'

    # Check some edge cases that are easy to work out by hand.
    assert (candidate(["b"]) == "b"), 't9'
    assert (candidate(["play", "play", "play"]) == "play"), 't10'



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
