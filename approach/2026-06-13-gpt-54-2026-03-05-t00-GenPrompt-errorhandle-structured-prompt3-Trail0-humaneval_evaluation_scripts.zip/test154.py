
import unittest
import re
import sys
import math
import copy


def cycpattern_check(a, b):
    """Return True if ``b`` or any cyclic rotation of ``b`` is a substring of ``a``.

    Examples:
        cycpattern_check("abcd", "abd") -> False
        cycpattern_check("hello", "ell") -> True
        cycpattern_check("whassup", "psus") -> False
        cycpattern_check("abab", "baa") -> True
        cycpattern_check("efef", "eeff") -> False
        cycpattern_check("himenss", "simen") -> True

    Error handling:
        - Raises TypeError if either argument is not a string.
        - Raises ValueError if either argument is an empty string.
    """
    if not isinstance(a, str):
        raise TypeError(f"Expected 'a' to be str, got {type(a).__name__}")
    if not isinstance(b, str):
        raise TypeError(f"Expected 'b' to be str, got {type(b).__name__}")

    if a == "":
        raise ValueError("Argument 'a' must not be empty")
    if b == "":
        raise ValueError("Argument 'b' must not be empty")

    # If b is longer than a, no rotation can be a substring of a.
    if len(b) > len(a):
        return False

    # Generate all rotations of b and check whether any is a substring of a.
    for i in range(len(b)):
        rotated = b[i:] + b[:i]
        if rotated in a:
            return True

    return False
candidate = cycpattern_check


def check(candidate):

    # Check some simple cases
    #assert True, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    #assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert  candidate("xyzw","xyw") == False , "test #0"
    assert  candidate("yello","ell") == True , "test #1"
    assert  candidate("whattup","ptut") == False , "test #2"
    assert  candidate("efef","fee") == True , "test #3"
    assert  candidate("abab","aabb") == False , "test #4"
    assert  candidate("winemtt","tinem") == True , "test #5"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
