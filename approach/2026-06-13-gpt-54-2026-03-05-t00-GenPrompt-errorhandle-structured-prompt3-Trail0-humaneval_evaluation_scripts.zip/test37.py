
import unittest
import re
import sys
import math
import copy



def sort_even(l: list):
    """Return a copy of ``l`` where values at even indices are sorted, while
    values at odd indices remain in their original positions.

    Even indices are interpreted using Python's zero-based indexing:
    0, 2, 4, ...

    Args:
        l: A list whose even-indexed elements should be sorted.

    Returns:
        A new list with sorted even-indexed elements.

    Raises:
        TypeError: If ``l`` is not a list.
        ValueError: If the even-indexed elements cannot be mutually compared
            for sorting.

    Examples:
        >>> sort_even([1, 2, 3])
        [1, 2, 3]
        >>> sort_even([5, 6, 3, 4])
        [3, 6, 5, 4]
    """
    if not isinstance(l, list):
        raise TypeError(f"sort_even expected a list, got {type(l).__name__}")

    result = list(l)  # work on a copy to avoid leaving input in a modified state

    even_values = result[::2]
    try:
        even_values = sorted(even_values)
    except TypeError as exc:
        raise ValueError(
            "even-indexed elements must be mutually comparable for sorting"
        ) from exc

    result[::2] = even_values
    return result
candidate = sort_even




METADATA = {}


def check(candidate):
    assert tuple(candidate([1, 2, 3])) == tuple([1, 2, 3])
    assert tuple(candidate([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])) == tuple([-10, 3, -5, 2, -3, 3, 5, 0, 9, 1, 123])
    assert tuple(candidate([5, 8, -12, 4, 23, 2, 3, 11, 12, -10])) == tuple([-12, 8, 3, 4, 5, 2, 12, 11, 23, -10])



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
