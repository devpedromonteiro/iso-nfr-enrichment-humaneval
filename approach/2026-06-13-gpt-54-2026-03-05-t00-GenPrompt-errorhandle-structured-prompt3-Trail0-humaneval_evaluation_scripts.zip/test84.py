
import unittest
import re
import sys
import math
import copy


def solve(N):
    """Given a non-negative integer N, return the sum of its decimal digits as a binary string.

    Examples:
        solve(1000) -> "1"
        solve(150)  -> "110"
        solve(147)  -> "1100"

    Args:
        N: An integer such that 0 <= N <= 10000.

    Returns:
        A string representing the binary form of the sum of N's decimal digits.

    Raises:
        TypeError: If N is not an integer.
        ValueError: If N is outside the allowed range [0, 10000].
    """
    if isinstance(N, bool) or not isinstance(N, int):
        raise TypeError("N must be an integer.")
    if N < 0 or N > 10000:
        raise ValueError("N must be between 0 and 10000 inclusive.")

    digit_sum = sum(int(digit) for digit in str(N))
    return bin(digit_sum)[2:]
candidate = solve


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(1000) == "1", "Error"
    assert candidate(150) == "110", "Error"
    assert candidate(147) == "1100", "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate(333) == "1001", "Error"
    assert candidate(963) == "10010", "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
