
import unittest
import re
import sys
import math
import copy



def count_distinct_characters(string: str) -> int:
    """Given a string, return the number of distinct characters, case-insensitively.

    >>> count_distinct_characters('xyzXYZ')
    3
    >>> count_distinct_characters('Jerry')
    4
    """
    if not isinstance(string, str):
        raise TypeError(
            f"count_distinct_characters expected a string, got {type(string).__name__}"
        )

    try:
        return len(set(string.lower()))
    except AttributeError as exc:
        raise ValueError("Unable to process the provided string input") from exc
candidate = count_distinct_characters




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == 0
    assert candidate('abcde') == 5
    assert candidate('abcde' + 'cade' + 'CADE') == 5
    assert candidate('aaaaAAAAaaaa') == 1
    assert candidate('Jerry jERRY JeRRRY') == 5


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
