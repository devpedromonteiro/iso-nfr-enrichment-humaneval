
import unittest
import re
import sys
import math
import copy


def specialFilter(nums):
    """Return the count of numbers > 10 whose first and last digits are odd.

    Args:
        nums: An iterable of integers.

    Returns:
        int: Number of elements satisfying the condition.

    Raises:
        TypeError: If nums is not iterable or contains non-integer elements.
        ValueError: If nums is None.
    """
    if nums is None:
        raise ValueError("nums cannot be None")

    try:
        iterator = iter(nums)
    except TypeError as exc:
        raise TypeError("nums must be an iterable of integers") from exc

    odd_digits = {"1", "3", "5", "7", "9"}
    count = 0

    for num in iterator:
        if not isinstance(num, int):
            raise TypeError(f"all elements must be integers, got {type(num).__name__}")

        if num > 10:
            num_str = str(abs(num))
            if num_str[0] in odd_digits and num_str[-1] in odd_digits:
                count += 1

    return count
candidate = specialFilter


def check(candidate):

    # Check some simple cases
    assert candidate([5, -2, 1, -5]) == 0  
    assert candidate([15, -73, 14, -15]) == 1
    assert candidate([33, -2, -3, 45, 21, 109]) == 2
    assert candidate([43, -12, 93, 125, 121, 109]) == 4
    assert candidate([71, -2, -33, 75, 21, 19]) == 3


    # Check some edge cases that are easy to work out by hand.
    assert candidate([1]) == 0              
    assert candidate([]) == 0                   



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
