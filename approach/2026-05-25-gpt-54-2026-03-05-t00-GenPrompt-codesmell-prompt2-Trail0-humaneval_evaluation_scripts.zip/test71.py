
import unittest
import re
import sys
import math
import copy


import math


def triangle_area(a, b, c):
    """
    Given the lengths of the three sides of a triangle, return the area
    rounded to 2 decimal places if the sides form a valid triangle.
    Otherwise, return -1.

    A triangle is valid if the sum of any two sides is greater than the third.
    """
    sides = sorted([a, b, c])

    if sides[0] + sides[1] <= sides[2]:
        return -1

    s = sum(sides) / 2
    area = math.sqrt(s * (s - sides[0]) * (s - sides[1]) * (s - sides[2]))
    return round(area, 2)
candidate = triangle_area


def check(candidate):

    # Check some simple cases
    assert candidate(3, 4, 5) == 6.00, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(1, 2, 10) == -1
    assert candidate(4, 8, 5) == 8.18
    assert candidate(2, 2, 2) == 1.73
    assert candidate(1, 2, 3) == -1
    assert candidate(10, 5, 7) == 16.25
    assert candidate(2, 6, 3) == -1

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1, 1, 1) == 0.43, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate(2, 2, 10) == -1



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
