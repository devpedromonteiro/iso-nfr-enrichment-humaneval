
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    Return the number of triples (a[i], a[j], a[k]) with i < j < k such that
    a[i] + a[j] + a[k] is divisible by 3, where:

        a[i] = i*i - i + 1   for 1 <= i <= n

    Example:
        n = 5
        a = [1, 3, 7, 13, 21]
        Valid triple count = 1
    """
    if n < 3:
        return 0

    # For i mod 3:
    # i = 0 -> a[i] = i^2 - i + 1 â¡ 1 (mod 3)
    # i = 1 -> a[i] = i^2 - i + 1 â¡ 1 (mod 3)
    # i = 2 -> a[i] = i^2 - i + 1 â¡ 0 (mod 3)
    #
    # So values in a are only congruent to 0 or 1 modulo 3.
    # A triple sum is divisible by 3 only in these cases:
    #   0 + 0 + 0
    #   1 + 1 + 1

    count_mod_0 = n // 3                 # indices i â¡ 2 (mod 3)
    count_mod_1 = n - count_mod_0        # remaining indices

    def comb3(x):
        return x * (x - 1) * (x - 2) // 6 if x >= 3 else 0

    return comb3(count_mod_0) + comb3(count_mod_1)
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
