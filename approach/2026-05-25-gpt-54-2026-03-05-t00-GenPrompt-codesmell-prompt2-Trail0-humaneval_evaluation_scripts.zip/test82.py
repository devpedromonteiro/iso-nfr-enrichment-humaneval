
import unittest
import re
import sys
import math
import copy


def prime_length(string):
    """Return True if the string length is a prime number, else False.

    Examples:
        prime_length('Hello') == True
        prime_length('abcdcba') == True
        prime_length('kittens') == True
        prime_length('orange') == False
    """
    length = len(string)

    if length < 2:
        return False

    for divisor in range(2, int(length ** 0.5) + 1):
        if length % divisor == 0:
            return False

    return True
candidate = prime_length


def check(candidate):

    # Check some simple cases
    assert candidate('Hello') == True
    assert candidate('abcdcba') == True
    assert candidate('kittens') == True
    assert candidate('orange') == False
    assert candidate('wow') == True
    assert candidate('world') == True
    assert candidate('MadaM') == True
    assert candidate('Wow') == True
    assert candidate('') == False
    assert candidate('HI') == True
    assert candidate('go') == True
    assert candidate('gogo') == False
    assert candidate('aaaaaaaaaaaaaaa') == False

    # Check some edge cases that are easy to work out by hand.
    assert candidate('Madam') == True
    assert candidate('M') == False
    assert candidate('0') == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
