
import unittest
import re
import sys
import math
import copy


def prod_signs(arr):
    """
    Return the sum of absolute values multiplied by the product of signs.

    The sign of each number is:
    - 1 for positive numbers
    - -1 for negative numbers
    - 0 for zero

    If the array is empty, return None.

    Examples:
    >>> prod_signs([1, 2, 2, -4])
    -9
    >>> prod_signs([0, 1])
    0
    >>> prod_signs([])
    None
    """
    if not arr:
        return None

    magnitude_sum = sum(abs(x) for x in arr)

    if 0 in arr:
        return 0

    negative_count = sum(1 for x in arr if x < 0)
    sign_product = -1 if negative_count % 2 else 1

    return magnitude_sum * sign_product
candidate = prod_signs


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1, 2, 2, -4]) == -9
    assert candidate([0, 1]) == 0
    assert candidate([1, 1, 1, 2, 3, -1, 1]) == -10
    assert candidate([]) == None
    assert candidate([2, 4,1, 2, -1, -1, 9]) == 20
    assert candidate([-1, 1, -1, 1]) == 4
    assert candidate([-1, 1, 1, 1]) == -4
    assert candidate([-1, 1, 1, 0]) == 0

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
