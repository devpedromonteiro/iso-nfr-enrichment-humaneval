
import unittest
import re
import sys
import math
import copy


def is_multiply_prime(a):
    """Return True if a is the product of exactly 3 prime numbers, else False."""

    def is_prime(n):
        if n < 2:
            return False
        for i in range(2, int(n ** 0.5) + 1):
            if n % i == 0:
                return False
        return True

    for i in range(2, a):
        if not is_prime(i) or a % i != 0:
            continue
        for j in range(2, a):
            if not is_prime(j) or (a // i) % j != 0:
                continue
            k = a // (i * j)
            if i * j * k == a and is_prime(k):
                return True

    return False
candidate = is_multiply_prime


def check(candidate):

    assert candidate(5) == False
    assert candidate(30) == True
    assert candidate(8) == True
    assert candidate(10) == False
    assert candidate(125) == True
    assert candidate(3 * 5 * 7) == True
    assert candidate(3 * 6 * 7) == False
    assert candidate(9 * 9 * 9) == False
    assert candidate(11 * 9 * 9) == False
    assert candidate(11 * 13 * 7) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
