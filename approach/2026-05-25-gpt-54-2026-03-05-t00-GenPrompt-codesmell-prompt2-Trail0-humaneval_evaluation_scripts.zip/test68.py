
import unittest
import re
import sys
import math
import copy


def pluck(arr):
    """
    Given an array representing a branch of a tree with non-negative integer nodes,
    return [smallest_even_value, its_index].

    If multiple nodes have the same smallest even value, return the one with
    the smallest index.

    If there are no even values or the array is empty, return [].
    """
    for index, value in enumerate(arr):
        if value % 2 == 0:
            smallest_even = value
            smallest_index = index
            break
    else:
        return []

    for index in range(smallest_index + 1, len(arr)):
        value = arr[index]
        if value % 2 == 0 and value < smallest_even:
            smallest_even = value
            smallest_index = index

    return [smallest_even, smallest_index]
candidate = pluck


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([4,2,3]) == [2, 1], "Error"
    assert candidate([1,2,3]) == [2, 1], "Error"
    assert candidate([]) == [], "Error"
    assert candidate([5, 0, 3, 0, 4, 2]) == [0, 1], "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([1, 2, 3, 0, 5, 3]) == [0, 3], "Error"
    assert candidate([5, 4, 8, 4 ,8]) == [4, 1], "Error"
    assert candidate([7, 6, 7, 1]) == [6, 1], "Error"
    assert candidate([7, 9, 7, 1]) == [], "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
