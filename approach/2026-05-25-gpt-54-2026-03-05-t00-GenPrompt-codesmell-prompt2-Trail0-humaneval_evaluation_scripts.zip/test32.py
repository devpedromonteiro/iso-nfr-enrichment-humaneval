
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


def poly(coeffs: list[float], x: float) -> float:
    """
    Evaluate a polynomial with coefficients ``coeffs`` at point ``x``.

    The polynomial is:
        coeffs[0] + coeffs[1] * x + coeffs[2] * x^2 + ... + coeffs[n] * x^n
    """
    result = 0.0
    for coeff in reversed(coeffs):
        result = result * x + coeff
    return result


def find_zero(coeffs: list[float]) -> float:
    """
    Find one real zero of a polynomial.

    Assumptions:
    - ``coeffs`` contains an even number of coefficients
    - the highest non-zero coefficient is positive

    Under these assumptions, the polynomial has odd degree with positive
    leading coefficient, so it is guaranteed to have at least one real root.

    Returns one zero point, even if there are many.

    >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2)  # (x - 1)(x - 2)(x - 3)
    1.0
    """
    if not coeffs:
        raise ValueError("coeffs must not be empty")

    # Remove trailing zeros so the actual degree is correct.
    while len(coeffs) > 1 and coeffs[-1] == 0:
        coeffs = coeffs[:-1]

    if len(coeffs) % 2 != 0:
        raise ValueError("coeffs must contain an even number of coefficients")

    if coeffs[-1] <= 0:
        raise ValueError("highest non-zero coefficient must be positive")

    def f(x: float) -> float:
        return poly(coeffs, x)

    # Find an interval [left, right] with a sign change.
    left, right = -1.0, 1.0
    f_left, f_right = f(left), f(right)

    while f_left > 0:
        left *= 2
        f_left = f(left)

    while f_right < 0:
        right *= 2
        f_right = f(right)

    # Bisection method.
    tolerance = 1e-12
    while right - left > tolerance:
        mid = (left + right) / 2
        f_mid = f(mid)

        if f_mid == 0:
            return mid
        if f_mid < 0:
            left = mid
        else:
            right = mid

    return (left + right) / 2
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
