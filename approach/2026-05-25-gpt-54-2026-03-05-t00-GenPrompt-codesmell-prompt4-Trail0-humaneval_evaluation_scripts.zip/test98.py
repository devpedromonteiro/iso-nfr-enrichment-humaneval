
import unittest
import re
import sys
import math
import copy


def count_upper(s):
    """
    Count uppercase vowels located at even indices in a string.

    Args:
        s: Input string.

    Returns:
        The number of uppercase vowels ('A', 'E', 'I', 'O', 'U')
        that appear at even indices.

    Examples:
        >>> count_upper('aBCdEf')
        1
        >>> count_upper('abcdefg')
        0
        >>> count_upper('dBBE')
        0
    """
    uppercase_vowels = {"A", "E", "I", "O", "U"}
    return sum(1 for index, char in enumerate(s) if index % 2 == 0 and char in uppercase_vowels)
candidate = count_upper


def check(candidate):

    # Check some simple cases
    assert candidate('aBCdEf')  == 1
    assert candidate('abcdefg') == 0
    assert candidate('dBBE') == 0
    assert candidate('B')  == 0
    assert candidate('U')  == 1
    assert candidate('') == 0
    assert candidate('EEEE') == 2

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
