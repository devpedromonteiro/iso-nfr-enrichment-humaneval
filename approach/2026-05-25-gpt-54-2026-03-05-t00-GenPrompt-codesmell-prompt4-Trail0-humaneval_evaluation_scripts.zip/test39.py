
import unittest
import re
import sys
import math
import copy



def prime_fib(n: int) -> int:
    """
    Return the n-th Fibonacci number that is also prime.

    The sequence starts as:
    2, 3, 5, 13, 89, ...

    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """
    if not isinstance(n, int) or n < 1:
        raise ValueError("n must be a positive integer")

    def is_prime(value: int) -> bool:
        """Return True if value is a prime number, otherwise False."""
        if value < 2:
            return False
        if value == 2:
            return True
        if value % 2 == 0:
            return False

        divisor = 3
        while divisor * divisor <= value:
            if value % divisor == 0:
                return False
            divisor += 2
        return True

    count = 0
    previous, current = 0, 1

    while True:
        previous, current = current, previous + current
        if is_prime(current):
            count += 1
            if count == n:
                return current
candidate = prime_fib




METADATA = {}


def check(candidate):
    assert candidate(1) == 2
    assert candidate(2) == 3
    assert candidate(3) == 5
    assert candidate(4) == 13
    assert candidate(5) == 89
    assert candidate(6) == 233
    assert candidate(7) == 1597
    assert candidate(8) == 28657
    assert candidate(9) == 514229
    assert candidate(10) == 433494437



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
