
import unittest
import re
import sys
import math
import copy

from typing import List, Optional


from typing import List, Optional


def longest(strings: List[str]) -> Optional[str]:
    """Return the longest string in a list.

    If multiple strings share the maximum length, return the first one.
    Return None if the input list is empty.

    >>> longest([])
    >>> longest(['a', 'b', 'c'])
    'a'
    >>> longest(['a', 'bb', 'ccc'])
    'ccc'
    """
    if not strings:
        return None

    return max(strings, key=len)
candidate = longest




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == None
    assert candidate(['x', 'y', 'z']) == 'x'
    assert candidate(['x', 'yyy', 'zzzz', 'www', 'kkkk', 'abc']) == 'zzzz'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
