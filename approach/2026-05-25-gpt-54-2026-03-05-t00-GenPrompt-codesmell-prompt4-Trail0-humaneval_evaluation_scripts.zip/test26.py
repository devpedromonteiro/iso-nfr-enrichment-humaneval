
import unittest
import re
import sys
import math
import copy

from typing import List


from collections import Counter
from typing import List


def remove_duplicates(numbers: List[int]) -> List[int]:
    """Remove all values that appear more than once, preserving input order.

    Args:
        numbers: A list of integers.

    Returns:
        A new list containing only integers that occur exactly once in the
        original list, in their original order.

    Examples:
        >>> remove_duplicates([1, 2, 3, 2, 4])
        [1, 3, 4]
        >>> remove_duplicates([1, 1, 2, 3, 3])
        [2]
    """
    counts = Counter(numbers)
    return [number for number in numbers if counts[number] == 1]
candidate = remove_duplicates




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == []
    assert candidate([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert candidate([1, 2, 3, 2, 4, 3, 5]) == [1, 4, 5]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
