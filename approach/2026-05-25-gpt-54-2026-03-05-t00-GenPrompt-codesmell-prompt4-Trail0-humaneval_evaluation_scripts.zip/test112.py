
import unittest
import re
import sys
import math
import copy


def reverse_delete(s, c):
    """
    Remove from `s` every character that appears in `c`,
    then return a tuple of:
      (filtered_string, is_palindrome)

    Examples:
        reverse_delete("abcde", "ae") -> ("bcd", False)
        reverse_delete("abcdef", "b") -> ("acdef", False)
        reverse_delete("abcdedcba", "ab") -> ("cdedc", True)
    """
    chars_to_remove = set(c)
    filtered = "".join(char for char in s if char not in chars_to_remove)
    return filtered, filtered == filtered[::-1]
candidate = reverse_delete


def check(candidate):

    assert candidate("abcde","ae") == ('bcd',False)
    assert candidate("abcdef", "b") == ('acdef',False)
    assert candidate("abcdedcba","ab") == ('cdedc',True)
    assert candidate("dwik","w") == ('dik',False)
    assert candidate("a","a") == ('',True)
    assert candidate("abcdedcba","") == ('abcdedcba',True)
    assert candidate("abcdedcba","v") == ('abcdedcba',True)
    assert candidate("vabba","v") == ('abba',True)
    assert candidate("mamma", "mia") == ("", True)


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
