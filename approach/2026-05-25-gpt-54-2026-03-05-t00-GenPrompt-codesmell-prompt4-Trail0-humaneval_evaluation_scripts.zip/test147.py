
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    Return the number of triples (a[i], a[j], a[k]) with i < j < k such that
    a[i] + a[j] + a[k] is divisible by 3, where:

        a[i] = i^2 - i + 1   for 1 <= i <= n

    Observation:
    Since we only care about divisibility by 3, reduce a[i] modulo 3:

        a[i] = i^2 - i + 1 = i(i - 1) + 1

    For i mod 3:
        i = 0 -> a[i] mod 3 = 1
        i = 1 -> a[i] mod 3 = 1
        i = 2 -> a[i] mod 3 = 0

    So:
        - indices congruent to 2 mod 3 contribute values divisible by 3
        - all other indices contribute values congruent to 1 mod 3

    A triple sum is divisible by 3 only in these cases:
        1) three numbers congruent to 0 mod 3
        2) three numbers congruent to 1 mod 3

    Let:
        count_0 = number of i in [1..n] with i % 3 == 2
        count_1 = n - count_0

    Answer:
        C(count_0, 3) + C(count_1, 3)
    """
    if n < 3:
        return 0

    def comb3(x):
        """Return x choose 3."""
        return x * (x - 1) * (x - 2) // 6 if x >= 3 else 0

    count_0 = (n + 1) // 3
    count_1 = n - count_0

    return comb3(count_0) + comb3(count_1)
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
