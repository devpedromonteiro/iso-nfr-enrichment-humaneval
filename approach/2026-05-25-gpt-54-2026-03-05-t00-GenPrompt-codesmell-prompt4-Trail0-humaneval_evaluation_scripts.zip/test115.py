
import unittest
import re
import sys
import math
import copy


import math


def max_fill(grid, capacity):
    """
    Return the total number of bucket lowerings needed to empty all wells.

    Each row in `grid` represents one well, and each `1` represents one unit of water.
    For each well, the number of bucket lowerings required is:

        ceil(units_of_water / capacity)

    Args:
        grid: List of lists containing 0s and 1s.
        capacity: Positive integer bucket capacity.

    Returns:
        Total number of times buckets must be lowered.
    """
    if capacity <= 0:
        raise ValueError("capacity must be a positive integer")

    total_lowerings = 0

    for well in grid:
        water_units = sum(well)
        total_lowerings += math.ceil(water_units / capacity)

    return total_lowerings
candidate = max_fill


def check(candidate):


    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([[0,0,1,0], [0,1,0,0], [1,1,1,1]], 1) == 6, "Error"
    assert candidate([[0,0,1,1], [0,0,0,0], [1,1,1,1], [0,1,1,1]], 2) == 5, "Error"
    assert candidate([[0,0,0], [0,0,0]], 5) == 0, "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([[1,1,1,1], [1,1,1,1]], 2) == 4, "Error"
    assert candidate([[1,1,1,1], [1,1,1,1]], 9) == 2, "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
