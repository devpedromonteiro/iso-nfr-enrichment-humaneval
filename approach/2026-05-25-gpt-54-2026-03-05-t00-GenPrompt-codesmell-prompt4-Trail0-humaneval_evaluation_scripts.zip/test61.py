
import unittest
import re
import sys
import math
import copy



def correct_bracketing(brackets: str) -> bool:
    """Return True if parentheses are correctly balanced.

    A string is correctly balanced when:
    - every opening bracket "(" has a matching closing bracket ")"
    - no closing bracket appears before its matching opening bracket

    >>> correct_bracketing("(")
    False
    >>> correct_bracketing("()")
    True
    >>> correct_bracketing("(()())")
    True
    >>> correct_bracketing(")(()")
    False
    """
    balance = 0

    for bracket in brackets:
        if bracket == "(":
            balance += 1
        elif bracket == ")":
            balance -= 1

        if balance < 0:
            return False

    return balance == 0
candidate = correct_bracketing




METADATA = {}


def check(candidate):
    assert candidate("()")
    assert candidate("(()())")
    assert candidate("()()(()())()")
    assert candidate("()()((()()())())(()()(()))")
    assert not candidate("((()())))")
    assert not candidate(")(()")
    assert not candidate("(")
    assert not candidate("((((")
    assert not candidate(")")
    assert not candidate("(()")
    assert not candidate("()()(()())())(()")
    assert not candidate("()()(()())()))()")



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
