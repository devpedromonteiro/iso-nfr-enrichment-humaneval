
import unittest
import re
import sys
import math
import copy


def circular_shift(x, shift):
    """Circularly shift the digits of an integer to the right.

    Args:
        x: Integer whose digits will be shifted.
        shift: Number of positions to shift right.

    Returns:
        A string containing the shifted digits.
        If shift is greater than the number of digits, the digits are reversed.

    Examples:
        >>> circular_shift(12, 1)
        '21'
        >>> circular_shift(12, 2)
        '12'
    """
    digits = str(x)
    digit_count = len(digits)

    if digit_count == 0:
        return digits

    if shift > digit_count:
        return digits[::-1]

    effective_shift = shift % digit_count
    if effective_shift == 0:
        return digits

    return digits[-effective_shift:] + digits[:-effective_shift]
candidate = circular_shift


def check(candidate):

    # Check some simple cases
    assert candidate(100, 2) == "001"
    assert candidate(12, 2) == "12"
    assert candidate(97, 8) == "79"
    assert candidate(12, 1) == "21", "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(11, 101) == "11", "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
