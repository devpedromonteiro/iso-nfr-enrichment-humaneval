
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


from typing import Sequence


def poly(coefficients: Sequence[float], x: float) -> float:
    """
    Evaluate a polynomial at point ``x``.

    The polynomial is defined by coefficients in ascending power order:
    ``coefficients[0] + coefficients[1] * x + coefficients[2] * x^2 + ...``

    Uses Horner's method for better performance and numerical stability.

    >>> poly([1, 2], 3)
    7.0
    >>> poly([-6, 11, -6, 1], 1)
    0.0
    """
    result = 0.0
    for coefficient in reversed(coefficients):
        result = result * x + coefficient
    return result


def find_zero(coefficients: Sequence[float], tolerance: float = 1e-10) -> float:
    """
    Find one real zero of a polynomial.

    Assumes:
    - ``coefficients`` has an even number of items
    - the highest non-zero coefficient corresponds to an odd degree

    Under these assumptions, the polynomial is guaranteed to have at least
    one real root.

    The function returns one such root using interval expansion and bisection.

    >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2)  # (x - 1) * (x - 2) * (x - 3)
    1.0
    """
    if not coefficients:
        raise ValueError("coefficients must not be empty")

    degree = _highest_non_zero_degree(coefficients, tolerance)
    if degree is None:
        raise ValueError("zero polynomial has infinitely many roots")

    if len(coefficients) % 2 != 0:
        raise ValueError("coefficients must contain an even number of items")

    if degree % 2 == 0:
        raise ValueError("highest non-zero coefficient must correspond to an odd degree")

    left, right = _find_bracketing_interval(coefficients, tolerance)

    return _bisect_root(coefficients, left, right, tolerance)


def _highest_non_zero_degree(
    coefficients: Sequence[float], tolerance: float
def _find_bracketing_interval(
    coefficients: Sequence[float], tolerance: float
def _bisect_root(
    coefficients: Sequence[float],
    left: float,
    right: float,
    tolerance: float,
    max_iterations: int = 10_000,
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
