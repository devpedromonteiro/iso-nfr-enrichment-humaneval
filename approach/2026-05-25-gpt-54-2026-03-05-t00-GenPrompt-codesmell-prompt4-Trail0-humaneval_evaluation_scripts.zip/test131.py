
import unittest
import re
import sys
import math
import copy


def digits(n):
    """Return the product of the odd digits in a positive integer.

    If n contains no odd digits, return 0.

    Examples:
        digits(1) == 1
        digits(4) == 0
        digits(235) == 15
    """
    product = 1
    found_odd = False

    while n > 0:
        digit = n % 10
        if digit % 2 == 1:
            product *= digit
            found_odd = True
        n //= 10

    return product if found_odd else 0
candidate = digits


def check(candidate):

    # Check some simple cases
    assert candidate(5) == 5
    assert candidate(54) == 5
    assert candidate(120) ==1
    assert candidate(5014) == 5
    assert candidate(98765) == 315
    assert candidate(5576543) == 2625

    # Check some edge cases that are easy to work out by hand.
    assert candidate(2468) == 0



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
