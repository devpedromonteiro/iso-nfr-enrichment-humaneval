
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def filter_by_prefix(strings: List[str], prefix: str) -> List[str]:
    """Filter strings that start with the given prefix.

    Args:
        strings: A list of input strings.
        prefix: The prefix to match.

    Returns:
        A list containing only the strings that start with `prefix`.

    Examples:
        >>> filter_by_prefix([], 'a')
        []
        >>> filter_by_prefix(['abc', 'bcd', 'cde', 'array'], 'a')
        ['abc', 'array']
    """
    return [string for string in strings if string.startswith(prefix)]
candidate = filter_by_prefix




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([], 'john') == []
    assert candidate(['xxx', 'asd', 'xxy', 'john doe', 'xxxAAA', 'xxx'], 'xxx') == ['xxx', 'xxxAAA', 'xxx']


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
