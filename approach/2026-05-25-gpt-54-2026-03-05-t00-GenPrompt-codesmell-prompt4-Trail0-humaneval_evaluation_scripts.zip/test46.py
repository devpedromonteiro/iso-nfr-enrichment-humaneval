
import unittest
import re
import sys
import math
import copy



def fib4(n: int) -> int:
    """Return the n-th value in the Fib4 sequence.

    The Fib4 sequence is defined as:
        fib4(0) = 0
        fib4(1) = 0
        fib4(2) = 2
        fib4(3) = 0
        fib4(n) = fib4(n-1) + fib4(n-2) + fib4(n-3) + fib4(n-4) for n >= 4

    This implementation is iterative and runs in O(n) time using O(1) space.

    >>> fib4(5)
    4
    >>> fib4(6)
    8
    >>> fib4(7)
    14
    """
    if n < 0:
        raise ValueError("n must be a non-negative integer")

    base_cases = (0, 0, 2, 0)
    if n < len(base_cases):
        return base_cases[n]

    a, b, c, d = base_cases
    for _ in range(4, n + 1):
        a, b, c, d = b, c, d, a + b + c + d

    return d
candidate = fib4




METADATA = {}


def check(candidate):
    assert candidate(5) == 4
    assert candidate(8) == 28
    assert candidate(10) == 104
    assert candidate(12) == 386



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
