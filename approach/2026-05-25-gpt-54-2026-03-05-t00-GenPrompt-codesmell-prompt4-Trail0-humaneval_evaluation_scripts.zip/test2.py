
import unittest
import re
import sys
import math
import copy



def truncate_number(number: float) -> float:
    """Return the fractional part of a positive floating-point number.

    The fractional part is the portion after the decimal point.

    Examples:
        >>> truncate_number(3.5)
        0.5
        >>> truncate_number(10.0)
        0.0
    """
    return number % 1
candidate = truncate_number




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(3.5) == 0.5
    assert abs(candidate(1.33) - 0.33) < 1e-6
    assert abs(candidate(123.456) - 0.456) < 1e-6


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
