
import unittest
import re
import sys
import math
import copy


def compare(game, guess):
    """
    Compare actual match scores with guessed scores.

    Returns a list where each element is the absolute difference between
    the actual score and the guessed score for the corresponding match.
    A correct guess results in 0.

    Examples:
        compare([1, 2, 3, 4, 5, 1], [1, 2, 3, 4, 2, -2]) -> [0, 0, 0, 0, 3, 3]
        compare([0, 5, 0, 0, 0, 4], [4, 1, 1, 0, 0, -2]) -> [4, 4, 1, 0, 0, 6]
    """
    return [abs(actual - predicted) for actual, predicted in zip(game, guess)]
candidate = compare


def check(candidate):

    # Check some simple cases
    assert candidate([1,2,3,4,5,1],[1,2,3,4,2,-2])==[0,0,0,0,3,3], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([0,0,0,0,0,0],[0,0,0,0,0,0])==[0,0,0,0,0,0], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,2,3],[-1,-2,-3])==[2,4,6], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,2,3,5],[-1,2,3,4])==[2,0,0,1], "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
