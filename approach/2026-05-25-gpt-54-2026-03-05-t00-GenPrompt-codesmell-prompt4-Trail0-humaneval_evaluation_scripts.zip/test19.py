
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import Dict, List

_WORD_TO_VALUE: Dict[str, int] = {
    "zero": 0,
    "one": 1,
    "two": 2,
    "three": 3,
    "four": 4,
    "five": 5,
    "six": 6,
    "seven": 7,
    "eight": 8,
    "nine": 9,
}


def sort_numbers(numbers: str) -> str:
    """Sort space-delimited number words from smallest to largest.

    Input must contain only valid number words from 'zero' to 'nine'.

    >>> sort_numbers("three one five")
    'one three five'
    """
    if not numbers.strip():
        return ""

    words: List[str] = numbers.split()
    invalid_words = [word for word in words if word not in _WORD_TO_VALUE]
    if invalid_words:
        raise ValueError(f"Invalid number word(s): {', '.join(invalid_words)}")

    sorted_words = sorted(words, key=_WORD_TO_VALUE.__getitem__)
    return " ".join(sorted_words)
candidate = sort_numbers




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == ''
    assert candidate('three') == 'three'
    assert candidate('three five nine') == 'three five nine'
    assert candidate('five zero four seven nine eight') == 'zero four five seven eight nine'
    assert candidate('six five four three two one zero') == 'zero one two three four five six'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
