
import unittest
import re
import sys
import math
import copy



def change_base(x: int, base: int) -> str:
    """Convert a non-negative integer ``x`` to its string representation in ``base``.

    The base must be between 2 and 9 inclusive.

    Args:
        x: Non-negative integer to convert.
        base: Target base.

    Returns:
        String representation of ``x`` in the given base.

    Raises:
        ValueError: If ``x`` is negative or ``base`` is not between 2 and 9.

    Examples:
        >>> change_base(8, 3)
        '22'
        >>> change_base(8, 2)
        '1000'
        >>> change_base(7, 2)
        '111'
        >>> change_base(0, 2)
        '0'
    """
    if x < 0:
        raise ValueError("x must be a non-negative integer")
    if not 2 <= base <= 9:
        raise ValueError("base must be between 2 and 9")

    if x == 0:
        return "0"

    digits = []
    current = x

    while current > 0:
        current, remainder = divmod(current, base)
        digits.append(str(remainder))

    return "".join(reversed(digits))
candidate = change_base




METADATA = {}


def check(candidate):
    assert candidate(8, 3) == "22"
    assert candidate(9, 3) == "100"
    assert candidate(234, 2) == "11101010"
    assert candidate(16, 2) == "10000"
    assert candidate(8, 2) == "1000"
    assert candidate(7, 2) == "111"
    for x in range(2, 8):
        assert candidate(x, x + 1) == str(x)



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
