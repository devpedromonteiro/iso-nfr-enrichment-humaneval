
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List

WHOLE_NOTE = "o"
HALF_NOTE = "o|"
QUARTER_NOTE = ".|"

NOTE_DURATIONS = {
    WHOLE_NOTE: 4,
    HALF_NOTE: 2,
    QUARTER_NOTE: 1,
}


def parse_music(music_string: str) -> List[int]:
    """Parse a space-separated ASCII music string into note durations.

    Legend:
    - 'o'  -> 4 beats
    - 'o|' -> 2 beats
    - '.|' -> 1 beat

    Args:
        music_string: A string containing notes separated by whitespace.

    Returns:
        A list of integers representing the duration of each note in beats.

    Raises:
        ValueError: If an unknown note token is encountered.

    >>> parse_music('o o| .| o| o| .| .| .| .| o o')
    [4, 2, 1, 2, 2, 1, 1, 1, 1, 4, 4]
    """
    if not music_string.strip():
        return []

    durations: List[int] = []

    for note in music_string.split():
        try:
            durations.append(NOTE_DURATIONS[note])
        except KeyError as exc:
            raise ValueError(f"Unknown note: {note!r}") from exc

    return durations
candidate = parse_music




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == []
    assert candidate('o o o o') == [4, 4, 4, 4]
    assert candidate('.| .| .| .|') == [1, 1, 1, 1]
    assert candidate('o| o| .| .| o o o o') == [2, 2, 1, 1, 4, 4, 4, 4]
    assert candidate('o| .| o| .| o o| o o|') == [2, 1, 2, 1, 4, 2, 4, 2]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
