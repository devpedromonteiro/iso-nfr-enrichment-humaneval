
import unittest
import re
import sys
import math
import copy


def get_odd_collatz(n):
    """
    Given a positive integer n, return a sorted list containing the odd numbers
    in the Collatz sequence for n.

    The returned list is sorted in increasing order.

    Args:
        n: A positive integer.

    Returns:
        A sorted list of odd integers from the Collatz sequence.

    Raises:
        TypeError: If n is not an integer.
        ValueError: If n is not a positive integer.
    """
    if isinstance(n, bool) or not isinstance(n, int):
        raise TypeError("n must be an integer")
    if n <= 0:
        raise ValueError("n must be a positive integer")

    odd_numbers = set()
    current = n

    while True:
        if current % 2 == 1:
            odd_numbers.add(current)

        if current == 1:
            break

        if current % 2 == 0:
            current //= 2
        else:
            current = 3 * current + 1

    return sorted(odd_numbers)
candidate = get_odd_collatz


def check(candidate):

    # Check some simple cases
    assert candidate(14) == [1, 5, 7, 11, 13, 17]
    assert candidate(5) == [1, 5]
    assert candidate(12) == [1, 3, 5], "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1) == [1], "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
