
import unittest
import re
import sys
import math
import copy


def move_one_ball(arr):
    """Determine whether a list can be sorted in non-decreasing order
    using only right circular shifts.

    A right shift moves the last element to the front.

    Args:
        arr: A list or tuple of unique integers.

    Returns:
        True if the array is empty or can be transformed into sorted
        non-decreasing order by some number of right shifts, else False.

    Raises:
        TypeError: If arr is not a list/tuple, or contains non-integer elements.
        ValueError: If arr contains duplicate elements.
    """
    if arr is None:
        raise TypeError("arr must be a list or tuple of integers, got None")

    if not isinstance(arr, (list, tuple)):
        raise TypeError(f"arr must be a list or tuple, got {type(arr).__name__}")

    if len(arr) == 0:
        return True

    if any(not isinstance(x, int) for x in arr):
        raise TypeError("all elements in arr must be integers")

    if len(set(arr)) != len(arr):
        raise ValueError("arr must contain unique elements")

    try:
        drops = 0
        n = len(arr)

        for i in range(n):
            if arr[i] > arr[(i + 1) % n]:
                drops += 1
                if drops > 1:
                    return False

        return True
    except IndexError as exc:
        raise RuntimeError("unexpected indexing error while processing array") from exc
candidate = move_one_ball


def check(candidate):

    # Check some simple cases
    assert candidate([3, 4, 5, 1, 2])==True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([3, 5, 10, 1, 2])==True
    assert candidate([4, 3, 1, 2])==False
    # Check some edge cases that are easy to work out by hand.
    assert candidate([3, 5, 4, 1, 2])==False, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([])==True


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
