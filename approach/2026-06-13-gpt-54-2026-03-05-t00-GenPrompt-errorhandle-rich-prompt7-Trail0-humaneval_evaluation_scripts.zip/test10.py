
import unittest
import re
import sys
import math
import copy



def is_palindrome(string: str) -> bool:
    """ Test if given string is a palindrome """
    return string == string[::-1]


def is_palindrome(string: str) -> bool:
    """Test if given string is a palindrome.

    Raises:
        TypeError: If string is not a str.
    """
    if not isinstance(string, str):
        raise TypeError(f"string must be of type str, got {type(string).__name__}")
    return string == string[::-1]


def make_palindrome(string: str) -> str:
    """Find the shortest palindrome that begins with a supplied string.

    Algorithm:
    - Find the longest postfix of supplied string that is a palindrome.
    - Append to the end of the string the reverse of the prefix that comes
      before the palindromic suffix.

    Raises:
        TypeError: If string is not a str.
        ValueError: If string is invalid.

    >>> make_palindrome('')
    ''
    >>> make_palindrome('cat')
    'catac'
    >>> make_palindrome('cata')
    'catac'
    """
    if not isinstance(string, str):
        raise TypeError(f"string must be of type str, got {type(string).__name__}")

    if string == "":
        return ""

    try:
        for i in range(len(string)):
            suffix = string[i:]
            if is_palindrome(suffix):
                prefix = string[:i]
                return string + prefix[::-1]
    except TypeError:
        raise
    except Exception as exc:
        raise RuntimeError("failed to construct palindrome") from exc

    raise ValueError("unable to construct palindrome from the provided string")
candidate = make_palindrome




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == ''
    assert candidate('x') == 'x'
    assert candidate('xyz') == 'xyzyx'
    assert candidate('xyx') == 'xyx'
    assert candidate('jerry') == 'jerryrrej'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
