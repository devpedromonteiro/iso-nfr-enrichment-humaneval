
import unittest
import re
import sys
import math
import copy


def circular_shift(x, shift):
    """Circular shift the digits of the integer x, shifting right by `shift`,
    and return the result as a string.

    If shift > number of digits, return the digits reversed.

    Args:
        x: Integer whose digits will be shifted.
        shift: Non-negative integer shift amount.

    Returns:
        A string representing the shifted digits.

    Raises:
        TypeError: If `x` or `shift` is not an integer.
        ValueError: If `shift` is negative.

    >>> circular_shift(12, 1)
    '21'
    >>> circular_shift(12, 2)
    '12'
    """
    if not isinstance(x, int):
        raise TypeError("x must be an integer")
    if not isinstance(shift, int):
        raise TypeError("shift must be an integer")
    if shift < 0:
        raise ValueError("shift must be non-negative")

    digits = str(x)
    length = len(digits)

    if shift > length:
        return digits[::-1]

    if length == 0:
        return digits

    shift = shift % length
    return digits[-shift:] + digits[:-shift] if shift != 0 else digits
candidate = circular_shift


def check(candidate):

    # Check some simple cases
    assert candidate(100, 2) == "001"
    assert candidate(12, 2) == "12"
    assert candidate(97, 8) == "79"
    assert candidate(12, 1) == "21", "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(11, 101) == "11", "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
