
import unittest
import re
import sys
import math
import copy


def will_it_fly(q, w):
    '''
    Write a function that returns True if the object q will fly, and False otherwise.
    The object q will fly if it's balanced (it is a palindromic list) and the sum of its elements is less than or equal the maximum possible weight w.

    Example:
    will_it_fly([1, 2], 5) â False 
    # 1+2 is less than the maximum possible weight, but it's unbalanced.

    will_it_fly([3, 2, 3], 1) â False
    # it's balanced, but 3+2+3 is more than the maximum possible weight.

    will_it_fly([3, 2, 3], 9) â True
    # 3+2+3 is less than the maximum possible weight, and it's balanced.

    will_it_fly([3], 5) â True
    # 3 is less than the maximum possible weight, and it's balanced.
    '''
    if not isinstance(q, list):
        raise TypeError("q must be a list")
    if not isinstance(w, (int, float)):
        raise TypeError("w must be a number")
    if w < 0:
        raise ValueError("w must be non-negative")

    for i, item in enumerate(q):
        if not isinstance(item, (int, float)):
            raise TypeError(f"q[{i}] must be a number")

    try:
        is_balanced = q == q[::-1]
        total_weight = sum(q)
    except TypeError as e:
        raise TypeError("q must contain only numeric values") from e

    return is_balanced and total_weight <= w
candidate = will_it_fly


def check(candidate):

    # Check some simple cases
    assert candidate([3, 2, 3], 9) is True
    assert candidate([1, 2], 5) is False
    assert candidate([3], 5) is True
    assert candidate([3, 2, 3], 1) is False


    # Check some edge cases that are easy to work out by hand.
    assert candidate([1, 2, 3], 6) is False
    assert candidate([5], 5) is True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
