
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def filter_by_prefix(strings: List[str], prefix: str) -> List[str]:
    """Filter an input list of strings for ones that start with a given prefix.

    >>> filter_by_prefix([], 'a')
    []
    >>> filter_by_prefix(['abc', 'bcd', 'cde', 'array'], 'a')
    ['abc', 'array']
    """
    if not isinstance(strings, list):
        raise TypeError("strings must be a list of strings")
    if not isinstance(prefix, str):
        raise TypeError("prefix must be a string")

    for i, value in enumerate(strings):
        if not isinstance(value, str):
            raise TypeError(f"strings[{i}] must be a string")

    return [s for s in strings if s.startswith(prefix)]
candidate = filter_by_prefix




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([], 'john') == []
    assert candidate(['xxx', 'asd', 'xxy', 'john doe', 'xxxAAA', 'xxx'], 'xxx') == ['xxx', 'xxxAAA', 'xxx']


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
