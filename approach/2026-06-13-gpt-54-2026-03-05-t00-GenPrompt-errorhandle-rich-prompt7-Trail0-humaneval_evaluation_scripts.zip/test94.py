
import unittest
import re
import sys
import math
import copy



def skjkasdkd(lst):
    """Return the sum of digits of the largest prime integer in lst.

    Args:
        lst: A list of integers.

    Returns:
        int: Sum of digits of the largest prime found in the list.

    Raises:
        TypeError: If lst is not a list or contains non-integer elements.
        ValueError: If no prime numbers are present in the list.
    """
    if not isinstance(lst, list):
        raise TypeError("lst must be a list of integers")

    for i, value in enumerate(lst):
        if not isinstance(value, int):
            raise TypeError(f"lst[{i}] must be an integer, got {type(value).__name__}")

    def is_prime(n):
        if n < 2:
            return False
        if n == 2:
            return True
        if n % 2 == 0:
            return False
        limit = int(n ** 0.5) + 1
        for divisor in range(3, limit, 2):
            if n % divisor == 0:
                return False
        return True

    primes = [x for x in lst if is_prime(x)]

    if not primes:
        raise ValueError("lst does not contain any prime numbers")

    largest_prime = max(primes)
    return sum(int(digit) for digit in str(largest_prime))
candidate = skjkasdkd


def check(candidate):

    # Check some simple cases
    assert candidate([0,3,2,1,3,5,7,4,5,5,5,2,181,32,4,32,3,2,32,324,4,3]) == 10, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate([1,0,1,8,2,4597,2,1,3,40,1,2,1,2,4,2,5,1]) == 25, "This prints if this assert fails 2 (also good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate([1,3,1,32,5107,34,83278,109,163,23,2323,32,30,1,9,3]) == 13, "This prints if this assert fails 3 (also good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate([0,724,32,71,99,32,6,0,5,91,83,0,5,6]) == 11, "This prints if this assert fails 4 (also good for debugging!)"
    
    # Check some edge cases that are easy to work out by hand.
    assert candidate([0,81,12,3,1,21]) == 3, "This prints if this assert fails 5 (also good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate([0,8,1,2,1,7]) == 7, "This prints if this assert fails 6 (also good for debugging!)"

    assert candidate([8191]) == 19, "This prints if this assert fails 7 (also good for debugging!)"
    assert candidate([8191, 123456, 127, 7]) == 19, "This prints if this assert fails 8 (also good for debugging!)"
    assert candidate([127, 97, 8192]) == 10, "This prints if this assert fails 9 (also good for debugging!)"


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
