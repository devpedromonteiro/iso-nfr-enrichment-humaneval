
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    You are given a positive integer n. You have to create an integer array a of length n.
        For each i (1 â¤ i â¤ n), the value of a[i] = i * i - i + 1.
        Return the number of triples (a[i], a[j], a[k]) of a where i < j < k,
    and a[i] + a[j] + a[k] is a multiple of 3.

    Example :
        Input: n = 5
        Output: 1
        Explanation:
        a = [1, 3, 7, 13, 21]
        The only valid triple is (1, 7, 13).
    """
    if isinstance(n, bool):
        raise TypeError("n must be a positive integer, not bool")
    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if n <= 0:
        raise ValueError("n must be a positive integer")

    try:
        # a[i] = i^2 - i + 1
        # Mod 3 pattern for i = 1,2,3,... is:
        # 1, 0, 1, 1, 0, 1, ...
        # So:
        # if i % 3 == 2 -> a[i] % 3 == 0
        # otherwise     -> a[i] % 3 == 1
        #
        # A triple sum is divisible by 3 only when residues are:
        # (1,1,1) or (0,1,2). Since residue 2 never occurs here,
        # only triples of three residue-1 elements are valid.

        count_mod_1 = n - (n // 3)  # all indices except those where i % 3 == 2

        if count_mod_1 < 3:
            return 0

        return count_mod_1 * (count_mod_1 - 1) * (count_mod_1 - 2) // 6

    except OverflowError:
        raise OverflowError("calculation overflowed while computing triples")
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
