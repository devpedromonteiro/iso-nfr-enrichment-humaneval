
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[2] * x^2 + .... + xs[n] * x^n
    """
    if not isinstance(xs, list):
        raise TypeError("xs must be a list of numeric coefficients")
    if len(xs) == 0:
        raise ValueError("xs must not be empty")
    if not isinstance(x, (int, float)):
        raise TypeError("x must be a numeric value")

    for i, coeff in enumerate(xs):
        if not isinstance(coeff, (int, float)):
            raise TypeError(f"coefficient at index {i} must be numeric")

    return sum(coeff * math.pow(x, i) for i, coeff in enumerate(xs))


def find_zero(xs: list):
    """xs are coefficients of a polynomial.

    find_zero finds x such that poly(xs, x) == 0.
    Returns only one zero point, even if there are many.

    Constraints:
    - xs must be a list
    - xs must have an even number of coefficients
    - xs must not be empty
    - coefficients must be numeric
    - the largest non-zero coefficient must be positive

    >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2)  # (x - 1) * (x - 2) * (x - 3)
    1.0
    """
    if not isinstance(xs, list):
        raise TypeError("xs must be a list of numeric coefficients")
    if len(xs) == 0:
        raise ValueError("xs must not be empty")
    if len(xs) % 2 != 0:
        raise ValueError("xs must contain an even number of coefficients")

    for i, coeff in enumerate(xs):
        if not isinstance(coeff, (int, float)):
            raise TypeError(f"coefficient at index {i} must be numeric")

    degree = None
    for i in range(len(xs) - 1, -1, -1):
        if xs[i] != 0:
            degree = i
            break

    if degree is None:
        raise ValueError("polynomial must not be the zero polynomial")

    if xs[degree] <= 0:
        raise ValueError("largest non-zero coefficient must be positive")

    # Linear case: a + bx = 0
    if degree == 1:
        if xs[1] == 0:
            raise ZeroDivisionError("linear coefficient must be non-zero")
        return -xs[0] / xs[1]

    # Search for a sign change and then use bisection.
    def _bisect(left, right, max_iter=200, tol=1e-12):
        f_left = poly(xs, left)
        f_right = poly(xs, right)

        if f_left == 0:
            return left
        if f_right == 0:
            return right
        if f_left * f_right > 0:
            raise ValueError("bisection requires an interval with a sign change")

        for _ in range(max_iter):
            mid = (left + right) / 2.0
            f_mid = poly(xs, mid)

            if abs(f_mid) < tol or abs(right - left) < tol:
                return mid

            if f_left * f_mid <= 0:
                right = mid
                f_right = f_mid
            else:
                left = mid
                f_left = f_mid

        return (left + right) / 2.0

    # Since degree is odd and leading coefficient is positive,
    # f(x) -> -inf as x -> -inf and f(x) -> +inf as x -> +inf.
    # Expand interval until a sign change is found.
    left, right = -1.0, 1.0
    f_left = poly(xs, left)
    f_right = poly(xs, right)

    max_expand = 100
    expand_count = 0
    while f_left * f_right > 0:
        left *= 2.0
        right *= 2.0
        f_left = poly(xs, left)
        f_right = poly(xs, right)
        expand_count += 1

        if expand_count >= max_expand:
            raise RuntimeError("failed to bracket a root for the polynomial")

    return _bisect(left, right)
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
