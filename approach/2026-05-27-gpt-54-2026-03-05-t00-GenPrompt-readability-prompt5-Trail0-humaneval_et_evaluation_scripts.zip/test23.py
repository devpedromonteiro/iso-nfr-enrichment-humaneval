
import unittest



def strlen(string: str) -> int:
    """Return length of given string.

    >>> strlen('')
    0
    >>> strlen('abc')
    3
    """
    length = 0
    for _ in string:
        length += 1
    return length
candidate = strlen


class Test(unittest.TestCase):
    def test(self):
        assert candidate('asdasnakj') == 9
        assert candidate("vc") == 2
        assert candidate("yb") == 2
        assert candidate("jogcyuitzjrvh") == 13
        assert candidate("ucomfyiviag") == 11
        assert candidate("ayl") == 3
        assert candidate("m") == 1
        assert candidate("e") == 1
        assert candidate("ktb") == 3
        assert candidate("mlibcojl") == 8
        assert candidate("atxezdbptfkmt") == 13
        assert candidate("ebs") == 3
        assert candidate("nys") == 3
        assert candidate("bfk") == 3
        assert candidate("i") == 1
        assert candidate("zoxeghlpn") == 9
        assert candidate("yzzbses") == 7
        assert candidate("frawhhhlnxbht") == 13
        assert candidate("q") == 1
        assert candidate("ocgxuaooxl") == 10
        assert candidate("v") == 1
        assert candidate("j") == 1
        assert candidate("wmgueqfzkeltnzs") == 15
        assert candidate("pf") == 2
        assert candidate("ul") == 2
        assert candidate("s") == 1
        assert candidate("ju") == 2
        assert candidate("awa") == 3
        assert candidate("mlymvigwgp") == 10
        assert candidate("dag") == 3
        assert candidate("mltzwtijfa") == 10
        assert candidate("kvkjlinq") == 8
        assert candidate('') == 0
        assert candidate("y") == 1
        assert candidate("synqrbip") == 8
        assert candidate("stf") == 3
        assert candidate("t") == 1
        assert candidate("o") == 1
        assert candidate("uikrinzshur") == 11
        assert candidate("f") == 1
        assert candidate("c") == 1
        assert candidate("ri") == 2
        assert candidate("fghpnpcwbtt") == 11
        assert candidate("hnleeqiivdnkcmg") == 15
        assert candidate("z") == 1
        assert candidate("hf") == 2
        assert candidate("ysgcoonffvro") == 12
        assert candidate("htu") == 3
        assert candidate("dktbzie") == 7
        assert candidate("nda") == 3
        assert candidate("lcyfivgvsc") == 10
        assert candidate("ovx") == 3
        assert candidate("n") == 1
        assert candidate("nkcxhu") == 6
        assert candidate("ioxinphe") == 8
        assert candidate("eldxchtrwpt") == 11
        assert candidate("irxccu") == 6
        assert candidate("wmprqbpl") == 8
        assert candidate("d") == 1
        assert candidate("iiapjyy") == 7
        assert candidate("he") == 2
        assert candidate("xl") == 2
        assert candidate("k") == 1
        assert candidate("qoaiffxdphe") == 11
        assert candidate("jjw") == 3
        assert candidate("gok") == 3
        assert candidate("sk") == 2
        assert candidate("ppfoxwul") == 8
        assert candidate("zq") == 2
        assert candidate("kehslysfoychuai") == 15
        assert candidate("xjtufvdxuuo") == 11
        assert candidate("ukycdfhgxcltpl") == 14
        assert candidate("b") == 1
        assert candidate("w") == 1
        assert candidate("hctqxmha") == 8
        assert candidate("ljrzldsvk") == 9
        assert candidate("a") == 1
        assert candidate("bgrmakcbqpwyi") == 13
        assert candidate("lvgulxd") == 7
        assert candidate("vnaevhphi") == 9
        assert candidate("rt") == 2
        assert candidate("zrmygypu") == 8
        assert candidate("zdr") == 3
        assert candidate("tov") == 3
        assert candidate("rnlrddf") == 7
        assert candidate("u") == 1
        assert candidate("ayuzaiwhczpz") == 12
        assert candidate("ucwkvbqsngpf") == 12
        assert candidate("xt") == 2
        assert candidate("gtamobyhrvxgvsr") == 15
        assert candidate("luvpxrpa") == 8
        assert candidate('x') == 1
        assert candidate("zpjtjbmjiapixsz") == 15
        assert candidate("ib") == 2

if __name__ == '__main__':
    unittest.main()
