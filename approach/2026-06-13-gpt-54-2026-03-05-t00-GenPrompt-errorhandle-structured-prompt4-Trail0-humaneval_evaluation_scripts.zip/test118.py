
import unittest
import re
import sys
import math
import copy


def get_closest_vowel(word):
    """Return the rightmost vowel that is between two consonants.

    A vowel at the beginning or end of the word does not count.
    The function is case sensitive and assumes English letters only.

    Raises:
        TypeError: If word is not a string.
        ValueError: If word contains non-alphabetic characters.
    """
    if not isinstance(word, str):
        raise TypeError("word must be a string")

    if not word.isalpha():
        raise ValueError("word must contain English letters only")

    if len(word) < 3:
        return ""

    vowels = set("aeiouAEIOU")

    for i in range(len(word) - 2, 0, -1):
        if (
            word[i] in vowels
            and word[i - 1] not in vowels
            and word[i + 1] not in vowels
        ):
            return word[i]

    return ""
candidate = get_closest_vowel


def check(candidate):

    # Check some simple cases
    assert candidate("yogurt") == "u"
    assert candidate("full") == "u"
    assert candidate("easy") == ""
    assert candidate("eAsy") == ""
    assert candidate("ali") == ""
    assert candidate("bad") == "a"
    assert candidate("most") == "o"
    assert candidate("ab") == ""
    assert candidate("ba") == ""
    assert candidate("quick") == ""
    assert candidate("anime") == "i"
    assert candidate("Asia") == ""
    assert candidate("Above") == "o"

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
