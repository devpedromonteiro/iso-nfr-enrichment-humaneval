
import unittest
import re
import sys
import math
import copy


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and
    the second list is a list of integers. Use the two given lists to build the algebraic
    expression and return the evaluation of this expression.

    Supported operators:
        +, -, *, //, **

    Reliability / error-handling behavior:
        - validates input types and sizes explicitly
        - raises specific exceptions for invalid arguments
        - does not silently swallow runtime errors such as division by zero
    """
    supported_operators = {"+", "-", "*", "//", "**"}

    if not isinstance(operator, list):
        raise TypeError("operator must be a list")
    if not isinstance(operand, list):
        raise TypeError("operand must be a list")

    if len(operator) < 1:
        raise ValueError("operator list must contain at least one operator")
    if len(operand) < 2:
        raise ValueError("operand list must contain at least two operands")
    if len(operator) != len(operand) - 1:
        raise ValueError("length of operator must be equal to length of operand minus one")

    for op in operator:
        if not isinstance(op, str):
            raise TypeError("each operator must be a string")
        if op not in supported_operators:
            raise ValueError(f"unsupported operator: {op}")

    for value in operand:
        if not isinstance(value, int):
            raise TypeError("each operand must be an integer")
        if value < 0:
            raise ValueError("operands must be non-negative integers")

    expression = [operand[0]]
    for i, op in enumerate(operator):
        expression.append(op)
        expression.append(operand[i + 1])

    precedence = {"**": 3, "*": 2, "//": 2, "+": 1, "-": 1}
    values = []
    ops = []

    def apply_top_operator():
        if len(values) < 2:
            raise ValueError("invalid expression: insufficient operands")
        if not ops:
            raise ValueError("invalid expression: missing operator")

        right = values.pop()
        left = values.pop()
        op = ops.pop()

        if op == "+":
            values.append(left + right)
        elif op == "-":
            values.append(left - right)
        elif op == "*":
            values.append(left * right)
        elif op == "//":
            if right == 0:
                raise ZeroDivisionError("floor division by zero")
            values.append(left // right)
        elif op == "**":
            values.append(left ** right)
        else:
            raise ValueError(f"unsupported operator encountered during evaluation: {op}")

    try:
        values.append(expression[0])

        i = 1
        while i < len(expression):
            op = expression[i]
            val = expression[i + 1]

            while ops and (
                precedence[ops[-1]] > precedence[op]
                or (precedence[ops[-1]] == precedence[op] and op != "**")
            ):
                apply_top_operator()

            ops.append(op)
            values.append(val)
            i += 2

        while ops:
            apply_top_operator()

        if len(values) != 1:
            raise ValueError("invalid expression: evaluation did not resolve to a single result")

        return values[0]

    except (TypeError, ValueError, ZeroDivisionError, OverflowError):
        # Re-raise specific exceptions without swallowing them.
        raise
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
