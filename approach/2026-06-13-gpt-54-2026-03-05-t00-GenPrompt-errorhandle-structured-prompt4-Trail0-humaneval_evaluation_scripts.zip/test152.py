
import unittest
import re
import sys
import math
import copy


def compare(game, guess):
    """Compare actual scores to guessed scores.

    Returns a list where each element is the absolute difference between
    the corresponding values in `game` and `guess`.

    Examples:
        compare([1,2,3,4,5,1], [1,2,3,4,2,-2]) -> [0,0,0,0,3,3]
        compare([0,5,0,0,0,4], [4,1,1,0,0,-2]) -> [4,4,1,0,0,6]
    """
    if not isinstance(game, list):
        raise TypeError("game must be a list")
    if not isinstance(guess, list):
        raise TypeError("guess must be a list")
    if len(game) != len(guess):
        raise ValueError("game and guess must have the same length")

    result = []
    for i, (actual, predicted) in enumerate(zip(game, guess)):
        if not isinstance(actual, (int, float)):
            raise TypeError(f"game[{i}] must be a number")
        if not isinstance(predicted, (int, float)):
            raise TypeError(f"guess[{i}] must be a number")
        result.append(abs(actual - predicted))

    return result
candidate = compare


def check(candidate):

    # Check some simple cases
    assert candidate([1,2,3,4,5,1],[1,2,3,4,2,-2])==[0,0,0,0,3,3], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([0,0,0,0,0,0],[0,0,0,0,0,0])==[0,0,0,0,0,0], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,2,3],[-1,-2,-3])==[2,4,6], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,2,3,5],[-1,2,3,4])==[2,0,0,1], "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
