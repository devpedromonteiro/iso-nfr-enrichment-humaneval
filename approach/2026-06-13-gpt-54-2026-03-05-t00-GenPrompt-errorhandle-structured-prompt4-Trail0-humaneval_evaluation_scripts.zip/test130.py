
import unittest
import re
import sys
import math
import copy


def tri(n):
    """Return a list of the first n + 1 values of the Tribonacci sequence.

    Sequence definition:
    - tri(1) = 3
    - tri(n) = 1 + n / 2, if n is even
    - tri(n) = tri(n - 1) + tri(n - 2) + tri(n + 1), if n is odd

    By the example, the returned list starts with tri(0) = 1:
    tri(3) -> [1, 3, 2, 8]

    Raises:
        TypeError: if n is not an integer
        ValueError: if n is negative
    """
    if isinstance(n, bool) or not isinstance(n, int):
        raise TypeError("n must be a non-negative integer")
    if n < 0:
        raise ValueError("n must be a non-negative integer")

    result = [1]
    if n == 0:
        return result

    result.append(3)  # tri(1)

    for i in range(2, n + 1):
        if i % 2 == 0:
            result.append(1 + i // 2)
        else:
            # tri(i) = tri(i - 1) + tri(i - 2) + tri(i + 1)
            # for odd i, i + 1 is even, so it can be computed directly
            next_even = 1 + (i + 1) // 2
            result.append(result[i - 1] + result[i - 2] + next_even)

    return result
candidate = tri


def check(candidate):

    # Check some simple cases
    
    assert candidate(3) == [1, 3, 2.0, 8.0]
    assert candidate(4) == [1, 3, 2.0, 8.0, 3.0]
    assert candidate(5) == [1, 3, 2.0, 8.0, 3.0, 15.0]
    assert candidate(6) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0]
    assert candidate(7) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0]
    assert candidate(8) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0]
    assert candidate(9) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0]
    assert candidate(20) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0, 6.0, 48.0, 7.0, 63.0, 8.0, 80.0, 9.0, 99.0, 10.0, 120.0, 11.0]

    # Check some edge cases that are easy to work out by hand.
    assert candidate(0) == [1]
    assert candidate(1) == [1, 3]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
