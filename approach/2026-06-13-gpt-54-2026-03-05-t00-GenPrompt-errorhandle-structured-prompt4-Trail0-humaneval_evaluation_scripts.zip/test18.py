
import unittest
import re
import sys
import math
import copy



def how_many_times(string: str, substring: str) -> int:
    """Find how many times a given substring can be found in the original string.
    Count overlapping cases.

    >>> how_many_times('', 'a')
    0
    >>> how_many_times('aaa', 'a')
    3
    >>> how_many_times('aaaa', 'aa')
    3
    """
    if not isinstance(string, str):
        raise TypeError("string must be of type str")
    if not isinstance(substring, str):
        raise TypeError("substring must be of type str")
    if substring == "":
        raise ValueError("substring must not be empty")

    count = 0
    start = 0

    while True:
        index = string.find(substring, start)
        if index == -1:
            break
        count += 1
        start = index + 1

    return count
candidate = how_many_times




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('', 'x') == 0
    assert candidate('xyxyxyx', 'x') == 4
    assert candidate('cacacacac', 'cac') == 4
    assert candidate('john doe', 'john') == 1


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
