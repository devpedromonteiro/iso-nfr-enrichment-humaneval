
import unittest



def _is_opening_bracket(char: str) -> bool:
    return char == "("


def _is_closing_bracket(char: str) -> bool:
    return char == ")"


def correct_bracketing(brackets: str) -> bool:
    """brackets is a string of "(" and ")".
    Return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("(")
    False
    >>> correct_bracketing("()")
    True
    >>> correct_bracketing("(()())")
    True
    >>> correct_bracketing(")(()")
    False
    """
    balance = 0

    for char in brackets:
        if _is_opening_bracket(char):
            balance += 1
        elif _is_closing_bracket(char):
            balance -= 1

        if balance < 0:
            return False

    return balance == 0
candidate = correct_bracketing


class Test(unittest.TestCase):
    def test(self):
        assert candidate("(") == False
        assert candidate("))()))((())((()()((((") == False
        assert candidate(")((((((()())())()(((") == False
        assert candidate(")((())))()(()))())") == False
        assert not candidate("(()")
        assert candidate("(()())") == True
        assert candidate("(()())()()((()()())())(()()(()))()") == True
        assert candidate("()))") == False
        assert not candidate(")")
        assert candidate("()()") == True
        assert candidate(")())()())))(((") == False
        assert candidate("))((((((()") == False
        assert candidate(")((((") == False
        assert candidate("()(()())") == True
        assert candidate("(()())()()((()()())())(()()(()))") == True
        assert candidate("((())()))") == False
        assert candidate("()()()(())(") == False
        assert candidate("))())") == False
        assert candidate("()()(()())()")
        assert candidate("()()(()())()") == True
        assert candidate(")") == False
        assert candidate("()()()") == True
        assert candidate("()))()(") == False
        assert candidate("(())") == True
        assert candidate("()()(()())()()()(()())()") == True
        assert candidate("()()(()())()()()(()())()()()((()()())())(()()(()))") == True
        assert candidate("(()())()(()())") == True
        assert candidate("(()))))()") == False
        assert candidate(")(()())(") == False
        assert candidate("((((") == False
        assert candidate("(()())")
        assert candidate("(((()") == False
        assert candidate("))()") == False
        assert candidate(")))((") == False
        assert candidate(")()())") == False
        assert candidate("(()") == False
        assert candidate("(()())(()())()") == True
        assert candidate("(()())()()(()())()") == True
        assert candidate("()()(()())()(()())()") == True
        assert not candidate("((((")
        assert candidate("))))") == False
        assert candidate("()") == True
        assert candidate("())") == False
        assert candidate(")()(())()((()())") == False
        assert candidate("))()))))(()()(") == False
        assert candidate("()())())(") == False
        assert candidate("()()()()(()())()") == True
        assert candidate(")()(") == False
        assert candidate("((((((") == False
        assert candidate("()()()((()()(") == False
        assert candidate("()()((()()())())(()()(()))()()(()())()()") == True
        assert not candidate("((()())))")
        assert candidate("()")
        assert not candidate("(")
        assert candidate("())())((()()))") == False
        assert candidate("(()())()") == True
        assert candidate(")(()))(((()((()") == False
        assert candidate("()))))") == False
        assert candidate("))())()))(())") == False
        assert candidate(")())())()") == False
        assert candidate(")((()))))((()(") == False
        assert candidate("()())())))(()(())()") == False
        assert candidate(")((((((") == False
        assert not candidate(")(()")
        assert candidate("((())()()") == False
        assert not candidate("()()(()())()))()")
        assert candidate(")(()(())((())((())") == False
        assert candidate(")(()") == False
        assert candidate(")()") == False
        assert candidate("()()(()())()()()((()()())())(()()(()))(()())") == True
        assert candidate("()()(()())()()") == True
        assert candidate("(()())()()((()()())())(()()(()))(()())") == True
        assert candidate("()()((()()())())(()()(()))")
        assert candidate("(((") == False
        assert candidate("") == True
        assert not candidate("()()(()())())(()")
        assert candidate("()(())()()()") == True
        assert candidate(")()()(()(())(") == False
        assert candidate("))()()())(())") == False

if __name__ == '__main__':
    unittest.main()
