
import unittest
import re
import sys
import math
import copy


def check_if_last_char_is_a_letter(txt):
    '''
    Create a function that returns True if the last character
    of a given string is an alphabetical character and is not
    a part of a word, and False otherwise.
    Note: "word" is a group of characters separated by space.

    Examples:
    check_if_last_char_is_a_letter("apple pie") â False
    check_if_last_char_is_a_letter("apple pi e") â True
    check_if_last_char_is_a_letter("apple pi e ") â False
    check_if_last_char_is_a_letter("") â False 
    '''
    if not isinstance(txt, str):
        raise TypeError("txt must be a string")

    if txt == "":
        return False

    if txt[-1] == " ":
        return False

    if not txt[-1].isalpha():
        return False

    # Split by spaces; if the last token is a single alphabetical character,
    # then the last character is a letter and not part of a word.
    parts = txt.split(" ")
    if not parts:
        return False

    last_part = parts[-1]
    return len(last_part) == 1 and last_part.isalpha()
candidate = check_if_last_char_is_a_letter


def check(candidate):

    # Check some simple cases
    assert candidate("apple") == False
    assert candidate("apple pi e") == True
    assert candidate("eeeee") == False
    assert candidate("A") == True
    assert candidate("Pumpkin pie ") == False
    assert candidate("Pumpkin pie 1") == False
    assert candidate("") == False
    assert candidate("eeeee e ") == False
    assert candidate("apple pie") == False
    assert candidate("apple pi e ") == False

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
