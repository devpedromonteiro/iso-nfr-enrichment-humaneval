
import unittest
import re
import sys
import math
import copy



import math
from numbers import Real


def sum_squares(lst):
    """Return the sum of squares of the ceiling of each number in lst.

    Examples:
        sum_squares([1, 2, 3]) -> 14
        sum_squares([1, 4, 9]) -> 98
        sum_squares([1, 3, 5, 7]) -> 84
        sum_squares([1.4, 4.2, 0]) -> 29
        sum_squares([-2.4, 1, 1]) -> 6
    """
    if lst is None:
        raise TypeError("lst must be an iterable of real numbers, got None")

    if isinstance(lst, (str, bytes)):
        raise TypeError("lst must be an iterable of real numbers, not a string/bytes")

    try:
        iterator = iter(lst)
    except TypeError as exc:
        raise TypeError("lst must be an iterable of real numbers") from exc

    total = 0
    for index, value in enumerate(iterator):
        if not isinstance(value, Real):
            raise TypeError(f"Element at index {index} is not a real number: {value!r}")

        if not math.isfinite(value):
            raise ValueError(f"Element at index {index} must be finite, got: {value!r}")

        rounded = math.ceil(value)
        total += rounded ** 2

    return total
candidate = sum_squares


def check(candidate):

    # Check some simple cases
    assert candidate([1,2,3])==14, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1.0,2,3])==14, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,3,5,7])==84, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1.4,4.2,0])==29, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([-2.4,1,1])==6, "This prints if this assert fails 1 (good for debugging!)"

    assert candidate([100,1,15,2])==10230, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([10000,10000])==200000000, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([-1.4,4.6,6.3])==75, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([-1.4,17.9,18.9,19.9])==1086, "This prints if this assert fails 1 (good for debugging!)"


    # Check some edge cases that are easy to work out by hand.
    assert candidate([0])==0, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([-1])==1, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([-1,1,0])==2, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
