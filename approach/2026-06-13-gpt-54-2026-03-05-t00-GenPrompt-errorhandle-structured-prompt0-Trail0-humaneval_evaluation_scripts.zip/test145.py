
import unittest
import re
import sys
import math
import copy


def order_by_points(nums):
    """
    Sort a list of integers in ascending order by the sum of their digits.
    Ties preserve original order.

    Examples:
    >>> order_by_points([1, 11, -1, -11, -12])
    [-1, -11, 1, -12, 11]
    >>> order_by_points([])
    []
    """
    if nums is None:
        raise TypeError("nums must be a list of integers, got None")

    if not isinstance(nums, list):
        raise TypeError(f"nums must be a list, got {type(nums).__name__}")

    for i, value in enumerate(nums):
        if not isinstance(value, int):
            raise TypeError(
                f"all elements in nums must be integers; "
                f"found {type(value).__name__} at index {i}"
            )

    def digit_sum(n):
        return sum(int(ch) for ch in str(abs(n)))

    # Python's sort is stable, so equal digit sums keep original order.
    try:
        return sorted(nums, key=digit_sum)
    except ValueError as exc:
        # Defensive: re-raise with clearer context while preserving failure.
        raise ValueError(f"failed to sort nums by digit sums: {exc}") from exc
candidate = order_by_points


def check(candidate):

    # Check some simple cases
    assert candidate([1, 11, -1, -11, -12]) == [-1, -11, 1, -12, 11]
    assert candidate([1234,423,463,145,2,423,423,53,6,37,3457,3,56,0,46]) == [0, 2, 3, 6, 53, 423, 423, 423, 1234, 145, 37, 46, 56, 463, 3457]
    assert candidate([]) == []
    assert candidate([1, -11, -32, 43, 54, -98, 2, -3]) == [-3, -32, -98, -11, 1, 2, 43, 54]
    assert candidate([1,2,3,4,5,6,7,8,9,10,11]) == [1, 10, 2, 11, 3, 4, 5, 6, 7, 8, 9]
    assert candidate([0,6,6,-76,-21,23,4]) == [-76, -21, 0, 4, 23, 6, 6]

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
