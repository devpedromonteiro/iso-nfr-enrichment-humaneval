
import unittest
import re
import sys
import math
import copy


def f(n):
    """Return a list of length n where the i-th element (1-based) is:
    - factorial(i) if i is even
    - sum(1..i) if i is odd

    Example:
        f(5) == [1, 2, 6, 24, 15]
    """
    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if isinstance(n, bool):
        raise TypeError("n must be an integer, not bool")
    if n < 0:
        raise ValueError("n must be non-negative")

    result = []
    factorial = 1

    for i in range(1, n + 1):
        if i % 2 == 0:
            factorial *= i
            result.append(factorial)
        else:
            result.append(i * (i + 1) // 2)

    return result
candidate = f


def check(candidate):

    assert candidate(5) == [1, 2, 6, 24, 15]
    assert candidate(7) == [1, 2, 6, 24, 15, 720, 28]
    assert candidate(1) == [1]
    assert candidate(3) == [1, 2, 6]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
