
import unittest
import re
import sys
import math
import copy



def truncate_number(number: float) -> float:
    """Return the decimal part of a positive number.

    The decimal part is the leftover after removing the integer part.

    Args:
        number: A positive int or float.

    Returns:
        The decimal part as a float.

    Raises:
        TypeError: If number is not an int or float.
        ValueError: If number is negative.

    >>> truncate_number(3.5)
    0.5
    >>> truncate_number(2.0)
    0.0
    """
    if not isinstance(number, (int, float)):
        raise TypeError("number must be an int or float")

    if number < 0:
        raise ValueError("number must be positive")

    return number - int(number)
candidate = truncate_number




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(3.5) == 0.5
    assert abs(candidate(1.33) - 0.33) < 1e-6
    assert abs(candidate(123.456) - 0.456) < 1e-6


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
