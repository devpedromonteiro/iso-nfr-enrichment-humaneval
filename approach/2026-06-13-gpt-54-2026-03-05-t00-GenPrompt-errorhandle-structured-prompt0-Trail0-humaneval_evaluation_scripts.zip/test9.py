
import unittest
import re
import sys
import math
import copy

from typing import List, Tuple


from typing import List


def rolling_max(numbers: List[int]) -> List[int]:
    """From a given list of integers, generate a list of rolling maximum
    element found until a given moment in the sequence.

    >>> rolling_max([1, 2, 3, 2, 3, 4, 2])
    [1, 2, 3, 3, 3, 4, 4]
    """
    if numbers is None:
        raise TypeError("numbers must be a list of integers, got None")

    if not isinstance(numbers, list):
        raise TypeError(f"numbers must be of type list, got {type(numbers).__name__}")

    if not numbers:
        return []

    if not all(isinstance(n, int) for n in numbers):
        raise ValueError("all elements in numbers must be integers")

    result: List[int] = []
    current_max = numbers[0]

    for number in numbers:
        if number > current_max:
            current_max = number
        result.append(current_max)

    return result
candidate = rolling_max




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == []
    assert candidate([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert candidate([4, 3, 2, 1]) == [4, 4, 4, 4]
    assert candidate([3, 2, 3, 100, 3]) == [3, 3, 3, 100, 100]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
