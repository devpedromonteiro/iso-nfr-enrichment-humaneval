
import unittest
import re
import sys
import math
import copy


def specialFilter(nums):
    """Return the count of numbers > 10 whose first and last digits are odd.

    A number qualifies if:
    - it is an integer
    - it is greater than 10
    - its first digit is odd
    - its last digit is odd

    Examples:
        specialFilter([15, -73, 14, -15]) -> 1
        specialFilter([33, -2, -3, 45, 21, 109]) -> 2
    """
    if nums is None:
        raise TypeError("nums must be an iterable of integers, got None")

    if not isinstance(nums, (list, tuple)):
        raise TypeError(f"nums must be a list or tuple of integers, got {type(nums).__name__}")

    count = 0

    for i, num in enumerate(nums):
        if not isinstance(num, int):
            raise TypeError(f"all elements must be integers; element at index {i} is {type(num).__name__}")

        if num <= 10:
            continue

        num_str = str(abs(num))
        first_digit = int(num_str[0])
        last_digit = int(num_str[-1])

        if first_digit % 2 == 1 and last_digit % 2 == 1:
            count += 1

    return count
candidate = specialFilter


def check(candidate):

    # Check some simple cases
    assert candidate([5, -2, 1, -5]) == 0  
    assert candidate([15, -73, 14, -15]) == 1
    assert candidate([33, -2, -3, 45, 21, 109]) == 2
    assert candidate([43, -12, 93, 125, 121, 109]) == 4
    assert candidate([71, -2, -33, 75, 21, 19]) == 3


    # Check some edge cases that are easy to work out by hand.
    assert candidate([1]) == 0              
    assert candidate([]) == 0                   



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
