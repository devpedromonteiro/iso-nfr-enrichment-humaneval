
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    You are given a positive integer n. You have to create an integer array a of length n.
    For each i (1 â¤ i â¤ n), the value of a[i] = i * i - i + 1.
    Return the number of triples (a[i], a[j], a[k]) where i < j < k,
    and a[i] + a[j] + a[k] is a multiple of 3.

    Example:
        Input: n = 5
        Output: 1
    """
    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if isinstance(n, bool):
        raise TypeError("n must be an integer, not bool")
    if n <= 0:
        raise ValueError("n must be a positive integer")

    try:
        # a[i] = i^2 - i + 1
        # Mod 3 pattern for i:
        # i % 3 == 0 -> a[i] % 3 == 1
        # i % 3 == 1 -> a[i] % 3 == 1
        # i % 3 == 2 -> a[i] % 3 == 0
        #
        # Valid triple sums divisible by 3 are:
        # (0,0,0) and (1,1,1)
        #
        # Count how many indices produce each residue.
        count_0 = n // 3                  # i % 3 == 2
        count_1 = n - count_0             # i % 3 == 0 or 1

        def comb3(x):
            if x < 3:
                return 0
            return x * (x - 1) * (x - 2) // 6

        return comb3(count_0) + comb3(count_1)

    except OverflowError:
        raise OverflowError("calculation overflowed while computing triples")
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
