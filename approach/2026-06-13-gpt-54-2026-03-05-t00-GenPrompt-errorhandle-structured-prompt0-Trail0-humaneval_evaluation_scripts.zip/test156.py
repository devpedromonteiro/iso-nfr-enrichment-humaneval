
import unittest
import re
import sys
import math
import copy


def int_to_mini_roman(number):
    """
    Given a positive integer, obtain its roman numeral equivalent as a string,
    and return it in lowercase.
    Restrictions: 1 <= num <= 1000

    Examples:
    >>> int_to_mini_roman(19) == 'xix'
    True
    >>> int_to_mini_roman(152) == 'clii'
    True
    >>> int_to_mini_roman(426) == 'cdxxvi'
    True
    """
    if isinstance(number, bool):
        raise TypeError("number must be an integer between 1 and 1000, not bool")

    if not isinstance(number, int):
        raise TypeError("number must be an integer")

    if number < 1 or number > 1000:
        raise ValueError("number must be between 1 and 1000 inclusive")

    roman_map = [
        (1000, "M"),
        (900, "CM"),
        (500, "D"),
        (400, "CD"),
        (100, "C"),
        (90, "XC"),
        (50, "L"),
        (40, "XL"),
        (10, "X"),
        (9, "IX"),
        (5, "V"),
        (4, "IV"),
        (1, "I"),
    ]

    result = []
    remaining = number

    for value, numeral in roman_map:
        count, remaining = divmod(remaining, value)
        if count:
            result.append(numeral * count)

    return "".join(result).lower()
candidate = int_to_mini_roman


def check(candidate):

    # Check some simple cases
    assert candidate(19) == 'xix'
    assert candidate(152) == 'clii'
    assert candidate(251) == 'ccli'
    assert candidate(426) == 'cdxxvi'
    assert candidate(500) == 'd'
    assert candidate(1) == 'i'
    assert candidate(4) == 'iv'
    assert candidate(43) == 'xliii'
    assert candidate(90) == 'xc'
    assert candidate(94) == 'xciv'
    assert candidate(532) == 'dxxxii'
    assert candidate(900) == 'cm'
    assert candidate(994) == 'cmxciv'
    assert candidate(1000) == 'm'

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
