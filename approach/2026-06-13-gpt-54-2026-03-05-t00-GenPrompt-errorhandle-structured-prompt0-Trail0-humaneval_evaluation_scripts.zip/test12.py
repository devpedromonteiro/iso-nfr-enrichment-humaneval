
import unittest
import re
import sys
import math
import copy

from typing import List, Optional


from typing import List, Optional


def longest(strings: List[str]) -> Optional[str]:
    """Out of list of strings, return the longest one.

    Return the first one in case of multiple strings of the same length.
    Return None in case the input list is empty.

    >>> longest([])

    >>> longest(['a', 'b', 'c'])
    'a'
    >>> longest(['a', 'bb', 'ccc'])
    'ccc'
    """
    if strings is None:
        raise TypeError("strings must be a list of strings, got None")

    if not isinstance(strings, list):
        raise TypeError(f"strings must be a list, got {type(strings).__name__}")

    if not strings:
        return None

    longest_string: Optional[str] = None

    for index, value in enumerate(strings):
        if not isinstance(value, str):
            raise TypeError(
                f"all elements must be strings; element at index {index} "
                f"is {type(value).__name__}"
            )

        if longest_string is None or len(value) > len(longest_string):
            longest_string = value

    return longest_string
candidate = longest




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == None
    assert candidate(['x', 'y', 'z']) == 'x'
    assert candidate(['x', 'yyy', 'zzzz', 'www', 'kkkk', 'abc']) == 'zzzz'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
