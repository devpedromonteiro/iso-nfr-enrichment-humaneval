
import unittest
import re
import sys
import math
import copy


def add(lst):
    """Return the sum of even elements located at odd indices.

    Args:
        lst: A non-empty list of integers.

    Returns:
        The sum of values that are even and whose index is odd.

    Raises:
        TypeError: If lst is not a list, or contains non-integer elements.
        ValueError: If lst is empty.

    Examples:
        add([4, 2, 6, 7]) == 2
    """
    if not isinstance(lst, list):
        raise TypeError("lst must be a list")

    if not lst:
        raise ValueError("lst must be a non-empty list")

    for i, value in enumerate(lst):
        if not isinstance(value, int):
            raise TypeError(f"all elements must be integers; found {type(value).__name__} at index {i}")

    total = 0
    for i in range(1, len(lst), 2):
        if lst[i] % 2 == 0:
            total += lst[i]

    return total
candidate = add


def check(candidate):

    # Check some simple cases
    assert candidate([4, 88]) == 88
    assert candidate([4, 5, 6, 7, 2, 122]) == 122
    assert candidate([4, 0, 6, 7]) == 0
    assert candidate([4, 4, 6, 8]) == 12

    # Check some edge cases that are easy to work out by hand.
    


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
