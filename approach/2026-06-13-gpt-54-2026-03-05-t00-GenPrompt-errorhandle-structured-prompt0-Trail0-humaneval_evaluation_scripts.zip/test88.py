
import unittest
import re
import sys
import math
import copy


def sort_array(array):
    """
    Given an array of non-negative integers, return a copy of the given array after sorting.
    Sort in ascending order if the sum of the first and last values is odd,
    otherwise sort in descending order if that sum is even.

    Note:
    * don't change the given array.

    Examples:
    * sort_array([]) => []
    * sort_array([5]) => [5]
    * sort_array([2, 4, 3, 0, 1, 5]) => [0, 1, 2, 3, 4, 5]
    * sort_array([2, 4, 3, 0, 1, 5, 6]) => [6, 5, 4, 3, 2, 1, 0]
    """
    if not isinstance(array, list):
        raise TypeError("array must be a list of non-negative integers")

    if not array:
        return []

    if len(array) == 1:
        value = array[0]
        if not isinstance(value, int) or isinstance(value, bool):
            raise TypeError("array must contain only non-negative integers")
        if value < 0:
            raise ValueError("array must contain only non-negative integers")
        return [value]

    for value in array:
        if not isinstance(value, int) or isinstance(value, bool):
            raise TypeError("array must contain only non-negative integers")
        if value < 0:
            raise ValueError("array must contain only non-negative integers")

    result = list(array)

    first_last_sum = result[0] + result[-1]
    if first_last_sum % 2 == 1:
        result.sort()
    else:
        result.sort(reverse=True)

    return result
candidate = sort_array


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([]) == [], "Error"
    assert candidate([5]) == [5], "Error"
    assert candidate([2, 4, 3, 0, 1, 5]) == [0, 1, 2, 3, 4, 5], "Error"
    assert candidate([2, 4, 3, 0, 1, 5, 6]) == [6, 5, 4, 3, 2, 1, 0], "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([2, 1]) == [1, 2], "Error"
    assert candidate([15, 42, 87, 32 ,11, 0]) == [0, 11, 15, 32, 42, 87], "Error"
    assert candidate([21, 14, 23, 11]) == [23, 21, 14, 11], "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
