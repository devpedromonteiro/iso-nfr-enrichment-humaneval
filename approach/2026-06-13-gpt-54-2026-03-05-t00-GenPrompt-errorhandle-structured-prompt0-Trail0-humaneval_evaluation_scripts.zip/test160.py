
import unittest
import re
import sys
import math
import copy


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and
    the second list is a list of integers. Use the two given lists to build the algebraic
    expression and return the evaluation of this expression.

    Supported operations:
    Addition ( + )
    Subtraction ( - )
    Multiplication ( * )
    Floor division ( // )
    Exponentiation ( ** )

    Example:
    operator = ['+', '*', '-']
    operand = [2, 3, 4, 5]
    result = 2 + 3 * 4 - 5
    => result = 9
    """
    if not isinstance(operator, list):
        raise TypeError("operator must be a list")
    if not isinstance(operand, list):
        raise TypeError("operand must be a list")

    if len(operator) < 1:
        raise ValueError("operator list must contain at least one operator")
    if len(operand) < 2:
        raise ValueError("operand list must contain at least two operands")
    if len(operator) != len(operand) - 1:
        raise ValueError("length of operator must be equal to length of operand minus one")

    valid_operators = {"+", "-", "*", "//", "**"}

    for op in operator:
        if not isinstance(op, str):
            raise TypeError(f"operator entries must be strings, got {type(op).__name__}")
        if op not in valid_operators:
            raise ValueError(f"unsupported operator: {op}")

    for value in operand:
        if not isinstance(value, int):
            raise TypeError(f"operand entries must be integers, got {type(value).__name__}")
        if value < 0:
            raise ValueError(f"operand entries must be non-negative integers, got {value}")

    expression = [operand[0]]
    for op, value in zip(operator, operand[1:]):
        expression.extend([op, value])

    try:
        result = expression[0]
        i = 1

        # First pass: handle ** with right associativity
        temp = [result]
        while i < len(expression):
            op = expression[i]
            val = expression[i + 1]
            temp.extend([op, val])
            i += 2

        # Resolve exponentiation right-to-left
        stack = []
        i = len(temp) - 1
        current = temp[i]
        i -= 1
        while i >= 0:
            op = temp[i]
            left = temp[i - 1]
            if op == "**":
                current = left ** current
            else:
                stack.append(current)
                stack.append(op)
                current = left
            i -= 2
        stack.append(current)
        stack.reverse()

        # Second pass: handle * and //
        reduced = [stack[0]]
        i = 1
        while i < len(stack):
            op = stack[i]
            val = stack[i + 1]
            if op == "*":
                reduced[-1] = reduced[-1] * val
            elif op == "//":
                if val == 0:
                    raise ZeroDivisionError("floor division by zero")
                reduced[-1] = reduced[-1] // val
            else:
                reduced.extend([op, val])
            i += 2

        # Third pass: handle + and -
        result = reduced[0]
        i = 1
        while i < len(reduced):
            op = reduced[i]
            val = reduced[i + 1]
            if op == "+":
                result += val
            elif op == "-":
                result -= val
            i += 2

        return result

    except OverflowError:
        raise
    except ZeroDivisionError:
        raise
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
