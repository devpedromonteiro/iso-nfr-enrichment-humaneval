
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[2] * x^2 + .... + xs[n] * x^n
    """
    if not isinstance(xs, list):
        raise TypeError("xs must be a list of numeric coefficients")
    if len(xs) == 0:
        raise ValueError("xs must not be empty")
    if not isinstance(x, (int, float)):
        raise TypeError("x must be a numeric value")

    total = 0.0
    for i, coeff in enumerate(xs):
        if not isinstance(coeff, (int, float)):
            raise TypeError(f"coefficient at index {i} must be numeric")
        total += coeff * math.pow(x, i)
    return total


def find_zero(xs: list):
    """xs are coefficients of a polynomial.
    find_zero finds x such that poly(x) = 0.
    find_zero returns only one zero point, even if there are many.
    Moreover, find_zero only takes list xs having even number of coefficients
    and largest non-zero coefficient as it guarantees a solution.

    >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2)  # (x - 1) * (x - 2) * (x - 3)
    1.0
    """
    if not isinstance(xs, list):
        raise TypeError("xs must be a list of numeric coefficients")
    if len(xs) == 0:
        raise ValueError("xs must not be empty")
    if len(xs) % 2 != 0:
        raise ValueError("xs must contain an even number of coefficients")

    for i, coeff in enumerate(xs):
        if not isinstance(coeff, (int, float)):
            raise TypeError(f"coefficient at index {i} must be numeric")

    if all(coeff == 0 for coeff in xs):
        raise ValueError("zero polynomial has infinitely many zeros")

    degree = None
    leading_coeff = None
    for i in range(len(xs) - 1, -1, -1):
        if xs[i] != 0:
            degree = i
            leading_coeff = xs[i]
            break

    if degree is None:
        raise ValueError("could not determine polynomial degree")

    if degree % 2 == 0:
        raise ValueError("polynomial degree must be odd to guarantee a real zero")

    # Since odd-degree polynomials always have at least one real root,
    # search for a sign change and then apply bisection.
    def f(val):
        return poly(xs, val)

    if degree == 1:
        if leading_coeff == 0:
            raise ValueError("invalid linear polynomial: leading coefficient is zero")
        return -xs[0] / xs[1]

    left = -1.0
    right = 1.0
    f_left = f(left)
    f_right = f(right)

    if f_left == 0:
        return left
    if f_right == 0:
        return right

    max_iterations = 10_000

    for _ in range(max_iterations):
        if f_left * f_right < 0:
            break

        left *= 2
        right *= 2
        f_left = f(left)
        f_right = f(right)

        if f_left == 0:
            return left
        if f_right == 0:
            return right
    else:
        raise RuntimeError("failed to bracket a root for the polynomial")

    # Bisection method
    tolerance = 1e-12
    for _ in range(max_iterations):
        mid = (left + right) / 2.0
        f_mid = f(mid)

        if abs(f_mid) < tolerance or abs(right - left) < tolerance:
            return mid

        if f_left * f_mid < 0:
            right = mid
            f_right = f_mid
        else:
            left = mid
            f_left = f_mid

    raise RuntimeError("bisection did not converge")
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
