
import unittest



def change_base(x: int, base: int):
    """Change numerical base of input number x to base.
    Return string representation after the conversion.
    Base numbers are less than 10.

    >>> change_base(8, 3)
    '22'
    >>> change_base(8, 2)
    '1000'
    >>> change_base(7, 2)
    '111'
    """
    if not isinstance(x, int):
        raise TypeError(f"x must be an int, got {type(x).__name__}")
    if not isinstance(base, int):
        raise TypeError(f"base must be an int, got {type(base).__name__}")

    if base < 2 or base >= 10:
        raise ValueError("base must be an integer between 2 and 9 inclusive")

    if x == 0:
        return "0"

    negative = x < 0
    x = abs(x)

    digits = []
    while x > 0:
        digits.append(str(x % base))
        x //= base

    result = ''.join(reversed(digits))
    return f"-{result}" if negative else result
candidate = change_base


class Test(unittest.TestCase):
    def test(self):
        assert candidate(4253, 6) == '31405'
        assert candidate(490, 6) == '2134'
        assert candidate(2175, 7) == '6225'
        assert candidate(3158, 8) == '6126'
        assert candidate(402, 2) == '110010010'
        assert candidate(5951, 8) == '13477'
        assert candidate(5401, 6) == '41001'
        assert candidate(4972, 8) == '11554'
        assert candidate(3984, 6) == '30240'
        assert candidate(3547, 6) == '24231'
        assert candidate(7, 2) == "111"
        assert candidate(5798, 8) == '13246'
        assert candidate(8, 3) == "22"
        assert candidate(4930, 2) == '1001101000010'
        assert candidate(16, 2) == "10000"
        assert candidate(6140, 9) == '8372'
        assert candidate(3980, 2) == '111110001100'
        assert candidate(4039, 7) == '14530'
        assert candidate(1054, 5) == '13204'
        assert candidate(1839, 7) == '5235'
        assert candidate(213, 2) == '11010101'
        assert candidate(650, 5) == '10100'
        assert candidate(6675, 4) == '1220103'
        assert candidate(2968, 4) == '232120'
        assert candidate(2878, 7) == '11251'
        assert candidate(2362, 2) == '100100111010'
        assert candidate(6821, 4) == '1222211'
        assert candidate(3431, 6) == '23515'
        assert candidate(803, 9) == '1082'
        assert candidate(9239, 4) == '2100113'
        assert candidate(8345, 8) == '20231'
        assert candidate(4409, 9) == '6038'
        assert candidate(9784, 3) == '111102101'
        assert candidate(967, 4) == '33013'
        assert candidate(4983, 5) == '124413'
        assert candidate(624, 3) == '212010'
        assert candidate(2739, 4) == '222303'
        assert candidate(3244, 9) == '4404'
        assert candidate(5364, 3) == '21100200'
        assert candidate(1125, 8) == '2145'
        assert candidate(9135, 5) == '243020'
        assert candidate(1083, 4) == '100323'
        assert candidate(729, 4) == '23121'
        assert candidate(6813, 2) == '1101010011101'
        assert candidate(1002, 4) == '33222'
        assert candidate(8845, 2) == '10001010001101'
        assert candidate(9431, 8) == '22327'
        assert candidate(5567, 3) == '21122012'
        assert candidate(1393, 3) == '1220121'
        assert candidate(606, 6) == '2450'
        assert candidate(2581, 6) == '15541'
        assert candidate(6325, 2) == '1100010110101'
        assert candidate(4273, 2) == '1000010110001'
        assert candidate(7136, 7) == '26543'
        assert candidate(9106, 3) == '110111021'
        assert candidate(6227, 2) == '1100001010011'
        assert candidate(2947, 7) == '11410'
        assert candidate(1273, 7) == '3466'
        assert candidate(x, x + 1) == str(x)
        assert candidate(9631, 9) == '14181'
        assert candidate(1107, 4) == '101103'
        assert candidate(4069, 3) == '12120201'
        assert candidate(7251, 3) == '100221120'
        assert candidate(3702, 9) == '5063'
        assert candidate(3336, 8) == '6410'
        assert candidate(4467, 3) == '20010110'
        assert candidate(7268, 7) == '30122'
        assert candidate(3853, 8) == '7415'
        assert candidate(9561, 9) == '14103'
        assert candidate(4924, 5) == '124144'
        assert candidate(2054, 2) == '100000000110'
        assert candidate(2283, 7) == '6441'
        assert candidate(4636, 7) == '16342'
        assert candidate(2010, 3) == '2202110'
        assert candidate(6698, 5) == '203243'
        assert candidate(8257, 4) == '2001001'
        assert candidate(8642, 4) == '2013002'
        assert candidate(5732, 4) == '1121210'
        assert candidate(3541, 7) == '13216'
        assert candidate(4101, 6) == '30553'
        assert candidate(9614, 3) == '111012002'
        assert candidate(4838, 8) == '11346'
        assert candidate(234, 2) == "11101010"
        assert candidate(6899, 9) == '10415'
        assert candidate(5180, 8) == '12074'
        assert candidate(4932, 2) == '1001101000100'
        assert candidate(4905, 8) == '11451'
        assert candidate(1649, 4) == '121301'
        assert candidate(4712, 2) == '1001001101000'
        assert candidate(1214, 4) == '102332'
        assert candidate(5750, 3) == '21212222'
        assert candidate(7434, 7) == '30450'
        assert candidate(3896, 8) == '7470'
        assert candidate(4229, 8) == '10205'
        assert candidate(9, 3) == "100"
        assert candidate(8825, 4) == '2021321'
        assert candidate(6876, 6) == '51500'
        assert candidate(3310, 9) == '4477'
        assert candidate(3083, 9) == '4205'
        assert candidate(7864, 8) == '17270'
        assert candidate(5232, 3) == '21011210'
        assert candidate(9657, 9) == '14220'
        assert candidate(8, 2) == "1000"
        assert candidate(8520, 6) == '103240'
        assert candidate(9799, 9) == '14387'
        assert candidate(9202, 8) == '21762'
        assert candidate(8499, 6) == '103203'
        assert candidate(8415, 3) == '102112200'
        assert candidate(7875, 9) == '11720'
        assert candidate(3238, 8) == '6246'
        assert candidate(865, 4) == '31201'
        assert candidate(3565, 8) == '6755'
        assert candidate(3335, 6) == '23235'
        assert candidate(9822, 4) == '2121132'
        assert candidate(5557, 9) == '7554'
        assert candidate(1459, 5) == '21314'
        assert candidate(3522, 9) == '4743'
        assert candidate(8615, 9) == '12732'
        assert candidate(978, 6) == '4310'
        assert candidate(8969, 4) == '2030021'
        assert candidate(1824, 6) == '12240'
        assert candidate(5625, 3) == '21201100'
        assert candidate(3586, 8) == '7002'
        assert candidate(2646, 5) == '41041'
        assert candidate(2034, 7) == '5634'
        assert candidate(2721, 6) == '20333'
        assert candidate(2955, 9) == '4043'
        assert candidate(8371, 6) == '102431'
        assert candidate(4868, 5) == '123433'
        assert candidate(2109, 7) == '6102'
        assert candidate(8222, 2) == '10000000011110'
        assert candidate(558, 8) == '1056'
        assert candidate(1548, 8) == '3014'

if __name__ == '__main__':
    unittest.main()
