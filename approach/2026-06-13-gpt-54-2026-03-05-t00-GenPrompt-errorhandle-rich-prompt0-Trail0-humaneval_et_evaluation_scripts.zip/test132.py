
import unittest


def is_nested(string):
    '''
    Create a function that takes a string as input which contains only square brackets.
    The function should return True if and only if there is a valid subsequence of brackets
    where at least one bracket in the subsequence is nested.

    is_nested('[[]]') â True
    is_nested('[]]]]]]][[[[[]') â False
    is_nested('[][]') â False
    is_nested('[]') â False
    is_nested('[[][]]') â True
    is_nested('[[]][[') â True
    '''
    if not isinstance(string, str):
        raise TypeError("string must be of type str")

    invalid_chars = set(string) - {'[', ']'}
    if invalid_chars:
        raise ValueError(
            "string must contain only square brackets '[' and ']'"
        )

    balance = 0
    max_depth = 0

    for char in string:
        if char == '[':
            balance += 1
            if balance > max_depth:
                max_depth = balance
        elif char == ']':
            if balance > 0:
                balance -= 1

    return max_depth >= 2
candidate = is_nested


class Test(unittest.TestCase):
    def test(self):
        assert candidate('[[]') == False
        assert candidate("[]]]][[]") == False
        assert candidate('[]]]]]]][[[[[]') == False
        assert candidate("][[[[]]") == True
        assert candidate("[][[][][") == True
        assert candidate(('[]')) == False
        assert candidate("[][][[[[[]]") == True
        assert candidate('[[]][[') == True
        assert candidate("][][[") == False
        assert candidate('') == False
        assert candidate("[]][") == False
        assert candidate("][][][]]]") == True
        assert candidate("]][[[[][][]") == True
        assert candidate("[[[]][][[") == True
        assert candidate("b") == False
        assert candidate("][][][]") == True
        assert candidate("[[[][]]][") == True
        assert candidate("][]]]]]]]") == False
        assert candidate("[][[[]") == False
        assert candidate("]][][]]") == True
        assert candidate('[][][[]]') == True
        assert candidate("[]]][[[") == False
        assert candidate("[]][[[[]]") == True
        assert candidate("][][[][]") == True
        assert candidate("[][[]") == False
        assert candidate('[[[[[[[[') == False
        assert candidate("]]]]][][]][[[]") == True
        assert candidate("][[]]") == True
        assert candidate("][]]][][[][]") == True
        assert candidate("]]]][[]][") == True
        assert candidate("][[][]") == True
        assert candidate('[[]]') == True
        assert candidate("[]]]][") == False
        assert candidate("gv") == False
        assert candidate("[[[[][[[") == False
        assert candidate("]][][][]]") == True
        assert candidate("]]]][][]]]]") == True
        assert candidate("][]]]][[]]") == True
        assert candidate("][[[") == False
        assert candidate("][[[]]]") == True
        assert candidate("[[][]") == True
        assert candidate("][[[]") == False
        assert candidate("][]][]") == False
        assert candidate("]]][") == False
        assert candidate("[[[[]]][[[[]") == True
        assert candidate("ol") == False
        assert candidate("][[][][[") == True
        assert candidate("][[]]]") == True
        assert candidate("]][[") == False
        assert candidate("][]]") == False
        assert candidate("][][]][[[") == True
        assert candidate("ljv") == False
        assert candidate('[[[[]]]]') == True
        assert candidate("]]][[") == False
        assert candidate("[]]]]") == False
        assert candidate("][[]") == False
        assert candidate("][]]]]") == False
        assert candidate("]][[]]]][[][") == True
        assert candidate("][[][[]") == True
        assert candidate("[[[[[][][[") == True
        assert candidate("][]][][") == False
        assert candidate("adx") == False
        assert candidate("][]][") == False
        assert candidate("[[]][][]]") == True
        assert candidate("[][[[]][]]]") == True
        assert candidate("][[[]][") == True
        assert candidate("]]]") == False
        assert candidate("][[]]][][]][") == True
        assert candidate("[[]]]") == True
        assert candidate("uh") == False
        assert candidate("]][]][[][") == False
        assert candidate("]]]]]][]") == False
        assert candidate("]]]]]") == False
        assert candidate(']]]]]]]]') == False
        assert candidate("[]]][[]][") == True
        assert candidate("[[][]]]]") == True
        assert candidate("[]][][[]]") == True
        assert candidate("][]]][][]]") == True
        assert candidate("[]]][[[[[]") == False
        assert candidate("]]]]]][[[") == False
        assert candidate("]]][[][[[") == False
        assert candidate("]]][]]]]][[[][[") == False
        assert candidate("[[[[][") == False
        assert candidate("[][]][[[]][[[][") == True
        assert candidate("[[[]]]") == True
        assert candidate("]][]][]]][") == True
        assert candidate("[[][][]") == True
        assert candidate('[][]') == False
        assert candidate("]][") == False
        assert candidate("[]][[]]]") == True
        assert candidate("[][]]") == True
        assert candidate("][[") == False
        assert candidate("]][][[") == False
        assert candidate("]]][[]][][]][[][]]") == True
        assert candidate("]][[[[") == False
        assert candidate("]]][][[[[][]]") == True
        assert candidate("][[]][[[[") == True
        assert candidate("c") == False
        assert candidate("]][[]]") == True
        assert candidate("[]][][][]") == True
        assert candidate("][]][[[") == False
        assert candidate("[]]]][[]]][][]") == True
        assert candidate("]]]][[[[") == False
        assert candidate("[[[[[[[[][]]") == True
        assert candidate("[][][[") == False
        assert candidate("][[][[[[") == False
        assert candidate("]]]][]") == False
        assert candidate("]][[[][][[[") == True
        assert candidate("[[[[[[") == False
        assert candidate("[][[") == False
        assert candidate('[]]]]]]]]]]') == False
        assert candidate('[[][]]') == True

    # Check some edge cases that are easy to work out by hand.
        assert candidate("[][[][]]]]") == True
        assert candidate('[]]') == False
        assert candidate("][]]][[") == False
        assert candidate("[][[][[][") == True
        assert candidate("[]][[") == False
        assert candidate("[][]][]][") == True
        assert candidate("[[]][[") == True
        assert candidate("[[[[]]][[[[[") == True
        assert candidate("uz") == False
        assert candidate("]][]]]]") == False
        assert candidate("[[[]][][][]") == True
        assert candidate("]]][[]][[") == True
        assert candidate("[]][]") == False
        assert candidate("[][][[[[[][") == True
        assert candidate("h") == False
        assert candidate("[]]]]][[]") == False

if __name__ == '__main__':
    unittest.main()
