
import unittest

from typing import List


from typing import List


def sort_numbers(numbers: str) -> str:
    """Input is a space-delimited string of numerals from 'zero' to 'nine'.
    Valid choices are 'zero', 'one', 'two', 'three', 'four', 'five',
    'six', 'seven', 'eight' and 'nine'.

    Return the string with numbers sorted from smallest to largest.

    >>> sort_numbers('three one five')
    'one three five'
    """
    number_order = {
        "zero": 0,
        "one": 1,
        "two": 2,
        "three": 3,
        "four": 4,
        "five": 5,
        "six": 6,
        "seven": 7,
        "eight": 8,
        "nine": 9,
    }

    words: List[str] = numbers.split()
    sorted_words = sorted(words, key=lambda word: number_order[word])
    return " ".join(sorted_words)
candidate = sort_numbers


class Test(unittest.TestCase):
    def test(self):
        assert candidate("one six one six six seven") == 'one one six six six seven'
        assert candidate("one nine one six six") == 'one one six six nine'
        assert candidate("one") == 'one'
        assert candidate("five six eight six two three nine eight nine") == 'two three five six six eight eight nine nine'
        assert candidate("six zero three eight five one two two seven") == 'zero one two two three five six seven eight'
        assert candidate("eight five one eight five one") == 'one one five five eight eight'
        assert candidate("seven one one four seven seven") == 'one one four seven seven seven'
        assert candidate("two three four five eight nine") == 'two three four five eight nine'
        assert candidate("four four three six") == 'three four four six'
        assert candidate("three six four three zero") == 'zero three three four six'
        assert candidate("nine one six four") == 'one four six nine'
        assert candidate("seven one zero nine eight") == 'zero one seven eight nine'
        assert candidate("three eight one one zero") == 'zero one one three eight'
        assert candidate("five four five two six two zero") == 'zero two two four five five six'
        assert candidate("eight zero zero six") == 'zero zero six eight'
        assert candidate("two three six seven nine four zero") == 'zero two three four six seven nine'
        assert candidate("five zero five three four nine") == 'zero three four five five nine'
        assert candidate("six eight eight two six zero") == 'zero two six six eight eight'
        assert candidate("five eight three nine") == 'three five eight nine'
        assert candidate("one two") == 'one two'
        assert candidate("two eight eight zero seven seven one four") == 'zero one two four seven seven eight eight'
        assert candidate("five nine two four eight") == 'two four five eight nine'
        assert candidate("four five five one one") == 'one one four five five'
        assert candidate("six seven one three two eight") == 'one two three six seven eight'
        assert candidate("four eight four nine three four three five eight") == 'three three four four four five eight eight nine'
        assert candidate("seven two six nine two zero zero") == 'zero zero two two six seven nine'
        assert candidate("seven two one four one nine five five") == 'one one two four five five seven nine'
        assert candidate("four zero two five") == 'zero two four five'
        assert candidate("eight") == 'eight'
        assert candidate("five three nine four one") == 'one three four five nine'
        assert candidate("eight eight zero two two nine four zero") == 'zero zero two two four eight eight nine'
        assert candidate("three five three nine zero") == 'zero three three five nine'
        assert candidate("five zero one zero four eight") == 'zero zero one four five eight'
        assert candidate("six three") == 'three six'
        assert candidate("seven zero") == 'zero seven'
        assert candidate("seven zero three four four") == 'zero three four four seven'
        assert candidate("six one seven two nine six two zero seven") == 'zero one two two six six seven seven nine'
        assert candidate("four three zero") == 'zero three four'
        assert candidate("five six nine nine nine eight") == 'five six eight nine nine nine'
        assert candidate("seven") == 'seven'
        assert candidate("eight one five five six one") == 'one one five five six eight'
        assert candidate("three two four two eight five") == 'two two three four five eight'
        assert candidate("two one two nine eight seven eight") == 'one two two seven eight eight nine'
        assert candidate("five nine eight zero zero four five") == 'zero zero four five five eight nine'
        assert candidate("six nine three") == 'three six nine'
        assert candidate("seven six four five six eight four") == 'four four five six six seven eight'
        assert candidate("two seven zero nine three one eight") == 'zero one two three seven eight nine'
        assert candidate("four one nine three") == 'one three four nine'
        assert candidate("zero two two eight three nine four four four") == 'zero two two three four four four eight nine'
        assert candidate('three five nine') == 'three five nine'
        assert candidate("zero three") == 'zero three'
        assert candidate("three zero one nine nine three") == 'zero one three three nine nine'
        assert candidate("two one eight zero zero nine") == 'zero zero one two eight nine'
        assert candidate("nine three three four nine five five") == 'three three four five five nine nine'
        assert candidate("five five three nine three zero zero zero eight") == 'zero zero zero three three five five eight nine'
        assert candidate("four one seven") == 'one four seven'
        assert candidate("seven six") == 'six seven'
        assert candidate("four two seven") == 'two four seven'
        assert candidate("two five five one nine one two zero six") == 'zero one one two two five five six nine'
        assert candidate("eight three nine three one seven eight nine two") == 'one two three three seven eight eight nine nine'
        assert candidate("nine one three zero nine") == 'zero one three nine nine'
        assert candidate("nine three four five") == 'three four five nine'
        assert candidate("one nine seven eight two nine three two") == 'one two two three seven eight nine nine'
        assert candidate("eight three zero one five one nine") == 'zero one one three five eight nine'
        assert candidate("one five six eight five seven five six four") == 'one four five five five six six seven eight'
        assert candidate("two five four zero") == 'zero two four five'
        assert candidate("six four five one four six eight zero five") == 'zero one four four five five six six eight'
        assert candidate("zero one seven eight three") == 'zero one three seven eight'
        assert candidate("three seven two") == 'two three seven'
        assert candidate("zero three four five eight seven two eight") == 'zero two three four five seven eight eight'
        assert candidate("zero five six five eight zero three three six") == 'zero zero three three five five six six eight'
        assert candidate("nine six two three four one zero two seven") == 'zero one two two three four six seven nine'
        assert candidate("four four six four one") == 'one four four four six'
        assert candidate("eight six three") == 'three six eight'
        assert candidate("five three five") == 'three five five'
        assert candidate("seven one five five zero six four four zero") == 'zero zero one four four five five six seven'
        assert candidate("three two three four one eight five nine one") == 'one one two three three four five eight nine'
        assert candidate("eight eight seven seven two three nine two seven") == 'two two three seven seven seven eight eight nine'
        assert candidate("four") == 'four'
        assert candidate("nine two three two eight six four six") == 'two two three four six six eight nine'
        assert candidate("six zero four one") == 'zero one four six'
        assert candidate("two zero four six zero five") == 'zero zero two four five six'
        assert candidate("three six two five three six") == 'two three three five six six'
        assert candidate("nine") == 'nine'
        assert candidate("two seven eight seven four seven") == 'two four seven seven seven eight'
        assert candidate("one four eight one eight zero") == 'zero one one four eight eight'
        assert candidate("six zero one eight one four two three") == 'zero one one two three four six eight'
        assert candidate("one nine zero one nine three nine") == 'zero one one three nine nine nine'
        assert candidate("three") == 'three'
        assert candidate("three four zero") == 'zero three four'
        assert candidate("six two two seven one") == 'one two two six seven'
        assert candidate("seven three two four zero five three one") == 'zero one two three three four five seven'
        assert candidate("zero seven four seven six seven seven") == 'zero four six seven seven seven seven'
        assert candidate("five six four seven seven") == 'four five six seven seven'
        assert candidate("three two four seven one nine eight four") == 'one two three four four seven eight nine'
        assert candidate("seven five one three seven one five") == 'one one three five five seven seven'
        assert candidate("eight nine one one seven") == 'one one seven eight nine'
        assert candidate("one two four four three seven") == 'one two three four four seven'
        assert candidate("five") == 'five'
        assert candidate("three nine nine eight") == 'three eight nine nine'
        assert candidate("seven zero seven seven two five nine six") == 'zero two five six seven seven seven nine'
        assert candidate('three') == 'three'
        assert candidate('five zero four seven nine eight') == 'zero four five seven eight nine'
        assert candidate("six") == 'six'
        assert candidate('six five four three two one zero') == 'zero one two three four five six'
        assert candidate("eight five") == 'five eight'
        assert candidate('') == ''
        assert candidate("zero seven zero three two nine") == 'zero zero two three seven nine'
        assert candidate("seven two one four two eight") == 'one two two four seven eight'
        assert candidate("eight zero seven") == 'zero seven eight'
        assert candidate("five zero one one two two three") == 'zero one one two two three five'
        assert candidate("nine nine five") == 'five nine nine'
        assert candidate("four eight four two eight zero four seven") == 'zero two four four four seven eight eight'
        assert candidate("seven three") == 'three seven'
        assert candidate("seven six six seven seven two") == 'two six six seven seven seven'
        assert candidate("six five five five two one nine") == 'one two five five five six nine'
        assert candidate("six zero nine six four zero six six") == 'zero zero four six six six six nine'
        assert candidate("zero") == 'zero'
        assert candidate("nine zero") == 'zero nine'
        assert candidate("one eight five eight zero three five") == 'zero one three five five eight eight'
        assert candidate("one six two seven") == 'one two six seven'

if __name__ == '__main__':
    unittest.main()
