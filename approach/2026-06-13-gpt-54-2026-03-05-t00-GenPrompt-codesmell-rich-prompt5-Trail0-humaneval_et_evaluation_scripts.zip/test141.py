
import unittest


VALID_EXTENSIONS = {"txt", "exe", "dll"}


def _has_valid_digit_count(file_name):
    return sum(char.isdigit() for char in file_name) <= 3


def _has_single_dot(file_name):
    return file_name.count(".") == 1


def _split_name_and_extension(file_name):
    return file_name.rsplit(".", 1)


def _has_valid_base_name(base_name):
    return bool(base_name) and base_name[0].isalpha() and base_name[0].isascii()


def _has_valid_extension(extension):
    return extension in VALID_EXTENSIONS


def file_name_check(file_name):
    """Return 'Yes' if the file name is valid, otherwise return 'No'."""
    if not _has_valid_digit_count(file_name):
        return "No"

    if not _has_single_dot(file_name):
        return "No"

    base_name, extension = _split_name_and_extension(file_name)

    if not _has_valid_base_name(base_name):
        return "No"

    if not _has_valid_extension(extension):
        return "No"

    return "Yes"
candidate = file_name_check


class Test(unittest.TestCase):
    def test(self):
        assert candidate("zmz1h1ZW5.txt") == 'Yes'
        assert candidate("|ypo/e+~=yxqk@l:=n-|_w/.exe") == 'No'
        assert candidate("T|x@:8vC6.exe") == 'Yes'
        assert candidate("p90hm2.dll") == 'Yes'
        assert candidate("@_HqUwn.taP9n@IeU.dll") == 'No'
        assert candidate("AwtZe!.exe") == 'Yes'
        assert candidate('this_is_valid.txt') == 'Yes'
        assert candidate("pps:pq00f&=-e@p4oe^u1so3^8.exe") == 'No'
        assert candidate('@this1_is6_valid.exe') == 'No'
        assert candidate("svIkpyQe7pYHiedh.exe") == 'Yes'
        assert candidate("e$r=krxi#o=yevwd**z.dll") == 'Yes'
        assert candidate(".tt.txt") == 'No'
        assert candidate('Is3youfault.txt') == 'Yes'
        assert candidate("on&z+t~=su$k.txt") == 'Yes'
        assert candidate("#gk_nfFgjJg:.dll") == 'No'
        assert candidate("hpuf2oz.dll") == 'Yes'
        assert candidate("pteiqqcwqbu.w.j.txt") == 'No'
        assert candidate("ncStUyBIegxXn6HC.exe") == 'Yes'
        assert candidate("qtf&js*:$a.vk+e.txt") == 'No'
        assert candidate('final..txt') == 'No'
        assert candidate("eOky5qsos.kg.txt") == 'No'
        assert candidate("h*ujtt.~j*/l%|*i$e.dll") == 'No'
        assert candidate('final132') == 'No'
        assert candidate('/this_is_valid.dll') == 'No'
        assert candidate("zpbyutvvgq0mpoaxu.dll") == 'Yes'
        assert candidate("^/je*z?-@ylp^ai.s.txt") == 'No'
        assert candidate(".pszd.dll") == 'No'
        assert candidate("vgjgf.exe") == 'Yes'
        assert candidate("hl3tarbv4uwywwr.exe") == 'Yes'
        assert candidate('I563_Yes3.txtt') == 'No'
        assert candidate("uw26lmhi4y0af.txt") == 'No'
        assert candidate("~%/-qvn&_:g|rcs&g-ky#.txt") == 'No'
        assert candidate('s1sdf3.asd') == 'No'
        assert candidate('His12FILE94.exe') == 'No'
        assert candidate("0i7q0uqdv.txt") == 'No'
        assert candidate("dzs.dll") == 'Yes'
        assert candidate("UIlYE5DRb2SV.exe") == 'Yes'
        assert candidate("IrXV.exe") == 'Yes'
        assert candidate("^m^p:n|?#h@*ci*^=k--v.dll") == 'No'
        assert candidate("i66yaotkz.exe") == 'Yes'
        assert candidate("vnlxospuliq.dll") == 'Yes'
        assert candidate('this_is_valid.txtexe') == 'No'
        assert candidate("o2+fqga~_h.@k1d0:o$_$.0.txt") == 'No'
        assert candidate("jYQ!%7Oadf=HxM.exe") == 'Yes'
        assert candidate("y=rdUuG1Okf=F.txt") == 'Yes'
        assert candidate("oopglo.tf.dll") == 'No'
        assert candidate("LMao0wz.dll") == 'Yes'
        assert candidate("^-O?gGH.dll") == 'No'
        assert candidate(".$_1vhnquh6s=!6r_!~j1~.exe") == 'No'
        assert candidate("qnt.txt") == 'Yes'
        assert candidate("+52?m&^_!c-q0r?pe.dll") == 'No'
        assert candidate("gnz+zb@^cy+|gqi*h?l=s.txt") == 'Yes'
        assert candidate("6cqsqta.txt") == 'No'
        assert candidate("$ca@u.s@@-yx#a/.exe") == 'No'
        assert candidate("yvfznekitgek.dll") == 'Yes'
        assert candidate("n-+g?&+g=x~s&~.-&fk%.exe") == 'No'
        assert candidate("Ww~vDBe_.exe") == 'Yes'
        assert candidate("i%$mq/p!_w&@eu@c/gvxajql.dll") == 'Yes'
        assert candidate("E1Lnmck&QIbVV01.txt") == 'Yes'
        assert candidate('no_one#knows.dll') == 'Yes'
        assert candidate("c+91:8=_*&=z#s&3h7#/.exe") == 'No'
        assert candidate('this_is_12valid.6exe4.txt') == 'No'
        assert candidate("*w_brros!kq@iaoq.dll") == 'No'
        assert candidate("kbpmh.dll") == 'Yes'
        assert candidate("0Y=Mm+Oe~.dll") == 'No'
        assert candidate("rvwndksjhoo.txt") == 'Yes'
        assert candidate("botehqmlxp.olr.dll") == 'No'
        assert candidate("+lq_?kE-o!gd|&X.dll") == 'No'
        assert candidate("qqsy..egxjde.txt") == 'No'
        assert candidate(":#lg=cp&ur#+d5d^li-b8.dll") == 'No'
        assert candidate('.txt') == 'No'
        assert candidate("dfedi.txt") == 'Yes'
        assert candidate("qp|%#&xu|y~$jx.exe") == 'Yes'
        assert candidate("laj@e.luof@!n.exe") == 'No'
        assert candidate("l.igcr.exe") == 'No'
        assert candidate("iEVAdcwQQCoiO0jM.txt") == 'Yes'
        assert candidate('#this2_i4s_5valid.ten') == 'No'
        assert candidate('_Y.txt') == 'No'
        assert candidate("j*90pb:3mwpch1%e$fc.dll") == 'No'
        assert candidate('all.exe.txt') == 'No'
        assert candidate("lzi-@=?!c@%s&p$si.exe") == 'Yes'
        assert candidate("1$q&45N3=lRzm.dll") == 'No'
        assert candidate('_f4indsartal132.') == 'No'
    
        

    # Check some edge cases that are easy to work out by hand.
        assert candidate("fEev.exe") == 'Yes'
        assert candidate("$:ZRFZ04!1-n.dll") == 'No'
        assert candidate("i.yshapqayncaj.exe") == 'No'
        assert candidate("izanbyqrv3b.dll") == 'Yes'
        assert candidate("ktqDzjP.og69Y3=.dll") == 'No'
        assert candidate("m8frtq@xt:#z:.exe") == 'Yes'
        assert candidate("bPw.jjsT1YCelZBQO.exe") == 'No'
        assert candidate("9KWOUbCL3Q0QR1p.txt") == 'No'
        assert candidate("+BN=.exe") == 'No'
        assert candidate("annATke..ej.cVxK6vuE.dll") == 'No'
        assert candidate("*b0#ln!9vf#%oa|17ie/$-.dll") == 'No'
        assert candidate("17E9anu32jG:EP~54.exe") == 'No'
        assert candidate("PfqMHW.txt") == 'Yes'
        assert candidate("&z|i!-+@&l~#g%|%who.txt") == 'No'
        assert candidate("@Fmt~B-_BW.dll") == 'No'
        assert candidate("tiscsoskzlipxld.dll") == 'Yes'
        assert candidate("t+yx?e%/sk?*vecv/t.exe") == 'Yes'
        assert candidate("sdsojhwcc.dll") == 'Yes'
        assert candidate(":11j%:n5/$jp^ruab|.exe") == 'No'
        assert candidate("icXCNbcPz.txt") == 'Yes'
        assert candidate("wSvddcj3BdEgxA18Ne.dll") == 'Yes'
        assert candidate("6kk^:!&tl0zk&hrz*y~mu3.dll") == 'No'
        assert candidate("0g4zwy.dll") == 'No'
        assert candidate('I563_No.exe') == 'Yes'
        assert candidate("oe~$&$@g~u&@@z:xj!lm@!.exe") == 'Yes'
        assert candidate("s+b.exe") == 'Yes'
        assert candidate("OMEihb9WMxRG82MZLPx.txt") == 'Yes'
        assert candidate("~nfkmjqc_$cor%/?ykj%%x%^o9^.dll") == 'No'
        assert candidate("r5q-#nhxw3:4b9d5z*xai.txt") == 'No'
        assert candidate('s.') == 'No'
        assert candidate("VQtimZLsgjDfOBejmciF.dll") == 'Yes'
        assert candidate('MY16FILE3.exe') == 'Yes'
        assert candidate("xj82uvv3djfudzwer.dll") == 'Yes'
        assert candidate('1I563_Yes3.exe') == 'No'
        assert candidate('K.dll') == 'Yes'
        assert candidate('this_is_valid.wow') == 'No'
        assert candidate("cf612q:n?o1m8b0!+v43-wh.exe") == 'No'
        assert candidate("_:a:46!8yq_#06bxji8rf!2nt1!lsc.exe") == 'No'
        assert candidate("s&c1x*o/er*4$^rpw1uzbcb.dll") == 'Yes'
        assert candidate("ssgbu.dll") == 'Yes'
        assert candidate("example.txt") == 'Yes'
        assert candidate("l$!dvdd+dg!/:fz$_^.dll") == 'Yes'
        assert candidate("nzigdcskiz.exe") == 'Yes'
        assert candidate("sIR6wneLqFNKwY.exe") == 'Yes'
        assert candidate('?aREYA.exe') == 'No'
        assert candidate("vmuccyt.exe") == 'Yes'
        assert candidate("1example.dll") == 'No'

if __name__ == '__main__':
    unittest.main()
