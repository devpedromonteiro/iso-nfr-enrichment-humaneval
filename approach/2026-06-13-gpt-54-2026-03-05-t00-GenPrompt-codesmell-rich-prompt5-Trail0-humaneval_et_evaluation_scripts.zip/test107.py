
import unittest


def even_odd_palindrome(n):
    """
    Given a positive integer n, return a tuple that has the number of even and odd
    integer palindromes that fall within the range(1, n), inclusive.

    Example 1:

        Input: 3
        Output: (1, 2)
        Explanation:
        Integer palindrome are 1, 2, 3. one of them is even, and two of them are odd.

    Example 2:

        Input: 12
        Output: (4, 6)
        Explanation:
        Integer palindrome are 1, 2, 3, 4, 5, 6, 7, 8, 9, 11. four of them are even, and 6 of them are odd.

    Note:
        1. 1 <= n <= 10^3
        2. returned tuple has the number of even and odd integer palindromes respectively.
    """
    def is_palindrome(number):
        text = str(number)
        return text == text[::-1]

    def count_even_odd_palindromes(limit):
        even_count = 0
        odd_count = 0

        for number in range(1, limit + 1):
            if not is_palindrome(number):
                continue

            if number % 2 == 0:
                even_count += 1
            else:
                odd_count += 1

        return even_count, odd_count

    return count_even_odd_palindromes(n)
candidate = even_odd_palindrome


class Test(unittest.TestCase):
    def test(self):
        assert candidate(830) == (41, 50)
        assert candidate(898) == (48, 50)
        assert candidate(151) == (8, 16)
        assert candidate(108) == (8, 11)
        assert candidate(1) == (0, 1)
        assert candidate(687) == (37, 40)
        assert candidate(999) == (48, 60)
        assert candidate(452) == (23, 30)
        assert candidate(510) == (28, 31)
        assert candidate(670) == (35, 40)
        assert candidate(799) == (38, 50)
        assert candidate(890) == (47, 50)
        assert candidate(944) == (48, 54)
        assert candidate(554) == (28, 35)
        assert candidate(986) == (48, 58)
        assert candidate(956) == (48, 55)
        assert candidate(845) == (42, 50)
        assert candidate(541) == (28, 34)
        assert candidate(28) == (5, 6)
        assert candidate(848) == (43, 50)
        assert candidate(405) == (19, 30)
        assert candidate(40) == (5, 7)
        assert candidate(415) == (20, 30)
        assert candidate(12) == (4, 6)
        assert candidate(548) == (28, 35)
        assert candidate(175) == (8, 18)
        assert candidate(860) == (44, 50)
        assert candidate(123) == (8, 13)
        assert candidate(854) == (43, 50)
        assert candidate(769) == (38, 47)
        assert candidate(423) == (20, 30)
        assert candidate(113) == (8, 12)
        assert candidate(688) == (37, 40)
        assert candidate(210) == (9, 20)
        assert candidate(661) == (34, 40)
        assert candidate(947) == (48, 54)
        assert candidate(133) == (8, 14)
        assert candidate(987) == (48, 58)
        assert candidate(434) == (22, 30)
        assert candidate(193) == (8, 20)
        assert candidate(613) == (29, 40)
        assert candidate(808) == (39, 50)
        assert candidate(95) == (8, 9)
        assert candidate(627) == (31, 40)
        assert candidate(154) == (8, 16)
        assert candidate(335) == (18, 24)
        assert candidate(485) == (27, 30)
        assert candidate(19) == (4, 6)
        assert candidate(550) == (28, 35)
        assert candidate(170) == (8, 17)
        assert candidate(460) == (24, 30)
        assert candidate(725) == (38, 42)
        assert candidate(824) == (40, 50)
        assert candidate(93) == (8, 9)
        assert candidate(315) == (18, 22)
        assert candidate(63) == (6, 8)
        assert candidate(539) == (28, 34)
        assert candidate(792) == (38, 49)
        assert candidate(911) == (48, 51)
        assert candidate(603) == (28, 40)
        assert candidate(385) == (18, 29)
        assert candidate(617) == (30, 40)
        assert candidate(980) == (48, 58)
        assert candidate(566) == (28, 37)
        assert candidate(633) == (31, 40)
        assert candidate(843) == (42, 50)
        assert candidate(722) == (38, 42)
        assert candidate(190) == (8, 19)
        assert candidate(25) == (5, 6)
        assert candidate(71) == (7, 8)
        assert candidate(949) == (48, 55)
        assert candidate(9) == (4, 5)
        assert candidate(971) == (48, 57)
        assert candidate(572) == (28, 37)
        assert candidate(307) == (18, 21)
        assert candidate(778) == (38, 48)
        assert candidate(130) == (8, 13)
        assert candidate(84) == (7, 9)
        assert candidate(421) == (20, 30)
        assert candidate(628) == (31, 40)
        assert candidate(319) == (18, 22)
        assert candidate(487) == (27, 30)
        assert candidate(993) == (48, 59)
        assert candidate(820) == (40, 50)
        assert candidate(951) == (48, 55)
        assert candidate(389) == (18, 29)
        assert candidate(664) == (34, 40)
        assert candidate(26) == (5, 6)
        assert candidate(570) == (28, 37)
        assert candidate(629) == (31, 40)
        assert candidate(376) == (18, 28)
        assert candidate(446) == (23, 30)
        assert candidate(369) == (18, 27)
        assert candidate(3) == (1, 2)
        assert candidate(680) == (36, 40)
        assert candidate(395) == (18, 30)
        assert candidate(506) == (28, 31)
        assert candidate(893) == (47, 50)
        assert candidate(470) == (25, 30)
        assert candidate(56) == (6, 8)
        assert candidate(291) == (17, 20)
        assert candidate(330) == (18, 23)
        assert candidate(545) == (28, 35)
        assert candidate(701) == (38, 40)
        assert candidate(328) == (18, 23)
        assert candidate(631) == (31, 40)
        assert candidate(8) == (4, 4)
        assert candidate(934) == (48, 53)
        assert candidate(585) == (28, 39)
        assert candidate(876) == (45, 50)
        assert candidate(203) == (9, 20)
        assert candidate(105) == (8, 11)
        assert candidate(960) == (48, 56)
        assert candidate(537) == (28, 34)
        assert candidate(38) == (5, 7)
        assert candidate(507) == (28, 31)
        assert candidate(448) == (23, 30)
        assert candidate(994) == (48, 59)
        assert candidate(188) == (8, 19)
        assert candidate(922) == (48, 52)
        assert candidate(672) == (35, 40)
        assert candidate(403) == (18, 30)

if __name__ == '__main__':
    unittest.main()
