
import unittest
import re
import sys
import math
import copy


def anti_shuffle(s):
    """
    Return a version of the input string where each word's characters are sorted
    in ascending ASCII order, while preserving the original positions of spaces.

    A "word" is any maximal sequence of non-space characters.

    Examples:
        anti_shuffle('Hi') -> 'Hi'
        anti_shuffle('hello') -> 'ehllo'
        anti_shuffle('Hello World!!!') -> 'Hello !!!Wdlor'

    Raises:
        TypeError: If s is not a string.
        ValueError: If s is None.
    """
    if s is None:
        raise ValueError("Input cannot be None.")
    if not isinstance(s, str):
        raise TypeError(f"Input must be a string, got {type(s).__name__}.")

    try:
        result = []
        current_word = []

        for ch in s:
            if ch == ' ':
                if current_word:
                    result.append(''.join(sorted(current_word)))
                    current_word.clear()
                result.append(ch)
            else:
                current_word.append(ch)

        if current_word:
            result.append(''.join(sorted(current_word)))

        return ''.join(result)

    except TypeError:
        # Re-raise specific type-related errors without masking them.
        raise
    except Exception as exc:
        # Wrap unexpected failures in a more meaningful runtime error.
        raise RuntimeError("Unexpected error while anti-shuffling the string.") from exc
candidate = anti_shuffle


def check(candidate):

    # Check some simple cases
    assert candidate('Hi') == 'Hi'
    assert candidate('hello') == 'ehllo'
    assert candidate('number') == 'bemnru'
    assert candidate('abcd') == 'abcd'
    assert candidate('Hello World!!!') == 'Hello !!!Wdlor'
    assert candidate('') == ''
    assert candidate('Hi. My name is Mister Robot. How are you?') == '.Hi My aemn is Meirst .Rboot How aer ?ouy'
    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
