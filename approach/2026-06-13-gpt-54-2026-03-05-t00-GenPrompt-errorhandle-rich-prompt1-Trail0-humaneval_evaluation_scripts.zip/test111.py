
import unittest
import re
import sys
import math
import copy


def histogram(test):
    """Given a string representing space-separated lowercase letters, return a dictionary
    containing the letter(s) with the highest frequency and their corresponding count.

    Examples:
        histogram('a b c') == {'a': 1, 'b': 1, 'c': 1}
        histogram('a b b a') == {'a': 2, 'b': 2}
        histogram('a b c a b') == {'a': 2, 'b': 2}
        histogram('b b b b a') == {'b': 4}
        histogram('') == {}

    Raises:
        TypeError: If test is not a string.
        ValueError: If input contains invalid tokens (non-lowercase single letters).
    """
    if test is None:
        raise TypeError("Input cannot be None; expected a string.")
    if not isinstance(test, str):
        raise TypeError(f"Expected input of type str, got {type(test).__name__}.")

    if test == "":
        return {}

    try:
        tokens = test.split()
    except AttributeError as exc:
        raise TypeError("Input must be a string with space-separated lowercase letters.") from exc

    counts = {}

    for token in tokens:
        if not isinstance(token, str):
            raise TypeError("Each token must be a string.")
        if len(token) != 1 or not token.isalpha() or not token.islower():
            raise ValueError(
                f"Invalid token '{token}'; expected single lowercase letters separated by spaces."
            )
        counts[token] = counts.get(token, 0) + 1

    if not counts:
        return {}

    max_count = max(counts.values())
    return {letter: count for letter, count in counts.items() if count == max_count}
candidate = histogram


def check(candidate):

    # Check some simple cases
    assert candidate('a b b a') == {'a':2,'b': 2}, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('a b c a b') == {'a': 2, 'b': 2}, "This prints if this assert fails 2 (good for debugging!)"
    assert candidate('a b c d g') == {'a': 1, 'b': 1, 'c': 1, 'd': 1, 'g': 1}, "This prints if this assert fails 3 (good for debugging!)"
    assert candidate('r t g') == {'r': 1,'t': 1,'g': 1}, "This prints if this assert fails 4 (good for debugging!)"
    assert candidate('b b b b a') == {'b': 4}, "This prints if this assert fails 5 (good for debugging!)"
    assert candidate('r t g') == {'r': 1,'t': 1,'g': 1}, "This prints if this assert fails 6 (good for debugging!)"
    
    
    # Check some edge cases that are easy to work out by hand.
    assert candidate('') == {}, "This prints if this assert fails 7 (also good for debugging!)"
    assert candidate('a') == {'a': 1}, "This prints if this assert fails 8 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
