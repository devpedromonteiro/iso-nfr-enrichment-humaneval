
import unittest
import re
import sys
import math
import copy


def compare(game, guess):
    """Return absolute differences between actual scores and guesses.

    Each element in `game` is compared with the corresponding element in `guess`.
    If equal, the result is 0; otherwise, the result is the absolute difference.

    Examples:
        compare([1, 2, 3, 4, 5, 1], [1, 2, 3, 4, 2, -2]) -> [0, 0, 0, 0, 3, 3]
        compare([0, 5, 0, 0, 0, 4], [4, 1, 1, 0, 0, -2]) -> [4, 4, 1, 0, 0, 6]
    """
    if game is None:
        raise ValueError("game must not be None")
    if guess is None:
        raise ValueError("guess must not be None")

    if not isinstance(game, (list, tuple)):
        raise TypeError("game must be a list or tuple of numbers")
    if not isinstance(guess, (list, tuple)):
        raise TypeError("guess must be a list or tuple of numbers")

    if len(game) != len(guess):
        raise ValueError("game and guess must have the same length")

    result = []

    try:
        for index, (actual, predicted) in enumerate(zip(game, guess)):
            if not isinstance(actual, (int, float)) or isinstance(actual, bool):
                raise TypeError(f"game[{index}] must be an int or float")
            if not isinstance(predicted, (int, float)) or isinstance(predicted, bool):
                raise TypeError(f"guess[{index}] must be an int or float")

            result.append(abs(actual - predicted))
    except (TypeError, ValueError):
        # Re-raise specific exceptions so errors are not swallowed
        raise
    except Exception as exc:
        # Wrap unexpected failures with context
        raise RuntimeError("unexpected error while comparing scores and guesses") from exc

    return result
candidate = compare


def check(candidate):

    # Check some simple cases
    assert candidate([1,2,3,4,5,1],[1,2,3,4,2,-2])==[0,0,0,0,3,3], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([0,0,0,0,0,0],[0,0,0,0,0,0])==[0,0,0,0,0,0], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,2,3],[-1,-2,-3])==[2,4,6], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,2,3,5],[-1,2,3,4])==[2,0,0,1], "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
