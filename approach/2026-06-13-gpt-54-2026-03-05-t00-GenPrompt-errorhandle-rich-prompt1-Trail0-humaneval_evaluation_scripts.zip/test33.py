
import unittest
import re
import sys
import math
import copy



def sort_third(l: list):
    """Return a new list where elements at indices divisible by 3 are sorted,
    while all other elements remain unchanged.

    Indices considered: 0, 3, 6, 9, ...

    Args:
        l: A list whose elements at indices divisible by 3 are sortable
           relative to each other.

    Returns:
        A new list with only the elements at indices divisible by 3 sorted.

    Raises:
        TypeError: If `l` is not a list.
        ValueError: If `l` is None.
        TypeError: If the elements at indices divisible by 3 cannot be compared
                   and sorted.

    >>> sort_third([1, 2, 3])
    [1, 2, 3]
    >>> sort_third([5, 6, 3, 4, 8, 9, 2])
    [2, 6, 3, 4, 8, 9, 5]
    """
    if l is None:
        raise ValueError("Input list cannot be None.")
    if not isinstance(l, list):
        raise TypeError(f"Expected input of type list, got {type(l).__name__}.")

    result = l.copy()

    try:
        third_values = [result[i] for i in range(0, len(result), 3)]
        third_values.sort()
    except TypeError as e:
        raise TypeError(
            "Elements at indices divisible by 3 must be mutually comparable for sorting."
        ) from e

    try:
        for idx, value in zip(range(0, len(result), 3), third_values):
            result[idx] = value
    except Exception:
        # Defensive rollback to preserve consistency, though assignment into a copied
        # list should normally not fail in standard Python lists.
        raise

    return result
candidate = sort_third




METADATA = {}


def check(candidate):
    assert tuple(candidate([1, 2, 3])) == tuple(sort_third([1, 2, 3]))
    assert tuple(candidate([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])) == tuple(sort_third([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10]))
    assert tuple(candidate([5, 8, -12, 4, 23, 2, 3, 11, 12, -10])) == tuple(sort_third([5, 8, -12, 4, 23, 2, 3, 11, 12, -10]))
    assert tuple(candidate([5, 6, 3, 4, 8, 9, 2])) == tuple([2, 6, 3, 4, 8, 9, 5])
    assert tuple(candidate([5, 8, 3, 4, 6, 9, 2])) == tuple([2, 8, 3, 4, 6, 9, 5])
    assert tuple(candidate([5, 6, 9, 4, 8, 3, 2])) == tuple([2, 6, 9, 4, 8, 3, 5])
    assert tuple(candidate([5, 6, 3, 4, 8, 9, 2, 1])) == tuple([2, 6, 3, 4, 8, 9, 5, 1])



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
