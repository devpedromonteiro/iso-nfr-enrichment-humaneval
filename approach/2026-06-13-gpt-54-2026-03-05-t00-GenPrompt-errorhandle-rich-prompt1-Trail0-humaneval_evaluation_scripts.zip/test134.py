
import unittest
import re
import sys
import math
import copy


def check_if_last_char_is_a_letter(txt):
    '''
    Create a function that returns True if the last character
    of a given string is an alphabetical character and is not
    a part of a word, and False otherwise.
    Note: "word" is a group of characters separated by space.

    Examples:
    check_if_last_char_is_a_letter("apple pie") â False
    check_if_last_char_is_a_letter("apple pi e") â True
    check_if_last_char_is_a_letter("apple pi e ") â False
    check_if_last_char_is_a_letter("") â False 
    '''
    if txt is None:
        raise ValueError("txt must not be None")
    if not isinstance(txt, str):
        raise TypeError("txt must be a string")

    try:
        if txt == "":
            return False

        # If the string ends with a space, the last character is not a letter.
        if txt[-1].isspace():
            return False

        # Split by spaces; a single-letter final word means the last character
        # is a letter and not part of a longer word.
        words = txt.split(" ")
        last_word = words[-1]

        if last_word == "":
            return False

        return len(last_word) == 1 and last_word.isalpha()

    except IndexError as exc:
        # Defensive handling for unexpected indexing issues.
        raise RuntimeError("Unexpected error while checking the last character") from exc
candidate = check_if_last_char_is_a_letter


def check(candidate):

    # Check some simple cases
    assert candidate("apple") == False
    assert candidate("apple pi e") == True
    assert candidate("eeeee") == False
    assert candidate("A") == True
    assert candidate("Pumpkin pie ") == False
    assert candidate("Pumpkin pie 1") == False
    assert candidate("") == False
    assert candidate("eeeee e ") == False
    assert candidate("apple pie") == False
    assert candidate("apple pi e ") == False

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
