
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """Input to this function is a string represented multiple groups for nested
    parentheses separated by spaces.
    For each of the group, output the deepest level of nesting of parentheses.
    E.g. (()()) has maximum two levels of nesting while ((())) has three.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """
    if not isinstance(paren_string, str):
        raise TypeError(
            f"paren_string must be of type str, got {type(paren_string).__name__}"
        )

    stripped = paren_string.strip()
    if not stripped:
        return []

    groups = stripped.split()
    depths: List[int] = []

    for group_index, group in enumerate(groups):
        current_depth = 0
        max_depth = 0

        for char_index, char in enumerate(group):
            if char == "(":
                current_depth += 1
                if current_depth > max_depth:
                    max_depth = current_depth
            elif char == ")":
                if current_depth == 0:
                    raise ValueError(
                        f"Unbalanced parentheses in group {group_index}: "
                        f"unexpected ')' at position {char_index}"
                    )
                current_depth -= 1
            else:
                raise ValueError(
                    f"Invalid character {char!r} in group {group_index} "
                    f"at position {char_index}; only '(' and ')' are allowed"
                )

        if current_depth != 0:
            raise ValueError(
                f"Unbalanced parentheses in group {group_index}: "
                f"missing {current_depth} closing parenthesis(es)"
            )

        depths.append(max_depth)

    return depths
candidate = parse_nested_parens




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('(()()) ((())) () ((())()())') == [2, 3, 1, 3]
    assert candidate('() (()) ((())) (((())))') == [1, 2, 3, 4]
    assert candidate('(()(())((())))') == [4]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
