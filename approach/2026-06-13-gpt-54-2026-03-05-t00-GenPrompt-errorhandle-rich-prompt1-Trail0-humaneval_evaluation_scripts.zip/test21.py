
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def rescale_to_unit(numbers: List[float]) -> List[float]:
    """Given list of numbers (of at least two elements), apply a linear transform
    to that list such that the smallest number becomes 0 and the largest becomes 1.

    >>> rescale_to_unit([1.0, 2.0, 3.0, 4.0, 5.0])
    [0.0, 0.25, 0.5, 0.75, 1.0]
    """
    if numbers is None:
        raise TypeError("numbers must not be None")

    if not isinstance(numbers, list):
        raise TypeError("numbers must be a list of numeric values")

    if len(numbers) < 2:
        raise ValueError("numbers must contain at least two elements")

    validated_numbers = []
    for i, value in enumerate(numbers):
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise TypeError(f"numbers[{i}] must be an int or float, got {type(value).__name__}")
        validated_numbers.append(float(value))

    min_value = min(validated_numbers)
    max_value = max(validated_numbers)

    if min_value == max_value:
        raise ValueError("cannot rescale when all numbers are equal")

    scale = max_value - min_value
    return [(value - min_value) / scale for value in validated_numbers]
candidate = rescale_to_unit




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([2.0, 49.9]) == [0.0, 1.0]
    assert candidate([100.0, 49.9]) == [1.0, 0.0]
    assert candidate([1.0, 2.0, 3.0, 4.0, 5.0]) == [0.0, 0.25, 0.5, 0.75, 1.0]
    assert candidate([2.0, 1.0, 5.0, 3.0, 4.0]) == [0.25, 0.0, 1.0, 0.5, 0.75]
    assert candidate([12.0, 11.0, 15.0, 13.0, 14.0]) == [0.25, 0.0, 1.0, 0.5, 0.75]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
