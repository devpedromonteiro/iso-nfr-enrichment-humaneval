
import unittest
import re
import sys
import math
import copy


def solve(N):
    """Given a non-negative integer N, return the binary representation
    of the sum of its decimal digits.

    Example:
        solve(1000) -> "1"
        solve(150)  -> "110"
        solve(147)  -> "1100"

    Constraints:
        0 <= N <= 10000

    Raises:
        TypeError: if N is not an integer.
        ValueError: if N is outside the allowed range.
    """
    # Validate presence/type explicitly
    if isinstance(N, bool):
        raise TypeError("N must be an integer, not a boolean.")

    if not isinstance(N, int):
        raise TypeError("N must be an integer.")

    # Validate range explicitly
    if N < 0 or N > 10000:
        raise ValueError("N must satisfy 0 <= N <= 10000.")

    try:
        digit_sum = sum(int(ch) for ch in str(N))
    except ValueError as exc:
        # Defensive handling: should not occur after validation,
        # but keeps failure explicit and state consistent.
        raise ValueError("Failed to compute digit sum from input.") from exc

    try:
        return bin(digit_sum)[2:]
    except TypeError as exc:
        # Defensive handling for unexpected internal type issues.
        raise TypeError("Failed to convert digit sum to binary.") from exc
candidate = solve


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(1000) == "1", "Error"
    assert candidate(150) == "110", "Error"
    assert candidate(147) == "1100", "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate(333) == "1001", "Error"
    assert candidate(963) == "10010", "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
