
import unittest
import re
import sys
import math
import copy


def maximum(arr, k):
    """
    Given an array arr of integers and a non-negative integer k, return a sorted
    list of length k with the maximum k numbers in arr.

    Raises:
        TypeError: If arr is not a list/tuple, if k is not an integer, or if any
                   element in arr is not an integer.
        ValueError: If arr is empty, or if k is out of the valid range
                    0 <= k <= len(arr).
    """
    # Validate arr container type
    if not isinstance(arr, (list, tuple)):
        raise TypeError("arr must be a list or tuple of integers")

    # Validate k type
    if not isinstance(k, int):
        raise TypeError("k must be an integer")

    # Validate arr length constraint
    if len(arr) == 0:
        raise ValueError("arr must not be empty")

    # Validate k range
    if k < 0 or k > len(arr):
        raise ValueError("k must satisfy 0 <= k <= len(arr)")

    # Validate element types explicitly
    for i, value in enumerate(arr):
        if not isinstance(value, int):
            raise TypeError(f"arr[{i}] must be an integer, got {type(value).__name__}")

    # Fast path for k == 0
    if k == 0:
        return []

    try:
        # Sort descending, take top k, then sort ascending for final output
        result = sorted(sorted(arr, reverse=True)[:k])
    except MemoryError:
        # Preserve specific system-level failure context
        raise
    except Exception as exc:
        # Wrap unexpected failures with explicit context
        raise RuntimeError("failed to compute maximum k numbers") from exc

    return result
candidate = maximum


def check(candidate):

    # Check some simple cases
    assert candidate([-3, -4, 5], 3) == [-4, -3, 5]
    assert candidate([4, -4, 4], 2) == [4, 4]
    assert candidate([-3, 2, 1, 2, -1, -2, 1], 1) == [2]
    assert candidate([123, -123, 20, 0 , 1, 2, -3], 3) == [2, 20, 123]
    assert candidate([-123, 20, 0 , 1, 2, -3], 4) == [0, 1, 2, 20]
    assert candidate([5, 15, 0, 3, -13, -8, 0], 7) == [-13, -8, 0, 0, 3, 5, 15]
    assert candidate([-1, 0, 2, 5, 3, -10], 2) == [3, 5]
    assert candidate([1, 0, 5, -7], 1) == [5]
    assert candidate([4, -4], 2) == [-4, 4]
    assert candidate([-10, 10], 2) == [-10, 10]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([1, 2, 3, -23, 243, -400, 0], 0) == []



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
