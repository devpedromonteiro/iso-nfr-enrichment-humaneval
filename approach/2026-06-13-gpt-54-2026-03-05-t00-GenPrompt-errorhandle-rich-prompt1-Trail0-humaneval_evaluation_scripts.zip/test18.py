
import unittest
import re
import sys
import math
import copy



def how_many_times(string: str, substring: str) -> int:
    """Find how many times a given substring occurs in the original string.
    Overlapping matches are counted.

    >>> how_many_times('', 'a')
    0
    >>> how_many_times('aaa', 'a')
    3
    >>> how_many_times('aaaa', 'aa')
    3
    """
    if not isinstance(string, str):
        raise TypeError(f"string must be of type str, got {type(string).__name__}")
    if not isinstance(substring, str):
        raise TypeError(f"substring must be of type str, got {type(substring).__name__}")

    if substring == "":
        raise ValueError("substring must not be empty")

    count = 0
    start = 0

    try:
        while True:
            index = string.find(substring, start)
            if index == -1:
                break
            count += 1
            start = index + 1  # allow overlapping matches
    except (TypeError, ValueError):
        raise
    except Exception as exc:
        raise RuntimeError("unexpected error while counting substring occurrences") from exc

    return count
candidate = how_many_times




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('', 'x') == 0
    assert candidate('xyxyxyx', 'x') == 4
    assert candidate('cacacacac', 'cac') == 4
    assert candidate('john doe', 'john') == 1


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
