
import unittest
import re
import sys
import math
import copy


def is_sorted(lst):
    '''
    Given a list of numbers, return whether or not they are sorted
    in ascending order. If list has more than 1 duplicate of the same
    number, return False. Assume no negative numbers and only integers.

    Examples
    is_sorted([5]) â True
    is_sorted([1, 2, 3, 4, 5]) â True
    is_sorted([1, 3, 2, 4, 5]) â False
    is_sorted([1, 2, 3, 4, 5, 6]) â True
    is_sorted([1, 2, 3, 4, 5, 6, 7]) â True
    is_sorted([1, 3, 2, 4, 5, 6, 7]) â False
    is_sorted([1, 2, 2, 3, 3, 4]) â True
    is_sorted([1, 2, 2, 2, 3, 4]) â False
    '''
    if not isinstance(lst, list):
        raise TypeError("lst must be a list")

    try:
        for i, value in enumerate(lst):
            if not isinstance(value, int):
                raise TypeError(f"All elements must be integers; found {type(value).__name__} at index {i}")
            if value < 0:
                raise ValueError(f"All elements must be non-negative; found {value} at index {i}")

        if len(lst) <= 1:
            return True

        duplicate_counts = {}

        for i in range(len(lst) - 1):
            current = lst[i]
            nxt = lst[i + 1]

            duplicate_counts[current] = duplicate_counts.get(current, 0) + 1
            if duplicate_counts[current] > 2:
                return False

            if current > nxt:
                return False

        last_value = lst[-1]
        duplicate_counts[last_value] = duplicate_counts.get(last_value, 0) + 1
        if duplicate_counts[last_value] > 2:
            return False

        return True

    except (TypeError, ValueError):
        raise
    except IndexError as exc:
        raise RuntimeError("Unexpected indexing error while checking sorted order") from exc
candidate = is_sorted


def check(candidate):

    # Check some simple cases
    assert candidate([5]) == True
    assert candidate([1, 2, 3, 4, 5]) == True
    assert candidate([1, 3, 2, 4, 5]) == False
    assert candidate([1, 2, 3, 4, 5, 6]) == True
    assert candidate([1, 2, 3, 4, 5, 6, 7]) == True
    assert candidate([1, 3, 2, 4, 5, 6, 7]) == False, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([]) == True, "This prints if this assert fails 2 (good for debugging!)"
    assert candidate([1]) == True, "This prints if this assert fails 3 (good for debugging!)"
    assert candidate([3, 2, 1]) == False, "This prints if this assert fails 4 (good for debugging!)"
    
    # Check some edge cases that are easy to work out by hand.
    assert candidate([1, 2, 2, 2, 3, 4]) == False, "This prints if this assert fails 5 (good for debugging!)"
    assert candidate([1, 2, 3, 3, 3, 4]) == False, "This prints if this assert fails 6 (good for debugging!)"
    assert candidate([1, 2, 2, 3, 3, 4]) == True, "This prints if this assert fails 7 (good for debugging!)"
    assert candidate([1, 2, 3, 4]) == True, "This prints if this assert fails 8 (good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
