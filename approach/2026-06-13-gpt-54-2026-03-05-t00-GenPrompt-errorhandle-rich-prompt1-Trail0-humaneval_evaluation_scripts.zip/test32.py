
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[2] * x^2 + .... + xs[n] * x^n
    """
    if not isinstance(xs, list):
        raise TypeError("xs must be a list of numeric coefficients")
    if not xs:
        raise ValueError("xs must not be empty")
    if not isinstance(x, (int, float)):
        raise TypeError("x must be a numeric value")

    try:
        return sum(coeff * math.pow(x, i) for i, coeff in enumerate(xs))
    except TypeError as exc:
        raise TypeError("all coefficients in xs must be numeric") from exc
    except OverflowError as exc:
        raise OverflowError("polynomial evaluation overflowed") from exc


def find_zero(xs: list):
    """xs are coefficients of a polynomial.
    find_zero finds x such that poly(x) = 0.
    find_zero returns only one zero point, even if there are many.
    Moreover, find_zero only takes list xs having even number of coefficients
    and largest non-zero coefficient positive as it guarantees
    a solution.

    >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2)  # (x - 1) * (x - 2) * (x - 3)
    1.0
    """
    if not isinstance(xs, list):
        raise TypeError("xs must be a list of numeric coefficients")
    if not xs:
        raise ValueError("xs must not be empty")
    if len(xs) % 2 != 0:
        raise ValueError("xs must contain an even number of coefficients")
    if not all(isinstance(c, (int, float)) for c in xs):
        raise TypeError("all coefficients in xs must be numeric")

    # Remove trailing zeros safely to determine the actual degree.
    coeffs = xs[:]
    while coeffs and coeffs[-1] == 0:
        coeffs.pop()

    if not coeffs:
        raise ValueError("zero polynomial has infinitely many roots")

    if coeffs[-1] <= 0:
        raise ValueError("largest non-zero coefficient must be positive")

    # Handle linear case directly.
    if len(coeffs) == 2:
        a0, a1 = coeffs
        if a1 == 0:
            raise ZeroDivisionError("linear coefficient must be non-zero")
        return -a0 / a1

    def f(x):
        return poly(coeffs, x)

    # By the stated constraint, odd-degree with positive leading coefficient
    # guarantees at least one real root. Search for a sign change.
    left = -1.0
    right = 1.0

    try:
        f_left = f(left)
        f_right = f(right)
    except (TypeError, OverflowError, ValueError):
        raise

    max_bound = 1e6
    while f_left == 0 or f_right == 0 or f_left * f_right > 0:
        if f_left == 0:
            return left
        if f_right == 0:
            return right

        left *= 2
        right *= 2

        if abs(left) > max_bound or abs(right) > max_bound:
            raise ArithmeticError("failed to bracket a root within safe bounds")

        try:
            f_left = f(left)
            f_right = f(right)
        except OverflowError as exc:
            raise ArithmeticError("overflow while searching for a root interval") from exc

    # Bisection method on a valid bracket.
    for _ in range(200):
        mid = (left + right) / 2.0
        f_mid = f(mid)

        if abs(f_mid) < 1e-12:
            return mid

        if f_left * f_mid < 0:
            right = mid
            f_right = f_mid
        else:
            left = mid
            f_left = f_mid

    # Return best approximation without leaving inconsistent state.
    return (left + right) / 2.0
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
