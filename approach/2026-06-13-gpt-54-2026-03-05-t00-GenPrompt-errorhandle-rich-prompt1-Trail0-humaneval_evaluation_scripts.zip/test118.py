
import unittest
import re
import sys
import math
import copy


def get_closest_vowel(word):
    """Return the closest vowel from the right that is between two consonants.

    A vowel qualifies only if:
    - it is not the first or last character
    - the characters immediately before and after it are consonants

    The function is case sensitive and supports English letters only.

    Raises:
        TypeError: if word is not a string
        ValueError: if word contains non-alphabetic characters
    """
    if not isinstance(word, str):
        raise TypeError("word must be a string")

    if not word.isalpha():
        raise ValueError("word must contain English letters only")

    if len(word) < 3:
        return ""

    vowels = set("aeiouAEIOU")

    try:
        for i in range(len(word) - 2, 0, -1):
            char = word[i]
            if (
                char in vowels
                and word[i - 1] not in vowels
                and word[i + 1] not in vowels
            ):
                return char
        return ""
    except IndexError as exc:
        # Defensive safeguard: preserve consistent behavior if indexing assumptions change.
        raise RuntimeError("unexpected indexing error while searching for closest vowel") from exc
candidate = get_closest_vowel


def check(candidate):

    # Check some simple cases
    assert candidate("yogurt") == "u"
    assert candidate("full") == "u"
    assert candidate("easy") == ""
    assert candidate("eAsy") == ""
    assert candidate("ali") == ""
    assert candidate("bad") == "a"
    assert candidate("most") == "o"
    assert candidate("ab") == ""
    assert candidate("ba") == ""
    assert candidate("quick") == ""
    assert candidate("anime") == "i"
    assert candidate("Asia") == ""
    assert candidate("Above") == "o"

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
