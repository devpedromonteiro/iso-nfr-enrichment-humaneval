
import unittest
import re
import sys
import math
import copy


def is_simple_power(x, n):
    """Return True if x is an integer power of n, else False.

    A simple power means there exists an integer k >= 0 such that n**k == x.

    Examples:
        is_simple_power(1, 4) -> True
        is_simple_power(2, 2) -> True
        is_simple_power(8, 2) -> True
        is_simple_power(3, 2) -> False
        is_simple_power(3, 1) -> False
        is_simple_power(5, 3) -> False

    Raises:
        TypeError: if x or n is not an integer.
        ValueError: for unsupported or invalid inputs that would make the
                    power check undefined or non-terminating.
    """
    if not isinstance(x, int) or not isinstance(n, int):
        raise TypeError("Both x and n must be integers.")

    if x < 1:
        raise ValueError("x must be a positive integer.")
    if n < 1:
        raise ValueError("n must be a positive integer.")

    # 1 is n**0 for any positive n
    if x == 1:
        return True

    # Powers of 1 never produce values other than 1
    if n == 1:
        return False

    try:
        current = x
        while current > 1:
            if current % n != 0:
                return False
            current //= n
        return current == 1
    except ZeroDivisionError as exc:
        # Defensive handling, though n < 1 is already rejected above
        raise ValueError("n must not be zero.") from exc
    except OverflowError as exc:
        raise ValueError("Numeric overflow occurred during power evaluation.") from exc
candidate = is_simple_power


def check(candidate):

    # Check some simple cases
    assert candidate(16, 2)== True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(143214, 16)== False, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(4, 2)==True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(9, 3)==True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(16, 4)==True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(24, 2)==False, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(128, 4)==False, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(12, 6)==False, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1, 1)==True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate(1, 12)==True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
