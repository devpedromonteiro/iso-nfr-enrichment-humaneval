
import unittest
import re
import sys
import math
import copy


def split_words(txt):
    '''
    Given a string of words, return a list of words split on whitespace, if no whitespaces exists in the text you
    should split on commas ',' if no commas exists you should return the number of lower-case letters with odd order in the
    alphabet, ord('a') = 0, ord('b') = 1, ... ord('z') = 25

    Examples
    split_words("Hello world!") â ["Hello", "world!"]
    split_words("Hello,world!") â ["Hello", "world!"]
    split_words("abcdef") == 3
    '''
    if txt is None:
        raise ValueError("txt must not be None")
    if not isinstance(txt, str):
        raise TypeError(f"txt must be a string, got {type(txt).__name__}")

    try:
        if any(ch.isspace() for ch in txt):
            return txt.split()

        if ',' in txt:
            return txt.split(',')

        count = 0
        for ch in txt:
            if 'a' <= ch <= 'z':
                if (ord(ch) - ord('a')) % 2 == 1:
                    count += 1
        return count

    except (TypeError, ValueError):
        raise
    except Exception as exc:
        raise RuntimeError("Unexpected error while processing input") from exc
candidate = split_words


def check(candidate):

    assert candidate("Hello world!") == ["Hello","world!"]
    assert candidate("Hello,world!") == ["Hello","world!"]
    assert candidate("Hello world,!") == ["Hello","world,!"]
    assert candidate("Hello,Hello,world !") == ["Hello,Hello,world","!"]
    assert candidate("abcdef") == 3
    assert candidate("aaabb") == 2
    assert candidate("aaaBb") == 1
    assert candidate("") == 0


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
