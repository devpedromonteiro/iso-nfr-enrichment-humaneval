
import unittest
import re
import sys
import math
import copy


def is_nested(string):
    '''
    Create a function that takes a string as input which contains only square brackets.
    The function should return True if and only if there is a valid subsequence of brackets
    where at least one bracket in the subsequence is nested.

    is_nested('[[]]') â True
    is_nested('[]]]]]]][[[[[]') â False
    is_nested('[][]') â False
    is_nested('[]') â False
    is_nested('[[][]]') â True
    is_nested('[[]][[') â True
    '''
    if not isinstance(string, str):
        raise TypeError("Input must be a string.")

    invalid_chars = set(string) - {'[', ']'}
    if invalid_chars:
        raise ValueError("Input string must contain only square brackets '[' and ']'.")

    depth = 0
    max_depth = 0

    try:
        for char in string:
            if char == '[':
                depth += 1
                max_depth = max(max_depth, depth)
            elif char == ']':
                if depth > 0:
                    depth -= 1
    except TypeError as e:
        raise TypeError("Failed while processing the input string.") from e
    except Exception as e:
        raise RuntimeError("Unexpected error while evaluating bracket nesting.") from e

    return max_depth >= 2
candidate = is_nested


def check(candidate):

    # Check some simple cases
    assert candidate('[[]]') == True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('[]]]]]]][[[[[]') == False
    assert candidate('[][]') == False
    assert candidate(('[]')) == False
    assert candidate('[[[[]]]]') == True
    assert candidate('[]]]]]]]]]]') == False
    assert candidate('[][][[]]') == True
    assert candidate('[[]') == False
    assert candidate('[]]') == False
    assert candidate('[[]][[') == True
    assert candidate('[[][]]') == True

    # Check some edge cases that are easy to work out by hand.
    assert candidate('') == False, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate('[[[[[[[[') == False
    assert candidate(']]]]]]]]') == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
