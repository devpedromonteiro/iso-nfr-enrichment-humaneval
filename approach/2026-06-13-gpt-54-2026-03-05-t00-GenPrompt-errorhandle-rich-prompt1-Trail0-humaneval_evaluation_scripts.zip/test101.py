
import unittest
import re
import sys
import math
import copy


import re


def words_string(s):
    """
    Split a string of words separated by commas and/or spaces into a list of words.

    Examples:
        words_string("Hi, my name is John")
        -> ["Hi", "my", "name", "is", "John"]

        words_string("One, two, three, four, five, six")
        -> ["One", "two", "three", "four", "five", "six"]

    Error handling:
        - Raises TypeError if s is not a string.
        - Raises ValueError if s is an empty string or contains no valid words.
    """
    if s is None:
        raise TypeError("Input cannot be None; expected a string.")

    if not isinstance(s, str):
        raise TypeError(f"Expected input of type str, got {type(s).__name__}.")

    if s == "":
        raise ValueError("Input string cannot be empty.")

    try:
        words = [word for word in re.split(r"[,\s]+", s.strip()) if word]
    except re.error as exc:
        raise ValueError("Failed to split input string due to an invalid pattern.") from exc

    if not words:
        raise ValueError("Input string contains no valid words.")

    return words
candidate = words_string


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate("Hi, my name is John") == ["Hi", "my", "name", "is", "John"]
    assert candidate("One, two, three, four, five, six") == ["One", "two", "three", "four", "five", "six"]
    assert candidate("Hi, my name") == ["Hi", "my", "name"]
    assert candidate("One,, two, three, four, five, six,") == ["One", "two", "three", "four", "five", "six"]

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate("") == []
    assert candidate("ahmed     , gamal") == ["ahmed", "gamal"]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
