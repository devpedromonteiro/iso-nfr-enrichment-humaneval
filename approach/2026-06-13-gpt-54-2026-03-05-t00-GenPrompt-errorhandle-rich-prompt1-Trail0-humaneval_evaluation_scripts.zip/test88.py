
import unittest
import re
import sys
import math
import copy


def sort_array(array):
    """
    Given an array of non-negative integers, return a copy of the given array after sorting.
    Sort ascending if the sum of the first and last values is odd,
    otherwise sort descending if that sum is even.

    Note:
    * don't change the given array.

    Examples:
    * sort_array([]) => []
    * sort_array([5]) => [5]
    * sort_array([2, 4, 3, 0, 1, 5]) => [0, 1, 2, 3, 4, 5]
    * sort_array([2, 4, 3, 0, 1, 5, 6]) => [6, 5, 4, 3, 2, 1, 0]
    """
    if array is None:
        raise TypeError("array must not be None")

    if not isinstance(array, list):
        raise TypeError("array must be a list of non-negative integers")

    try:
        copied = list(array)
    except TypeError as exc:
        raise TypeError("array must be an iterable list of non-negative integers") from exc

    for index, value in enumerate(copied):
        if not isinstance(value, int):
            raise TypeError(f"array[{index}] must be an integer, got {type(value).__name__}")
        if value < 0:
            raise ValueError(f"array[{index}] must be non-negative, got {value}")

    if len(copied) <= 1:
        return copied

    try:
        first_last_sum = copied[0] + copied[-1]
    except IndexError as exc:
        raise ValueError("array must contain valid first and last elements") from exc
    except TypeError as exc:
        raise TypeError("first and last elements must support integer addition") from exc

    try:
        return sorted(copied, reverse=(first_last_sum % 2 == 0))
    except TypeError as exc:
        raise TypeError("array contains values that cannot be sorted") from exc
candidate = sort_array


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([]) == [], "Error"
    assert candidate([5]) == [5], "Error"
    assert candidate([2, 4, 3, 0, 1, 5]) == [0, 1, 2, 3, 4, 5], "Error"
    assert candidate([2, 4, 3, 0, 1, 5, 6]) == [6, 5, 4, 3, 2, 1, 0], "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([2, 1]) == [1, 2], "Error"
    assert candidate([15, 42, 87, 32 ,11, 0]) == [0, 11, 15, 32, 42, 87], "Error"
    assert candidate([21, 14, 23, 11]) == [23, 21, 14, 11], "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
