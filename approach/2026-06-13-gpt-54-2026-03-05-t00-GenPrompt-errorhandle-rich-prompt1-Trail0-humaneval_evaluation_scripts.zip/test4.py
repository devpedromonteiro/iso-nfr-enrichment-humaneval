
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def mean_absolute_deviation(numbers: List[float]) -> float:
    """For a given list of input numbers, calculate Mean Absolute Deviation
    around the mean of this dataset.

    Mean Absolute Deviation is the average absolute difference between each
    element and a centerpoint (mean in this case):
    MAD = average | x - x_mean |

    >>> mean_absolute_deviation([1.0, 2.0, 3.0, 4.0])
    1.0
    """
    if numbers is None:
        raise TypeError("numbers must not be None")

    if not isinstance(numbers, list):
        raise TypeError("numbers must be a list of numeric values")

    if len(numbers) == 0:
        raise ValueError("numbers must not be empty")

    try:
        validated_numbers = []
        for i, value in enumerate(numbers):
            if isinstance(value, bool):
                raise TypeError(f"numbers[{i}] must be an int or float, got bool")
            if not isinstance(value, (int, float)):
                raise TypeError(
                    f"numbers[{i}] must be an int or float, got {type(value).__name__}"
                )
            validated_numbers.append(float(value))

        mean = sum(validated_numbers) / len(validated_numbers)
        absolute_deviations = [abs(x - mean) for x in validated_numbers]
        return sum(absolute_deviations) / len(validated_numbers)

    except ZeroDivisionError as exc:
        # Defensive safeguard in case state changes unexpectedly.
        raise ValueError("cannot compute mean absolute deviation for empty input") from exc
    except OverflowError as exc:
        raise OverflowError("numeric overflow occurred while computing deviation") from exc
candidate = mean_absolute_deviation




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert abs(candidate([1.0, 2.0, 3.0]) - 2.0/3.0) < 1e-6
    assert abs(candidate([1.0, 2.0, 3.0, 4.0]) - 1.0) < 1e-6
    assert abs(candidate([1.0, 2.0, 3.0, 4.0, 5.0]) - 6.0/5.0) < 1e-6



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
