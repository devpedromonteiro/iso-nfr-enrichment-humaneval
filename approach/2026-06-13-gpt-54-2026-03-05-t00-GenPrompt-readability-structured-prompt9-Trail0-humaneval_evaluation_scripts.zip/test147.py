
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    Return the number of index triples (i, j, k), with 1 <= i < j < k <= n,
    such that:
        a[i] = i*i - i + 1
    and
        a[i] + a[j] + a[k]
    is divisible by 3.

    Observation:
    For any integer i:
        a[i] = i*i - i + 1 = i(i - 1) + 1

    Since i(i - 1) is always divisible by 2 but we only care modulo 3,
    evaluate a[i] modulo 3:

        i % 3 == 0 -> a[i] % 3 == 1
        i % 3 == 1 -> a[i] % 3 == 1
        i % 3 == 2 -> a[i] % 3 == 0

    So every value in the array belongs to one of two residue classes:
        - remainder 1 modulo 3
        - remainder 0 modulo 3

    A triple sum is divisible by 3 only in these cases:
        1) 0 + 0 + 0
        2) 1 + 1 + 1

    Therefore:
        answer = C(count_mod_0, 3) + C(count_mod_1, 3)

    Indices with i % 3 == 2 produce remainder 0.
    All other indices produce remainder 1.
    """

    def combinations_of_three(count):
        """Return the number of ways to choose 3 items from count items."""
        if count < 3:
            return 0
        return count * (count - 1) * (count - 2) // 6

    count_remainder_0 = n // 3
    count_remainder_1 = n - count_remainder_0

    triples_with_sum_divisible_by_3 = (
        combinations_of_three(count_remainder_0)
        + combinations_of_three(count_remainder_1)
    )

    return triples_with_sum_divisible_by_3
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
