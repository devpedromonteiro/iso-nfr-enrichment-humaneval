
import unittest
import re
import sys
import math
import copy


def is_prime(number):
    """Return True if number is a prime, otherwise False."""
    if number < 2:
        return False

    divisor = 2
    while divisor * divisor <= number:
        if number % divisor == 0:
            return False
        divisor += 1

    return True


def is_multiply_prime(number):
    """Return True if number is the product of exactly 3 prime numbers."""
    if number < 8:
        return False

    first_factor = 2
    while first_factor <= number:
        if number % first_factor == 0 and is_prime(first_factor):
            remaining_after_first = number // first_factor

            second_factor = 2
            while second_factor <= remaining_after_first:
                if (
                    remaining_after_first % second_factor == 0
                    and is_prime(second_factor)
                ):
                    third_factor = remaining_after_first // second_factor
                    if is_prime(third_factor):
                        return True
                second_factor += 1
        first_factor += 1

    return False
candidate = is_multiply_prime


def check(candidate):

    assert candidate(5) == False
    assert candidate(30) == True
    assert candidate(8) == True
    assert candidate(10) == False
    assert candidate(125) == True
    assert candidate(3 * 5 * 7) == True
    assert candidate(3 * 6 * 7) == False
    assert candidate(9 * 9 * 9) == False
    assert candidate(11 * 9 * 9) == False
    assert candidate(11 * 13 * 7) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
