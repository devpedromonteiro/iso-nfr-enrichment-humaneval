
import unittest
import re
import sys
import math
import copy


def solve(text):
    has_letter = any(character.isalpha() for character in text)

    if not has_letter:
        return text[::-1]

    swapped_characters = []
    for character in text:
        if character.isalpha():
            swapped_characters.append(character.swapcase())
        else:
            swapped_characters.append(character)

    return "".join(swapped_characters)
candidate = solve


def check(candidate):

    # Check some simple cases
    assert candidate("AsDf") == "aSdF"
    assert candidate("1234") == "4321"
    assert candidate("ab") == "AB"
    assert candidate("#a@C") == "#A@c"
    assert candidate("#AsdfW^45") == "#aSDFw^45"
    assert candidate("#6@2") == "2@6#"

    # Check some edge cases that are easy to work out by hand.
    assert candidate("#$a^D") == "#$A^d"
    assert candidate("#ccc") == "#CCC"

    # Don't remove this line:


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
