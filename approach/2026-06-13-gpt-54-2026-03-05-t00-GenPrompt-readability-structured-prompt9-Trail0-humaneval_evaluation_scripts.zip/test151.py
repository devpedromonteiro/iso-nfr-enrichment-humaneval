
import unittest
import re
import sys
import math
import copy


def double_the_difference(numbers):
    """
    Return the sum of squares of positive odd integers in the input list.

    Negative numbers, non-integers, and even numbers are ignored.
    If the list is empty, return 0.
    """
    total = 0

    for number in numbers:
        is_integer = isinstance(number, int) and not isinstance(number, bool)
        is_positive_odd = is_integer and number > 0 and number % 2 == 1

        if is_positive_odd:
            total += number ** 2

    return total
candidate = double_the_difference


def check(candidate):

    # Check some simple cases
    assert candidate([]) == 0 , "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([5, 4]) == 25 , "This prints if this assert fails 2 (good for debugging!)"
    assert candidate([0.1, 0.2, 0.3]) == 0 , "This prints if this assert fails 3 (good for debugging!)"
    assert candidate([-10, -20, -30]) == 0 , "This prints if this assert fails 4 (good for debugging!)"


    # Check some edge cases that are easy to work out by hand.
    assert candidate([-1, -2, 8]) == 0, "This prints if this assert fails 5 (also good for debugging!)"
    assert candidate([0.2, 3, 5]) == 34, "This prints if this assert fails 6 (also good for debugging!)"
    lst = list(range(-99, 100, 2))
    odd_sum = sum([i**2 for i in lst if i%2!=0 and i > 0])
    assert candidate(lst) == odd_sum , "This prints if this assert fails 7 (good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
