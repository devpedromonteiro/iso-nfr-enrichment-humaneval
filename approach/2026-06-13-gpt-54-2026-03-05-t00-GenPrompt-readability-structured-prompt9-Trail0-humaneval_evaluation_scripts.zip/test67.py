
import unittest
import re
import sys
import math
import copy


def fruit_distribution(fruit_description, total_fruits):
    """
    Return the number of mangoes in the basket.

    The input string contains the counts of apples and oranges, and the
    integer represents the total number of fruits in the basket.
    """

    words = fruit_description.split()
    apple_count = int(words[0])
    orange_count = int(words[3])

    mango_count = total_fruits - apple_count - orange_count
    return mango_count
candidate = fruit_distribution


def check(candidate):

    # Check some simple cases
    assert candidate("5 apples and 6 oranges",19) == 8
    assert candidate("5 apples and 6 oranges",21) == 10
    assert candidate("0 apples and 1 oranges",3) == 2
    assert candidate("1 apples and 0 oranges",3) == 2
    assert candidate("2 apples and 3 oranges",100) == 95
    assert candidate("2 apples and 3 oranges",5) == 0
    assert candidate("1 apples and 100 oranges",120) == 19


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
