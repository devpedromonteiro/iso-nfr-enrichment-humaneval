
import unittest
import re
import sys
import math
import copy


def closest_integer(value):
    """
    Return the integer closest to the numeric string ``value``.

    If the fractional part is exactly 0.5, the result is rounded away
    from zero.

    Examples
    >>> closest_integer("10")
    10
    >>> closest_integer("15.3")
    15
    >>> closest_integer("14.5")
    15
    >>> closest_integer("-14.5")
    -15
    """
    number = float(value)

    if number >= 0:
        return int(number + 0.5)

    return int(number - 0.5)
candidate = closest_integer


def check(candidate):

    # Check some simple cases
    assert candidate("10") == 10, "Test 1"
    assert candidate("14.5") == 15, "Test 2"
    assert candidate("-15.5") == -16, "Test 3"
    assert candidate("15.3") == 15, "Test 3"

    # Check some edge cases that are easy to work out by hand.
    assert candidate("0") == 0, "Test 0"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
