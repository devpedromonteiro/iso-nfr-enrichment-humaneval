
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


NUMBER_WORDS_IN_ORDER: List[str] = [
    "zero",
    "one",
    "two",
    "three",
    "four",
    "five",
    "six",
    "seven",
    "eight",
    "nine",
]

WORD_TO_VALUE = {word: value for value, word in enumerate(NUMBER_WORDS_IN_ORDER)}


def sort_numbers(numbers: str) -> str:
    """Input is a space-delimited string of numerals from 'zero' to 'nine'.

    Valid choices are 'zero', 'one', 'two', 'three', 'four', 'five',
    'six', 'seven', 'eight' and 'nine'.

    Return the string with numbers sorted from smallest to largest.

    >>> sort_numbers('three one five')
    'one three five'
    """
    number_words = numbers.split()
    sorted_number_words = sorted(number_words, key=WORD_TO_VALUE.__getitem__)
    return " ".join(sorted_number_words)
candidate = sort_numbers




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == ''
    assert candidate('three') == 'three'
    assert candidate('three five nine') == 'three five nine'
    assert candidate('five zero four seven nine eight') == 'zero four five seven eight nine'
    assert candidate('six five four three two one zero') == 'zero one two three four five six'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
