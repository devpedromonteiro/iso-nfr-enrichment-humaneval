
import unittest
import re
import sys
import math
import copy


def f(n):
    """Return a list of length n based on values from 1 to n.

    For each position corresponding to number i (starting at 1):
    - if i is even, store i!
    - if i is odd, store the sum 1 + 2 + ... + i

    Example:
        f(5) == [1, 2, 6, 24, 15]
    """
    result = []

    for number in range(1, n + 1):
        if number % 2 == 0:
            factorial = 1
            for factor in range(1, number + 1):
                factorial *= factor
            result.append(factorial)
        else:
            cumulative_sum = 0
            for value in range(1, number + 1):
                cumulative_sum += value
            result.append(cumulative_sum)

    return result
candidate = f


def check(candidate):

    assert candidate(5) == [1, 2, 6, 24, 15]
    assert candidate(7) == [1, 2, 6, 24, 15, 720, 28]
    assert candidate(1) == [1]
    assert candidate(3) == [1, 2, 6]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
