
import unittest
import re
import sys
import math
import copy


def f(n):
    """Return a list of length n based on values from 1 to n.

    For each number i from 1 to n:
    - if i is even, append i!
    - if i is odd, append the sum of numbers from 1 to i

    Example:
        f(5) == [1, 2, 6, 24, 15]
    """
    result = []
    factorial_so_far = 1
    cumulative_sum = 0

    for number in range(1, n + 1):
        factorial_so_far *= number
        cumulative_sum += number

        if number % 2 == 0:
            result.append(factorial_so_far)
        else:
            result.append(cumulative_sum)

    return result
candidate = f


def check(candidate):

    assert candidate(5) == [1, 2, 6, 24, 15]
    assert candidate(7) == [1, 2, 6, 24, 15, 720, 28]
    assert candidate(1) == [1]
    assert candidate(3) == [1, 2, 6]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
