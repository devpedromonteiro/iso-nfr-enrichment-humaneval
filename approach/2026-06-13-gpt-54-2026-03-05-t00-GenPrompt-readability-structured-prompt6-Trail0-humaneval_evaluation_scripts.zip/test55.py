
import unittest
import re
import sys
import math
import copy



def fib(position: int) -> int:
    """Return the Fibonacci number at the given 1-based position.

    >>> fib(10)
    55
    >>> fib(1)
    1
    >>> fib(8)
    21
    """
    if position <= 0:
        raise ValueError("position must be a positive integer")

    if position in (1, 2):
        return 1

    previous_value = 1
    current_value = 1

    for _ in range(3, position + 1):
        previous_value, current_value = current_value, previous_value + current_value

    return current_value
candidate = fib




METADATA = {}


def check(candidate):
    assert candidate(10) == 55
    assert candidate(1) == 1
    assert candidate(8) == 21
    assert candidate(11) == 89
    assert candidate(12) == 144



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
