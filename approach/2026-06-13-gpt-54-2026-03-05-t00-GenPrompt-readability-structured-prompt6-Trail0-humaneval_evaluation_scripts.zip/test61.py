
import unittest
import re
import sys
import math
import copy



def correct_bracketing(brackets: str) -> bool:
    """Return True if the parentheses in ``brackets`` are balanced.

    A string is considered correctly bracketed when:
    - every opening parenthesis "(" has a matching closing parenthesis ")"
    - no closing parenthesis appears before its matching opening parenthesis

    >>> correct_bracketing("(")
    False
    >>> correct_bracketing("()")
    True
    >>> correct_bracketing("(()())")
    True
    >>> correct_bracketing(")(()")
    False
    """
    open_bracket_count = 0

    for bracket in brackets:
        if bracket == "(":
            open_bracket_count += 1
        else:
            open_bracket_count -= 1

        if open_bracket_count < 0:
            return False

    return open_bracket_count == 0
candidate = correct_bracketing




METADATA = {}


def check(candidate):
    assert candidate("()")
    assert candidate("(()())")
    assert candidate("()()(()())()")
    assert candidate("()()((()()())())(()()(()))")
    assert not candidate("((()())))")
    assert not candidate(")(()")
    assert not candidate("(")
    assert not candidate("((((")
    assert not candidate(")")
    assert not candidate("(()")
    assert not candidate("()()(()())())(()")
    assert not candidate("()()(()())()))()")



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
