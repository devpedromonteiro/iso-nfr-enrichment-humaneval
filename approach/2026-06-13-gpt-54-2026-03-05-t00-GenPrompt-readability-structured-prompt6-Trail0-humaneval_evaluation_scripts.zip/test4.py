
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def mean_absolute_deviation(numbers: List[float]) -> float:
    """Calculate the mean absolute deviation around the mean.

    Mean Absolute Deviation (MAD) is the average absolute distance between
    each value and the mean of the dataset.

    Formula:
        MAD = average(|x - mean|)

    >>> mean_absolute_deviation([1.0, 2.0, 3.0, 4.0])
    1.0
    """
    mean_value = sum(numbers) / len(numbers)

    absolute_deviations = [
        abs(number - mean_value)
        for number in numbers
    ]

    return sum(absolute_deviations) / len(absolute_deviations)
candidate = mean_absolute_deviation




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert abs(candidate([1.0, 2.0, 3.0]) - 2.0/3.0) < 1e-6
    assert abs(candidate([1.0, 2.0, 3.0, 4.0]) - 1.0) < 1e-6
    assert abs(candidate([1.0, 2.0, 3.0, 4.0, 5.0]) - 6.0/5.0) < 1e-6



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
