
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    Return the number of index triples (i, j, k) with 1 <= i < j < k <= n
    such that:
        a[i] + a[j] + a[k] is divisible by 3

    where:
        a[x] = x * x - x + 1

    Observation:
        a[x] % 3 depends only on x % 3.

        If x % 3 == 0 -> a[x] % 3 == 1
        If x % 3 == 1 -> a[x] % 3 == 1
        If x % 3 == 2 -> a[x] % 3 == 0

    So every element in the array belongs to one of two residue groups:
        remainder 0 modulo 3
        remainder 1 modulo 3

    A triple sum is divisible by 3 only in this case:
        1 + 1 + 1 == 0 (mod 3)

    Therefore, we only need to count how many array values are congruent to 1 mod 3,
    then compute how many ways to choose 3 of them.
    """
    count_remainder_zero = n // 3
    count_remainder_one = n - count_remainder_zero

    if count_remainder_one < 3:
        return 0

    return count_remainder_one * (count_remainder_one - 1) * (count_remainder_one - 2) // 6
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
