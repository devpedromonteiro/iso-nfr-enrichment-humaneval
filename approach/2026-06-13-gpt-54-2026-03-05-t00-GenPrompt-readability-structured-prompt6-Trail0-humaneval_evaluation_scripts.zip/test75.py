
import unittest
import re
import sys
import math
import copy


def is_multiply_prime(number):
    """Return True if number is the product of exactly three prime numbers.

    The three prime factors do not need to be distinct.
    Examples:
        30 = 2 * 3 * 5  -> True
         8 = 2 * 2 * 2  -> True
        12 = 2 * 2 * 3  -> True
    """
    if number < 2:
        return False

    prime_factor_count = 0
    remaining_value = number
    divisor = 2

    while divisor * divisor <= remaining_value and prime_factor_count <= 3:
        while remaining_value % divisor == 0:
            prime_factor_count += 1
            remaining_value //= divisor

            if prime_factor_count > 3:
                return False

        divisor += 1

    if remaining_value > 1:
        prime_factor_count += 1

    return prime_factor_count == 3
candidate = is_multiply_prime


def check(candidate):

    assert candidate(5) == False
    assert candidate(30) == True
    assert candidate(8) == True
    assert candidate(10) == False
    assert candidate(125) == True
    assert candidate(3 * 5 * 7) == True
    assert candidate(3 * 6 * 7) == False
    assert candidate(9 * 9 * 9) == False
    assert candidate(11 * 9 * 9) == False
    assert candidate(11 * 13 * 7) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
