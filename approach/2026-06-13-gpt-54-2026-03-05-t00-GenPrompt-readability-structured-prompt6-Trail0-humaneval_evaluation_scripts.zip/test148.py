
import unittest
import re
import sys
import math
import copy


def bf(planet1, planet2):
    """
    Return a tuple of planets located between two given planets, ordered by
    distance from the Sun.

    If either input is not a valid planet name, return an empty tuple.
    """
    planets_by_distance = (
        "Mercury",
        "Venus",
        "Earth",
        "Mars",
        "Jupiter",
        "Saturn",
        "Uranus",
        "Neptune",
    )

    if planet1 not in planets_by_distance or planet2 not in planets_by_distance:
        return ()

    first_planet_index = planets_by_distance.index(planet1)
    second_planet_index = planets_by_distance.index(planet2)

    start_index = min(first_planet_index, second_planet_index) + 1
    end_index = max(first_planet_index, second_planet_index)

    return planets_by_distance[start_index:end_index]
candidate = bf


def check(candidate):

    # Check some simple cases
    assert candidate("Jupiter", "Neptune") == ("Saturn", "Uranus"), "First test error: " + str(len(candidate("Jupiter", "Neptune")))      
    assert candidate("Earth", "Mercury") == ("Venus",), "Second test error: " + str(candidate("Earth", "Mercury"))  
    assert candidate("Mercury", "Uranus") == ("Venus", "Earth", "Mars", "Jupiter", "Saturn"), "Third test error: " + str(candidate("Mercury", "Uranus"))      
    assert candidate("Neptune", "Venus") == ("Earth", "Mars", "Jupiter", "Saturn", "Uranus"), "Fourth test error: " + str(candidate("Neptune", "Venus"))  


    # Check some edge cases that are easy to work out by hand.
    assert candidate("Earth", "Earth") == ()
    assert candidate("Mars", "Earth") == ()
    assert candidate("Jupiter", "Makemake") == ()



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
