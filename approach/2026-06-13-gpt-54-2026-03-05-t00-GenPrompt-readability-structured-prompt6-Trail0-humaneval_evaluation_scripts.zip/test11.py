
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def string_xor(left_bits: str, right_bits: str) -> str:
    """Return the bitwise XOR of two equal-length binary strings.

    Each input string must contain only the characters '0' and '1'.

    >>> string_xor("010", "110")
    '100'
    """
    xor_bits: List[str] = []

    for left_bit, right_bit in zip(left_bits, right_bits):
        xor_bit = "0" if left_bit == right_bit else "1"
        xor_bits.append(xor_bit)

    return "".join(xor_bits)
candidate = string_xor




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('111000', '101010') == '010010'
    assert candidate('1', '1') == '0'
    assert candidate('0101', '0000') == '0101'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
