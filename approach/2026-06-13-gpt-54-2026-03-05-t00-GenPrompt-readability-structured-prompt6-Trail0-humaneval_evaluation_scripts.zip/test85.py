
import unittest
import re
import sys
import math
import copy


def add(numbers):
    """Return the sum of even values located at odd indices.

    Args:
        numbers: A non-empty list of integers.

    Returns:
        The sum of elements that are both:
        - at an odd index
        - even numbers

    Examples:
        add([4, 2, 6, 7]) == 2
    """
    total = 0

    for index, value in enumerate(numbers):
        is_odd_index = index % 2 == 1
        is_even_value = value % 2 == 0

        if is_odd_index and is_even_value:
            total += value

    return total
candidate = add


def check(candidate):

    # Check some simple cases
    assert candidate([4, 88]) == 88
    assert candidate([4, 5, 6, 7, 2, 122]) == 122
    assert candidate([4, 0, 6, 7]) == 0
    assert candidate([4, 4, 6, 8]) == 12

    # Check some edge cases that are easy to work out by hand.
    


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
