
import unittest
import re
import sys
import math
import copy



def how_many_times(text: str, pattern: str) -> int:
    """Count how many times a substring appears in a string, including overlaps.

    >>> how_many_times('', 'a')
    0
    >>> how_many_times('aaa', 'a')
    3
    >>> how_many_times('aaaa', 'aa')
    3
    """
    if not pattern:
        return 0

    match_count = 0
    pattern_length = len(pattern)
    last_start_index = len(text) - pattern_length

    for start_index in range(last_start_index + 1):
        if text[start_index:start_index + pattern_length] == pattern:
            match_count += 1

    return match_count
candidate = how_many_times




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('', 'x') == 0
    assert candidate('xyxyxyx', 'x') == 4
    assert candidate('cacacacac', 'cac') == 4
    assert candidate('john doe', 'john') == 1


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
