
import unittest
import re
import sys
import math
import copy



def triangle_area(base_length, height):
    """Return the area of a triangle.

    The area is calculated as (base_length * height) / 2.

    >>> triangle_area(5, 3)
    7.5
    """
    area = (base_length * height) / 2
    return area
candidate = triangle_area




METADATA = {}


def check(candidate):
    assert candidate(5, 3) == 7.5
    assert candidate(2, 2) == 2.0
    assert candidate(10, 8) == 40.0



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
