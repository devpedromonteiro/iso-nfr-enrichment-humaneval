
import unittest
import re
import sys
import math
import copy


def unique_digits(numbers):
    """Return the sorted numbers that contain no even digits.

    A number is included only if every one of its digits is odd.

    Examples:
    >>> unique_digits([15, 33, 1422, 1])
    [1, 15, 33]
    >>> unique_digits([152, 323, 1422, 10])
    []
    """
    def has_only_odd_digits(number):
        even_digits = {"0", "2", "4", "6", "8"}
        return all(digit not in even_digits for digit in str(number))

    numbers_with_only_odd_digits = [
        number for number in numbers if has_only_odd_digits(number)
    ]

    return sorted(numbers_with_only_odd_digits)
candidate = unique_digits


def check(candidate):

    # Check some simple cases
    assert candidate([15, 33, 1422, 1]) == [1, 15, 33]
    assert candidate([152, 323, 1422, 10]) == []
    assert candidate([12345, 2033, 111, 151]) == [111, 151]
    assert candidate([135, 103, 31]) == [31, 135]

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
