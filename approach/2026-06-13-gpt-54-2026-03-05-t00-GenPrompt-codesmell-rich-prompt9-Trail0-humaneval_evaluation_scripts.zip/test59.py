
import unittest
import re
import sys
import math
import copy



def largest_prime_factor(n: int):
    """Return the largest prime factor of n. Assume n > 1 and is not a prime.
    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    remaining = n
    largest = None

    def divide_out_factor(value: int, factor: int) -> int:
        while value % factor == 0:
            value //= factor
        return value

    if remaining % 2 == 0:
        largest = 2
        remaining = divide_out_factor(remaining, 2)

    factor = 3
    while factor * factor <= remaining:
        if remaining % factor == 0:
            largest = factor
            remaining = divide_out_factor(remaining, factor)
        factor += 2

    return remaining if remaining > 1 else largest
candidate = largest_prime_factor




METADATA = {}


def check(candidate):
    assert candidate(15) == 5
    assert candidate(27) == 3
    assert candidate(63) == 7
    assert candidate(330) == 11
    assert candidate(13195) == 29



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
