
import unittest
import re
import sys
import math
import copy


def split_words(txt):
    """
    Given a string of words, return a list of words split on whitespace.
    If no whitespace exists in the text, split on commas ','.
    If no commas exist, return the number of lower-case letters with odd
    order in the alphabet, where ord('a') = 0, ord('b') = 1, ... ord('z') = 25.

    Examples
    split_words("Hello world!") -> ["Hello", "world!"]
    split_words("Hello,world!") -> ["Hello", "world!"]
    split_words("abcdef") -> 3
    """
    if _contains_whitespace(txt):
        return txt.split()

    if _contains_comma(txt):
        return txt.split(",")

    return _count_odd_order_lowercase_letters(txt)


def _contains_whitespace(text):
    return any(char.isspace() for char in text)


def _contains_comma(text):
    return "," in text


def _count_odd_order_lowercase_letters(text):
    return sum(1 for char in text if _is_odd_order_lowercase(char))


def _is_odd_order_lowercase(char):
    return char.islower() and char.isalpha() and (ord(char) - ord("a")) % 2 == 1
candidate = split_words


def check(candidate):

    assert candidate("Hello world!") == ["Hello","world!"]
    assert candidate("Hello,world!") == ["Hello","world!"]
    assert candidate("Hello world,!") == ["Hello","world,!"]
    assert candidate("Hello,Hello,world !") == ["Hello,Hello,world","!"]
    assert candidate("abcdef") == 3
    assert candidate("aaabb") == 2
    assert candidate("aaaBb") == 1
    assert candidate("") == 0


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
