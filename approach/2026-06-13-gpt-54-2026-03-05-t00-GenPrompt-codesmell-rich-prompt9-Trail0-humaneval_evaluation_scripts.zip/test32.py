
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math
from typing import List


def poly(coefficients: List[float], x: float) -> float:
    """
    Evaluate a polynomial with coefficients at point x.

    coefficients[i] is the coefficient for x^i.
    """
    return sum(coeff * math.pow(x, i) for i, coeff in enumerate(coefficients))


def _validate_coefficients(coefficients: List[float]) -> None:
    """
    Validate the constraints required by find_zero.
    """
    if not coefficients:
        raise ValueError("coefficients must not be empty")

    if len(coefficients) % 2 != 0:
        raise ValueError("find_zero requires an even number of coefficients")

    if coefficients[-1] == 0:
        raise ValueError("largest coefficient must be non-zero")


def _derivative(coefficients: List[float]) -> List[float]:
    """
    Return the derivative polynomial coefficients.
    """
    return [i * coeff for i, coeff in enumerate(coefficients)][1:]


def _find_bound(coefficients: List[float]) -> float:
    """
    Find a symmetric search bound guaranteed to contain at least one root
    under the documented constraints.
    """
    leading = abs(coefficients[-1])
    max_other = max((abs(c) for c in coefficients[:-1]), default=0.0)
    return 1.0 + max_other / leading


def _bisect_root(coefficients: List[float], left: float, right: float, *, tolerance: float = 1e-10) -> float:
    """
    Find a root in [left, right] assuming the polynomial changes sign there.
    """
    f_left = poly(coefficients, left)
    f_right = poly(coefficients, right)

    if f_left == 0:
        return left
    if f_right == 0:
        return right

    while right - left > tolerance:
        mid = (left + right) / 2
        f_mid = poly(coefficients, mid)

        if f_mid == 0:
            return mid

        if f_left * f_mid < 0:
            right = mid
            f_right = f_mid
        else:
            left = mid
            f_left = f_mid

    return (left + right) / 2


def find_zero(coefficients: List[float]) -> float:
    """
    Find one real zero of a polynomial.

    The function assumes:
    - coefficients has an even number of elements
    - the highest-degree coefficient is non-zero

    Under these constraints, the polynomial degree is odd, so at least one
    real root exists.

    >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2)
    1.0
    """
    _validate_coefficients(coefficients)

    bound = _find_bound(coefficients)
    left = -bound
    right = bound

    f_left = poly(coefficients, left)
    f_right = poly(coefficients, right)

    if f_left == 0:
        return left
    if f_right == 0:
        return right

    if f_left * f_right > 0:
        raise ValueError("could not bracket a root")

    return _bisect_root(coefficients, left, right)
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
