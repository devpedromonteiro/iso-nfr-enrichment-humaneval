
import unittest
import re
import sys
import math
import copy


def is_prime(number):
    """Return True if number is prime, otherwise False."""
    if number < 2:
        return False
    if number == 2:
        return True
    if number % 2 == 0:
        return False

    divisor = 3
    while divisor * divisor <= number:
        if number % divisor == 0:
            return False
        divisor += 2
    return True


def has_prime_length(word):
    """Return True if the word length is a prime number."""
    return is_prime(len(word))


def words_in_sentence(sentence):
    """
    Return a string containing only the words whose lengths are prime numbers,
    preserving their original order.
    """
    words = sentence.split()
    prime_length_words = [word for word in words if has_prime_length(word)]
    return " ".join(prime_length_words)
candidate = words_in_sentence


def check(candidate):

    # Check some simple cases
    assert candidate("This is a test") == "is"
    assert candidate("lets go for swimming") == "go for"
    assert candidate("there is no place available here") == "there is no place"
    assert candidate("Hi I am Hussein") == "Hi am Hussein"
    assert candidate("go for it") == "go for it"

    # Check some edge cases that are easy to work out by hand.
    assert candidate("here") == ""
    assert candidate("here is") == "is"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
