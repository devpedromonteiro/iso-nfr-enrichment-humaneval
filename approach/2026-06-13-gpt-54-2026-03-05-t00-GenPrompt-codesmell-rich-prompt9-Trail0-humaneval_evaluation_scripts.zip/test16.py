
import unittest
import re
import sys
import math
import copy



def _normalize_characters(string: str) -> str:
    """Return a lowercase version of the input string."""
    return string.lower()


def _get_distinct_characters(string: str) -> set[str]:
    """Return the set of distinct characters in the string."""
    return set(_normalize_characters(string))


def count_distinct_characters(string: str) -> int:
    """Given a string, find out how many distinct characters
    (regardless of case) it consists of.

    >>> count_distinct_characters('xyzXYZ')
    3
    >>> count_distinct_characters('Jerry')
    4
    """
    return len(_get_distinct_characters(string))
candidate = count_distinct_characters




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == 0
    assert candidate('abcde') == 5
    assert candidate('abcde' + 'cade' + 'CADE') == 5
    assert candidate('aaaaAAAAaaaa') == 1
    assert candidate('Jerry jERRY JeRRRY') == 5


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
