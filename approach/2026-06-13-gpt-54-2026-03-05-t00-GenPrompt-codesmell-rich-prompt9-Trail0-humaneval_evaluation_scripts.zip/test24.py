
import unittest
import re
import sys
import math
import copy



def largest_divisor(n: int) -> int:
    """Return the largest proper divisor of ``n``.

    A proper divisor divides ``n`` evenly and is smaller than ``n``.

    >>> largest_divisor(15)
    5
    """
    _validate_input(n)

    for divisor in range(n // 2, 0, -1):
        if _is_divisor(n, divisor):
            return divisor

    raise ValueError("n must be greater than 1")


def _is_divisor(number: int, candidate: int) -> bool:
    """Return True if candidate divides number evenly."""
    return number % candidate == 0


def _validate_input(n: int) -> None:
    """Validate input for largest_divisor."""
    if n <= 1:
        raise ValueError("n must be greater than 1")
candidate = largest_divisor




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(3) == 1
    assert candidate(7) == 1
    assert candidate(10) == 5
    assert candidate(100) == 50
    assert candidate(49) == 7


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
