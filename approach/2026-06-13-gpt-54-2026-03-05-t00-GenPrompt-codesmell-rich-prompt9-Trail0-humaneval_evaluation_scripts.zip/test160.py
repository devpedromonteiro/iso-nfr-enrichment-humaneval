
import unittest
import re
import sys
import math
import copy


def _validate_inputs(operators, operands):
    if len(operators) != len(operands) - 1:
        raise ValueError("The number of operators must be exactly one less than the number of operands.")


def _apply_operator(left, operator, right):
    operations = {
        "+": lambda a, b: a + b,
        "-": lambda a, b: a - b,
        "*": lambda a, b: a * b,
        "//": lambda a, b: a // b,
        "**": lambda a, b: a ** b,
    }

    if operator not in operations:
        raise ValueError(f"Unsupported operator: {operator}")

    return operations[operator](left, right)


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and
    the second list is a list of integers. Use the two given lists to build the algebraic
    expression and return the evaluation of this expression.

    The basic algebra operations:
    Addition ( + )
    Subtraction ( - )
    Multiplication ( * )
    Floor division ( // )
    Exponentiation ( ** )

    Example:
    operator = ['+', '*', '-']
    operand = [2, 3, 4, 5]
    result = 2 + 3 * 4 - 5
    => result = 9

    Note:
        The length of operator list is equal to the length of operand list minus one.
        Operand is a list of non-negative integers.
        Operator list has at least one operator, and operand list has at least two operands.
    """
    _validate_inputs(operator, operand)

    expression = [operand[0]]
    for op, value in zip(operator, operand[1:]):
        expression.extend([op, value])

    precedence_levels = [
        {"**"},
        {"*", "//"},
        {"+", "-"},
    ]

    for current_ops in precedence_levels:
        reduced_expression = []
        index = 0

        while index < len(expression):
            token = expression[index]

            if (
                isinstance(token, str)
                and token in current_ops
                and reduced_expression
                and index + 1 < len(expression)
            ):
                left = reduced_expression.pop()
                right = expression[index + 1]
                reduced_expression.append(_apply_operator(left, token, right))
                index += 2
            else:
                reduced_expression.append(token)
                index += 1

        expression = reduced_expression

    return expression[0]
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
