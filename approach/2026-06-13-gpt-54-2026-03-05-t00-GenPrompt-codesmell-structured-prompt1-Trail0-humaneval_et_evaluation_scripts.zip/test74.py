
import unittest


def _total_char_count(strings):
    """Return the total number of characters across all strings in the list."""
    return sum(len(string) for string in strings)


def total_match(lst1, lst2):
    """
    Return the list whose strings have the smaller total character count.
    If both totals are equal, return the first list.
    """
    total_lst1 = _total_char_count(lst1)
    total_lst2 = _total_char_count(lst2)

    return lst1 if total_lst1 <= total_lst2 else lst2
candidate = total_match


class Test(unittest.TestCase):
    def test(self):
        assert candidate(['0'], ['2', '1', '5', '0', '1']) == ['0']
        assert candidate(['cgpz', 'xszax'], ['NBpw', 'jsvti', 'ldglw']) == ['cgpz', 'xszax']
        assert candidate(['mzpigv', 'ohdkfev'], ['qxar', 'zsnp', 'wkhdqgob', 'lccizt']) == ['mzpigv', 'ohdkfev']
        assert candidate(['jnf', 'xpd'], ['tIxE', 'JQPWvU']) == ['jnf', 'xpd']
        assert candidate(['noqv', 'mrod'], ['nmi', 'xedwkq']) == ['noqv', 'mrod']
        assert candidate(['bsmcnk', 'gmirteebn'], ['wkej', 'fjzmb', 'awebiu', 'nwnurukytme']) == ['bsmcnk', 'gmirteebn']
        assert candidate(['paohv', 'llhlltr'], ['CnjDg', 'fykwe', 'thrjcrap']) == ['paohv', 'llhlltr']
        assert candidate(['2'], ['0', '3', '2', '8', '1']) == ['2']
        assert candidate(['djze', 'ynurnbkop'], ['iBlv', 'izjbl', 'jnp']) == ['iBlv', 'izjbl', 'jnp']
        assert candidate(['0'], ['7', '3', '2', '9', '0']) == ['0']
        assert candidate(['xxqfp', 'skxvjch'], ['gpbmy', 'zvk']) == ['gpbmy', 'zvk']
        assert candidate(['kip', 'afxldkr'], ['odvrbz', 'jfv']) == ['odvrbz', 'jfv']
        assert candidate(['wqc', 'ntwdjvatg'], ['yybjwi', 'sjnx', 'naldqg', 'nffuptrzcjh']) == ['wqc', 'ntwdjvatg']
        assert candidate(['hi', 'admin'], ['hI', 'hi', 'hi']) == ['hI', 'hi', 'hi']
        assert candidate([], ['jnk']) == []
        assert candidate(['uing', 'vnstvg'], ['KGMU', 'oie', 'pbhpoqm']) == ['uing', 'vnstvg']
        assert candidate([], ['oalzawl']) == []
        assert candidate(['9'], ['9', '4', '2', '8', '8']) == ['9']
        assert candidate([], ['lrzdjbpbp']) == []
        assert candidate(['7'], ['9', '0', '5', '2', '8']) == ['7']
        assert candidate([], ['lzvwcxfm']) == []
        assert candidate([], ['esqe']) == []
        assert candidate([], ['aospj']) == []
        assert candidate(['lgtpwb', 'xbgfppc'], ['hvh', 'pyq', 'czktqi', 'pflzxbvcl']) == ['lgtpwb', 'xbgfppc']
        assert candidate([], ['sxwto']) == []
        assert candidate(['ardn', 'mmwhbpb'], ['Mfkb', 'XuHTQG']) == ['Mfkb', 'XuHTQG']
        assert candidate(['dmeo', 'qnkoepksc'], ['zno', 'kbt']) == ['zno', 'kbt']
        assert candidate(['qxmmc', 'fvvle'], ['Islf', 'ttxkyx', 'cuhcat']) == ['qxmmc', 'fvvle']
        assert candidate(['bdjdb', 'fvigxnhw'], ['fLBCb', 'NHwmP']) == ['fLBCb', 'NHwmP']
        assert candidate(['hrx', 'tfqwzyd'], ['fzo', 'tnjfbl']) == ['fzo', 'tnjfbl']
        assert candidate(['qumb', 'qcyikz'], ['SSQC', 'xvyut', 'picy']) == ['qumb', 'qcyikz']
        assert candidate([], []) == []
        assert candidate(['lbjjkd', 'tcjx'], ['kwGm', 'mbit', 'dxbln']) == ['lbjjkd', 'tcjx']
        assert candidate(['bmmha', 'nhfqupt'], ['zgcwia', 'sfe', 'tzf', 'nhr']) == ['bmmha', 'nhfqupt']
        assert candidate(['npn', 'nfiehn'], ['UPTvt', 'gaua', 'zlwa']) == ['npn', 'nfiehn']
        assert candidate(['igftl', 'tkmaax'], ['mlojy', 'zbath', 'rosz', 'glvdwzycmsr']) == ['igftl', 'tkmaax']
        assert candidate(['htlu', 'btg'], ['nWfUbi', 'kezzg', 'vjwhx']) == ['htlu', 'btg']
        assert candidate(['8'], ['8', '2', '7', '8', '9']) == ['8']
        assert candidate(['vmuywl', 'jjjbxnb'], ['RRq', 'jyyq', 'xcejyjcyi']) == ['vmuywl', 'jjjbxnb']
        assert candidate(['rcoo', 'hhweadvl'], ['ahTkUL', 'ahrjpd', 'cfngg']) == ['rcoo', 'hhweadvl']
        assert candidate([], ['gkfsf']) == []
        assert candidate(['bmw', 'rfhst'], ['jikO', 'tqepf', 'wxi']) == ['bmw', 'rfhst']
        assert candidate(['6'], ['5', '8', '3', '0', '6']) == ['6']
        assert candidate(['mcji', 'rsofzj'], ['cqLjne', 'fha', 'ofwn']) == ['mcji', 'rsofzj']
        assert candidate(['4'], ['0', '9', '7', '0', '1']) == ['4']
        assert candidate(['5'], ['8', '1', '0', '2', '2']) == ['5']
        assert candidate(['3'], ['7', '4', '6', '0', '1']) == ['3']
        assert candidate(['glihe', 'ajce'], ['OHvTd', 'gwUKG']) == ['glihe', 'ajce']
        assert candidate([], ['urcxh']) == []
        assert candidate(['this'], []) == []
        assert candidate([], ['hzzixniek']) == []
        assert candidate([], ['gqmjhnjms']) == []
        assert candidate(['dnse', 'yfluvb'], ['bgbx', 'jwdou', 'ebrfvxwp', 'vvqujepncrv']) == ['dnse', 'yfluvb']
        assert candidate([], ['ohfdzarl']) == []
        assert candidate(['hi', 'admin'], ['hI', 'Hi']) == ['hI', 'Hi']
        assert candidate(['zimfb', 'ybllki'], ['eos', 'karf']) == ['eos', 'karf']
        assert candidate(['tjqa', 'sxzq'], ['ojw', 'jpy', 'vpefnv', 'bdbxf']) == ['tjqa', 'sxzq']
        assert candidate(['lntjf', 'zfehism'], ['nKee', 'bzJMVh']) == ['nKee', 'bzJMVh']
        assert candidate(['svqv', 'jvvqs'], ['vtc', 'aylk']) == ['vtc', 'aylk']
        assert candidate(['eebxoh', 'nixliaavb'], ['agqf', 'qwu', 'rpyuhpiar', 'gnehgs']) == ['eebxoh', 'nixliaavb']
        assert candidate(['zzc', 'wtv'], ['gRno', 'mkfn', 'mohepd']) == ['zzc', 'wtv']
        assert candidate(['cbn', 'grjg'], ['lltl', 'vxjupk', 'qxdptxdss']) == ['cbn', 'grjg']
        assert candidate(['hbvqy', 'pfahngdrj'], ['jqp', 'kvpafq', 'sysht', 'hvkcyumt']) == ['hbvqy', 'pfahngdrj']
        assert candidate(['ozlrwf', 'znrbo'], ['Hurkru', 'gtvadb', 'dntqu']) == ['ozlrwf', 'znrbo']
        assert candidate(['1'], ['2', '3', '7', '7', '8']) == ['1']
        assert candidate(['ovkchl', 'bkrnlfsp'], ['IRgZA', 'mywP']) == ['IRgZA', 'mywP']
        assert candidate(['ojdi', 'ywdy'], ['Ztuyh', 'vbuir', 'lbf']) == ['ojdi', 'ywdy']
        assert candidate(['eni', 'kaaxaq'], ['bmTIEx', 'pZful']) == ['eni', 'kaaxaq']
        assert candidate(['ykxw', 'zbyl'], ['kmn', 'tpogo']) == ['ykxw', 'zbyl']
        assert candidate(['wow', 'ljbc'], ['vnRN', 'gDh']) == ['wow', 'ljbc']
        assert candidate(['ifc', 'mekydfv'], ['NPBP', 'yhsb', 'hxbmpq']) == ['ifc', 'mekydfv']
        assert candidate(['6'], ['7', '3', '1', '5', '5']) == ['6']
        assert candidate(['fozvsq', 'irypjl'], ['ssirjv', 'ouxowl']) == ['fozvsq', 'irypjl']
        assert candidate(['qie', 'pcgvnlt'], ['keyp', 'mrg', 'rymhlu', 'msssnw']) == ['qie', 'pcgvnlt']
        assert candidate(['uey', 'ksrrlgr'], ['qfm', 'esmcaf', 'pmjazyke', 'npigr']) == ['uey', 'ksrrlgr']
        assert candidate(['kybhlz', 'jbdfpg'], ['gSFyj', 'CsYY']) == ['gSFyj', 'CsYY']
        assert candidate(['0'], ['9', '5', '2', '0', '8']) == ['0']
        assert candidate(['hi', 'admin'], ['hi', 'hi']) == ['hi', 'hi']
        assert candidate(['7'], ['6', '7', '2', '9', '7']) == ['7']
        assert candidate(['xqidu', 'hnph'], ['fEbF', 'tlah', 'ckejhrhz']) == ['xqidu', 'hnph']
        assert candidate([], ['this']) == []
        assert candidate([], ['qujl']) == []
        assert candidate(['jvgh', 'hlimtafj'], ['GBg', 'mvttgn', 'vkdx']) == ['jvgh', 'hlimtafj']
        assert candidate(['kqe', 'sodpst'], ['AZWyD', 'tfkqtw', 'rozvk']) == ['kqe', 'sodpst']
        assert candidate(['gpeg', 'amlxxqla'], ['GLM', 'KHdOaZ']) == ['GLM', 'KHdOaZ']
        assert candidate(['tplpe', 'yzizq'], ['WHYZWP', 'wtd', 'xoqufoias']) == ['tplpe', 'yzizq']
        assert candidate(['mexur', 'eweclnqa'], ['jgd', 'ytfl']) == ['jgd', 'ytfl']
        assert candidate(['ruif', 'vqdcfk'], ['iCJaE', 'oyhbj', 'nlxjqsvx']) == ['ruif', 'vqdcfk']
        assert candidate(['bon', 'dhfnxi'], ['xpqtuo', 'sdykpo']) == ['bon', 'dhfnxi']
        assert candidate(['ilqm', 'pvvz'], ['mxWkBQ', 'MDljnN']) == ['ilqm', 'pvvz']
        assert candidate(['nemm', 'lyf'], ['chxjd', 'cfjwc']) == ['nemm', 'lyf']
        assert candidate(['gmfbtd', 'zxkdswl'], ['uzHJV', 'olx', 'zgljwk']) == ['gmfbtd', 'zxkdswl']
        assert candidate(['woh', 'jviqyrgo'], ['gnLdW', 'yhup', 'dnx']) == ['woh', 'jviqyrgo']
        assert candidate(['4'], ['1', '2', '3', '4', '5']) == ['4']
        assert candidate([], ['zsoeys']) == []
        assert candidate(['qka', 'zhtvol'], ['Yzg', 'dgtw', 'qmpag']) == ['qka', 'zhtvol']
        assert candidate(['gzzji', 'boz'], ['kOuf', 'hRDYu']) == ['gzzji', 'boz']
        assert candidate(['bgbkd', 'juq'], ['mjmdcv', 'slearh']) == ['bgbkd', 'juq']
        assert candidate(['qnwod', 'uzv'], ['ryd', 'asskh', 'yrwkmu', 'xqh']) == ['qnwod', 'uzv']
        assert candidate(['lyh', 'nic'], ['hjNr', 'YJavSm']) == ['lyh', 'nic']
        assert candidate(['wqmar', 'bpzb'], ['BlDN', 'qpi', 'wuwogq']) == ['wqmar', 'bpzb']
        assert candidate(['vmvhjd', 'rzravingv'], ['qKhzdi', 'TydVAV']) == ['qKhzdi', 'TydVAV']
        assert candidate(['kret', 'rqjkgth'], ['tuui', 'xdg', 'kgbwpziff', 'ctefa']) == ['kret', 'rqjkgth']
        assert candidate(['hi', 'admin'], ['hI', 'hi', 'hii']) == ['hi', 'admin']


    # Check some edge cases that are easy to work out by hand.
        assert candidate(['rpeilt', 'mbmspvh'], ['IPr', 'qyquv', 'ohq']) == ['IPr', 'qyquv', 'ohq']
        assert candidate(['hwsyak', 'lzkuljmob'], ['brxzfw', 'vyib']) == ['brxzfw', 'vyib']
        assert candidate(['hi', 'admin'], ['hi', 'hi', 'admin', 'project']) == ['hi', 'admin']

if __name__ == '__main__':
    unittest.main()
