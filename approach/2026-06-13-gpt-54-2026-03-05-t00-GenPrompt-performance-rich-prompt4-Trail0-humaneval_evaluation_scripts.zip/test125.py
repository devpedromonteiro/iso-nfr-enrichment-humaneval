
import unittest
import re
import sys
import math
import copy


def split_words(txt):
    """
    Given a string of words, return a list of words split on whitespace.
    If no whitespace exists, split on commas ','.
    If no commas exist, return the number of lower-case letters whose
    alphabet index is odd: a=0, b=1, ..., z=25.
    """
    if any(ch.isspace() for ch in txt):
        return txt.split()

    if ',' in txt:
        return txt.split(',')

    count = 0
    for ch in txt:
        if 'a' <= ch <= 'z' and ((ord(ch) - ord('a')) & 1):
            count += 1
    return count
candidate = split_words


def check(candidate):

    assert candidate("Hello world!") == ["Hello","world!"]
    assert candidate("Hello,world!") == ["Hello","world!"]
    assert candidate("Hello world,!") == ["Hello","world,!"]
    assert candidate("Hello,Hello,world !") == ["Hello,Hello,world","!"]
    assert candidate("abcdef") == 3
    assert candidate("aaabb") == 2
    assert candidate("aaaBb") == 1
    assert candidate("") == 0


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
