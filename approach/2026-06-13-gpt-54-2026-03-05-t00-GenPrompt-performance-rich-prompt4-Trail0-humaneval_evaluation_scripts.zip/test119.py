
import unittest
import re
import sys
import math
import copy


def match_parens(lst):
    def is_good_concat(a, b):
        balance = 0
        for ch in a:
            balance += 1 if ch == '(' else -1
            if balance < 0:
                return False
        for ch in b:
            balance += 1 if ch == '(' else -1
            if balance < 0:
                return False
        return balance == 0

    a, b = lst
    return 'Yes' if is_good_concat(a, b) or is_good_concat(b, a) else 'No'
candidate = match_parens


def check(candidate):

    # Check some simple cases
    assert candidate(['()(', ')']) == 'Yes'
    assert candidate([')', ')']) == 'No'
    assert candidate(['(()(())', '())())']) == 'No'
    assert candidate([')())', '(()()(']) == 'Yes'
    assert candidate(['(())))', '(()())((']) == 'Yes'
    assert candidate(['()', '())']) == 'No'
    assert candidate(['(()(', '()))()']) == 'Yes'
    assert candidate(['((((', '((())']) == 'No'
    assert candidate([')(()', '(()(']) == 'No'
    assert candidate([')(', ')(']) == 'No'
    

    # Check some edge cases that are easy to work out by hand.
    assert candidate(['(', ')']) == 'Yes'
    assert candidate([')', '(']) == 'Yes' 



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
