
import unittest



def encode_shift(s: str):
    """
    returns encoded string by shifting every character by 5 in the alphabet.
    """
    return "".join([chr(((ord(ch) + 5 - ord("a")) % 26) + ord("a")) for ch in s])


def encode_shift(text: str) -> str:
    """
    Return a new string where each lowercase letter is shifted forward by 5.

    Example:
        "abc" -> "fgh"
        "xyz" -> "cde"
    """
    shift_amount = 5
    encoded_characters = []

    for character in text:
        original_position = ord(character) - ord("a")
        shifted_position = (original_position + shift_amount) % 26
        encoded_character = chr(shifted_position + ord("a"))
        encoded_characters.append(encoded_character)

    return "".join(encoded_characters)


def decode_shift(text: str) -> str:
    """
    Return the original string by shifting each lowercase letter backward by 5.

    This function reverses the transformation performed by encode_shift.
    """
    shift_amount = 5
    decoded_characters = []

    for character in text:
        encoded_position = ord(character) - ord("a")
        original_position = (encoded_position - shift_amount) % 26
        decoded_character = chr(original_position + ord("a"))
        decoded_characters.append(decoded_character)

    return "".join(decoded_characters)
candidate = decode_shift


class Test(unittest.TestCase):
    def test(self):
        assert candidate("ce#wkoapw.[bev%^o=bgyd+lvczhy)") == 'xzlrfjvkrwpwzqnsjlwbtytgqxuctr'
        assert candidate("x=j<o!?nvf_swj<z#[m=)}***") == 'slekjjniqatnrekulphlrxsss'
        assert candidate("^sf.*#|t*}<|(m<>[.^l*z") == 'snawslwosxkwqhkmpwsgsu'
        assert candidate("gat=r%_oh?kl(#tna.|{-mnee") == 'bvolmntjcnfgqloivwwvvhizz'
        assert candidate("%r=$<{-<qy|.iz+p:mjy/r}>^+=u$?") == 'nmlmkvvkltwwdutkihetxmxmstlpmn'
        assert candidate(")adur*hh>]]<]/u!p@/.g~") == 'rvypmsccmrrkrxpjkoxwby'
        assert candidate("a_wf)gb-r=tv->md]@f[l~-") == 'vtrarbwvmloqvmhyroapgyv'
        assert candidate("gst*%ee&suk=]]sx=(tlk>ux>") == 'bnosnzzonpflrrnslqogfmpsm'
        assert candidate("y*!jvtpwzv^$>s%+dx<~{hcq>u%h:{") == 'tsjeqokruqsmmnntyskyvcxlmpnciv'
        assert candidate("k^.f]%l%}dj/eu%#[}@(**~t?g") == 'fswarngnxyexzpnlpxoqssyonb'
        assert candidate("cb/+)mymih{{.:(<-j/$.h^>::z") == 'xwxtrhthdcvvwiqkvexmwcsmiiu'
        assert candidate("dq{&ck><u{vesy&l<{:<tl(s|i") == 'ylvoxfmkpvqzntogkvikogqnwd'
        assert candidate("ovr]le}raz@%_rv^nt{.iset[|y") == 'jqmrgzxmvuontmqsiovwdnzopwt'
        assert candidate("p{<~~uf%e?f?x>buv[.nt") == 'kvkyypanznansmwpqpwio'
        assert candidate("fpjyxu#p_y>%_n%[$.u>t@") == 'aketsplkttmntinpmwpmoo'
        assert candidate("z!<s|nfpw(zrc>z!t<>=lps)no") == 'ujknwiakrqumxmujokmlgknrij'
        assert candidate("q)g!~x|y]v@p<xlcg~za>^]v/gdo") == 'lrbjyswtrqokksgxbyuvmsrqxbyj'
        assert candidate(".p-(=s<<lx<wshx?{+u{/?:>") == 'wkvqlnkkgskrncsnvtpvxnim'
        assert candidate("#w[>tn$?[t&fq_]s{gi>d!mj.u") == 'lrpmoimnpooaltrnvbdmyjhewp'
        assert candidate("eg]*>=<!&^{<qcb+yne/d.l") == 'zbrsmlkjosvklxwttizxywg'
        assert candidate("(b+t&<)h_dpaq>fv~</<#lr!/gh/mq") == 'qwtookrctykvlmaqykxklgmjxbcxhl'
        assert candidate("k)k_[m!g&l+l(^mxzcxx}|") == 'frftphjbogtgqshsuxssxw'
        assert candidate("vl>gz:as}>i!)n<dd!ygr") == 'qgmbuivnxmdjrikyyjtbm'
        assert candidate("r<hchrvx!fpq|><na|/#.v=:w@rr") == 'mkcxcmqsjaklwmkivwxlwqliromm'
        assert candidate("?suboj[i_u$>-v.<p?n?p{sd>/") == 'nnpwjepdtpmmvqwkkninkvnymx'
        assert candidate("p<wpxxp!+fr>+_~$]?t^b]=):wxs)") == 'kkrksskjtammttymrnoswrlrirsnr'
        assert candidate("x.p]c@aytaqh!ofhrrv.o") == 'swkrxovtovlcjjacmmqwj'
        assert candidate("lv-d><d@^gn:lctn_h<o%)&") == 'gqvymkyosbiigxoitckjnro'
        assert candidate("aqy*{p&c/]gttx%vn(s)i.b<zxx&?!") == 'vltsvkoxxrboosnqiqnrdwwkussonj'
        assert candidate("jod%)<):v(>cgj}e:hwbma^=^<") == 'ejynrkriqqmxbexzicrwhvslsk'
        assert candidate("<]+o>=pdx)s|w{=z&/ajcpiis<?") == 'krtjmlkysrnwrvluoxvexkddnkn'
        assert candidate("<-!.{>qhmx&p{<yshrw^bo") == 'kvjwvmlchsokvktncmrswj'
        assert candidate("u+<(.![^psa@^=@@@<:cs$&") == 'ptkqwjpsknvosloookixnmo'
        assert candidate("~qcu!:fh&_gol_j.:!r(hi><") == 'ylxpjiacotbjgtewijmqcdmk'
        assert candidate("t{bs@i~$wv%mmek&b@(nk") == 'ovwnodymrqnhhzfowoqif'
        assert candidate("yeefyz~t#_qv*y+.+av&=m*uva>i") == 'tzzatuyoltlqsttwtvqolhspqvmd'
        assert candidate("bt$>bvgb<{-{i[!x(fu/+?>/") == 'wommwqbwkvvvdpjsqapxtnmx'
        assert candidate("[m[m!vb-x+jklac%npfh<d^:^rvzho") == 'phphjqwvstefgvxnikackysismqucj'
        assert candidate("/>fepzi$}z(<ib_/s<q}lei&+{uw") == 'xmazkudmxuqkdwtxnklxgzdotvpr'
        assert candidate("@)p|**ht:>ew/!+>)-un#*u") == 'orkwsscoimzrxjtmrvpilsp'
        assert candidate("w_pdbz~#+xc:_brh@(=~^ip#)o%$") == 'rtkywuyltsxitwmcoqlysdklrjnm'
        assert candidate("z~}bjwptqb-n-ewxoxahb") == 'uyxwerkolwvivzrsjsvcw'
        assert candidate("|~e/:+]banrnd@*#|}o]<>u#") == 'wyzxitrwvimiyoslwxjrkmpl'
        assert candidate("dhm[+-y%riz&vhh|jx&lu/orc{") == 'ychptvtnmduoqccwesogpxjmxv'
        assert candidate("f?(_f<vtvyc@:&w<|.tfyy]v") == 'anqtakqoqtxoiorkwwoattrq'
        assert candidate("$<-@(&#%^bb&_#@_#<</ea@lg_.xu") == 'mkvoqolnswwotlotlkkxzvogbtwsp'
        assert candidate("?l+%u}[x>[{w?rub(anr>^_^") == 'ngtnpxpsmpvrnmpwqvimmsts'
        assert candidate("lpssitq&@l]w.[rjxh@oe-") == 'gknndoloogrrwpmescojzv'
        assert candidate("sr_?arvyaud<&%c?+kzqh=n") == 'nmtnvmqtvpykonxntfulcli'
        assert candidate("-]]|(!zfm)hw[_++f-q/t)@-{[") == 'vrrwqjuahrcrptttavlxorovvp'
        assert candidate("<j_iuv=+[?]st$w)+tw+!bb/w-(m") == 'ketdpqltpnrnomrrtortjwwxrvqh'
        assert candidate("p%lg}.@v|vgpoo[@scky<h") == 'kngbxwoqwqbkjjponxftkc'
        assert candidate("j_hc?%)ye=[#$:b>gz{?kl:") == 'etcxnnrtzlplmiwmbuvnfgi'
        assert candidate("<i)qs:/l}x+yc?)/&%)^]]^") == 'kdrlnixgxsttxnrxonrsrrs'
        assert candidate(copy.deepcopy(encoded_str)) == str
        assert candidate(")$-lzj[k.*toff<xe&~c>_h>>acd=") == 'rmvguepfwsojaakszoyxmtcmmvxyl'
        assert candidate("ik+a<}-m{n[#xkwkh~io.qp%]?<") == 'dftvkxvhviplsfrfcydjwlknrnk'
        assert candidate("yr%wfi:j!nxvr%b&r%.l~(<p<") == 'tmnradiejisqmnwomnwgyqkkk'
        assert candidate("f^&ludx-sv</vs~)b*!$+w]") == 'asogpysvnqkxqnyrwsjmtrr'
        assert candidate("g>(:a|tc&ez]zk>mew@jx.ekw?+e") == 'bmqivwoxozurufmhzroeswzfrntz'
        assert candidate("k&}z#no|a<n$%ii$@kznp^#{") == 'foxulijwvkimnddmofuikslv'
        assert candidate(":v}#slb=^ja|#|j%rw=apxgb=") == 'iqxlngwlsevwlwenmrlvksbwl'
        assert candidate("@r>*&ny*]r/c-bi=o>pb.yp<zjp") == 'ommsoitsrmxxvwdljmkwwtkkuek'
        assert candidate(")-f|-<aypb!&:~mwj=%>|!|?") == 'rvawvkvtkwjoiyhrelnmwjwn'
        assert candidate("+%t+|]ab_}>>b<u<mi{u{#h") == 'tnotwrvwtxmmwkpkhdvpvlc'
        assert candidate("f.bgbp}!>[a_q:}d$~n>}") == 'awwbwkxjmpvtlixymyimx'
        assert candidate("(f]#${q.y)~vq.[d@yzral") == 'qarlmvlwtryqlwpyotumvg'
        assert candidate("%_y<u|k}%{vmzgqlgc=+a^r") == 'nttkpwfxnvqhublgbxltvsm'
        assert candidate("l|:<]?a@d&a&oi!(t|>+bs#>nl@") == 'gwikrnvoyovojdjqowmtwnlmigo'
        assert candidate("i)c+oc_tmtf%<zx|x:b<bw}i>zgj%") == 'drxtjxtohoankuswsiwkwrxdmuben'
        assert candidate("!#|-+]z%d$#<<&-td$^i<j-#") == 'jlwvtrunymlkkovoymsdkevl'
        assert candidate(":}?@|-wv}wfs+&x-kh:ri__-[gamw") == 'ixnowvrqxrantosvfcimdttvpbvhr'
        assert candidate("uo[l)>?{-_+ir^sg:/($?k") == 'pjpgrmnvvttdmsnbixqmnf'
        assert candidate("uv~m~=/<(b=g>]!l!&qxce-y!edv^#") == 'pqyhylxkqwlbmrjgjolsxzvtjzyqsl'
        assert candidate("gx$s@i<sw?bq>lahb|:x!?k)d?zy") == 'bsmnodknrnwlmgvcwwisjnfrynut'
        assert candidate("]jammxp.gu+~|o|!z&p~!}|e?@n") == 'revhhskwbptywjwjuokyjxwznoi'
        assert candidate("^r+&s{~>)>v#}.{+q|@<djbt") == 'smtonvymrmqlxwvtlwokyewo'
        assert candidate("h~@l$t#$f_[yu[<)!l?)<*&*@%") == 'cyogmolmatptppkrjgnrksoson'
        assert candidate("sx&(%p(]z~p?j=y%#e<_#<j*") == 'nsoqnkqruykneltnlzktlkes'
        assert candidate("?bpi>)xg@>s)g@madytxw-d") == 'nwkdmrsbomnrbohvytosrvy'
        assert candidate(">#ler:<_jg}>v>m*<cf-<u..rsf<>}") == 'mlgzmiktebxmqmhskxavkpwwmnakmx'
        assert candidate("px&-{&>tw<la~b@@[lv#j") == 'ksovvomorkgvywoopgqle'
        assert candidate("l>!x($~ho/jzx]a)sai)c<r") == 'gmjsqmycjxeusrvrnvdrxkm'
        assert candidate("g]v*<c+t)zbm(nvwx{}|-%") == 'brqskxtoruwhqiqrsvxwvn'
        assert candidate("n!kp(rlzac>(qzgkhtxr{e#/>b{{~*") == 'ijfkqmguvxmqlubfcosmvzlxmwvvys'
        assert candidate("i&>.<eyd>bb)zp^<%:wqb") == 'domwkztymwwruksknirlw'
        assert candidate("eq./ftx!n%lusy:%<v#qegf{ts*.") == 'zlwxaosjingpntinkqllzbavonsw'
        assert candidate("gw(x}]e<d}g~u*-<{[uu()x$<<") == 'brqsxrzkyxbypsvkvpppqrsmkk'
        assert candidate("/knj)!f!<>q(tm(+:u?@<o&t=<<") == 'xfierjajkmlqohqtipnokjoolkk'
        assert candidate("]x>uzr<_>-(t[=si-a$e]a*<x~l") == 'rsmpumktmvqoplndvvmzrvsksyg'
        assert candidate(":@qvg~[o>&?~(_*h*<>>[~") == 'iolqbypjmonyqtscskmmpy'
        assert candidate("={!/~uy~>#im>+we:${)vo(]%e(#") == 'lvjxyptymldhmtrzimvrqjqrnzql'
        assert candidate("hm]$>drwuvt&ms|do!{t&sr") == 'chrmmymrpqoohnwyjjvoonm'
        assert candidate("|vw[:(gzj^<i]x#:*y~z:@c=&&") == 'wqrpiqbueskdrslistyuioxloo'
        assert candidate(".n)mo-&r|(d/~x>|?&n.|h][)") == 'wirhjvomwqyxysmwnoiwwcrpr'
        assert candidate("lm|@v_x?|/h/b-u#$d%ul") == 'ghwoqtsnwxcxwvplmynpg'
        assert candidate("zt@vvvuif:_d)o$o$$}y{o<?{b!j") == 'uooqqqpdaityrjmjmmxtvjknvwje'
        assert candidate("{aub=|&v}v!dn]<r->]h]h)~#") == 'vvpwlwoqxqjyirkmvmrcrcryl'
        assert candidate("z$!~}:_}_r[e^ubf^b<u>h>}[") == 'umjyxitxtmpzspwaswkpmcmxp'
        assert candidate("|%x<>&hkqc]h*kp<vs@c{eg>$@szf") == 'wnskmocflxrcsfkkqnoxvzbmmonua'
        assert candidate("xu+/hrb/*</:$d>*(ee._n:u+n/d") == 'sptxcmwxskximymsqzzwtiiptixy'
        assert candidate("^h<>wx%rfl^x~h<m./c:+}c]jy") == 'sckmrsnmagssyckhwxxitxxret'
        assert candidate("~<~n%fhx*u+z{+c->-=t+/") == 'ykyinacssptuvtxvmvlotx'
        assert candidate(")/tbkw-$rt)v_*f*sqo?)z[_") == 'rxowfrvmmorqtsasnljnrupt'
        assert candidate("whfb$%]!?^t<n>s+(#_+>xqo") == 'rcawmnrjnsokimntqlttmslj'
        assert candidate("qm^i#/a[o=gr~(~<+)+q!p&oj+h[r") == 'lhsdlxvpjlbmyqyktrtljkojetcpm'
        assert candidate("-^iqio+{zqiwun-![c(sjol?j=m") == 'vsdldjtvuldrpivjpxqnejgnelh'
        assert candidate("b$[~f>_oy~[(a$i>a:&g<") == 'wmpyamtjtypqvmdmviobk'
        assert candidate("z$vuh&<vya?:?y)-n_hh?tmm=jfr") == 'umqpcokqtvnintrvitccnohhleam'
        assert candidate("xf=&&$bqcx{vwifhy+u>v~i-)ma<&") == 'saloomwlxsvqrdacttpmqydvrhvko'
        assert candidate(":d}?x?-]b_l?/k<x<[~yc^awv>*bj|") == 'iyxnsnvrwtgnxfkskpytxsvrqmswew'
        assert candidate("/?(>ynh}y_<)mr<i^vb>{o>") == 'xnqmticxttkrhmkdsqwmvjm'
        assert candidate("(|ixe^&)xcxvbt)g@/-irr") == 'qwdszsorsxsqworboxvdmm'
        assert candidate("kgy[!$iy=%lawxf_uut~>d#%~x$") == 'fbtpjmdtlngvrsatppoymylnysm'
        assert candidate("a)b]?^jh+(/xl@pz%k-i%]$") == 'vrwrnsectqxsgokunfvdnrm'
        assert candidate("+?wn~>@l.ouloe<|gojkokigedy/") == 'tnriymogwjpgjzkwbjefjfdbzytx'
        assert candidate("ay@<kv~u>q=cl<?e~_}:r/qe]?") == 'vtokfqypmllxgknzytximxlzrn'
        assert candidate("#ln[[gg:ufl.~rk+k.s?[~>>^w") == 'lgippbbipagwymftfwnnpymmsr'
        assert candidate("c&{kxj:/><>(dj#k!^:l@lk^}=]") == 'xovfseixmkmqyelfjsigogfsxlr'
        assert candidate(">xgk{j${v<t@>%:~$ah!>y{") == 'msbfvemvqkoomniymvcjmtv'
        assert candidate("/%=?*$:?aqtrj>uaihv@&") == 'xnlnsminvlomempvdcqoo'
        assert candidate("w>}_>n.#z@fd=a>e^)^}>ctt") == 'rmxtmiwluoaylvmzsrsxmxoo'
        assert candidate("dr{>t>kzt^k<h}p{mqu<_?ol$h@y?") == 'ymvmomfuosfkcxkvhlpktnjgmcotn'
        assert candidate("rvjkpy.x<bje/<>r&tcs/]+$o!<+") == 'mqefktwskwezxkmmooxnxrtmjjkt'
        assert candidate(">(/(l>:*a~b=+fo-+.@?|y~>^:") == 'mqxqgmisvywltajvtwonwtymsi'
        assert candidate("z=km?+swpld=)nnmpczp*_e") == 'ulfhntnrkgylriihkxukstz'

if __name__ == '__main__':
    unittest.main()
