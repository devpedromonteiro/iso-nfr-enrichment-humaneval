
import unittest
import re
import sys
import math
import copy


def is_sorted(lst):
    """
    Return True if the list is sorted in ascending order and no number
    appears more than twice. Otherwise, return False.

    Rules:
    - Numbers must be in non-decreasing order.
    - A value can appear at most 2 times consecutively.
    - Assume all values are non-negative integers.

    Examples:
    is_sorted([5]) -> True
    is_sorted([1, 2, 3, 4, 5]) -> True
    is_sorted([1, 3, 2, 4, 5]) -> False
    is_sorted([1, 2, 2, 3, 3, 4]) -> True
    is_sorted([1, 2, 2, 2, 3, 4]) -> False
    """
    if len(lst) <= 1:
        return True

    duplicate_count = 1

    for i in range(1, len(lst)):
        # If current number is smaller than previous, list is not sorted
        if lst[i] < lst[i - 1]:
            return False

        # Count duplicates
        if lst[i] == lst[i - 1]:
            duplicate_count += 1
            if duplicate_count > 2:
                return False
        else:
            duplicate_count = 1

    return True
candidate = is_sorted


def check(candidate):

    # Check some simple cases
    assert candidate([5]) == True
    assert candidate([1, 2, 3, 4, 5]) == True
    assert candidate([1, 3, 2, 4, 5]) == False
    assert candidate([1, 2, 3, 4, 5, 6]) == True
    assert candidate([1, 2, 3, 4, 5, 6, 7]) == True
    assert candidate([1, 3, 2, 4, 5, 6, 7]) == False, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([]) == True, "This prints if this assert fails 2 (good for debugging!)"
    assert candidate([1]) == True, "This prints if this assert fails 3 (good for debugging!)"
    assert candidate([3, 2, 1]) == False, "This prints if this assert fails 4 (good for debugging!)"
    
    # Check some edge cases that are easy to work out by hand.
    assert candidate([1, 2, 2, 2, 3, 4]) == False, "This prints if this assert fails 5 (good for debugging!)"
    assert candidate([1, 2, 3, 3, 3, 4]) == False, "This prints if this assert fails 6 (good for debugging!)"
    assert candidate([1, 2, 2, 3, 3, 4]) == True, "This prints if this assert fails 7 (good for debugging!)"
    assert candidate([1, 2, 3, 4]) == True, "This prints if this assert fails 8 (good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
