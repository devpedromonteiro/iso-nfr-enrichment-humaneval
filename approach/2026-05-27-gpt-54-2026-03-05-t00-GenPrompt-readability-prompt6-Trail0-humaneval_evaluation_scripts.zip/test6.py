
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """
    Given a string containing multiple groups of parentheses separated by spaces,
    return a list with the maximum nesting depth for each group.

    Examples:
        (()()) -> 2
        ((())) -> 3
        () -> 1

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """
    groups = paren_string.split()
    max_depths: List[int] = []

    for group in groups:
        current_depth = 0
        deepest_depth = 0

        for char in group:
            if char == "(":
                current_depth += 1
                deepest_depth = max(deepest_depth, current_depth)
            elif char == ")":
                current_depth -= 1

        max_depths.append(deepest_depth)

    return max_depths
candidate = parse_nested_parens




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('(()()) ((())) () ((())()())') == [2, 3, 1, 3]
    assert candidate('() (()) ((())) (((())))') == [1, 2, 3, 4]
    assert candidate('(()(())((())))') == [4]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
