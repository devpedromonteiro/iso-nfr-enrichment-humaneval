
import unittest
import re
import sys
import math
import copy


def odd_count(strings):
    """
    Given a list of digit-only strings, return a list where each element is:
    "the number of odd elements in the string i of the input."
    with every 'i' replaced by the count of odd digits in that string.

    >>> odd_count(['1234567'])
    ["the number of odd elements 4n the str4ng 4 of the 4nput."]
    >>> odd_count(['3', '11111111'])
    ["the number of odd elements 1n the str1ng 1 of the 1nput.",
     "the number of odd elements 8n the str8ng 8 of the 8nput."]
    """
    result = []

    for digit_string in strings:
        odd_digits = sum(1 for ch in digit_string if int(ch) % 2 == 1)
        sentence = "the number of odd elements in the string i of the input."
        sentence = sentence.replace("i", str(odd_digits))
        result.append(sentence)

    return result
candidate = odd_count


def check(candidate):

    # Check some simple cases
    assert candidate(['1234567']) == ["the number of odd elements 4n the str4ng 4 of the 4nput."], "Test 1"
    assert candidate(['3',"11111111"]) == ["the number of odd elements 1n the str1ng 1 of the 1nput.", "the number of odd elements 8n the str8ng 8 of the 8nput."], "Test 2"
    assert candidate(['271', '137', '314']) == [
        'the number of odd elements 2n the str2ng 2 of the 2nput.',
        'the number of odd elements 3n the str3ng 3 of the 3nput.',
        'the number of odd elements 2n the str2ng 2 of the 2nput.'
    ]

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
