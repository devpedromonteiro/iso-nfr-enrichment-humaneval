
import unittest
import re
import sys
import math
import copy


def count_nums(arr):
    """
    Return the number of integers whose digit sum is greater than 0.

    For negative numbers, only the first digit is treated as negative.
    Example:
        -123 -> -1 + 2 + 3 = 4

    >>> count_nums([]) == 0
    True
    >>> count_nums([-1, 11, -11]) == 1
    True
    >>> count_nums([1, 1, 2]) == 3
    True
    """
    def digit_sum(num):
        digits = str(num)

        if digits[0] == '-':
            total = -int(digits[1])
            total += sum(int(d) for d in digits[2:])
        else:
            total = sum(int(d) for d in digits)

        return total

    return sum(1 for num in arr if digit_sum(num) > 0)
candidate = count_nums


def check(candidate):

    # Check some simple cases
    assert candidate([]) == 0
    assert candidate([-1, -2, 0]) == 0
    assert candidate([1, 1, 2, -2, 3, 4, 5]) == 6
    assert candidate([1, 6, 9, -6, 0, 1, 5]) == 5
    assert candidate([1, 100, 98, -7, 1, -1]) == 4
    assert candidate([12, 23, 34, -45, -56, 0]) == 5
    assert candidate([-0, 1**0]) == 1
    assert candidate([1]) == 1

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
