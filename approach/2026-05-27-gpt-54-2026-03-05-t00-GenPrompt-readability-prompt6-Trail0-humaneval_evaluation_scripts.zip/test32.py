
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math
from typing import List


def poly(coefficients: List[float], x: float) -> float:
    """
    Evaluate a polynomial at point x.

    The polynomial is defined by its coefficients:
        coefficients[0] + coefficients[1] * x + coefficients[2] * x^2 + ... + coefficients[n] * x^n

    Example:
        poly([1, 2], 3) = 1 + 2*3 = 7
    """
    return sum(coefficient * (x ** power) for power, coefficient in enumerate(coefficients))


def find_zero(coefficients: List[float]) -> float:
    """
    Find one real zero of a polynomial.

    Assumptions:
    - `coefficients` contains an even number of items.
    - The highest non-zero coefficient corresponds to an odd degree polynomial,
      which guarantees at least one real root.

    Returns:
        One value x such that poly(coefficients, x) == 0 (approximately).

    Examples:
        >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
        -0.5
        >>> round(find_zero([-6, 11, -6, 1]), 2)  # (x - 1)(x - 2)(x - 3)
        1.0
    """

    def f(x: float) -> float:
        return poly(coefficients, x)

    # First, find an interval [left, right] where the polynomial changes sign.
    left = -1.0
    right = 1.0

    while f(left) * f(right) > 0:
        left *= 2
        right *= 2

    # Use binary search (bisection method) to approximate a root.
    epsilon = 1e-10

    while right - left > epsilon:
        mid = (left + right) / 2
        value = f(mid)

        if abs(value) < epsilon:
            return mid

        if f(left) * value <= 0:
            right = mid
        else:
            left = mid

    return (left + right) / 2
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
