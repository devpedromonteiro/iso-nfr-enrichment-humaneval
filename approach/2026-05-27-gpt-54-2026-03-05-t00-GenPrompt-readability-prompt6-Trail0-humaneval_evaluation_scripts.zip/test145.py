
import unittest
import re
import sys
import math
import copy


def order_by_points(nums):
    """
    Sort integers by the sum of their digits in ascending order.

    If multiple numbers have the same digit sum, preserve their
    original order from the input list.

    Examples:
        >>> order_by_points([1, 11, -1, -11, -12])
        [-1, -11, 1, -12, 11]
        >>> order_by_points([])
        []
    """
    def digit_sum(number):
        return sum(int(digit) for digit in str(abs(number)))

    return sorted(nums, key=digit_sum)
candidate = order_by_points


def check(candidate):

    # Check some simple cases
    assert candidate([1, 11, -1, -11, -12]) == [-1, -11, 1, -12, 11]
    assert candidate([1234,423,463,145,2,423,423,53,6,37,3457,3,56,0,46]) == [0, 2, 3, 6, 53, 423, 423, 423, 1234, 145, 37, 46, 56, 463, 3457]
    assert candidate([]) == []
    assert candidate([1, -11, -32, 43, 54, -98, 2, -3]) == [-3, -32, -98, -11, 1, 2, 43, 54]
    assert candidate([1,2,3,4,5,6,7,8,9,10,11]) == [1, 10, 2, 11, 3, 4, 5, 6, 7, 8, 9]
    assert candidate([0,6,6,-76,-21,23,4]) == [-76, -21, 0, 4, 23, 6, 6]

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
