
import unittest
import re
import sys
import math
import copy


def do_algebra(operator, operand):
    """
    Build and evaluate an algebraic expression from operators and operands.

    Parameters:
        operator (list[str]): A list of operators such as '+', '-', '*', '//', '**'
        operand (list[int]): A list of non-negative integers

    Returns:
        int: The result of the evaluated expression

    Example:
        do_algebra(['+', '*', '-'], [2, 3, 4, 5])
        -> 9
    """
    expression = str(operand[0])

    for op, value in zip(operator, operand[1:]):
        expression += f" {op} {value}"

    return eval(expression)
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
