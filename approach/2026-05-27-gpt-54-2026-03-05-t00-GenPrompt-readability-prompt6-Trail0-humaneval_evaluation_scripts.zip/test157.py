
import unittest
import re
import sys
import math
import copy


def right_angle_triangle(a, b, c):
    """
    Return True if the three side lengths form a right-angled triangle,
    otherwise return False.

    A right-angled triangle satisfies the Pythagorean theorem:
        longest_side^2 = other_side_1^2 + other_side_2^2

    Examples:
        right_angle_triangle(3, 4, 5) -> True
        right_angle_triangle(1, 2, 3) -> False
    """
    # Sort the sides so the longest side is last
    side1, side2, hypotenuse = sorted([a, b, c])

    # First, check whether the sides can form a valid triangle
    if side1 + side2 <= hypotenuse:
        return False

    # Check the Pythagorean theorem
    return side1 ** 2 + side2 ** 2 == hypotenuse ** 2
candidate = right_angle_triangle


def check(candidate):

    # Check some simple cases
    assert candidate(3, 4, 5) == True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(1, 2, 3) == False
    assert candidate(10, 6, 8) == True
    assert candidate(2, 2, 2) == False
    assert candidate(7, 24, 25) == True
    assert candidate(10, 5, 7) == False
    assert candidate(5, 12, 13) == True
    assert candidate(15, 8, 17) == True
    assert candidate(48, 55, 73) == True

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1, 1, 1) == False, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate(2, 2, 10) == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
