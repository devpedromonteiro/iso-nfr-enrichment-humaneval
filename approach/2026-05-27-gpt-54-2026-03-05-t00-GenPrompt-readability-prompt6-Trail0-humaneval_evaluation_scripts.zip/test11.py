
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def string_xor(a: str, b: str) -> str:
    """
    Perform a binary XOR on two equal-length strings containing only '0' and '1'.

    Args:
        a: First binary string.
        b: Second binary string.

    Returns:
        A binary string where each character is the XOR of the corresponding
        characters in `a` and `b`.

    Raises:
        ValueError: If the input strings do not have the same length.

    Example:
        >>> string_xor('010', '110')
        '100'
    """
    if len(a) != len(b):
        raise ValueError("Input strings must have the same length.")

    result: List[str] = []

    for bit_a, bit_b in zip(a, b):
        result_bit = '0' if bit_a == bit_b else '1'
        result.append(result_bit)

    return ''.join(result)
candidate = string_xor




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('111000', '101010') == '010010'
    assert candidate('1', '1') == '0'
    assert candidate('0101', '0000') == '0101'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
