
import unittest
import re
import sys
import math
import copy


def specialFilter(nums):
    """
    Return the count of numbers that:
    - are greater than 10
    - have both first and last digits odd

    Examples:
        specialFilter([15, -73, 14, -15]) -> 1
        specialFilter([33, -2, -3, 45, 21, 109]) -> 2
    """
    odd_digits = {"1", "3", "5", "7", "9"}
    count = 0

    for num in nums:
        if num > 10:
            num_str = str(num)
            first_digit = num_str[0]
            last_digit = num_str[-1]

            if first_digit in odd_digits and last_digit in odd_digits:
                count += 1

    return count
candidate = specialFilter


def check(candidate):

    # Check some simple cases
    assert candidate([5, -2, 1, -5]) == 0  
    assert candidate([15, -73, 14, -15]) == 1
    assert candidate([33, -2, -3, 45, 21, 109]) == 2
    assert candidate([43, -12, 93, 125, 121, 109]) == 4
    assert candidate([71, -2, -33, 75, 21, 19]) == 3


    # Check some edge cases that are easy to work out by hand.
    assert candidate([1]) == 0              
    assert candidate([]) == 0                   



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
