
import unittest
import re
import sys
import math
import copy



def encode_shift(s: str):
    """
    returns encoded string by shifting every character by 5 in the alphabet.
    """
    return "".join([chr(((ord(ch) + 5 - ord("a")) % 26) + ord("a")) for ch in s])


def encode_shift(text: str) -> str:
    """
    Encode a lowercase string by shifting each character forward by 5 positions
    in the alphabet.

    Example:
        encode_shift("abc") -> "fgh"
    """
    shift = 5
    alphabet_size = 26
    base = ord("a")

    return "".join(
        chr((ord(char) - base + shift) % alphabet_size + base)
        for char in text
    )


def decode_shift(text: str) -> str:
    """
    Decode a string that was encoded with encode_shift by shifting each character
    backward by 5 positions in the alphabet.

    Example:
        decode_shift("fgh") -> "abc"
    """
    shift = 5
    alphabet_size = 26
    base = ord("a")

    return "".join(
        chr((ord(char) - base - shift) % alphabet_size + base)
        for char in text
    )
candidate = decode_shift




METADATA = {}


def check(candidate):
    from random import randint, choice
    import copy
    import string

    letters = string.ascii_lowercase
    for _ in range(100):
        str = ''.join(choice(letters) for i in range(randint(10, 20)))
        encoded_str = encode_shift(str)
        assert candidate(copy.deepcopy(encoded_str)) == str



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
