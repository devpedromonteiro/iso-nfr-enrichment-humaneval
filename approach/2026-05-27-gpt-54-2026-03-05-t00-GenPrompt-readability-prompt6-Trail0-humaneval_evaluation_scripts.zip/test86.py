
import unittest
import re
import sys
import math
import copy


def anti_shuffle(s):
    """
    Return a version of the string where each word's characters are sorted
    in ascending ASCII order, while preserving the original spacing.

    A word is any sequence of non-space characters. Spaces remain in the
    same positions as in the input.

    Examples:
        anti_shuffle('Hi') -> 'Hi'
        anti_shuffle('hello') -> 'ehllo'
        anti_shuffle('Hello World!!!') -> 'Hello !!!Wdlor'
    """
    result = []
    current_word = []

    for char in s:
        if char == ' ':
            if current_word:
                result.append(''.join(sorted(current_word)))
                current_word = []
            result.append(char)
        else:
            current_word.append(char)

    if current_word:
        result.append(''.join(sorted(current_word)))

    return ''.join(result)
candidate = anti_shuffle


def check(candidate):

    # Check some simple cases
    assert candidate('Hi') == 'Hi'
    assert candidate('hello') == 'ehllo'
    assert candidate('number') == 'bemnru'
    assert candidate('abcd') == 'abcd'
    assert candidate('Hello World!!!') == 'Hello !!!Wdlor'
    assert candidate('') == ''
    assert candidate('Hi. My name is Mister Robot. How are you?') == '.Hi My aemn is Meirst .Rboot How aer ?ouy'
    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
