
import unittest
import re
import sys
import math
import copy



def car_race_collision(n: int) -> int:
    """
    Return the total number of collisions between two groups of cars.

    There are:
    - `n` cars moving from left to right
    - `n` cars moving from right to left

    Every left-to-right car will collide exactly once with every right-to-left car.
    Therefore, the total number of collisions is:

        n * n

    Args:
        n: Number of cars in each group.

    Returns:
        Total number of collisions.
    """
    return n * n
candidate = car_race_collision




METADATA = {}


def check(candidate):
    assert candidate(2) == 4
    assert candidate(3) == 9
    assert candidate(4) == 16
    assert candidate(8) == 64
    assert candidate(10) == 100



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
