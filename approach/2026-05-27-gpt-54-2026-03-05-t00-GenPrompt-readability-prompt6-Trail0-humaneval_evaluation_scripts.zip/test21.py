
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def rescale_to_unit(numbers: List[float]) -> List[float]:
    """
    Linearly rescale a list of numbers so that:
    - the smallest value becomes 0.0
    - the largest value becomes 1.0

    The relative positions of the other values are preserved.

    Args:
        numbers: A list of at least two float values.

    Returns:
        A new list with all values rescaled to the range [0.0, 1.0].

    Example:
        >>> rescale_to_unit([1.0, 2.0, 3.0, 4.0, 5.0])
        [0.0, 0.25, 0.5, 0.75, 1.0]
    """
    minimum = min(numbers)
    maximum = max(numbers)
    value_range = maximum - minimum

    return [(number - minimum) / value_range for number in numbers]
candidate = rescale_to_unit




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([2.0, 49.9]) == [0.0, 1.0]
    assert candidate([100.0, 49.9]) == [1.0, 0.0]
    assert candidate([1.0, 2.0, 3.0, 4.0, 5.0]) == [0.0, 0.25, 0.5, 0.75, 1.0]
    assert candidate([2.0, 1.0, 5.0, 3.0, 4.0]) == [0.25, 0.0, 1.0, 0.5, 0.75]
    assert candidate([12.0, 11.0, 15.0, 13.0, 14.0]) == [0.25, 0.0, 1.0, 0.5, 0.75]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
