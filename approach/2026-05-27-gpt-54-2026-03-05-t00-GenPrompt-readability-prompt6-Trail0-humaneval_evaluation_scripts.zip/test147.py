
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    Return the number of triples (a[i], a[j], a[k]) such that:
        - 1 <= i < j < k <= n
        - a[i] + a[j] + a[k] is divisible by 3

    Where:
        a[i] = i^2 - i + 1

    Observation:
        We only care about a[i] modulo 3.

        a[i] = i^2 - i + 1 = i(i - 1) + 1

        Since i(i - 1) is always even, that does not directly help for mod 3,
        so let's check i % 3:

        If i % 3 == 0:
            a[i] % 3 = 1
        If i % 3 == 1:
            a[i] % 3 = 1
        If i % 3 == 2:
            a[i] % 3 = 0

        So:
            - indices congruent to 2 mod 3 produce values divisible by 3
            - all other indices produce values congruent to 1 mod 3

        A sum of three numbers is divisible by 3 only in these cases:
            1) 0 + 0 + 0
            2) 1 + 1 + 1

        Therefore, if:
            count_0 = number of terms where a[i] % 3 == 0
            count_1 = number of terms where a[i] % 3 == 1

        Answer = C(count_0, 3) + C(count_1, 3)
    """

    def combinations_of_3(x):
        """Return C(x, 3) = x choose 3."""
        if x < 3:
            return 0
        return x * (x - 1) * (x - 2) // 6

    # Indices i such that i % 3 == 2 give a[i] % 3 == 0
    count_0 = (n + 1) // 3

    # All remaining indices give a[i] % 3 == 1
    count_1 = n - count_0

    return combinations_of_3(count_0) + combinations_of_3(count_1)
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
