
import unittest
import re
import sys
import math
import copy



def correct_bracketing(brackets: str) -> bool:
    """
    Return True if every opening bracket has a matching closing bracket
    and the brackets are properly ordered.

    >>> correct_bracketing("(")
    False
    >>> correct_bracketing("()")
    True
    >>> correct_bracketing("(()())")
    True
    >>> correct_bracketing(")(()")
    False
    """
    open_count = 0

    for bracket in brackets:
        if bracket == "(":
            open_count += 1
        elif bracket == ")":
            open_count -= 1

        # A closing bracket appeared before a matching opening bracket
        if open_count < 0:
            return False

    # All opening brackets must be closed
    return open_count == 0
candidate = correct_bracketing




METADATA = {}


def check(candidate):
    assert candidate("()")
    assert candidate("(()())")
    assert candidate("()()(()())()")
    assert candidate("()()((()()())())(()()(()))")
    assert not candidate("((()())))")
    assert not candidate(")(()")
    assert not candidate("(")
    assert not candidate("((((")
    assert not candidate(")")
    assert not candidate("(()")
    assert not candidate("()()(()())())(()")
    assert not candidate("()()(()())()))()")



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
