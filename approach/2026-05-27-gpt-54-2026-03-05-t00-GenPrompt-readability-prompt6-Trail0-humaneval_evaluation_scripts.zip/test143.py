
import unittest
import re
import sys
import math
import copy


def words_in_sentence(sentence):
    """
    Return a string containing only the words whose lengths are prime numbers.

    Words keep their original order and are joined by a single space.

    Examples:
        words_in_sentence("This is a test") -> "is"
        words_in_sentence("lets go for swimming") -> "go for"
    """

    def is_prime(number):
        """Check whether a positive integer is prime."""
        if number < 2:
            return False

        for divisor in range(2, int(number ** 0.5) + 1):
            if number % divisor == 0:
                return False

        return True

    prime_length_words = [
        word for word in sentence.split()
        if is_prime(len(word))
    ]

    return " ".join(prime_length_words)
candidate = words_in_sentence


def check(candidate):

    # Check some simple cases
    assert candidate("This is a test") == "is"
    assert candidate("lets go for swimming") == "go for"
    assert candidate("there is no place available here") == "there is no place"
    assert candidate("Hi I am Hussein") == "Hi am Hussein"
    assert candidate("go for it") == "go for it"

    # Check some edge cases that are easy to work out by hand.
    assert candidate("here") == ""
    assert candidate("here is") == "is"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
