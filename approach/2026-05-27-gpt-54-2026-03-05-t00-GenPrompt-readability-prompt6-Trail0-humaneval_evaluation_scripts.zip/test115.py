
import unittest
import re
import sys
import math
import copy


import math


def max_fill(grid, capacity):
    """
    Given a grid where each row represents a well and each `1` represents
    one unit of water, return the total number of bucket lowers needed
    to empty all wells.

    Each well uses its own bucket, and every bucket has the same capacity.

    Args:
        grid: List of lists containing 0s and 1s.
        capacity: Maximum number of water units a bucket can carry per lower.

    Returns:
        Total number of times buckets must be lowered.

    Examples:
        >>> max_fill([[0, 0, 1, 0], [0, 1, 0, 0], [1, 1, 1, 1]], 1)
        6
        >>> max_fill([[0, 0, 1, 1], [0, 0, 0, 0], [1, 1, 1, 1], [0, 1, 1, 1]], 2)
        5
        >>> max_fill([[0, 0, 0], [0, 0, 0]], 5)
        0
    """
    total_bucket_lowers = 0

    for well in grid:
        water_units = sum(well)
        lowers_needed = math.ceil(water_units / capacity)
        total_bucket_lowers += lowers_needed

    return total_bucket_lowers
candidate = max_fill


def check(candidate):


    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([[0,0,1,0], [0,1,0,0], [1,1,1,1]], 1) == 6, "Error"
    assert candidate([[0,0,1,1], [0,0,0,0], [1,1,1,1], [0,1,1,1]], 2) == 5, "Error"
    assert candidate([[0,0,0], [0,0,0]], 5) == 0, "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([[1,1,1,1], [1,1,1,1]], 2) == 4, "Error"
    assert candidate([[1,1,1,1], [1,1,1,1]], 9) == 2, "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
