
import unittest
import re
import sys
import math
import copy


def get_closest_vowel(word):
    """
    Return the rightmost vowel that is surrounded by consonants.

    A valid vowel:
    - must not be the first or last character
    - must be one of: a, e, i, o, u, A, E, I, O, U
    - must have consonants on both sides

    If no such vowel exists, return an empty string.

    Examples:
        get_closest_vowel("yogurt") -> "u"
        get_closest_vowel("FULL")   -> "U"
        get_closest_vowel("quick")  -> ""
        get_closest_vowel("ab")     -> ""
    """
    vowels = "aeiouAEIOU"

    # Scan from right to left, skipping the first and last characters
    for i in range(len(word) - 2, 0, -1):
        current_char = word[i]
        left_char = word[i - 1]
        right_char = word[i + 1]

        if (
            current_char in vowels
            and left_char not in vowels
            and right_char not in vowels
        ):
            return current_char

    return ""
candidate = get_closest_vowel


def check(candidate):

    # Check some simple cases
    assert candidate("yogurt") == "u"
    assert candidate("full") == "u"
    assert candidate("easy") == ""
    assert candidate("eAsy") == ""
    assert candidate("ali") == ""
    assert candidate("bad") == "a"
    assert candidate("most") == "o"
    assert candidate("ab") == ""
    assert candidate("ba") == ""
    assert candidate("quick") == ""
    assert candidate("anime") == "i"
    assert candidate("Asia") == ""
    assert candidate("Above") == "o"

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
