
import unittest
import re
import sys
import math
import copy



def derivative(coefficients: list[float]) -> list[float]:
    """
    Return the derivative coefficients of a polynomial.

    The input list represents a polynomial in coefficient form:
        coefficients[0] + coefficients[1] * x + coefficients[2] * x^2 + ...

    The returned list uses the same format for the derivative.

    Examples:
    >>> derivative([3, 1, 2, 4, 5])
    [1, 4, 12, 20]
    >>> derivative([1, 2, 3])
    [2, 6]
    >>> derivative([7])
    []
    """
    return [power * coefficient for power, coefficient in enumerate(coefficients[1:], start=1)]
candidate = derivative




METADATA = {}


def check(candidate):
    assert candidate([3, 1, 2, 4, 5]) == [1, 4, 12, 20]
    assert candidate([1, 2, 3]) == [2, 6]
    assert candidate([3, 2, 1]) == [2, 2]
    assert candidate([3, 2, 1, 0, 4]) == [2, 2, 0, 16]
    assert candidate([1]) == []



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
