
import unittest
import re
import sys
import math
import copy


def is_multiply_prime(a):
    """
    Return True if `a` can be written as the product of exactly 3 prime numbers,
    otherwise return False.

    Notes:
    - `a` is assumed to be less than 100.
    - The 3 prime numbers do not need to be distinct.
      Example: 8 = 2 * 2 * 2 -> True
    """

    def is_prime(n):
        """Check whether a number is prime."""
        if n < 2:
            return False
        for divisor in range(2, int(n ** 0.5) + 1):
            if n % divisor == 0:
                return False
        return True

    primes = [num for num in range(2, a + 1) if is_prime(num)]

    for i in primes:
        for j in primes:
            for k in primes:
                if i * j * k == a:
                    return True

    return False
candidate = is_multiply_prime


def check(candidate):

    assert candidate(5) == False
    assert candidate(30) == True
    assert candidate(8) == True
    assert candidate(10) == False
    assert candidate(125) == True
    assert candidate(3 * 5 * 7) == True
    assert candidate(3 * 6 * 7) == False
    assert candidate(9 * 9 * 9) == False
    assert candidate(11 * 9 * 9) == False
    assert candidate(11 * 13 * 7) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
