
import unittest
import re
import sys
import math
import copy



def triangle_area(base, height):
    """Return the area of a triangle.

    Given the length of a base and its corresponding height,
    compute the triangle's area using:

        area = (base * height) / 2

    >>> triangle_area(5, 3)
    7.5
    """
    return (base * height) / 2
candidate = triangle_area




METADATA = {}


def check(candidate):
    assert candidate(5, 3) == 7.5
    assert candidate(2, 2) == 2.0
    assert candidate(10, 8) == 40.0



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
