
import unittest
import re
import sys
import math
import copy



def largest_prime_factor(n: int) -> int:
    """Return the largest prime factor of n.

    Assumes:
        - n > 1
        - n is not prime

    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    largest_factor = None

    # Remove all factors of 2 first.
    while n % 2 == 0:
        largest_factor = 2
        n //= 2

    # Check odd factors from 3 upward.
    factor = 3
    while factor * factor <= n:
        while n % factor == 0:
            largest_factor = factor
            n //= factor
        factor += 2

    # If n is still greater than 1, then it is prime and larger than
    # any factor we have already found.
    if n > 1:
        largest_factor = n

    return largest_factor
candidate = largest_prime_factor




METADATA = {}


def check(candidate):
    assert candidate(15) == 5
    assert candidate(27) == 3
    assert candidate(63) == 7
    assert candidate(330) == 11
    assert candidate(13195) == 29



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
