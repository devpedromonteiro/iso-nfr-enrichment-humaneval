
import unittest
import re
import sys
import math
import copy


def eat(number, need, remaining):
    """
    Return:
        [total_eaten_after_meal, carrots_left]

    The rabbit wants to eat `need` more carrots.
    If there are fewer than `need` carrots remaining, it eats all that are left.
    """
    carrots_eaten_now = min(need, remaining)
    total_eaten = number + carrots_eaten_now
    carrots_left = remaining - carrots_eaten_now

    return [total_eaten, carrots_left]
candidate = eat


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(5, 6, 10) == [11, 4], "Error"
    assert candidate(4, 8, 9) == [12, 1], "Error"
    assert candidate(1, 10, 10) == [11, 0], "Error"
    assert candidate(2, 11, 5) == [7, 0], "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate(4, 5, 7) == [9, 2], "Error"
    assert candidate(4, 5, 1) == [5, 0], "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
