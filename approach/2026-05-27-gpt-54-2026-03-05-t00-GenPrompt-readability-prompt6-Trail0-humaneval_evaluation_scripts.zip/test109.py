
import unittest
import re
import sys
import math
import copy


def move_one_ball(arr):
    """
    Return True if the array can become sorted in non-decreasing order
    by applying any number of right circular shifts.

    A right shift moves the last element to the front.

    Examples:
        move_one_ball([3, 4, 5, 1, 2]) -> True
        move_one_ball([3, 5, 4, 1, 2]) -> False
        move_one_ball([]) -> True
    """
    if not arr:
        return True

    # Count how many times the order decreases when moving through the array.
    # For a rotated sorted array with unique elements, this can happen at most once.
    drops = 0
    n = len(arr)

    for i in range(n):
        if arr[i] > arr[(i + 1) % n]:
            drops += 1
            if drops > 1:
                return False

    return True
candidate = move_one_ball


def check(candidate):

    # Check some simple cases
    assert candidate([3, 4, 5, 1, 2])==True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([3, 5, 10, 1, 2])==True
    assert candidate([4, 3, 1, 2])==False
    # Check some edge cases that are easy to work out by hand.
    assert candidate([3, 5, 4, 1, 2])==False, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([])==True


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
