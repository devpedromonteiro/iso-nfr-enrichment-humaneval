
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Return the lexicographically smallest path of length k in the grid.

    A path:
    - starts from any cell
    - moves only up/down/left/right
    - visits exactly k cells
    - may revisit cells

    Since every value from 1 to N*N appears exactly once, the smallest possible
    first value is always the globally smallest reachable starting value.
    To get the lexicographically smallest full path, at each step we greedily
    move to the neighboring cell with the smallest value.

    Args:
        grid: NxN matrix containing each integer from 1 to N*N exactly once.
        k: Length of the path (number of visited cells).

    Returns:
        A list of values representing the lexicographically smallest path.
    """
    n = len(grid)

    # Find the position of the smallest value in the grid.
    min_row, min_col = 0, 0
    for r in range(n):
        for c in range(n):
            if grid[r][c] < grid[min_row][min_col]:
                min_row, min_col = r, c

    # Helper to yield valid neighboring positions.
    def neighbors(r, c):
        for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            nr, nc = r + dr, c + dc
            if 0 <= nr < n and 0 <= nc < n:
                yield nr, nc

    path = []
    row, col = min_row, min_col

    for _ in range(k):
        path.append(grid[row][col])

        # No need to choose the next cell after the last step.
        if len(path) == k:
            break

        # Move to the neighbor with the smallest value.
        next_row, next_col = min(neighbors(row, col), key=lambda pos: grid[pos[0]][pos[1]])
        row, col = next_row, next_col

    return path
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
