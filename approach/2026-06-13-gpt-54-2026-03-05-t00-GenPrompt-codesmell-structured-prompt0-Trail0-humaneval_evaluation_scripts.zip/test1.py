
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def _normalize_input(paren_string: str) -> str:
    """Remove all spaces from the input."""
    return "".join(paren_string.split())


def _split_balanced_groups(paren_string: str) -> List[str]:
    """Split a normalized parentheses string into balanced top-level groups."""
    groups: List[str] = []
    current_group: List[str] = []
    balance = 0

    for char in paren_string:
        current_group.append(char)

        if char == "(":
            balance += 1
        elif char == ")":
            balance -= 1

        if balance == 0 and current_group:
            groups.append("".join(current_group))
            current_group = []

    return groups


def separate_paren_groups(paren_string: str) -> List[str]:
    """Input to this function is a string containing multiple groups of nested parentheses.
    Your goal is to separate those groups into separate strings and return the list of those.

    Separate groups are balanced (each open brace is properly closed) and not nested within each other).
    Ignore any spaces in the input string.

    >>> separate_paren_groups('( ) (( )) (( )( ))')
    ['()', '(())', '(()())']
    """
    normalized = _normalize_input(paren_string)
    return _split_balanced_groups(normalized)
candidate = separate_paren_groups




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('(()()) ((())) () ((())()())') == [
        '(()())', '((()))', '()', '((())()())'
    ]
    assert candidate('() (()) ((())) (((())))') == [
        '()', '(())', '((()))', '(((())))'
    ]
    assert candidate('(()(())((())))') == [
        '(()(())((())))'
    ]
    assert candidate('( ) (( )) (( )( ))') == ['()', '(())', '(()())']


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
