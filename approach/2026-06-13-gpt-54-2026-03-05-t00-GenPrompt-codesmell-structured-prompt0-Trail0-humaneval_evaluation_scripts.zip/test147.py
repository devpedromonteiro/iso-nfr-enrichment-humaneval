
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    You are given a positive integer n. You have to create an integer array a of length n.
    For each i (1 â¤ i â¤ n), the value of a[i] = i * i - i + 1.

    Return the number of triples (a[i], a[j], a[k]) where i < j < k and
    a[i] + a[j] + a[k] is a multiple of 3.

    Example:
        Input: n = 5
        Output: 1
        Explanation:
        a = [1, 3, 7, 13, 21]
        The only valid triple is (1, 7, 13).
    """

    def count_indices_by_mod_3(length):
        counts = [0, 0, 0]
        for i in range(1, length + 1):
            counts[i % 3] += 1
        return counts

    def combinations_of_three(x):
        if x < 3:
            return 0
        return x * (x - 1) * (x - 2) // 6

    counts = count_indices_by_mod_3(n)
    count_0, count_1, count_2 = counts[0], counts[1], counts[2]

    # Since a[i] = i^2 - i + 1 â¡ 1 (mod 3) when i % 3 is 0 or 1,
    # and a[i] â¡ 0 (mod 3) when i % 3 is 2.
    divisible_values = count_2
    remainder_one_values = count_0 + count_1

    # Valid triples modulo 3:
    # (0,0,0) or (1,1,1)
    return (
        combinations_of_three(divisible_values)
        + combinations_of_three(remainder_one_values)
    )
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
