
import unittest
import re
import sys
import math
import copy



def _validate_non_empty_sequence(values: list) -> None:
    """Validate that the input list is not empty."""
    if not values:
        raise ValueError("median() arg is an empty list")


def _sorted_values(values: list) -> list:
    """Return a sorted copy of the input values."""
    return sorted(values)


def _middle_index(length: int) -> int:
    """Return the middle index for a sequence length."""
    return length // 2


def _median_of_sorted(values: list):
    """Return the median from an already sorted non-empty list."""
    length = len(values)
    mid = _middle_index(length)

    if length % 2 == 1:
        return values[mid]

    return (values[mid - 1] + values[mid]) / 2


def median(l: list):
    """Return median of elements in the list l.

    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    15.0
    """
    _validate_non_empty_sequence(l)
    sorted_list = _sorted_values(l)
    return _median_of_sorted(sorted_list)
candidate = median




METADATA = {}


def check(candidate):
    assert candidate([3, 1, 2, 4, 5]) == 3
    assert candidate([-10, 4, 6, 1000, 10, 20]) == 8.0
    assert candidate([5]) == 5
    assert candidate([6, 5]) == 5.5
    assert candidate([8, 1, 3, 9, 9, 2, 7]) == 7 



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
