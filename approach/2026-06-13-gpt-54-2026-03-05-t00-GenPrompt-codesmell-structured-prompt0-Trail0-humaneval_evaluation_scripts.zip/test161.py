
import unittest
import re
import sys
import math
import copy


def _has_letters(text):
    return any(char.isalpha() for char in text)


def _swap_case(text):
    return "".join(char.swapcase() if char.isalpha() else char for char in text)


def solve(s):
    """Return a case-reversed string, or the reversed string if it has no letters.

    Rules:
    - If the string contains at least one letter, reverse the case of each letter.
    - Non-letter characters remain unchanged.
    - If the string contains no letters, reverse the whole string.

    Examples:
    solve("1234") -> "4321"
    solve("ab") -> "AB"
    solve("#a@C") -> "#A@c"
    """
    if _has_letters(s):
        return _swap_case(s)
    return s[::-1]
candidate = solve


def check(candidate):

    # Check some simple cases
    assert candidate("AsDf") == "aSdF"
    assert candidate("1234") == "4321"
    assert candidate("ab") == "AB"
    assert candidate("#a@C") == "#A@c"
    assert candidate("#AsdfW^45") == "#aSDFw^45"
    assert candidate("#6@2") == "2@6#"

    # Check some edge cases that are easy to work out by hand.
    assert candidate("#$a^D") == "#$A^d"
    assert candidate("#ccc") == "#CCC"

    # Don't remove this line:


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
