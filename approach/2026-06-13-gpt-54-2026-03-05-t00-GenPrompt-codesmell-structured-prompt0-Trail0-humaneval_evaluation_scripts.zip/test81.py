
import unittest
import re
import sys
import math
import copy


def _grade_from_gpa(gpa):
    """Return the letter grade for a single GPA."""
    grade_thresholds = [
        (4.0, "A+"),
        (3.7, "A"),
        (3.3, "A-"),
        (3.0, "B+"),
        (2.7, "B"),
        (2.3, "B-"),
        (2.0, "C+"),
        (1.7, "C"),
        (1.3, "C-"),
        (1.0, "D+"),
        (0.7, "D"),
        (0.0, "D-"),
    ]

    if gpa == 4.0:
        return "A+"
    if gpa == 0.0:
        return "E"

    for threshold, letter_grade in grade_thresholds[1:]:
        if gpa > threshold:
            return letter_grade

    return "E"


def numerical_letter_grade(grades):
    """Convert a list of GPAs into their corresponding letter grades."""
    return [_grade_from_gpa(gpa) for gpa in grades]
candidate = numerical_letter_grade


def check(candidate):

    # Check some simple cases
    assert candidate([4.0, 3, 1.7, 2, 3.5]) == ['A+', 'B', 'C-', 'C', 'A-']
    assert candidate([1.2]) == ['D+']
    assert candidate([0.5]) == ['D-']
    assert candidate([0.0]) == ['E']
    assert candidate([1, 0.3, 1.5, 2.8, 3.3]) == ['D', 'D-', 'C-', 'B', 'B+']
    assert candidate([0, 0.7]) == ['E', 'D-']

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
