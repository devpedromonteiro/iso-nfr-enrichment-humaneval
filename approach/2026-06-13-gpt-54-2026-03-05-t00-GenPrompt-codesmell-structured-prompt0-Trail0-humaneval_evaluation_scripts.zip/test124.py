
import unittest
import re
import sys
import math
import copy


def _is_non_empty_string(value):
    return isinstance(value, str) and value != ""


def _has_valid_format(date_string):
    parts = date_string.split("-")
    return len(parts) == 3 and all(part.isdigit() for part in parts)


def _parse_date_parts(date_string):
    month_str, day_str, year_str = date_string.split("-")
    return int(month_str), int(day_str), int(year_str)


def _is_valid_month(month):
    return 1 <= month <= 12


def _max_days_in_month(month):
    if month == 2:
        return 29
    if month in {4, 6, 9, 11}:
        return 30
    return 31


def _is_valid_day(month, day):
    return 1 <= day <= _max_days_in_month(month)


def valid_date(date):
    """You have to write a function which validates a given date string and
    returns True if the date is valid otherwise False.
    The date is valid if all of the following rules are satisfied:
    1. The date string is not empty.
    2. The number of days is not less than 1 or higher than 31 days for months 1,3,5,7,8,10,12. And the number of days is not less than 1 or higher than 30 days for months 4,6,9,11. And, the number of days is not less than 1 or higher than 29 for the month 2.
    3. The months should not be less than 1 or higher than 12.
    4. The date should be in the format: mm-dd-yyyy

    for example:
    valid_date('03-11-2000') => True

    valid_date('15-01-2012') => False

    valid_date('04-0-2040') => False

    valid_date('06-04-2020') => True

    valid_date('06/04/2020') => False
    """
    if not _is_non_empty_string(date):
        return False

    if not _has_valid_format(date):
        return False

    month, day, _year = _parse_date_parts(date)

    if not _is_valid_month(month):
        return False

    return _is_valid_day(month, day)
candidate = valid_date


def check(candidate):

    # Check some simple cases
    assert candidate('03-11-2000') == True

    assert candidate('15-01-2012') == False

    assert candidate('04-0-2040') == False

    assert candidate('06-04-2020') == True

    assert candidate('01-01-2007') == True

    assert candidate('03-32-2011') == False

    assert candidate('') == False

    assert candidate('04-31-3000') == False

    assert candidate('06-06-2005') == True

    assert candidate('21-31-2000') == False

    assert candidate('04-12-2003') == True

    assert candidate('04122003') == False

    assert candidate('20030412') == False

    assert candidate('2003-04') == False

    assert candidate('2003-04-12') == False

    assert candidate('04-2003') == False


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
