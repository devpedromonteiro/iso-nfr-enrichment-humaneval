
import unittest
import re
import sys
import math
import copy


def _is_even_length(text):
    return len(text) % 2 == 0


def _sort_key(text):
    return (len(text), text)


def sorted_list_sum(lst):
    """Return even-length strings sorted by length, then alphabetically.

    Removes strings with odd lengths and returns a new sorted list.
    """
    even_length_strings = [text for text in lst if _is_even_length(text)]
    return sorted(even_length_strings, key=_sort_key)
candidate = sorted_list_sum


def check(candidate):

    # Check some simple cases
    assert candidate(["aa", "a", "aaa"]) == ["aa"]
    assert candidate(["school", "AI", "asdf", "b"]) == ["AI", "asdf", "school"]
    assert candidate(["d", "b", "c", "a"]) == []
    assert candidate(["d", "dcba", "abcd", "a"]) == ["abcd", "dcba"]

    # Check some edge cases that are easy to work out by hand.
    assert candidate(["AI", "ai", "au"]) == ["AI", "ai", "au"]
    assert candidate(["a", "b", "b", "c", "c", "a"]) == []
    assert candidate(['aaaa', 'bbbb', 'dd', 'cc']) == ["cc", "dd", "aaaa", "bbbb"]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
