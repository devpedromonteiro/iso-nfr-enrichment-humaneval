
import unittest
import re
import sys
import math
import copy


import re
from typing import List, Union


def split_words(txt: str) -> Union[List[str], int]:
    """
    Given a string of words:
    - split on whitespace if any whitespace exists
    - otherwise split on commas if any commas exist
    - otherwise return the count of lowercase letters whose alphabet index is odd
      (a=0, b=1, ..., z=25)

    Examples:
    split_words("Hello world!") -> ["Hello", "world!"]
    split_words("Hello,world!") -> ["Hello", "world!"]
    split_words("abcdef") -> 3
    """
    if _contains_whitespace(txt):
        return _split_on_whitespace(txt)

    if _contains_comma(txt):
        return _split_on_comma(txt)

    return _count_odd_order_lowercase_letters(txt)


def _contains_whitespace(txt: str) -> bool:
    return any(char.isspace() for char in txt)


def _contains_comma(txt: str) -> bool:
    return "," in txt


def _split_on_whitespace(txt: str) -> List[str]:
    return txt.split()


def _split_on_comma(txt: str) -> List[str]:
    return txt.split(",")


def _count_odd_order_lowercase_letters(txt: str) -> int:
    return sum(1 for char in txt if _is_lowercase_odd_order_letter(char))


def _is_lowercase_odd_order_letter(char: str) -> bool:
    return char.islower() and char.isalpha() and (ord(char) - ord("a")) % 2 == 1
candidate = split_words


def check(candidate):

    assert candidate("Hello world!") == ["Hello","world!"]
    assert candidate("Hello,world!") == ["Hello","world!"]
    assert candidate("Hello world,!") == ["Hello","world,!"]
    assert candidate("Hello,Hello,world !") == ["Hello,Hello,world","!"]
    assert candidate("abcdef") == 3
    assert candidate("aaabb") == 2
    assert candidate("aaaBb") == 1
    assert candidate("") == 0


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
