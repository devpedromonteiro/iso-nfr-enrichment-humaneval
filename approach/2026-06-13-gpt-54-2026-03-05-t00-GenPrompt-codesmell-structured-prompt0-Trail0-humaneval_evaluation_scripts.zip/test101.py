
import unittest
import re
import sys
import math
import copy


import re


def _normalize_separators(text):
    """Replace commas and surrounding whitespace with single spaces."""
    return re.sub(r"\s*,\s*|\s+", " ", text.strip())


def _split_words(text):
    """Split normalized text into words."""
    return [] if not text else text.split(" ")


def words_string(s):
    """
    Split a string of words separated by commas or spaces into a list of words.

    Examples:
    words_string("Hi, my name is John") -> ["Hi", "my", "name", "is", "John"]
    words_string("One, two, three, four, five, six") ->
        ["One", "two", "three", "four", "five", "six"]
    """
    normalized = _normalize_separators(s)
    return _split_words(normalized)
candidate = words_string


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate("Hi, my name is John") == ["Hi", "my", "name", "is", "John"]
    assert candidate("One, two, three, four, five, six") == ["One", "two", "three", "four", "five", "six"]
    assert candidate("Hi, my name") == ["Hi", "my", "name"]
    assert candidate("One,, two, three, four, five, six,") == ["One", "two", "three", "four", "five", "six"]

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate("") == []
    assert candidate("ahmed     , gamal") == ["ahmed", "gamal"]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
