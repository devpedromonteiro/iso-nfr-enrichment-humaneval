
import unittest
import re
import sys
import math
import copy



def _validate_non_negative_number(value, name):
    if not isinstance(value, (int, float)):
        raise TypeError(f"{name} must be a number")
    if value < 0:
        raise ValueError(f"{name} must be non-negative")


def triangle_area(a, h):
    """Given length of a side and height return area for a triangle.

    >>> triangle_area(5, 3)
    7.5
    """
    _validate_non_negative_number(a, "a")
    _validate_non_negative_number(h, "h")
    return (a * h) / 2
candidate = triangle_area




METADATA = {}


def check(candidate):
    assert candidate(5, 3) == 7.5
    assert candidate(2, 2) == 2.0
    assert candidate(10, 8) == 40.0



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
