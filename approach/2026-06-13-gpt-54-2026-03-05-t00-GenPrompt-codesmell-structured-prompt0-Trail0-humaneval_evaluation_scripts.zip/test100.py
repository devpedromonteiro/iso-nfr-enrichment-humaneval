
import unittest
import re
import sys
import math
import copy


def _step_for_parity(n):
    """Return the increment needed to keep the same parity sequence."""
    return 2


def make_a_pile(n):
    """
    Given a positive integer n, return a list representing a pile of n levels.

    The first level has n stones, and each next level has the next number
    with the same parity as n.

    Examples:
    >>> make_a_pile(3)
    [3, 5, 7]
    >>> make_a_pile(4)
    [4, 6, 8, 10]
    """
    step = _step_for_parity(n)
    return [n + step * i for i in range(n)]
candidate = make_a_pile


def check(candidate):

    # Check some simple cases
    assert candidate(3) == [3, 5, 7], "Test 3"
    assert candidate(4) == [4,6,8,10], "Test 4"
    assert candidate(5) == [5, 7, 9, 11, 13]
    assert candidate(6) == [6, 8, 10, 12, 14, 16]
    assert candidate(8) == [8, 10, 12, 14, 16, 18, 20, 22]

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
