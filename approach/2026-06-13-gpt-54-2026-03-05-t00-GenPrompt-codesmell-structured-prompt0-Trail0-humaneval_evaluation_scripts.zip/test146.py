
import unittest
import re
import sys
import math
import copy


def _first_digit(value):
    """Return the first digit of a non-negative integer."""
    while value >= 10:
        value //= 10
    return value


def _has_odd_first_and_last_digit(number):
    """Check whether both the first and last digits are odd."""
    value = abs(number)
    first = _first_digit(value)
    last = value % 10
    return first % 2 == 1 and last % 2 == 1


def specialFilter(nums):
    """Return how many numbers are greater than 10 and have odd first/last digits."""
    return sum(
        1
        for number in nums
        if number > 10 and _has_odd_first_and_last_digit(number)
    )
candidate = specialFilter


def check(candidate):

    # Check some simple cases
    assert candidate([5, -2, 1, -5]) == 0  
    assert candidate([15, -73, 14, -15]) == 1
    assert candidate([33, -2, -3, 45, 21, 109]) == 2
    assert candidate([43, -12, 93, 125, 121, 109]) == 4
    assert candidate([71, -2, -33, 75, 21, 19]) == 3


    # Check some edge cases that are easy to work out by hand.
    assert candidate([1]) == 0              
    assert candidate([]) == 0                   



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
