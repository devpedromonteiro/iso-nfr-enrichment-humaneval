
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List

_NUMBER_ORDER = {
    "zero": 0,
    "one": 1,
    "two": 2,
    "three": 3,
    "four": 4,
    "five": 5,
    "six": 6,
    "seven": 7,
    "eight": 8,
    "nine": 9,
}


def _tokenize_numbers(numbers: str) -> List[str]:
    """Split the input string into numeral words."""
    return numbers.split()


def _sort_numeral_words(words: List[str]) -> List[str]:
    """Sort numeral words by their numeric value."""
    return sorted(words, key=_NUMBER_ORDER.__getitem__)


def sort_numbers(numbers: str) -> str:
    """Input is a space-delimited string of numerals from 'zero' to 'nine'.

    Valid choices are 'zero', 'one', 'two', 'three', 'four', 'five',
    'six', 'seven', 'eight' and 'nine'.

    Return the string with numbers sorted from smallest to largest.

    >>> sort_numbers('three one five')
    'one three five'
    """
    words = _tokenize_numbers(numbers)
    sorted_words = _sort_numeral_words(words)
    return " ".join(sorted_words)
candidate = sort_numbers




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == ''
    assert candidate('three') == 'three'
    assert candidate('three five nine') == 'three five nine'
    assert candidate('five zero four seven nine eight') == 'zero four five seven eight nine'
    assert candidate('six five four three two one zero') == 'zero one two three four five six'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
