
import unittest
import re
import sys
import math
import copy


def is_nested(string):
    """
    Return True if the bracket string contains a valid nested subsequence.

    A nested subsequence exists when we can find at least two unmatched opening
    brackets before a matching closing bracket, i.e. a pattern equivalent to
    '[[]]' in some valid subsequence.
    """

    depth = 0

    for char in string:
        if char == '[':
            depth += 1
        elif char == ']':
            if depth >= 2:
                return True
            if depth == 1:
                depth -= 1

    return False
candidate = is_nested


def check(candidate):

    # Check some simple cases
    assert candidate('[[]]') == True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('[]]]]]]][[[[[]') == False
    assert candidate('[][]') == False
    assert candidate(('[]')) == False
    assert candidate('[[[[]]]]') == True
    assert candidate('[]]]]]]]]]]') == False
    assert candidate('[][][[]]') == True
    assert candidate('[[]') == False
    assert candidate('[]]') == False
    assert candidate('[[]][[') == True
    assert candidate('[[][]]') == True

    # Check some edge cases that are easy to work out by hand.
    assert candidate('') == False, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate('[[[[[[[[') == False
    assert candidate(']]]]]]]]') == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
