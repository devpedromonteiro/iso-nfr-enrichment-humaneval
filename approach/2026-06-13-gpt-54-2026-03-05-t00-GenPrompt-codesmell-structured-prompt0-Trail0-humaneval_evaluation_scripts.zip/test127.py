
import unittest
import re
import sys
import math
import copy


def intersection(interval1, interval2):
    """Determine whether the length of the intersection of two closed intervals is prime.

    The intersection length is computed as the number of integers strictly between
    the overlapping endpoints in terms of interval distance:
    for overlap (start, end), length = end - start.

    Returns:
        "YES" if the intersection length is a prime number, otherwise "NO".
    """
    overlap_length = _get_intersection_length(interval1, interval2)
    return "YES" if _is_prime(overlap_length) else "NO"


def _get_intersection_length(interval1, interval2):
    """Return the length of the overlap between two closed intervals."""
    start = max(interval1[0], interval2[0])
    end = min(interval1[1], interval2[1])
    return end - start if start <= end else -1


def _is_prime(number):
    """Return True if number is prime, otherwise False."""
    if number < 2:
        return False
    if number == 2:
        return True
    if number % 2 == 0:
        return False

    divisor = 3
    while divisor * divisor <= number:
        if number % divisor == 0:
            return False
        divisor += 2
    return True
candidate = intersection


def check(candidate):

    # Check some simple cases
    assert candidate((1, 2), (2, 3)) == "NO"
    assert candidate((-1, 1), (0, 4)) == "NO"
    assert candidate((-3, -1), (-5, 5)) == "YES"
    assert candidate((-2, 2), (-4, 0)) == "YES"

    # Check some edge cases that are easy to work out by hand.
    assert candidate((-11, 2), (-1, -1)) == "NO"
    assert candidate((1, 2), (3, 5)) == "NO"
    assert candidate((1, 2), (1, 2)) == "NO"
    assert candidate((-2, -2), (-3, -2)) == "NO"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
