
import unittest
import re
import sys
import math
import copy


def _is_even(value):
    return value % 2 == 0


def _find_smallest_even(arr):
    smallest_value = None
    smallest_index = -1

    for index, value in enumerate(arr):
        if _is_even(value):
            if smallest_value is None or value < smallest_value:
                smallest_value = value
                smallest_index = index

    if smallest_value is None:
        return []

    return [smallest_value, smallest_index]


def pluck(arr):
    return _find_smallest_even(arr)
candidate = pluck


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([4,2,3]) == [2, 1], "Error"
    assert candidate([1,2,3]) == [2, 1], "Error"
    assert candidate([]) == [], "Error"
    assert candidate([5, 0, 3, 0, 4, 2]) == [0, 1], "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([1, 2, 3, 0, 5, 3]) == [0, 3], "Error"
    assert candidate([5, 4, 8, 4 ,8]) == [4, 1], "Error"
    assert candidate([7, 6, 7, 1]) == [6, 1], "Error"
    assert candidate([7, 9, 7, 1]) == [], "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
