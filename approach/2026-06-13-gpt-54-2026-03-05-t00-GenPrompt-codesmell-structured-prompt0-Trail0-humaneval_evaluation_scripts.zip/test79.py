
import unittest
import re
import sys
import math
import copy


def _to_binary_digits(decimal):
    """Convert a non-negative integer to its binary digit string."""
    if decimal == 0:
        return "0"

    digits = []
    while decimal > 0:
        digits.append(str(decimal % 2))
        decimal //= 2

    return "".join(reversed(digits))


def _wrap_with_db(binary_digits):
    """Wrap binary digits with the required db markers."""
    return f"db{binary_digits}db"


def decimal_to_binary(decimal):
    """Convert a decimal number to the required wrapped binary format.

    Examples:
    decimal_to_binary(15) -> "db1111db"
    decimal_to_binary(32) -> "db100000db"
    """
    binary_digits = _to_binary_digits(decimal)
    return _wrap_with_db(binary_digits)
candidate = decimal_to_binary


def check(candidate):

    # Check some simple cases
    assert candidate(0) == "db0db"
    assert candidate(32) == "db100000db"
    assert candidate(103) == "db1100111db"
    assert candidate(15) == "db1111db", "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
