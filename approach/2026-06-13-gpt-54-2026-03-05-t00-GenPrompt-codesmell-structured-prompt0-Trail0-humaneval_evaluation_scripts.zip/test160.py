
import unittest
import re
import sys
import math
import copy


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and
    the second list is a list of integers. Use the two given lists to build the algebraic
    expression and return the evaluation of this expression.

    Supported operations:
    Addition ( + )
    Subtraction ( - )
    Multiplication ( * )
    Floor division ( // )
    Exponentiation ( ** )
    """
    _validate_inputs(operator, operand)
    tokens = _build_expression_tokens(operator, operand)
    expression = " ".join(tokens)
    return eval(expression)


def _validate_inputs(operator, operand):
    if len(operator) != len(operand) - 1:
        raise ValueError("operator length must be equal to operand length minus one")

    supported_operators = {"+", "-", "*", "//", "**"}
    invalid_operators = [op for op in operator if op not in supported_operators]
    if invalid_operators:
        raise ValueError(f"unsupported operators: {invalid_operators}")


def _build_expression_tokens(operator, operand):
    tokens = [str(operand[0])]

    for op, value in zip(operator, operand[1:]):
        tokens.append(op)
        tokens.append(str(value))

    return tokens
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
