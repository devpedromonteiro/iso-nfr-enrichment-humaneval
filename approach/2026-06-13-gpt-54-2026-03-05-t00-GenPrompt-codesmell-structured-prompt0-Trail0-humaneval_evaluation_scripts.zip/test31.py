
import unittest
import re
import sys
import math
import copy



def _is_invalid_prime_candidate(n):
    """Return True when n cannot be a prime number."""
    return n <= 1


def _is_trivial_prime(n):
    """Return True when n is one of the smallest prime numbers."""
    return n in (2, 3)


def _is_divisible_by_small_factor(n):
    """Return True when n is divisible by 2 or 3."""
    return n % 2 == 0 or n % 3 == 0


def _has_nontrivial_divisor(n):
    """Return True when n has a divisor greater than 3."""
    factor = 5
    while factor * factor <= n:
        if n % factor == 0 or n % (factor + 2) == 0:
            return True
        factor += 6
    return False


def is_prime(n):
    """Return true if a given number is prime, and false otherwise.
    >>> is_prime(6)
    False
    >>> is_prime(101)
    True
    >>> is_prime(11)
    True
    >>> is_prime(13441)
    True
    >>> is_prime(61)
    True
    >>> is_prime(4)
    False
    >>> is_prime(1)
    False
    """
    if _is_invalid_prime_candidate(n):
        return False
    if _is_trivial_prime(n):
        return True
    if _is_divisible_by_small_factor(n):
        return False
    return not _has_nontrivial_divisor(n)
candidate = is_prime




METADATA = {}


def check(candidate):
    assert candidate(6) == False
    assert candidate(101) == True
    assert candidate(11) == True
    assert candidate(13441) == True
    assert candidate(61) == True
    assert candidate(4) == False
    assert candidate(1) == False
    assert candidate(5) == True
    assert candidate(11) == True
    assert candidate(17) == True
    assert candidate(5 * 17) == False
    assert candidate(11 * 7) == False
    assert candidate(13441 * 19) == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
