
import unittest

from typing import List


from typing import List


def factorize(n: int) -> List[int]:
    """Return the prime factors of ``n`` from smallest to largest.

    Each prime factor appears as many times as it occurs in the factorization.

    >>> factorize(8)
    [2, 2, 2]
    >>> factorize(25)
    [5, 5]
    >>> factorize(70)
    [2, 5, 7]
    """
    factors: List[int] = []
    remaining = n
    divisor = 2

    while divisor * divisor <= remaining:
        while remaining % divisor == 0:
            factors.append(divisor)
            remaining //= divisor
        divisor += 1

    if remaining > 1:
        factors.append(remaining)

    return factors
candidate = factorize


class Test(unittest.TestCase):
    def test(self):
        assert candidate(3 * 19 * 19 * 19) == [3, 19, 19, 19]
        assert candidate(3 * 19 * 3 * 19) == [3, 3, 19, 19]
        assert candidate(185940) == [2, 2, 3, 3, 5, 1033]
        assert candidate(2690) == [2, 5, 269]
        assert candidate(184219) == [7, 26317]
        assert candidate(184152) == [2, 2, 2, 3, 7673]
        assert candidate(21091) == [7, 23, 131]
        assert candidate(3 * 19 * 3 * 19 * 3 * 19) == [3, 3, 3, 19, 19, 19]
        assert candidate(20270) == [2, 5, 2027]
        assert candidate(21236) == [2, 2, 5309]
        assert candidate(19) == [19]
        assert candidate(19825) == [5, 5, 13, 61]
        assert candidate(15) == [3, 5]
        assert candidate(62) == [2, 31]
        assert candidate(2438) == [2, 23, 53]
        assert candidate(2894) == [2, 1447]
        assert candidate(3688) == [2, 2, 2, 461]
        assert candidate(4019) == [4019]
        assert candidate(21448) == [2, 2, 2, 7, 383]
        assert candidate(20229) == [3, 11, 613]
        assert candidate(2) == [2]
        assert candidate(55) == [5, 11]
        assert candidate(185555) == [5, 17, 37, 59]
        assert candidate(13) == [13]
        assert candidate(185970) == [2, 3, 5, 6199]
        assert candidate(185618) == [2, 92809]
        assert candidate(19605) == [3, 5, 1307]
        assert candidate(1) == []
        assert candidate(185727) == [3, 61909]
        assert candidate(20475) == [3, 3, 5, 5, 7, 13]
        assert candidate(2344) == [2, 2, 2, 293]
        assert candidate(2979) == [3, 3, 331]
        assert candidate(7) == [7]
        assert candidate(184579) == [131, 1409]
        assert candidate(20094) == [2, 3, 17, 197]
        assert candidate(20644) == [2, 2, 13, 397]
        assert candidate(20929) == [20929]
        assert candidate(61) == [61]
        assert candidate(5) == [5]
        assert candidate(3) == [3]
        assert candidate(3307) == [3307]
        assert candidate(19880) == [2, 2, 2, 5, 7, 71]
        assert candidate(3 * 2 * 3) == [2, 3, 3]
        assert candidate(4065) == [3, 5, 271]
        assert candidate(3691) == [3691]
        assert candidate(185592) == [2, 2, 2, 3, 11, 19, 37]
        assert candidate(184432) == [2, 2, 2, 2, 11527]
        assert candidate(9) == [3, 3]
        assert candidate(54) == [2, 3, 3, 3]
        assert candidate(2939) == [2939]
        assert candidate(22) == [2, 11]
        assert candidate(6) == [2, 3]
        assert candidate(12) == [2, 2, 3]
        assert candidate(58) == [2, 29]
        assert candidate(3116) == [2, 2, 19, 41]
        assert candidate(56) == [2, 2, 2, 7]
        assert candidate(16) == [2, 2, 2, 2]
        assert candidate(20902) == [2, 7, 1493]
        assert candidate(8) == [2, 2, 2]
        assert candidate(19879) == [103, 193]
        assert candidate(23) == [23]
        assert candidate(10) == [2, 5]
        assert candidate(2373) == [3, 7, 113]
        assert candidate(186028) == [2, 2, 46507]
        assert candidate(185036) == [2, 2, 167, 277]
        assert candidate(184240) == [2, 2, 2, 2, 5, 7, 7, 47]
        assert candidate(20807) == [20807]
        assert candidate(14) == [2, 7]
        assert candidate(4) == [2, 2]
        assert candidate(3 * 19) == [3, 19]
        assert candidate(184984) == [2, 2, 2, 19, 1217]
        assert candidate(185324) == [2, 2, 107, 433]
        assert candidate(2719) == [2719]
        assert candidate(3905) == [5, 11, 71]
        assert candidate(52) == [2, 2, 13]

if __name__ == '__main__':
    unittest.main()
