
import unittest
import re
import sys
import math
import copy


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and
    the second list is a list of integers. Use the two given lists to build the algebraic
    expression and return the evaluation of this expression.

    Supported operators:
    +, -, *, //, **

    Evaluation follows normal Python operator precedence.
    """
    # First collapse high-precedence operations (** , * , //) in one pass,
    # while keeping low-precedence (+, -) for a final linear pass.
    values = [operand[0]]
    low_ops = []

    for op, num in zip(operator, operand[1:]):
        if op == '**':
            values[-1] = values[-1] ** num
        elif op == '*':
            values[-1] *= num
        elif op == '//':
            values[-1] //= num
        elif op == '+':
            low_ops.append(op)
            values.append(num)
        else:  # op == '-'
            low_ops.append(op)
            values.append(num)

    # Final pass for + and -
    result = values[0]
    for op, num in zip(low_ops, values[1:]):
        if op == '+':
            result += num
        else:
            result -= num

    return result
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
