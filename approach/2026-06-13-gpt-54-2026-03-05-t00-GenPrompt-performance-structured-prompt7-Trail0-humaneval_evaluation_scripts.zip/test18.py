
import unittest
import re
import sys
import math
import copy



def how_many_times(string: str, substring: str) -> int:
    """Find how many times a given substring occurs in the original string.
    Overlapping matches are counted.

    >>> how_many_times('', 'a')
    0
    >>> how_many_times('aaa', 'a')
    3
    >>> how_many_times('aaaa', 'aa')
    3
    """
    if not string or not substring:
        return 0

    count = 0
    start = 0
    while True:
        idx = string.find(substring, start)
        if idx == -1:
            break
        count += 1
        start = idx + 1
    return count
candidate = how_many_times




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('', 'x') == 0
    assert candidate('xyxyxyx', 'x') == 4
    assert candidate('cacacacac', 'cac') == 4
    assert candidate('john doe', 'john') == 1


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
