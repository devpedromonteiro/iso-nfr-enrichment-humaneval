
import unittest


def words_in_sentence(sentence):
    """
    You are given a string representing a sentence,
    the sentence contains some words separated by a space,
    and you have to return a string that contains the words from the original sentence,
    whose lengths are prime numbers,
    the order of the words in the new string should be the same as the original one.

    Example 1:
        Input: sentence = "This is a test"
        Output: "is"

    Example 2:
        Input: sentence = "lets go for swimming"
        Output: "go for"

    Constraints:
        * 1 <= len(sentence) <= 100
        * sentence contains only letters
    """

    def is_prime(number):
        if number < 2:
            return False
        if number == 2:
            return True
        if number % 2 == 0:
            return False

        divisor = 3
        while divisor * divisor <= number:
            if number % divisor == 0:
                return False
            divisor += 2
        return True

    words = sentence.split()
    prime_length_words = [word for word in words if is_prime(len(word))]
    return " ".join(prime_length_words)
candidate = words_in_sentence


class Test(unittest.TestCase):
    def test(self):
        assert candidate("bwx    iweqxvuzcncrozfvjh cldf la") == 'bwx la'
        assert candidate("ebaelvct lyqwict xs") == 'lyqwict xs'
        assert candidate("brvoc ") == 'brvoc'
        assert candidate(" mboxy") == 'mboxy'
        assert candidate(" dgs ") == 'dgs'
        assert candidate("orasjxzf z xa sh   dca mprwjrhecfe") == 'xa sh dca mprwjrhecfe'
        assert candidate("ysqkfqoj  lletkxjo xdf") == 'xdf'
        assert candidate(" seohs g ") == 'seohs'
        assert candidate("x  Hqz TzvATYBZVC") == 'Hqz'
        assert candidate("mRkf  TUpaZJb") == 'TUpaZJb'
        assert candidate("qsv") == 'qsv'
        assert candidate("ustp hasgmwe") == 'hasgmwe'
        assert candidate("wltiidisdshqdgqzdupmmosyom ") == ''
        assert candidate("there is no place available here") == "there is no place"
        assert candidate("iwwquyz zzdnjsmnketxnwy") == 'iwwquyz'
        assert candidate("v  kdua") == ''
        assert candidate("FqAUlv fJlRNB  FNX") == 'FNX'
        assert candidate("wedvhfpbyclmdyezpttascfknyva") == ''
        assert candidate("knhdfseyib") == ''
        assert candidate("mZvJuobQiGMkjpOnRu") == ''
        assert candidate("oOdKuIewhlQaNHST  ") == ''
        assert candidate("cz aya nwie vdjhobtirgkjilzjbg") == 'cz aya'
        assert candidate("faMrT aJwycF") == 'faMrT'
        assert candidate("here") == ""
        assert candidate("lets go for swimming") == "go for"
        assert candidate("udstoapumz ") == ''
        assert candidate("afq  gdxrz mkpslkltjpj a iny wskuxu") == 'afq gdxrz mkpslkltjpj iny'
        assert candidate("jpzep fqa") == 'jpzep fqa'
        assert candidate("mnt xartsstuxgdwglhu vyr") == 'mnt vyr'
        assert candidate("onski") == 'onski'
        assert candidate("t o ") == ''
        assert candidate("xpgj") == ''
        assert candidate("xkixju d") == ''
        assert candidate("gayaypivvxwu ndpxq") == 'ndpxq'
        assert candidate("tlfrmmlasog vi  rfgzuns kwsbkiwxnrjv") == 'tlfrmmlasog vi rfgzuns'
        assert candidate("go  jV ShvUEMiE") == 'go jV'
        assert candidate("dt khhccmffxcswrvolyl") == 'dt'
        assert candidate("s rokrwtn qzvbrgbf") == 'rokrwtn'
        assert candidate(" WwQmPKXAxTU") == 'WwQmPKXAxTU'
        assert candidate("Ha rMHRuLRiY") == 'Ha'
        assert candidate("ynytu ewvd") == 'ynytu'
        assert candidate("XJm  tRQsV") == 'XJm tRQsV'
        assert candidate("p nylyzve") == 'nylyzve'
        assert candidate("nwu xiau") == 'nwu'
        assert candidate("fmg jj") == 'fmg jj'
        assert candidate("ojeej") == 'ojeej'
        assert candidate("nCGlejWzIq j ") == ''
        assert candidate(" hfcrgrombeqinu w") == ''
        assert candidate("j tnnfiwtwl nm ejbpxkryhutg awfjuc") == 'nm'
        assert candidate("gah  RogZ") == 'gah'
        assert candidate("s   u zfp") == 'zfp'
        assert candidate("yv  ksjzj") == 'yv ksjzj'
        assert candidate("rYBHJL w tGmS I jI qO") == 'jI qO'
        assert candidate("fnbtnmyfd i") == ''
        assert candidate(" ktbteo") == ''
        assert candidate("E  RZi kGDDovBr") == 'RZi'
        assert candidate("DKktElZUSPQ sRFO") == 'DKktElZUSPQ'
        assert candidate("hbjnyqftmbgsh") == 'hbjnyqftmbgsh'
        assert candidate("jpr zlnfpdpztvswentdnno ") == 'jpr zlnfpdpztvswentdnno'
        assert candidate("nVBsIIsRZmHXtC") == ''
        assert candidate("bbnnyywlly") == ''
        assert candidate("incpzw mqtfh uodaf") == 'mqtfh uodaf'
        assert candidate("KXDZBIBxWS") == ''
        assert candidate("xdXqM xRQLGpW") == 'xdXqM xRQLGpW'
        assert candidate("onLNjvJKB kyGm") == ''
        assert candidate("zhw  cogagm") == 'zhw'
        assert candidate("mWRhyWtGiZxlpJ hq  s") == 'hq'
        assert candidate("d okkyjdcoshkf y bbz") == 'bbz'
        assert candidate("jbfoy vhqq wcp rdzaqj u qidqjmr yxd") == 'jbfoy wcp qidqjmr yxd'
        assert candidate("g dbsva ells") == 'dbsva'
        assert candidate("here is") == "is"
        assert candidate("pwlvnqxjghh yoxemx cwqu prie qsy") == 'pwlvnqxjghh qsy'
        assert candidate("hbok orfd") == ''
        assert candidate("rckasnz qivvh ") == 'rckasnz qivvh'
        assert candidate("tkbba fjcvajmrbemj maloq yw ") == 'tkbba maloq yw'
        assert candidate("qlqs gf bm") == 'gf bm'
        assert candidate(" ml n ") == 'ml'
        assert candidate("nxx pl i   ysehgkfo") == 'nxx pl'
        assert candidate("AvcgNCWZQl R") == ''
        assert candidate("etGrdLBtgA HOcCOmfbF") == ''
        assert candidate("vlwnbi cctdgtpqv  umztaw") == ''
        assert candidate("xazrkmp  dquylyujw nwrhah vkb a") == 'xazrkmp vkb'
        assert candidate("BXaBjGjrspbJSH") == ''
        assert candidate("tcljn") == 'tcljn'
        assert candidate(" UCNaOVPk  ") == ''
        assert candidate("  ykcuqiir") == ''
        assert candidate("OynMpE IeViwO") == ''
        assert candidate("ffco ic") == 'ic'
        assert candidate("xRlNnTl KrtMh") == 'xRlNnTl KrtMh'
        assert candidate("kaqe") == ''
        assert candidate("r a jbnbkhsuidhi mvovyq") == ''
        assert candidate("enjd") == ''
        assert candidate("zithec") == ''
        assert candidate("nohzjc j  klcdzuzjlviru   nhnzsk u ") == 'klcdzuzjlviru'
        assert candidate("lnum") == ''
        assert candidate(" ntadoa skxzevo  tb") == 'skxzevo tb'
        assert candidate("fdes jlxltwmprsqlpodvia wizcxu") == ''
        assert candidate("xqLpFjaPyDLhim xO") == 'xO'
        assert candidate("cjvvf") == 'cjvvf'
        assert candidate("lblfvpuzhqkbh b") == 'lblfvpuzhqkbh'
        assert candidate("tmU TNrqNAsyFLOh lhw") == 'tmU lhw'
        assert candidate("avfbsbr ne slo dbq ek xkoagjn") == 'avfbsbr ne slo dbq ek xkoagjn'
        assert candidate("wezxe") == 'wezxe'
        assert candidate("Q TjyIWLZniqEv") == ''
        assert candidate("This is a test") == "is"
        assert candidate("rggmlp") == ''
        assert candidate("go for it") == "go for it"

    # Check some edge cases that are easy to work out by hand.
        assert candidate("ikmsuyqiaap zlnlogfzpa") == 'ikmsuyqiaap'
        assert candidate("o stvgznn") == 'stvgznn'
        assert candidate("myetpwnx edadxdfarmtkjlqh spe nkl") == 'spe nkl'
        assert candidate(" hguqx") == 'hguqx'
        assert candidate("mmhb") == ''
        assert candidate("mltE NaSAMAg cA") == 'NaSAMAg cA'
        assert candidate("ew  tk ehaf") == 'ew tk'
        assert candidate("fjhv ecryy") == 'ecryy'
        assert candidate("Hi I am Hussein") == "Hi am Hussein"
        assert candidate(" LUEjadzWVKN") == 'LUEjadzWVKN'
        assert candidate("piibojh ls vb pkobjcocis n ") == 'piibojh ls vb'
        assert candidate("xjh ykag itkurnakb") == 'xjh'
        assert candidate("b  f rixpypk kmjdkvqqz annxke") == 'rixpypk'
        assert candidate("JIxQBVuMwvx v ") == 'JIxQBVuMwvx'
        assert candidate("cy cad") == 'cy cad'
        assert candidate("KGjXAWbLKE zcFZ") == ''
        assert candidate("bm  ojecs zhesy") == 'bm ojecs zhesy'
        assert candidate("yppcp gf") == 'yppcp gf'
        assert candidate("TC vrUAV uwpnLUJ") == 'TC vrUAV uwpnLUJ'
        assert candidate("tx e qlcglux") == 'tx qlcglux'
        assert candidate("dtsipy") == ''
        assert candidate(" s zrue") == ''
        assert candidate("okgifwkqqmd") == 'okgifwkqqmd'
        assert candidate(" ddyyl wvs") == 'ddyyl wvs'
        assert candidate("dnuyQmZcsHRmVApL") == ''
        assert candidate("USEFFD  KcHmTkt") == 'KcHmTkt'

if __name__ == '__main__':
    unittest.main()
