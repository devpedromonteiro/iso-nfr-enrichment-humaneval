
import unittest
import re
import sys
import math
import copy



from typing import Sequence, Union

Number = Union[int, float]


def _validate_non_empty(values: Sequence[Number]) -> None:
    if not values:
        raise ValueError("median() arg is an empty sequence")


def _sorted_values(values: Sequence[Number]) -> list[Number]:
    return sorted(values)


def _middle_index(length: int) -> int:
    return length // 2


def median(values: Sequence[Number]) -> Number:
    """Return the median of the elements in values.

    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    8.0
    """
    _validate_non_empty(values)
    ordered = _sorted_values(values)
    size = len(ordered)
    mid = _middle_index(size)

    if size % 2 == 1:
        return ordered[mid]

    return (ordered[mid - 1] + ordered[mid]) / 2
candidate = median




METADATA = {}


def check(candidate):
    assert candidate([3, 1, 2, 4, 5]) == 3
    assert candidate([-10, 4, 6, 1000, 10, 20]) == 8.0
    assert candidate([5]) == 5
    assert candidate([6, 5]) == 5.5
    assert candidate([8, 1, 3, 9, 9, 2, 7]) == 7 



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
