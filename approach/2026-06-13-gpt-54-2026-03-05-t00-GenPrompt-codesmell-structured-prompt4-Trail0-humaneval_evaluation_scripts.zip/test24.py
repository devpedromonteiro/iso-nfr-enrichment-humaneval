
import unittest
import re
import sys
import math
import copy



def _largest_proper_divisor_from_half(n: int) -> int:
    """Return the largest proper divisor of n by searching downward from n // 2."""
    for candidate in range(n // 2, 0, -1):
        if n % candidate == 0:
            return candidate
    return 1


def largest_divisor(n: int) -> int:
    """For a given number n, find the largest number that divides n evenly, smaller than n.

    >>> largest_divisor(15)
    5
    """
    if n <= 1:
        raise ValueError("n must be greater than 1")

    return _largest_proper_divisor_from_half(n)
candidate = largest_divisor




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(3) == 1
    assert candidate(7) == 1
    assert candidate(10) == 5
    assert candidate(100) == 50
    assert candidate(49) == 7


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
