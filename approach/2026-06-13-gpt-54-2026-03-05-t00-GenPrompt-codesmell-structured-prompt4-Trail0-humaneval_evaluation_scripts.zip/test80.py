
import unittest
import re
import sys
import math
import copy


def _has_minimum_length(text, minimum=3):
    return len(text) >= minimum


def _triplet_is_distinct(triplet):
    return len(set(triplet)) == 3


def _all_consecutive_triplets_are_distinct(text):
    for index in range(len(text) - 2):
        if not _triplet_is_distinct(text[index:index + 3]):
            return False
    return True


def is_happy(s):
    """Check whether a string is happy.

    A string is happy if:
    - its length is at least 3
    - every 3 consecutive letters are distinct
    """
    if not _has_minimum_length(s):
        return False

    return _all_consecutive_triplets_are_distinct(s)
candidate = is_happy


def check(candidate):

    # Check some simple cases
    assert candidate("a") == False , "a"
    assert candidate("aa") == False , "aa"
    assert candidate("abcd") == True , "abcd"
    assert candidate("aabb") == False , "aabb"
    assert candidate("adb") == True , "adb"
    assert candidate("xyy") == False , "xyy"
    assert candidate("iopaxpoi") == True , "iopaxpoi"
    assert candidate("iopaxioi") == False , "iopaxioi"


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
