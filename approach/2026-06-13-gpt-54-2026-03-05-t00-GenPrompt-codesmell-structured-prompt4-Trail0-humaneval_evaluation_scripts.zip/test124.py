
import unittest
import re
import sys
import math
import copy


def _is_valid_format(date_string):
    """Return True when the date matches the exact mm-dd-yyyy format."""
    if not isinstance(date_string, str) or not date_string:
        return False

    parts = date_string.split("-")
    if len(parts) != 3:
        return False

    month, day, year = parts
    return (
        len(month) == 2 and month.isdigit() and
        len(day) == 2 and day.isdigit() and
        len(year) == 4 and year.isdigit()
    )


def _days_in_month(month):
    """Return the maximum valid day for the given month."""
    if month == 2:
        return 29
    if month in {4, 6, 9, 11}:
        return 30
    return 31


def valid_date(date):
    """Validate whether a date string is in mm-dd-yyyy format and has valid ranges."""
    if not _is_valid_format(date):
        return False

    month_str, day_str, _year_str = date.split("-")
    month = int(month_str)
    day = int(day_str)

    if month < 1 or month > 12:
        return False

    return 1 <= day <= _days_in_month(month)
candidate = valid_date


def check(candidate):

    # Check some simple cases
    assert candidate('03-11-2000') == True

    assert candidate('15-01-2012') == False

    assert candidate('04-0-2040') == False

    assert candidate('06-04-2020') == True

    assert candidate('01-01-2007') == True

    assert candidate('03-32-2011') == False

    assert candidate('') == False

    assert candidate('04-31-3000') == False

    assert candidate('06-06-2005') == True

    assert candidate('21-31-2000') == False

    assert candidate('04-12-2003') == True

    assert candidate('04122003') == False

    assert candidate('20030412') == False

    assert candidate('2003-04') == False

    assert candidate('2003-04-12') == False

    assert candidate('04-2003') == False


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
