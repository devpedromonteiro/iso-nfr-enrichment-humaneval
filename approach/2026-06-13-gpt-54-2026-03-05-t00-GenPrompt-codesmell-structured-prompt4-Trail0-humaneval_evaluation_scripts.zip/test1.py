
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def _normalize_paren_string(paren_string: str) -> str:
    """Remove spaces from the input."""
    return "".join(paren_string.split())


def separate_paren_groups(paren_string: str) -> List[str]:
    """Separate top-level balanced parenthesis groups.

    Input is a string containing multiple groups of nested parentheses.
    Spaces are ignored.

    >>> separate_paren_groups('( ) (( )) (( )( ))')
    ['()', '(())', '(()())']
    """
    normalized = _normalize_paren_string(paren_string)

    groups: List[str] = []
    current_group: List[str] = []
    balance = 0

    for char in normalized:
        current_group.append(char)

        if char == "(":
            balance += 1
        elif char == ")":
            balance -= 1

        if balance == 0 and current_group:
            groups.append("".join(current_group))
            current_group = []

    return groups
candidate = separate_paren_groups




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('(()()) ((())) () ((())()())') == [
        '(()())', '((()))', '()', '((())()())'
    ]
    assert candidate('() (()) ((())) (((())))') == [
        '()', '(())', '((()))', '(((())))'
    ]
    assert candidate('(()(())((())))') == [
        '(()(())((())))'
    ]
    assert candidate('( ) (( )) (( )( ))') == ['()', '(())', '(()())']


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
