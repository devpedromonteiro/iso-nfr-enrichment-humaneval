
import unittest
import re
import sys
import math
import copy



def encode_shift(s: str):
    """
    returns encoded string by shifting every character by 5 in the alphabet.
    """
    return "".join([chr(((ord(ch) + 5 - ord("a")) % 26) + ord("a")) for ch in s])


SHIFT = 5
ALPHABET_START = ord("a")
ALPHABET_SIZE = 26


def _shift_char(ch: str, offset: int) -> str:
    """Shift a lowercase alphabetic character by the given offset."""
    return chr(((ord(ch) - ALPHABET_START + offset) % ALPHABET_SIZE) + ALPHABET_START)


def _transform_shift(text: str, offset: int) -> str:
    """Apply a Caesar-style shift to all characters in the input text."""
    return "".join(_shift_char(ch, offset) for ch in text)


def encode_shift(s: str) -> str:
    """
    Return an encoded string by shifting every character by 5 in the alphabet.
    """
    return _transform_shift(s, SHIFT)


def decode_shift(s: str) -> str:
    """
    Decode a string previously encoded with encode_shift.
    """
    return _transform_shift(s, -SHIFT)
candidate = decode_shift




METADATA = {}


def check(candidate):
    from random import randint, choice
    import copy
    import string

    letters = string.ascii_lowercase
    for _ in range(100):
        str = ''.join(choice(letters) for i in range(randint(10, 20)))
        encoded_str = encode_shift(str)
        assert candidate(copy.deepcopy(encoded_str)) == str



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
