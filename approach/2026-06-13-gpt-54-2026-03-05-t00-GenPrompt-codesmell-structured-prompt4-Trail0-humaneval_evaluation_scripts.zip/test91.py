
import unittest
import re
import sys
import math
import copy


import re


_SENTENCE_DELIMITER_PATTERN = re.compile(r"[.!?]")


def _split_sentences(text):
    """Split text into sentences using '.', '?' and '!' as delimiters."""
    return _SENTENCE_DELIMITER_PATTERN.split(text)


def _starts_with_i(sentence):
    """Return True if the sentence starts with the standalone word 'I'."""
    words = sentence.strip().split()
    return bool(words) and words[0] == "I"


def is_bored(S):
    """
    Count the number of sentences that start with the word "I".

    Sentences are delimited by '.', '?' or '!'.

    Examples:
    >>> is_bored("Hello world")
    0
    >>> is_bored("The sky is blue. The sun is shining. I love this weather")
    1
    """
    sentences = _split_sentences(S)
    return sum(1 for sentence in sentences if _starts_with_i(sentence))
candidate = is_bored


def check(candidate):

    # Check some simple cases
    assert candidate("Hello world") == 0, "Test 1"
    assert candidate("Is the sky blue?") == 0, "Test 2"
    assert candidate("I love It !") == 1, "Test 3"
    assert candidate("bIt") == 0, "Test 4"
    assert candidate("I feel good today. I will be productive. will kill It") == 2, "Test 5"
    assert candidate("You and I are going for a walk") == 0, "Test 6"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
