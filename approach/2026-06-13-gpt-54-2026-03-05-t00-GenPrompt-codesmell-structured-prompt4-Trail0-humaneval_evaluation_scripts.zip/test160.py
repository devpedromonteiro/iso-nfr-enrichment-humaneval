
import unittest
import re
import sys
import math
import copy


import operator as op
from typing import Callable, Dict, List


def _build_operator_map() -> Dict[str, Callable[[int, int], int]]:
    """Return the supported algebra operations."""
    return {
        "+": op.add,
        "-": op.sub,
        "*": op.mul,
        "//": op.floordiv,
        "**": op.pow,
    }


def _validate_inputs(operators: List[str], operands: List[int]) -> None:
    """Validate input structure and supported operators."""
    if len(operators) != len(operands) - 1:
        raise ValueError("The number of operators must be exactly one less than the number of operands.")

    if len(operators) < 1 or len(operands) < 2:
        raise ValueError("At least one operator and two operands are required.")

    supported = _build_operator_map()
    unsupported = [symbol for symbol in operators if symbol not in supported]
    if unsupported:
        raise ValueError(f"Unsupported operator(s): {', '.join(unsupported)}")


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and
    the second list is a list of integers. Use the two given lists to build the algebraic
    expression and return the evaluation of this expression.

    The basic algebra operations:
    Addition ( + )
    Subtraction ( - )
    Multiplication ( * )
    Floor division ( // )
    Exponentiation ( ** )

    Example:
    operator = ['+', '*', '-']
    operand = [2, 3, 4, 5]
    result = 2 + 3 * 4 - 5
    => result = 9

    Note:
        The length of operator list is equal to the length of operand list minus one.
        Operand is a list of non-negative integers.
        Operator list has at least one operator, and operand list has at least two operands.
    """
    _validate_inputs(operator, operand)

    expression = str(operand[0])
    for current_operator, current_operand in zip(operator, operand[1:]):
        expression += f" {current_operator} {current_operand}"

    return eval(expression)
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
