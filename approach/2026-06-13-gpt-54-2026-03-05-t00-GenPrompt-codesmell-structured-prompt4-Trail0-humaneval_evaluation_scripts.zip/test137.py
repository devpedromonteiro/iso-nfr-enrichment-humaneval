
import unittest
import re
import sys
import math
import copy


def _to_float(value):
    """Convert ints, floats, or numeric strings using '.' or ',' to float."""
    if isinstance(value, str):
        return float(value.replace(",", "."))
    return float(value)


def compare_one(a, b):
    """
    Return the larger original value between a and b.
    If both represent the same numeric value, return None.
    """
    a_num = _to_float(a)
    b_num = _to_float(b)

    if a_num == b_num:
        return None
    return a if a_num > b_num else b
candidate = compare_one


def check(candidate):

    # Check some simple cases
    assert candidate(1, 2) == 2
    assert candidate(1, 2.5) == 2.5
    assert candidate(2, 3) == 3
    assert candidate(5, 6) == 6
    assert candidate(1, "2,3") == "2,3"
    assert candidate("5,1", "6") == "6"
    assert candidate("1", "2") == "2"
    assert candidate("1", 1) == None

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
