
import unittest
import re
import sys
import math
import copy


def _factorial(value):
    result = 1
    for number in range(1, value + 1):
        result *= number
    return result


def _sum_to(value):
    return value * (value + 1) // 2


def _value_for_index(index):
    if index % 2 == 0:
        return _factorial(index)
    return _sum_to(index)


def f(n):
    """Return a list of size n based on 1-based index rules.

    For each index i from 1 to n:
    - if i is even, the value is i!
    - if i is odd, the value is the sum of numbers from 1 to i

    Example:
        f(5) == [1, 2, 6, 24, 15]
    """
    return [_value_for_index(index) for index in range(1, n + 1)]
candidate = f


def check(candidate):

    assert candidate(5) == [1, 2, 6, 24, 15]
    assert candidate(7) == [1, 2, 6, 24, 15, 720, 28]
    assert candidate(1) == [1]
    assert candidate(3) == [1, 2, 6]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
