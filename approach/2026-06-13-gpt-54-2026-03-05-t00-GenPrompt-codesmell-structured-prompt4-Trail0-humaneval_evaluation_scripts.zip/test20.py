
import unittest
import re
import sys
import math
import copy

from typing import List, Tuple


from typing import List, Tuple


def _validate_input(numbers: List[float]) -> None:
    if len(numbers) < 2:
        raise ValueError("numbers must contain at least two elements")


def _find_closest_in_sorted(sorted_numbers: List[float]) -> Tuple[float, float]:
    closest_pair = (sorted_numbers[0], sorted_numbers[1])
    smallest_difference = abs(sorted_numbers[1] - sorted_numbers[0])

    for index in range(1, len(sorted_numbers) - 1):
        left = sorted_numbers[index]
        right = sorted_numbers[index + 1]
        difference = abs(right - left)

        if difference < smallest_difference:
            smallest_difference = difference
            closest_pair = (left, right)

    return closest_pair


def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    """From a supplied list of numbers (of length at least two) select and return
    two that are the closest to each other and return them in order
    (smaller number, larger number).

    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.2])
    (2.0, 2.2)
    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.0])
    (2.0, 2.0)
    """
    _validate_input(numbers)
    sorted_numbers = sorted(numbers)
    return _find_closest_in_sorted(sorted_numbers)
candidate = find_closest_elements




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([1.0, 2.0, 3.9, 4.0, 5.0, 2.2]) == (3.9, 4.0)
    assert candidate([1.0, 2.0, 5.9, 4.0, 5.0]) == (5.0, 5.9)
    assert candidate([1.0, 2.0, 3.0, 4.0, 5.0, 2.2]) == (2.0, 2.2)
    assert candidate([1.0, 2.0, 3.0, 4.0, 5.0, 2.0]) == (2.0, 2.0)
    assert candidate([1.1, 2.2, 3.1, 4.1, 5.1]) == (2.2, 3.1)



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
