
import unittest
import re
import sys
import math
import copy


def _is_letter(char):
    return char.isalpha()


def _last_non_space_index(text):
    for index in range(len(text) - 1, -1, -1):
        if text[index] != " ":
            return index
    return -1


def check_if_last_char_is_a_letter(txt):
    """
    Return True if the last character of the string is a letter
    and forms a standalone one-letter word; otherwise return False.
    """
    if not txt or txt[-1] == " ":
        return False

    last_index = _last_non_space_index(txt)
    if last_index == -1:
        return False

    last_char = txt[last_index]
    if not _is_letter(last_char):
        return False

    if last_index == 0:
        return True

    return txt[last_index - 1] == " "
candidate = check_if_last_char_is_a_letter


def check(candidate):

    # Check some simple cases
    assert candidate("apple") == False
    assert candidate("apple pi e") == True
    assert candidate("eeeee") == False
    assert candidate("A") == True
    assert candidate("Pumpkin pie ") == False
    assert candidate("Pumpkin pie 1") == False
    assert candidate("") == False
    assert candidate("eeeee e ") == False
    assert candidate("apple pie") == False
    assert candidate("apple pi e ") == False

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
