
import unittest
import re
import sys
import math
import copy



def _validate_integer(value: int, name: str) -> None:
    """Validate that a value is an integer."""
    if not isinstance(value, int):
        raise TypeError(f"{name} must be an integer")


def _normalize_pair(a: int, b: int) -> tuple[int, int]:
    """Return absolute values for a pair of integers."""
    return abs(a), abs(b)


def greatest_common_divisor(a: int, b: int) -> int:
    """Return the greatest common divisor of two integers a and b.

    >>> greatest_common_divisor(3, 5)
    1
    >>> greatest_common_divisor(25, 15)
    5
    """
    _validate_integer(a, "a")
    _validate_integer(b, "b")

    a, b = _normalize_pair(a, b)

    while b != 0:
        a, b = b, a % b

    return a
candidate = greatest_common_divisor




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(3, 7) == 1
    assert candidate(10, 15) == 5
    assert candidate(49, 14) == 7
    assert candidate(144, 60) == 12


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
