
import unittest
import re
import sys
import math
import copy


def _is_even(value):
    return value % 2 == 0


def pluck(arr):
    """
    Given an array representing a branch of a tree that has non-negative integer nodes,
    return [smallest_even_value, index] for the smallest even value.
    If multiple equal smallest even values exist, return the one with the smallest index.
    If there are no even values or the array is empty, return [].
    """
    best_value = None
    best_index = -1

    for index, value in enumerate(arr):
        if _is_even(value) and (best_value is None or value < best_value):
            best_value = value
            best_index = index

    return [] if best_value is None else [best_value, best_index]
candidate = pluck


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([4,2,3]) == [2, 1], "Error"
    assert candidate([1,2,3]) == [2, 1], "Error"
    assert candidate([]) == [], "Error"
    assert candidate([5, 0, 3, 0, 4, 2]) == [0, 1], "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([1, 2, 3, 0, 5, 3]) == [0, 3], "Error"
    assert candidate([5, 4, 8, 4 ,8]) == [4, 1], "Error"
    assert candidate([7, 6, 7, 1]) == [6, 1], "Error"
    assert candidate([7, 9, 7, 1]) == [], "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
