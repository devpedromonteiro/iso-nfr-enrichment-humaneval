
import unittest
import re
import sys
import math
import copy


from collections import Counter


def _has_excessive_duplicates(lst):
    """Return True if any value appears more than twice."""
    counts = Counter(lst)
    return any(count > 2 for count in counts.values())


def _is_non_decreasing(lst):
    """Return True if the list is sorted in ascending non-decreasing order."""
    return all(current <= next_value for current, next_value in zip(lst, lst[1:]))


def is_sorted(lst):
    """
    Given a list of numbers, return whether or not they are sorted
    in ascending order. If a number appears more than twice, return False.
    Assume no negative numbers and only integers.
    """
    if _has_excessive_duplicates(lst):
        return False

    return _is_non_decreasing(lst)
candidate = is_sorted


def check(candidate):

    # Check some simple cases
    assert candidate([5]) == True
    assert candidate([1, 2, 3, 4, 5]) == True
    assert candidate([1, 3, 2, 4, 5]) == False
    assert candidate([1, 2, 3, 4, 5, 6]) == True
    assert candidate([1, 2, 3, 4, 5, 6, 7]) == True
    assert candidate([1, 3, 2, 4, 5, 6, 7]) == False, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([]) == True, "This prints if this assert fails 2 (good for debugging!)"
    assert candidate([1]) == True, "This prints if this assert fails 3 (good for debugging!)"
    assert candidate([3, 2, 1]) == False, "This prints if this assert fails 4 (good for debugging!)"
    
    # Check some edge cases that are easy to work out by hand.
    assert candidate([1, 2, 2, 2, 3, 4]) == False, "This prints if this assert fails 5 (good for debugging!)"
    assert candidate([1, 2, 3, 3, 3, 4]) == False, "This prints if this assert fails 6 (good for debugging!)"
    assert candidate([1, 2, 2, 3, 3, 4]) == True, "This prints if this assert fails 7 (good for debugging!)"
    assert candidate([1, 2, 3, 4]) == True, "This prints if this assert fails 8 (good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
