
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def _validate_binary_strings(a: str, b: str) -> None:
    """Validate that both inputs are binary strings of equal length."""
    if len(a) != len(b):
        raise ValueError("Inputs must have the same length.")
    if any(char not in {"0", "1"} for char in a):
        raise ValueError("First input must contain only '0' and '1'.")
    if any(char not in {"0", "1"} for char in b):
        raise ValueError("Second input must contain only '0' and '1'.")


def string_xor(a: str, b: str) -> str:
    """Input are two strings a and b consisting only of 1s and 0s.
    Perform binary XOR on these inputs and return result also as a string.

    >>> string_xor('010', '110')
    '100'
    """
    _validate_binary_strings(a, b)
    return "".join("1" if left != right else "0" for left, right in zip(a, b))
candidate = string_xor




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('111000', '101010') == '010010'
    assert candidate('1', '1') == '0'
    assert candidate('0101', '0000') == '0101'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
