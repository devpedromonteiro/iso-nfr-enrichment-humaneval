
import unittest
import re
import sys
import math
import copy



from typing import Iterable


def is_below_threshold(value: int, threshold: int) -> bool:
    """Return True if a single value is below the given threshold."""
    return value < threshold


def below_threshold(values: Iterable[int], threshold: int) -> bool:
    """Return True if all numbers in values are below threshold.

    >>> below_threshold([1, 2, 4, 10], 100)
    True
    >>> below_threshold([1, 20, 4, 10], 5)
    False
    """
    return all(is_below_threshold(value, threshold) for value in values)
candidate = below_threshold




METADATA = {}


def check(candidate):
    assert candidate([1, 2, 4, 10], 100)
    assert not candidate([1, 20, 4, 10], 5)
    assert candidate([1, 20, 4, 10], 21)
    assert candidate([1, 20, 4, 10], 22)
    assert candidate([1, 8, 4, 10], 11)
    assert not candidate([1, 8, 4, 10], 10)



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
