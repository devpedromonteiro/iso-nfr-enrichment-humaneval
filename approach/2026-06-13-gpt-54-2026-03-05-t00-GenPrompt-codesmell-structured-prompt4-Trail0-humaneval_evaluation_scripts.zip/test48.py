
import unittest
import re
import sys
import math
import copy



def _normalized_text(text: str) -> str:
    """Return the text in a normalized form for palindrome comparison."""
    return text.lower()


def is_palindrome(text: str) -> bool:
    """
    Check whether the given string is a palindrome.

    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    """
    normalized = _normalized_text(text)
    return normalized == normalized[::-1]
candidate = is_palindrome




METADATA = {}


def check(candidate):
    assert candidate('') == True
    assert candidate('aba') == True
    assert candidate('aaaaa') == True
    assert candidate('zbcd') == False
    assert candidate('xywyx') == True
    assert candidate('xywyz') == False
    assert candidate('xywzx') == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
