
import unittest
import re
import sys
import math
import copy



from typing import Any, List


def _third_index_values(items: List[Any]) -> List[Any]:
    """Return the values located at indices divisible by three."""
    return items[::3]


def _merge_third_index_values(items: List[Any], sorted_values: List[Any]) -> List[Any]:
    """Return a copy of items with values at indices divisible by three replaced."""
    result = list(items)
    result[::3] = sorted_values
    return result


def sort_third(items: List[Any]) -> List[Any]:
    """Return a copy of items where values at indices divisible by three are sorted.

    Elements at indices not divisible by three remain unchanged.

    >>> sort_third([1, 2, 3])
    [1, 2, 3]
    >>> sort_third([5, 6, 3, 4, 8, 9, 2])
    [2, 6, 3, 4, 8, 9, 5]
    """
    sorted_third_values = sorted(_third_index_values(items))
    return _merge_third_index_values(items, sorted_third_values)
candidate = sort_third




METADATA = {}


def check(candidate):
    assert tuple(candidate([1, 2, 3])) == tuple(sort_third([1, 2, 3]))
    assert tuple(candidate([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])) == tuple(sort_third([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10]))
    assert tuple(candidate([5, 8, -12, 4, 23, 2, 3, 11, 12, -10])) == tuple(sort_third([5, 8, -12, 4, 23, 2, 3, 11, 12, -10]))
    assert tuple(candidate([5, 6, 3, 4, 8, 9, 2])) == tuple([2, 6, 3, 4, 8, 9, 5])
    assert tuple(candidate([5, 8, 3, 4, 6, 9, 2])) == tuple([2, 8, 3, 4, 6, 9, 5])
    assert tuple(candidate([5, 6, 9, 4, 8, 3, 2])) == tuple([2, 6, 9, 4, 8, 3, 5])
    assert tuple(candidate([5, 6, 3, 4, 8, 9, 2, 1])) == tuple([2, 6, 3, 4, 8, 9, 5, 1])



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
