
import unittest
import re
import sys
import math
import copy



from typing import List, Sequence, TypeVar

T = TypeVar("T")


def _even_index_values(items: Sequence[T]) -> List[T]:
    """Return the values stored at even indices."""
    return list(items[::2])


def _merge_even_values(items: Sequence[T], sorted_even_values: Sequence[T]) -> List[T]:
    """Return a new list with sorted even-index values merged back in."""
    result = list(items)
    result[::2] = sorted_even_values
    return result


def sort_even(items: Sequence[T]) -> List[T]:
    """Return a copy of items where values at even indices are sorted.

    Values at odd indices remain unchanged.

    >>> sort_even([1, 2, 3])
    [1, 2, 3]
    >>> sort_even([5, 6, 3, 4])
    [3, 6, 5, 4]
    """
    sorted_even_values = sorted(_even_index_values(items))
    return _merge_even_values(items, sorted_even_values)
candidate = sort_even




METADATA = {}


def check(candidate):
    assert tuple(candidate([1, 2, 3])) == tuple([1, 2, 3])
    assert tuple(candidate([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])) == tuple([-10, 3, -5, 2, -3, 3, 5, 0, 9, 1, 123])
    assert tuple(candidate([5, 8, -12, 4, 23, 2, 3, 11, 12, -10])) == tuple([-12, 8, 3, 4, 5, 2, 12, 11, 23, -10])



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
