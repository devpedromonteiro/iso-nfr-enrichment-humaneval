
import unittest



def correct_bracketing(brackets: str) -> bool:
    """Return True if angle brackets are properly balanced.

    A string is correctly bracketed when:
    - every "<" has a matching ">"
    - no closing bracket appears before its matching opening bracket

    >>> correct_bracketing("<")
    False
    >>> correct_bracketing("<>")
    True
    >>> correct_bracketing("<<><>>")
    True
    >>> correct_bracketing("><<>")
    False
    """
    open_count = 0

    for bracket in brackets:
        if bracket == "<":
            open_count += 1
        elif bracket == ">":
            open_count -= 1

        if open_count < 0:
            return False

    return open_count == 0
candidate = correct_bracketing


class Test(unittest.TestCase):
    def test(self):
        assert candidate("<") == False
        assert candidate("<>") == True
        assert candidate("<><>>>><<") == False
        assert candidate("<>>>>>") == False
        assert candidate("<>>><<<") == False
        assert candidate(">><<>>>><<>>>>") == False
        assert candidate(">>>>><<") == False
        assert candidate("<<><>><<><>>") == True
        assert candidate(">><>><>") == False
        assert not candidate(">")
        assert candidate("<<><>><<><>><>") == True
        assert candidate("<><><<<><><>><>><<><><<>>>") == True
        assert candidate("<><><>") == True
        assert candidate("><<<><<<") == False
        assert candidate("<><><><<><>><>") == True
        assert candidate("<<<<<><>") == False
        assert candidate("<><><<><>><><><><<><>><><><><<><>><>") == True
        assert candidate("<>><>") == False
        assert candidate("><<<>>>>>>>><<><<") == False
        assert candidate(">>>><<><<<") == False
        assert not candidate("><<>")
        assert candidate("<><<><>>") == True
        assert candidate(">") == False
        assert candidate("<<<>") == False
        assert candidate(">><<<") == False
        assert candidate("><<><><>") == False
        assert candidate("<><>>>>><><>>><") == False
        assert candidate("<<><>><<><>><><><<<><><>><>><<><><<>>>") == True
        assert candidate(">>>") == False
        assert candidate("<>><<><<><><><>><>>") == False
        assert candidate(">><<<>><<<<><") == False
        assert candidate(">>>><<<<") == False
        assert candidate("<<<<>><<>") == False
        assert candidate("<>")
        assert candidate(">>>><<<>><><><>><<><") == False
        assert candidate("<><>") == True
        assert not candidate("<")
        assert candidate("") == True
        assert candidate("><<<>><>") == False
        assert candidate("<>>><>") == False
        assert candidate("<<<>><>><") == False
        assert candidate("><><>>") == False
        assert candidate("<>>><>>>>>><><<") == False
        assert candidate("<>>><<<>>>>>><><>><>") == False
        assert candidate("<><><<<><><>><>><<><><<>>>")
        assert candidate("<><<><>><><><<<><><>><>><<><><<>>>") == True
        assert candidate("<<<") == False
        assert candidate(">>><><><<<>><") == False
        assert candidate("<<><>><><><<<><><>><>><<><><<>>>") == True
        assert candidate("<<><>>") == True
        assert candidate("<><><<><>><><><><<><>><>") == True
        assert candidate("<><><<><>><>")
        assert candidate("><<<><") == False
        assert candidate("<><><<>>>><<<<<>") == False
        assert candidate(">><<><>>><><") == False
        assert candidate(">>><>>><") == False
        assert candidate("><><<><") == False
        assert candidate("><>>><<") == False
        assert candidate("<><><<><>><>") == True
        assert candidate("><<") == False
        assert candidate("<<><>>")
        assert candidate(">><>><><") == False
        assert candidate("><>><") == False
        assert candidate(">><") == False
        assert candidate("<><><<><>><><<><>>") == True
        assert candidate(">>><<<>><><<<>>><><") == False
        assert candidate("<<><>><><><<<><><>><>><<><><<>>><><><<><>><>") == True
        assert candidate("<<<>>") == False
        assert not candidate("<><><<><>><>><<>")
        assert not candidate("<<<<")
        assert candidate("<<><>><>") == True
        assert not candidate("<<>")
        assert candidate("><<><>>") == False
        assert candidate("><>>><<>>><<<") == False
        assert candidate("<<><>><<><>><><><<><>><>") == True
        assert candidate("<>><<><") == False
        assert candidate("<<><") == False
        assert not candidate("<><><<><>><>>><>")
        assert candidate("<>><<<<><><>><>") == False
        assert not candidate("<<<><>>>>")
        assert candidate(">>>><><<<>>") == False

if __name__ == '__main__':
    unittest.main()
