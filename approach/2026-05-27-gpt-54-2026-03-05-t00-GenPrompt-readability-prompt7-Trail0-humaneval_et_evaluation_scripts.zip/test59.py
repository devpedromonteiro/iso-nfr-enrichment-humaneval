
import unittest



def largest_prime_factor(n: int) -> int:
    """Return the largest prime factor of n.

    Assume n > 1 and n is not prime.

    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    largest_factor = None

    # Remove all factors of 2 first.
    while n % 2 == 0:
        largest_factor = 2
        n //= 2

    # Check odd factors from 3 upward.
    factor = 3
    while factor * factor <= n:
        while n % factor == 0:
            largest_factor = factor
            n //= factor
        factor += 2

    # If n is still greater than 1, then it is prime and larger than
    # any factor we have already found.
    if n > 1:
        largest_factor = n

    return largest_factor
candidate = largest_prime_factor


class Test(unittest.TestCase):
    def test(self):
        assert candidate(151744) == 2371
        assert candidate(69672) == 2903
        assert candidate(839908) == 209977
        assert candidate(72216) == 59
        assert candidate(93973) == 8543
        assert candidate(998782) == 499391
        assert candidate(546935) == 109387
        assert candidate(223751) == 20341
        assert candidate(27) == 3
        assert candidate(97767) == 71
        assert candidate(126162) == 163
        assert candidate(678495) == 45233
        assert candidate(178919) == 13763
        assert candidate(637083) == 997
        assert candidate(578015) == 115603
        assert candidate(606926) == 303463
        assert candidate(296792) == 1613
        assert candidate(48664) == 79
        assert candidate(688059) == 859
        assert candidate(44324) == 1583
        assert candidate(206158) == 103079
        assert candidate(330073) == 127
        assert candidate(780079) == 45887
        assert candidate(13195) == 29
        assert candidate(545017) == 49547
        assert candidate(679692) == 4357
        assert candidate(29458) == 103
        assert candidate(198874) == 7649
        assert candidate(375921) == 17
        assert candidate(982531) == 499
        assert candidate(884867) == 52051
        assert candidate(373143) == 4289
        assert candidate(293778) == 859
        assert candidate(441063) == 7001
        assert candidate(150069) == 50023
        assert candidate(440449) == 10243
        assert candidate(449137) == 34549
        assert candidate(852306) == 223
        assert candidate(148824) == 53
        assert candidate(508089) == 659
        assert candidate(351286) == 229
        assert candidate(669798) == 293
        assert candidate(858060) == 227
        assert candidate(17679) == 83
        assert candidate(51705) == 383
        assert candidate(950141) == 997
        assert candidate(965957) == 56821
        assert candidate(844600) == 103
        assert candidate(771453) == 85717
        assert candidate(330) == 11
        assert candidate(407634) == 67939
        assert candidate(193358) == 47
        assert candidate(979096) == 122387
        assert candidate(340468) == 1811
        assert candidate(892958) == 1097
        assert candidate(709317) == 139
        assert candidate(907624) == 113453
        assert candidate(695092) == 173773
        assert candidate(24895) == 383
        assert candidate(325256) == 373
        assert candidate(399148) == 99787
        assert candidate(249886) == 1373
        assert candidate(647418) == 107903
        assert candidate(88102) == 31
        assert candidate(93186) == 167
        assert candidate(107904) == 281
        assert candidate(699315) == 2027
        assert candidate(340173) == 293
        assert candidate(15) == 5
        assert candidate(2031) == 677
        assert candidate(349383) == 116461
        assert candidate(132848) == 23
        assert candidate(861210) == 1367
        assert candidate(858476) == 1367
        assert candidate(371221) == 127
        assert candidate(717088) == 22409
        assert candidate(82876) == 20719
        assert candidate(910738) == 691
        assert candidate(233109) == 439
        assert candidate(677005) == 29
        assert candidate(683441) == 62131
        assert candidate(829820) == 41491
        assert candidate(915097) == 48163
        assert candidate(789018) == 1229
        assert candidate(759955) == 21713
        assert candidate(715348) == 4159
        assert candidate(676882) == 3163
        assert candidate(959669) == 701
        assert candidate(208046) == 211
        assert candidate(203475) == 2713
        assert candidate(155409) == 51803
        assert candidate(21993) == 7331
        assert candidate(118164) == 229
        assert candidate(382340) == 2731
        assert candidate(901758) == 1051
        assert candidate(690588) == 19183
        assert candidate(512631) == 103
        assert candidate(754917) == 251639
        assert candidate(801190) == 6163
        assert candidate(93473) == 443
        assert candidate(242695) == 48539
        assert candidate(94230) == 349
        assert candidate(397777) == 5449
        assert candidate(962149) == 56597
        assert candidate(63) == 7

if __name__ == '__main__':
    unittest.main()
