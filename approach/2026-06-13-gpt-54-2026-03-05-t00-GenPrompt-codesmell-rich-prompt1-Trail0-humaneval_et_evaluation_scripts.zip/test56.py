
import unittest



def _update_balance(balance: int, bracket: str) -> int:
    """Return the updated balance after processing one bracket."""
    if bracket == "<":
        return balance + 1
    return balance - 1


def _is_invalid_balance(balance: int) -> bool:
    """Return True when the running balance indicates invalid bracketing."""
    return balance < 0


def correct_bracketing(brackets: str) -> bool:
    """brackets is a string of "<" and ">".
    return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("<")
    False
    >>> correct_bracketing("<>")
    True
    >>> correct_bracketing("<<><>>")
    True
    >>> correct_bracketing("><<>")
    False
    """
    balance = 0

    for bracket in brackets:
        balance = _update_balance(balance, bracket)
        if _is_invalid_balance(balance):
            return False

    return balance == 0
candidate = correct_bracketing


class Test(unittest.TestCase):
    def test(self):
        assert candidate("<") == False
        assert candidate("<>") == True
        assert candidate("<><>>>><<") == False
        assert candidate("<>>>>>") == False
        assert candidate("<>>><<<") == False
        assert candidate(">><<>>>><<>>>>") == False
        assert candidate(">>>>><<") == False
        assert candidate("<<><>><<><>>") == True
        assert candidate(">><>><>") == False
        assert not candidate(">")
        assert candidate("<<><>><<><>><>") == True
        assert candidate("<><><<<><><>><>><<><><<>>>") == True
        assert candidate("<><><>") == True
        assert candidate("><<<><<<") == False
        assert candidate("<><><><<><>><>") == True
        assert candidate("<<<<<><>") == False
        assert candidate("<><><<><>><><><><<><>><><><><<><>><>") == True
        assert candidate("<>><>") == False
        assert candidate("><<<>>>>>>>><<><<") == False
        assert candidate(">>>><<><<<") == False
        assert not candidate("><<>")
        assert candidate("<><<><>>") == True
        assert candidate(">") == False
        assert candidate("<<<>") == False
        assert candidate(">><<<") == False
        assert candidate("><<><><>") == False
        assert candidate("<><>>>>><><>>><") == False
        assert candidate("<<><>><<><>><><><<<><><>><>><<><><<>>>") == True
        assert candidate(">>>") == False
        assert candidate("<>><<><<><><><>><>>") == False
        assert candidate(">><<<>><<<<><") == False
        assert candidate(">>>><<<<") == False
        assert candidate("<<<<>><<>") == False
        assert candidate("<>")
        assert candidate(">>>><<<>><><><>><<><") == False
        assert candidate("<><>") == True
        assert not candidate("<")
        assert candidate("") == True
        assert candidate("><<<>><>") == False
        assert candidate("<>>><>") == False
        assert candidate("<<<>><>><") == False
        assert candidate("><><>>") == False
        assert candidate("<>>><>>>>>><><<") == False
        assert candidate("<>>><<<>>>>>><><>><>") == False
        assert candidate("<><><<<><><>><>><<><><<>>>")
        assert candidate("<><<><>><><><<<><><>><>><<><><<>>>") == True
        assert candidate("<<<") == False
        assert candidate(">>><><><<<>><") == False
        assert candidate("<<><>><><><<<><><>><>><<><><<>>>") == True
        assert candidate("<<><>>") == True
        assert candidate("<><><<><>><><><><<><>><>") == True
        assert candidate("<><><<><>><>")
        assert candidate("><<<><") == False
        assert candidate("<><><<>>>><<<<<>") == False
        assert candidate(">><<><>>><><") == False
        assert candidate(">>><>>><") == False
        assert candidate("><><<><") == False
        assert candidate("><>>><<") == False
        assert candidate("<><><<><>><>") == True
        assert candidate("><<") == False
        assert candidate("<<><>>")
        assert candidate(">><>><><") == False
        assert candidate("><>><") == False
        assert candidate(">><") == False
        assert candidate("<><><<><>><><<><>>") == True
        assert candidate(">>><<<>><><<<>>><><") == False
        assert candidate("<<><>><><><<<><><>><>><<><><<>>><><><<><>><>") == True
        assert candidate("<<<>>") == False
        assert not candidate("<><><<><>><>><<>")
        assert not candidate("<<<<")
        assert candidate("<<><>><>") == True
        assert not candidate("<<>")
        assert candidate("><<><>>") == False
        assert candidate("><>>><<>>><<<") == False
        assert candidate("<<><>><<><>><><><<><>><>") == True
        assert candidate("<>><<><") == False
        assert candidate("<<><") == False
        assert not candidate("<><><<><>><>>><>")
        assert candidate("<>><<<<><><>><>") == False
        assert not candidate("<<<><>>>>")
        assert candidate(">>>><><<<>>") == False

if __name__ == '__main__':
    unittest.main()
