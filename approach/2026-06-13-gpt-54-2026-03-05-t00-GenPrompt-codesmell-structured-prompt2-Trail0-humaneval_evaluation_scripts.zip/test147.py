
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    You are given a positive integer n. You have to create an integer array a of length n.
    For each i (1 â¤ i â¤ n), the value of a[i] = i * i - i + 1.
    Return the number of triples (a[i], a[j], a[k]) where i < j < k and
    a[i] + a[j] + a[k] is a multiple of 3.

    Example:
        Input: n = 5
        Output: 1
    """

    def combination_count(count, size):
        if count < size:
            return 0
        if size == 2:
            return count * (count - 1) // 2
        if size == 3:
            return count * (count - 1) * (count - 2) // 6
        raise ValueError("Unsupported combination size")

    def count_indices_by_remainder(limit):
        remainder_counts = [0, 0, 0]
        for i in range(1, limit + 1):
            value_remainder = (i * i - i + 1) % 3
            remainder_counts[value_remainder] += 1
        return remainder_counts

    counts = count_indices_by_remainder(n)
    count_rem_0, count_rem_1, count_rem_2 = counts

    valid_triples = 0

    valid_triples += combination_count(count_rem_0, 3)
    valid_triples += combination_count(count_rem_1, 3)
    valid_triples += combination_count(count_rem_2, 3)
    valid_triples += count_rem_0 * count_rem_1 * count_rem_2

    return valid_triples
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
