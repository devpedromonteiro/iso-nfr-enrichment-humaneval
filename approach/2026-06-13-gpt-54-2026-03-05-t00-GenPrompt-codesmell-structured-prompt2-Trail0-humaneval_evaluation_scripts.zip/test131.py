
import unittest
import re
import sys
import math
import copy


def digits(n):
    """Given a positive integer n, return the product of the odd digits.
    Return 0 if all digits are even.

    For example:
    digits(1) == 1
    digits(4) == 0
    digits(235) == 15
    """
    odd_digits = _extract_odd_digits(n)
    return _product(odd_digits) if odd_digits else 0


def _extract_odd_digits(n):
    """Return a list of odd digits found in n."""
    return [int(char) for char in str(n) if int(char) % 2 == 1]


def _product(values):
    """Return the product of the given iterable of integers."""
    result = 1
    for value in values:
        result *= value
    return result
candidate = digits


def check(candidate):

    # Check some simple cases
    assert candidate(5) == 5
    assert candidate(54) == 5
    assert candidate(120) ==1
    assert candidate(5014) == 5
    assert candidate(98765) == 315
    assert candidate(5576543) == 2625

    # Check some edge cases that are easy to work out by hand.
    assert candidate(2468) == 0



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
