
import unittest
import re
import sys
import math
import copy


def _is_prime(n):
    """Return True if n is a prime number, otherwise False."""
    if n < 2:
        return False
    if n == 2:
        return True
    if n % 2 == 0:
        return False

    divisor = 3
    while divisor * divisor <= n:
        if n % divisor == 0:
            return False
        divisor += 2
    return True


def _prime_factors_with_multiplicity(n):
    """Return the prime factors of n, including repeated factors."""
    factors = []
    divisor = 2

    while divisor * divisor <= n:
        while n % divisor == 0:
            factors.append(divisor)
            n //= divisor
        divisor = 3 if divisor == 2 else divisor + 2

    if n > 1:
        factors.append(n)

    return factors


def is_multiply_prime(a):
    """Return True if a is the product of exactly 3 prime numbers, else False.

    Prime factors are counted with multiplicity, so:
    8 = 2 * 2 * 2 -> True
    12 = 2 * 2 * 3 -> True
    30 = 2 * 3 * 5 -> True
    """
    if a < 2:
        return False

    factors = _prime_factors_with_multiplicity(a)
    return len(factors) == 3 and all(_is_prime(factor) for factor in factors)
candidate = is_multiply_prime


def check(candidate):

    assert candidate(5) == False
    assert candidate(30) == True
    assert candidate(8) == True
    assert candidate(10) == False
    assert candidate(125) == True
    assert candidate(3 * 5 * 7) == True
    assert candidate(3 * 6 * 7) == False
    assert candidate(9 * 9 * 9) == False
    assert candidate(11 * 9 * 9) == False
    assert candidate(11 * 13 * 7) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
