
import unittest
import re
import sys
import math
import copy


def do_algebra(operator, operand):
    """
    Given two lists operator and operand, build the algebraic expression they represent
    and return its evaluated result using normal Python operator precedence.

    Supported operators:
        +   Addition
        -   Subtraction
        *   Multiplication
        //  Floor division
        **  Exponentiation
    """
    expression = _build_expression(operator, operand)
    return eval(expression)


def _build_expression(operators, operands):
    """Create an infix expression string from operators and operands."""
    expression_parts = [str(operands[0])]

    for op, value in zip(operators, operands[1:]):
        expression_parts.append(op)
        expression_parts.append(str(value))

    return " ".join(expression_parts)
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
