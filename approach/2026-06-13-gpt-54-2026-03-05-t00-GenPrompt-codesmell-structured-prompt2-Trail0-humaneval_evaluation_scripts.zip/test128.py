
import unittest
import re
import sys
import math
import copy


def _sign_product(values):
    """Return the product of the signs of all integers in values."""
    product = 1
    for value in values:
        if value == 0:
            return 0
        if value < 0:
            product *= -1
    return product


def _sum_of_magnitudes(values):
    """Return the sum of absolute values in values."""
    return sum(abs(value) for value in values)


def prod_signs(arr):
    """
    You are given an array arr of integers and you need to return
    sum of magnitudes of integers multiplied by product of all signs
    of each number in the array, represented by 1, -1 or 0.
    Note: return None for empty arr.

    Example:
    >>> prod_signs([1, 2, 2, -4]) == -9
    True
    >>> prod_signs([0, 1]) == 0
    True
    >>> prod_signs([]) is None
    True
    """
    if not arr:
        return None

    return _sum_of_magnitudes(arr) * _sign_product(arr)
candidate = prod_signs


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1, 2, 2, -4]) == -9
    assert candidate([0, 1]) == 0
    assert candidate([1, 1, 1, 2, 3, -1, 1]) == -10
    assert candidate([]) == None
    assert candidate([2, 4,1, 2, -1, -1, 9]) == 20
    assert candidate([-1, 1, -1, 1]) == 4
    assert candidate([-1, 1, 1, 1]) == -4
    assert candidate([-1, 1, 1, 0]) == 0

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
