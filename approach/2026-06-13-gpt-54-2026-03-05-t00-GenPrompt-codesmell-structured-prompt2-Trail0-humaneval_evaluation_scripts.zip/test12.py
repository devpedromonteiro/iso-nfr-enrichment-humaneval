
import unittest
import re
import sys
import math
import copy

from typing import List, Optional


from typing import List, Optional


def _is_better_candidate(current: str, best: Optional[str]) -> bool:
    """Return True if current should replace best as the longest string."""
    return best is None or len(current) > len(best)


def longest(strings: List[str]) -> Optional[str]:
    """Out of a list of strings, return the longest one.

    Return the first one in case of multiple strings of the same length.
    Return None if the input list is empty.

    >>> longest([])
    >>> longest(['a', 'b', 'c'])
    'a'
    >>> longest(['a', 'bb', 'ccc'])
    'ccc'
    """
    longest_string: Optional[str] = None

    for current in strings:
        if _is_better_candidate(current, longest_string):
            longest_string = current

    return longest_string
candidate = longest




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == None
    assert candidate(['x', 'y', 'z']) == 'x'
    assert candidate(['x', 'yyy', 'zzzz', 'www', 'kkkk', 'abc']) == 'zzzz'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
