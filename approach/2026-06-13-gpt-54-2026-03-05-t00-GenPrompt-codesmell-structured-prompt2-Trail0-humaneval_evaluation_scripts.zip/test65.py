
import unittest
import re
import sys
import math
import copy


def _normalize_digits(x):
    """Return the digit string for x."""
    return str(x)


def _reverse_digits(digits):
    """Return the reversed digit string."""
    return digits[::-1]


def _rotate_right(digits, shift):
    """Return digits circularly shifted right by shift."""
    length = len(digits)
    if length == 0:
        return digits

    normalized_shift = shift % length
    if normalized_shift == 0:
        return digits

    return digits[-normalized_shift:] + digits[:-normalized_shift]


def circular_shift(x, shift):
    """Circular shift the digits of the integer x, shift the digits right by shift
    and return the result as a string.
    If shift > number of digits, return digits reversed.

    >>> circular_shift(12, 1)
    '21'
    >>> circular_shift(12, 2)
    '12'
    """
    digits = _normalize_digits(x)

    if shift > len(digits):
        return _reverse_digits(digits)

    return _rotate_right(digits, shift)
candidate = circular_shift


def check(candidate):

    # Check some simple cases
    assert candidate(100, 2) == "001"
    assert candidate(12, 2) == "12"
    assert candidate(97, 8) == "79"
    assert candidate(12, 1) == "21", "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(11, 101) == "11", "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
