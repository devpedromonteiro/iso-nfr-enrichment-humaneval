
import unittest
import re
import sys
import math
import copy


import re


def _extract_fruit_counts(description):
    """Extract apple and orange counts from the input description."""
    numbers = [int(value) for value in re.findall(r"\d+", description)]
    apples, oranges = numbers
    return apples, oranges


def fruit_distribution(s, n):
    """
    Return the number of mangoes in the basket.

    The input string contains the counts of apples and oranges, and `n`
    is the total number of fruits in the basket.
    """
    apples, oranges = _extract_fruit_counts(s)
    return n - apples - oranges
candidate = fruit_distribution


def check(candidate):

    # Check some simple cases
    assert candidate("5 apples and 6 oranges",19) == 8
    assert candidate("5 apples and 6 oranges",21) == 10
    assert candidate("0 apples and 1 oranges",3) == 2
    assert candidate("1 apples and 0 oranges",3) == 2
    assert candidate("2 apples and 3 oranges",100) == 95
    assert candidate("2 apples and 3 oranges",5) == 0
    assert candidate("1 apples and 100 oranges",120) == 19


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
