
import unittest
import re
import sys
import math
import copy



def _unique_items(items: list) -> set:
    """Return unique elements from a list as a set."""
    return set(items)


def _sorted_intersection(left: set, right: set) -> list:
    """Return the sorted intersection of two sets."""
    return sorted(left & right)


def common(l1: list, l2: list):
    """Return sorted unique common elements for two lists.
    >>> common([1, 4, 3, 34, 653, 2, 5], [5, 7, 1, 5, 9, 653, 121])
    [1, 5, 653]
    >>> common([5, 3, 2, 8], [3, 2])
    [2, 3]

    """
    left_unique = _unique_items(l1)
    right_unique = _unique_items(l2)
    return _sorted_intersection(left_unique, right_unique)
candidate = common




METADATA = {}


def check(candidate):
    assert candidate([1, 4, 3, 34, 653, 2, 5], [5, 7, 1, 5, 9, 653, 121]) == [1, 5, 653]
    assert candidate([5, 3, 2, 8], [3, 2]) == [2, 3]
    assert candidate([4, 3, 2, 8], [3, 2, 4]) == [2, 3, 4]
    assert candidate([4, 3, 2, 8], []) == []



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
