
import unittest
import re
import sys
import math
import copy


def valid_date(date):
    """Validate a date string in mm-dd-yyyy format."""
    if not date:
        return False

    parts = _split_date_parts(date)
    if parts is None:
        return False

    month, day, year = parts

    if not _is_valid_month(month):
        return False

    return _is_valid_day(month, day)


def _split_date_parts(date_string):
    """Split and validate the basic date format."""
    parts = date_string.split("-")
    if len(parts) != 3:
        return None

    month_str, day_str, year_str = parts

    if not (month_str.isdigit() and day_str.isdigit() and year_str.isdigit()):
        return None

    if len(month_str) != 2 or len(day_str) != 2 or len(year_str) != 4:
        return None

    return int(month_str), int(day_str), int(year_str)


def _is_valid_month(month):
    """Check whether the month is within the valid range."""
    return 1 <= month <= 12


def _is_valid_day(month, day):
    """Check whether the day is valid for the given month."""
    if day < 1:
        return False

    max_days_by_month = {
        1: 31, 2: 29, 3: 31, 4: 30,
        5: 31, 6: 30, 7: 31, 8: 31,
        9: 30, 10: 31, 11: 30, 12: 31,
    }

    return day <= max_days_by_month[month]
candidate = valid_date


def check(candidate):

    # Check some simple cases
    assert candidate('03-11-2000') == True

    assert candidate('15-01-2012') == False

    assert candidate('04-0-2040') == False

    assert candidate('06-04-2020') == True

    assert candidate('01-01-2007') == True

    assert candidate('03-32-2011') == False

    assert candidate('') == False

    assert candidate('04-31-3000') == False

    assert candidate('06-06-2005') == True

    assert candidate('21-31-2000') == False

    assert candidate('04-12-2003') == True

    assert candidate('04122003') == False

    assert candidate('20030412') == False

    assert candidate('2003-04') == False

    assert candidate('2003-04-12') == False

    assert candidate('04-2003') == False


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
