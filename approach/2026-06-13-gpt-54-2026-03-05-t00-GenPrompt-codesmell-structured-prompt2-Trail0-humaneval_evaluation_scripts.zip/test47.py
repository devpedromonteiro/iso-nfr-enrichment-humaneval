
import unittest
import re
import sys
import math
import copy



from typing import Sequence, Union

Number = Union[int, float]


def _sorted_values(values: Sequence[Number]) -> list[Number]:
    """Return a sorted copy of the input values."""
    return sorted(values)


def _middle_index(length: int) -> int:
    """Return the middle index for a sequence length."""
    return length // 2


def _validate_non_empty(values: Sequence[Number]) -> None:
    """Ensure the input sequence is not empty."""
    if not values:
        raise ValueError("median() arg is an empty sequence")


def median(values: Sequence[Number]) -> Number:
    """Return median of elements in the sequence values.

    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    8.0
    """
    _validate_non_empty(values)
    sorted_values = _sorted_values(values)
    length = len(sorted_values)
    mid = _middle_index(length)

    if length % 2 == 1:
        return sorted_values[mid]

    return (sorted_values[mid - 1] + sorted_values[mid]) / 2
candidate = median




METADATA = {}


def check(candidate):
    assert candidate([3, 1, 2, 4, 5]) == 3
    assert candidate([-10, 4, 6, 1000, 10, 20]) == 8.0
    assert candidate([5]) == 5
    assert candidate([6, 5]) == 5.5
    assert candidate([8, 1, 3, 9, 9, 2, 7]) == 7 



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
