
import unittest
import re
import sys
import math
import copy



def _is_match_at(string: str, substring: str, start: int) -> bool:
    return string[start:start + len(substring)] == substring


def how_many_times(string: str, substring: str) -> int:
    """Find how many times a given substring can be found in the original string.

    Overlapping cases are counted.

    >>> how_many_times('', 'a')
    0
    >>> how_many_times('aaa', 'a')
    3
    >>> how_many_times('aaaa', 'aa')
    3
    """
    if not string or not substring or len(substring) > len(string):
        return 0

    match_count = 0
    last_start_index = len(string) - len(substring)

    for start_index in range(last_start_index + 1):
        if _is_match_at(string, substring, start_index):
            match_count += 1

    return match_count
candidate = how_many_times




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('', 'x') == 0
    assert candidate('xyxyxyx', 'x') == 4
    assert candidate('cacacacac', 'cac') == 4
    assert candidate('john doe', 'john') == 1


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
