
import unittest
import re
import sys
import math
import copy



def _validate_base(base: int) -> None:
    if not isinstance(base, int):
        raise TypeError("base must be an integer")
    if base < 2 or base >= 10:
        raise ValueError("base must be between 2 and 9")


def _validate_number(x: int) -> None:
    if not isinstance(x, int):
        raise TypeError("x must be an integer")
    if x < 0:
        raise ValueError("x must be non-negative")


def _convert_positive_number(x: int, base: int) -> str:
    digits = []
    while x > 0:
        x, remainder = divmod(x, base)
        digits.append(str(remainder))
    return "".join(reversed(digits))


def change_base(x: int, base: int) -> str:
    """Change numerical base of input number x to base.
    Return string representation after the conversion.
    Base numbers are less than 10.

    >>> change_base(8, 3)
    '22'
    >>> change_base(8, 2)
    '1000'
    >>> change_base(7, 2)
    '111'
    """
    _validate_number(x)
    _validate_base(base)

    if x == 0:
        return "0"

    return _convert_positive_number(x, base)
candidate = change_base




METADATA = {}


def check(candidate):
    assert candidate(8, 3) == "22"
    assert candidate(9, 3) == "100"
    assert candidate(234, 2) == "11101010"
    assert candidate(16, 2) == "10000"
    assert candidate(8, 2) == "1000"
    assert candidate(7, 2) == "111"
    for x in range(2, 8):
        assert candidate(x, x + 1) == str(x)



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
