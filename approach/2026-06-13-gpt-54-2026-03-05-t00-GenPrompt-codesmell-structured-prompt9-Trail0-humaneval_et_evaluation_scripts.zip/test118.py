
import unittest


def get_closest_vowel(word):
    """Return the rightmost vowel that is between two consonants.

    A vowel qualifies only if:
    - it is not the first or last character
    - the characters immediately before and after it are consonants

    The function is case sensitive and assumes `word` contains only English letters.
    Returns an empty string if no such vowel exists.
    """
    vowels = {"a", "e", "i", "o", "u", "A", "E", "I", "O", "U"}

    def is_vowel(char):
        return char in vowels

    for index in range(len(word) - 2, 0, -1):
        if (
            is_vowel(word[index])
            and not is_vowel(word[index - 1])
            and not is_vowel(word[index + 1])
        ):
            return word[index]

    return ""
candidate = get_closest_vowel


class Test(unittest.TestCase):
    def test(self):
        assert candidate("tGFYIJD") == 'I'
        assert candidate("trngs") == ''
        assert candidate("ypwdlj") == ''
        assert candidate("cpizmgbr") == 'i'
        assert candidate("arvowxo") == 'o'
        assert candidate("fvoq") == 'o'
        assert candidate("BBZVid") == 'i'
        assert candidate("rfsnzbkwn") == ''
        assert candidate("ahfahd") == 'a'
        assert candidate("vqjo") == ''
        assert candidate("fJBfZSo") == ''
        assert candidate("RGdufA") == 'u'
        assert candidate("rebqcy") == 'e'
        assert candidate("asl") == ''
        assert candidate("hxzbb") == ''
        assert candidate("akfpd") == ''
        assert candidate("tujwth") == 'u'
        assert candidate("zbakq") == 'a'
        assert candidate("avhsz") == ''
        assert candidate("slvlbltbj") == ''
        assert candidate("zlptf") == ''
        assert candidate("bijAZ") == 'A'
        assert candidate("YsSJU") == ''
        assert candidate("QtM") == ''
        assert candidate("kgobnd") == 'o'
        assert candidate("yfin") == 'i'
        assert candidate("NDZBuU") == ''
        assert candidate("IBDJnJR") == ''
        assert candidate("qloyeb") == 'e'
        assert candidate("vaylznipp") == 'i'
        assert candidate("kobcedy") == 'e'
        assert candidate("nohi") == 'o'
        assert candidate("bqvhubae") == 'u'
        assert candidate("fvpsdx") == ''
        assert candidate("xarlcy") == 'a'
        assert candidate("qhceuv") == ''
        assert candidate("anime") == "i"
        assert candidate("ewatt") == 'a'
        assert candidate("bad") == "a"
        assert candidate("hqwgwnkhe") == ''
        assert candidate("ohueb") == ''
        assert candidate("euy") == ''
        assert candidate("xuyq") == 'u'
        assert candidate("ngvqt") == ''
        assert candidate("zDdxS") == ''
        assert candidate("yqd") == ''
        assert candidate("nzxphpwl") == ''
        assert candidate("iyjwtc") == ''
        assert candidate("yogurt") == "u"
        assert candidate("tltqbsfli") == ''
        assert candidate("itkzagrua") == 'a'
        assert candidate("oaznwzxb") == ''
        assert candidate("rvkg") == ''
        assert candidate("izhnynh") == ''
        assert candidate("gwtghbzzs") == ''
        assert candidate("easy") == ""
        assert candidate("nMzDyoquX") == 'u'
        assert candidate("jwr") == ''
        assert candidate("ewmwa") == ''
        assert candidate("fqE") == ''
        assert candidate("ogzv") == ''
        assert candidate("tngyskv") == ''
        assert candidate("tcjfrktu") == ''
        assert candidate("ijhvpy") == ''
        assert candidate("EpyvaZNy") == 'a'
        assert candidate("jlqd") == ''
        assert candidate("taQosTDF") == 'o'
        assert candidate("hxzrg") == ''
        assert candidate("mjha") == ''
        assert candidate("Asia") == ""
        assert candidate("wBPWktE") == ''
        assert candidate("Above") == "o"

    # Check some edge cases that are easy to work out by hand.
        assert candidate("ali") == ""
        assert candidate("jjdw") == ''
        assert candidate("WRVxzZb") == ''
        assert candidate("ycr") == ''
        assert candidate("sapndx") == 'a'
        assert candidate("bqrdgn") == ''
        assert candidate("ljibidugfgah") == 'a'
        assert candidate("full") == "u"
        assert candidate("vzl") == ''
        assert candidate("evw") == ''
        assert candidate("dug") == 'u'
        assert candidate("KxRfZv") == ''
        assert candidate("leneu") == 'e'
        assert candidate("hwqcb") == ''
        assert candidate("nai") == ''
        assert candidate("jebrugbg") == 'u'
        assert candidate("gmfvvxa") == ''
        assert candidate("xzyoqy") == 'o'
        assert candidate("kijxmjxy") == 'i'
        assert candidate("quick") == ""
        assert candidate("noyfmt") == 'o'
        assert candidate("ffvtklifh") == 'i'
        assert candidate("ehumjln") == 'u'
        assert candidate("skrikqwb") == 'i'
        assert candidate("moh") == 'o'
        assert candidate("cybl") == ''
        assert candidate("lbvxaaupz") == ''
        assert candidate("ab") == ""
        assert candidate("most") == "o"
        assert candidate("wsqyq") == ''
        assert candidate("rnrucalo") == 'a'
        assert candidate("ptbz") == ''
        assert candidate("ziTTVi") == 'i'
        assert candidate("tkjdeq") == 'e'
        assert candidate("hly") == ''
        assert candidate("sunhxtb") == 'u'
        assert candidate("btazqrg") == 'a'
        assert candidate("ocfsalgno") == 'a'
        assert candidate("fttpojb") == 'o'
        assert candidate("eAsy") == ""
        assert candidate("miNITNc") == 'I'
        assert candidate("DBpemZx") == 'e'
        assert candidate("wmxdyhz") == ''
        assert candidate("jHHWPTONQ") == 'O'
        assert candidate("mGea") == ''
        assert candidate("IzAIgi") == ''
        assert candidate("usxeqslh") == 'e'
        assert candidate("xsytk") == ''
        assert candidate("vNdzcFb") == ''
        assert candidate("lwwcnln") == ''
        assert candidate("qqIV") == 'I'
        assert candidate("ba") == ""
        assert candidate("fjbilzo") == 'i'
        assert candidate("hphfdo") == ''
        assert candidate("lsmrpkds") == ''
        assert candidate("ufqt") == ''
        assert candidate("FjDlDoF") == 'o'
        assert candidate("KlVgMzEdK") == 'E'

if __name__ == '__main__':
    unittest.main()
