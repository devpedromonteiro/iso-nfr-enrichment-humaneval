
import unittest


def _count_ones(value):
    """Return the number of ones in the binary representation of value."""
    return bin(value).count("1")


def _sort_key(value):
    """Build the sorting key: first by bit count, then by numeric value."""
    return _count_ones(value), value


def sort_array(arr):
    """
    Sort an array by the number of ones in the binary representation of each value.
    For equal bit counts, sort by decimal value in ascending order.

    Examples:
    >>> sort_array([1, 5, 2, 3, 4])
    [1, 2, 3, 4, 5]
    >>> sort_array([-2, -3, -4, -5, -6])
    [-6, -5, -4, -3, -2]
    >>> sort_array([1, 0, 2, 3, 4])
    [0, 1, 2, 3, 4]
    """
    return sorted(arr, key=_sort_key)
candidate = sort_array


class Test(unittest.TestCase):
    def test(self):
        assert candidate([4, 1, 45, 10, 30, 7]) == [1, 4, 10, 7, 30, 45]
        assert candidate([4, 2, 6, 15, 30]) == [2, 4, 6, 15, 30]
        assert candidate([4, 10, 1, 5, 2]) == [1, 2, 4, 5, 10]
        assert candidate([2, 3, 5, 5, 4]) == [2, 4, 3, 5, 5]
        assert candidate([4, 9, 13, 13, 27]) == [4, 9, 13, 13, 27]
        assert candidate([2, 3, 12, 20, 36]) == [2, 3, 12, 20, 36]
        assert candidate([3, 3, 5, 4, 8]) == [4, 8, 3, 3, 5]
        assert candidate([3, 10, 1, 4, 7]) == [1, 4, 3, 10, 7]
        assert candidate([1, 1, 47, 13, 30, 3]) == [1, 1, 3, 13, 30, 47]
        assert candidate([5, 7, 10, 21, 34]) == [5, 10, 34, 7, 21]
        assert candidate([-4, -7, 0, -9, -1]) == [0, -4, -1, -9, -7]
        assert candidate([7, 4, 46, 10, 29, 7]) == [4, 10, 7, 7, 29, 46]
        assert candidate([6, 7, 5, 6, 4]) == [4, 5, 6, 6, 7]
        assert candidate([6, 4, 13, 13, 29]) == [4, 6, 13, 13, 29]
        assert candidate([2, 6, 1, 5, 9]) == [1, 2, 5, 6, 9]
        assert candidate([2,5,77,4,5,3,5,7,2,3,4]) == [2, 2, 4, 4, 3, 3, 5, 5, 5, 7, 77]
        assert candidate([-6, -5, -5, -6, -6]) == [-6, -6, -6, -5, -5]
        assert candidate([4, 4, 7, 17, 31]) == [4, 4, 17, 7, 31]
        assert candidate([3, 4, 2, 1, 3]) == [1, 2, 4, 3, 3]
        assert candidate([2,4,8,16,32]) == [2, 4, 8, 16, 32]
        assert candidate([3, -4, -9, 0, -5]) == [0, -4, -9, -5, 3]
        assert candidate([4, 1, 46, 14, 34, 9]) == [1, 4, 9, 34, 14, 46]
        assert candidate([4, 8, 3, 21, 29]) == [4, 8, 3, 21, 29]
        assert candidate([6, 1, 4, 5, 4]) == [1, 4, 4, 5, 6]
        assert candidate([3, 7, 42, 9, 34, 5]) == [3, 5, 9, 34, 7, 42]
        assert candidate([2, 5, 80, 8, 2, 6, 6, 3, 2, 6, 3]) == [2, 2, 2, 8, 3, 3, 5, 6, 6, 6, 80]
        assert candidate([8, 4, 45, 11, 37, 8]) == [4, 8, 8, 11, 37, 45]
        assert candidate([5, 8, 46, 17, 28, 1]) == [1, 8, 5, 17, 28, 46]
        assert candidate([5, 5, 13, 20, 28]) == [5, 5, 20, 13, 28]
        assert candidate([2, 11, 41, 15, 37, 3]) == [2, 3, 11, 37, 41, 15]
        assert candidate([5, 3, 2, 3, 6]) == [2, 3, 3, 5, 6]
        assert candidate([0, -3, -9, -7, -6]) == [0, -9, -6, -3, -7]
        assert candidate([1, 5, 2, 2, 2]) == [1, 2, 2, 2, 5]
        assert candidate([3, 4, 5, 8, 2]) == [2, 4, 8, 3, 5]
        assert candidate([7, 7, 7, 17, 29]) == [17, 7, 7, 7, 29]
        assert candidate([7, 6, 41, 12, 37, 6]) == [6, 6, 12, 7, 37, 41]
        assert candidate([6, 9, 48, 12, 34, 4]) == [4, 6, 9, 12, 34, 48]
        assert candidate([5, 10, 6, 3, 9]) == [3, 5, 6, 9, 10]
        assert candidate([1,0,2,3,4]) == [0, 1, 2, 4, 3]
        assert candidate([3, 8, 74, 5, 8, 3, 8, 9, 2, 1, 5]) == [1, 2, 8, 8, 8, 3, 3, 5, 5, 9, 74]
        assert candidate([5, 9, 74, 7, 6, 7, 3, 2, 1, 5, 8]) == [1, 2, 8, 3, 5, 5, 6, 9, 7, 7, 74]
        assert candidate([-7, -3, -4, -10, -10]) == [-4, -10, -10, -3, -7]
        assert candidate([4, 2, 8, 14, 30]) == [2, 4, 8, 14, 30]
        assert candidate([-3, -5, -9, -7, -4]) == [-4, -9, -5, -3, -7]
        assert candidate([5, 2, 5, 4, 4]) == [2, 4, 4, 5, 5]
        assert candidate([3, 2, 4, 17, 35]) == [2, 4, 3, 17, 35]
        assert candidate([7, 5, 10, 21, 33]) == [5, 10, 33, 7, 21]
        assert candidate([1, 6, 81, 8, 8, 2, 7, 8, 7, 8, 7]) == [1, 2, 8, 8, 8, 8, 6, 7, 7, 7, 81]
        assert candidate([4, 10, 77, 3, 8, 2, 9, 3, 4, 8, 2]) == [2, 2, 4, 4, 8, 8, 3, 3, 9, 10, 77]
        assert candidate([6, 11, 43, 9, 29, 10]) == [6, 9, 10, 11, 29, 43]
        assert candidate([1, 5, 8, 16, 27]) == [1, 8, 16, 5, 27]
        assert candidate([1, 5, 75, 6, 4, 3, 7, 11, 7, 2, 4]) == [1, 2, 4, 4, 3, 5, 6, 7, 7, 11, 75]
        assert candidate([3, 5, 81, 6, 5, 6, 9, 5, 3, 3, 3]) == [3, 3, 3, 3, 5, 5, 5, 6, 6, 9, 81]
        assert candidate([6, 8, 5, 2, 3]) == [2, 8, 3, 5, 6]
        assert candidate([5, 9, 42, 8, 34, 10]) == [8, 5, 9, 10, 34, 42]
        assert candidate([2,4,8,16,32]) == [2, 4, 8, 16, 32]

    # Check some edge cases that are easy to work out by hand.
        assert candidate([6, 7, 9, 21, 33]) == [6, 9, 33, 7, 21]
        assert candidate([1, 7, 11, 12, 32]) == [1, 32, 12, 7, 11]
        assert candidate([3,6,44,12,32,5]) == [32, 3, 5, 6, 12, 44]
        assert candidate([4, 1, 13, 12, 33]) == [1, 4, 12, 33, 13]
        assert candidate([3, 8, 78, 5, 10, 5, 9, 3, 4, 7, 1]) == [1, 4, 8, 3, 3, 5, 5, 9, 10, 7, 78]
        assert candidate([2, 6, 6, 1, 6]) == [1, 2, 6, 6, 6]
        assert candidate([4, 2, 3, 4, 9]) == [2, 4, 4, 3, 9]
        assert candidate([3, 2, 2, 8, 3]) == [2, 2, 8, 3, 3]
        assert candidate([5, 2, 1, 6, 5]) == [1, 2, 5, 5, 6]
        assert candidate([4, 4, 9, 16, 32]) == [4, 4, 16, 32, 9]
        assert candidate([2, -5, -5, -6, -4]) == [-4, 2, -6, -5, -5]
        assert candidate([1, 3, 41, 16, 32, 3]) == [1, 16, 32, 3, 3, 41]
        assert candidate([3, -7, -9, -2, -9]) == [-2, -9, -9, 3, -7]
        assert candidate([-1, -6, 0, -2, -8]) == [0, -8, -2, -1, -6]
        assert candidate([6, 2, 6, 17, 33]) == [2, 6, 6, 17, 33]
        assert candidate([3, 1, 8, 19, 32]) == [1, 8, 32, 3, 19]
        assert candidate([5, 6, 10, 15, 31]) == [5, 6, 10, 15, 31]
        assert candidate([2, 0, -7, -5, -3]) == [0, 2, -5, -3, -7]
        assert candidate([3, 1, -6, -4, -3]) == [-4, 1, -6, -3, 3]
        assert candidate([2, 7, 11, 14, 37]) == [2, 7, 11, 14, 37]
        assert candidate([6, 7, 9, 15, 30]) == [6, 9, 7, 15, 30]
        assert candidate([4, 1, 75, 9, 7, 7, 4, 7, 4, 2, 5]) == [1, 2, 4, 4, 4, 5, 9, 7, 7, 7, 75]
        assert candidate([7, 7, 79, 4, 3, 2, 10, 2, 2, 8, 8]) == [2, 2, 2, 4, 8, 8, 3, 10, 7, 7, 79]
        assert candidate([-6, -5, -9, -4, -8]) == [-8, -4, -9, -6, -5]
        assert candidate([7, 7, 12, 15, 29]) == [12, 7, 7, 15, 29]
        assert candidate([3, 2, 76, 9, 5, 3, 4, 2, 3, 3, 5]) == [2, 2, 4, 3, 3, 3, 3, 5, 5, 9, 76]
        assert candidate([-2,-3,-4,-5,-6]) == [-4, -2, -6, -5, -3]
        assert candidate([1, 3, 9, 15, 27]) == [1, 3, 9, 15, 27]
        assert candidate([3, 5, 8, 17, 27]) == [8, 3, 5, 17, 27]
        assert candidate([1, 3, 5, 1, 2]) == [1, 1, 2, 3, 5]
        assert candidate([2, 2, 10, 13, 27]) == [2, 2, 10, 13, 27]
        assert candidate([5, 6, 4, 1, 2]) == [1, 2, 4, 5, 6]
        assert candidate([3, 2, 4, 2, 2]) == [2, 2, 2, 4, 3]
        assert candidate([5, 4, 75, 8, 6, 2, 10, 4, 4, 6, 1]) == [1, 2, 4, 4, 4, 8, 5, 6, 6, 10, 75]
        assert candidate([8, 9, 39, 9, 28, 3]) == [8, 3, 9, 9, 28, 39]
        assert candidate([6, 9, 13, 16, 37]) == [16, 6, 9, 13, 37]
        assert candidate([6, 9, 2, 6, 7]) == [2, 6, 6, 9, 7]
        assert candidate([5, 3, 12, 17, 37]) == [3, 5, 12, 17, 37]
        assert candidate([2, 9, 12, 15, 31]) == [2, 9, 12, 15, 31]
        assert candidate([3, 6, 72, 3, 7, 6, 7, 6, 3, 8, 3]) == [8, 3, 3, 3, 3, 6, 6, 6, 72, 7, 7]
        assert candidate([3, -3, -7, -6, -3]) == [-6, -3, -3, 3, -7]
        assert candidate([4, 3, 4, 4, 1]) == [1, 4, 4, 4, 3]
        assert candidate([-1, 1, -4, -6, -6]) == [-4, -1, 1, -6, -6]
        assert candidate([4, 1, 6, 16, 30]) == [1, 4, 16, 6, 30]
        assert candidate([2, 9, 1, 8, 8]) == [1, 2, 8, 8, 9]
        assert candidate([5, 3, 2, 1, 7]) == [1, 2, 3, 5, 7]
        assert candidate([3, 1, 6, 7, 7]) == [1, 3, 6, 7, 7]
        assert candidate([1, 5, 3, 5, 1]) == [1, 1, 3, 5, 5]
        assert candidate([1,5,2,3,4]) == [1, 2, 4, 3, 5]
        assert candidate([]) == []
        assert candidate([1, 10, 74, 7, 1, 2, 1, 2, 6, 6, 1]) == [1, 1, 1, 1, 2, 2, 6, 6, 10, 7, 74]
        assert candidate([4, 4, 5, 4, 1]) == [1, 4, 4, 4, 5]
        assert candidate([-4, 0, -1, -4, -7]) == [0, -4, -4, -1, -7]
        assert candidate([4, 11, 45, 13, 29, 8]) == [4, 8, 11, 13, 29, 45]
        assert candidate([3, 6, 3, 1, 7]) == [1, 3, 3, 6, 7]
        assert candidate([2, 8, 76, 4, 7, 6, 6, 8, 6, 2, 8]) == [2, 2, 4, 8, 8, 8, 6, 6, 6, 7, 76]
        assert candidate([1, 8, 7, 2, 3]) == [1, 2, 8, 3, 7]

if __name__ == '__main__':
    unittest.main()
