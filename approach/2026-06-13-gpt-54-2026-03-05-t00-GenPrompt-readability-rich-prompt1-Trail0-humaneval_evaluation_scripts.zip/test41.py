
import unittest
import re
import sys
import math
import copy



def car_race_collision(number_of_cars_per_direction: int) -> int:
    """
    Return the total number of collisions between two groups of cars.

    One group has `number_of_cars_per_direction` cars moving left to right.
    The other group has the same number moving right to left.

    Every car moving right will collide exactly once with every car moving left,
    so the total number of collisions is:

        number_of_cars_per_direction * number_of_cars_per_direction
    """
    return number_of_cars_per_direction * number_of_cars_per_direction
candidate = car_race_collision




METADATA = {}


def check(candidate):
    assert candidate(2) == 4
    assert candidate(3) == 9
    assert candidate(4) == 16
    assert candidate(8) == 64
    assert candidate(10) == 100



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
