
import unittest
import re
import sys
import math
import copy


def is_happy(text):
    """Return True if the string is happy, otherwise False.

    A string is happy when:
    - its length is at least 3
    - every group of 3 consecutive characters contains 3 distinct characters
    """
    if len(text) < 3:
        return False

    for index in range(len(text) - 2):
        first_char = text[index]
        second_char = text[index + 1]
        third_char = text[index + 2]

        if len({first_char, second_char, third_char}) != 3:
            return False

    return True
candidate = is_happy


def check(candidate):

    # Check some simple cases
    assert candidate("a") == False , "a"
    assert candidate("aa") == False , "aa"
    assert candidate("abcd") == True , "abcd"
    assert candidate("aabb") == False , "aabb"
    assert candidate("adb") == True , "adb"
    assert candidate("xyy") == False , "xyy"
    assert candidate("iopaxpoi") == True , "iopaxpoi"
    assert candidate("iopaxioi") == False , "iopaxioi"


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
