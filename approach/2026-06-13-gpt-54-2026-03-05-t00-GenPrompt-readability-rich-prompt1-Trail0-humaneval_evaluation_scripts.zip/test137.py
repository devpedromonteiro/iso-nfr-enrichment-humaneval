
import unittest
import re
import sys
import math
import copy


def compare_one(first_value, second_value):
    """
    Return the larger of two real-number values while preserving the original type.

    The inputs may be:
    - int
    - float
    - str representing a real number

    String numbers may use either "." or "," as the decimal separator.

    Return:
    - the original input value that is numerically larger
    - None if both values are numerically equal
    """

    def to_float(value):
        if isinstance(value, str):
            normalized_value = value.replace(",", ".")
            return float(normalized_value)
        return float(value)

    first_number = to_float(first_value)
    second_number = to_float(second_value)

    if first_number == second_number:
        return None

    if first_number > second_number:
        return first_value

    return second_value
candidate = compare_one


def check(candidate):

    # Check some simple cases
    assert candidate(1, 2) == 2
    assert candidate(1, 2.5) == 2.5
    assert candidate(2, 3) == 3
    assert candidate(5, 6) == 6
    assert candidate(1, "2,3") == "2,3"
    assert candidate("5,1", "6") == "6"
    assert candidate("1", "2") == "2"
    assert candidate("1", 1) == None

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
