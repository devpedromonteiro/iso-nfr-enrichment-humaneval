
import unittest
import re
import sys
import math
import copy


def is_nested(brackets):
    """
    Return True if the string contains a valid bracket subsequence
    with at least one nested pair of square brackets.
    """

    current_depth = 0
    deepest_nesting = 0

    for bracket in brackets:
        if bracket == "[":
            current_depth += 1
            deepest_nesting = max(deepest_nesting, current_depth)
        elif bracket == "]" and current_depth > 0:
            current_depth -= 1

    return deepest_nesting >= 2
candidate = is_nested


def check(candidate):

    # Check some simple cases
    assert candidate('[[]]') == True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('[]]]]]]][[[[[]') == False
    assert candidate('[][]') == False
    assert candidate(('[]')) == False
    assert candidate('[[[[]]]]') == True
    assert candidate('[]]]]]]]]]]') == False
    assert candidate('[][][[]]') == True
    assert candidate('[[]') == False
    assert candidate('[]]') == False
    assert candidate('[[]][[') == True
    assert candidate('[[][]]') == True

    # Check some edge cases that are easy to work out by hand.
    assert candidate('') == False, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate('[[[[[[[[') == False
    assert candidate(']]]]]]]]') == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
