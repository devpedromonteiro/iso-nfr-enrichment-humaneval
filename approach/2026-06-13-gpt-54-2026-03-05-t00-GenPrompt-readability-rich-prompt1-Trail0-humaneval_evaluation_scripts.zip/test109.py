
import unittest
import re
import sys
import math
import copy


def move_one_ball(numbers):
    """Return True if some number of right shifts can sort the array.

    A right shift moves the last element to the front. The array can be made
    non-decreasing by right shifts if it is already sorted except for at most
    one "drop", where a value is greater than the value after it.

    Examples:
        move_one_ball([3, 4, 5, 1, 2]) -> True
        move_one_ball([3, 5, 4, 1, 2]) -> False
        move_one_ball([]) -> True
    """
    if not numbers:
        return True

    descending_transitions = 0

    for current_index in range(len(numbers)):
        next_index = (current_index + 1) % len(numbers)

        if numbers[current_index] > numbers[next_index]:
            descending_transitions += 1

            if descending_transitions > 1:
                return False

    return True
candidate = move_one_ball


def check(candidate):

    # Check some simple cases
    assert candidate([3, 4, 5, 1, 2])==True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([3, 5, 10, 1, 2])==True
    assert candidate([4, 3, 1, 2])==False
    # Check some edge cases that are easy to work out by hand.
    assert candidate([3, 5, 4, 1, 2])==False, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([])==True


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
