
import unittest


def maximum(arr, k):
    """
    Given an array arr of integers and a positive integer k, return a sorted list
    of length k with the maximum k numbers in arr.

    Example 1:
        Input: arr = [-3, -4, 5], k = 3
        Output: [-4, -3, 5]

    Example 2:
        Input: arr = [4, -4, 4], k = 2
        Output: [4, 4]

    Example 3:
        Input: arr = [-3, 2, 1, 2, -1, -2, 1], k = 1
        Output: [2]

    Note:
        1. The length of the array will be in the range of [1, 1000].
        2. The elements in the array will be in the range of [-1000, 1000].
        3. 0 <= k <= len(arr)
    """
    if not isinstance(arr, list):
        raise TypeError("arr must be a list of integers")

    if not isinstance(k, int):
        raise TypeError("k must be an integer")

    if k < 0:
        raise ValueError("k must be non-negative")

    if k > len(arr):
        raise ValueError("k cannot be greater than the length of arr")

    for i, value in enumerate(arr):
        if not isinstance(value, int):
            raise TypeError(f"arr[{i}] must be an integer")

    # Use a copy to avoid mutating the input and leaving external state inconsistent.
    try:
        return sorted(arr)[-k:] if k > 0 else []
    except TypeError as exc:
        raise TypeError("arr must contain only mutually comparable integers") from exc
candidate = maximum


class Test(unittest.TestCase):
    def test(self):
        assert candidate([2, 1, 1], 1) == [2]
        assert candidate([5, 5, 4, -12], 4) == [-12, 4, 5, 5]
        assert candidate([4, 6, 5, -18, 248, -403, 5], 3) == [5, 6, 248]
        assert candidate([2, 3, 5, 3, 1, -15], 3) == [3, 3, 5]
        assert candidate([4, 5, 5, -22, 241, -401, 1], 1) == [241]
        assert candidate([1, 12, 2, 1, -11, -4, 5], 5) == [1, 1, 2, 5, 12]
        assert candidate([8, 13, 4, 2, -11, -4, 1], 11) == [-11, -4, 1, 2, 4, 8, 13]
        assert candidate([3, -4, 7], 3) == [-4, 3, 7]
        assert candidate([-123, 23, 1, 3, 3, 1], 9) == [-123, 1, 1, 3, 3, 23]
        assert candidate([-10, 10], 2) == [-10, 10]

    # Check some edge cases that are easy to work out by hand.
        assert candidate([-9, 11], 3) == [-9, 11]
        assert candidate([6, 6, 2, -24, 240, -402, 4], 1) == [240]
        assert candidate([-11, 5], 4) == [-11, 5]
        assert candidate([6, 1, 3, -26, 247, -400, 1], 1) == [247]
        assert candidate([-119, 24, 5, 4, 1, -8], 9) == [-119, -8, 1, 4, 5, 24]
        assert candidate([-123, 24, 3, 4, 2, -7], 6) == [-123, -7, 2, 3, 4, 24]
        assert candidate([-3, -4, 5], 3) == [-4, -3, 5]
        assert candidate([3, 3, 2, -27, 243, -396, 5], 3) == [3, 5, 243]
        assert candidate([4, -4, 4], 2) == [4, 4]
        assert candidate([4, 1, 9, -3], 3) == [1, 4, 9]
        assert candidate([2, 5, 1, 2, -6, -2, 5], 6) == [-2, 1, 2, 2, 5, 5]
        assert candidate([0, 5, 2, 7, 2, -15], 3) == [2, 5, 7]
        assert candidate([-1, 5, 3, 6, -2, -7, 6], 3) == [5, 6, 6]
        assert candidate([5, 3, 7, -2], 3) == [3, 5, 7]
        assert candidate([2, 1, 9], 1) == [9]
        assert candidate([8, 15, 1, 4, -14, -5, 2], 6) == [-5, 1, 2, 4, 8, 15]
        assert candidate([-3, 1, 7, 7, 4, -12], 7) == [-12, -3, 1, 4, 7, 7]
        assert candidate([7, -2], 7) == [-2, 7]
        assert candidate([6, -5], 2) == [-5, 6]
        assert candidate([-8, 5], 6) == [-8, 5]
        assert candidate([-126, 15, 4, 3, 4, -4], 3) == [4, 4, 15]
        assert candidate([5, -2, 1], 6) == [-2, 1, 5]
        assert candidate([10, 12, 1, 2, -11, -6, 2], 4) == [2, 2, 10, 12]
        assert candidate([-2, 5, 5, 5, -1, 2, 3], 6) == [-1, 2, 3, 5, 5, 5]
        assert candidate([-6, -2, 5], 2) == [-2, 5]
        assert candidate([3, -9, 1], 4) == [-9, 1, 3]
        assert candidate([119, -119, 21, 2, 4, 4, -3], 3) == [4, 21, 119]
        assert candidate([2, 6, 6, 3, 4, 3, 1], 2) == [6, 6]
        assert candidate([7, -9, 7], 7) == [-9, 7, 7]
        assert candidate([118, -119, 17, 4, 1, 1, -7], 2) == [17, 118]
        assert candidate([-1, -2, 3], 3) == [-2, -1, 3]
        assert candidate([8, -2, 4], 3) == [-2, 4, 8]
        assert candidate([-1, 3, 4, 7, 2, -3, 6], 1) == [7]
        assert candidate([-14, 6], 4) == [-14, 6]
        assert candidate([122, -124, 25, 1, 1, 1, -2], 2) == [25, 122]
        assert candidate([1, 1, 2, -2], 2) == [1, 2]
        assert candidate([3, 15, 5, 4, -16, -10, 4], 11) == [-16, -10, 3, 4, 4, 5, 15]
        assert candidate([8, -6], 7) == [-6, 8]
        assert candidate([-12, 8], 2) == [-12, 8]
        assert candidate([10, 16, 5, 2, -12, -3, 1], 7) == [-12, -3, 1, 2, 5, 10, 16]
        assert candidate([-119, 16, 5, 2, 3, -6], 8) == [-119, -6, 2, 3, 5, 16]
        assert candidate([5, 1, 4], 2) == [4, 5]
        assert candidate([-1, 2, 1, 5, 6, -13], 2) == [5, 6]
        assert candidate([-13, 13], 7) == [-13, 13]
        assert candidate([-1, 0, 2, 5, 3, -10], 2) == [3, 5]
        assert candidate([4, -6, 8], 4) == [-6, 4, 8]
        assert candidate([-2, 1, 1], 1) == [1]
        assert candidate([2, 1], 1) == [2]
        assert candidate([128, -128, 22, 2, 3, 1, -5], 6) == [-5, 1, 2, 3, 22, 128]
        assert candidate([-120, 20, 2, 5, 1, -6], 7) == [-120, -6, 1, 2, 5, 20]
        assert candidate([-5, 10], 6) == [-5, 10]
        assert candidate([-1, 4, 7, 3, 8, -9], 7) == [-9, -1, 3, 4, 7, 8]
        assert candidate([4, 3, 4, -20, 247, -400, 4], 4) == [4, 4, 4, 247]
        assert candidate([-3, 1, 2], 4) == [-3, 1, 2]
        assert candidate([-1, 2, 1, 2, -5, -5, 2], 3) == [2, 2, 2]
        assert candidate([2, 13, 4, 6, -17, -3, 1], 7) == [-17, -3, 1, 2, 4, 6, 13]
        assert candidate([-5, -6, 10], 1) == [10]
        assert candidate([10, 12, 2, 1, -17, -3, 5], 4) == [2, 5, 10, 12]
        assert candidate([119, -118, 15, 3, 3, 3, -8], 1) == [119]
        assert candidate([2, -9], 4) == [-9, 2]
        assert candidate([-9, 13], 3) == [-9, 13]
        assert candidate([6, 0, 5], 4) == [0, 5, 6]
        assert candidate([123, -128, 20, 4, 3, 2, 1], 6) == [1, 2, 3, 4, 20, 123]
        assert candidate([5, 3, 2, -9], 5) == [-9, 2, 3, 5]
        assert candidate([4, -9], 4) == [-9, 4]
        assert candidate([1, 2, 3, -23, 243, -400, 0], 0) == []
        assert candidate([4, -4], 2) == [-4, 4]
        assert candidate([3, 2, 1, -9], 6) == [-9, 1, 2, 3]
        assert candidate([1, 0, 5, -7], 1) == [5]
        assert candidate([6, 0, 8], 2) == [6, 8]
        assert candidate([0, -5, 10], 1) == [10]
        assert candidate([-5, 3, 2, 8, 3, -10], 1) == [8]
        assert candidate([6, 1, 3, -4], 6) == [-4, 1, 3, 6]
        assert candidate([119, -119, 24, 5, 5, 7, -4], 6) == [-4, 5, 5, 7, 24, 119]
        assert candidate([6, 5, 2, -10], 5) == [-10, 2, 5, 6]
        assert candidate([3, 13, 3, 4, -9, -11, 3], 2) == [4, 13]
        assert candidate([1, 1], 4) == [1, 1]
        assert candidate([8, -4], 7) == [-4, 8]
        assert candidate([9, -9], 1) == [9]
        assert candidate([0, 3, 6, 2, -1, 3, 4], 4) == [3, 3, 4, 6]
        assert candidate([8, 1, 2], 4) == [1, 2, 8]
        assert candidate([-2, 2, 5, 2, 0, 2, 2], 4) == [2, 2, 2, 5]
        assert candidate([6, -1], 5) == [-1, 6]
        assert candidate([2, 2, 10, -3], 1) == [10]
        assert candidate([3, 19, 4, 5, -13, -8, 5], 4) == [4, 5, 5, 19]
        assert candidate([-4, 6, 4, 2, 4, -6, 5], 4) == [4, 4, 5, 6]
        assert candidate([6, 5, 1, -19, 242, -403, 5], 3) == [5, 6, 242]
        assert candidate([-3, 6, 3, 1, 0, -4, 6], 5) == [0, 1, 3, 6, 6]
        assert candidate([1, 3, 3, 2, -2, -5, 5], 2) == [3, 5]
        assert candidate([127, -124, 16, 1, 5, 7, -6], 7) == [-124, -6, 1, 5, 7, 16, 127]
        assert candidate([-7, 10], 7) == [-7, 10]
        assert candidate([7, 12, 4, 4, -16, -7, 3], 10) == [-16, -7, 3, 4, 4, 7, 12]
        assert candidate([5, 2, 5, -11], 5) == [-11, 2, 5, 5]
        assert candidate([-123, 20, 0 , 1, 2, -3], 4) == [0, 1, 2, 20]
        assert candidate([6, 7, 8, -20, 243, -398, 5], 3) == [7, 8, 243]
        assert candidate([-10, 10], 3) == [-10, 10]
        assert candidate([4, 5, 8, -28, 245, -402, 2], 4) == [4, 5, 8, 245]
        assert candidate([125, -119, 24, 2, 3, 4, -4], 6) == [-4, 2, 3, 4, 24, 125]
        assert candidate([1, -6], 1) == [1]
        assert candidate([3, 1, 1, -19, 248, -404, 5], 1) == [248]
        assert candidate([1, 4, 4, -9], 3) == [1, 4, 4]
        assert candidate([-122, 16, 1, 4, 2, 1], 6) == [-122, 1, 1, 2, 4, 16]
        assert candidate([0, 1, 2, 5, 1, -9], 2) == [2, 5]
        assert candidate([3, 6, 2, -19, 243, -396, 4], 1) == [243]
        assert candidate([-1, 0, 2], 1) == [2]
        assert candidate([-120, 25, 1, 5, 6, -3], 7) == [-120, -3, 1, 5, 6, 25]
        assert candidate([-126, 22, 2, 2, 5, -3], 3) == [2, 5, 22]
        assert candidate([1, -4, 2], 7) == [-4, 1, 2]
        assert candidate([3, 1, 2, 7, 8, -11], 5) == [1, 2, 3, 7, 8]
        assert candidate([-6, 7], 2) == [-6, 7]
        assert candidate([3, 6, 4, -26, 246, -403, 5], 5) == [3, 4, 5, 6, 246]
        assert candidate([-2, -7, 4], 4) == [-7, -2, 4]
        assert candidate([4, 3, 4, 5, 1, -10], 1) == [5]
        assert candidate([128, -127, 25, 1, 3, 2, -8], 5) == [1, 2, 3, 25, 128]
        assert candidate([127, -127, 21, 5, 3, 3, -2], 8) == [-127, -2, 3, 3, 5, 21, 127]
        assert candidate([123, -123, 20, 0 , 1, 2, -3], 3) == [2, 20, 123]
        assert candidate([-7, 1, 4], 5) == [-7, 1, 4]
        assert candidate([-7, -8, 6], 1) == [6]
        assert candidate([7, 20, 1, 4, -9, -13, 1], 4) == [1, 4, 7, 20]
        assert candidate([123, -121, 22, 4, 2, 2, -6], 1) == [123]
        assert candidate([5, 3, 5, -6], 3) == [3, 5, 5]
        assert candidate([-121, 15, 3, 4, 7, -5], 3) == [4, 7, 15]
        assert candidate([-13, 11], 2) == [-13, 11]
        assert candidate([-125, 18, 3, 1, 5, -1], 1) == [18]
        assert candidate([9, -3, 1], 3) == [-3, 1, 9]
        assert candidate([-3, 2, 1, 2, -1, -2, 1], 1) == [2]
        assert candidate([-1, 2, 1, 1, 1, -5], 1) == [2]
        assert candidate([5, 15, 0, 3, -13, -8, 0], 7) == [-13, -8, 0, 0, 3, 5, 15]
        assert candidate([-2, 7, 4, 5, 0, 0, 4], 3) == [4, 5, 7]
        assert candidate([-4, 4, 2, 10, 2, -5], 5) == [-4, 2, 2, 4, 10]
        assert candidate([1, 4, 4, 1, 2, -14], 5) == [1, 1, 2, 4, 4]
        assert candidate([-123, 19, 4, 5, 6, -2], 3) == [5, 6, 19]

if __name__ == '__main__':
    unittest.main()
