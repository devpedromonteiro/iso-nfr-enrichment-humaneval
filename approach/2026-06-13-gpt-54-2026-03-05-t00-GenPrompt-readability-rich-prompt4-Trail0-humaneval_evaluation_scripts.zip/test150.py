
import unittest
import re
import sys
import math
import copy


def x_or_y(number, value_if_prime, value_if_not_prime):
    """Return one of two values depending on whether ``number`` is prime.

    Args:
        number: The integer to test for primality.
        value_if_prime: The value to return when ``number`` is prime.
        value_if_not_prime: The value to return when ``number`` is not prime.

    Examples:
        >>> x_or_y(7, 34, 12)
        34
        >>> x_or_y(15, 8, 5)
        5
    """

    def is_prime(candidate):
        if candidate < 2:
            return False

        divisor = 2
        while divisor * divisor <= candidate:
            if candidate % divisor == 0:
                return False
            divisor += 1

        return True

    if is_prime(number):
        return value_if_prime

    return value_if_not_prime
candidate = x_or_y


def check(candidate):

    # Check some simple cases
    assert candidate(7, 34, 12) == 34
    assert candidate(15, 8, 5) == 5
    assert candidate(3, 33, 5212) == 33
    assert candidate(1259, 3, 52) == 3
    assert candidate(7919, -1, 12) == -1
    assert candidate(3609, 1245, 583) == 583
    assert candidate(91, 56, 129) == 129
    assert candidate(6, 34, 1234) == 1234
    

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1, 2, 0) == 0
    assert candidate(2, 2, 0) == 2



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
