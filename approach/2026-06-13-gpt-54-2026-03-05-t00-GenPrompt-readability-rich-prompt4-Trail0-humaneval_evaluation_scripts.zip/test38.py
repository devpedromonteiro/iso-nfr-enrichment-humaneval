
import unittest
import re
import sys
import math
import copy



def encode_cyclic(s: str):
    """
    returns encoded string by cycling groups of three characters.
    """
    # split string to groups. Each of length 3.
    groups = [s[(3 * i):min((3 * i + 3), len(s))] for i in range((len(s) + 2) // 3)]
    # cycle elements in each group. Unless group has fewer elements than 3.
    groups = [(group[1:] + group[0]) if len(group) == 3 else group for group in groups]
    return "".join(groups)


def encode_cyclic(text: str) -> str:
    """
    Return a string where each group of three characters is cyclically shifted left.

    Example:
        "abcdef" -> "bcaefd"

    Groups shorter than three characters are left unchanged.
    """
    encoded_groups = []

    for start_index in range(0, len(text), 3):
        group = text[start_index:start_index + 3]

        if len(group) == 3:
            shifted_group = group[1:] + group[0]
            encoded_groups.append(shifted_group)
        else:
            encoded_groups.append(group)

    return "".join(encoded_groups)


def decode_cyclic(text: str) -> str:
    """
    Decode a string produced by encode_cyclic.

    Each full group of three characters is cyclically shifted right
    to restore the original text.

    Example:
        "bcaefd" -> "abcdef"

    Groups shorter than three characters are left unchanged.
    """
    decoded_groups = []

    for start_index in range(0, len(text), 3):
        group = text[start_index:start_index + 3]

        if len(group) == 3:
            restored_group = group[-1] + group[:-1]
            decoded_groups.append(restored_group)
        else:
            decoded_groups.append(group)

    return "".join(decoded_groups)
candidate = decode_cyclic




METADATA = {}


def check(candidate):
    from random import randint, choice
    import string

    letters = string.ascii_lowercase
    for _ in range(100):
        str = ''.join(choice(letters) for i in range(randint(10, 20)))
        encoded_str = encode_cyclic(str)
        assert candidate(encoded_str) == str



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
