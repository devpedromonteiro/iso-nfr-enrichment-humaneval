
import unittest
import re
import sys
import math
import copy


def numerical_letter_grade(grades):
    """Convert a list of GPA values to their corresponding letter grades."""

    letter_grades = []

    for grade_point_average in grades:
        if grade_point_average == 4.0:
            letter_grade = "A+"
        elif grade_point_average > 3.7:
            letter_grade = "A"
        elif grade_point_average > 3.3:
            letter_grade = "A-"
        elif grade_point_average > 3.0:
            letter_grade = "B+"
        elif grade_point_average > 2.7:
            letter_grade = "B"
        elif grade_point_average > 2.3:
            letter_grade = "B-"
        elif grade_point_average > 2.0:
            letter_grade = "C+"
        elif grade_point_average > 1.7:
            letter_grade = "C"
        elif grade_point_average > 1.3:
            letter_grade = "C-"
        elif grade_point_average > 1.0:
            letter_grade = "D+"
        elif grade_point_average > 0.7:
            letter_grade = "D"
        elif grade_point_average > 0.0:
            letter_grade = "D-"
        else:
            letter_grade = "E"

        letter_grades.append(letter_grade)

    return letter_grades
candidate = numerical_letter_grade


def check(candidate):

    # Check some simple cases
    assert candidate([4.0, 3, 1.7, 2, 3.5]) == ['A+', 'B', 'C-', 'C', 'A-']
    assert candidate([1.2]) == ['D+']
    assert candidate([0.5]) == ['D-']
    assert candidate([0.0]) == ['E']
    assert candidate([1, 0.3, 1.5, 2.8, 3.3]) == ['D', 'D-', 'C-', 'B', 'B+']
    assert candidate([0, 0.7]) == ['E', 'D-']

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
