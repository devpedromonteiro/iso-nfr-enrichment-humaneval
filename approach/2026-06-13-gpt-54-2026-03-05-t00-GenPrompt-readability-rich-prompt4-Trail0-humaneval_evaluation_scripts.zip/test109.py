
import unittest
import re
import sys
import math
import copy


def move_one_ball(numbers):
    """Return True if some number of right shifts can sort the array.

    A right shift moves the last element to the front. The function returns True
    when the given list can become sorted in non-decreasing order after applying
    that operation zero or more times.

    An empty list is considered sortable.

    Examples:
        move_one_ball([3, 4, 5, 1, 2]) -> True
        move_one_ball([3, 5, 4, 1, 2]) -> False
    """
    if not numbers:
        return True

    drop_count = 0
    last_index = len(numbers) - 1

    for index in range(last_index):
        if numbers[index] > numbers[index + 1]:
            drop_count += 1
            if drop_count > 1:
                return False

    if numbers[-1] > numbers[0]:
        drop_count += 1

    return drop_count <= 1
candidate = move_one_ball


def check(candidate):

    # Check some simple cases
    assert candidate([3, 4, 5, 1, 2])==True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([3, 5, 10, 1, 2])==True
    assert candidate([4, 3, 1, 2])==False
    # Check some edge cases that are easy to work out by hand.
    assert candidate([3, 5, 4, 1, 2])==False, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([])==True


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
