
import unittest
import re
import sys
import math
import copy


def solve(text):
    """Return the string with letter cases swapped.

    If the input contains at least one letter, each letter changes case and all
    other characters stay unchanged.
    If the input contains no letters, the whole string is reversed.
    """
    contains_letter = any(character.isalpha() for character in text)

    if not contains_letter:
        return text[::-1]

    transformed_characters = []

    for character in text:
        if character.isalpha():
            transformed_characters.append(character.swapcase())
        else:
            transformed_characters.append(character)

    return "".join(transformed_characters)
candidate = solve


def check(candidate):

    # Check some simple cases
    assert candidate("AsDf") == "aSdF"
    assert candidate("1234") == "4321"
    assert candidate("ab") == "AB"
    assert candidate("#a@C") == "#A@c"
    assert candidate("#AsdfW^45") == "#aSDFw^45"
    assert candidate("#6@2") == "2@6#"

    # Check some edge cases that are easy to work out by hand.
    assert candidate("#$a^D") == "#$A^d"
    assert candidate("#ccc") == "#CCC"

    # Don't remove this line:


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
