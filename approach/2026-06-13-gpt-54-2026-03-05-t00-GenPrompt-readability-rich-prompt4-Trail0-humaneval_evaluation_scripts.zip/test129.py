
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Return the lexicographically smallest path of length k.

    A path visits exactly k cells. From each cell, you may move up, down,
    left, or right, and you may revisit cells.
    """
    grid_size = len(grid)

    def get_neighbors(row, col):
        neighbors = []

        if row > 0:
            neighbors.append((row - 1, col))
        if row < grid_size - 1:
            neighbors.append((row + 1, col))
        if col > 0:
            neighbors.append((row, col - 1))
        if col < grid_size - 1:
            neighbors.append((row, col + 1))

        return neighbors

    value_to_position = {}
    for row in range(grid_size):
        for col in range(grid_size):
            cell_value = grid[row][col]
            value_to_position[cell_value] = (row, col)

    smallest_value = 1
    current_row, current_col = value_to_position[smallest_value]
    path_values = [smallest_value]

    for _ in range(k - 1):
        best_next_value = None
        best_next_position = None

        for neighbor_row, neighbor_col in get_neighbors(current_row, current_col):
            neighbor_value = grid[neighbor_row][neighbor_col]

            if best_next_value is None or neighbor_value < best_next_value:
                best_next_value = neighbor_value
                best_next_position = (neighbor_row, neighbor_col)

        path_values.append(best_next_value)
        current_row, current_col = best_next_position

    return path_values
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
