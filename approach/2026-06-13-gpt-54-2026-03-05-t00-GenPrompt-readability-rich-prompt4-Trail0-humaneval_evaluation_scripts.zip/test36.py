
import unittest
import re
import sys
import math
import copy



def fizz_buzz(n: int) -> int:
    """Return how many times the digit 7 appears in numbers less than n
    that are divisible by 11 or 13.

    >>> fizz_buzz(50)
    0
    >>> fizz_buzz(78)
    2
    >>> fizz_buzz(79)
    3
    """
    total_sevens = 0

    for number in range(n):
        is_divisible_by_11 = number % 11 == 0
        is_divisible_by_13 = number % 13 == 0

        if is_divisible_by_11 or is_divisible_by_13:
            total_sevens += str(number).count("7")

    return total_sevens
candidate = fizz_buzz




METADATA = {}


def check(candidate):
    assert candidate(50) == 0
    assert candidate(78) == 2
    assert candidate(79) == 3
    assert candidate(100) == 3
    assert candidate(200) == 6
    assert candidate(4000) == 192
    assert candidate(10000) == 639
    assert candidate(100000) == 8026



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
