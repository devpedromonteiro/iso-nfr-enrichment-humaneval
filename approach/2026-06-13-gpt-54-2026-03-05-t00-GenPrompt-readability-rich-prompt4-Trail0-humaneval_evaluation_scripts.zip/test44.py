
import unittest
import re
import sys
import math
import copy



def change_base(number: int, target_base: int) -> str:
    """Convert a non-negative integer to its representation in another base.

    The target base must be less than 10.

    >>> change_base(8, 3)
    '22'
    >>> change_base(8, 2)
    '1000'
    >>> change_base(7, 2)
    '111'
    """
    if target_base < 2 or target_base >= 10:
        raise ValueError("target_base must be between 2 and 9")

    if number == 0:
        return "0"

    digits = []
    remaining_value = number

    while remaining_value > 0:
        remainder = remaining_value % target_base
        digits.append(str(remainder))
        remaining_value //= target_base

    digits.reverse()
    return "".join(digits)
candidate = change_base




METADATA = {}


def check(candidate):
    assert candidate(8, 3) == "22"
    assert candidate(9, 3) == "100"
    assert candidate(234, 2) == "11101010"
    assert candidate(16, 2) == "10000"
    assert candidate(8, 2) == "1000"
    assert candidate(7, 2) == "111"
    for x in range(2, 8):
        assert candidate(x, x + 1) == str(x)



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
