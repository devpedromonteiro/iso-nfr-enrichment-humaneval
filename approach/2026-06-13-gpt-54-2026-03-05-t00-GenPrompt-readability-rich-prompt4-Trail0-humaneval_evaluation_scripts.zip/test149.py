
import unittest
import re
import sys
import math
import copy


def sorted_list_sum(words):
    """Return even-length strings sorted by length, then alphabetically.

    Strings with odd lengths are removed. The remaining strings are sorted
    in ascending order by length, and alphabetically when lengths are equal.
    """
    even_length_words = []

    for word in words:
        if len(word) % 2 == 0:
            even_length_words.append(word)

    return sorted(even_length_words, key=lambda word: (len(word), word))
candidate = sorted_list_sum


def check(candidate):

    # Check some simple cases
    assert candidate(["aa", "a", "aaa"]) == ["aa"]
    assert candidate(["school", "AI", "asdf", "b"]) == ["AI", "asdf", "school"]
    assert candidate(["d", "b", "c", "a"]) == []
    assert candidate(["d", "dcba", "abcd", "a"]) == ["abcd", "dcba"]

    # Check some edge cases that are easy to work out by hand.
    assert candidate(["AI", "ai", "au"]) == ["AI", "ai", "au"]
    assert candidate(["a", "b", "b", "c", "c", "a"]) == []
    assert candidate(['aaaa', 'bbbb', 'dd', 'cc']) == ["cc", "dd", "aaaa", "bbbb"]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
