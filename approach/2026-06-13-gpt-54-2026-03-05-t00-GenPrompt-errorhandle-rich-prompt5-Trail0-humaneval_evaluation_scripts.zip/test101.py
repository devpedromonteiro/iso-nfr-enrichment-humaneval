
import unittest
import re
import sys
import math
import copy


def words_string(s):
    """
    Split a string of words separated by commas and/or spaces into a list of words.

    Examples:
        words_string("Hi, my name is John") -> ["Hi", "my", "name", "is", "John"]
        words_string("One, two, three, four, five, six") -> ["One", "two", "three", "four", "five", "six"]
    """
    if s is None:
        raise ValueError("Input cannot be None.")

    if not isinstance(s, str):
        raise TypeError(f"Input must be a string, got {type(s).__name__}.")

    try:
        normalized = s.replace(",", " ")
        words = [word for word in normalized.split() if word]
        return words
    except AttributeError as exc:
        # Defensive handling in case string-like assumptions fail unexpectedly
        raise TypeError("Input must support string operations.") from exc
candidate = words_string


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate("Hi, my name is John") == ["Hi", "my", "name", "is", "John"]
    assert candidate("One, two, three, four, five, six") == ["One", "two", "three", "four", "five", "six"]
    assert candidate("Hi, my name") == ["Hi", "my", "name"]
    assert candidate("One,, two, three, four, five, six,") == ["One", "two", "three", "four", "five", "six"]

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate("") == []
    assert candidate("ahmed     , gamal") == ["ahmed", "gamal"]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
