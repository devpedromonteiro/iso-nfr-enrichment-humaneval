
import unittest
import re
import sys
import math
import copy


def words_in_sentence(sentence):
    """
    You are given a string representing a sentence,
    the sentence contains some words separated by a space,
    and you have to return a string that contains the words from the original sentence,
    whose lengths are prime numbers,
    the order of the words in the new string should be the same as the original one.

    Example 1:
        Input: sentence = "This is a test"
        Output: "is"

    Example 2:
        Input: sentence = "lets go for swimming"
        Output: "go for"

    Constraints:
        * 1 <= len(sentence) <= 100
        * sentence contains only letters
    """
    if not isinstance(sentence, str):
        raise TypeError("sentence must be a string")

    if not (1 <= len(sentence) <= 100):
        raise ValueError("sentence length must be between 1 and 100")

    if sentence != sentence.strip():
        raise ValueError("sentence must not have leading or trailing spaces")

    if "  " in sentence:
        raise ValueError("sentence must contain words separated by single spaces only")

    words = sentence.split(" ")

    for word in words:
        if not word:
            raise ValueError("sentence must not contain empty words")
        if not word.isalpha():
            raise ValueError("sentence must contain only letters and spaces")

    def is_prime(n):
        if not isinstance(n, int):
            raise TypeError("word length must be an integer")
        if n < 0:
            raise ValueError("word length cannot be negative")
        if n < 2:
            return False
        for i in range(2, int(n ** 0.5) + 1):
            if n % i == 0:
                return False
        return True

    prime_length_words = [word for word in words if is_prime(len(word))]
    return " ".join(prime_length_words)
candidate = words_in_sentence


def check(candidate):

    # Check some simple cases
    assert candidate("This is a test") == "is"
    assert candidate("lets go for swimming") == "go for"
    assert candidate("there is no place available here") == "there is no place"
    assert candidate("Hi I am Hussein") == "Hi am Hussein"
    assert candidate("go for it") == "go for it"

    # Check some edge cases that are easy to work out by hand.
    assert candidate("here") == ""
    assert candidate("here is") == "is"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
