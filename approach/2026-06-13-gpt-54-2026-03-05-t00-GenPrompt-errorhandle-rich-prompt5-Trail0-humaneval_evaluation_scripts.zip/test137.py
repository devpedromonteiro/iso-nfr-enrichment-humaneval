
import unittest
import re
import sys
import math
import copy


def compare_one(a, b):
    """
    Compare two real-number values provided as int, float, or numeric strings.

    Returns:
        The larger original argument, preserving its original type.
        Returns None if the numeric values are equal.

    Accepted inputs:
        - int
        - float
        - str representing a real number, using '.' or ',' as decimal separator

    Raises:
        TypeError: if an argument is not int, float, or str
        ValueError: if a string argument does not represent a valid real number
    """

    def to_number(value, name):
        if isinstance(value, bool):
            raise TypeError(f"{name} must be int, float, or numeric string, not bool")

        if isinstance(value, (int, float)):
            return float(value)

        if isinstance(value, str):
            normalized = value.strip()
            if not normalized:
                raise ValueError(f"{name} cannot be an empty string")

            normalized = normalized.replace(",", ".")

            try:
                return float(normalized)
            except ValueError as exc:
                raise ValueError(
                    f"{name} must be a valid real number string, got {value!r}"
                ) from exc

        raise TypeError(
            f"{name} must be int, float, or numeric string, got {type(value).__name__}"
        )

    num_a = to_number(a, "a")
    num_b = to_number(b, "b")

    if num_a > num_b:
        return a
    if num_b > num_a:
        return b
    return None
candidate = compare_one


def check(candidate):

    # Check some simple cases
    assert candidate(1, 2) == 2
    assert candidate(1, 2.5) == 2.5
    assert candidate(2, 3) == 3
    assert candidate(5, 6) == 6
    assert candidate(1, "2,3") == "2,3"
    assert candidate("5,1", "6") == "6"
    assert candidate("1", "2") == "2"
    assert candidate("1", 1) == None

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
