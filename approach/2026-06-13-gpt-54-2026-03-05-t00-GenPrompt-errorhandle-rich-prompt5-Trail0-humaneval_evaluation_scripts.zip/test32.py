
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[2] * x^2 + .... + xs[n] * x^n
    """
    if not isinstance(xs, list):
        raise TypeError("xs must be a list of numeric coefficients")
    if len(xs) == 0:
        raise ValueError("xs must not be empty")
    if not isinstance(x, (int, float)):
        raise TypeError("x must be a numeric value")

    for i, coeff in enumerate(xs):
        if not isinstance(coeff, (int, float)):
            raise TypeError(f"coefficient at index {i} must be numeric")

    return sum(coeff * math.pow(x, i) for i, coeff in enumerate(xs))


def find_zero(xs: list):
    """xs are coefficients of a polynomial.
    find_zero finds x such that poly(x) = 0.
    find_zero returns only one zero point, even if there are many.
    Moreover, find_zero only takes list xs having even number of coefficients
    and largest non-zero coefficient as it guarantees a solution.

    >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2)  # (x - 1) * (x - 2) * (x - 3)
    1.0
    """
    if not isinstance(xs, list):
        raise TypeError("xs must be a list of numeric coefficients")
    if len(xs) == 0:
        raise ValueError("xs must not be empty")
    if len(xs) % 2 != 0:
        raise ValueError("xs must contain an even number of coefficients")

    for i, coeff in enumerate(xs):
        if not isinstance(coeff, (int, float)):
            raise TypeError(f"coefficient at index {i} must be numeric")

    if all(coeff == 0 for coeff in xs):
        raise ValueError("polynomial must not be the zero polynomial")

    degree = len(xs) - 1
    leading = xs[-1]
    if leading == 0:
        raise ValueError("largest-degree coefficient must be non-zero")

    # For an odd-degree polynomial, a real root is guaranteed.
    if degree % 2 == 0:
        raise ValueError("polynomial degree must be odd to guarantee a real root")

    def f(v):
        return poly(xs, v)

    # Handle exact zero at x = 0 early.
    f0 = f(0.0)
    if f0 == 0:
        return 0.0

    # Find a bracket [left, right] such that f(left) and f(right) have opposite signs.
    left, right = -1.0, 1.0
    f_left, f_right = f(left), f(right)

    max_expand = 10_000
    expand_count = 0
    while f_left * f_right > 0:
        left *= 2.0
        right *= 2.0
        f_left, f_right = f(left), f(right)
        expand_count += 1
        if expand_count > max_expand:
            raise RuntimeError("failed to bracket a root for the polynomial")

    if f_left == 0:
        return left
    if f_right == 0:
        return right

    # Bisection method on the valid bracket.
    tolerance = 1e-12
    max_iter = 10_000

    for _ in range(max_iter):
        mid = (left + right) / 2.0
        f_mid = f(mid)

        if abs(f_mid) < tolerance or abs(right - left) < tolerance:
            return mid

        if f_left * f_mid < 0:
            right = mid
            f_right = f_mid
        else:
            left = mid
            f_left = f_mid

    raise RuntimeError("bisection did not converge")
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
