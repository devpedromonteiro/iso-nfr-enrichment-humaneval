
import unittest
import re
import sys
import math
import copy


def sorted_list_sum(lst):
    """Accept a list of strings, remove strings with odd lengths, and return
    the remaining strings sorted by length ascending, then alphabetically.

    Args:
        lst: A list of strings.

    Returns:
        A new sorted list containing only strings of even length.

    Raises:
        TypeError: If lst is not a list or any element is not a string.
        ValueError: If lst is None.
    """
    if lst is None:
        raise ValueError("Input list cannot be None.")
    if not isinstance(lst, list):
        raise TypeError("Input must be a list.")
    if not all(isinstance(item, str) for item in lst):
        raise TypeError("All elements in the list must be strings.")

    try:
        filtered = [item for item in lst if len(item) % 2 == 0]
        return sorted(filtered, key=lambda s: (len(s), s))
    except TypeError as exc:
        raise TypeError("Failed to process or sort the list of strings.") from exc
candidate = sorted_list_sum


def check(candidate):

    # Check some simple cases
    assert candidate(["aa", "a", "aaa"]) == ["aa"]
    assert candidate(["school", "AI", "asdf", "b"]) == ["AI", "asdf", "school"]
    assert candidate(["d", "b", "c", "a"]) == []
    assert candidate(["d", "dcba", "abcd", "a"]) == ["abcd", "dcba"]

    # Check some edge cases that are easy to work out by hand.
    assert candidate(["AI", "ai", "au"]) == ["AI", "ai", "au"]
    assert candidate(["a", "b", "b", "c", "c", "a"]) == []
    assert candidate(['aaaa', 'bbbb', 'dd', 'cc']) == ["cc", "dd", "aaaa", "bbbb"]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
