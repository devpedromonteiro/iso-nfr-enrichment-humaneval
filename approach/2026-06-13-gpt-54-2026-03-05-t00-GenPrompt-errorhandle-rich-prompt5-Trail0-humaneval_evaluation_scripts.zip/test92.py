
import unittest
import re
import sys
import math
import copy


def any_int(x, y, z):
    '''
    Create a function that takes 3 numbers.
    Returns true if one of the numbers is equal to the sum of the other two, and all numbers are integers.
    Returns false in any other cases.
    
    Examples
    any_int(5, 2, 7) â True
    
    any_int(3, 2, 2) â False

    any_int(3, -2, 1) â True
    
    any_int(3.6, -2.2, 2) â False
    '''
    # Validate argument presence/type explicitly.
    for name, value in (("x", x), ("y", y), ("z", z)):
        if value is None:
            raise ValueError(f"{name} must not be None")
        if isinstance(value, bool):
            raise TypeError(f"{name} must be an integer or numeric value, not bool")
        if not isinstance(value, (int, float)):
            raise TypeError(f"{name} must be an int or float, got {type(value).__name__}")

    # If any value is not an integer-valued number, return False.
    if not all(isinstance(v, int) or (isinstance(v, float) and v.is_integer()) for v in (x, y, z)):
        return False

    # Normalize integer-valued floats safely to ints.
    try:
        a, b, c = int(x), int(y), int(z)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError("Failed to convert inputs to integers safely") from exc

    return a == b + c or b == a + c or c == a + b
candidate = any_int


def check(candidate):

    # Check some simple cases
    assert candidate(2, 3, 1)==True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(2.5, 2, 3)==False, "This prints if this assert fails 2 (good for debugging!)"
    assert candidate(1.5, 5, 3.5)==False, "This prints if this assert fails 3 (good for debugging!)"
    assert candidate(2, 6, 2)==False, "This prints if this assert fails 4 (good for debugging!)"
    assert candidate(4, 2, 2)==True, "This prints if this assert fails 5 (good for debugging!)"
    assert candidate(2.2, 2.2, 2.2)==False, "This prints if this assert fails 6 (good for debugging!)"
    assert candidate(-4, 6, 2)==True, "This prints if this assert fails 7 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(2,1,1)==True, "This prints if this assert fails 8 (also good for debugging!)"
    assert candidate(3,4,7)==True, "This prints if this assert fails 9 (also good for debugging!)"
    assert candidate(3.0,4,7)==False, "This prints if this assert fails 10 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
