
import unittest
import re
import sys
import math
import copy



def largest_prime_factor(n: int):
    """Return the largest prime factor of n.

    Args:
        n: Integer greater than 1 and not prime.

    Returns:
        The largest prime factor of n.

    Raises:
        TypeError: If n is not an integer.
        ValueError: If n <= 1 or if n is prime.

    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if n <= 1:
        raise ValueError("n must be greater than 1")

    original_n = n
    largest = None

    while n % 2 == 0:
        largest = 2
        n //= 2

    factor = 3
    while factor * factor <= n:
        while n % factor == 0:
            largest = factor
            n //= factor
        factor += 2

    if n > 1:
        if largest is None:
            raise ValueError(f"{original_n} is prime; expected a composite integer")
        largest = n

    if largest is None:
        raise ValueError(f"{original_n} has no prime factors under the given constraints")

    return largest
candidate = largest_prime_factor




METADATA = {}


def check(candidate):
    assert candidate(15) == 5
    assert candidate(27) == 3
    assert candidate(63) == 7
    assert candidate(330) == 11
    assert candidate(13195) == 29



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
