
import unittest
import re
import sys
import math
import copy


def encode(message):
    """
    Encode a message by:
    1. Swapping the case of all letters.
    2. Replacing vowels with the letter 2 places ahead in the alphabet.

    Assumptions:
    - Input must be a string.
    - Only alphabetic characters and spaces are allowed.

    Examples:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """
    if message is None:
        raise TypeError("message must be a string, got None")
    if not isinstance(message, str):
        raise TypeError(f"message must be a string, got {type(message).__name__}")

    vowels = {'a': 'c', 'e': 'g', 'i': 'k', 'o': 'q', 'u': 'w'}
    result = []

    for ch in message:
        if not (ch.isalpha() or ch == ' '):
            raise ValueError(f"message contains invalid character: {ch!r}")

        if ch == ' ':
            result.append(ch)
            continue

        swapped = ch.swapcase()
        lower_swapped = swapped.lower()

        if lower_swapped in vowels:
            replacement = vowels[lower_swapped]
            if swapped.isupper():
                result.append(replacement.upper())
            else:
                result.append(replacement.lower())
        else:
            result.append(swapped)

    return ''.join(result)
candidate = encode


def check(candidate):

    # Check some simple cases
    assert candidate('TEST') == 'tgst', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('Mudasir') == 'mWDCSKR', "This prints if this assert fails 2 (good for debugging!)"
    assert candidate('YES') == 'ygs', "This prints if this assert fails 3 (good for debugging!)"
    
    # Check some edge cases that are easy to work out by hand.
    assert candidate('This is a message') == 'tHKS KS C MGSSCGG', "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate("I DoNt KnOw WhAt tO WrItE") == 'k dQnT kNqW wHcT Tq wRkTg', "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
