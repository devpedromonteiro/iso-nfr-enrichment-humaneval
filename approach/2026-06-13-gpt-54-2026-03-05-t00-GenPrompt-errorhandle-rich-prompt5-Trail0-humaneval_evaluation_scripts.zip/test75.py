
import unittest
import re
import sys
import math
import copy


def is_multiply_prime(a):
    """Return True if `a` is the product of exactly 3 prime numbers, else False.

    A prime factor may repeat, so values like 8 = 2 * 2 * 2 return True.

    Constraints handled:
    - validates input type explicitly
    - validates input range explicitly
    - raises specific exceptions for invalid arguments
    """
    if isinstance(a, bool) or not isinstance(a, int):
        raise TypeError("a must be an integer")
    if a < 0:
        raise ValueError("a must be non-negative")
    if a >= 100:
        raise ValueError("a must be less than 100")

    if a < 8:  # smallest product of 3 primes is 2 * 2 * 2
        return False

    def is_prime(n):
        if n < 2:
            return False
        for i in range(2, int(n ** 0.5) + 1):
            if n % i == 0:
                return False
        return True

    prime_factors_count = 0
    remaining = a

    factor = 2
    while factor * factor <= remaining and prime_factors_count <= 3:
        while remaining % factor == 0:
            if not is_prime(factor):
                return False
            prime_factors_count += 1
            remaining //= factor
        factor += 1

    if remaining > 1:
        if not is_prime(remaining):
            return False
        prime_factors_count += 1

    return prime_factors_count == 3
candidate = is_multiply_prime


def check(candidate):

    assert candidate(5) == False
    assert candidate(30) == True
    assert candidate(8) == True
    assert candidate(10) == False
    assert candidate(125) == True
    assert candidate(3 * 5 * 7) == True
    assert candidate(3 * 6 * 7) == False
    assert candidate(9 * 9 * 9) == False
    assert candidate(11 * 9 * 9) == False
    assert candidate(11 * 13 * 7) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
