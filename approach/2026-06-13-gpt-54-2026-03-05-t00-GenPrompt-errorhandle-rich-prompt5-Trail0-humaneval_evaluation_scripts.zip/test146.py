
import unittest
import re
import sys
import math
import copy


def specialFilter(nums):
    """Return the count of numbers > 10 whose first and last digits are odd.

    Rules:
    - Input must be a list or tuple of integers.
    - Values greater than 10 are considered.
    - For qualifying values, both the first and last decimal digits must be odd.

    Examples:
        specialFilter([15, -73, 14, -15]) -> 1
        specialFilter([33, -2, -3, 45, 21, 109]) -> 2
    """
    if nums is None:
        raise TypeError("nums cannot be None")

    if not isinstance(nums, (list, tuple)):
        raise TypeError("nums must be a list or tuple of integers")

    count = 0

    for index, value in enumerate(nums):
        if isinstance(value, bool) or not isinstance(value, int):
            raise TypeError(
                f"nums[{index}] must be an integer, got {type(value).__name__}"
            )

        if value > 10:
            digits = str(abs(value))
            first_digit = int(digits[0])
            last_digit = int(digits[-1])

            if first_digit % 2 == 1 and last_digit % 2 == 1:
                count += 1

    return count
candidate = specialFilter


def check(candidate):

    # Check some simple cases
    assert candidate([5, -2, 1, -5]) == 0  
    assert candidate([15, -73, 14, -15]) == 1
    assert candidate([33, -2, -3, 45, 21, 109]) == 2
    assert candidate([43, -12, 93, 125, 121, 109]) == 4
    assert candidate([71, -2, -33, 75, 21, 19]) == 3


    # Check some edge cases that are easy to work out by hand.
    assert candidate([1]) == 0              
    assert candidate([]) == 0                   



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
