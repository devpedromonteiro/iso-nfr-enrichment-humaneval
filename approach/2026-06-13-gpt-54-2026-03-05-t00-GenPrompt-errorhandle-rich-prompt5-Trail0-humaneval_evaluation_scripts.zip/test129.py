
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Given a grid with N rows and N columns (N >= 2) and a positive integer k,
    return the lexicographically minimum path of length k.

    Error handling:
    - Validates input types and values explicitly.
    - Raises specific exceptions for invalid arguments.
    - Does not mutate input, so error paths do not leave inconsistent state.
    """
    # Validate grid container
    if not isinstance(grid, list):
        raise TypeError("grid must be a list of lists")

    if not grid:
        raise ValueError("grid must not be empty")

    n = len(grid)

    if n < 2:
        raise ValueError("grid must have at least 2 rows")

    # Validate rows
    for i, row in enumerate(grid):
        if not isinstance(row, list):
            raise TypeError(f"grid row at index {i} must be a list")
        if len(row) != n:
            raise ValueError("grid must be square (N x N)")

    # Validate k
    if not isinstance(k, int):
        raise TypeError("k must be an integer")
    if k <= 0:
        raise ValueError("k must be a positive integer")

    # Validate grid values: integers 1..N*N each exactly once
    expected_values = set(range(1, n * n + 1))
    seen_values = set()

    for i, row in enumerate(grid):
        for j, value in enumerate(row):
            if not isinstance(value, int):
                raise TypeError(f"grid[{i}][{j}] must be an integer")
            if value not in expected_values:
                raise ValueError(
                    f"grid[{i}][{j}] must be in the range [1, {n * n}]"
                )
            if value in seen_values:
                raise ValueError(f"duplicate value found in grid: {value}")
            seen_values.add(value)

    if seen_values != expected_values:
        missing = expected_values - seen_values
        raise ValueError(f"grid must contain every integer in [1, {n * n}] exactly once; missing: {sorted(missing)}")

    # Build value -> position map
    positions = {}
    for i in range(n):
        for j in range(n):
            positions[grid[i][j]] = (i, j)

    # Helper to get neighbors
    def neighbors(r, c):
        result = []
        if r > 0:
            result.append((r - 1, c))
        if r < n - 1:
            result.append((r + 1, c))
        if c > 0:
            result.append((r, c - 1))
        if c < n - 1:
            result.append((r, c + 1))
        return result

    # Since values are unique from 1..N*N, the lexicographically smallest path
    # starts from the smallest possible value that can be extended to length k.
    # Any cell can always be extended to any length >= 1 by moving back and forth
    # with a neighbor, because N >= 2 guarantees every cell has at least one neighbor.
    #
    # Therefore:
    # - First value must be 1.
    # - Each next step should go to the neighboring cell with the smallest value.
    #
    # This greedy choice is correct for lexicographic minimization.
    start_r, start_c = positions[1]
    path = [1]
    r, c = start_r, start_c

    for _ in range(k - 1):
        nbrs = neighbors(r, c)
        if not nbrs:
            # Defensive check; should never happen for valid N >= 2 grids.
            raise RuntimeError("no valid neighbor found; grid is in an unexpected state")

        try:
            next_r, next_c = min(nbrs, key=lambda pos: grid[pos[0]][pos[1]])
        except (IndexError, TypeError) as exc:
            raise RuntimeError("failed to evaluate neighboring cells") from exc

        path.append(grid[next_r][next_c])
        r, c = next_r, next_c

    return path
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
