
import unittest
import re
import sys
import math
import copy



def unique(l: list):
    """Return sorted unique elements in a list.

    Args:
        l: A list of comparable elements.

    Returns:
        A sorted list containing each unique element from ``l``.

    Raises:
        TypeError: If ``l`` is not a list.
        ValueError: If elements in ``l`` cannot be sorted together.

    >>> unique([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [0, 2, 3, 5, 9, 123]
    """
    if not isinstance(l, list):
        raise TypeError(f"unique() expected a list, got {type(l).__name__}")

    try:
        return sorted(set(l))
    except TypeError as exc:
        raise ValueError(
            "unique() requires all list elements to be hashable and mutually comparable"
        ) from exc
candidate = unique




METADATA = {}


def check(candidate):
    assert candidate([5, 3, 5, 2, 3, 3, 9, 0, 123]) == [0, 2, 3, 5, 9, 123]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
