
import unittest
import re
import sys
import math
import copy


def f(n):
    """Return a list of length n where:
    - at 1-based position i:
      - value is factorial(i) if i is even
      - value is sum(1..i) if i is odd

    Example:
        f(5) == [1, 2, 6, 24, 15]
    """
    if isinstance(n, bool):
        raise TypeError("n must be an integer, not bool")
    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if n < 0:
        raise ValueError("n must be non-negative")

    result = []

    try:
        factorial = 1
        running_sum = 0

        for i in range(1, n + 1):
            running_sum += i
            factorial *= i

            if i % 2 == 0:
                result.append(factorial)
            else:
                result.append(running_sum)

        return result

    except OverflowError:
        # Re-raise specific exception without leaving partial external state.
        raise
    except MemoryError:
        # Re-raise specific exception for resource exhaustion.
        raise
candidate = f


def check(candidate):

    assert candidate(5) == [1, 2, 6, 24, 15]
    assert candidate(7) == [1, 2, 6, 24, 15, 720, 28]
    assert candidate(1) == [1]
    assert candidate(3) == [1, 2, 6]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
