
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """Input to this function is a string represented multiple groups for nested
    parentheses separated by spaces. For each group, output the deepest level of
    nesting of parentheses.

    E.g. (()()) has maximum two levels of nesting while ((())) has three.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """
    if not isinstance(paren_string, str):
        raise TypeError("paren_string must be a string")

    if paren_string == "":
        raise ValueError("paren_string must not be empty")

    groups = paren_string.split()

    if not groups:
        raise ValueError("paren_string must contain at least one parentheses group")

    results: List[int] = []

    for group in groups:
        depth = 0
        max_depth = 0

        for index, char in enumerate(group):
            if char == "(":
                depth += 1
                if depth > max_depth:
                    max_depth = depth
            elif char == ")":
                depth -= 1
                if depth < 0:
                    raise ValueError(
                        f"Unbalanced parentheses in group '{group}': "
                        f"unexpected ')' at position {index}"
                    )
            else:
                raise ValueError(
                    f"Invalid character '{char}' in group '{group}' at position {index}"
                )

        if depth != 0:
            raise ValueError(
                f"Unbalanced parentheses in group '{group}': missing {depth} closing parenthesis(es)"
            )

        results.append(max_depth)

    return results
candidate = parse_nested_parens




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('(()()) ((())) () ((())()())') == [2, 3, 1, 3]
    assert candidate('() (()) ((())) (((())))') == [1, 2, 3, 4]
    assert candidate('(()(())((())))') == [4]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
