
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    """Filter an input list of strings for ones that contain the given substring.

    Args:
        strings: A list of strings to search.
        substring: The substring to match.

    Returns:
        A new list containing only the strings that include `substring`.

    Raises:
        TypeError: If `strings` is not a list, if `substring` is not a string,
            or if any element in `strings` is not a string.

    >>> filter_by_substring([], 'a')
    []
    >>> filter_by_substring(['abc', 'bacd', 'cde', 'array'], 'a')
    ['abc', 'bacd', 'array']
    """
    if not isinstance(strings, list):
        raise TypeError("strings must be a list of strings")

    if not isinstance(substring, str):
        raise TypeError("substring must be a string")

    for index, value in enumerate(strings):
        if not isinstance(value, str):
            raise TypeError(f"strings[{index}] must be a string, got {type(value).__name__}")

    return [value for value in strings if substring in value]
candidate = filter_by_substring




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([], 'john') == []
    assert candidate(['xxx', 'asd', 'xxy', 'john doe', 'xxxAAA', 'xxx'], 'xxx') == ['xxx', 'xxxAAA', 'xxx']
    assert candidate(['xxx', 'asd', 'aaaxxy', 'john doe', 'xxxAAA', 'xxx'], 'xx') == ['xxx', 'aaaxxy', 'xxxAAA', 'xxx']
    assert candidate(['grunt', 'trumpet', 'prune', 'gruesome'], 'run') == ['grunt', 'prune']


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
