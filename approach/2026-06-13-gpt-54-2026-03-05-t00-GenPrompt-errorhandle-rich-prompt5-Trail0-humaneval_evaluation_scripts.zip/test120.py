
import unittest
import re
import sys
import math
import copy


def maximum(arr, k):
    """
    Given an array arr of integers and a positive integer k, return a sorted list
    of length k with the maximum k numbers in arr.

    Example 1:
        Input: arr = [-3, -4, 5], k = 3
        Output: [-4, -3, 5]

    Example 2:
        Input: arr = [4, -4, 4], k = 2
        Output: [4, 4]

    Example 3:
        Input: arr = [-3, 2, 1, 2, -1, -2, 1], k = 1
        Output: [2]

    Note:
        1. The length of the array will be in the range of [1, 1000].
        2. The elements in the array will be in the range of [-1000, 1000].
        3. 0 <= k <= len(arr)

    Raises:
        TypeError: If arr is not a list/tuple, if k is not an integer,
                   or if any element in arr is not an integer.
        ValueError: If arr length or values are out of allowed range,
                    or if k is outside [0, len(arr)].
    """
    if not isinstance(arr, (list, tuple)):
        raise TypeError("arr must be a list or tuple of integers")

    if not isinstance(k, int):
        raise TypeError("k must be an integer")

    if len(arr) < 1 or len(arr) > 1000:
        raise ValueError("arr length must be in the range [1, 1000]")

    if k < 0 or k > len(arr):
        raise ValueError("k must be in the range [0, len(arr)]")

    validated_arr = []
    for i, value in enumerate(arr):
        if not isinstance(value, int):
            raise TypeError(f"arr[{i}] must be an integer")
        if value < -1000 or value > 1000:
            raise ValueError(f"arr[{i}] must be in the range [-1000, 1000]")
        validated_arr.append(value)

    if k == 0:
        return []

    result = sorted(validated_arr)[-k:]
    return sorted(result)
candidate = maximum


def check(candidate):

    # Check some simple cases
    assert candidate([-3, -4, 5], 3) == [-4, -3, 5]
    assert candidate([4, -4, 4], 2) == [4, 4]
    assert candidate([-3, 2, 1, 2, -1, -2, 1], 1) == [2]
    assert candidate([123, -123, 20, 0 , 1, 2, -3], 3) == [2, 20, 123]
    assert candidate([-123, 20, 0 , 1, 2, -3], 4) == [0, 1, 2, 20]
    assert candidate([5, 15, 0, 3, -13, -8, 0], 7) == [-13, -8, 0, 0, 3, 5, 15]
    assert candidate([-1, 0, 2, 5, 3, -10], 2) == [3, 5]
    assert candidate([1, 0, 5, -7], 1) == [5]
    assert candidate([4, -4], 2) == [-4, 4]
    assert candidate([-10, 10], 2) == [-10, 10]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([1, 2, 3, -23, 243, -400, 0], 0) == []



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
