
import unittest
import re
import sys
import math
import copy


def move_one_ball(arr):
    """Determine whether a list can be sorted in non-decreasing order
    using only right circular shifts.

    A right shift moves the last element to the front.

    Args:
        arr: A list of unique integers.

    Returns:
        True if the array can be transformed into non-decreasing order
        by applying zero or more right shifts, otherwise False.
        Returns True for an empty list.

    Raises:
        TypeError: If arr is not a list or contains non-integer elements.
        ValueError: If arr contains duplicate elements.
    """
    if arr is None:
        raise TypeError("arr must be a list of integers, got None")

    if not isinstance(arr, list):
        raise TypeError(f"arr must be a list, got {type(arr).__name__}")

    for i, value in enumerate(arr):
        if not isinstance(value, int):
            raise TypeError(
                f"arr must contain only integers; found {type(value).__name__} at index {i}"
            )

    if len(arr) != len(set(arr)):
        raise ValueError("arr must contain unique elements")

    if len(arr) == 0:
        return True

    # Count how many times the order decreases.
    # A sortable-by-rotation array can have at most one such drop,
    # considering the circular connection from last to first.
    drops = 0
    n = len(arr)

    for i in range(n):
        if arr[i] > arr[(i + 1) % n]:
            drops += 1
            if drops > 1:
                return False

    return True
candidate = move_one_ball


def check(candidate):

    # Check some simple cases
    assert candidate([3, 4, 5, 1, 2])==True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([3, 5, 10, 1, 2])==True
    assert candidate([4, 3, 1, 2])==False
    # Check some edge cases that are easy to work out by hand.
    assert candidate([3, 5, 4, 1, 2])==False, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([])==True


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
