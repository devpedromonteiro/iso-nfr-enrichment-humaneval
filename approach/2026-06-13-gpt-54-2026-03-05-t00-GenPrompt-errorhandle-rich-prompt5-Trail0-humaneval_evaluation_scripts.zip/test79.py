
import unittest
import re
import sys
import math
import copy


def decimal_to_binary(decimal):
    """Convert a non-negative integer in decimal form to a wrapped binary string.

    The returned format is: "db" + binary_digits + "db"

    Examples:
        decimal_to_binary(15) -> "db1111db"
        decimal_to_binary(32) -> "db100000db"

    Raises:
        TypeError: If `decimal` is not an integer.
        ValueError: If `decimal` is negative.
    """
    if isinstance(decimal, bool):
        raise TypeError("decimal must be an integer, not bool")

    if not isinstance(decimal, int):
        raise TypeError("decimal must be an integer")

    if decimal < 0:
        raise ValueError("decimal must be non-negative")

    if decimal == 0:
        return "db0db"

    try:
        binary_digits = bin(decimal)[2:]
        return f"db{binary_digits}db"
    except (TypeError, ValueError) as exc:
        # Re-raise specific known conversion issues with context.
        raise exc
    except Exception as exc:
        # Preserve program consistency and provide explicit failure information.
        raise RuntimeError("unexpected error during decimal to binary conversion") from exc
candidate = decimal_to_binary


def check(candidate):

    # Check some simple cases
    assert candidate(0) == "db0db"
    assert candidate(32) == "db100000db"
    assert candidate(103) == "db1100111db"
    assert candidate(15) == "db1111db", "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
