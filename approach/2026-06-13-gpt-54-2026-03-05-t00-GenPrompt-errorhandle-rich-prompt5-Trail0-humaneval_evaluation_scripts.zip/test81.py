
import unittest
import re
import sys
import math
import copy


def numerical_letter_grade(grades):
    """Convert a list of GPA values to letter grades.

    Mapping:
         4.0  -> A+
        >3.7  -> A
        >3.3  -> A-
        >3.0  -> B+
        >2.7  -> B
        >2.3  -> B-
        >2.0  -> C+
        >1.7  -> C
        >1.3  -> C-
        >1.0  -> D+
        >0.7  -> D
        >0.0  -> D-
         0.0  -> E

    Args:
        grades: iterable of numeric GPA values in the range [0.0, 4.0]

    Returns:
        list[str]: corresponding letter grades

    Raises:
        TypeError: if grades is not an iterable of numbers
        ValueError: if any GPA is outside the valid range [0.0, 4.0]
    """
    if grades is None:
        raise TypeError("grades must be an iterable of numeric GPA values, got None")

    if isinstance(grades, (str, bytes)):
        raise TypeError("grades must be an iterable of numeric GPA values, not a string/bytes")

    try:
        iterator = iter(grades)
    except TypeError as exc:
        raise TypeError("grades must be an iterable of numeric GPA values") from exc

    result = []

    for i, grade in enumerate(iterator):
        if isinstance(grade, bool) or not isinstance(grade, (int, float)):
            raise TypeError(f"grade at index {i} must be a number, got {type(grade).__name__}")

        if grade < 0.0 or grade > 4.0:
            raise ValueError(f"grade at index {i} must be between 0.0 and 4.0, got {grade}")

        if grade == 4.0:
            result.append("A+")
        elif grade > 3.7:
            result.append("A")
        elif grade > 3.3:
            result.append("A-")
        elif grade > 3.0:
            result.append("B+")
        elif grade > 2.7:
            result.append("B")
        elif grade > 2.3:
            result.append("B-")
        elif grade > 2.0:
            result.append("C+")
        elif grade > 1.7:
            result.append("C")
        elif grade > 1.3:
            result.append("C-")
        elif grade > 1.0:
            result.append("D+")
        elif grade > 0.7:
            result.append("D")
        elif grade > 0.0:
            result.append("D-")
        else:  # grade == 0.0
            result.append("E")

    return result
candidate = numerical_letter_grade


def check(candidate):

    # Check some simple cases
    assert candidate([4.0, 3, 1.7, 2, 3.5]) == ['A+', 'B', 'C-', 'C', 'A-']
    assert candidate([1.2]) == ['D+']
    assert candidate([0.5]) == ['D-']
    assert candidate([0.0]) == ['E']
    assert candidate([1, 0.3, 1.5, 2.8, 3.3]) == ['D', 'D-', 'C-', 'B', 'B+']
    assert candidate([0, 0.7]) == ['E', 'D-']

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
