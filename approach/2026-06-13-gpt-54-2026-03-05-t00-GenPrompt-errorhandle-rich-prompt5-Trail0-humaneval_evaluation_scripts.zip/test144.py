
import unittest
import re
import sys
import math
import copy


from math import gcd


def simplify(x, n):
    """Return True if the product of fractions x and n is a whole number.

    Both x and n must be strings in the form "<numerator>/<denominator>",
    where numerator and denominator are positive whole numbers.

    Examples:
        simplify("1/5", "5/1") -> True
        simplify("1/6", "2/1") -> False
        simplify("7/10", "10/2") -> False
    """

    def parse_fraction(value, name):
        if not isinstance(value, str):
            raise TypeError(f"{name} must be a string in the form 'a/b'")

        parts = value.split("/")
        if len(parts) != 2:
            raise ValueError(f"{name} must be in the form 'a/b'")

        numerator_str, denominator_str = parts

        if not numerator_str or not denominator_str:
            raise ValueError(f"{name} must contain both numerator and denominator")

        if not numerator_str.isdigit() or not denominator_str.isdigit():
            raise ValueError(
                f"{name} must contain positive whole numbers only"
            )

        numerator = int(numerator_str)
        denominator = int(denominator_str)

        if numerator <= 0 or denominator <= 0:
            raise ValueError(
                f"{name} must contain positive whole numbers greater than zero"
            )

        return numerator, denominator

    x_num, x_den = parse_fraction(x, "x")
    n_num, n_den = parse_fraction(n, "n")

    # Reduce cross factors safely before multiplication to avoid unnecessary growth.
    g1 = gcd(x_num, n_den)
    x_num //= g1
    n_den //= g1

    g2 = gcd(n_num, x_den)
    n_num //= g2
    x_den //= g2

    # Product is a whole number iff the reduced denominator is 1.
    return x_den * n_den == 1
candidate = simplify


def check(candidate):

    # Check some simple cases
    assert candidate("1/5", "5/1") == True, 'test1'
    assert candidate("1/6", "2/1") == False, 'test2'
    assert candidate("5/1", "3/1") == True, 'test3'
    assert candidate("7/10", "10/2") == False, 'test4'
    assert candidate("2/10", "50/10") == True, 'test5'
    assert candidate("7/2", "4/2") == True, 'test6'
    assert candidate("11/6", "6/1") == True, 'test7'
    assert candidate("2/3", "5/2") == False, 'test8'
    assert candidate("5/2", "3/5") == False, 'test9'
    assert candidate("2/4", "8/4") == True, 'test10'


    # Check some edge cases that are easy to work out by hand.
    assert candidate("2/4", "4/2") == True, 'test11'
    assert candidate("1/5", "5/1") == True, 'test12'
    assert candidate("1/5", "1/5") == False, 'test13'



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
