
import unittest
import re
import sys
import math
import copy


def by_length(arr):
    """
    Given an array of integers, sort the integers that are between 1 and 9 inclusive,
    reverse the resulting array, and then replace each digit by its corresponding name.

    Rules:
    - Return [] for an empty input.
    - Ignore values outside the range 1..9.
    - Validate inputs explicitly and raise specific exceptions for invalid arguments.
    """
    digit_names = {
        1: "One",
        2: "Two",
        3: "Three",
        4: "Four",
        5: "Five",
        6: "Six",
        7: "Seven",
        8: "Eight",
        9: "Nine",
    }

    if arr is None:
        raise TypeError("arr must be a list or tuple of integers, got None")

    if not isinstance(arr, (list, tuple)):
        raise TypeError(f"arr must be a list or tuple of integers, got {type(arr).__name__}")

    if len(arr) == 0:
        return []

    valid_digits = []

    for index, value in enumerate(arr):
        if isinstance(value, bool):
            raise TypeError(f"arr[{index}] must be an integer between 1 and 9 or an ignorable integer, got bool")
        if not isinstance(value, int):
            raise TypeError(f"arr[{index}] must be an integer, got {type(value).__name__}")

        if 1 <= value <= 9:
            valid_digits.append(value)

    try:
        valid_digits.sort()
        valid_digits.reverse()
        return [digit_names[digit] for digit in valid_digits]
    except KeyError as exc:
        raise ValueError(f"Unexpected digit encountered during conversion: {exc.args[0]}") from exc
candidate = by_length


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([2, 1, 1, 4, 5, 8, 2, 3]) == ["Eight", "Five", "Four", "Three", "Two", "Two", "One", "One"], "Error"
    assert candidate([]) == [], "Error"
    assert candidate([1, -1 , 55]) == ['One'], "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([1, -1, 3, 2]) == ["Three", "Two", "One"]
    assert candidate([9, 4, 8]) == ["Nine", "Eight", "Four"]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
