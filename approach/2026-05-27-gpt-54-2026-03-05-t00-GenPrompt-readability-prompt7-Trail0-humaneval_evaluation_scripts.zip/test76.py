
import unittest
import re
import sys
import math
import copy


def is_simple_power(x, n):
    """
    Return True if x can be written as n**k for some non-negative integer k.
    Otherwise, return False.

    Examples:
    is_simple_power(1, 4) -> True   # 4**0 = 1
    is_simple_power(2, 2) -> True   # 2**1 = 2
    is_simple_power(8, 2) -> True   # 2**3 = 8
    is_simple_power(3, 2) -> False
    is_simple_power(3, 1) -> False
    is_simple_power(5, 3) -> False
    """
    # Any number to the power of 0 is 1
    if x == 1:
        return True

    # 1 raised to any power is always 1, so it cannot produce other values
    if n == 1:
        return False

    # Keep dividing x by n while it is evenly divisible
    while x % n == 0:
        x //= n

    # If we reduced x to 1, then x was a power of n
    return x == 1
candidate = is_simple_power


def check(candidate):

    # Check some simple cases
    assert candidate(16, 2)== True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(143214, 16)== False, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(4, 2)==True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(9, 3)==True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(16, 4)==True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(24, 2)==False, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(128, 4)==False, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(12, 6)==False, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1, 1)==True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate(1, 12)==True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
