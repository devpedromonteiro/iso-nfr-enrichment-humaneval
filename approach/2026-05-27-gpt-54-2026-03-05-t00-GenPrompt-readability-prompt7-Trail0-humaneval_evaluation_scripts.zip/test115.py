
import unittest
import re
import sys
import math
import copy


import math

def max_fill(grid, capacity):
    """
    Calculate how many times buckets must be lowered to empty all wells.

    Each row in `grid` represents one well.
    Each `1` represents one unit of water in that well.
    A bucket with size `capacity` is assigned to each well.

    For each well:
        lowers_needed = ceil(units_of_water / capacity)

    The total answer is the sum across all wells.

    Examples:
        max_fill([[0,0,1,0], [0,1,0,0], [1,1,1,1]], 1) -> 6
        max_fill([[0,0,1,1], [0,0,0,0], [1,1,1,1], [0,1,1,1]], 2) -> 5
        max_fill([[0,0,0], [0,0,0]], 5) -> 0
    """
    total_lowers = 0

    for well in grid:
        water_units = sum(well)
        lowers_for_well = math.ceil(water_units / capacity)
        total_lowers += lowers_for_well

    return total_lowers
candidate = max_fill


def check(candidate):


    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([[0,0,1,0], [0,1,0,0], [1,1,1,1]], 1) == 6, "Error"
    assert candidate([[0,0,1,1], [0,0,0,0], [1,1,1,1], [0,1,1,1]], 2) == 5, "Error"
    assert candidate([[0,0,0], [0,0,0]], 5) == 0, "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([[1,1,1,1], [1,1,1,1]], 2) == 4, "Error"
    assert candidate([[1,1,1,1], [1,1,1,1]], 9) == 2, "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
