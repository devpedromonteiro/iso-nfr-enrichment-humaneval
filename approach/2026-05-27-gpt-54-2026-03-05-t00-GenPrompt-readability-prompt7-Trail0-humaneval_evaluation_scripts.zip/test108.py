
import unittest
import re
import sys
import math
import copy


def count_nums(arr):
    """
    Return the number of integers in arr whose signed digit sum is > 0.

    A negative number contributes a negative first digit:
    -123 -> -1 + 2 + 3 = 4

    Examples:
    >>> count_nums([])
    0
    >>> count_nums([-1, 11, -11])
    1
    >>> count_nums([1, 1, 2])
    3
    """

    def signed_digit_sum(n):
        digits = str(n)
        total = 0

        if digits[0] == "-":
            total -= int(digits[1])
            digits = digits[2:]
        else:
            total += int(digits[0])
            digits = digits[1:]

        for ch in digits:
            total += int(ch)

        return total

    return sum(1 for num in arr if signed_digit_sum(num) > 0)
candidate = count_nums


def check(candidate):

    # Check some simple cases
    assert candidate([]) == 0
    assert candidate([-1, -2, 0]) == 0
    assert candidate([1, 1, 2, -2, 3, 4, 5]) == 6
    assert candidate([1, 6, 9, -6, 0, 1, 5]) == 5
    assert candidate([1, 100, 98, -7, 1, -1]) == 4
    assert candidate([12, 23, 34, -45, -56, 0]) == 5
    assert candidate([-0, 1**0]) == 1
    assert candidate([1]) == 1

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
