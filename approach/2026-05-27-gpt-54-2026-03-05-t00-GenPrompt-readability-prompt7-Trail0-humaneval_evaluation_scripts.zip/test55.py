
import unittest
import re
import sys
import math
import copy



def fib(n: int) -> int:
    """Return the n-th Fibonacci number.

    The Fibonacci sequence is:
    0, 1, 1, 2, 3, 5, 8, ...

    This function uses an iterative approach for readability and efficiency.

    Args:
        n: The position in the Fibonacci sequence (must be >= 0).

    Returns:
        The n-th Fibonacci number.

    Raises:
        ValueError: If n is negative.

    Examples:
        >>> fib(10)
        55
        >>> fib(1)
        1
        >>> fib(8)
        21
        >>> fib(0)
        0
    """
    if n < 0:
        raise ValueError("n must be non-negative")

    if n == 0:
        return 0
    if n == 1:
        return 1

    previous, current = 0, 1
    for _ in range(2, n + 1):
        previous, current = current, previous + current

    return current
candidate = fib




METADATA = {}


def check(candidate):
    assert candidate(10) == 55
    assert candidate(1) == 1
    assert candidate(8) == 21
    assert candidate(11) == 89
    assert candidate(12) == 144



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
