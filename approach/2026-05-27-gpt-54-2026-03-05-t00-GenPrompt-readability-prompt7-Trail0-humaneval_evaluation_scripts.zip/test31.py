
import unittest
import re
import sys
import math
import copy



def is_prime(n):
    """Return True if n is prime, and False otherwise.

    A prime number is an integer greater than 1 that has no positive
    divisors other than 1 and itself.

    >>> is_prime(6)
    False
    >>> is_prime(101)
    True
    >>> is_prime(11)
    True
    >>> is_prime(13441)
    True
    >>> is_prime(61)
    True
    >>> is_prime(4)
    False
    >>> is_prime(1)
    False
    """
    # Numbers less than 2 are not prime.
    if n < 2:
        return False

    # 2 is the only even prime number.
    if n == 2:
        return True

    # Any other even number is not prime.
    if n % 2 == 0:
        return False

    # Check only odd divisors up to the square root of n.
    divisor = 3
    while divisor * divisor <= n:
        if n % divisor == 0:
            return False
        divisor += 2

    return True
candidate = is_prime




METADATA = {}


def check(candidate):
    assert candidate(6) == False
    assert candidate(101) == True
    assert candidate(11) == True
    assert candidate(13441) == True
    assert candidate(61) == True
    assert candidate(4) == False
    assert candidate(1) == False
    assert candidate(5) == True
    assert candidate(11) == True
    assert candidate(17) == True
    assert candidate(5 * 17) == False
    assert candidate(11 * 7) == False
    assert candidate(13441 * 19) == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
