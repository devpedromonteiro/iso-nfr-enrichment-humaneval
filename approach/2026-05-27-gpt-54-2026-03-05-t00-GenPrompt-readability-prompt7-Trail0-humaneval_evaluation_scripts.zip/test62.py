
import unittest
import re
import sys
import math
import copy



from typing import List


def derivative(coefficients: List[float]) -> List[float]:
    """
    Return the derivative of a polynomial represented by its coefficients.

    The input list represents:
        coefficients[0] + coefficients[1] * x + coefficients[2] * x^2 + ...

    The derivative is returned in the same coefficient-list form.

    Examples:
    >>> derivative([3, 1, 2, 4, 5])
    [1, 4, 12, 20]
    >>> derivative([1, 2, 3])
    [2, 6]
    >>> derivative([7])
    []
    """
    return [power * coefficient for power, coefficient in enumerate(coefficients[1:], start=1)]
candidate = derivative




METADATA = {}


def check(candidate):
    assert candidate([3, 1, 2, 4, 5]) == [1, 4, 12, 20]
    assert candidate([1, 2, 3]) == [2, 6]
    assert candidate([3, 2, 1]) == [2, 2]
    assert candidate([3, 2, 1, 0, 4]) == [2, 2, 0, 16]
    assert candidate([1]) == []



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
