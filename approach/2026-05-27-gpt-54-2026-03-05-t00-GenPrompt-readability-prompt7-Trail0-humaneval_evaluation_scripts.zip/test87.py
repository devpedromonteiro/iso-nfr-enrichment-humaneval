
import unittest
import re
import sys
import math
import copy


def get_row(lst, x):
    """
    You are given a 2 dimensional data, as nested lists,
    where each row may contain a different number of columns.

    Given lst and integer x, find all occurrences of x and return
    a list of tuples in the form (row, column), starting from 0.

    Sorting rules:
    - Rows in ascending order
    - Columns within the same row in descending order

    Examples:
    get_row([
      [1, 2, 3, 4, 5, 6],
      [1, 2, 3, 4, 1, 6],
      [1, 2, 3, 4, 5, 1]
    ], 1) == [(0, 0), (1, 4), (1, 0), (2, 5), (2, 0)]

    get_row([], 1) == []

    get_row([[], [1], [1, 2, 3]], 3) == [(2, 2)]
    """
    coordinates = []

    for row_index, row in enumerate(lst):
        row_matches = []

        for col_index, value in enumerate(row):
            if value == x:
                row_matches.append((row_index, col_index))

        row_matches.sort(key=lambda coord: coord[1], reverse=True)
        coordinates.extend(row_matches)

    return coordinates
candidate = get_row


def check(candidate):

    # Check some simple cases
    assert candidate([
        [1,2,3,4,5,6],
        [1,2,3,4,1,6],
        [1,2,3,4,5,1]
    ], 1) == [(0, 0), (1, 4), (1, 0), (2, 5), (2, 0)]
    assert candidate([
        [1,2,3,4,5,6],
        [1,2,3,4,5,6],
        [1,2,3,4,5,6],
        [1,2,3,4,5,6],
        [1,2,3,4,5,6],
        [1,2,3,4,5,6]
    ], 2) == [(0, 1), (1, 1), (2, 1), (3, 1), (4, 1), (5, 1)]
    assert candidate([
        [1,2,3,4,5,6],
        [1,2,3,4,5,6],
        [1,1,3,4,5,6],
        [1,2,1,4,5,6],
        [1,2,3,1,5,6],
        [1,2,3,4,1,6],
        [1,2,3,4,5,1]
    ], 1) == [(0, 0), (1, 0), (2, 1), (2, 0), (3, 2), (3, 0), (4, 3), (4, 0), (5, 4), (5, 0), (6, 5), (6, 0)]
    assert candidate([], 1) == []
    assert candidate([[1]], 2) == []
    assert candidate([[], [1], [1, 2, 3]], 3) == [(2, 2)]

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
