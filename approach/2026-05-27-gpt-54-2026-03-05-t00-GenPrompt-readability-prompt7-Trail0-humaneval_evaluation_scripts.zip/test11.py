
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def string_xor(a: str, b: str) -> str:
    """Return the bitwise XOR of two equal-length binary strings.

    Args:
        a: A string containing only '0' and '1'.
        b: A string containing only '0' and '1'.

    Returns:
        A binary string where each character is the XOR of the
        corresponding characters in `a` and `b`.

    Raises:
        ValueError: If the strings have different lengths or contain
            characters other than '0' and '1'.

    Examples:
        >>> string_xor('010', '110')
        '100'
        >>> string_xor('111', '000')
        '111'
    """
    if len(a) != len(b):
        raise ValueError("Input strings must have the same length.")

    if any(char not in {"0", "1"} for char in a + b):
        raise ValueError("Input strings must contain only '0' and '1'.")

    result_bits: List[str] = []

    for bit_a, bit_b in zip(a, b):
        xor_bit = "0" if bit_a == bit_b else "1"
        result_bits.append(xor_bit)

    return "".join(result_bits)
candidate = string_xor




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('111000', '101010') == '010010'
    assert candidate('1', '1') == '0'
    assert candidate('0101', '0000') == '0101'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
