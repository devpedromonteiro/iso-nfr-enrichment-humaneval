
import unittest
import re
import sys
import math
import copy


def split_words(txt):
    """
    Given a string of words:
    - If it contains whitespace, return a list of words split on whitespace.
    - Else if it contains commas, return a list of words split on commas.
    - Else return the count of lowercase letters whose alphabet index is odd:
      a=0, b=1, ..., z=25.

    Examples:
    split_words("Hello world!") -> ["Hello", "world!"]
    split_words("Hello,world!") -> ["Hello", "world!"]
    split_words("abcdef") -> 3
    """
    # Split on any whitespace if present
    if any(char.isspace() for char in txt):
        return txt.split()

    # Otherwise split on commas if present
    if ',' in txt:
        return txt.split(',')

    # Otherwise count lowercase letters with odd alphabet positions
    count = 0
    for char in txt:
        if char.islower() and char.isalpha():
            if (ord(char) - ord('a')) % 2 == 1:
                count += 1

    return count
candidate = split_words


def check(candidate):

    assert candidate("Hello world!") == ["Hello","world!"]
    assert candidate("Hello,world!") == ["Hello","world!"]
    assert candidate("Hello world,!") == ["Hello","world,!"]
    assert candidate("Hello,Hello,world !") == ["Hello,Hello,world","!"]
    assert candidate("abcdef") == 3
    assert candidate("aaabb") == 2
    assert candidate("aaaBb") == 1
    assert candidate("") == 0


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
