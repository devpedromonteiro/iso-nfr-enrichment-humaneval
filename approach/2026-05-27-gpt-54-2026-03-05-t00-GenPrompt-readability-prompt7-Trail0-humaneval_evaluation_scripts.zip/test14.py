
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def all_prefixes(string: str) -> List[str]:
    """Return all non-empty prefixes of ``string`` from shortest to longest.

    >>> all_prefixes('abc')
    ['a', 'ab', 'abc']
    >>> all_prefixes('')
    []
    """
    prefixes: List[str] = []

    for end_index in range(1, len(string) + 1):
        prefix = string[:end_index]
        prefixes.append(prefix)

    return prefixes
candidate = all_prefixes




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == []
    assert candidate('asdfgh') == ['a', 'as', 'asd', 'asdf', 'asdfg', 'asdfgh']
    assert candidate('WWW') == ['W', 'WW', 'WWW']


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
