
import unittest
import re
import sys
import math
import copy


def starts_one_ends(n):
    """
    Return the count of n-digit positive integers that start or end with 1.

    An n-digit number:
    - starts with 1: 10^(n-1) possibilities
    - ends with 1:   9 * 10^(n-2) possibilities
      (first digit can be 1-9, middle digits can be anything)

    Numbers counted in both groups:
    - start and end with 1: 10^(n-2) possibilities

    By inclusion-exclusion:
        total = starts_with_1 + ends_with_1 - both

    Parameters:
        n (int): Number of digits, must be positive.

    Returns:
        int: Count of n-digit positive integers that start or end with 1.
    """
    if n <= 0:
        raise ValueError("n must be a positive integer")

    if n == 1:
        return 1

    starts_with_1 = 10 ** (n - 1)
    ends_with_1 = 9 * 10 ** (n - 2)
    starts_and_ends_with_1 = 10 ** (n - 2)

    return starts_with_1 + ends_with_1 - starts_and_ends_with_1
candidate = starts_one_ends


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(1) == 1
    assert candidate(2) == 18
    assert candidate(3) == 180
    assert candidate(4) == 1800
    assert candidate(5) == 18000

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
