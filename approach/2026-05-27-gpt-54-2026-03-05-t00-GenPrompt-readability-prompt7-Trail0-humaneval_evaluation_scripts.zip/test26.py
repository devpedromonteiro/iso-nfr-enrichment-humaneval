
import unittest
import re
import sys
import math
import copy

from typing import List


from collections import Counter
from typing import List


def remove_duplicates(numbers: List[int]) -> List[int]:
    """
    Return a new list containing only the integers that appear exactly once,
    preserving their original order.

    Args:
        numbers: A list of integers.

    Returns:
        A list of integers that occur only once in the input list.

    Examples:
        >>> remove_duplicates([1, 2, 3, 2, 4])
        [1, 3, 4]
        >>> remove_duplicates([5, 5, 5])
        []
        >>> remove_duplicates([])
        []
    """
    counts = Counter(numbers)
    return [number for number in numbers if counts[number] == 1]
candidate = remove_duplicates




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == []
    assert candidate([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert candidate([1, 2, 3, 2, 4, 3, 5]) == [1, 4, 5]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
