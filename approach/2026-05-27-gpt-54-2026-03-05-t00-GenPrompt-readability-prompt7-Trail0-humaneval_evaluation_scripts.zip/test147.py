
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    You are given a positive integer n. Create an array a of length n where:
        a[i] = i*i - i + 1   for 1 <= i <= n

    Return the number of triples (a[i], a[j], a[k]) such that:
        i < j < k
        and (a[i] + a[j] + a[k]) is divisible by 3.

    Example:
        n = 5
        a = [1, 3, 7, 13, 21]
        Valid triple count = 1
    """

    # Count how many values fall into each remainder class modulo 3.
    # Since divisibility by 3 depends only on remainders, we do not need
    # to build the full array.
    remainder_counts = [0, 0, 0]

    for i in range(1, n + 1):
        value_mod_3 = (i * i - i + 1) % 3
        remainder_counts[value_mod_3] += 1

    count_0, count_1, count_2 = remainder_counts

    def combinations_of_3(x):
        """Return C(x, 3) = x choose 3."""
        if x < 3:
            return 0
        return x * (x - 1) * (x - 2) // 6

    # Valid remainder combinations whose sum is divisible by 3:
    # (0,0,0), (1,1,1), (2,2,2), and (0,1,2)
    total_triples = (
        combinations_of_3(count_0) +
        combinations_of_3(count_1) +
        combinations_of_3(count_2) +
        count_0 * count_1 * count_2
    )

    return total_triples
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
