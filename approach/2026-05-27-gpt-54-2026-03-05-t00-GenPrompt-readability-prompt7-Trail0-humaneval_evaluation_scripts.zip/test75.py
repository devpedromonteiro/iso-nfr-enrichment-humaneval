
import unittest
import re
import sys
import math
import copy


def is_prime(number):
    """Return True if number is a prime number, otherwise False."""
    if number < 2:
        return False

    for divisor in range(2, int(number ** 0.5) + 1):
        if number % divisor == 0:
            return False

    return True


def is_multiply_prime(a):
    """Return True if a is the product of exactly 3 prime numbers, else False.

    The 3 prime numbers do not need to be distinct.
    Examples:
        30 = 2 * 3 * 5  -> True
         8 = 2 * 2 * 2  -> True
        12 = 2 * 2 * 3  -> True
    """
    if a < 8:
        return False

    for first in range(2, a + 1):
        if not is_prime(first):
            continue

        for second in range(2, a + 1):
            if not is_prime(second):
                continue

            for third in range(2, a + 1):
                if not is_prime(third):
                    continue

                if first * second * third == a:
                    return True

    return False
candidate = is_multiply_prime


def check(candidate):

    assert candidate(5) == False
    assert candidate(30) == True
    assert candidate(8) == True
    assert candidate(10) == False
    assert candidate(125) == True
    assert candidate(3 * 5 * 7) == True
    assert candidate(3 * 6 * 7) == False
    assert candidate(9 * 9 * 9) == False
    assert candidate(11 * 9 * 9) == False
    assert candidate(11 * 13 * 7) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
