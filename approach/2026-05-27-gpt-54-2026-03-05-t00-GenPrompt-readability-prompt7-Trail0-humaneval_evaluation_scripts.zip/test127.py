
import unittest
import re
import sys
import math
import copy


def intersection(interval1, interval2):
    """Return "YES" if the intersection length of two closed intervals is prime.

    Each interval is a tuple: (start, end), with start <= end.
    The intervals are closed, so both endpoints are included.

    Examples:
        intersection((1, 2), (2, 3)) -> "NO"
        intersection((-1, 1), (0, 4)) -> "NO"
        intersection((-3, -1), (-5, 5)) -> "YES"
    """

    def is_prime(number):
        """Check whether a positive integer is prime."""
        if number < 2:
            return False
        for divisor in range(2, int(number ** 0.5) + 1):
            if number % divisor == 0:
                return False
        return True

    start1, end1 = interval1
    start2, end2 = interval2

    # Find the overlapping part of the two closed intervals
    overlap_start = max(start1, start2)
    overlap_end = min(end1, end2)

    # No intersection
    if overlap_start > overlap_end:
        return "NO"

    # Length of a closed interval [a, b] is b - a
    intersection_length = overlap_end - overlap_start

    return "YES" if is_prime(intersection_length) else "NO"
candidate = intersection


def check(candidate):

    # Check some simple cases
    assert candidate((1, 2), (2, 3)) == "NO"
    assert candidate((-1, 1), (0, 4)) == "NO"
    assert candidate((-3, -1), (-5, 5)) == "YES"
    assert candidate((-2, 2), (-4, 0)) == "YES"

    # Check some edge cases that are easy to work out by hand.
    assert candidate((-11, 2), (-1, -1)) == "NO"
    assert candidate((1, 2), (3, 5)) == "NO"
    assert candidate((1, 2), (1, 2)) == "NO"
    assert candidate((-2, -2), (-3, -2)) == "NO"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
