
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math
from typing import List


def poly(coefficients: List[float], x: float) -> float:
    """
    Evaluate a polynomial at point x.

    The polynomial is defined by its coefficients:
        coefficients[0] + coefficients[1] * x + coefficients[2] * x^2 + ... + coefficients[n] * x^n

    Example:
        poly([1, 2], 3) = 1 + 2 * 3 = 7
    """
    return sum(coefficient * (x ** power) for power, coefficient in enumerate(coefficients))


def find_zero(coefficients: List[float], tolerance: float = 1e-10, max_iterations: int = 10_000) -> float:
    """
    Find one real zero of a polynomial.

    Assumptions:
    - `coefficients` has an even number of elements.
    - The highest non-zero coefficient guarantees the polynomial has at least one real root
      under the problem's constraints.

    The function returns one x such that poly(coefficients, x) ~= 0.

    Strategy:
    1. Find an interval [left, right] where the polynomial changes sign.
    2. Use binary search (bisection) to approximate a root.

    >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2)  # (x - 1) * (x - 2) * (x - 3)
    1.0
    """
    if not coefficients:
        raise ValueError("Coefficient list must not be empty.")

    def f(x: float) -> float:
        return poly(coefficients, x)

    # First, try to find a sign change by expanding outward from 0.
    left = -1.0
    right = 1.0
    f_left = f(left)
    f_right = f(right)

    # If either endpoint is already a root, return it.
    if abs(f_left) < tolerance:
        return left
    if abs(f_right) < tolerance:
        return right

    while f_left * f_right > 0:
        left *= 2
        right *= 2
        f_left = f(left)
        f_right = f(right)

        if abs(f_left) < tolerance:
            return left
        if abs(f_right) < tolerance:
            return right

    # Bisection method.
    for _ in range(max_iterations):
        mid = (left + right) / 2
        f_mid = f(mid)

        if abs(f_mid) < tolerance:
            return mid

        if f_left * f_mid <= 0:
            right = mid
            f_right = f_mid
        else:
            left = mid
            f_left = f_mid

    return (left + right) / 2
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
