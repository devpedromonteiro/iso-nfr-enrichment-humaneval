
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def mean_absolute_deviation(numbers: List[float]) -> float:
    """Calculate the mean absolute deviation around the mean.

    Mean Absolute Deviation (MAD) is the average absolute distance between
    each value in the dataset and the dataset mean.

    Formula:
        MAD = average(|x - mean|)

    Args:
        numbers: A list of numeric values.

    Returns:
        The mean absolute deviation as a float.

    Raises:
        ValueError: If the input list is empty.

    Examples:
        >>> mean_absolute_deviation([1.0, 2.0, 3.0, 4.0])
        1.0
        >>> mean_absolute_deviation([5.0, 5.0, 5.0])
        0.0
    """
    if not numbers:
        raise ValueError("numbers must not be empty")

    mean_value = sum(numbers) / len(numbers)
    absolute_deviations = [abs(number - mean_value) for number in numbers]
    return sum(absolute_deviations) / len(numbers)
candidate = mean_absolute_deviation




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert abs(candidate([1.0, 2.0, 3.0]) - 2.0/3.0) < 1e-6
    assert abs(candidate([1.0, 2.0, 3.0, 4.0]) - 1.0) < 1e-6
    assert abs(candidate([1.0, 2.0, 3.0, 4.0, 5.0]) - 6.0/5.0) < 1e-6



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
