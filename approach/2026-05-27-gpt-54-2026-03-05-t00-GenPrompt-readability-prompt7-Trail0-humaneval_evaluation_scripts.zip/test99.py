
import unittest
import re
import sys
import math
import copy


from decimal import Decimal, ROUND_HALF_UP


def closest_integer(value):
    """
    Return the nearest integer for a numeric string.

    If the value is exactly halfway between two integers, round away from zero.

    Examples:
    >>> closest_integer("10")
    10
    >>> closest_integer("15.3")
    15
    >>> closest_integer("14.5")
    15
    >>> closest_integer("-14.5")
    -15
    """
    number = Decimal(value)
    rounded = number.quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    return int(rounded)
candidate = closest_integer


def check(candidate):

    # Check some simple cases
    assert candidate("10") == 10, "Test 1"
    assert candidate("14.5") == 15, "Test 2"
    assert candidate("-15.5") == -16, "Test 3"
    assert candidate("15.3") == 15, "Test 3"

    # Check some edge cases that are easy to work out by hand.
    assert candidate("0") == 0, "Test 0"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
