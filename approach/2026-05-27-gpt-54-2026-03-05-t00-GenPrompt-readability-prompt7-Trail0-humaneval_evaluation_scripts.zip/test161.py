
import unittest
import re
import sys
import math
import copy


def solve(s):
    """
    You are given a string s.
    If s[i] is a letter, reverse its case from lower to upper or vice versa,
    otherwise keep it as it is.
    If the string contains no letters, reverse the string.

    Examples:
        solve("1234") -> "4321"
        solve("ab")   -> "AB"
        solve("#a@C") -> "#A@c"
    """

    # Check whether the string contains at least one alphabetic character
    has_letter = any(char.isalpha() for char in s)

    # If there are no letters, return the reversed string
    if not has_letter:
        return s[::-1]

    # Otherwise, swap the case of each letter and keep other characters unchanged
    return ''.join(char.swapcase() if char.isalpha() else char for char in s)
candidate = solve


def check(candidate):

    # Check some simple cases
    assert candidate("AsDf") == "aSdF"
    assert candidate("1234") == "4321"
    assert candidate("ab") == "AB"
    assert candidate("#a@C") == "#A@c"
    assert candidate("#AsdfW^45") == "#aSDFw^45"
    assert candidate("#6@2") == "2@6#"

    # Check some edge cases that are easy to work out by hand.
    assert candidate("#$a^D") == "#$A^d"
    assert candidate("#ccc") == "#CCC"

    # Don't remove this line:


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
