
import unittest
import re
import sys
import math
import copy



def fib4(n: int) -> int:
    """Return the n-th value in the Fib4 sequence.

    The Fib4 sequence is defined as:
        fib4(0) = 0
        fib4(1) = 0
        fib4(2) = 2
        fib4(3) = 0
        fib4(n) = fib4(n-1) + fib4(n-2) + fib4(n-3) + fib4(n-4) for n >= 4

    This implementation is iterative for efficiency and readability.

    >>> fib4(5)
    4
    >>> fib4(6)
    8
    >>> fib4(7)
    14
    """
    if n < 0:
        raise ValueError("n must be non-negative")

    # Base cases
    if n == 0:
        return 0
    if n == 1:
        return 0
    if n == 2:
        return 2
    if n == 3:
        return 0

    # Track the previous four sequence values:
    # fib4(i-4), fib4(i-3), fib4(i-2), fib4(i-1)
    a, b, c, d = 0, 0, 2, 0

    for _ in range(4, n + 1):
        next_value = a + b + c + d
        a, b, c, d = b, c, d, next_value

    return d
candidate = fib4




METADATA = {}


def check(candidate):
    assert candidate(5) == 4
    assert candidate(8) == 28
    assert candidate(10) == 104
    assert candidate(12) == 386



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
