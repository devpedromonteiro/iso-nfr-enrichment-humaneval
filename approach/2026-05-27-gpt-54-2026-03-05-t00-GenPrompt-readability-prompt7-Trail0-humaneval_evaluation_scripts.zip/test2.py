
import unittest
import re
import sys
import math
import copy



def truncate_number(number: float) -> float:
    """Return the decimal part of a positive floating-point number.

    A positive floating-point number can be split into:
    - an integer part
    - a decimal part (the remainder, always smaller than 1)

    Examples:
        >>> truncate_number(3.5)
        0.5
        >>> truncate_number(10.75)
        0.75
    """
    integer_part = int(number)
    decimal_part = number - integer_part
    return decimal_part
candidate = truncate_number




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(3.5) == 0.5
    assert abs(candidate(1.33) - 0.33) < 1e-6
    assert abs(candidate(123.456) - 0.456) < 1e-6


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
