
import unittest
import re
import sys
import math
import copy


def move_one_ball(arr):
    """Return True if some number of right rotations makes arr non-decreasing.

    A right shift moves the last element to the front. Since repeated right
    shifts only rotate the array, the question becomes:

    Can this array be rotated so that it is sorted in non-decreasing order?

    Strategy:
    - An already sorted array is valid.
    - A rotated sorted array with unique elements has at most one "drop",
      where arr[i] > arr[i + 1].
    - If there is exactly one drop, the last element must be less than or equal
      to the first element for the rotation to work.
    - Empty and single-element arrays are always valid.

    Examples:
        move_one_ball([3, 4, 5, 1, 2]) -> True
        move_one_ball([3, 5, 4, 1, 2]) -> False
    """
    n = len(arr)

    if n <= 1:
        return True

    drops = 0

    for i in range(n - 1):
        if arr[i] > arr[i + 1]:
            drops += 1
            if drops > 1:
                return False

    if drops == 0:
        return True

    return arr[-1] <= arr[0]
candidate = move_one_ball


def check(candidate):

    # Check some simple cases
    assert candidate([3, 4, 5, 1, 2])==True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([3, 5, 10, 1, 2])==True
    assert candidate([4, 3, 1, 2])==False
    # Check some edge cases that are easy to work out by hand.
    assert candidate([3, 5, 4, 1, 2])==False, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([])==True


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
