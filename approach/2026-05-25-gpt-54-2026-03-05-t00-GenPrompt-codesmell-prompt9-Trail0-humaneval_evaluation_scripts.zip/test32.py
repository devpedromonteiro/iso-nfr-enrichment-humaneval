
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


def poly(xs: list[float], x: float) -> float:
    """
    Evaluate a polynomial with coefficients xs at point x.

    xs[0] + xs[1] * x + xs[2] * x^2 + ... + xs[n] * x^n

    Uses Horner's method for better performance and readability.
    """
    result = 0.0
    for coeff in reversed(xs):
        result = result * x + coeff
    return result


def find_zero(xs: list[float]) -> float:
    """
    xs are coefficients of a polynomial.

    find_zero finds x such that poly(xs, x) == 0.
    It returns only one zero, even if there are many.

    Assumption:
    - xs has an even number of coefficients
    - the largest non-zero coefficient corresponds to an odd degree,
      which guarantees at least one real root

    >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2)  # (x - 1)(x - 2)(x - 3)
    1.0
    """
    if not xs:
        raise ValueError("Coefficient list must not be empty.")

    # Remove trailing zeros to get the actual degree
    while len(xs) > 1 and xs[-1] == 0:
        xs = xs[:-1]

    if xs[-1] == 0:
        raise ValueError("Polynomial must have a non-zero leading coefficient.")

    # Handle constant polynomial
    if len(xs) == 1:
        if xs[0] == 0:
            return 0.0
        raise ValueError("Non-zero constant polynomial has no root.")

    def f(x: float) -> float:
        return poly(xs, x)

    # Find an interval [left, right] where the function changes sign
    left, right = -1.0, 1.0
    f_left, f_right = f(left), f(right)

    while f_left * f_right > 0:
        left *= 2
        right *= 2
        f_left, f_right = f(left), f(right)

    # If one endpoint is already a root
    if f_left == 0:
        return left
    if f_right == 0:
        return right

    # Bisection method
    eps = 1e-12
    while right - left > eps:
        mid = (left + right) / 2
        f_mid = f(mid)

        if f_mid == 0:
            return mid
        if f_left * f_mid < 0:
            right = mid
            f_right = f_mid
        else:
            left = mid
            f_left = f_mid

    return (left + right) / 2
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
