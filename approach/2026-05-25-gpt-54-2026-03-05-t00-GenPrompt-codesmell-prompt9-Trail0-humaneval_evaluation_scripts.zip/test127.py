
import unittest
import re
import sys
import math
import copy


def intersection(interval1, interval2):
    """Return "YES" if the length of the intersection of two closed intervals is prime.

    Intervals are given as tuples: (start, end), with start <= end.
    The intersection length is computed geometrically, so for closed intervals
    (a, b) and (c, d), it is:

        min(b, d) - max(a, c)

    If they do not intersect or the length is not prime, return "NO".

    Examples:
        intersection((1, 2), (2, 3)) -> "NO"
        intersection((-1, 1), (0, 4)) -> "NO"
        intersection((-3, -1), (-5, 5)) -> "YES"
    """
    def is_prime(n):
        if n < 2:
            return False
        if n == 2:
            return True
        if n % 2 == 0:
            return False

        i = 3
        while i * i <= n:
            if n % i == 0:
                return False
            i += 2
        return True

    start = max(interval1[0], interval2[0])
    end = min(interval1[1], interval2[1])
    length = end - start

    return "YES" if length >= 0 and is_prime(length) else "NO"
candidate = intersection


def check(candidate):

    # Check some simple cases
    assert candidate((1, 2), (2, 3)) == "NO"
    assert candidate((-1, 1), (0, 4)) == "NO"
    assert candidate((-3, -1), (-5, 5)) == "YES"
    assert candidate((-2, 2), (-4, 0)) == "YES"

    # Check some edge cases that are easy to work out by hand.
    assert candidate((-11, 2), (-1, -1)) == "NO"
    assert candidate((1, 2), (3, 5)) == "NO"
    assert candidate((1, 2), (1, 2)) == "NO"
    assert candidate((-2, -2), (-3, -2)) == "NO"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
