
import unittest
import re
import sys
import math
import copy


def count_up_to(n):
    """Return a list of all prime numbers less than n.

    Examples:
        count_up_to(5) -> [2, 3]
        count_up_to(11) -> [2, 3, 5, 7]
        count_up_to(0) -> []
    """
    if n <= 2:
        return []

    sieve = [True] * n
    sieve[0] = sieve[1] = False

    for i in range(2, int(n ** 0.5) + 1):
        if sieve[i]:
            for multiple in range(i * i, n, i):
                sieve[multiple] = False

    return [i for i, is_prime in enumerate(sieve) if is_prime]
candidate = count_up_to


def check(candidate):

    assert candidate(5) == [2,3]
    assert candidate(6) == [2,3,5]
    assert candidate(7) == [2,3,5]
    assert candidate(10) == [2,3,5,7]
    assert candidate(0) == []
    assert candidate(22) == [2,3,5,7,11,13,17,19]
    assert candidate(1) == []
    assert candidate(18) == [2,3,5,7,11,13,17]
    assert candidate(47) == [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43]
    assert candidate(101) == [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
