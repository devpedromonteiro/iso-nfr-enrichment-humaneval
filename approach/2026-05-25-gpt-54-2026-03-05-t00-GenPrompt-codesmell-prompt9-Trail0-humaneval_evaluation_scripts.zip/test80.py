
import unittest
import re
import sys
import math
import copy


def is_happy(s):
    """Return True if s is happy, otherwise False.

    A string is happy if:
    - its length is at least 3
    - every 3 consecutive characters are all distinct
    """
    return len(s) >= 3 and all(
        len({s[i], s[i + 1], s[i + 2]}) == 3
        for i in range(len(s) - 2)
    )
candidate = is_happy


def check(candidate):

    # Check some simple cases
    assert candidate("a") == False , "a"
    assert candidate("aa") == False , "aa"
    assert candidate("abcd") == True , "abcd"
    assert candidate("aabb") == False , "aabb"
    assert candidate("adb") == True , "adb"
    assert candidate("xyy") == False , "xyy"
    assert candidate("iopaxpoi") == True , "iopaxpoi"
    assert candidate("iopaxioi") == False , "iopaxioi"


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
