
import unittest
import re
import sys
import math
import copy


def specialFilter(nums):
    def first_and_last_digits_odd(n):
        n = abs(n)
        if n <= 10:
            return False

        last_digit = n % 10
        first_digit = int(str(n)[0])

        return first_digit % 2 == 1 and last_digit % 2 == 1

    return sum(1 for num in nums if first_and_last_digits_odd(num))
candidate = specialFilter


def check(candidate):

    # Check some simple cases
    assert candidate([5, -2, 1, -5]) == 0  
    assert candidate([15, -73, 14, -15]) == 1
    assert candidate([33, -2, -3, 45, 21, 109]) == 2
    assert candidate([43, -12, 93, 125, 121, 109]) == 4
    assert candidate([71, -2, -33, 75, 21, 19]) == 3


    # Check some edge cases that are easy to work out by hand.
    assert candidate([1]) == 0              
    assert candidate([]) == 0                   



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
