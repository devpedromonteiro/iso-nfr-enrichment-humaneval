
import unittest
import re
import sys
import math
import copy


def sorted_list_sum(lst):
    """Return even-length strings sorted by length, then alphabetically.

    Removes all strings with odd lengths and returns the remaining strings
    sorted in ascending order by:
    1. string length
    2. alphabetical order for strings of the same length
    """
    return sorted((s for s in lst if len(s) % 2 == 0), key=lambda s: (len(s), s))
candidate = sorted_list_sum


def check(candidate):

    # Check some simple cases
    assert candidate(["aa", "a", "aaa"]) == ["aa"]
    assert candidate(["school", "AI", "asdf", "b"]) == ["AI", "asdf", "school"]
    assert candidate(["d", "b", "c", "a"]) == []
    assert candidate(["d", "dcba", "abcd", "a"]) == ["abcd", "dcba"]

    # Check some edge cases that are easy to work out by hand.
    assert candidate(["AI", "ai", "au"]) == ["AI", "ai", "au"]
    assert candidate(["a", "b", "b", "c", "c", "a"]) == []
    assert candidate(['aaaa', 'bbbb', 'dd', 'cc']) == ["cc", "dd", "aaaa", "bbbb"]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
