
import unittest
import re
import sys
import math
import copy


def is_multiply_prime(a):
    """Return True if a is the product of exactly 3 primes, else False."""

    def is_prime(n):
        if n < 2:
            return False
        for i in range(2, int(n**0.5) + 1):
            if n % i == 0:
                return False
        return True

    prime_count = 0
    divisor = 2

    while a > 1 and prime_count < 3:
        while a % divisor == 0:
            if not is_prime(divisor):
                return False
            a //= divisor
            prime_count += 1
        divisor += 1

    return prime_count == 3 and a == 1
candidate = is_multiply_prime


def check(candidate):

    assert candidate(5) == False
    assert candidate(30) == True
    assert candidate(8) == True
    assert candidate(10) == False
    assert candidate(125) == True
    assert candidate(3 * 5 * 7) == True
    assert candidate(3 * 6 * 7) == False
    assert candidate(9 * 9 * 9) == False
    assert candidate(11 * 9 * 9) == False
    assert candidate(11 * 13 * 7) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
