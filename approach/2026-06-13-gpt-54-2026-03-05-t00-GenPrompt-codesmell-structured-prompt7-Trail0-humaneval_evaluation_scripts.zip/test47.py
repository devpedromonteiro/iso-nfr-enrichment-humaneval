
import unittest
import re
import sys
import math
import copy



def _sorted_copy(values: list):
    """Return a sorted copy of the input list."""
    return sorted(values)


def _middle_index(length: int):
    """Return the middle index for a sequence length."""
    return length // 2


def _is_even(length: int):
    """Return True if length is even."""
    return length % 2 == 0


def _average(a, b):
    """Return the arithmetic mean of two numbers."""
    return (a + b) / 2


def median(l: list):
    """Return median of elements in the list l.
    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    15.0
    """
    sorted_values = _sorted_copy(l)
    length = len(sorted_values)
    middle = _middle_index(length)

    if _is_even(length):
        return _average(sorted_values[middle - 1], sorted_values[middle])

    return sorted_values[middle]
candidate = median




METADATA = {}


def check(candidate):
    assert candidate([3, 1, 2, 4, 5]) == 3
    assert candidate([-10, 4, 6, 1000, 10, 20]) == 8.0
    assert candidate([5]) == 5
    assert candidate([6, 5]) == 5.5
    assert candidate([8, 1, 3, 9, 9, 2, 7]) == 7 



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
