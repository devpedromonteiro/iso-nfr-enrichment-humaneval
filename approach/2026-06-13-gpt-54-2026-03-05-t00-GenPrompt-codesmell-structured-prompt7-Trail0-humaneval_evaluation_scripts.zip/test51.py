
import unittest
import re
import sys
import math
import copy



VOWELS = frozenset("aeiouAEIOU")


def _is_vowel(char):
    """Return True if char is a vowel, otherwise False."""
    return char in VOWELS


def remove_vowels(text):
    """
    Return a copy of text with all vowels removed.

    >>> remove_vowels('')
    ''
    >>> remove_vowels("abcdef
candidate = remove_vowels




METADATA = {}


def check(candidate):
    assert candidate('') == ''
    assert candidate("abcdef\nghijklm") == 'bcdf\nghjklm'
    assert candidate('fedcba') == 'fdcb'
    assert candidate('eeeee') == ''
    assert candidate('acBAA') == 'cB'
    assert candidate('EcBOO') == 'cB'
    assert candidate('ybcd') == 'ybcd'



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
