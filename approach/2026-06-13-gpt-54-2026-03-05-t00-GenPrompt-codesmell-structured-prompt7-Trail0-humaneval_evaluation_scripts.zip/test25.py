
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def _extract_factor(n: int, factor: int, factors: List[int]) -> int:
    """Divide out `factor` from `n` as many times as possible."""
    while n % factor == 0:
        factors.append(factor)
        n //= factor
    return n


def _candidate_factors(limit: int):
    """Yield possible prime factors greater than 2 up to sqrt(limit)."""
    factor = 3
    while factor * factor <= limit:
        yield factor
        factor += 2


def factorize(n: int) -> List[int]:
    """Return prime factors of `n` from smallest to largest.

    Each factor appears as many times as it occurs in the prime factorization.

    >>> factorize(8)
    [2, 2, 2]
    >>> factorize(25)
    [5, 5]
    >>> factorize(70)
    [2, 5, 7]
    """
    if n < 2:
        return []

    factors: List[int] = []

    n = _extract_factor(n, 2, factors)

    for factor in _candidate_factors(n):
        n = _extract_factor(n, factor, factors)
        if n == 1:
            break

    if n > 1:
        factors.append(n)

    return factors
candidate = factorize




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(2) == [2]
    assert candidate(4) == [2, 2]
    assert candidate(8) == [2, 2, 2]
    assert candidate(3 * 19) == [3, 19]
    assert candidate(3 * 19 * 3 * 19) == [3, 3, 19, 19]
    assert candidate(3 * 19 * 3 * 19 * 3 * 19) == [3, 3, 3, 19, 19, 19]
    assert candidate(3 * 19 * 19 * 19) == [3, 19, 19, 19]
    assert candidate(3 * 2 * 3) == [2, 3, 3]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
