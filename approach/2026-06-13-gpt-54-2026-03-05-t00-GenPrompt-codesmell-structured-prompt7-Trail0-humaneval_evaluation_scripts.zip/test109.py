
import unittest
import re
import sys
import math
import copy


def _count_descents(arr):
    """Return the number of positions where order decreases."""
    return sum(1 for i in range(len(arr)) if arr[i] > arr[(i + 1) % len(arr)])


def move_one_ball(arr):
    """Return True if some number of right rotations can sort the array.

    A right rotation can transform the array into sorted non-decreasing order
    iff the array is a rotation of a sorted array. With unique elements, this
    means there is at most one descent in the circular sequence.

    Empty arrays are considered sortable.
    """
    if len(arr) < 2:
        return True

    return _count_descents(arr) <= 1
candidate = move_one_ball


def check(candidate):

    # Check some simple cases
    assert candidate([3, 4, 5, 1, 2])==True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([3, 5, 10, 1, 2])==True
    assert candidate([4, 3, 1, 2])==False
    # Check some edge cases that are easy to work out by hand.
    assert candidate([3, 5, 4, 1, 2])==False, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([])==True


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
