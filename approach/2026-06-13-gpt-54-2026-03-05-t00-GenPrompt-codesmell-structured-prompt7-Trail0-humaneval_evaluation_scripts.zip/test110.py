
import unittest
import re
import sys
import math
import copy


def exchange(lst1, lst2):
    """Determine whether lst1 can be made all-even by exchanging elements with lst2.

    Since any number of exchanges is allowed, each odd number in lst1 must be
    replaced by an even number from lst2. Therefore, the transformation is
    possible iff lst2 contains at least as many even numbers as lst1 contains
    odd numbers.
    """
    odd_count_in_lst1 = _count_by_parity(lst1, want_even=False)
    even_count_in_lst2 = _count_by_parity(lst2, want_even=True)
    return "YES" if even_count_in_lst2 >= odd_count_in_lst1 else "NO"


def _count_by_parity(numbers, want_even):
    """Count numbers in `numbers` matching the requested parity."""
    return sum(1 for number in numbers if _is_even(number) == want_even)


def _is_even(number):
    """Return True if number is even, otherwise False."""
    return number % 2 == 0
candidate = exchange


def check(candidate):

    # Check some simple cases
    assert candidate([1, 2, 3, 4], [1, 2, 3, 4]) == "YES"
    assert candidate([1, 2, 3, 4], [1, 5, 3, 4]) == "NO"
    assert candidate([1, 2, 3, 4], [2, 1, 4, 3]) == "YES" 
    assert candidate([5, 7, 3], [2, 6, 4]) == "YES"
    assert candidate([5, 7, 3], [2, 6, 3]) == "NO" 
    assert candidate([3, 2, 6, 1, 8, 9], [3, 5, 5, 1, 1, 1]) == "NO"

    # Check some edge cases that are easy to work out by hand.
    assert candidate([100, 200], [200, 200]) == "YES"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
