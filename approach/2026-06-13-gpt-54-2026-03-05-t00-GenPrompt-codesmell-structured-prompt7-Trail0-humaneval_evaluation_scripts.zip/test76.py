
import unittest
import re
import sys
import math
import copy


def _handle_special_base(x, n):
    """Return the result for bases that need special-case handling."""
    if n == 0:
        return x == 1
    if n == 1:
        return x == 1
    if n == -1:
        return x in (1, -1)
    return None


def _is_power_by_division(x, n):
    """Check whether x is a power of n using repeated exact division."""
    current = x
    while current != 1:
        if current % n != 0:
            return False
        current //= n
    return True


def is_simple_power(x, n):
    """Return True if x is an integer power of n, otherwise False."""
    special_case_result = _handle_special_base(x, n)
    if special_case_result is not None:
        return special_case_result

    if x == 1:
        return True

    return _is_power_by_division(x, n)
candidate = is_simple_power


def check(candidate):

    # Check some simple cases
    assert candidate(16, 2)== True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(143214, 16)== False, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(4, 2)==True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(9, 3)==True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(16, 4)==True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(24, 2)==False, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(128, 4)==False, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(12, 6)==False, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1, 1)==True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate(1, 12)==True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
