
import unittest
import re
import sys
import math
import copy


def _grade_from_gpa(gpa):
    """Convert a single GPA value to its corresponding letter grade."""
    if gpa == 4.0:
        return "A+"
    if gpa > 3.7:
        return "A"
    if gpa > 3.3:
        return "A-"
    if gpa > 3.0:
        return "B+"
    if gpa > 2.7:
        return "B"
    if gpa > 2.3:
        return "B-"
    if gpa > 2.0:
        return "C+"
    if gpa > 1.7:
        return "C"
    if gpa > 1.3:
        return "C-"
    if gpa > 1.0:
        return "D+"
    if gpa > 0.7:
        return "D"
    if gpa > 0.0:
        return "D-"
    return "E"


def numerical_letter_grade(grades):
    """Convert a list of GPA values into letter grades.

    Example:
    numerical_letter_grade([4.0, 3, 1.7, 2, 3.5]) == ['A+', 'B', 'C-', 'C', 'A-']
    """
    return [_grade_from_gpa(gpa) for gpa in grades]
candidate = numerical_letter_grade


def check(candidate):

    # Check some simple cases
    assert candidate([4.0, 3, 1.7, 2, 3.5]) == ['A+', 'B', 'C-', 'C', 'A-']
    assert candidate([1.2]) == ['D+']
    assert candidate([0.5]) == ['D-']
    assert candidate([0.0]) == ['E']
    assert candidate([1, 0.3, 1.5, 2.8, 3.3]) == ['D', 'D-', 'C-', 'B', 'B+']
    assert candidate([0, 0.7]) == ['E', 'D-']

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
