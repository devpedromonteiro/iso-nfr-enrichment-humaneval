
import unittest
import re
import sys
import math
import copy



def _remove_factor(value: int, factor: int) -> int:
    """Divide value by factor until it is no longer divisible."""
    while value % factor == 0:
        value //= factor
    return value


def largest_prime_factor(n: int):
    """Return the largest prime factor of n. Assume n > 1 and is not a prime.
    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    largest = None

    if n % 2 == 0:
        largest = 2
        n = _remove_factor(n, 2)

    factor = 3
    while factor * factor <= n:
        if n % factor == 0:
            largest = factor
            n = _remove_factor(n, factor)
        factor += 2

    if n > 1:
        largest = n

    return largest
candidate = largest_prime_factor




METADATA = {}


def check(candidate):
    assert candidate(15) == 5
    assert candidate(27) == 3
    assert candidate(63) == 7
    assert candidate(330) == 11
    assert candidate(13195) == 29



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
