
import unittest
import re
import sys
import math
import copy


def _sorted_sides(a, b, c):
    """Return the triangle sides in non-decreasing order."""
    return sorted((a, b, c))


def _is_valid_triangle(x, y, z):
    """Return True if the sides can form a valid triangle."""
    return x > 0 and x + y > z


def _satisfies_pythagorean_theorem(x, y, z):
    """Return True if the sides satisfy the Pythagorean theorem."""
    return x * x + y * y == z * z


def right_angle_triangle(a, b, c):
    '''
    Given the lengths of the three sides of a triangle. Return True if the three
    sides form a right-angled triangle, False otherwise.
    A right-angled triangle is a triangle in which one angle is right angle or 
    90 degree.
    Example:
    right_angle_triangle(3, 4, 5) == True
    right_angle_triangle(1, 2, 3) == False
    '''
    x, y, z = _sorted_sides(a, b, c)

    if not _is_valid_triangle(x, y, z):
        return False

    return _satisfies_pythagorean_theorem(x, y, z)
candidate = right_angle_triangle


def check(candidate):

    # Check some simple cases
    assert candidate(3, 4, 5) == True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(1, 2, 3) == False
    assert candidate(10, 6, 8) == True
    assert candidate(2, 2, 2) == False
    assert candidate(7, 24, 25) == True
    assert candidate(10, 5, 7) == False
    assert candidate(5, 12, 13) == True
    assert candidate(15, 8, 17) == True
    assert candidate(48, 55, 73) == True

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1, 1, 1) == False, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate(2, 2, 10) == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
