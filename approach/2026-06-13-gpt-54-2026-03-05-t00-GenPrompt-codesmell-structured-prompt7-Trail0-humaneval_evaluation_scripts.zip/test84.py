
import unittest
import re
import sys
import math
import copy


def _sum_decimal_digits(number):
    """Return the sum of decimal digits of a non-negative integer."""
    return sum(int(digit) for digit in str(number))


def _to_binary_string(number):
    """Return the binary representation of a non-negative integer as a string."""
    return bin(number)[2:]


def solve(N):
    """Given a non-negative integer N, return the binary form of the sum of its decimal digits.

    Examples:
        N = 1000 -> digit sum = 1  -> "1"
        N = 150  -> digit sum = 6  -> "110"
        N = 147  -> digit sum = 12 -> "1100"
    """
    digit_sum = _sum_decimal_digits(N)
    return _to_binary_string(digit_sum)
candidate = solve


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(1000) == "1", "Error"
    assert candidate(150) == "110", "Error"
    assert candidate(147) == "1100", "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate(333) == "1001", "Error"
    assert candidate(963) == "10010", "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
