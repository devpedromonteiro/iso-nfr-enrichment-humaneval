
import unittest
import re
import sys
import math
import copy

from typing import List, Tuple


from typing import Iterable, Tuple


def _sum_numbers(numbers: Iterable[int]) -> int:
    """Return the sum of the provided numbers."""
    total = 0
    for number in numbers:
        total += number
    return total


def _product_numbers(numbers: Iterable[int]) -> int:
    """Return the product of the provided numbers."""
    product = 1
    for number in numbers:
        product *= number
    return product


def sum_product(numbers: list[int]) -> Tuple[int, int]:
    """For a given list of integers, return a tuple with their sum and product.

    Empty sum is 0 and empty product is 1.

    >>> sum_product([])
    (0, 1)
    >>> sum_product([1, 2, 3, 4])
    (10, 24)
    """
    return _sum_numbers(numbers), _product_numbers(numbers)
candidate = sum_product




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == (0, 1)
    assert candidate([1, 1, 1]) == (3, 1)
    assert candidate([100, 0]) == (100, 0)
    assert candidate([3, 5, 7]) == (3 + 5 + 7, 3 * 5 * 7)
    assert candidate([10]) == (10, 10)


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
