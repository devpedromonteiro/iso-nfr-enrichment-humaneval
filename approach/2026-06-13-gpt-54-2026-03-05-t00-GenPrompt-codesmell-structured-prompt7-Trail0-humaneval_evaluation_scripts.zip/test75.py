
import unittest
import re
import sys
import math
import copy


def is_multiply_prime(a):
    """Return True if a is the product of exactly 3 prime numbers, else False.

    Prime factors are counted with multiplicity.
    Examples:
        30 = 2 * 3 * 5  -> True
         8 = 2 * 2 * 2  -> True
        12 = 2 * 2 * 3  -> True
        18 = 2 * 3 * 3  -> True
         7              -> False
    """

    def is_prime(n):
        if n < 2:
            return False
        divisor = 2
        while divisor * divisor <= n:
            if n % divisor == 0:
                return False
            divisor += 1
        return True

    def prime_factor_count(n):
        count = 0
        factor = 2

        while factor * factor <= n:
            while n % factor == 0:
                if not is_prime(factor):
                    return -1
                n //= factor
                count += 1
                if count > 3:
                    return count
            factor += 1

        if n > 1:
            if not is_prime(n):
                return -1
            count += 1

        return count

    if a < 2:
        return False

    return prime_factor_count(a) == 3
candidate = is_multiply_prime


def check(candidate):

    assert candidate(5) == False
    assert candidate(30) == True
    assert candidate(8) == True
    assert candidate(10) == False
    assert candidate(125) == True
    assert candidate(3 * 5 * 7) == True
    assert candidate(3 * 6 * 7) == False
    assert candidate(9 * 9 * 9) == False
    assert candidate(11 * 9 * 9) == False
    assert candidate(11 * 13 * 7) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
