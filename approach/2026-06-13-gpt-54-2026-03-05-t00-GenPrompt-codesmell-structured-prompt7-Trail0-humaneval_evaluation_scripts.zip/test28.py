
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def _validate_strings(strings: List[str]) -> None:
    """Validate the input collection for concatenation."""
    if strings is None:
        raise TypeError("strings must not be None")


def concatenate(strings: List[str]) -> str:
    """Concatenate a list of strings into a single string.

    >>> concatenate([])
    ''
    >>> concatenate(['a', 'b', 'c'])
    'abc'
    """
    _validate_strings(strings)
    return "".join(strings)
candidate = concatenate




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == ''
    assert candidate(['x', 'y', 'z']) == 'xyz'
    assert candidate(['x', 'y', 'z', 'w', 'k']) == 'xyzwk'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
