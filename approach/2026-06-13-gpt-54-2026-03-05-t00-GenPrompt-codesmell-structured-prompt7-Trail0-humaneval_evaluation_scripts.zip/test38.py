
import unittest
import re
import sys
import math
import copy



def encode_cyclic(s: str):
    """
    returns encoded string by cycling groups of three characters.
    """
    # split string to groups. Each of length 3.
    groups = [s[(3 * i):min((3 * i + 3), len(s))] for i in range((len(s) + 2) // 3)]
    # cycle elements in each group. Unless group has fewer elements than 3.
    groups = [(group[1:] + group[0]) if len(group) == 3 else group for group in groups]
    return "".join(groups)


def _chunk_string(s: str, size: int):
    """
    Split a string into chunks of the given size.
    """
    return [s[i:i + size] for i in range(0, len(s), size)]


def _rotate_left(group: str) -> str:
    """
    Rotate a 3-character group left by one position.
    """
    return group[1:] + group[0] if len(group) == 3 else group


def _rotate_right(group: str) -> str:
    """
    Rotate a 3-character group right by one position.
    """
    return group[-1] + group[:-1] if len(group) == 3 else group


def encode_cyclic(s: str):
    """
    returns encoded string by cycling groups of three characters.
    """
    groups = _chunk_string(s, 3)
    encoded_groups = [_rotate_left(group) for group in groups]
    return "".join(encoded_groups)


def decode_cyclic(s: str):
    """
    takes as input string encoded with encode_cyclic function. Returns decoded string.
    """
    groups = _chunk_string(s, 3)
    decoded_groups = [_rotate_right(group) for group in groups]
    return "".join(decoded_groups)
candidate = decode_cyclic




METADATA = {}


def check(candidate):
    from random import randint, choice
    import string

    letters = string.ascii_lowercase
    for _ in range(100):
        str = ''.join(choice(letters) for i in range(randint(10, 20)))
        encoded_str = encode_cyclic(str)
        assert candidate(encoded_str) == str



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
