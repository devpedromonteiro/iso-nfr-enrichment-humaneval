
import unittest
import re
import sys
import math
import copy


def _validate_positive_integer(n):
    if not isinstance(n, int) or n <= 0:
        raise ValueError("n must be a positive integer")


def _next_collatz_value(value):
    return value // 2 if value % 2 == 0 else 3 * value + 1


def _generate_collatz_sequence(start):
    sequence = []
    current = start

    while True:
        sequence.append(current)
        if current == 1:
            break
        current = _next_collatz_value(current)

    return sequence


def _extract_sorted_odds(values):
    odd_values = {value for value in values if value % 2 != 0}
    return sorted(odd_values)


def get_odd_collatz(n):
    """
    Given a positive integer n, return a sorted list that has the odd numbers in collatz sequence.

    The Collatz conjecture is a conjecture in mathematics that concerns a sequence defined
    as follows: start with any positive integer n. Then each term is obtained from the
    previous term as follows: if the previous term is even, the next term is one half of
    the previous term. If the previous term is odd, the next term is 3 times the previous
    term plus 1. The conjecture is that no matter what value of n, the sequence will always reach 1.

    Note:
        1. Collatz(1) is [1].
        2. returned list sorted in increasing order.

    For example:
    get_odd_collatz(5) returns [1, 5] # The collatz sequence for 5 is [5, 16, 8, 4, 2, 1], so the odd numbers are only 1, and 5.
    """
    _validate_positive_integer(n)
    sequence = _generate_collatz_sequence(n)
    return _extract_sorted_odds(sequence)
candidate = get_odd_collatz


def check(candidate):

    # Check some simple cases
    assert candidate(14) == [1, 5, 7, 11, 13, 17]
    assert candidate(5) == [1, 5]
    assert candidate(12) == [1, 3, 5], "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1) == [1], "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
