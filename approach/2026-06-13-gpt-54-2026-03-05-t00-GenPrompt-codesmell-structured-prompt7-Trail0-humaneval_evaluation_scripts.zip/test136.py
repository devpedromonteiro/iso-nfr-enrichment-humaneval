
import unittest
import re
import sys
import math
import copy


def _is_negative(value):
    return value < 0


def _is_positive(value):
    return value > 0


def largest_smallest_integers(lst):
    """
    Return a tuple (largest_negative, smallest_positive).

    - largest_negative: the negative integer closest to zero
    - smallest_positive: the positive integer closest to zero

    If no negative or no positive integer exists, return None for that position.
    Zero is ignored.
    """
    largest_negative = None
    smallest_positive = None

    for value in lst:
        if _is_negative(value):
            if largest_negative is None or value > largest_negative:
                largest_negative = value
        elif _is_positive(value):
            if smallest_positive is None or value < smallest_positive:
                smallest_positive = value

    return largest_negative, smallest_positive
candidate = largest_smallest_integers


def check(candidate):

    # Check some simple cases
    assert candidate([2, 4, 1, 3, 5, 7]) == (None, 1)
    assert candidate([2, 4, 1, 3, 5, 7, 0]) == (None, 1)
    assert candidate([1, 3, 2, 4, 5, 6, -2]) == (-2, 1)
    assert candidate([4, 5, 3, 6, 2, 7, -7]) == (-7, 2)
    assert candidate([7, 3, 8, 4, 9, 2, 5, -9]) == (-9, 2)
    assert candidate([]) == (None, None)
    assert candidate([0]) == (None, None)
    assert candidate([-1, -3, -5, -6]) == (-1, None)
    assert candidate([-1, -3, -5, -6, 0]) == (-1, None)
    assert candidate([-6, -4, -4, -3, 1]) == (-3, 1)
    assert candidate([-6, -4, -4, -3, -100, 1]) == (-3, 1)

    # Check some edge cases that are easy to work out by hand.
    assert True


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
