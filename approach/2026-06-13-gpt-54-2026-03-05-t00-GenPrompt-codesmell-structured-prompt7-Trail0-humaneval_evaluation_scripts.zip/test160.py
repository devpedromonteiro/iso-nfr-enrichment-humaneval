
import unittest
import re
import sys
import math
import copy


import operator as op


_OPERATION_MAP = {
    "+": op.add,
    "-": op.sub,
    "*": op.mul,
    "//": op.floordiv,
    "**": op.pow,
}

_PRECEDENCE = {
    "+": 1,
    "-": 1,
    "*": 2,
    "//": 2,
    "**": 3,
}


def _validate_inputs(operators, operands):
    if len(operators) != len(operands) - 1:
        raise ValueError("operators length must be equal to operands length minus one")

    invalid_operators = [symbol for symbol in operators if symbol not in _OPERATION_MAP]
    if invalid_operators:
        raise ValueError(f"unsupported operators: {invalid_operators}")


def _apply_operator(values_stack, operator_stack):
    right = values_stack.pop()
    left = values_stack.pop()
    current_operator = operator_stack.pop()
    values_stack.append(_OPERATION_MAP[current_operator](left, right))


def _should_apply_before(stack_top, current_operator):
    if stack_top == "**" and current_operator == "**":
        return False
    return _PRECEDENCE[stack_top] >= _PRECEDENCE[current_operator]


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and
    the second list is a list of integers. Use the two given lists to build the algebraic
    expression and return the evaluation of this expression.

    The basic algebra operations:
    Addition ( + )
    Subtraction ( - )
    Multiplication ( * )
    Floor division ( // )
    Exponentiation ( ** )

    Example:
    operator = ['+', '*', '-']
    operand = [2, 3, 4, 5]
    result = 2 + 3 * 4 - 5
    => result = 9

    Note:
        The length of operator list is equal to the length of operand list minus one.
        Operand is a list of non-negative integers.
        Operator list has at least one operator, and operand list has at least two operands.
    """
    _validate_inputs(operator, operand)

    values_stack = [operand[0]]
    operator_stack = []

    for current_operator, next_operand in zip(operator, operand[1:]):
        while operator_stack and _should_apply_before(operator_stack[-1], current_operator):
            _apply_operator(values_stack, operator_stack)

        operator_stack.append(current_operator)
        values_stack.append(next_operand)

    while operator_stack:
        _apply_operator(values_stack, operator_stack)

    return values_stack[0]
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
