
import unittest
import re
import sys
import math
import copy



def _count_cars_per_direction(n: int) -> tuple[int, int]:
    """Return the number of cars moving in each direction."""
    return n, n


def _calculate_collisions(left_to_right: int, right_to_left: int) -> int:
    """Return total pairwise collisions between the two groups."""
    return left_to_right * right_to_left


def car_race_collision(n: int) -> int:
    """
    Imagine a road that's a perfectly straight infinitely long line.
    n cars are driving left to right; simultaneously, a different set of n cars
    are driving right to left. The two sets of cars start out being very far from
    each other. All cars move at the same speed. Two cars are said to collide
    when a car that's moving left to right hits a car that's moving right to left.
    However, the cars are infinitely sturdy and strong; as a result, they continue moving
    in their trajectory as if they did not collide.

    This function outputs the number of such collisions.
    """
    left_to_right, right_to_left = _count_cars_per_direction(n)
    return _calculate_collisions(left_to_right, right_to_left)
candidate = car_race_collision




METADATA = {}


def check(candidate):
    assert candidate(2) == 4
    assert candidate(3) == 9
    assert candidate(4) == 16
    assert candidate(8) == 64
    assert candidate(10) == 100



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
