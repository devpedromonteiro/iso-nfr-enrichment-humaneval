
import unittest
import re
import sys
import math
import copy



def _unique_items(items: list) -> set:
    """Return the unique items from a list as a set."""
    return set(items)


def _sorted_items(items: set) -> list:
    """Return sorted items from a set as a list."""
    return sorted(items)


def common(l1: list, l2: list):
    """Return sorted unique common elements for two lists.
    >>> common([1, 4, 3, 34, 653, 2, 5], [5, 7, 1, 5, 9, 653, 121])
    [1, 5, 653]
    >>> common([5, 3, 2, 8], [3, 2])
    [2, 3]

    """
    unique_l1 = _unique_items(l1)
    unique_l2 = _unique_items(l2)
    common_items = unique_l1.intersection(unique_l2)
    return _sorted_items(common_items)
candidate = common




METADATA = {}


def check(candidate):
    assert candidate([1, 4, 3, 34, 653, 2, 5], [5, 7, 1, 5, 9, 653, 121]) == [1, 5, 653]
    assert candidate([5, 3, 2, 8], [3, 2]) == [2, 3]
    assert candidate([4, 3, 2, 8], [3, 2, 4]) == [2, 3, 4]
    assert candidate([4, 3, 2, 8], []) == []



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
