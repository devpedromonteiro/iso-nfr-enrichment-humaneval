
import unittest
import re
import sys
import math
import copy


def _signed_digit_sum(number):
    """Return the digit sum where the first digit keeps the number's sign."""
    if number == 0:
        return 0

    digits = str(abs(number))
    total = sum(int(digit) for digit in digits)

    if number < 0:
        total -= 2 * int(digits[0])

    return total


def count_nums(arr):
    """
    Return the count of integers whose signed digit sum is greater than 0.

    If a number is negative, its first digit is treated as negative.
    For example, -123 has signed digits -1, 2, 3, so the sum is 4.

    >>> count_nums([]) == 0
    True
    >>> count_nums([-1, 11, -11]) == 1
    True
    >>> count_nums([1, 1, 2]) == 3
    True
    """
    return sum(1 for number in arr if _signed_digit_sum(number) > 0)
candidate = count_nums


def check(candidate):

    # Check some simple cases
    assert candidate([]) == 0
    assert candidate([-1, -2, 0]) == 0
    assert candidate([1, 1, 2, -2, 3, 4, 5]) == 6
    assert candidate([1, 6, 9, -6, 0, 1, 5]) == 5
    assert candidate([1, 100, 98, -7, 1, -1]) == 4
    assert candidate([12, 23, 34, -45, -56, 0]) == 5
    assert candidate([-0, 1**0]) == 1
    assert candidate([1]) == 1

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
