
import unittest
import re
import sys
import math
import copy



def _normalize_characters(string: str) -> str:
    """Return a case-insensitive representation of the input string."""
    return string.lower()


def _distinct_characters(string: str) -> set[str]:
    """Return the set of distinct characters in the string."""
    return set(string)


def count_distinct_characters(string: str) -> int:
    """Given a string, return how many distinct characters it contains, ignoring case.

    >>> count_distinct_characters('xyzXYZ')
    3
    >>> count_distinct_characters('Jerry')
    4
    """
    normalized_string = _normalize_characters(string)
    distinct_chars = _distinct_characters(normalized_string)
    return len(distinct_chars)
candidate = count_distinct_characters




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == 0
    assert candidate('abcde') == 5
    assert candidate('abcde' + 'cade' + 'CADE') == 5
    assert candidate('aaaaAAAAaaaa') == 1
    assert candidate('Jerry jERRY JeRRRY') == 5


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
