
import unittest
import re
import sys
import math
import copy


def valid_date(date):
    """Validate a date string in mm-dd-yyyy format."""

    if not _is_non_empty_string(date):
        return False

    parts = _split_date_parts(date)
    if parts is None:
        return False

    month, day, year = parts

    if not _is_valid_month(month):
        return False

    return _is_valid_day_for_month(month, day)


def _is_non_empty_string(value):
    return isinstance(value, str) and value != ""


def _split_date_parts(date_string):
    parts = date_string.split("-")
    if len(parts) != 3:
        return None

    month_str, day_str, year_str = parts

    if not (_has_expected_lengths(month_str, day_str, year_str) and
            _all_numeric(month_str, day_str, year_str)):
        return None

    return int(month_str), int(day_str), int(year_str)


def _has_expected_lengths(month_str, day_str, year_str):
    return len(month_str) == 2 and len(day_str) == 2 and len(year_str) == 4


def _all_numeric(*values):
    return all(value.isdigit() for value in values)


def _is_valid_month(month):
    return 1 <= month <= 12


def _is_valid_day_for_month(month, day):
    max_days_by_month = {
        1: 31, 2: 29, 3: 31, 4: 30,
        5: 31, 6: 30, 7: 31, 8: 31,
        9: 30, 10: 31, 11: 30, 12: 31,
    }
    return 1 <= day <= max_days_by_month[month]
candidate = valid_date


def check(candidate):

    # Check some simple cases
    assert candidate('03-11-2000') == True

    assert candidate('15-01-2012') == False

    assert candidate('04-0-2040') == False

    assert candidate('06-04-2020') == True

    assert candidate('01-01-2007') == True

    assert candidate('03-32-2011') == False

    assert candidate('') == False

    assert candidate('04-31-3000') == False

    assert candidate('06-06-2005') == True

    assert candidate('21-31-2000') == False

    assert candidate('04-12-2003') == True

    assert candidate('04122003') == False

    assert candidate('20030412') == False

    assert candidate('2003-04') == False

    assert candidate('2003-04-12') == False

    assert candidate('04-2003') == False


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
