
import unittest
import re
import sys
import math
import copy


def f(n):
    """Return a list of length n based on each 1-based index.

    For each position i from 1 to n:
    - if i is even, store i!
    - if i is odd, store the sum of numbers from 1 to i

    Example:
        f(5) == [1, 2, 6, 24, 15]
    """

    def factorial(number):
        result = 1
        for current_value in range(1, number + 1):
            result *= current_value
        return result

    def sum_from_one_to(number):
        total = 0
        for current_value in range(1, number + 1):
            total += current_value
        return total

    values = []

    for index in range(1, n + 1):
        if index % 2 == 0:
            values.append(factorial(index))
        else:
            values.append(sum_from_one_to(index))

    return values
candidate = f


def check(candidate):

    assert candidate(5) == [1, 2, 6, 24, 15]
    assert candidate(7) == [1, 2, 6, 24, 15, 720, 28]
    assert candidate(1) == [1]
    assert candidate(3) == [1, 2, 6]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
