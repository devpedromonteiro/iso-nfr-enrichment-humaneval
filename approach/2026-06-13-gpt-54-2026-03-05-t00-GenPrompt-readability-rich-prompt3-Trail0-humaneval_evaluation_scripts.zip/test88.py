
import unittest
import re
import sys
import math
import copy


def sort_array(array):
    """
    Given an array of non-negative integers, return a sorted copy of the array.

    Sort in ascending order if the sum of the first and last values is odd.
    Sort in descending order if the sum of the first and last values is even.

    The original array is not modified.
    """
    if len(array) <= 1:
        return array.copy()

    first_value = array[0]
    last_value = array[-1]
    should_sort_ascending = (first_value + last_value) % 2 == 1

    sorted_array = sorted(array, reverse=not should_sort_ascending)
    return sorted_array
candidate = sort_array


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([]) == [], "Error"
    assert candidate([5]) == [5], "Error"
    assert candidate([2, 4, 3, 0, 1, 5]) == [0, 1, 2, 3, 4, 5], "Error"
    assert candidate([2, 4, 3, 0, 1, 5, 6]) == [6, 5, 4, 3, 2, 1, 0], "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([2, 1]) == [1, 2], "Error"
    assert candidate([15, 42, 87, 32 ,11, 0]) == [0, 11, 15, 32, 42, 87], "Error"
    assert candidate([21, 14, 23, 11]) == [23, 21, 14, 11], "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
