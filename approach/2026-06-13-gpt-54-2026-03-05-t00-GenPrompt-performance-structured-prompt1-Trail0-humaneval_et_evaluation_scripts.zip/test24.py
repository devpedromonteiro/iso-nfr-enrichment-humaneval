
import unittest



def largest_divisor(n: int) -> int:
    """For a given number n, find the largest number that divides n evenly, smaller than n.

    >>> largest_divisor(15)
    5
    """
    if n <= 1:
        raise ValueError("n must be greater than 1")

    # The largest proper divisor is n divided by its smallest factor > 1.
    # Checking upward from 2 minimizes work compared with checking all smaller divisors.
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            return n // i

    # If no factor is found, n is prime, so its largest proper divisor is 1.
    return 1
candidate = largest_divisor


class Test(unittest.TestCase):
    def test(self):
        assert candidate(47) == 1
        assert candidate(98) == 49
        assert candidate(104) == 52
        assert candidate(51) == 17
        assert candidate(10) == 5
        assert candidate(53) == 1
        assert candidate(3) == 1
        assert candidate(95) == 19
        assert candidate(44) == 22
        assert candidate(8) == 4
        assert candidate(4) == 2
        assert candidate(103) == 1
        assert candidate(11) == 1
        assert candidate(46) == 23
        assert candidate(49) == 7
        assert candidate(13) == 1
        assert candidate(14) == 7
        assert candidate(54) == 27
        assert candidate(99) == 33
        assert candidate(45) == 15
        assert candidate(9) == 3
        assert candidate(7) == 1
        assert candidate(100) == 50
        assert candidate(6) == 3
        assert candidate(48) == 24
        assert candidate(15) == 5
        assert candidate(101) == 1
        assert candidate(97) == 1
        assert candidate(12) == 6
        assert candidate(105) == 35
        assert candidate(5) == 1
        assert candidate(2) == 1
        assert candidate(102) == 51

if __name__ == '__main__':
    unittest.main()
