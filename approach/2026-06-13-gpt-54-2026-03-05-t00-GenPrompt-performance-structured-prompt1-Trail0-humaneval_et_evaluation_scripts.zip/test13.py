
import unittest



def greatest_common_divisor(a: int, b: int) -> int:
    """Return the greatest common divisor of two integers a and b.

    Uses the Euclidean algorithm for good performance:
    - time complexity: O(log(min(a, b)))
    - constant extra space

    >>> greatest_common_divisor(3, 5)
    1
    >>> greatest_common_divisor(25, 15)
    5
    """
    a, b = abs(a), abs(b)
    while b:
        a, b = b, a % b
    return a
candidate = greatest_common_divisor


class Test(unittest.TestCase):
    def test(self):
        assert candidate(6, 16) == 2
        assert candidate(47, 19) == 1
        assert candidate(141, 65) == 1
        assert candidate(45, 15) == 15
        assert candidate(1, 6) == 1
        assert candidate(50, 14) == 2
        assert candidate(53, 16) == 1
        assert candidate(3, 9) == 3
        assert candidate(50, 11) == 1
        assert candidate(48, 12) == 12
        assert candidate(49, 9) == 1
        assert candidate(6, 14) == 2
        assert candidate(141, 63) == 3
        assert candidate(5, 11) == 1
        assert candidate(11, 12) == 1
        assert candidate(12, 13) == 1
        assert candidate(15, 19) == 1
        assert candidate(46, 18) == 2
        assert candidate(4, 12) == 4
        assert candidate(46, 13) == 1
        assert candidate(12, 11) == 1
        assert candidate(11, 17) == 1
        assert candidate(148, 64) == 4
        assert candidate(5, 9) == 1
        assert candidate(5, 2) == 1
        assert candidate(1, 11) == 1
        assert candidate(141, 61) == 1
        assert candidate(53, 14) == 1
        assert candidate(12, 10) == 2
        assert candidate(147, 62) == 1
        assert candidate(2, 4) == 2
        assert candidate(142, 63) == 1
        assert candidate(4, 6) == 2
        assert candidate(149, 64) == 1
        assert candidate(6, 2) == 2
        assert candidate(5, 13) == 1
        assert candidate(148, 58) == 2
        assert candidate(46, 10) == 2
        assert candidate(44, 12) == 4
        assert candidate(5, 12) == 1
        assert candidate(13, 15) == 1
        assert candidate(10, 17) == 1
        assert candidate(2, 7) == 1
        assert candidate(5, 5) == 5
        assert candidate(1, 7) == 1
        assert candidate(48, 18) == 6
        assert candidate(46, 12) == 2
        assert candidate(3, 12) == 3
        assert candidate(54, 9) == 9
        assert candidate(142, 57) == 1
        assert candidate(5, 16) == 1
        assert candidate(142, 55) == 1
        assert candidate(44, 16) == 4
        assert candidate(145, 63) == 1
        assert candidate(144, 59) == 1
        assert candidate(8, 9) == 1
        assert candidate(148, 62) == 2
        assert candidate(49, 16) == 1
        assert candidate(140, 65) == 5
        assert candidate(145, 55) == 5
        assert candidate(1, 3) == 1
        assert candidate(12, 20) == 4
        assert candidate(6, 13) == 1
        assert candidate(141, 59) == 1
        assert candidate(7, 10) == 1
        assert candidate(51, 11) == 1
        assert candidate(12, 16) == 4
        assert candidate(46, 14) == 2
        assert candidate(6, 3) == 3
        assert candidate(14, 13) == 1
        assert candidate(10, 15) == 5
        assert candidate(15, 20) == 5
        assert candidate(6, 17) == 1
        assert candidate(147, 61) == 1
        assert candidate(4, 4) == 4
        assert candidate(1, 9) == 1
        assert candidate(13, 17) == 1
        assert candidate(139, 65) == 1
        assert candidate(144, 58) == 2
        assert candidate(147, 64) == 1
        assert candidate(3, 7) == 1
        assert candidate(52, 19) == 1
        assert candidate(50, 10) == 10
        assert candidate(2, 9) == 1
        assert candidate(44, 10) == 2
        assert candidate(144, 62) == 2
        assert candidate(148, 55) == 1
        assert candidate(144, 60) == 12
        assert candidate(49, 14) == 7
        assert candidate(143, 59) == 1
        assert candidate(6, 4) == 2
        assert candidate(148, 60) == 4
        assert candidate(11, 19) == 1
        assert candidate(4, 7) == 1
        assert candidate(15, 16) == 1
        assert candidate(49, 13) == 1
        assert candidate(8, 16) == 8
        assert candidate(54, 19) == 1
        assert candidate(8, 11) == 1
        assert candidate(8, 6) == 2
        assert candidate(6, 9) == 3
        assert candidate(12, 14) == 2
        assert candidate(146, 55) == 1
        assert candidate(139, 61) == 1
        assert candidate(147, 65) == 1
        assert candidate(11, 10) == 1
        assert candidate(143, 62) == 1
        assert candidate(140, 63) == 7
        assert candidate(49, 15) == 1
        assert candidate(44, 15) == 1
        assert candidate(2, 6) == 2
        assert candidate(8, 18) == 2
        assert candidate(6, 6) == 6
        assert candidate(48, 15) == 3
        assert candidate(44, 9) == 1
        assert candidate(14, 20) == 2

if __name__ == '__main__':
    unittest.main()
