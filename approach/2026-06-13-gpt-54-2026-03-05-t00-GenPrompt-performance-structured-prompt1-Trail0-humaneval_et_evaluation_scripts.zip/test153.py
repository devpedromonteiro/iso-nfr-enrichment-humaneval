
import unittest


def Strongest_Extension(class_name, extensions):
    """You will be given the name of a class (a string) and a list of extensions.
    The extensions are to be used to load additional classes to the class. The
    strength of the extension is as follows: Let CAP be the number of the uppercase
    letters in the extension's name, and let SM be the number of lowercase letters
    in the extension's name, the strength is given by the fraction CAP - SM.
    You should find the strongest extension and return a string in this
    format: ClassName.StrongestExtensionName.
    If there are two or more extensions with the same strength, you should
    choose the one that comes first in the list.
    For example, if you are given "Slices" as the class and a list of the
    extensions: ['SErviNGSliCes', 'Cheese', 'StuFfed'] then you should
    return 'Slices.SErviNGSliCes' since 'SErviNGSliCes' is the strongest extension
    (its strength is -1).
    Example:
    for Strongest_Extension('my_class', ['AA', 'Be', 'CC']) == 'my_class.AA'
    """
    best_extension = extensions[0]
    best_strength = float("-inf")

    for ext in extensions:
        strength = 0
        for ch in ext:
            if ch.isupper():
                strength += 1
            elif ch.islower():
                strength -= 1

        if strength > best_strength:
            best_strength = strength
            best_extension = ext

    return class_name + "." + best_extension
candidate = Strongest_Extension


class Test(unittest.TestCase):
    def test(self):
        assert candidate('*+F_BQJP', ['GvS', '618674', '81358', '%|**&/%%~']) == '*+F_BQJP.GvS'
        assert candidate('XMVP', ['hspdpnlma', 'DbxHarTYs', 'YwLIJYlKUG', 'jildgj']) == 'XMVP.YwLIJYlKUG'
        assert candidate('/', ['TeHZ', '257190708']) == '/.TeHZ'
        assert candidate('_', ['Bb', '91245']) == '_.Bb'
        assert candidate('T?W+E:', ['w', 'HOzGtHHnX', 'wtu', 'M7KE', '&udG', 'mMS9yg95vFTSmmYS6']) == 'T?W+E:.HOzGtHHnX'
        assert candidate('#UOLLUUH', ['Wtib', '07545', '7698', '--!!']) == '#UOLLUUH.07545'
        assert candidate('D', ['BoEus', 'ERM', 'oHQ8nw', 'WCfkVA']) == 'D.ERM'
        assert candidate('VEjG', ['sZfG', 'tNg', 'oLaPQY']) == 'VEjG.oLaPQY'
        assert candidate('vvza', ['kvm', 'kiXXSwM', 'RbjZMK', '26lg9wng']) == 'vvza.RbjZMK'
        assert candidate('TZcZFZg', ['XEt', 'WgdbsBD', 'llfclvmk', 'FhAAIFHSe']) == 'TZcZFZg.FhAAIFHSe'
        assert candidate('@PWACU', ['s', 'eqtaob', 'pfwor', 'bhm5B2', '&$Vm!kou', 'Ar4sHMXfITAmK']) == '@PWACU.Ar4sHMXfITAmK'
        assert candidate('BGE!IART_+=^U', ['b', 'BtuL', 'chfhbbr', 'va98odY64', '%xLD&RXy#n/', 'makkFgnJSmjKzMhIO']) == 'BGE!IART_+=^U.%xLD&RXy#n/'
        assert candidate('CRCmZptHgJw', ['twhwpqh', 'ZOHeYFXoX', 'qJ.RHCbvYqQJ', 'i7i3v0q311nrnvu']) == 'CRCmZptHgJw.ZOHeYFXoX'
        assert candidate('PAWZjZc', ['bjsA', 'uNMjNEonB4WY4Dq', 'PkqtYalVTS', 'QSL', '-?*&?']) == 'PAWZjZc.uNMjNEonB4WY4Dq'
        assert candidate('sMDiyLSYyOY', ['WTrp', 'HpSgHjJj', 'ii5Xthj9AZ4nmOp']) == 'sMDiyLSYyOY.WTrp'
        assert candidate('bsclnM', ['GwyoOWMu', 'uJZRvP', 'iNRxSMq', 'MjAUmFWpV']) == 'bsclnM.MjAUmFWpV'
        assert candidate('A', ['vuYA', 'GAKX', 'GJvy', 'MYRSsI']) == 'A.GAKX'
        assert candidate('Q-?:+W', ['c', 'VCVO', 'tslzwrigeho', 'hYTSHBzR', 'k|KNuGxX__q', 'K6dpelxte50A']) == 'Q-?:+W.VCVO'
        assert candidate('JHWofsNy', ['ehbrlCsSN', 'kSVCTqtQp', 'aTx', 'rFgQAZSHX']) == 'JHWofsNy.rFgQAZSHX'
        assert candidate('FRI~', ['AGwZ', '8873885', '6947', '~@$']) == 'FRI~.AGwZ'
        assert candidate('@', ['Atbytp', '117694605']) == '@.117694605'
        assert candidate('/', ['BSCWB', '09569']) == '/.BSCWB'
        assert candidate('kBupApJhoed', ['HBLe', 'hMwILqoi', 'Q0kxrsSC6Hj']) == 'kBupApJhoed.HBLe'
        assert candidate('AfF9TF1H', ['prdor', 'XUaeAzcjnK', 'ALXFDlofAxGjKUb', 'hqks289']) == 'AfF9TF1H.ALXFDlofAxGjKUb'
        assert candidate('BlBRDhtAl', ['tvMzrfQR', 'nIfa3F2W2N9gPr', 'ytXuwcohgNw', 'jlXwaU', '@!/@#&@']) == 'BlBRDhtAl.nIfa3F2W2N9gPr'
        assert candidate('csufsy', ['YfkhnbFQ', 'mScEbB52s1k', 'MCVmIlH', 'IQcmKZMLy', '_=_*|']) == 'csufsy.MCVmIlH'
        assert candidate('cIAj', ['mfog', 'wezaMTICtlakm', 'LdNY', 'JucoEDJf', '#//_|@']) == 'cIAj.LdNY'
        assert candidate('lwKQ', ['02327846646', 'eaQKO']) == 'lwKQ.eaQKO'
        assert candidate('#', ['EfRONu', '215']) == '#.EfRONu'
        assert candidate('!', ['QtAcA', '403478456']) == '!.QtAcA'
        assert candidate('XRX', ['src', 'yXPN', 'imvidTW', 'iu9psm0abqt9']) == 'XRX.yXPN'
        assert candidate('RrhQI', ['eSvYKfU', 'cQMJaodRd', 'bOgsqkAQ7']) == 'RrhQI.eSvYKfU'
        assert candidate('U+:MZK^NJ/:~', ['RNvvDjNRX', '709417', '01040495562', '?_@+&|*&']) == 'U+:MZK^NJ/:~.RNvvDjNRX'
        assert candidate('ORVNl', ['805539624', 'zpewje']) == 'ORVNl.805539624'
        assert candidate(':', ['GIFNES', '81425591']) == ':.GIFNES'
        assert candidate('Watashi', ['tEN', 'niNE', 'eIGHt8OKe']) == 'Watashi.eIGHt8OKe'
        assert candidate('lGwjPbfmh', ['jIRdWJh', 'qI41fmRkHKq', 'XIcX', 'befSC', '!_|/?=^']) == 'lGwjPbfmh.XIcX'
        assert candidate('eOqPIViIzusFYP', ['RjuxuP', 'JSJ', 'CqAkiF', 'YbvqMQX']) == 'eOqPIViIzusFYP.JSJ'
        assert candidate('D', ['AepvR', 'LQELHOF', 'sN8OHrsyY', 'xAqfD']) == 'D.LQELHOF'
        assert candidate('ouSK', ['TiJQbs', 'jkNjDc', 'MpWWtB']) == 'ouSK.MpWWtB'
        assert candidate('Fhe', ['90478119', 'WjVUK']) == 'Fhe.WjVUK'
        assert candidate('G', ['xoldMl', 'SQTDTH', 'vl83ZVlB', 'ldmnmCSDC']) == 'G.SQTDTH'
        assert candidate('#*Z', ['ePllhoInE', '74746', '8280', '*+!#-&^!/']) == '#*Z.74746'
        assert candidate('ZoVbnWCKigQ', ['ZzjLvmEok', 'A5zPLS1WHR', 'rdwdzNCz', 'hYPzS', '=/=%']) == 'ZoVbnWCKigQ.A5zPLS1WHR'
        assert candidate('DILWLY', ['92527', 'rSjVk']) == 'DILWLY.92527'
        assert candidate('FKmkaw', ['gaB', 'EVpUuQsBo', 'Zqc06UtH']) == 'FKmkaw.EVpUuQsBo'
        assert candidate('Q', ['rxeGlo', 'GGWDE', 'fULTz6p54l5', 'Fago']) == 'Q.GGWDE'
        assert candidate('PajcBWKjXE', ['WIaxk', 'Yaa6Cqwpbzb', 'igdcIRMj', 'xqJ', '?/%']) == 'PajcBWKjXE.?/%'
        assert candidate('?', ['YPMsSD', '8670851']) == '?.YPMsSD'
        assert candidate('B', ['lbsuTh', 'KEIAA', 'nH0f7v6BYcaT', 'eweeCaOW']) == 'B.KEIAA'
        assert candidate('Meu', ['toQQF', 'l2gCXipxz30c7k', 'xRzDR', 'EQPUyl', '=-|-']) == 'Meu.EQPUyl'
        assert candidate('eLSw', ['53942091616', 'FkLrI']) == 'eLSw.FkLrI'
        assert candidate('S^/GDWQ*EF?BNN', ['h', 'CbIPR', 'jlfyp', '51JvjNr3', 'GkI$nu+e&y', 'sBE03hrRogxoZ9R']) == 'S^/GDWQ*EF?BNN.CbIPR'
        assert candidate('Q', ['TWZQs', 'EUYNBP', 'lhoGTKzuxvy', 'JEwbEdFu']) == 'Q.EUYNBP'
        assert candidate('Msoh', ['33703253', 'lph']) == 'Msoh.33703253'
        assert candidate('WaRlzPhsXbv', ['EbckOlW', 'BxA', 'SWF0Tq5eGIml']) == 'WaRlzPhsXbv.SWF0Tq5eGIml'
        assert candidate('dGIt', ['9252631368', 'yKNteG']) == 'dGIt.9252631368'
        assert candidate('igKRdwEMym', ['JThSfRu', 'oJyyK', 'pvydN', 'snG']) == 'igKRdwEMym.JThSfRu'
        assert candidate('FpVbL', ['85379', 'CxADbI']) == 'FpVbL.CxADbI'
        assert candidate('OR@UM*/EG|X!HHQ', ['j', 'TXzd', 'xmbttwav', 'z5FelN', '#Z@wM', 'vJed7fLec7dDIawBCL']) == 'OR@UM*/EG|X!HHQ.#Z@wM'
        assert candidate('finNNalLLly', ['Die', 'NowW', 'Wow', 'WoW']) == 'finNNalLLly.WoW'

    # Check some edge cases that are easy to work out by hand.
        assert candidate('TGLD=L|SNN', ['p', 'iBfhnRX', 'oapkqdj', '6FDDW2eCE', 'd*tfxubFyMU', 'jEfn66UI5SCgB5gnBN']) == 'TGLD=L|SNN.6FDDW2eCE'
        assert candidate('?', ['KdaTuj', '85543']) == '?.85543'
        assert candidate('&ZW/G|X:|', ['MzcytjzNb', '97843433', '6806520048', '~#!_:']) == '&ZW/G|X:|.97843433'
        assert candidate('Q', ['qLOaj', 'OPQPFUZQE', 'AVNgLwkA7Dx', 'kMzlTh']) == 'Q.OPQPFUZQE'
        assert candidate('|LLV#Y|X', ['FCweayvL', '0555', '999801294', '$/_^|~_+']) == '|LLV#Y|X.0555'
        assert candidate('fyRuJp', ['eNSuR', 'BbIQYs2avy', 'SfWYLSz', 'Ruk', '%~~']) == 'fyRuJp.SfWYLSz'
        assert candidate('~', ['MxeOK', '920']) == '~.MxeOK'
        assert candidate('~', ['YlNBp', '505167986']) == '~.YlNBp'
        assert candidate('gILLaMmv', ['hQIUELQ', 'qIlJMwv', 'oua', 'ijIwPp']) == 'gILLaMmv.hQIUELQ'
        assert candidate('M', ['gZvPL', 'XEAW', '9lGL', 'DBLtogHD']) == 'M.XEAW'
        assert candidate('__YESIMHERE', ['t', 'eMptY', 'nothing', 'zeR00', 'NuLl__', '123NoooneB321']) == '__YESIMHERE.NuLl__'
        assert candidate('pdULvHPDu', ['vogq', 'wOQhfFUdGqM', 'jLLovMAmwHKE', 'tbzdc0p26365qk']) == 'pdULvHPDu.jLLovMAmwHKE'
        assert candidate('vsJeaDaIkEg', ['PqUxkrh', 'uwAS1C', 'vYkAoQ', 'qcSN', '?%%/']) == 'vsJeaDaIkEg.uwAS1C'
        assert candidate('DCQAPVI|$X&', ['p', 'gZU', 'saccbp', 'AfX', 'Y@|DWsgMRSuT', 'PWpmYgeEi2kWIEy']) == 'DCQAPVI|$X&.Y@|DWsgMRSuT'
        assert candidate('FatGbwc1GGz', ['horetduxv', 'HGjwJTsqyyA', 'dYqlL.wWatfH', 'jd68pk2l1muptc4']) == 'FatGbwc1GGz.HGjwJTsqyyA'
        assert candidate('heVSAH', ['OvBQ', 'AxyemmrMn', 'jlzoRgzSG', 'ZieZZ']) == 'heVSAH.OvBQ'
        assert candidate('$SK%?Q?W', ['d', 'hSMUdFLh', 'hfc', 'FSSQw', 'kfu?lA%XAW', '1tjz5NmKeb']) == '$SK%?Q?W.FSSQw'
        assert candidate('ddm', ['114', 'hPqY']) == 'ddm.114'
        assert candidate('KW=', ['KTpzELfI', '64104', '675413268270', '&:|']) == 'KW=.KTpzELfI'
        assert candidate('VO8lTbdbk', ['zzi', 'ImvLBRYrKsg', 'VBAGXnw', 'arcx6l2aw']) == 'VO8lTbdbk.VBAGXnw'
        assert candidate('H&TFWS', ['IpH', '0046', '7226404', '~$-^']) == 'H&TFWS.IpH'
        assert candidate('TR%*&$^IKJQN', ['QhcVVx', '3991261', '229452505686', '==:~%']) == 'TR%*&$^IKJQN.QhcVVx'
        assert candidate('_', ['rpx', '066421382']) == '_.066421382'
        assert candidate('Boku123', ['nani', 'NazeDa', 'YEs.WeCaNe', '32145tggg']) == 'Boku123.YEs.WeCaNe'
        assert candidate('rrPJByTtTPfEv', ['vlq', 'efS', 'CjZTQodtx', 'HeHHM']) == 'rrPJByTtTPfEv.HeHHM'
        assert candidate('eQArLhgVYOs', ['jWlSDky', 'gELbOGX584z', 'EBXfgmPhdv', 'cXGef', '&|/%=?:|/']) == 'eQArLhgVYOs.gELbOGX584z'
        assert candidate('QeYQXTYgBCFE', ['OsopD', 'lFbt', 'NMYuiQhR', 'EGYJFi']) == 'QeYQXTYgBCFE.EGYJFi'
        assert candidate('HhPZeBTx', ['XSu', 'EVIOuqwCS', 'iAhnRuxd4hQHCKP']) == 'HhPZeBTx.EVIOuqwCS'
        assert candidate('UwT', ['KHfynGaX', 'tiQPePAt', 'JQOWxKagVH2CP']) == 'UwT.JQOWxKagVH2CP'
        assert candidate('DPv', ['olat', 'HsPfZURJttx', 'htRintWxgf', '3hnd43nybsy3']) == 'DPv.HsPfZURJttx'
        assert candidate('vRIaFFihciSB', ['noPLYIvDm', 'Pctzd', '3HxoEE7U']) == 'vRIaFFihciSB.3HxoEE7U'
        assert candidate(':JA_MUEY', ['WyGfiME', '84841922', '891', '+%$?:__$']) == ':JA_MUEY.WyGfiME'
        assert candidate('X', ['nCT', 'GOTAPLZV', 'apRGBs', 'RqFUcRmF']) == 'X.GOTAPLZV'
        assert candidate('+', ['vrmNGT', '91155']) == '+.vrmNGT'
        assert candidate('IX*N_YZBWQ', ['r', 'UxgN', 'spcymxm', 'XuC3YFX', 'CHtr', 'XnRPRj6Vsk']) == 'IX*N_YZBWQ.XuC3YFX'
        assert candidate('viErbq', ['JWrN', 'tTavzc', 'iNwdfdGMxbPJ', 'bDoxhjrG', '-$|-==-']) == 'viErbq.JWrN'
        assert candidate('#TKW=*&XGJ*PZQ^', ['j', 'hnQVJX', 'tzlmmjy', 'hNSTVM', 'a_umjZASWWg/', 'ADBiqyM3f']) == '#TKW=*&XGJ*PZQ^.hNSTVM'
        assert candidate('sbpbSczSAYfr', ['jhiJCxgCR', 'fWw', 'fqAcX2dicmV5']) == 'sbpbSczSAYfr.jhiJCxgCR'
        assert candidate('__HAHA', ['Tab', '123', '781345', '-_-']) == '__HAHA.123'
        assert candidate('Sp', ['671235', 'Bb']) == 'Sp.671235'
        assert candidate('LPcqtO', ['apXjjDgR', 'jXYoRUZaL', '9Fg7Xmgr']) == 'LPcqtO.jXYoRUZaL'
        assert candidate('ATmEEI5Tomo', ['ndbd', 'ekQlELD', 'kYU.OvtJ', 'rpunxydb3enyd9']) == 'ATmEEI5Tomo.ekQlELD'
        assert candidate('PDr', ['viSzRy', 'i1PDVdEvEKXeJD', 'nddvMSrp', 'FfLLgXiJ', '=&~|']) == 'PDr.i1PDVdEvEKXeJD'
        assert candidate('K', ['Ta', 'TAR', 't234An', 'cosSo']) == 'K.TAR'
        assert candidate('igdKai', ['8786', 'vLO']) == 'igdKai.vLO'
        assert candidate('*C?TOCCYMF#', ['UhI', '81376772', '9424178697', '+~^/-+*#']) == '*C?TOCCYMF#.UhI'
        assert candidate('mss', ['EtCrQpzcv', 'CfcO', 'Nwb3WD']) == 'mss.Nwb3WD'
        assert candidate('N9WkDnmi', ['nyjntr', 'SEYwjYZZ', 'KrfhKHxm', '449g0qajup']) == 'N9WkDnmi.SEYwjYZZ'
        assert candidate('H', ['ZQP', 'QDOMYQKCC', 'B49H', 'dcRUmtc']) == 'H.QDOMYQKCC'
        assert candidate('*LO_|%+N:YAG?', ['w', 'Ffh', 'dsgvgmlewhzt', 'VSZrqHJf', 'Y!%n?~^Zj#_', 'uz3991C3cG6tzk']) == '*LO_|%+N:YAG?.VSZrqHJf'
        assert candidate('8UwSphCKq3', ['dnqsrmbrm', 'SQu', 'TDUhncgiR', 'r7bc5few58h']) == '8UwSphCKq3.SQu'
        assert candidate('@_YLVZJD*$', ['x', 'VBIuLXA', 'kmygj', 'UriEwos', 'kYzKivJ/Do', 'wmZR5B7rlNPb']) == '@_YLVZJD*$.VBIuLXA'
        assert candidate('vqnhvJjNGgvmUBm', ['HzOTtDeU', 'uxwSVKq', 'ZAxl', 'FDBvmYVWD']) == 'vqnhvJjNGgvmUBm.FDBvmYVWD'
        assert candidate('T', ['Fypiwl', 'RYKNQINBD', 'DYDfQJ', 'poEzygy']) == 'T.RYKNQINBD'
        assert candidate('^', ['xtyW', '27975']) == '^.27975'
        assert candidate('MlLK', ['7080561', 'QpCRf']) == 'MlLK.QpCRf'
        assert candidate('|', ['pnMgUW', '201271']) == '|.pnMgUW'
        assert candidate('DvtFEPScf', ['xktzl', 'eAqteapdJev', 'mhjRcBEdRLcCjzY', 'h7f7b74']) == 'DvtFEPScf.mhjRcBEdRLcCjzY'
        assert candidate('YFebwCkvIuAZMSS', ['ngdcFFk', 'rKpI', 'dBuNBaoyj', 'KDOhWCW']) == 'YFebwCkvIuAZMSS.KDOhWCW'
        assert candidate('KCa8nLGyfXj', ['akcavtoz', 'dGcRdJvy', 'zqKBBNsa.VtlrD', 'gi6u9nb']) == 'KCa8nLGyfXj.zqKBBNsa.VtlrD'
        assert candidate('urNxXmhlB', ['EsLScJT', 'SWiAxrrF', 'hdrbK', 'vOWPLjnme']) == 'urNxXmhlB.EsLScJT'
        assert candidate('dbeKQKwUtAo', ['wdvRmSn', 'cqbY', 'BfN8pBB79dR']) == 'dbeKQKwUtAo.BfN8pBB79dR'
        assert candidate('Y/|AV#|MYZ', ['WyoGqXVR', '708570', '25024575', '@/@|-@|@+']) == 'Y/|AV#|MYZ.WyoGqXVR'
        assert candidate('TJtgRNIaQa', ['guiPFqN', 'bhuiJ', 'YCSy', 'czPP']) == 'TJtgRNIaQa.YCSy'
        assert candidate('NrcS', ['50553162', 'lVgIv']) == 'NrcS.50553162'
        assert candidate('M', ['RBt', 'COQJPLPJJ', '6qmKiUJJS', 'vZQOOz']) == 'M.COQJPLPJJ'
        assert candidate('AWf', ['841205799303', 'pcw']) == 'AWf.841205799303'
        assert candidate('L', ['QWj', 'KMYFP', 'rzK8b', 'UPmaPsYi']) == 'L.KMYFP'
        assert candidate('SP?HD|_ABHPQ', ['s', 'Jmq', 'cgc', 'k8D', 'tCdQj', '9NfaReAkABQcGapX']) == 'SP?HD|_ABHPQ.9NfaReAkABQcGapX'
        assert candidate('FWDRduVSzmNfK', ['DnafTbHwZ', 'PcNbbtOHL', 'bqeESK', 'pfsmfTbw']) == 'FWDRduVSzmNfK.PcNbbtOHL'
        assert candidate('xmHxmtgtKoW', ['ozBIeRLg', 'IFmNl5877mAu7H', 'btofzd', 'YjQoPf', '?+!%^']) == 'xmHxmtgtKoW.IFmNl5877mAu7H'
        assert candidate('kUroWx', ['1546026', 'mruE']) == 'kUroWx.1546026'
        assert candidate('Z#PZOXUAEP^J', ['TSHgFXt', '851647972', '508208216', '|?&=+$~']) == 'Z#PZOXUAEP^J.TSHgFXt'
        assert candidate('YameRore', ['HhAas', 'okIWILL123', 'WorkOut', 'Fails', '-_-']) == 'YameRore.okIWILL123'

if __name__ == '__main__':
    unittest.main()
