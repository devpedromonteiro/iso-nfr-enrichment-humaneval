
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    Return the number of index triples (i, j, k) with i < j < k such that
    a[i] + a[j] + a[k] is divisible by 3, where:

        a[x] = x * x - x + 1   for 1 <= x <= n

    Observation:
    Since x * x - x is always divisible by 2 but we only care modulo 3,
    evaluate the sequence modulo 3:

        x = 1 -> 1
        x = 2 -> 0
        x = 3 -> 1
        x = 4 -> 1
        x = 5 -> 0
        x = 6 -> 1

    The pattern repeats every 3 indices:
        x % 3 == 1 -> a[x] % 3 == 1
        x % 3 == 2 -> a[x] % 3 == 0
        x % 3 == 0 -> a[x] % 3 == 1

    So every element is either 0 or 1 modulo 3.
    A triple sum is divisible by 3 only when all three values are 1 modulo 3.

    Therefore, the answer is:
        C(count_of_ones_mod_3, 3)

    where count_of_ones_mod_3 is the number of indices from 1 to n
    that are not congruent to 2 modulo 3.
    """
    count_with_remainder_zero = n // 3
    count_with_remainder_one = (n + 2) // 3
    count_with_remainder_two = (n + 1) // 3

    count_values_congruent_to_one_mod_3 = (
        count_with_remainder_zero + count_with_remainder_one
    )

    if count_values_congruent_to_one_mod_3 < 3:
        return 0

    m = count_values_congruent_to_one_mod_3
    return m * (m - 1) * (m - 2) // 6
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
