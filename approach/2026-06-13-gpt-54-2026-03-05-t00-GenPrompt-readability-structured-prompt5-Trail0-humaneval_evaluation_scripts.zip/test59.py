
import unittest
import re
import sys
import math
import copy



def largest_prime_factor(n: int):
    """Return the largest prime factor of n. Assume n > 1 and is not a prime.
    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    largest_factor = None

    while n % 2 == 0:
        largest_factor = 2
        n //= 2

    candidate_factor = 3
    while candidate_factor * candidate_factor <= n:
        while n % candidate_factor == 0:
            largest_factor = candidate_factor
            n //= candidate_factor
        candidate_factor += 2

    if n > 1:
        largest_factor = n

    return largest_factor
candidate = largest_prime_factor




METADATA = {}


def check(candidate):
    assert candidate(15) == 5
    assert candidate(27) == 3
    assert candidate(63) == 7
    assert candidate(330) == 11
    assert candidate(13195) == 29



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
