
import unittest
import re
import sys
import math
import copy



def fib(n: int) -> int:
    """Return the n-th Fibonacci number.

    The sequence is:
    0, 1, 1, 2, 3, 5, 8, ...

    >>> fib(10)
    55
    >>> fib(1)
    1
    >>> fib(8)
    21
    """
    if n < 0:
        raise ValueError("n must be a non-negative integer")

    if n == 0:
        return 0

    previous_number = 0
    current_number = 1

    for _ in range(1, n):
        previous_number, current_number = current_number, previous_number + current_number

    return current_number
candidate = fib




METADATA = {}


def check(candidate):
    assert candidate(10) == 55
    assert candidate(1) == 1
    assert candidate(8) == 21
    assert candidate(11) == 89
    assert candidate(12) == 144



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
