
import unittest
import re
import sys
import math
import copy


def anti_shuffle(text):
    """
    Return a version of the input string where each word's characters are
    sorted in ascending ASCII order, while preserving the original positions
    of spaces.

    Examples:
        anti_shuffle('Hi') -> 'Hi'
        anti_shuffle('hello') -> 'ehllo'
        anti_shuffle('Hello World!!!') -> 'Hello !!!Wdlor'
    """
    words = text.split(" ")
    sorted_words = []

    for word in words:
        sorted_word = "".join(sorted(word))
        sorted_words.append(sorted_word)

    return " ".join(sorted_words)
candidate = anti_shuffle


def check(candidate):

    # Check some simple cases
    assert candidate('Hi') == 'Hi'
    assert candidate('hello') == 'ehllo'
    assert candidate('number') == 'bemnru'
    assert candidate('abcd') == 'abcd'
    assert candidate('Hello World!!!') == 'Hello !!!Wdlor'
    assert candidate('') == ''
    assert candidate('Hi. My name is Mister Robot. How are you?') == '.Hi My aemn is Meirst .Rboot How aer ?ouy'
    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
