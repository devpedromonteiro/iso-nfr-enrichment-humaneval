
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math


def evaluate_polynomial(coefficients: list[float], x_value: float) -> float:
    """
    Evaluate a polynomial at a given x value.

    The polynomial is defined by its coefficients:
    coefficients[0] + coefficients[1] * x + coefficients[2] * x^2 + ...

    Example:
        coefficients = [1, 2, 3] represents 1 + 2x + 3x^2
    """
    return sum(
        coefficient * math.pow(x_value, power)
        for power, coefficient in enumerate(coefficients)
    )


def find_zero(coefficients: list[float]) -> float:
    """
    Find one real zero of a polynomial.

    The input must contain an even number of coefficients, and the highest
    non-zero coefficient must be positive. Under these assumptions, the
    polynomial is guaranteed to have at least one real zero.

    The function returns one zero, even if the polynomial has several.

    Examples:
        >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
        -0.5
        >>> round(find_zero([-6, 11, -6, 1]), 2)
        1.0
    """
    left = -1.0
    right = 1.0

    while evaluate_polynomial(coefficients, left) > 0:
        left *= 2

    while evaluate_polynomial(coefficients, right) < 0:
        right *= 2

    tolerance = 1e-7

    while right - left > tolerance:
        midpoint = (left + right) / 2
        midpoint_value = evaluate_polynomial(coefficients, midpoint)

        if midpoint_value == 0:
            return midpoint
        if midpoint_value < 0:
            left = midpoint
        else:
            right = midpoint

    return (left + right) / 2
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
