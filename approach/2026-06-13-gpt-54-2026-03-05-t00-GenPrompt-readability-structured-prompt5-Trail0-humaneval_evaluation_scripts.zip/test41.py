
import unittest
import re
import sys
import math
import copy



def car_race_collision(n: int) -> int:
    """
    Return the total number of collisions between two groups of cars.

    There are `n` cars moving from left to right and `n` cars moving from
    right to left. Every left-to-right car collides exactly once with every
    right-to-left car, so the total number of collisions is n * n.
    """
    cars_moving_left_to_right = n
    cars_moving_right_to_left = n

    total_collisions = cars_moving_left_to_right * cars_moving_right_to_left
    return total_collisions
candidate = car_race_collision




METADATA = {}


def check(candidate):
    assert candidate(2) == 4
    assert candidate(3) == 9
    assert candidate(4) == 16
    assert candidate(8) == 64
    assert candidate(10) == 100



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
