
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def string_xor(a: str, b: str) -> str:
    """Input are two strings a and b consisting only of 1s and 0s.
    Perform binary XOR on these inputs and return result also as a string.

    >>> string_xor('010', '110')
    '100'
    """
    if len(a) != len(b):
        raise ValueError("Inputs must have the same length.")

    result: List[str] = []

    for bit_a, bit_b in zip(a, b):
        if bit_a not in {"0", "1"} or bit_b not in {"0", "1"}:
            raise ValueError("Inputs must contain only '0' and '1'.")
        result.append("1" if bit_a != bit_b else "0")

    return "".join(result)
candidate = string_xor




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('111000', '101010') == '010010'
    assert candidate('1', '1') == '0'
    assert candidate('0101', '0000') == '0101'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
