
import unittest
import re
import sys
import math
import copy



def car_race_collision(n: int) -> int:
    """
    Imagine a road that's a perfectly straight infinitely long line.
    n cars are driving left to right; simultaneously, a different set of n cars
    are driving right to left. The two sets of cars start out being very far from
    each other. All cars move at the same speed.

    Two cars are said to collide when a car moving left to right meets a car
    moving right to left. Since the cars continue unaffected after colliding,
    every left-to-right car will collide exactly once with every right-to-left car.

    Therefore, the total number of collisions is:
        n * n

    Args:
        n: Number of cars moving in each direction.

    Returns:
        Total number of collisions.
    """
    return n * n
candidate = car_race_collision




METADATA = {}


def check(candidate):
    assert candidate(2) == 4
    assert candidate(3) == 9
    assert candidate(4) == 16
    assert candidate(8) == 64
    assert candidate(10) == 100



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
