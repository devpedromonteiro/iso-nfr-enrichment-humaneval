
import unittest
import re
import sys
import math
import copy


def is_sorted(lst):
    '''
    Given a list of numbers, return whether or not they are sorted
    in ascending order. If list has more than 1 duplicate of the same
    number, return False. Assume no negative numbers and only integers.

    Examples
    is_sorted([5]) â True
    is_sorted([1, 2, 3, 4, 5]) â True
    is_sorted([1, 3, 2, 4, 5]) â False
    is_sorted([1, 2, 3, 4, 5, 6]) â True
    is_sorted([1, 2, 3, 4, 5, 6, 7]) â True
    is_sorted([1, 3, 2, 4, 5, 6, 7]) â False
    is_sorted([1, 2, 2, 3, 3, 4]) â True
    is_sorted([1, 2, 2, 2, 3, 4]) â False
    '''
    counts = {}

    for i in range(len(lst) - 1):
        current = lst[i]
        next_value = lst[i + 1]

        if current > next_value:
            return False

        counts[current] = counts.get(current, 0) + 1
        if counts[current] > 2:
            return False

    if lst:
        last_value = lst[-1]
        counts[last_value] = counts.get(last_value, 0) + 1
        if counts[last_value] > 2:
            return False

    return True
candidate = is_sorted


def check(candidate):

    # Check some simple cases
    assert candidate([5]) == True
    assert candidate([1, 2, 3, 4, 5]) == True
    assert candidate([1, 3, 2, 4, 5]) == False
    assert candidate([1, 2, 3, 4, 5, 6]) == True
    assert candidate([1, 2, 3, 4, 5, 6, 7]) == True
    assert candidate([1, 3, 2, 4, 5, 6, 7]) == False, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([]) == True, "This prints if this assert fails 2 (good for debugging!)"
    assert candidate([1]) == True, "This prints if this assert fails 3 (good for debugging!)"
    assert candidate([3, 2, 1]) == False, "This prints if this assert fails 4 (good for debugging!)"
    
    # Check some edge cases that are easy to work out by hand.
    assert candidate([1, 2, 2, 2, 3, 4]) == False, "This prints if this assert fails 5 (good for debugging!)"
    assert candidate([1, 2, 3, 3, 3, 4]) == False, "This prints if this assert fails 6 (good for debugging!)"
    assert candidate([1, 2, 2, 3, 3, 4]) == True, "This prints if this assert fails 7 (good for debugging!)"
    assert candidate([1, 2, 3, 4]) == True, "This prints if this assert fails 8 (good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
