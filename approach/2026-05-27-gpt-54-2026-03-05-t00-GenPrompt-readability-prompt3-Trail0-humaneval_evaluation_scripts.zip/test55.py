
import unittest
import re
import sys
import math
import copy



def fib(n: int) -> int:
    """Return n-th Fibonacci number.

    >>> fib(10)
    55
    >>> fib(1)
    1
    >>> fib(8)
    21
    """
    if n <= 0:
        raise ValueError("n must be a positive integer")

    if n in (1, 2):
        return 1

    prev, curr = 1, 1
    for _ in range(3, n + 1):
        prev, curr = curr, prev + curr

    return curr
candidate = fib




METADATA = {}


def check(candidate):
    assert candidate(10) == 55
    assert candidate(1) == 1
    assert candidate(8) == 21
    assert candidate(11) == 89
    assert candidate(12) == 144



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
