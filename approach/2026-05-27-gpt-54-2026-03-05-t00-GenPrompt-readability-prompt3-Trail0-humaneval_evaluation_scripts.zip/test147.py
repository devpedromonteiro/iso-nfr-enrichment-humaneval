
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    You are given a positive integer n. Create an integer array a of length n where:
        a[i] = i * i - i + 1   for 1 <= i <= n

    Return the number of triples (a[i], a[j], a[k]) such that:
        i < j < k
        and a[i] + a[j] + a[k] is divisible by 3.

    Example:
        Input: n = 5
        Output: 1

        a = [1, 3, 7, 13, 21]
        The only valid triple is (1, 7, 13).
    """

    # Observe:
    # a[i] = i^2 - i + 1 = i(i - 1) + 1
    # Since i(i - 1) is always divisible by 2, that does not directly help for mod 3.
    #
    # Let's compute a[i] mod 3 based on i mod 3:
    # i % 3 == 0 -> a[i] % 3 = 1
    # i % 3 == 1 -> a[i] % 3 = 1
    # i % 3 == 2 -> a[i] % 3 = 0
    #
    # So:
    # - indices congruent to 2 mod 3 contribute values divisible by 3
    # - all other indices contribute values congruent to 1 mod 3
    #
    # For three numbers to sum to a multiple of 3, possible residue combinations are:
    # - (0, 0, 0)
    # - (1, 1, 1)
    #
    # Therefore, answer = C(count_0, 3) + C(count_1, 3)

    def combinations_of_3(x):
        if x < 3:
            return 0
        return x * (x - 1) * (x - 2) // 6

    count_mod_0 = n // 3  # indices where i % 3 == 2
    count_mod_1 = n - count_mod_0  # remaining indices

    return combinations_of_3(count_mod_0) + combinations_of_3(count_mod_1)
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
