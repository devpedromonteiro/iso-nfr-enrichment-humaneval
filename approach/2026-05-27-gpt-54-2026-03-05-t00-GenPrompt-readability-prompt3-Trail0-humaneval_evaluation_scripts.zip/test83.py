
import unittest
import re
import sys
import math
import copy


def starts_one_ends(n):
    """
    Given a positive integer n, return the count of the numbers of n-digit
    positive integers that start or end with 1.
    """
    if n <= 0:
        raise ValueError("n must be a positive integer")

    # Count n-digit numbers that start with 1:
    # first digit fixed as 1, remaining (n - 1) digits can be 0-9
    starts_with_1 = 10 ** (n - 1)

    # Count n-digit numbers that end with 1:
    # first digit can be 1-9, middle (n - 2) digits can be 0-9, last digit fixed as 1
    ends_with_1 = 9 * (10 ** (n - 2)) if n > 1 else 1

    # Count numbers counted in both groups:
    # start with 1 and end with 1
    both = 10 ** (n - 2) if n > 1 else 1

    # Use inclusion-exclusion
    return starts_with_1 + ends_with_1 - both
candidate = starts_one_ends


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(1) == 1
    assert candidate(2) == 18
    assert candidate(3) == 180
    assert candidate(4) == 1800
    assert candidate(5) == 18000

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
