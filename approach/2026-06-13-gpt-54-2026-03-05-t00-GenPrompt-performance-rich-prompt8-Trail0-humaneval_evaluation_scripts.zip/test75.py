
import unittest
import re
import sys
import math
import copy


def is_multiply_prime(a):
    """Return True if a is the product of exactly 3 primes, else False.

    Primes may repeat, e.g. 8 = 2 * 2 * 2 -> True.
    Constraint: a < 100.
    """
    if a < 8:  # smallest product of 3 primes is 2*2*2
        return False

    count = 0
    d = 2

    while d * d <= a and count < 3:
        while a % d == 0:
            a //= d
            count += 1
            if count > 3:
                return False
        d += 1

    if a > 1:
        count += 1

    return count == 3
candidate = is_multiply_prime


def check(candidate):

    assert candidate(5) == False
    assert candidate(30) == True
    assert candidate(8) == True
    assert candidate(10) == False
    assert candidate(125) == True
    assert candidate(3 * 5 * 7) == True
    assert candidate(3 * 6 * 7) == False
    assert candidate(9 * 9 * 9) == False
    assert candidate(11 * 9 * 9) == False
    assert candidate(11 * 13 * 7) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
