
import unittest
import re
import sys
import math
import copy


def split_words(txt):
    # Prefer whitespace split first
    if any(ch.isspace() for ch in txt):
        return txt.split()

    # Then comma split
    if ',' in txt:
        return txt.split(',')

    # Otherwise count lowercase letters with odd alphabet index
    count = 0
    for ch in txt:
        if 'a' <= ch <= 'z' and ((ord(ch) - ord('a')) % 2 == 1):
            count += 1
    return count
candidate = split_words


def check(candidate):

    assert candidate("Hello world!") == ["Hello","world!"]
    assert candidate("Hello,world!") == ["Hello","world!"]
    assert candidate("Hello world,!") == ["Hello","world,!"]
    assert candidate("Hello,Hello,world !") == ["Hello,Hello,world","!"]
    assert candidate("abcdef") == 3
    assert candidate("aaabb") == 2
    assert candidate("aaaBb") == 1
    assert candidate("") == 0


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
