
import unittest
import re
import sys
import math
import copy


def match_parens(lst):
    def stats(s):
        bal = 0
        min_bal = 0
        for ch in s:
            if ch == '(':
                bal += 1
            else:
                bal -= 1
            if bal < min_bal:
                min_bal = bal
        return bal, min_bal

    a, b = lst
    bal_a, min_a = stats(a)
    bal_b, min_b = stats(b)

    # Check a + b
    if min_a >= 0 and bal_a + bal_b == 0 and bal_a + min_b >= 0:
        return 'Yes'

    # Check b + a
    if min_b >= 0 and bal_b + bal_a == 0 and bal_b + min_a >= 0:
        return 'Yes'

    return 'No'
candidate = match_parens


def check(candidate):

    # Check some simple cases
    assert candidate(['()(', ')']) == 'Yes'
    assert candidate([')', ')']) == 'No'
    assert candidate(['(()(())', '())())']) == 'No'
    assert candidate([')())', '(()()(']) == 'Yes'
    assert candidate(['(())))', '(()())((']) == 'Yes'
    assert candidate(['()', '())']) == 'No'
    assert candidate(['(()(', '()))()']) == 'Yes'
    assert candidate(['((((', '((())']) == 'No'
    assert candidate([')(()', '(()(']) == 'No'
    assert candidate([')(', ')(']) == 'No'
    

    # Check some edge cases that are easy to work out by hand.
    assert candidate(['(', ')']) == 'Yes'
    assert candidate([')', '(']) == 'Yes' 



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
