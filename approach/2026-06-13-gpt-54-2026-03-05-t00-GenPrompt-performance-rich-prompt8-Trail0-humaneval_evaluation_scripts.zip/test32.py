
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[2] * x^2 + .... xs[n] * x^n
    """
    # Horner's method: O(n), no redundant pow calls, minimal allocations.
    result = 0.0
    for coeff in reversed(xs):
        result = result * x + coeff
    return result


def find_zero(xs: list):
    """xs are coefficients of a polynomial.
    find_zero finds x such that poly(x) = 0.
    find_zero returns only one zero point, even if there are many.
    Moreover, find_zero only takes list xs having even number of coefficients
    and largest non zero coefficient as it guarantees
    a solution.

    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3
    1.0
    """
    if not xs:
        raise ValueError("xs must not be empty")

    degree = len(xs) - 1
    while degree >= 0 and xs[degree] == 0:
        degree -= 1
    if degree < 0:
        raise ValueError("zero polynomial has infinitely many roots")

    # For odd degree polynomials, a real root is guaranteed.
    if degree % 2 == 0:
        raise ValueError("polynomial must have odd degree to guarantee a real root")

    def f(x: float) -> float:
        return poly(xs, x)

    # Find a bracket [lo, hi] with opposite signs.
    lo, hi = -1.0, 1.0
    flo, fhi = f(lo), f(hi)

    while flo == 0:
        return lo
    while fhi == 0:
        return hi

    while flo * fhi > 0:
        lo *= 2.0
        hi *= 2.0
        flo, fhi = f(lo), f(hi)

    # Bisection: bounded resource usage, robust convergence.
    for _ in range(100):
        mid = (lo + hi) / 2.0
        fmid = f(mid)

        if fmid == 0 or abs(hi - lo) < 1e-12:
            return mid

        if flo * fmid <= 0:
            hi, fhi = mid, fmid
        else:
            lo, flo = mid, fmid

    return (lo + hi) / 2.0
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
