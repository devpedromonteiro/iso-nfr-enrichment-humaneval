
import unittest
import re
import sys
import math
import copy


def solve(s):
    has_letter = False
    chars = list(s)

    for i, ch in enumerate(chars):
        if 'a' <= ch <= 'z':
            chars[i] = chr(ord(ch) - 32)
            has_letter = True
        elif 'A' <= ch <= 'Z':
            chars[i] = chr(ord(ch) + 32)
            has_letter = True

    if has_letter:
        return ''.join(chars)
    return s[::-1]
candidate = solve


def check(candidate):

    # Check some simple cases
    assert candidate("AsDf") == "aSdF"
    assert candidate("1234") == "4321"
    assert candidate("ab") == "AB"
    assert candidate("#a@C") == "#A@c"
    assert candidate("#AsdfW^45") == "#aSDFw^45"
    assert candidate("#6@2") == "2@6#"

    # Check some edge cases that are easy to work out by hand.
    assert candidate("#$a^D") == "#$A^d"
    assert candidate("#ccc") == "#CCC"

    # Don't remove this line:


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
