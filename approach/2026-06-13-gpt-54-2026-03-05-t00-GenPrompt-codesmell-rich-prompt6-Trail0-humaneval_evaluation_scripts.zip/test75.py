
import unittest
import re
import sys
import math
import copy


def is_multiply_prime(a):
    """Return True if a is the product of exactly 3 prime numbers, else False."""
    if a < 2:
        return False

    prime_factors = _prime_factors(a)
    return len(prime_factors) == 3 and _product(prime_factors) == a


def _prime_factors(n):
    """Return the prime factors of n, including repeated factors."""
    factors = []
    divisor = 2

    while divisor * divisor <= n:
        while n % divisor == 0:
            factors.append(divisor)
            n //= divisor
        divisor += 1

    if n > 1:
        factors.append(n)

    return factors


def _product(numbers):
    """Return the product of a list of numbers."""
    result = 1
    for number in numbers:
        result *= number
    return result
candidate = is_multiply_prime


def check(candidate):

    assert candidate(5) == False
    assert candidate(30) == True
    assert candidate(8) == True
    assert candidate(10) == False
    assert candidate(125) == True
    assert candidate(3 * 5 * 7) == True
    assert candidate(3 * 6 * 7) == False
    assert candidate(9 * 9 * 9) == False
    assert candidate(11 * 9 * 9) == False
    assert candidate(11 * 13 * 7) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
