
import unittest
import re
import sys
import math
import copy


def _has_text(txt):
    return bool(txt)


def _last_char(txt):
    return txt[-1]


def _char_before_last(txt):
    return txt[-2] if len(txt) > 1 else None


def _is_single_letter_word(last_char, previous_char):
    return last_char.isalpha() and previous_char == " "


def check_if_last_char_is_a_letter(txt):
    '''
    Create a function that returns True if the last character
    of a given string is an alphabetical character and is not
    a part of a word, and False otherwise.
    Note: "word" is a group of characters separated by space.

    Examples:
    check_if_last_char_is_a_letter("apple pie") â False
    check_if_last_char_is_a_letter("apple pi e") â True
    check_if_last_char_is_a_letter("apple pi e ") â False
    check_if_last_char_is_a_letter("") â False 
    '''
    if not _has_text(txt):
        return False

    last_char = _last_char(txt)
    previous_char = _char_before_last(txt)

    if previous_char is None:
        return last_char.isalpha()

    return _is_single_letter_word(last_char, previous_char)
candidate = check_if_last_char_is_a_letter


def check(candidate):

    # Check some simple cases
    assert candidate("apple") == False
    assert candidate("apple pi e") == True
    assert candidate("eeeee") == False
    assert candidate("A") == True
    assert candidate("Pumpkin pie ") == False
    assert candidate("Pumpkin pie 1") == False
    assert candidate("") == False
    assert candidate("eeeee e ") == False
    assert candidate("apple pie") == False
    assert candidate("apple pi e ") == False

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
