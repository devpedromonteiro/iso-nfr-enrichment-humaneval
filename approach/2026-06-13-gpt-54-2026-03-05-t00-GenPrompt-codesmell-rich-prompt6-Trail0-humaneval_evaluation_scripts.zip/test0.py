
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def _sorted_numbers(numbers: List[float]) -> List[float]:
    """Return a sorted copy of the input numbers."""
    return sorted(numbers)


def _has_close_neighbors(sorted_numbers: List[float], threshold: float) -> bool:
    """Check adjacent values in a sorted list for distances below threshold."""
    for index in range(1, len(sorted_numbers)):
        if sorted_numbers[index] - sorted_numbers[index - 1] < threshold:
            return True
    return False


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """Check whether any two numbers in the list are closer than the threshold.

    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    sorted_nums = _sorted_numbers(numbers)
    return _has_close_neighbors(sorted_nums, threshold)
candidate = has_close_elements




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([1.0, 2.0, 3.9, 4.0, 5.0, 2.2], 0.3) == True
    assert candidate([1.0, 2.0, 3.9, 4.0, 5.0, 2.2], 0.05) == False
    assert candidate([1.0, 2.0, 5.9, 4.0, 5.0], 0.95) == True
    assert candidate([1.0, 2.0, 5.9, 4.0, 5.0], 0.8) == False
    assert candidate([1.0, 2.0, 3.0, 4.0, 5.0, 2.0], 0.1) == True
    assert candidate([1.1, 2.2, 3.1, 4.1, 5.1], 1.0) == True
    assert candidate([1.1, 2.2, 3.1, 4.1, 5.1], 0.5) == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
