
import unittest
import re
import sys
import math
import copy


def _tri_value(index):
    """Return the Tribonacci value for a single index."""
    if index == 0:
        return 1
    if index == 1:
        return 3
    if index % 2 == 0:
        return 1 + index // 2
    return _tri_value(index - 1) + _tri_value(index - 2) + _tri_value(index + 1)


def _build_sequence(limit):
    """Build Tribonacci sequence values from 0 to limit."""
    if limit < 0:
        return []

    sequence = [0] * (limit + 1)
    sequence[0] = 1

    if limit >= 1:
        sequence[1] = 3

    for index in range(2, limit + 1):
        if index % 2 == 0:
            sequence[index] = 1 + index // 2
        else:
            sequence[index] = sequence[index - 1] + sequence[index - 2] + (1 + (index + 1) // 2)

    return sequence


def tri(n):
    """Return the first n + 1 numbers of the Tribonacci sequence.

    Tribonacci sequence is defined by:
    tri(1) = 3
    tri(n) = 1 + n / 2, if n is even
    tri(n) = tri(n - 1) + tri(n - 2) + tri(n + 1), if n is odd

    Example:
    tri(3) == [1, 3, 2, 8]
    """
    return _build_sequence(n)
candidate = tri


def check(candidate):

    # Check some simple cases
    
    assert candidate(3) == [1, 3, 2.0, 8.0]
    assert candidate(4) == [1, 3, 2.0, 8.0, 3.0]
    assert candidate(5) == [1, 3, 2.0, 8.0, 3.0, 15.0]
    assert candidate(6) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0]
    assert candidate(7) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0]
    assert candidate(8) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0]
    assert candidate(9) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0]
    assert candidate(20) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0, 6.0, 48.0, 7.0, 63.0, 8.0, 80.0, 9.0, 99.0, 10.0, 120.0, 11.0]

    # Check some edge cases that are easy to work out by hand.
    assert candidate(0) == [1]
    assert candidate(1) == [1, 3]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
