
import unittest
import re
import sys
import math
import copy



def _third_indices(length: int) -> list[int]:
    """Return indices divisible by three for a sequence of given length."""
    return list(range(0, length, 3))


def _sorted_values_at_indices(items: list, indices: list[int]) -> list:
    """Return sorted values from items located at the given indices."""
    return sorted(items[index] for index in indices)


def sort_third(l: list):
    """Return a copy of l where values at indices divisible by three are sorted.

    Indices not divisible by three remain unchanged.

    >>> sort_third([1, 2, 3])
    [1, 2, 3]
    >>> sort_third([5, 6, 3, 4, 8, 9, 2])
    [2, 6, 3, 4, 8, 9, 5]
    """
    result = list(l)
    indices = _third_indices(len(l))
    sorted_third_values = _sorted_values_at_indices(l, indices)

    for index, value in zip(indices, sorted_third_values):
        result[index] = value

    return result
candidate = sort_third




METADATA = {}


def check(candidate):
    assert tuple(candidate([1, 2, 3])) == tuple(sort_third([1, 2, 3]))
    assert tuple(candidate([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])) == tuple(sort_third([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10]))
    assert tuple(candidate([5, 8, -12, 4, 23, 2, 3, 11, 12, -10])) == tuple(sort_third([5, 8, -12, 4, 23, 2, 3, 11, 12, -10]))
    assert tuple(candidate([5, 6, 3, 4, 8, 9, 2])) == tuple([2, 6, 3, 4, 8, 9, 5])
    assert tuple(candidate([5, 8, 3, 4, 6, 9, 2])) == tuple([2, 8, 3, 4, 6, 9, 5])
    assert tuple(candidate([5, 6, 9, 4, 8, 3, 2])) == tuple([2, 6, 9, 4, 8, 3, 5])
    assert tuple(candidate([5, 6, 3, 4, 8, 9, 2, 1])) == tuple([2, 6, 3, 4, 8, 9, 5, 1])



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
