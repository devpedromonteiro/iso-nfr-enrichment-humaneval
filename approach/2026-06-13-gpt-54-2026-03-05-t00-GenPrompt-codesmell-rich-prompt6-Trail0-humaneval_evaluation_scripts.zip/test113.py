
import unittest
import re
import sys
import math
import copy


def count_odd_digits(text):
    """Return the number of odd digits in a digit-only string."""
    return sum(1 for char in text if int(char) % 2 == 1)


def build_message(count):
    """Build the required output message for a given odd-digit count."""
    template = "the number of odd elements in the string i of the input."
    return template.replace("i", str(count))


def odd_count(lst):
    """Given a list of digit strings, return formatted odd-digit counts.

    >>> odd_count(['1234567'])
    ["the number of odd elements 4n the str4ng 4 of the 4nput."]
    >>> odd_count(['3', "11111111"])
    ["the number of odd elements 1n the str1ng 1 of the 1nput.",
     "the number of odd elements 8n the str8ng 8 of the 8nput."]
    """
    return [build_message(count_odd_digits(item)) for item in lst]
candidate = odd_count


def check(candidate):

    # Check some simple cases
    assert candidate(['1234567']) == ["the number of odd elements 4n the str4ng 4 of the 4nput."], "Test 1"
    assert candidate(['3',"11111111"]) == ["the number of odd elements 1n the str1ng 1 of the 1nput.", "the number of odd elements 8n the str8ng 8 of the 8nput."], "Test 2"
    assert candidate(['271', '137', '314']) == [
        'the number of odd elements 2n the str2ng 2 of the 2nput.',
        'the number of odd elements 3n the str3ng 3 of the 3nput.',
        'the number of odd elements 2n the str2ng 2 of the 2nput.'
    ]

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
