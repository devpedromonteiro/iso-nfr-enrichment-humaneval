
import unittest
import re
import sys
import math
import copy


def _signed_digit_sum(number):
    """Return the sum of digits, treating the first digit as signed for negatives."""
    if number >= 0:
        return sum(int(digit) for digit in str(number))

    digits = str(number)[1:]
    if not digits:
        return 0

    first_digit = -int(digits[0])
    remaining_sum = sum(int(digit) for digit in digits[1:])
    return first_digit + remaining_sum


def _has_positive_signed_digit_sum(number):
    """Return True if the signed digit sum of number is greater than zero."""
    return _signed_digit_sum(number) > 0


def count_nums(arr):
    """
    Write a function count_nums which takes an array of integers and returns
    the number of elements which has a sum of digits > 0.
    If a number is negative, then its first signed digit will be negative:
    e.g. -123 has signed digits -1, 2, and 3.
    >>> count_nums([]) == 0
    >>> count_nums([-1, 11, -11]) == 1
    >>> count_nums([1, 1, 2]) == 3
    """
    return sum(1 for number in arr if _has_positive_signed_digit_sum(number))
candidate = count_nums


def check(candidate):

    # Check some simple cases
    assert candidate([]) == 0
    assert candidate([-1, -2, 0]) == 0
    assert candidate([1, 1, 2, -2, 3, 4, 5]) == 6
    assert candidate([1, 6, 9, -6, 0, 1, 5]) == 5
    assert candidate([1, 100, 98, -7, 1, -1]) == 4
    assert candidate([12, 23, 34, -45, -56, 0]) == 5
    assert candidate([-0, 1**0]) == 1
    assert candidate([1]) == 1

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
