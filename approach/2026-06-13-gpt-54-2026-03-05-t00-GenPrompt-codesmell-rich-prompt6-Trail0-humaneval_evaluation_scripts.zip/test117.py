
import unittest
import re
import sys
import math
import copy


def _is_consonant(char):
    return char.isalpha() and char.lower() not in "aeiou"


def _count_consonants(word):
    return sum(1 for char in word if _is_consonant(char))


def _matches_consonant_count(word, expected_count):
    return _count_consonants(word) == expected_count


def select_words(s, n):
    """Return words from s that contain exactly n consonants."""
    if not s:
        return []

    words = s.split()
    return [word for word in words if _matches_consonant_count(word, n)]
candidate = select_words


def check(candidate):

    # Check some simple cases
    assert candidate("Mary had a little lamb", 4) == ["little"], "First test error: " + str(candidate("Mary had a little lamb", 4))      
    assert candidate("Mary had a little lamb", 3) == ["Mary", "lamb"], "Second test error: " + str(candidate("Mary had a little lamb", 3))  
    assert candidate("simple white space", 2) == [], "Third test error: " + str(candidate("simple white space", 2))      
    assert candidate("Hello world", 4) == ["world"], "Fourth test error: " + str(candidate("Hello world", 4))  
    assert candidate("Uncle sam", 3) == ["Uncle"], "Fifth test error: " + str(candidate("Uncle sam", 3))


    # Check some edge cases that are easy to work out by hand.
    assert candidate("", 4) == [], "1st edge test error: " + str(candidate("", 4))
    assert candidate("a b c d e f", 1) == ["b", "c", "d", "f"], "2nd edge test error: " + str(candidate("a b c d e f", 1))



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
