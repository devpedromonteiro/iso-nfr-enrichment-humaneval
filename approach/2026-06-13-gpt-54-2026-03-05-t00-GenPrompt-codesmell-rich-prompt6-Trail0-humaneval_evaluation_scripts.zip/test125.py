
import unittest
import re
import sys
import math
import copy


def _split_on_whitespace(txt):
    return txt.split()


def _split_on_comma(txt):
    return txt.split(",")


def _count_odd_order_lowercase_letters(txt):
    return sum(1 for char in txt if char.islower() and (ord(char) - ord("a")) % 2 == 1)


def split_words(txt):
    """
    Given a string of words, return a list of words split on whitespace.
    If no whitespace exists in the text, split on commas ','.
    If no commas exist, return the number of lower-case letters with odd order
    in the alphabet, where ord('a') = 0, ord('b') = 1, ... ord('z') = 25.

    Examples:
    split_words("Hello world!") -> ["Hello", "world!"]
    split_words("Hello,world!") -> ["Hello", "world!"]
    split_words("abcdef") -> 3
    """
    if any(char.isspace() for char in txt):
        return _split_on_whitespace(txt)

    if "," in txt:
        return _split_on_comma(txt)

    return _count_odd_order_lowercase_letters(txt)
candidate = split_words


def check(candidate):

    assert candidate("Hello world!") == ["Hello","world!"]
    assert candidate("Hello,world!") == ["Hello","world!"]
    assert candidate("Hello world,!") == ["Hello","world,!"]
    assert candidate("Hello,Hello,world !") == ["Hello,Hello,world","!"]
    assert candidate("abcdef") == 3
    assert candidate("aaabb") == 2
    assert candidate("aaaBb") == 1
    assert candidate("") == 0


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
