
import unittest
import re
import sys
import math
import copy


def _integer_cube_root(value):
    """Return the truncated integer cube root of a non-negative integer."""
    return round(value ** (1 / 3))


def _is_perfect_cube(value):
    """Check whether a non-negative integer is a perfect cube."""
    root = _integer_cube_root(value)
    return root ** 3 == value


def iscube(a):
    """
    Return True if a is a cube of some integer, otherwise False.
    """
    absolute_value = abs(a)
    return _is_perfect_cube(absolute_value)
candidate = iscube


def check(candidate):

    # Check some simple cases
    assert candidate(1) == True, "First test error: " + str(candidate(1))
    assert candidate(2) == False, "Second test error: " + str(candidate(2))
    assert candidate(-1) == True, "Third test error: " + str(candidate(-1))
    assert candidate(64) == True, "Fourth test error: " + str(candidate(64))
    assert candidate(180) == False, "Fifth test error: " + str(candidate(180))
    assert candidate(1000) == True, "Sixth test error: " + str(candidate(1000))


    # Check some edge cases that are easy to work out by hand.
    assert candidate(0) == True, "1st edge test error: " + str(candidate(0))
    assert candidate(1729) == False, "2nd edge test error: " + str(candidate(1728))



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
