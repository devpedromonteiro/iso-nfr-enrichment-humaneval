
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


WHOLE_NOTE = "o"
HALF_NOTE = "o|"
QUARTER_NOTE = ".|"

NOTE_TO_BEATS = {
    WHOLE_NOTE: 4,
    HALF_NOTE: 2,
    QUARTER_NOTE: 1,
}


def _split_notes(music_string: str) -> List[str]:
    """Split the input string into individual note tokens."""
    return music_string.split()


def _parse_note(note: str) -> int:
    """Convert a single note token into its beat count."""
    return NOTE_TO_BEATS[note]


def parse_music(music_string: str) -> List[int]:
    """Input to this function is a string representing musical notes in a special ASCII format.
    Your task is to parse this string and return list of integers corresponding to how many beats does each
    note last.

    Here is a legend:
    'o' - whole note, lasts four beats
    'o|' - half note, lasts two beats
    '.|' - quarter note, lasts one beat

    >>> parse_music('o o| .| o| o| .| .| .| .| o o')
    [4, 2, 1, 2, 2, 1, 1, 1, 1, 4, 4]
    """
    notes = _split_notes(music_string)
    return [_parse_note(note) for note in notes]
candidate = parse_music




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == []
    assert candidate('o o o o') == [4, 4, 4, 4]
    assert candidate('.| .| .| .|') == [1, 1, 1, 1]
    assert candidate('o| o| .| .| o o o o') == [2, 2, 1, 1, 4, 4, 4, 4]
    assert candidate('o| .| o| .| o o| o o|') == [2, 1, 2, 1, 4, 2, 4, 2]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
