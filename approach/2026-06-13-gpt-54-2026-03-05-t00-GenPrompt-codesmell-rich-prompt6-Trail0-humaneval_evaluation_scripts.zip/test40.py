
import unittest
import re
import sys
import math
import copy



from typing import List


def triples_sum_to_zero(l: List[int]) -> bool:
    """
    triples_sum_to_zero takes a list of integers as an input.
    it returns True if there are three distinct elements in the list that
    sum to zero, and False otherwise.

    >>> triples_sum_to_zero([1, 3, 5, 0])
    False
    >>> triples_sum_to_zero([1, 3, -2, 1])
    True
    >>> triples_sum_to_zero([1, 2, 3, 7])
    False
    >>> triples_sum_to_zero([2, 4, -5, 3, 9, 7])
    True
    >>> triples_sum_to_zero([1])
    False
    """
    if len(l) < 3:
        return False

    sorted_values = sorted(l)
    return _has_zero_sum_triplet(sorted_values)


def _has_zero_sum_triplet(values: List[int]) -> bool:
    """Check whether a sorted list contains any triplet summing to zero."""
    for index in range(len(values) - 2):
        if _has_matching_pair(values, index):
            return True
    return False


def _has_matching_pair(values: List[int], fixed_index: int) -> bool:
    """
    For a fixed element in a sorted list, use the two-pointer technique
    to find whether two other distinct elements complete a zero-sum triplet.
    """
    left = fixed_index + 1
    right = len(values) - 1
    target = -values[fixed_index]

    while left < right:
        current_sum = values[left] + values[right]

        if current_sum == target:
            return True
        if current_sum < target:
            left += 1
        else:
            right -= 1

    return False
candidate = triples_sum_to_zero




METADATA = {}


def check(candidate):
    assert candidate([1, 3, 5, 0]) == False
    assert candidate([1, 3, 5, -1]) == False
    assert candidate([1, 3, -2, 1]) == True
    assert candidate([1, 2, 3, 7]) == False
    assert candidate([1, 2, 5, 7]) == False
    assert candidate([2, 4, -5, 3, 9, 7]) == True
    assert candidate([1]) == False
    assert candidate([1, 3, 5, -100]) == False
    assert candidate([100, 3, 5, -100]) == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
