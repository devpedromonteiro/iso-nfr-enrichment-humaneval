
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def _build_prefixes(text: str) -> List[str]:
    """Build all prefixes of the given text from shortest to longest."""
    return [text[:index] for index in range(1, len(text) + 1)]


def all_prefixes(string: str) -> List[str]:
    """Return list of all prefixes from shortest to longest of the input string.

    >>> all_prefixes('abc')
    ['a', 'ab', 'abc']
    """
    return _build_prefixes(string)
candidate = all_prefixes




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == []
    assert candidate('asdfgh') == ['a', 'as', 'asd', 'asdf', 'asdfg', 'asdfgh']
    assert candidate('WWW') == ['W', 'WW', 'WWW']


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
