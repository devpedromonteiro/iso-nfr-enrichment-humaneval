
import unittest
import re
import sys
import math
import copy


def solution(lst):
    """Given a non-empty list of integers, return the sum of all odd elements
    that are in even positions (0-based indexing).

    Examples
    --------
    solution([5, 8, 7, 1]) == 12
    solution([3, 3, 3, 3, 3]) == 9
    solution([30, 13, 24, 321]) == 0
    """
    if lst is None:
        raise TypeError("lst must be a non-empty list of integers, got None")

    if not isinstance(lst, list):
        raise TypeError(f"lst must be of type list, got {type(lst).__name__}")

    if not lst:
        raise ValueError("lst must be a non-empty list")

    if not all(isinstance(x, int) for x in lst):
        raise TypeError("all elements in lst must be integers")

    total = 0
    try:
        for i, value in enumerate(lst):
            if i % 2 == 0 and value % 2 != 0:
                total += value
    except TypeError as exc:
        raise TypeError("failed while processing list elements") from exc
    except Exception:
        # Re-raise unexpected exceptions to avoid silently swallowing errors
        raise

    return total
candidate = solution


def check(candidate):

    # Check some simple cases
    assert candidate([5, 8, 7, 1])    == 12
    assert candidate([3, 3, 3, 3, 3]) == 9
    assert candidate([30, 13, 24, 321]) == 0
    assert candidate([5, 9]) == 5
    assert candidate([2, 4, 8]) == 0
    assert candidate([30, 13, 23, 32]) == 23
    assert candidate([3, 13, 2, 9]) == 3

    # Check some edge cases that are easy to work out by hand.



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
