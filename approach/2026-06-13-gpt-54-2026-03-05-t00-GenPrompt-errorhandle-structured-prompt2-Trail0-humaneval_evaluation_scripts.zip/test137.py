
import unittest
import re
import sys
import math
import copy


def compare_one(a, b):
    """
    Create a function that takes integers, floats, or strings representing
    real numbers, and returns the larger variable in its given variable type.
    Return None if the values are equal.
    Note: If a real number is represented as a string, the floating point might be . or ,

    compare_one(1, 2.5) â 2.5
    compare_one(1, "2,3") â "2,3"
    compare_one("5,1", "6") â "6"
    compare_one("1", 1) â None
    """

    def to_number(value):
        if isinstance(value, bool):
            raise TypeError("Boolean values are not valid numeric inputs.")
        if isinstance(value, (int, float)):
            return float(value)
        if isinstance(value, str):
            normalized = value.replace(",", ".").strip()
            if not normalized:
                raise ValueError("String input cannot be empty or whitespace.")
            try:
                return float(normalized)
            except ValueError as exc:
                raise ValueError(f"Invalid numeric string: {value!r}") from exc
        raise TypeError(
            f"Unsupported input type: {type(value).__name__}. "
            "Expected int, float, or numeric string."
        )

    num_a = to_number(a)
    num_b = to_number(b)

    if num_a > num_b:
        return a
    if num_b > num_a:
        return b
    return None
candidate = compare_one


def check(candidate):

    # Check some simple cases
    assert candidate(1, 2) == 2
    assert candidate(1, 2.5) == 2.5
    assert candidate(2, 3) == 3
    assert candidate(5, 6) == 6
    assert candidate(1, "2,3") == "2,3"
    assert candidate("5,1", "6") == "6"
    assert candidate("1", "2") == "2"
    assert candidate("1", 1) == None

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
