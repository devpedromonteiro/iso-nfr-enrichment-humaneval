
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    You are given a positive integer n. You have to create an integer array a of length n.
    For each i (1 â¤ i â¤ n), the value of a[i] = i * i - i + 1.
    Return the number of triples (a[i], a[j], a[k]) where i < j < k and
    a[i] + a[j] + a[k] is a multiple of 3.

    Example:
        Input: n = 5
        Output: 1
    """
    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if isinstance(n, bool):
        raise TypeError("n must be an integer, not bool")
    if n <= 0:
        raise ValueError("n must be a positive integer")

    try:
        counts = [0, 0, 0]

        for i in range(1, n + 1):
            value_mod = (i * i - i + 1) % 3
            counts[value_mod] += 1

        c0, c1, c2 = counts

        def comb3(x):
            return x * (x - 1) * (x - 2) // 6 if x >= 3 else 0

        result = 0

        # Triples with residues summing to 0 mod 3:
        # (0,0,0), (1,1,1), (2,2,2), and (0,1,2)
        result += comb3(c0)
        result += comb3(c1)
        result += comb3(c2)
        result += c0 * c1 * c2

        return result

    except OverflowError:
        raise OverflowError("numeric overflow occurred while computing triples")
    except Exception:
        raise RuntimeError("failed to compute the number of valid triples")
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
