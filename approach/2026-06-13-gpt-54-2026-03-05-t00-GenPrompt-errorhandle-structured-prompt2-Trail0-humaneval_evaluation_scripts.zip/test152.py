
import unittest
import re
import sys
import math
import copy


def compare(game, guess):
    """Return per-match absolute differences between actual scores and guesses.

    Each argument must be an iterable of equal length containing numeric values.
    A correct guess yields 0; otherwise the absolute difference is returned.

    Examples:
        compare([1, 2, 3], [1, 0, 5]) -> [0, 2, 2]
    """
    if game is None or guess is None:
        raise ValueError("game and guess must not be None")

    if not isinstance(game, (list, tuple)):
        raise TypeError("game must be a list or tuple of numbers")

    if not isinstance(guess, (list, tuple)):
        raise TypeError("guess must be a list or tuple of numbers")

    if len(game) != len(guess):
        raise ValueError("game and guess must have the same length")

    result = []

    for index, (score, predicted) in enumerate(zip(game, guess)):
        if not isinstance(score, (int, float)) or isinstance(score, bool):
            raise TypeError(f"game[{index}] must be a number")
        if not isinstance(predicted, (int, float)) or isinstance(predicted, bool):
            raise TypeError(f"guess[{index}] must be a number")

        result.append(abs(score - predicted))

    return result
candidate = compare


def check(candidate):

    # Check some simple cases
    assert candidate([1,2,3,4,5,1],[1,2,3,4,2,-2])==[0,0,0,0,3,3], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([0,0,0,0,0,0],[0,0,0,0,0,0])==[0,0,0,0,0,0], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,2,3],[-1,-2,-3])==[2,4,6], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,2,3,5],[-1,2,3,4])==[2,0,0,1], "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
