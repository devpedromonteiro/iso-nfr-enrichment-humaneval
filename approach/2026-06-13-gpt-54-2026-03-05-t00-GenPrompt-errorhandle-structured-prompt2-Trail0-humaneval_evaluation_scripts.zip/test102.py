
import unittest
import re
import sys
import math
import copy


def choose_num(x, y):
    """Return the largest even integer in the inclusive range [x, y].

    The function expects two positive integers. If x > y, or if there is no
    even integer in the range, it returns -1.

    Raises:
        TypeError: If x or y is not an integer.
        ValueError: If x or y is not positive.
    """
    if not isinstance(x, int) or not isinstance(y, int):
        raise TypeError("x and y must both be integers")

    if x <= 0 or y <= 0:
        raise ValueError("x and y must both be positive integers")

    if x > y:
        return -1

    if y % 2 == 0:
        return y

    candidate = y - 1
    return candidate if candidate >= x else -1
candidate = choose_num


def check(candidate):

    # Check some simple cases
    assert candidate(12, 15) == 14
    assert candidate(13, 12) == -1
    assert candidate(33, 12354) == 12354
    assert candidate(5234, 5233) == -1
    assert candidate(6, 29) == 28
    assert candidate(27, 10) == -1

    # Check some edge cases that are easy to work out by hand.
    assert candidate(7, 7) == -1
    assert candidate(546, 546) == 546



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
