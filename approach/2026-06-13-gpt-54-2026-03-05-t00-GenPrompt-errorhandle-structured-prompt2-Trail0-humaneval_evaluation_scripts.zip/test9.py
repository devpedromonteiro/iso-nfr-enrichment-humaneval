
import unittest
import re
import sys
import math
import copy

from typing import List, Tuple


from typing import List


def rolling_max(numbers: List[int]) -> List[int]:
    """From a given list of integers, generate a list of rolling maximums seen so far.

    Args:
        numbers: A list of integers.

    Returns:
        A list where each element is the maximum value encountered up to that index.

    Raises:
        TypeError: If `numbers` is not a list or contains non-integer elements.
        ValueError: If `numbers` is empty.

    Examples:
        >>> rolling_max([1, 2, 3, 2, 3, 4, 2])
        [1, 2, 3, 3, 3, 4, 4]
    """
    if not isinstance(numbers, list):
        raise TypeError("numbers must be a list of integers")

    if not numbers:
        raise ValueError("numbers must not be empty")

    for i, value in enumerate(numbers):
        if not isinstance(value, int):
            raise TypeError(f"numbers[{i}] must be an integer, got {type(value).__name__}")

    result: List[int] = []
    current_max = numbers[0]

    for value in numbers:
        if value > current_max:
            current_max = value
        result.append(current_max)

    return result
candidate = rolling_max




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == []
    assert candidate([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert candidate([4, 3, 2, 1]) == [4, 4, 4, 4]
    assert candidate([3, 2, 3, 100, 3]) == [3, 3, 3, 100, 100]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
