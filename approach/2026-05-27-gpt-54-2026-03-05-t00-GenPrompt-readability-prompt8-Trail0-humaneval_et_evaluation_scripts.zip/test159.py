
import unittest


def eat(number, need, remaining):
    """
    You're a hungry rabbit, and you already have eaten a certain number of carrots,
    but now you need to eat more carrots to complete the day's meals.

    Return:
        [total_eaten_after_meal, carrots_left]

    Rules:
    - If there are enough carrots remaining, eat exactly `need`.
    - Otherwise, eat all remaining carrots.
    """
    eaten_now = min(need, remaining)
    total_eaten = number + eaten_now
    carrots_left = remaining - eaten_now

    return [total_eaten, carrots_left]
candidate = eat


class Test(unittest.TestCase):
    def test(self):
        assert candidate(5, 11, 12) == [16, 1]
        assert candidate(5, 6, 5) == [10, 0]
        assert candidate(5, 10, 5) == [10, 0]
        assert candidate(7, 15, 3) == [10, 0]
        assert candidate(4, 5, 11) == [9, 6]
        assert candidate(9, 6, 9) == [15, 3]
        assert candidate(1, 16, 6) == [7, 0]
        assert candidate(9, 1, 6) == [10, 5]
        assert candidate(5, 6, 10) == [11, 4], "Error"
        assert candidate(8, 1, 9) == [9, 8]
        assert candidate(4, 9, 9) == [13, 0]
        assert candidate(1, 1, 10) == [2, 9]
        assert candidate(1, 9, 6) == [7, 0]
        assert candidate(1, 6, 4) == [5, 0]
        assert candidate(10, 9, 12) == [19, 3]
        assert candidate(8, 13, 9) == [17, 0]
        assert candidate(4, 10, 8) == [12, 0]
        assert candidate(5, 5, 11) == [10, 6]
        assert candidate(4, 13, 10) == [14, 0]
        assert candidate(6, 14, 10) == [16, 0]
        assert candidate(4, 8, 10) == [12, 2]
        assert candidate(2, 3, 9) == [5, 6]
        assert candidate(1, 13, 7) == [8, 0]
        assert candidate(4, 3, 6) == [7, 3]
        assert candidate(3, 9, 5) == [8, 0]
        assert candidate(3, 9, 7) == [10, 0]
        assert candidate(7, 2, 6) == [9, 4]
        assert candidate(5, 12, 10) == [15, 0]
        assert candidate(7, 4, 9) == [11, 5]
        assert candidate(4, 4, 13) == [8, 9]
        assert candidate(7, 10, 3) == [10, 0]
        assert candidate(2, 3, 13) == [5, 10]
        assert candidate(6, 11, 11) == [17, 0]
        assert candidate(2, 8, 6) == [8, 0]
        assert candidate(1, 9, 2) == [3, 0]
        assert candidate(7, 16, 7) == [14, 0]
        assert candidate(3, 7, 8) == [10, 1]
        assert candidate(3, 8, 6) == [9, 0]
        assert candidate(1, 6, 5) == [6, 0]
        assert candidate(4, 14, 13) == [17, 0]
        assert candidate(3, 12, 5) == [8, 0]
        assert candidate(8, 2, 12) == [10, 10]
        assert candidate(5, 5, 3) == [8, 0]
        assert candidate(5, 9, 11) == [14, 2]
        assert candidate(1, 7, 7) == [8, 0]
        assert candidate(1, 15, 8) == [9, 0]
        assert candidate(9, 8, 8) == [17, 0]
        assert candidate(8, 4, 1) == [9, 0]
        assert candidate(2, 11, 9) == [11, 0]
        assert candidate(3, 13, 4) == [7, 0]
        assert candidate(8, 1, 12) == [9, 11]
        assert candidate(5, 8, 9) == [13, 1]
        assert candidate(4, 6, 6) == [10, 0]
        assert candidate(8, 12, 13) == [20, 1]
        assert candidate(4, 8, 8) == [12, 0]
        assert candidate(10, 6, 7) == [16, 1]
        assert candidate(5, 3, 2) == [7, 0]
        assert candidate(2, 4, 6) == [6, 2]
        assert candidate(6, 9, 9) == [15, 0]
        assert candidate(4, 7, 3) == [7, 0]
        assert candidate(6, 9, 6) == [12, 0]
        assert candidate(9, 4, 10) == [13, 6]
        assert candidate(8, 9, 5) == [13, 0]
        assert candidate(4, 5, 1) == [5, 0], "Error"
        assert candidate(9, 11, 10) == [19, 0]
        assert candidate(6, 7, 15) == [13, 8]
        assert candidate(5, 7, 6) == [11, 0]
        assert candidate(1, 4, 6) == [5, 2]
        assert candidate(2, 2, 10) == [4, 8]
        assert candidate(1, 14, 1) == [2, 0]
        assert candidate(3, 11, 9) == [12, 0]
        assert candidate(2, 5, 11) == [7, 6]
        assert candidate(6, 6, 3) == [9, 0]
        assert candidate(1, 4, 2) == [3, 0]
        assert candidate(3, 6, 7) == [9, 1]
        assert candidate(3, 16, 6) == [9, 0]
        assert candidate(4, 3, 5) == [7, 2]
        assert candidate(2, 2, 2) == [4, 0]
        assert candidate(8, 3, 6) == [11, 3]
        assert candidate(4, 5, 7) == [9, 2], "Error"
        assert candidate(7, 12, 14) == [19, 2]
        assert candidate(5, 10, 8) == [13, 0]
        assert candidate(7, 10, 7) == [14, 0]
        assert candidate(3, 6, 8) == [9, 2]
        assert candidate(1, 3, 11) == [4, 8]
        assert candidate(3, 9, 2) == [5, 0]
        assert candidate(2, 8, 11) == [10, 3]
        assert candidate(7, 7, 9) == [14, 2]
        assert candidate(6, 9, 14) == [15, 5]
        assert candidate(8, 5, 7) == [13, 2]
        assert candidate(5, 3, 3) == [8, 0]
        assert candidate(2, 16, 9) == [11, 0]
        assert candidate(1, 3, 7) == [4, 4]
        assert candidate(7, 6, 14) == [13, 8]
        assert candidate(3, 3, 13) == [6, 10]
        assert candidate(4, 11, 9) == [13, 0]
        assert candidate(4, 8, 9) == [12, 1], "Error"
        assert candidate(6, 7, 5) == [11, 0]
        assert candidate(6, 12, 12) == [18, 0]
        assert candidate(4, 12, 6) == [10, 0]
        assert candidate(9, 6, 3) == [12, 0]
        assert candidate(7, 7, 12) == [14, 5]
        assert candidate(6, 7, 6) == [12, 0]
        assert candidate(3, 2, 6) == [5, 4]
        assert candidate(6, 10, 14) == [16, 4]
        assert candidate(8, 6, 13) == [14, 7]
        assert candidate(7, 3, 14) == [10, 11]
        assert candidate(2, 11, 5) == [7, 0], "Error"

    # Check some edge cases that are easy to work out by hand.
        assert candidate(2, 10, 14) == [12, 4]
        assert candidate(1, 4, 13) == [5, 9]
        assert candidate(4, 11, 14) == [15, 3]
        assert candidate(7, 6, 11) == [13, 5]
        assert candidate(5, 12, 6) == [11, 0]
        assert candidate(3, 9, 12) == [12, 3]
        assert candidate(3, 8, 14) == [11, 6]
        assert candidate(2, 13, 3) == [5, 0]
        assert candidate(6, 4, 9) == [10, 5]
        assert candidate(6, 5, 12) == [11, 7]
        assert candidate(1, 10, 10) == [11, 0], "Error"
        assert candidate(6, 6, 14) == [12, 8]
        assert candidate(5, 6, 2) == [7, 0]
        assert candidate(5, 10, 12) == [15, 2]
        assert candidate(1, 9, 12) == [10, 3]

if __name__ == '__main__':
    unittest.main()
