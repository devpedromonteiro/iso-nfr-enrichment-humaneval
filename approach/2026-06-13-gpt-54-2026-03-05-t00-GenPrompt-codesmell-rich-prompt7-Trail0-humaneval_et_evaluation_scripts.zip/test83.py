
import unittest


def _count_n_digit_numbers(n):
    """Return the total number of n-digit positive integers."""
    return 9 * (10 ** (n - 1))


def _count_n_digit_numbers_not_starting_with_one(n):
    """Return the count of n-digit positive integers whose first digit is not 1."""
    return 8 * (10 ** (n - 1))


def _count_n_digit_numbers_not_ending_with_one(n):
    """Return the count of n-digit positive integers whose last digit is not 1."""
    return 8 * (10 ** (n - 1))


def _count_n_digit_numbers_neither_starting_nor_ending_with_one(n):
    """Return the count of n-digit positive integers that neither start nor end with 1."""
    if n == 1:
        return 0
    return 8 * 9 * (10 ** (n - 2))


def starts_one_ends(n):
    """
    Given a positive integer n, return the count of the numbers of n-digit
    positive integers that start or end with 1.
    """
    if n <= 0:
        raise ValueError("n must be a positive integer")

    total = _count_n_digit_numbers(n)
    neither = _count_n_digit_numbers_neither_starting_nor_ending_with_one(n)
    return total - neither
candidate = starts_one_ends


class Test(unittest.TestCase):
    def test(self):
        assert candidate(12) == 180000000000
        assert candidate(2) == 18
        assert candidate(14) == 18000000000000
        assert candidate(3) == 180
        assert candidate(19) == 1800000000000000000
        assert candidate(1) == 1
        assert candidate(8) == 18000000
        assert candidate(13) == 1800000000000
        assert candidate(16) == 1800000000000000
        assert candidate(11) == 18000000000
        assert candidate(17) == 18000000000000000
        assert candidate(4) == 1800
        assert candidate(20) == 18000000000000000000
        assert candidate(9) == 180000000
        assert candidate(6) == 180000
        assert candidate(15) == 180000000000000
        assert candidate(5) == 18000
        assert candidate(18) == 180000000000000000
        assert candidate(5) == 18000

    # Check some edge cases that are easy to work out by hand.
        assert candidate(7) == 1800000
        assert candidate(10) == 1800000000

if __name__ == '__main__':
    unittest.main()
