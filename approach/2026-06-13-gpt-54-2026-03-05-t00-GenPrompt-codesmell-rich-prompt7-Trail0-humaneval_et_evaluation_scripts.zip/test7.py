
import unittest

from typing import List


from typing import List


def _contains_substring(value: str, substring: str) -> bool:
    """Return True when substring is present in value."""
    return substring in value


def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    """Filter strings that contain the given substring.

    >>> filter_by_substring([], 'a')
    []
    >>> filter_by_substring(['abc', 'bacd', 'cde', 'array'], 'a')
    ['abc', 'bacd', 'array']
    """
    return [value for value in strings if _contains_substring(value, substring)]
candidate = filter_by_substring


class Test(unittest.TestCase):
    def test(self):
        assert candidate(['ugk', 'lxpl', 'dofffwbjmkjs', 'dakolixjey', 'EKbFGGOve', 'jcu'], 'ak') == ['dakolixjey']
        assert candidate(['swxwhcluk', 'fhg', 'atcoek', 'umgyypaszwj'], '') == ['swxwhcluk', 'fhg', 'atcoek', 'umgyypaszwj']
        assert candidate(['enusexwhv', 'wjuj', 'itxe', 'jcahiex', 'dUOiZxVAWtGw', 'uebyej'], '') == ['enusexwhv', 'wjuj', 'itxe', 'jcahiex', 'dUOiZxVAWtGw', 'uebyej']
        assert candidate(['fgshev', 'vjs', 'viu', ' abtlp', 'oZf', 'vxyuqn'], '') == ['fgshev', 'vjs', 'viu', ' abtlp', 'oZf', 'vxyuqn']
        assert candidate(['vzjrawyh', 'bygp', 'jngw', 'fj avcms', 'qCrKdp', 'smmywcfxq'], '') == ['vzjrawyh', 'bygp', 'jngw', 'fj avcms', 'qCrKdp', 'smmywcfxq']
        assert candidate(['xpwyfshyd', 'hyfpiqgtc', 'jirhnl', ' nsh', 'QErZpVdIJ', 'tdp'], '') == ['xpwyfshyd', 'hyfpiqgtc', 'jirhnl', ' nsh', 'QErZpVdIJ', 'tdp']
        assert candidate(['vuk', 'miq', 'lpogymr', 'dwxkxx', 'zpZrzWLRQz', 'iygu'], 'yg') == ['iygu']
        assert candidate(['tnmljjqc', 'pvncnz', 'tcbsyxeh', 'cwven z op', 'IdYgwAIIu', 'enadhn'], '') == ['tnmljjqc', 'pvncnz', 'tcbsyxeh', 'cwven z op', 'IdYgwAIIu', 'enadhn']
        assert candidate(['kdtqsykk', 'bgykpzt', 'tkht', 'bgr'], 't') == ['kdtqsykk', 'bgykpzt', 'tkht']
        assert candidate(['mnndulgj', 'yapued', 'yfxknmffe', 'z kflj', 'FIBkIkjyjVq', 'gdtvwpg'], '') == ['mnndulgj', 'yapued', 'yfxknmffe', 'z kflj', 'FIBkIkjyjVq', 'gdtvwpg']
        assert candidate(['oni', 'zleaohlkif', 'grzeqgllx', 'xsavijydab'], 'sa') == ['xsavijydab']
        assert candidate(['kqox', 'knr', 'qlaaxt', 'pst', 'XduWEmb', 'egaqop'], 'ps') == ['pst']
        assert candidate(['rdce', 'pepwrjoo', 'ozdnanxsiqj', ' jclyvgb', 'sfsgenBWtFR', 'ozpzyu'], 's') == ['ozdnanxsiqj', 'sfsgenBWtFR']
        assert candidate(['fot', 'eum', 'pxgsbphx', 'gzaorjz', 'KFVOhWwpoC', 'leht'], 'le') == ['leht']
        assert candidate(['tconue', 'mlney', 'akxtnzl', 'edrad'], 'on') == ['tconue']
        assert candidate([], 'john') == []
        assert candidate(['rpaywuhf', 'ngiwurfdsfer', 'ykgawxq', 'wexngsllje'], '') == ['rpaywuhf', 'ngiwurfdsfer', 'ykgawxq', 'wexngsllje']
        assert candidate(['eilf', 'mpj', 'nhqktxlz', 'tafvngt', 'rgP', 'lqedsgz'], 'h') == ['nhqktxlz']
        assert candidate(['xxx', 'asd', 'aaaxxy', 'john doe', 'xxxAAA', 'xxx'], 'xx') == ['xxx', 'aaaxxy', 'xxxAAA', 'xxx']
        assert candidate(['exkbpmyod', 'wafdw', 'essen', 'gycuxrrp'], 'af') == ['wafdw']
        assert candidate(['sxivcdjg', 'npgx', 'inpeumlqwmth', 'fckeci', 'LsDtYSsBmG', 'qicaol'], 'c') == ['sxivcdjg', 'fckeci', 'qicaol']
        assert candidate(['wxvqpbar', 'xftqp', 'hlvnmogt', 'zgvuggyylbgw'], '') == ['wxvqpbar', 'xftqp', 'hlvnmogt', 'zgvuggyylbgw']
        assert candidate(['viwul', 'khgf', 'tbio', 'lyobs', 'jAsuPR', 'masd'], '') == ['viwul', 'khgf', 'tbio', 'lyobs', 'jAsuPR', 'masd']
        assert candidate(['rei', 'lfmvyvcl', 'uodn', 'bwbaijeudy'], 'od') == ['uodn']
        assert candidate(['paomoryvt', 'zpjnoiwnocgg', 'nngcya', 'kkftckjrgluh'], '') == ['paomoryvt', 'zpjnoiwnocgg', 'nngcya', 'kkftckjrgluh']
        assert candidate(['usqvhbm', 'igpyd', 'gszactxzm', 'vqiyslsqnfe', 'vOhpjWbUu', 'awuwl'], 'w') == ['awuwl']
        assert candidate(['jvlewbhwa', 'mmf', 'tbhpeekfak', 'ymygffilhg', 'oxQwujZ', 'tfwdzweig'], '') == ['jvlewbhwa', 'mmf', 'tbhpeekfak', 'ymygffilhg', 'oxQwujZ', 'tfwdzweig']
        assert candidate(['rzlmq', 'nypmkzsg', 'aqngjmg', 'hldubutw', 'ZoTIDt', 'fgohcqf'], 'zl') == ['rzlmq']
        assert candidate(['puma', 'ahtk', 'glkv', 'vkdc'], 'um') == ['puma']
        assert candidate(['osl', 'asvubuummn', 'sjjlousus', 'gymryaasxsb'], 's') == ['osl', 'asvubuummn', 'sjjlousus', 'gymryaasxsb']
        assert candidate(['pnu', 'olmqbfixg', 'hcgtvdu', 'aveaoupyvlm', 'PNv', 'rdzpgoaf'], '') == ['pnu', 'olmqbfixg', 'hcgtvdu', 'aveaoupyvlm', 'PNv', 'rdzpgoaf']
        assert candidate(['fekndc', 'bey', 'xhysf', 'pwobsqo l', 'OSx', 'ftpidu'], 'p') == ['pwobsqo l', 'ftpidu']
        assert candidate(['tjbhxevmk', 'lutcztrn', 'vzwocf', 'lxmhqfqzcidl'], 'zw') == ['vzwocf']
        assert candidate([], 'agw') == []
        assert candidate(['oyjdxmhhj', 'jhue', 'akpxcr', 'mol', 'wmmikhyYQDvR', 'qmctr'], '') == ['oyjdxmhhj', 'jhue', 'akpxcr', 'mol', 'wmmikhyYQDvR', 'qmctr']
        assert candidate(['jfrgxtn', 'emgcjlv', 'kzfda', 'wsgvtzsoe', 'ALCGgsNR', 'ryv'], 'e') == ['emgcjlv', 'wsgvtzsoe']
        assert candidate([], 'y') == []
        assert candidate(['btfesq', 'rkagnsvsnzrs', 'eubbokyrm', 'gaxepuosip'], 'ga') == ['gaxepuosip']
        assert candidate(['zupqmk', 'rwsqpdth', 'nlocbgvg', 'icfuzakjtknb', 'hyo', 'bqtjtn'], 'oc') == ['nlocbgvg']
        assert candidate(['shxzctwmk', 'sdwufvy', 'olicmd', ' qjur', 'zTRvOovqTV', 'ehumiisy'], 'ol') == ['olicmd']
        assert candidate(['hidrl', 'ugjomisw', 'uxexjoldi', 'zpnwvhrgldoz'], '') == ['hidrl', 'ugjomisw', 'uxexjoldi', 'zpnwvhrgldoz']
        assert candidate(['jfgi', 'exrlzppdsje', 'tdpgsobl', 'yjok'], 't') == ['tdpgsobl']
        assert candidate(['gfikjrgy', 'onqcptegu', 'eyzyby', 'wbixoc ym', 'FHqsfXhbS', 'ark'], 'yz') == ['eyzyby']
        assert candidate([], 'ii') == []
        assert candidate(['augunz', 'fsyn', 'rzbjmi', 'nesckl', 'oCjPtbazAEsA', 'eyxtyx'], 'b') == ['rzbjmi', 'oCjPtbazAEsA']
        assert candidate(['scuasnve', 'yydy', 'fbjkc', 'syqw', 'zvO', 'pdlry'], 'y') == ['yydy', 'syqw', 'pdlry']
        assert candidate(['xjp', 'mpsdixcyw', 'mfqlwxatj', 'fiorka', 'kJUIVY', 'dekjfnmm'], 'ek') == ['dekjfnmm']
        assert candidate(['znf', 'xikmjd', 'yvwxvgvm', 'gnvhrlich', 'smGBJ', 'jrtcaxfq'], '') == ['znf', 'xikmjd', 'yvwxvgvm', 'gnvhrlich', 'smGBJ', 'jrtcaxfq']
        assert candidate([], 'hm') == []
        assert candidate(['jou', 'hpvkzz', 'hop', 'fetqrbiqivq', 'Ths', 'nallwag'], '') == ['jou', 'hpvkzz', 'hop', 'fetqrbiqivq', 'Ths', 'nallwag']
        assert candidate(['onw', 'vxqogmm', 'igoksz', 'sug xjoxjadz', 'PDxYMxKzL', 'caez'], 'P') == ['PDxYMxKzL']
        assert candidate(['oxmaldkqp', 'oksz', 'mjo', 'hlyomadtjj'], 'ma') == ['oxmaldkqp', 'hlyomadtjj']
        assert candidate(['mhgaqqxzo', 'merpgcx', 'wscb', 'htz', 'yQndvelwwpj', 'kcvmtq'], '') == ['mhgaqqxzo', 'merpgcx', 'wscb', 'htz', 'yQndvelwwpj', 'kcvmtq']
        assert candidate(['avdkvxgq', 'tcln', 'vvvmj', 'hgidnvs'], 'v') == ['avdkvxgq', 'vvvmj', 'hgidnvs']
        assert candidate(['fjtbhk', 'zagej', 'ecstspbf', 'dpftwhjpsdon', 'RcVDi', 'mmrqfzoed'], 'ag') == ['zagej']
        assert candidate(['bvrnc', 'ztjbx', 'spqodlmab', 'dhcfc ', 'xyjCNubAoMtv', 'srt'], '') == ['bvrnc', 'ztjbx', 'spqodlmab', 'dhcfc ', 'xyjCNubAoMtv', 'srt']
        assert candidate([], 'u') == []
        assert candidate(['tdzdgdges', 'nzkx', 'upxr', 'sqpqvpvypjv', 'uFZZz', 'msreruyvo'], '') == ['tdzdgdges', 'nzkx', 'upxr', 'sqpqvpvypjv', 'uFZZz', 'msreruyvo']
        assert candidate(['vlzqs', 'vaa', 'jyokyuek', 'blq'], 'va') == ['vaa']
        assert candidate(['byhxj', 'ojyu', 'bue', 'ztkejbhy', 'fnp', 'tjcym'], '') == ['byhxj', 'ojyu', 'bue', 'ztkejbhy', 'fnp', 'tjcym']
        assert candidate(['yrbqlzt', 'yoljy', 'hgnst', 'egwkaepxkr', 'pHPzwAlLi', 'jnzsvjnqd'], 'j') == ['yoljy', 'jnzsvjnqd']
        assert candidate(['kufpywimp', 'oysr', 'sidolbcrux', 'zufyfpupfsv', 'uLaJw', 'dfdpf'], '') == ['kufpywimp', 'oysr', 'sidolbcrux', 'zufyfpupfsv', 'uLaJw', 'dfdpf']
        assert candidate(['eqthk', 'hnfe', 'ywjz', 'pntutudpdu', 'yJmt', 'eufmcif'], 'nf') == ['hnfe']
        assert candidate(['jwzdw', 'cft', 'tvleiwn', 'wnbp', 'yQfFUrje', 'uhg'], 'bp') == ['wnbp']
        assert candidate(['zggckveb', 'ahyihxix', 'nbjxphh', 'ofntj'], '') == ['zggckveb', 'ahyihxix', 'nbjxphh', 'ofntj']
        assert candidate(['jmftlg', 'svpf', 'ahstcm', 'ulxugoklqs'], 's') == ['svpf', 'ahstcm', 'ulxugoklqs']
        assert candidate(['wfvacvya', 'rrz', 'vgsagcsb', 'mvn', 'aDs', 'mphoywuq'], 'fv') == ['wfvacvya']
        assert candidate(['pghu', 'pmwp', 'pyjqtd', 'xdsmzdggpwqv'], '') == ['pghu', 'pmwp', 'pyjqtd', 'xdsmzdggpwqv']
        assert candidate(['grunt', 'trumpet', 'prune', 'gruesome'], 'run') == ['grunt', 'prune']
        assert candidate(['urcttvjaz', 'mjyarapkn', 'hcrrak', 'pcwcwj', 'aMWv', 'ppurg'], '') == ['urcttvjaz', 'mjyarapkn', 'hcrrak', 'pcwcwj', 'aMWv', 'ppurg']
        assert candidate(['potgjni', 'snwj', 'pzzoklax', 'wnxdznip', 'JTlXExklWu', 'wgb'], 'n') == ['potgjni', 'snwj', 'wnxdznip']
        assert candidate([], 'p') == []
        assert candidate(['xxx', 'asd', 'xxy', 'john doe', 'xxxAAA', 'xxx'], 'xxx') == ['xxx', 'xxxAAA', 'xxx']
        assert candidate(['usmxmm', 'lewsordxonk', 'ozdow', 'fgacbnf'], 'u') == ['usmxmm']
        assert candidate(['ysuub', 'ebnfgbery', 'scgbpwkjl', 'adenslpxeqwf'], 'u') == ['ysuub']
        assert candidate(['sftm', 'dioyco', 'iuuqfi', 'rbqlkpykbbzf', 'bWJjEcloelv', 'bfbjmgjql'], 'W') == ['bWJjEcloelv']
        assert candidate(['oqoinujt', 'rkikbewjm', 'zpgfpdmyn', 'dmwxjss', 'qcgDNg', 'rmpqswrd'], 'ki') == ['rkikbewjm']
        assert candidate(['gnu', 'qounpksy', 'atrzxeqfp', 'lurboel', 'RjIGVEs', 'nwiq'], 'qo') == ['qounpksy']
        assert candidate(['dkgduwon', 'gxku', 'dou', 'yuidgjkbxe'], 'id') == ['yuidgjkbxe']
        assert candidate(['jaqamxam', 'racvaeu', 'gpshdiwef', 'gmcaonpp'], 'ps') == ['gpshdiwef']
        assert candidate(['dgscqyaz', 'dykyill', 'lvher', 'ibqz', 'SmsHmLTEgw', 'keisthr'], 'e') == ['lvher', 'keisthr']
        assert candidate(['jqbhage', 'ydq', 'ddcagpb', 'edvnjuevted', 'DZcBCg', 'hyrsi'], 'q') == ['jqbhage', 'ydq']
        assert candidate(['dhpuhk', 'cmayyfjgv', 'grutd', ' tu hovh', 'QGCCvFPAXHHQ', 'mbxovs'], 'm') == ['cmayyfjgv', 'mbxovs']
        assert candidate(['kmcficwq', 'deevgeasp', 'jwfzzywsj', 'yrepttfi r', 'PFBCPQXrAEE', 'fzp'], '') == ['kmcficwq', 'deevgeasp', 'jwfzzywsj', 'yrepttfi r', 'PFBCPQXrAEE', 'fzp']
        assert candidate(['qottbmhx', 'dvrz', 'ryynfcsc', 'wyvhz'], '') == ['qottbmhx', 'dvrz', 'ryynfcsc', 'wyvhz']
        assert candidate(['ffq', 'ymkokonn', 'vtu', 'nzghjgyk'], 'm') == ['ymkokonn']
        assert candidate(['qsut', 'igzl', 'zpaen', 'yphoctvqw'], 'yp') == ['yphoctvqw']
        assert candidate(['tcnmtr', 'fzfkluce', 'dzabikh', 'hsqd'], '') == ['tcnmtr', 'fzfkluce', 'dzabikh', 'hsqd']
        assert candidate(['ntbtue', 'xfmvt', 'wtrzaz', 'wuyjr ldgwwm', 'RxIxdKCol', 'hmt'], 'xf') == ['xfmvt']
        assert candidate(['hvoihyj', 'ulmqpwdl', 'crhrgo', 'ukcsrdksd', 'jsNWfXSsxHE', 'mla'], 'a') == ['mla']
        assert candidate(['xjl', 'bsxgjx', 'zoyqaxoh', 'yliujksqoy'], '') == ['xjl', 'bsxgjx', 'zoyqaxoh', 'yliujksqoy']
        assert candidate(['fimum', 'xmnmw', 'chbdrhlkt', 'difxuhc', 'gTlhU', 'qdikcnl'], 'im') == ['fimum']
        assert candidate(['cst', 'akmh', 'lva', 'fpy fm', 'gfqijgxkhm', 'jkriy'], 'k') == ['akmh', 'gfqijgxkhm', 'jkriy']
        assert candidate(['kqji', 'sfia', 'mjna', 'x v', 'mFSHZVEmc', 'bigycesk'], '') == ['kqji', 'sfia', 'mjna', 'x v', 'mFSHZVEmc', 'bigycesk']
        assert candidate(['qaplgtthu', 'ylkvtgeipq', 'qseb', 'ghigzmkfxss'], 'qa') == ['qaplgtthu']
        assert candidate(['smcse', 'gxzwz', 'olbea', 'yukag', 'JaDjvdHbtfLM', 'kncvrbzg'], 'yu') == ['yukag']
        assert candidate(['mskf', 'qltsxwf', 'vuxg', 'jty', 'rnyqYyDjQ', 'opmcslazf'], 'pm') == ['opmcslazf']
        assert candidate(['ygndao', 'umazijg', 'ujv', 'i kyrfjq', 'nyXNlvWstDr', 'kioxvagx'], 'u') == ['umazijg', 'ujv']
        assert candidate(['dmnu', 'snp', 'khydvutwhm', 'cgv', 'LClfX', 'wihfwkg'], 'ih') == ['wihfwkg']
        assert candidate(['ncawljf', 'gnpchna', 'remvtbgc', 'zpxx', 'LJjyj', 'eiq'], '') == ['ncawljf', 'gnpchna', 'remvtbgc', 'zpxx', 'LJjyj', 'eiq']
        assert candidate(['tbbahnqmx', 'yaw', 'upedb', 'bwz', 'xptoH', 'wxhm'], 'pe') == ['upedb']
        assert candidate(['okoqz', 'mshcjbssvd', 'wrreaqu', 'fzg'], '') == ['okoqz', 'mshcjbssvd', 'wrreaqu', 'fzg']
        assert candidate(['nkvfmcpka', 'iugtl', 'tvjvei', 'vnhwdmwc i', 'ZzXH', 'bbh'], 'n') == ['nkvfmcpka', 'vnhwdmwc i']
        assert candidate(['nbuz', 'tokenv', 'dbvcfrnl', 'yorgey', 'HNIEl', 'cfkoafrjh'], '') == ['nbuz', 'tokenv', 'dbvcfrnl', 'yorgey', 'HNIEl', 'cfkoafrjh']
        assert candidate(['tcvb', 'idguap', 'ukgtnfzqj', 'vfwmburpzqgg', 'jDFfcfd', 'cfbauoso'], 'c') == ['tcvb', 'jDFfcfd', 'cfbauoso']
        assert candidate(['lxpem', 'fbvojuium', 'amfr', 'cnzbtveckbvs', 'tEYQXHDxdFv', 'arozyzx'], '') == ['lxpem', 'fbvojuium', 'amfr', 'cnzbtveckbvs', 'tEYQXHDxdFv', 'arozyzx']

if __name__ == '__main__':
    unittest.main()
