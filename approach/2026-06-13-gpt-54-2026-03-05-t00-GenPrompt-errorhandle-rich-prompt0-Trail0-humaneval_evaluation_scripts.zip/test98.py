
import unittest
import re
import sys
import math
import copy


def count_upper(s):
    """
    Given a string s, count the number of uppercase vowels in even indices.

    For example:
    count_upper('aBCdEf') returns 1
    count_upper('abcdefg') returns 0
    count_upper('dBBE') returns 0
    """
    if s is None:
        raise TypeError("s must be a string, got None")
    if not isinstance(s, str):
        raise TypeError(f"s must be a string, got {type(s).__name__}")

    uppercase_vowels = {"A", "E", "I", "O", "U"}
    count = 0

    try:
        for i in range(0, len(s), 2):
            if s[i] in uppercase_vowels:
                count += 1
    except IndexError as exc:
        # Defensive handling: should not occur with the loop bounds above,
        # but if string access fails unexpectedly, raise a specific error.
        raise RuntimeError("Unexpected indexing error while counting uppercase vowels") from exc

    return count
candidate = count_upper


def check(candidate):

    # Check some simple cases
    assert candidate('aBCdEf')  == 1
    assert candidate('abcdefg') == 0
    assert candidate('dBBE') == 0
    assert candidate('B')  == 0
    assert candidate('U')  == 1
    assert candidate('') == 0
    assert candidate('EEEE') == 2

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
