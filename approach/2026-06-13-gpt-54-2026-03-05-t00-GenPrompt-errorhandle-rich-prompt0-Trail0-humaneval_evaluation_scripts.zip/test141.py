
import unittest
import re
import sys
import math
import copy


def file_name_check(file_name):
    """Return 'Yes' if file_name is valid, otherwise 'No'.

    Validation rules:
    - file_name must be a string
    - no more than three digits in the full file name
    - contains exactly one dot '.'
    - name before the dot is non-empty and starts with a Latin letter
    - extension after the dot is one of: txt, exe, dll

    Raises:
        TypeError: if file_name is not a string
        ValueError: if file_name is an empty string
    """
    if not isinstance(file_name, str):
        raise TypeError("file_name must be a string")

    if file_name == "":
        raise ValueError("file_name must not be empty")

    try:
        if sum(ch.isdigit() for ch in file_name) > 3:
            return "No"

        if file_name.count(".") != 1:
            return "No"

        name, extension = file_name.split(".")

        if not name:
            return "No"

        if not name[0].isalpha() or not name[0].isascii():
            return "No"

        if extension not in {"txt", "exe", "dll"}:
            return "No"

        return "Yes"

    except ValueError:
        # Defensive handling for unexpected split/unpack issues.
        return "No"
candidate = file_name_check


def check(candidate):

    # Check some simple cases
    assert candidate("example.txt") == 'Yes'
    assert candidate("1example.dll") == 'No'
    assert candidate('s1sdf3.asd') == 'No'
    assert candidate('K.dll') == 'Yes'
    assert candidate('MY16FILE3.exe') == 'Yes'
    assert candidate('His12FILE94.exe') == 'No'
    assert candidate('_Y.txt') == 'No'
    assert candidate('?aREYA.exe') == 'No'
    assert candidate('/this_is_valid.dll') == 'No'
    assert candidate('this_is_valid.wow') == 'No'
    assert candidate('this_is_valid.txt') == 'Yes'
    assert candidate('this_is_valid.txtexe') == 'No'
    assert candidate('#this2_i4s_5valid.ten') == 'No'
    assert candidate('@this1_is6_valid.exe') == 'No'
    assert candidate('this_is_12valid.6exe4.txt') == 'No'
    assert candidate('all.exe.txt') == 'No'
    assert candidate('I563_No.exe') == 'Yes'
    assert candidate('Is3youfault.txt') == 'Yes'
    assert candidate('no_one#knows.dll') == 'Yes'
    assert candidate('1I563_Yes3.exe') == 'No'
    assert candidate('I563_Yes3.txtt') == 'No'
    assert candidate('final..txt') == 'No'
    assert candidate('final132') == 'No'
    assert candidate('_f4indsartal132.') == 'No'
    
        

    # Check some edge cases that are easy to work out by hand.
    assert candidate('.txt') == 'No'
    assert candidate('s.') == 'No'



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
