
import unittest
import re
import sys
import math
import copy


def move_one_ball(arr):
    """Determine whether a list can become non-decreasing by right rotations.

    A right shift moves the last element to the front. This function returns
    True if some number of right shifts can transform `arr` into a sorted
    non-decreasing list, otherwise False.

    Rules:
    - Empty list returns True.
    - Input must be a list or tuple of integers.
    - Invalid inputs raise specific exceptions.

    Examples:
        move_one_ball([3, 4, 5, 1, 2]) -> True
        move_one_ball([3, 5, 4, 1, 2]) -> False
    """
    if arr is None:
        raise TypeError("arr must not be None")

    if not isinstance(arr, (list, tuple)):
        raise TypeError("arr must be a list or tuple of integers")

    if any(not isinstance(x, int) for x in arr):
        raise TypeError("all elements in arr must be integers")

    if len(arr) == 0:
        return True

    # Count positions where order decreases.
    # A sortable-by-rotation array can have at most one such drop.
    drops = 0
    for i in range(len(arr) - 1):
        if arr[i] > arr[i + 1]:
            drops += 1
            if drops > 1:
                return False

    # If there is one drop, the last element must be <= first element
    # for the array to be a rotation of a non-decreasing array.
    if drops == 1 and arr[-1] > arr[0]:
        return False

    return True
candidate = move_one_ball


def check(candidate):

    # Check some simple cases
    assert candidate([3, 4, 5, 1, 2])==True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([3, 5, 10, 1, 2])==True
    assert candidate([4, 3, 1, 2])==False
    # Check some edge cases that are easy to work out by hand.
    assert candidate([3, 5, 4, 1, 2])==False, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([])==True


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
