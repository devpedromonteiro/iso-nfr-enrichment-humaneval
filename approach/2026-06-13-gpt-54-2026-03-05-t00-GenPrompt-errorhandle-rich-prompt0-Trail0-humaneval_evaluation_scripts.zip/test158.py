
import unittest
import re
import sys
import math
import copy


def find_max(words):
    """Return the word with the highest count of unique characters.

    If multiple words have the same maximum count of unique characters,
    return the lexicographically smallest one.

    Args:
        words: A list of strings.

    Returns:
        The selected string.

    Raises:
        TypeError: If `words` is not a list or any element is not a string.
        ValueError: If `words` is empty.
    """
    if not isinstance(words, list):
        raise TypeError("words must be a list of strings")

    if not words:
        raise ValueError("words must not be empty")

    max_unique_count = -1
    best_word = None

    for index, word in enumerate(words):
        if not isinstance(word, str):
            raise TypeError(f"all elements must be strings; invalid element at index {index}")

        unique_count = len(set(word))

        if (
            unique_count > max_unique_count
            or (unique_count == max_unique_count and (best_word is None or word < best_word))
        ):
            max_unique_count = unique_count
            best_word = word

    return best_word
candidate = find_max


def check(candidate):

    # Check some simple cases
    assert (candidate(["name", "of", "string"]) == "string"), "t1"
    assert (candidate(["name", "enam", "game"]) == "enam"), 't2'
    assert (candidate(["aaaaaaa", "bb", "cc"]) == "aaaaaaa"), 't3'
    assert (candidate(["abc", "cba"]) == "abc"), 't4'
    assert (candidate(["play", "this", "game", "of","footbott"]) == "footbott"), 't5'
    assert (candidate(["we", "are", "gonna", "rock"]) == "gonna"), 't6'
    assert (candidate(["we", "are", "a", "mad", "nation"]) == "nation"), 't7'
    assert (candidate(["this", "is", "a", "prrk"]) == "this"), 't8'

    # Check some edge cases that are easy to work out by hand.
    assert (candidate(["b"]) == "b"), 't9'
    assert (candidate(["play", "play", "play"]) == "play"), 't10'



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
