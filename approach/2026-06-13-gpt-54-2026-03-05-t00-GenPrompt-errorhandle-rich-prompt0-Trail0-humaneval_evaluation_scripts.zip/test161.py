
import unittest
import re
import sys
import math
import copy


def solve(s):
    """Return a transformed version of string ``s``.

    Rules:
    - If ``s[i]`` is a letter, reverse its case.
    - Otherwise, keep it unchanged.
    - If the string contains no letters at all, reverse the entire string.

    Examples:
        solve("1234") -> "4321"
        solve("ab") -> "AB"
        solve("#a@C") -> "#A@c"

    Raises:
        TypeError: If ``s`` is not a string.
        ValueError: If ``s`` is None.
    """
    if s is None:
        raise ValueError("Input cannot be None.")
    if not isinstance(s, str):
        raise TypeError(f"Input must be of type str, got {type(s).__name__}.")

    has_letter = any(ch.isalpha() for ch in s)

    if not has_letter:
        return s[::-1]

    try:
        return "".join(ch.swapcase() if ch.isalpha() else ch for ch in s)
    except Exception as exc:
        raise RuntimeError("Failed to transform the input string.") from exc
candidate = solve


def check(candidate):

    # Check some simple cases
    assert candidate("AsDf") == "aSdF"
    assert candidate("1234") == "4321"
    assert candidate("ab") == "AB"
    assert candidate("#a@C") == "#A@c"
    assert candidate("#AsdfW^45") == "#aSDFw^45"
    assert candidate("#6@2") == "2@6#"

    # Check some edge cases that are easy to work out by hand.
    assert candidate("#$a^D") == "#$A^d"
    assert candidate("#ccc") == "#CCC"

    # Don't remove this line:


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
