
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Given a grid with N rows and N columns (N >= 2) and a positive integer k,
    each cell of the grid contains a value. Every integer in the range [1, N * N]
    inclusive appears exactly once on the cells of the grid.

    Return the lexicographically minimum path of length k.

    Error handling requirements implemented:
    - validates inputs explicitly
    - raises specific exception types for invalid arguments
    - does not silently swallow errors
    """

    # Validate grid container
    if not isinstance(grid, list):
        raise TypeError("grid must be a list of lists")

    if len(grid) < 2:
        raise ValueError("grid must have at least 2 rows")

    n = len(grid)

    # Validate rows and square shape
    for i, row in enumerate(grid):
        if not isinstance(row, list):
            raise TypeError(f"grid row at index {i} must be a list")
        if len(row) != n:
            raise ValueError("grid must be square (N x N)")

    # Validate k
    if not isinstance(k, int):
        raise TypeError("k must be an integer")
    if k <= 0:
        raise ValueError("k must be a positive integer")

    # Validate grid values
    values = []
    for i, row in enumerate(grid):
        for j, val in enumerate(row):
            if not isinstance(val, int):
                raise TypeError(f"grid[{i}][{j}] must be an integer")
            values.append(val)

    expected = set(range(1, n * n + 1))
    actual = set(values)

    if len(values) != len(actual):
        raise ValueError("grid values must be unique")
    if actual != expected:
        raise ValueError(f"grid must contain every integer from 1 to {n * n} exactly once")

    # Build value -> position map
    pos = {}
    for i in range(n):
        for j in range(n):
            pos[grid[i][j]] = (i, j)

    # Find the smallest starting value that can produce a path of length k.
    # Since values are unique and lexicographic order dominates from left to right,
    # greedily choosing the smallest possible next neighbor at each step is optimal.
    try:
        start_val = 1
        x, y = pos[start_val]
    except KeyError as exc:
        # Defensive: should not happen after validation, but keeps failure explicit.
        raise ValueError("grid is missing required value 1") from exc

    path = [start_val]

    for _ in range(k - 1):
        neighbors = []

        if x > 0:
            neighbors.append((grid[x - 1][y], x - 1, y))
        if x < n - 1:
            neighbors.append((grid[x + 1][y], x + 1, y))
        if y > 0:
            neighbors.append((grid[x][y - 1], x, y - 1))
        if y < n - 1:
            neighbors.append((grid[x][y + 1], x, y + 1))

        if not neighbors:
            raise RuntimeError("no valid moves available; grid state is inconsistent")

        next_val, x, y = min(neighbors, key=lambda t: t[0])
        path.append(next_val)

    return path
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
