
import unittest
import re
import sys
import math
import copy

from typing import List, Optional


from typing import List, Optional


def longest(strings: List[str]) -> Optional[str]:
    """Out of list of strings, return the longest one.

    Return the first one in case of multiple strings of the same length.
    Return None in case the input list is empty.

    >>> longest([])

    >>> longest(['a', 'b', 'c'])
    'a'
    >>> longest(['a', 'bb', 'ccc'])
    'ccc'
    """
    if strings is None:
        raise TypeError("strings must be a list of str, got None")

    if not isinstance(strings, list):
        raise TypeError(f"strings must be a list of str, got {type(strings).__name__}")

    if not strings:
        return None

    for i, value in enumerate(strings):
        if not isinstance(value, str):
            raise TypeError(
                f"all items in strings must be str; item at index {i} is {type(value).__name__}"
            )

    longest_string = strings[0]
    for value in strings[1:]:
        if len(value) > len(longest_string):
            longest_string = value

    return longest_string
candidate = longest




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == None
    assert candidate(['x', 'y', 'z']) == 'x'
    assert candidate(['x', 'yyy', 'zzzz', 'www', 'kkkk', 'abc']) == 'zzzz'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
