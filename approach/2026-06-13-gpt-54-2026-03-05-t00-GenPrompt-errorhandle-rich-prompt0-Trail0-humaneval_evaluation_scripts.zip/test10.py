
import unittest
import re
import sys
import math
import copy



def is_palindrome(string: str) -> bool:
    """ Test if given string is a palindrome """
    return string == string[::-1]


def is_palindrome(string: str) -> bool:
    """Test if given string is a palindrome.

    Raises:
        TypeError: If string is not a str.
    """
    if not isinstance(string, str):
        raise TypeError(
            f"is_palindrome expected 'string' to be of type str, got {type(string).__name__}"
        )
    return string == string[::-1]


def make_palindrome(string: str) -> str:
    """Find the shortest palindrome that begins with a supplied string.

    Algorithm idea is simple:
    - Find the longest postfix of supplied string that is a palindrome.
    - Append to the end of the string reverse of a string prefix that comes
      before the palindromic suffix.

    >>> make_palindrome('')
    ''
    >>> make_palindrome('cat')
    'catac'
    >>> make_palindrome('cata')
    'catac'

    Raises:
        TypeError: If string is not a str.
        ValueError: If string is None.
        RuntimeError: If palindrome construction fails unexpectedly.
    """
    if string is None:
        raise ValueError("make_palindrome does not accept None")
    if not isinstance(string, str):
        raise TypeError(
            f"make_palindrome expected 'string' to be of type str, got {type(string).__name__}"
        )

    try:
        for i in range(len(string) + 1):
            suffix = string[i:]
            if is_palindrome(suffix):
                prefix = string[:i]
                result = string + prefix[::-1]

                # Defensive consistency check to avoid returning invalid state.
                if not is_palindrome(result):
                    raise RuntimeError(
                        "Constructed result is not a palindrome; internal consistency error"
                    )
                return result

        # This path should be unreachable because at minimum the last character
        # (or empty string) is always a palindrome suffix.
        raise RuntimeError("Failed to construct palindrome from valid input")

    except (TypeError, ValueError, RuntimeError):
        # Re-raise specific exceptions explicitly; do not swallow errors.
        raise
candidate = make_palindrome




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == ''
    assert candidate('x') == 'x'
    assert candidate('xyz') == 'xyzyx'
    assert candidate('xyx') == 'xyx'
    assert candidate('jerry') == 'jerryrrej'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
