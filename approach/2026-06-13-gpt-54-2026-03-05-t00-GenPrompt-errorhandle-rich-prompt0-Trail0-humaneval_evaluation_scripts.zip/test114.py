
import unittest
import re
import sys
import math
import copy


def minSubArraySum(nums):
    """
    Given an array of integers nums, find the minimum sum of any non-empty sub-array
    of nums.

    Example:
        minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
        minSubArraySum([-1, -2, -3]) == -6

    Raises:
        TypeError: If nums is not a list or tuple, or contains non-integer elements.
        ValueError: If nums is empty.
    """
    if nums is None:
        raise TypeError("nums must not be None")

    if not isinstance(nums, (list, tuple)):
        raise TypeError("nums must be a list or tuple of integers")

    if len(nums) == 0:
        raise ValueError("nums must be a non-empty list or tuple")

    for i, value in enumerate(nums):
        if not isinstance(value, int):
            raise TypeError(f"nums[{i}] must be an integer, got {type(value).__name__}")

    min_ending_here = nums[0]
    min_so_far = nums[0]

    for num in nums[1:]:
        min_ending_here = min(num, min_ending_here + num)
        min_so_far = min(min_so_far, min_ending_here)

    return min_so_far
candidate = minSubArraySum


def check(candidate):

    # Check some simple cases
    assert candidate([2, 3, 4, 1, 2, 4]) == 1, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([-1, -2, -3]) == -6
    assert candidate([-1, -2, -3, 2, -10]) == -14
    assert candidate([-9999999999999999]) == -9999999999999999
    assert candidate([0, 10, 20, 1000000]) == 0
    assert candidate([-1, -2, -3, 10, -5]) == -6
    assert candidate([100, -1, -2, -3, 10, -5]) == -6
    assert candidate([10, 11, 13, 8, 3, 4]) == 3
    assert candidate([100, -33, 32, -1, 0, -2]) == -33

    # Check some edge cases that are easy to work out by hand.
    assert candidate([-10]) == -10, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([7]) == 7
    assert candidate([1, -1]) == -1


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
