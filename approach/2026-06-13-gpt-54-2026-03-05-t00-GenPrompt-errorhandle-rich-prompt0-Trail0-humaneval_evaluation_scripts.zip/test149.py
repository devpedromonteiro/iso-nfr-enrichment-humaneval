
import unittest
import re
import sys
import math
import copy


def sorted_list_sum(lst):
    """Return a sorted list containing only the even-length strings from lst.

    Rules:
    - Remove strings with odd lengths.
    - Sort ascending by string length.
    - If lengths are equal, sort alphabetically.

    Error handling:
    - Raises TypeError if lst is not a list.
    - Raises TypeError if any element of lst is not a string.
    """
    if not isinstance(lst, list):
        raise TypeError("lst must be a list of strings")

    for i, item in enumerate(lst):
        if not isinstance(item, str):
            raise TypeError(f"lst[{i}] must be a string, got {type(item).__name__}")

    try:
        filtered = [s for s in lst if len(s) % 2 == 0]
        return sorted(filtered, key=lambda s: (len(s), s))
    except Exception as e:
        raise RuntimeError("failed to filter and sort the list") from e
candidate = sorted_list_sum


def check(candidate):

    # Check some simple cases
    assert candidate(["aa", "a", "aaa"]) == ["aa"]
    assert candidate(["school", "AI", "asdf", "b"]) == ["AI", "asdf", "school"]
    assert candidate(["d", "b", "c", "a"]) == []
    assert candidate(["d", "dcba", "abcd", "a"]) == ["abcd", "dcba"]

    # Check some edge cases that are easy to work out by hand.
    assert candidate(["AI", "ai", "au"]) == ["AI", "ai", "au"]
    assert candidate(["a", "b", "b", "c", "c", "a"]) == []
    assert candidate(['aaaa', 'bbbb', 'dd', 'cc']) == ["cc", "dd", "aaaa", "bbbb"]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
