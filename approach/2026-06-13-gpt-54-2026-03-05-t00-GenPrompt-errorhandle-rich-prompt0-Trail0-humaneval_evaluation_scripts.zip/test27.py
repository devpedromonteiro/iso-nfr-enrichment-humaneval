
import unittest
import re
import sys
import math
import copy



def flip_case(string: str) -> str:
    """For a given string, flip lowercase characters to uppercase and uppercase to lowercase.

    >>> flip_case('Hello')
    'hELLO'
    """
    if not isinstance(string, str):
        raise TypeError(
            f"flip_case expected argument of type 'str', got '{type(string).__name__}'"
        )

    try:
        return string.swapcase()
    except AttributeError as exc:
        # Defensive handling in case the object is not a valid string-like value
        raise TypeError("Invalid input: unable to flip case for the provided value") from exc
candidate = flip_case




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == ''
    assert candidate('Hello!') == 'hELLO!'
    assert candidate('These violent delights have violent ends') == 'tHESE VIOLENT DELIGHTS HAVE VIOLENT ENDS'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
