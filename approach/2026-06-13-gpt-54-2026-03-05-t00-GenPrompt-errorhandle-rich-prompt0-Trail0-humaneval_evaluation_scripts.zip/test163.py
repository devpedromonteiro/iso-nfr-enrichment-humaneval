
import unittest
import re
import sys
import math
import copy


def generate_integers(a, b):
    """
    Given two positive integers a and b, return the even digits between a
    and b, in ascending order.

    For example:
    generate_integers(2, 8) => [2, 4, 6, 8]
    generate_integers(8, 2) => [2, 4, 6, 8]
    generate_integers(10, 14) => []

    Raises:
        TypeError: If a or b is not an integer.
        ValueError: If a or b is not a positive integer.
    """
    if not isinstance(a, int) or isinstance(a, bool):
        raise TypeError(f"a must be an integer, got {type(a).__name__}")
    if not isinstance(b, int) or isinstance(b, bool):
        raise TypeError(f"b must be an integer, got {type(b).__name__}")

    if a <= 0:
        raise ValueError(f"a must be a positive integer, got {a}")
    if b <= 0:
        raise ValueError(f"b must be a positive integer, got {b}")

    start, end = sorted((a, b))

    try:
        return [n for n in range(start, end + 1) if n in {2, 4, 6, 8}]
    except Exception as exc:
        raise RuntimeError("Failed to generate even digits between the given bounds") from exc
candidate = generate_integers


def check(candidate):

    # Check some simple cases
    assert candidate(2, 10) == [2, 4, 6, 8], "Test 1"
    assert candidate(10, 2) == [2, 4, 6, 8], "Test 2"
    assert candidate(132, 2) == [2, 4, 6, 8], "Test 3"
    assert candidate(17,89) == [], "Test 4"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
