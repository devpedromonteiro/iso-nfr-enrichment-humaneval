
import unittest
import re
import sys
import math
import copy


def by_length(arr):
    """
    Given an array of integers, return the valid digits (1..9) sorted ascending,
    then reversed, and mapped to their English names.

    Examples:
        [2, 1, 1, 4, 5, 8, 2, 3] -> ["Eight", "Five", "Four", "Three", "Two", "Two", "One", "One"]
        [] -> []
        [1, -1, 55] -> ["One"]

    Error handling:
        - Raises TypeError if arr is not a list or tuple.
        - Raises TypeError if any element is not an integer.
    """
    if arr is None:
        raise TypeError("arr must be a list or tuple of integers, got None")

    if not isinstance(arr, (list, tuple)):
        raise TypeError(f"arr must be a list or tuple of integers, got {type(arr).__name__}")

    digit_names = {
        1: "One",
        2: "Two",
        3: "Three",
        4: "Four",
        5: "Five",
        6: "Six",
        7: "Seven",
        8: "Eight",
        9: "Nine",
    }

    valid_digits = []

    for index, value in enumerate(arr):
        if not isinstance(value, int):
            raise TypeError(
                f"all elements must be integers; found {type(value).__name__} at index {index}"
            )
        if 1 <= value <= 9:
            valid_digits.append(value)

    valid_digits.sort()
    valid_digits.reverse()

    return [digit_names[digit] for digit in valid_digits]
candidate = by_length


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([2, 1, 1, 4, 5, 8, 2, 3]) == ["Eight", "Five", "Four", "Three", "Two", "Two", "One", "One"], "Error"
    assert candidate([]) == [], "Error"
    assert candidate([1, -1 , 55]) == ['One'], "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([1, -1, 3, 2]) == ["Three", "Two", "One"]
    assert candidate([9, 4, 8]) == ["Nine", "Eight", "Four"]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
