
import unittest
import re
import sys
import math
import copy


def compare_one(a, b):
    """
    Create a function that takes integers, floats, or strings representing
    real numbers, and returns the larger variable in its given variable type.
    Return None if the values are equal.

    Rules:
    - Accepted input types: int, float, str
    - Strings must represent valid real numbers, using either '.' or ',' as decimal separator
    - Returns the original argument (preserving its type/form) for the larger value
    - Returns None if numerically equal

    Raises:
        TypeError: if an argument is not int, float, or str
        ValueError: if a string does not represent a valid real number
    """

    def to_number(value):
        if isinstance(value, bool):
            raise TypeError("Boolean values are not valid inputs.")
        if isinstance(value, (int, float)):
            return float(value)
        if isinstance(value, str):
            normalized = value.strip().replace(",", ".")
            if not normalized:
                raise ValueError("Empty string is not a valid real number.")
            try:
                return float(normalized)
            except ValueError as exc:
                raise ValueError(f"Invalid numeric string: {value!r}") from exc
        raise TypeError(
            f"Unsupported type: {type(value).__name__}. Expected int, float, or str."
        )

    num_a = to_number(a)
    num_b = to_number(b)

    if num_a > num_b:
        return a
    if num_b > num_a:
        return b
    return None
candidate = compare_one


def check(candidate):

    # Check some simple cases
    assert candidate(1, 2) == 2
    assert candidate(1, 2.5) == 2.5
    assert candidate(2, 3) == 3
    assert candidate(5, 6) == 6
    assert candidate(1, "2,3") == "2,3"
    assert candidate("5,1", "6") == "6"
    assert candidate("1", "2") == "2"
    assert candidate("1", 1) == None

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
