
import unittest
import re
import sys
import math
import copy


import math

def max_fill(grid, capacity):
    """
    You are given a rectangular grid of wells. Each row represents a single well,
    and each 1 in a row represents a single unit of water.
    Each well has a corresponding bucket that can be used to extract water from it, 
    and all buckets have the same capacity.
    Your task is to use the buckets to empty the wells.
    Output the number of times you need to lower the buckets.

    Example 1:
        Input: 
            grid : [[0,0,1,0], [0,1,0,0], [1,1,1,1]]
            bucket_capacity : 1
        Output: 6

    Example 2:
        Input: 
            grid : [[0,0,1,1], [0,0,0,0], [1,1,1,1], [0,1,1,1]]
            bucket_capacity : 2
        Output: 5
    
    Example 3:
        Input: 
            grid : [[0,0,0], [0,0,0]]
            bucket_capacity : 5
        Output: 0

    Constraints:
        * all wells have the same length
        * 1 <= grid.length <= 10^2
        * 1 <= grid[:,1].length <= 10^2
        * grid[i][j] -> 0 | 1
        * 1 <= capacity <= 10
    """
    if not isinstance(grid, list):
        raise TypeError("grid must be a list of lists")

    if not isinstance(capacity, int):
        raise TypeError("capacity must be an integer")

    if capacity < 1 or capacity > 10:
        raise ValueError("capacity must be between 1 and 10 inclusive")

    if len(grid) == 0:
        raise ValueError("grid must contain at least one row")

    if len(grid) > 10**2:
        raise ValueError("grid must not contain more than 100 rows")

    if not all(isinstance(row, list) for row in grid):
        raise TypeError("each row in grid must be a list")

    row_length = len(grid[0])
    if row_length == 0:
        raise ValueError("grid rows must contain at least one column")

    if row_length > 10**2:
        raise ValueError("grid rows must not contain more than 100 columns")

    total_lowerings = 0

    for i, row in enumerate(grid):
        if len(row) != row_length:
            raise ValueError("all rows in grid must have the same length")

        for j, cell in enumerate(row):
            if not isinstance(cell, int):
                raise TypeError(f"grid[{i}][{j}] must be an integer")
            if cell not in (0, 1):
                raise ValueError(f"grid[{i}][{j}] must be either 0 or 1")

        water_units = sum(row)
        total_lowerings += math.ceil(water_units / capacity)

    return total_lowerings
candidate = max_fill


def check(candidate):


    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([[0,0,1,0], [0,1,0,0], [1,1,1,1]], 1) == 6, "Error"
    assert candidate([[0,0,1,1], [0,0,0,0], [1,1,1,1], [0,1,1,1]], 2) == 5, "Error"
    assert candidate([[0,0,0], [0,0,0]], 5) == 0, "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([[1,1,1,1], [1,1,1,1]], 2) == 4, "Error"
    assert candidate([[1,1,1,1], [1,1,1,1]], 9) == 2, "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
