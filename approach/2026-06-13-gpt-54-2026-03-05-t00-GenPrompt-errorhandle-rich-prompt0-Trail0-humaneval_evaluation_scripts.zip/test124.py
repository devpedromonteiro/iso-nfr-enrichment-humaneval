
import unittest
import re
import sys
import math
import copy


def valid_date(date):
    """Validate a date string in mm-dd-yyyy format.

    Returns:
        bool: True if the date is valid, otherwise False.

    Raises:
        TypeError: If date is not a string.
    """
    if date is None:
        raise TypeError("date must be a string, got None")

    if not isinstance(date, str):
        raise TypeError(f"date must be a string, got {type(date).__name__}")

    if date == "":
        return False

    parts = date.split("-")
    if len(parts) != 3:
        return False

    month_str, day_str, year_str = parts

    # Enforce exact mm-dd-yyyy structure
    if len(month_str) != 2 or len(day_str) != 2 or len(year_str) != 4:
        return False

    if not (month_str.isdigit() and day_str.isdigit() and year_str.isdigit()):
        return False

    try:
        month = int(month_str)
        day = int(day_str)
        year = int(year_str)
    except ValueError as exc:
        raise ValueError("date contains non-numeric components") from exc

    if year < 0:
        return False

    if month < 1 or month > 12:
        return False

    if month in (1, 3, 5, 7, 8, 10, 12):
        max_day = 31
    elif month in (4, 6, 9, 11):
        max_day = 30
    else:  # February
        max_day = 29

    if day < 1 or day > max_day:
        return False

    return True
candidate = valid_date


def check(candidate):

    # Check some simple cases
    assert candidate('03-11-2000') == True

    assert candidate('15-01-2012') == False

    assert candidate('04-0-2040') == False

    assert candidate('06-04-2020') == True

    assert candidate('01-01-2007') == True

    assert candidate('03-32-2011') == False

    assert candidate('') == False

    assert candidate('04-31-3000') == False

    assert candidate('06-06-2005') == True

    assert candidate('21-31-2000') == False

    assert candidate('04-12-2003') == True

    assert candidate('04122003') == False

    assert candidate('20030412') == False

    assert candidate('2003-04') == False

    assert candidate('2003-04-12') == False

    assert candidate('04-2003') == False


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
