
import unittest
import re
import sys
import math
import copy


def is_equal_to_sum_even(n):
    """Evaluate whether the given number n can be written as the sum of exactly 4 positive even numbers.

    A positive even number is one of: 2, 4, 6, ...
    The smallest possible sum of 4 positive even numbers is 2 + 2 + 2 + 2 = 8.

    Examples:
        is_equal_to_sum_even(4) == False
        is_equal_to_sum_even(6) == False
        is_equal_to_sum_even(8) == True

    Args:
        n: Integer value to evaluate.

    Returns:
        bool: True if n can be expressed as the sum of exactly 4 positive even numbers,
        otherwise False.

    Raises:
        TypeError: If n is not an integer.
        ValueError: If n is negative.
    """
    if isinstance(n, bool) or not isinstance(n, int):
        raise TypeError("n must be an integer")
    if n < 0:
        raise ValueError("n must be non-negative")

    return n >= 8 and n % 2 == 0
candidate = is_equal_to_sum_even


def check(candidate):
    assert candidate(4) == False
    assert candidate(6) == False
    assert candidate(8) == True
    assert candidate(10) == True
    assert candidate(11) == False
    assert candidate(12) == True
    assert candidate(13) == False
    assert candidate(16) == True


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
