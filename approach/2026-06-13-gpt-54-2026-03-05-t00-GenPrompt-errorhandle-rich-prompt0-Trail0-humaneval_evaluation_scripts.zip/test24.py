
import unittest
import re
import sys
import math
import copy



def largest_divisor(n: int) -> int:
    """For a given positive integer n, find the largest number that divides n evenly, smaller than n.

    >>> largest_divisor(15)
    5
    >>> largest_divisor(13)
    1
    """
    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if isinstance(n, bool):
        raise TypeError("n must be an integer, not bool")
    if n <= 1:
        raise ValueError("n must be greater than 1")

    for divisor in range(n // 2, 0, -1):
        if n % divisor == 0:
            return divisor

    raise RuntimeError("unexpected error: no divisor found")
candidate = largest_divisor




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(3) == 1
    assert candidate(7) == 1
    assert candidate(10) == 5
    assert candidate(100) == 50
    assert candidate(49) == 7


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
