
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math


def poly(coefficients: list[float], x: float) -> float:
    """
    Evaluate a polynomial with given coefficients at point x.

    The polynomial is:
        coefficients[0]
        + coefficients[1] * x
        + coefficients[2] * x^2
        + ...
        + coefficients[n] * x^n
    """
    return sum(coefficient * math.pow(x, power) for power, coefficient in enumerate(coefficients))


def find_zero(coefficients: list[float]) -> float:
    """
    Find one real zero of a polynomial.

    The input must satisfy:
    - the number of coefficients is even
    - the highest non-zero coefficient is positive

    Under these assumptions, the polynomial has odd degree with positive leading
    coefficient, so it is guaranteed to have at least one real root.

    Returns one real value x such that poly(coefficients, x) == 0 approximately.

    >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2)  # (x - 1)(x - 2)(x - 3)
    1.0
    """
    if not coefficients:
        raise ValueError("coefficients must not be empty")

    if len(coefficients) % 2 != 0:
        raise ValueError("coefficients must contain an even number of elements")

    highest_non_zero_index = None
    for index in range(len(coefficients) - 1, -1, -1):
        if coefficients[index] != 0:
            highest_non_zero_index = index
            break

    if highest_non_zero_index is None:
        raise ValueError("polynomial must not be the zero polynomial")

    if coefficients[highest_non_zero_index] <= 0:
        raise ValueError("highest non-zero coefficient must be positive")

    def f(x: float) -> float:
        return poly(coefficients, x)

    left = -1.0
    right = 1.0

    while f(left) > 0:
        left *= 2

    while f(right) < 0:
        right *= 2

    tolerance = 1e-12

    while right - left > tolerance:
        middle = (left + right) / 2
        value = f(middle)

        if value == 0:
            return middle

        if value < 0:
            left = middle
        else:
            right = middle

    return (left + right) / 2
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
