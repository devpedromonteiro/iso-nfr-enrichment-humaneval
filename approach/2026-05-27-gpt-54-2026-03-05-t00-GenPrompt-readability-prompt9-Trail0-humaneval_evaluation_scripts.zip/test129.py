
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Given an N x N grid containing each integer from 1 to N*N exactly once,
    return the lexicographically smallest path of length k, where each move
    goes to a 4-directionally adjacent cell.

    A path of length k visits exactly k cells, and cells may be revisited.
    """

    n = len(grid)

    # Map each value to its position for O(1) lookup.
    value_to_pos = {}
    for row in range(n):
        for col in range(n):
            value_to_pos[grid[row][col]] = (row, col)

    def neighbors(row, col):
        """Yield valid 4-directional neighbors of (row, col)."""
        directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]

        for dr, dc in directions:
            nr, nc = row + dr, col + dc
            if 0 <= nr < n and 0 <= nc < n:
                yield nr, nc

    # The lexicographically smallest path must start at value 1,
    # since all values are unique and we may start anywhere.
    current_value = 1
    row, col = value_to_pos[current_value]
    path = [current_value]

    # Build the remaining k - 1 values greedily:
    # at each step, choose the smallest-valued neighboring cell.
    for _ in range(k - 1):
        best_next_value = None
        best_next_pos = None

        for nr, nc in neighbors(row, col):
            neighbor_value = grid[nr][nc]
            if best_next_value is None or neighbor_value < best_next_value:
                best_next_value = neighbor_value
                best_next_pos = (nr, nc)

        path.append(best_next_value)
        row, col = best_next_pos

    return path
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
