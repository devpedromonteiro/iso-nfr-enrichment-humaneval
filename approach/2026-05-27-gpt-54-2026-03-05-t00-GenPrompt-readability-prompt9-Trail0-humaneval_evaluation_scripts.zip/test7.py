
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    """Filter strings that contain the given substring.

    >>> filter_by_substring([], "a")
    []
    >>> filter_by_substring(["abc", "bacd", "cde", "array"], "a")
    ['abc', 'bacd', 'array']
    """
    matching_strings: List[str] = []

    for text in strings:
        if substring in text:
            matching_strings.append(text)

    return matching_strings
candidate = filter_by_substring




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([], 'john') == []
    assert candidate(['xxx', 'asd', 'xxy', 'john doe', 'xxxAAA', 'xxx'], 'xxx') == ['xxx', 'xxxAAA', 'xxx']
    assert candidate(['xxx', 'asd', 'aaaxxy', 'john doe', 'xxxAAA', 'xxx'], 'xx') == ['xxx', 'aaaxxy', 'xxxAAA', 'xxx']
    assert candidate(['grunt', 'trumpet', 'prune', 'gruesome'], 'run') == ['grunt', 'prune']


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
