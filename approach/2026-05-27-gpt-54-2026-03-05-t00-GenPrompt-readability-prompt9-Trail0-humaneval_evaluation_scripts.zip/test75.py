
import unittest
import re
import sys
import math
import copy


def is_multiply_prime(a):
    """Return True if a is the product of exactly 3 prime numbers, else False.

    The 3 prime numbers do not need to be distinct.
    Examples:
        30 = 2 * 3 * 5   -> True
         8 = 2 * 2 * 2   -> True
        12 = 2 * 2 * 3   -> True
    """

    def is_prime(n):
        """Return True if n is prime, else False."""
        if n < 2:
            return False

        for divisor in range(2, int(n ** 0.5) + 1):
            if n % divisor == 0:
                return False

        return True

    prime_factors_count = 0
    remaining = a

    for candidate in range(2, a + 1):
        while remaining % candidate == 0 and is_prime(candidate):
            prime_factors_count += 1
            remaining //= candidate

            if prime_factors_count > 3:
                return False

    return prime_factors_count == 3 and remaining == 1
candidate = is_multiply_prime


def check(candidate):

    assert candidate(5) == False
    assert candidate(30) == True
    assert candidate(8) == True
    assert candidate(10) == False
    assert candidate(125) == True
    assert candidate(3 * 5 * 7) == True
    assert candidate(3 * 6 * 7) == False
    assert candidate(9 * 9 * 9) == False
    assert candidate(11 * 9 * 9) == False
    assert candidate(11 * 13 * 7) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
