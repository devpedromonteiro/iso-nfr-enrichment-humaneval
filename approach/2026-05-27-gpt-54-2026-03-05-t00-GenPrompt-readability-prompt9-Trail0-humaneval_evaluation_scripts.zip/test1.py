
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def separate_paren_groups(paren_string: str) -> List[str]:
    """Separate top-level balanced parenthesis groups.

    The input contains multiple balanced groups of parentheses, possibly with
    spaces between or inside them. Spaces are ignored.

    Examples:
        >>> separate_paren_groups('( ) (( )) (( )( ))')
        ['()', '(())', '(()())']
    """
    groups: List[str] = []
    current_group: List[str] = []
    balance = 0

    for char in paren_string:
        if char == " ":
            continue

        current_group.append(char)

        if char == "(":
            balance += 1
        elif char == ")":
            balance -= 1

        if balance == 0 and current_group:
            groups.append("".join(current_group))
            current_group = []

    return groups
candidate = separate_paren_groups




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('(()()) ((())) () ((())()())') == [
        '(()())', '((()))', '()', '((())()())'
    ]
    assert candidate('() (()) ((())) (((())))') == [
        '()', '(())', '((()))', '(((())))'
    ]
    assert candidate('(()(())((())))') == [
        '(()(())((())))'
    ]
    assert candidate('( ) (( )) (( )( ))') == ['()', '(())', '(()())']


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
