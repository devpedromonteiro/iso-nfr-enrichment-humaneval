
import unittest
import re
import sys
import math
import copy


def f(n):
    """
    Return a list of size n where:
    - the element for position i is i! if i is even
    - otherwise, it is the sum of numbers from 1 to i

    Note:
    i starts from 1.

    Example:
    f(5) == [1, 2, 6, 24, 15]
    """
    result = []

    for i in range(1, n + 1):
        if i % 2 == 0:
            factorial = 1
            for number in range(1, i + 1):
                factorial *= number
            result.append(factorial)
        else:
            total = 0
            for number in range(1, i + 1):
                total += number
            result.append(total)

    return result
candidate = f


def check(candidate):

    assert candidate(5) == [1, 2, 6, 24, 15]
    assert candidate(7) == [1, 2, 6, 24, 15, 720, 28]
    assert candidate(1) == [1]
    assert candidate(3) == [1, 2, 6]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
