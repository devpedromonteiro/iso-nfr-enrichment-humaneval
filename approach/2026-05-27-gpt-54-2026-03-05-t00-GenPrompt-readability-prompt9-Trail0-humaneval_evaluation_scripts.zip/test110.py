
import unittest
import re
import sys
import math
import copy


def exchange(lst1, lst2):
    """Determine whether lst1 can be made entirely even by exchanging elements with lst2.

    Any number of exchanges is allowed. To make all elements in lst1 even,
    every odd number currently in lst1 must be replaced by an even number from lst2.

    Args:
        lst1: A non-empty list of numbers.
        lst2: A non-empty list of numbers.

    Returns:
        "YES" if it is possible to make all elements of lst1 even, otherwise "NO".
    """
    odd_count_in_lst1 = sum(1 for value in lst1 if value % 2 != 0)
    even_count_in_lst2 = sum(1 for value in lst2 if value % 2 == 0)

    if even_count_in_lst2 >= odd_count_in_lst1:
        return "YES"

    return "NO"
candidate = exchange


def check(candidate):

    # Check some simple cases
    assert candidate([1, 2, 3, 4], [1, 2, 3, 4]) == "YES"
    assert candidate([1, 2, 3, 4], [1, 5, 3, 4]) == "NO"
    assert candidate([1, 2, 3, 4], [2, 1, 4, 3]) == "YES" 
    assert candidate([5, 7, 3], [2, 6, 4]) == "YES"
    assert candidate([5, 7, 3], [2, 6, 3]) == "NO" 
    assert candidate([3, 2, 6, 1, 8, 9], [3, 5, 5, 1, 1, 1]) == "NO"

    # Check some edge cases that are easy to work out by hand.
    assert candidate([100, 200], [200, 200]) == "YES"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
