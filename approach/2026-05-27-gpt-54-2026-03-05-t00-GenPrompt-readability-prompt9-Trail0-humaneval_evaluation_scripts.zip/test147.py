
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    You are given a positive integer n. Create an integer array a of length n where:
        a[i] = i * i - i + 1   for 1 <= i <= n

    Return the number of triples (a[i], a[j], a[k]) such that:
        i < j < k
        a[i] + a[j] + a[k] is divisible by 3

    Example:
        Input: n = 5
        Output: 1

        a = [1, 3, 7, 13, 21]
        The only valid triple is (1, 7, 13).
    """

    def combinations_of_three(count):
        """Return count choose 3."""
        if count < 3:
            return 0
        return count * (count - 1) * (count - 2) // 6

    # Observe:
    # a[i] = i^2 - i + 1 = i(i - 1) + 1
    # Since i(i - 1) is always divisible by 2 consecutive integers,
    # we only care about a[i] % 3.
    #
    # Checking i % 3:
    # i % 3 == 0 -> a[i] % 3 == 1
    # i % 3 == 1 -> a[i] % 3 == 1
    # i % 3 == 2 -> a[i] % 3 == 0
    #
    # So values in array a are only of remainder 0 or 1 modulo 3.
    #
    # For sum of three numbers to be divisible by 3, possible remainder combinations are:
    # (0, 0, 0) or (1, 1, 1)
    #
    # Count how many terms contribute remainder 0 and remainder 1.

    count_remainder_0 = n // 3          # indices where i % 3 == 2
    count_remainder_1 = n - count_remainder_0

    return (
        combinations_of_three(count_remainder_0) +
        combinations_of_three(count_remainder_1)
    )
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
