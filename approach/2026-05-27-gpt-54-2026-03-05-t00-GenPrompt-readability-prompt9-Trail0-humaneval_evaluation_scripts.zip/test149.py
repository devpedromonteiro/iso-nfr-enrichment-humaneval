
import unittest
import re
import sys
import math
import copy


def sorted_list_sum(lst):
    """Return even-length strings sorted by length, then alphabetically.

    The function:
    - removes strings with odd lengths
    - sorts the remaining strings in ascending order by length
    - uses alphabetical order as a tiebreaker for strings of equal length

    Examples:
        sorted_list_sum(["aa", "a", "aaa"]) -> ["aa"]
        sorted_list_sum(["ab", "a", "aaa", "cd"]) -> ["ab", "cd"]
    """
    even_length_strings = [word for word in lst if len(word) % 2 == 0]
    return sorted(even_length_strings, key=lambda word: (len(word), word))
candidate = sorted_list_sum


def check(candidate):

    # Check some simple cases
    assert candidate(["aa", "a", "aaa"]) == ["aa"]
    assert candidate(["school", "AI", "asdf", "b"]) == ["AI", "asdf", "school"]
    assert candidate(["d", "b", "c", "a"]) == []
    assert candidate(["d", "dcba", "abcd", "a"]) == ["abcd", "dcba"]

    # Check some edge cases that are easy to work out by hand.
    assert candidate(["AI", "ai", "au"]) == ["AI", "ai", "au"]
    assert candidate(["a", "b", "b", "c", "c", "a"]) == []
    assert candidate(['aaaa', 'bbbb', 'dd', 'cc']) == ["cc", "dd", "aaaa", "bbbb"]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
