
import unittest
import re
import sys
import math
import copy



def encode_shift(s: str):
    """
    returns encoded string by shifting every character by 5 in the alphabet.
    """
    return "".join([chr(((ord(ch) + 5 - ord("a")) % 26) + ord("a")) for ch in s])


def encode_shift(s: str) -> str:
    """
    Return a string with each lowercase letter shifted forward by 5 positions.

    Example:
        "abc" -> "fgh"
        "xyz" -> "cde"
    """
    shift = 5
    alphabet_size = 26
    base = ord("a")

    encoded_chars = []
    for ch in s:
        shifted = ((ord(ch) - base + shift) % alphabet_size) + base
        encoded_chars.append(chr(shifted))

    return "".join(encoded_chars)


def decode_shift(s: str) -> str:
    """
    Decode a string that was encoded with encode_shift.

    Example:
        "fgh" -> "abc"
        "cde" -> "xyz"
    """
    shift = 5
    alphabet_size = 26
    base = ord("a")

    decoded_chars = []
    for ch in s:
        shifted = ((ord(ch) - base - shift) % alphabet_size) + base
        decoded_chars.append(chr(shifted))

    return "".join(decoded_chars)
candidate = decode_shift




METADATA = {}


def check(candidate):
    from random import randint, choice
    import copy
    import string

    letters = string.ascii_lowercase
    for _ in range(100):
        str = ''.join(choice(letters) for i in range(randint(10, 20)))
        encoded_str = encode_shift(str)
        assert candidate(copy.deepcopy(encoded_str)) == str



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
