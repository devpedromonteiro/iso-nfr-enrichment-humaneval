
import unittest
import re
import sys
import math
import copy


def solution(lst):
    """Given a non-empty list of integers, return the sum of all odd elements
    that are in even positions.

    Positions are treated as 0-based indices, so even positions are:
    0, 2, 4, ...

    Examples:
        solution([5, 8, 7, 1]) == 12
        solution([3, 3, 3, 3, 3]) == 9
        solution([30, 13, 24, 321]) == 0
    """
    total = 0

    for index, value in enumerate(lst):
        is_even_position = index % 2 == 0
        is_odd_value = value % 2 != 0

        if is_even_position and is_odd_value:
            total += value

    return total
candidate = solution


def check(candidate):

    # Check some simple cases
    assert candidate([5, 8, 7, 1])    == 12
    assert candidate([3, 3, 3, 3, 3]) == 9
    assert candidate([30, 13, 24, 321]) == 0
    assert candidate([5, 9]) == 5
    assert candidate([2, 4, 8]) == 0
    assert candidate([30, 13, 23, 32]) == 23
    assert candidate([3, 13, 2, 9]) == 3

    # Check some edge cases that are easy to work out by hand.



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
