
import unittest

from typing import List


from typing import List


def separate_paren_groups(paren_string: str) -> List[str]:
    """Input to this function is a string containing multiple groups of nested parentheses.
    Your goal is to separate those groups into separate strings and return them as a list.

    Separate groups are balanced (each open brace is properly closed) and not nested within each other.
    Ignore any spaces in the input string.

    >>> separate_paren_groups('( ) (( )) (( )( ))')
    ['()', '(())', '(()())']
    """
    if not isinstance(paren_string, str):
        raise TypeError("paren_string must be a string")

    groups: List[str] = []
    current_group: List[str] = []
    balance = 0

    for index, char in enumerate(paren_string):
        if char == " ":
            continue
        if char not in ("(", ")"):
            raise ValueError(
                f"Invalid character at index {index}: {char!r}. Only '(', ')', and spaces are allowed."
            )

        current_group.append(char)

        if char == "(":
            balance += 1
        else:
            balance -= 1
            if balance < 0:
                raise ValueError(
                    f"Unbalanced parentheses at index {index}: closing parenthesis without matching opening parenthesis."
                )

        if balance == 0:
            groups.append("".join(current_group))
            current_group = []

    if balance != 0:
        raise ValueError("Unbalanced parentheses: missing closing parenthesis.")

    if current_group:
        raise ValueError("Invalid state: incomplete parenthesis group remains after parsing.")

    return groups
candidate = separate_paren_groups


class Test(unittest.TestCase):
    def test(self):
        assert candidate("(()())(()())(())") == ['(()())', '(()())', '(())']
        assert candidate("(())(((())))(((())))(((())))") == ['(())', '(((())))', '(((())))', '(((())))']
        assert candidate("()(())((()))(())") == ['()', '(())', '((()))', '(())']
        assert candidate("(()())()((())()())((()))") == ['(()())', '()', '((())()())', '((()))']
        assert candidate("(()())(()())((()))((()))") == ['(()())', '(()())', '((()))', '((()))']
        assert candidate("((()))()()((())()())") == ['((()))', '()', '()', '((())()())']
        assert candidate("(())()()") == ['(())', '()', '()']
        assert candidate("(((())))((()))((()))(((())))") == ['(((())))', '((()))', '((()))', '(((())))']
        assert candidate("((()))(())((()))(((())))") == ['((()))', '(())', '((()))', '(((())))']
        assert candidate("(())()(())") == ['(())', '()', '(())']
        assert candidate("(())(()())(())") == ['(())', '(()())', '(())']
        assert candidate("()()(()())") == ['()', '()', '(()())']
        assert candidate("(())(())(())") == ['(())', '(())', '(())']
        assert candidate("((())()())((()))((())()())((())()())") == ['((())()())', '((()))', '((())()())', '((())()())']
        assert candidate("()((())()())((()))((())()())") == ['()', '((())()())', '((()))', '((())()())']
        assert candidate("()((())()())((())()())((()))") == ['()', '((())()())', '((())()())', '((()))']
        assert candidate("((()))()()(((())))") == ['((()))', '()', '()', '(((())))']
        assert candidate("()()()((()))") == ['()', '()', '()', '((()))']
        assert candidate("()(((())))(((())))(())") == ['()', '(((())))', '(((())))', '(())']
        assert candidate("((())()())((())()())((())()())()") == ['((())()())', '((())()())', '((())()())', '()']
        assert candidate("(((())))(((())))(())(())") == ['(((())))', '(((())))', '(())', '(())']
        assert candidate("()(())()") == ['()', '(())', '()']
        assert candidate("((()))()((())()())(()())") == ['((()))', '()', '((())()())', '(()())']
        assert candidate("((())()())(()())((())()())()") == ['((())()())', '(()())', '((())()())', '()']
        assert candidate("(((())))(())()()") == ['(((())))', '(())', '()', '()']
        assert candidate("()(()())(()())((()))") == ['()', '(()())', '(()())', '((()))']
        assert candidate("(())(())(()())") == ['(())', '(())', '(()())']
        assert candidate("()(()())(()())()") == ['()', '(()())', '(()())', '()']
        assert candidate("(()())()(()())") == ['(()())', '()', '(()())']
        assert candidate("(()())(()())()((())()())") == ['(()())', '(()())', '()', '((())()())']
        assert candidate("()(())(())") == ['()', '(())', '(())']
        assert candidate("()(()())(())") == ['()', '(()())', '(())']
        assert candidate('(()()) ((())) () ((())()())') == [
        '(()())', '((()))', '()', '((())()())'
    ]
        assert candidate("(())((()))()(((())))") == ['(())', '((()))', '()', '(((())))']
        assert candidate("((())()())((()))((()))((()))") == ['((())()())', '((()))', '((()))', '((()))']
        assert candidate('() (()) ((())) (((())))') == [
        '()', '(())', '((()))', '(((())))'
    ]
        assert candidate("()()()((())()())") == ['()', '()', '()', '((())()())']
        assert candidate("()(((())))(())((()))") == ['()', '(((())))', '(())', '((()))']
        assert candidate("(())(()())()") == ['(())', '(()())', '()']
        assert candidate("((()))(((())))(())()") == ['((()))', '(((())))', '(())', '()']
        assert candidate("(()())()((()))()") == ['(()())', '()', '((()))', '()']
        assert candidate('( ) (( )) (( )( ))') == ['()', '(())', '(()())']
        assert candidate("()(())(((())))(((())))") == ['()', '(())', '(((())))', '(((())))']
        assert candidate("((()))(((())))((()))((()))") == ['((()))', '(((())))', '((()))', '((()))']
        assert candidate("(((())))(())(())(((())))") == ['(((())))', '(())', '(())', '(((())))']
        assert candidate("((()))()(()())((()))") == ['((()))', '()', '(()())', '((()))']
        assert candidate("()(((())))()(())") == ['()', '(((())))', '()', '(())']
        assert candidate("(())()(()())") == ['(())', '()', '(()())']
        assert candidate("()()()") == ['()', '()', '()']
        assert candidate("((()))(()())((()))()") == ['((()))', '(()())', '((()))', '()']
        assert candidate("((()))(()())()((())()())") == ['((()))', '(()())', '()', '((())()())']
        assert candidate("(()())(()())(()())") == ['(()())', '(()())', '(()())']
        assert candidate('(()(())((())))') == [
        '(()(())((())))'
    ]
        assert candidate("()(())()(())") == ['()', '(())', '()', '(())']
        assert candidate("(())()(())(((())))") == ['(())', '()', '(())', '(((())))']
        assert candidate("()((())()())((())()())()") == ['()', '((())()())', '((())()())', '()']
        assert candidate("()()(())((()))") == ['()', '()', '(())', '((()))']
        assert candidate("(())((()))((()))(((())))") == ['(())', '((()))', '((()))', '(((())))']
        assert candidate("((()))(())(())(())") == ['((()))', '(())', '(())', '(())']
        assert candidate("((()))()()((()))") == ['((()))', '()', '()', '((()))']
        assert candidate("(()())((()))((())()())(()())") == ['(()())', '((()))', '((())()())', '(()())']
        assert candidate("(())(())()()") == ['(())', '(())', '()', '()']
        assert candidate("(()(())((())))") == ['(()(())((())))']
        assert candidate("(((())))((()))(((())))((()))") == ['(((())))', '((()))', '(((())))', '((()))']
        assert candidate("()()(())") == ['()', '()', '(())']
        assert candidate("()(())(()())") == ['()', '(())', '(()())']
        assert candidate("(()())()(()())(()())") == ['(()())', '()', '(()())', '(()())']
        assert candidate("(()())()(())") == ['(()())', '()', '(())']
        assert candidate("((()))(())(())()") == ['((()))', '(())', '(())', '()']

if __name__ == '__main__':
    unittest.main()
