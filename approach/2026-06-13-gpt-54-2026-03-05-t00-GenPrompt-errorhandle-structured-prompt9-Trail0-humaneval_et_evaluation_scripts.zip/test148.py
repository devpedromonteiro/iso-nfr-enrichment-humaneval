
import unittest


def bf(planet1, planet2):
    '''
    There are eight planets in our solar system: the closerst to the Sun 
    is Mercury, the next one is Venus, then Earth, Mars, Jupiter, Saturn, 
    Uranus, Neptune.
    Write a function that takes two planet names as strings planet1 and planet2. 
    The function should return a tuple containing all planets whose orbits are 
    located between the orbit of planet1 and the orbit of planet2, sorted by 
    the proximity to the sun. 
    The function should return an empty tuple if planet1 or planet2
    are not correct planet names. 
    Examples
    bf("Jupiter", "Neptune") ==> ("Saturn", "Uranus")
    bf("Earth", "Mercury") ==> ("Venus")
    bf("Mercury", "Uranus") ==> ("Venus", "Earth", "Mars", "Jupiter", "Saturn")
    '''
    planets = (
        "Mercury", "Venus", "Earth", "Mars",
        "Jupiter", "Saturn", "Uranus", "Neptune"
    )

    try:
        if not isinstance(planet1, str):
            raise TypeError("planet1 must be a string")
        if not isinstance(planet2, str):
            raise TypeError("planet2 must be a string")

        if planet1 not in planets or planet2 not in planets:
            return ()

        index1 = planets.index(planet1)
        index2 = planets.index(planet2)

        start = min(index1, index2) + 1
        end = max(index1, index2)

        return planets[start:end]

    except TypeError:
        raise
    except Exception as exc:
        raise RuntimeError("Unexpected error while computing planets between orbits") from exc
candidate = bf


class Test(unittest.TestCase):
    def test(self):
        assert candidate('Mercury', 'Uranus') == ('Venus', 'Earth', 'Mars', 'Jupiter', 'Saturn')
        assert candidate('Earth', 'Neptune') == ('Mars', 'Jupiter', 'Saturn', 'Uranus')
        assert candidate('Uranus', 'Neptune') == ()
        assert candidate('BmIfOHfuO', 'wRdUevYZI') == ()
        assert candidate('hSLEjoINv', 'YYAhwA') == ()
        assert candidate('buNtf', 'scfbWIUY') == ()
        assert candidate('XSuDrOCZ', 'rIuxDaB') == ()
        assert candidate("Mars", "Earth") == ()
        assert candidate('UWohXWxaLKC', 'wxWzdfKzvTwn') == ()
        assert candidate('proqRzxn', 'cLxtIMtgR') == ()
        assert candidate('hayLKiu', 'PNqJKHp') == ()
        assert candidate('mKeLE', 'wUFkoci') == ()
        assert candidate('Earth', 'Earth') == ()
        assert candidate('DbZtRXht', 'IFhEw') == ()
        assert candidate('DmfS', 'jlIbIoY') == ()
        assert candidate('Mercury', 'Jupiter') == ('Venus', 'Earth', 'Mars')
        assert candidate('ffrUoKQx', 'SNZLGhr') == ()
        assert candidate('Venus', 'Mercury') == ()
        assert candidate('NLDe', 'rzLkDX') == ()
        assert candidate('qDuD', 'wdbCsSfpyJ') == ()
        assert candidate('eAuZ', 'CDjFvr') == ()
        assert candidate('uSALSr', 'hpkswMWd') == ()
        assert candidate('JTFhqMWoE', 'vshaCvtG') == ()
        assert candidate('Jupiter', 'Neptune') == ('Saturn', 'Uranus')
        assert candidate('xgGOVPmL', 'QcnfLMd') == ()
        assert candidate('Venus', 'Mars') == ('Earth',)
        assert candidate('VLDLDEO', 'Kemt') == ()
        assert candidate('Uranus', 'Saturn') == ()
        assert candidate('Earth', 'Jupiter') == ('Mars',)
        assert candidate('WxA', 'JRQl') == ()
        assert candidate('CvjBqYn', 'JphCPo') == ()
        assert candidate('JpxsgCfeGpVA', 'HUujAsabnZ') == ()
        assert candidate('Neptune', 'Saturn') == ('Uranus',)
        assert candidate('Uranus', 'Venus') == ('Earth', 'Mars', 'Jupiter', 'Saturn')
        assert candidate('Uranus', 'Earth') == ('Mars', 'Jupiter', 'Saturn')
        assert candidate('jxc', 'QmQxf') == ()
        assert candidate('GJTKYgzMd', 'gWi') == ()
        assert candidate('Jupiter', 'Earth') == ('Mars',)
        assert candidate('Earth', 'Mars') == ()
        assert candidate('fifVrBwCb', 'WwPWORetZ') == ()
        assert candidate('Saturn', 'Mercury') == ('Venus', 'Earth', 'Mars', 'Jupiter')
        assert candidate('Saturn', 'Earth') == ('Mars', 'Jupiter')
        assert candidate('Neptune', 'Jupiter') == ('Saturn', 'Uranus')
        assert candidate('Mercury', 'Neptune') == ('Venus', 'Earth', 'Mars', 'Jupiter', 'Saturn', 'Uranus')
        assert candidate("Earth", "Earth") == ()
        assert candidate('RucLkBzqBlnI', 'xstFZL') == ()
        assert candidate('Jupiter', 'Uranus') == ('Saturn',)
        assert candidate('lyfEeBXn', 'uzRssTA') == ()
        assert candidate('Jupiter', 'Saturn') == ()
        assert candidate("Jupiter", "Makemake") == ()
        assert candidate('Uranus', 'Uranus') == ()
        assert candidate('Venus', 'Earth') == ()
        assert candidate("Jupiter", "Neptune") == ("Saturn", "Uranus"), "First test error: " + str(len(candidate("Jupiter", "Neptune")))
        assert candidate('Neptune', 'Neptune') == ()
        assert candidate('xJrSGV', 'zdwOxdVzN') == ()
        assert candidate('gyUn', 'vMujG') == ()
        assert candidate('Venus', 'Saturn') == ('Earth', 'Mars', 'Jupiter')
        assert candidate('FoICpuSx', 'DLeFV') == ()
        assert candidate('tnrxRqi', 'AWplLV') == ()
        assert candidate('pHPJQTV', 'dWIDiZP') == ()
        assert candidate('smEXloM', 'jZBLGc') == ()
        assert candidate('Mars', 'Neptune') == ('Jupiter', 'Saturn', 'Uranus')
        assert candidate('Uranus', 'Mercury') == ('Venus', 'Earth', 'Mars', 'Jupiter', 'Saturn')
        assert candidate('tmaUgxPoC', 'YmJrbcSj') == ()
        assert candidate('GzPVDzR', 'zGQ') == ()
        assert candidate('DHKmwLimf', 'hejG') == ()
        assert candidate('IvccNilTV', 'PzX') == ()
        assert candidate('HCGq', 'yVCoay') == ()
        assert candidate('wdEgmW', 'dEgw') == ()
        assert candidate('Venus', 'Neptune') == ('Earth', 'Mars', 'Jupiter', 'Saturn', 'Uranus')
        assert candidate('UEmf', 'orUuN') == ()
        assert candidate('KQcimuFmov', 'dxFbURLcq') == ()
        assert candidate('JKjmqhz', 'vlVlQIlPkV') == ()
        assert candidate('Mercury', 'Earth') == ('Venus',)
        assert candidate('lXjRDOc', 'fXKFCManbjQ') == ()
        assert candidate('uKpmBiu', 'wLhUekd') == ()
        assert candidate('sKlHVKBU', 'Nxb') == ()
        assert candidate("Neptune", "Venus") == ("Earth", "Mars", "Jupiter", "Saturn", "Uranus"), "Fourth test error: " + str(candidate("Neptune", "Venus"))  


    # Check some edge cases that are easy to work out by hand.
        assert candidate('Saturn', 'Jupiter') == ()
        assert candidate('Earth', 'Saturn') == ('Mars', 'Jupiter')
        assert candidate('KHB', 'OoZXdElWw') == ()
        assert candidate('wBIcna', 'iQRGuAv') == ()
        assert candidate('Earth', 'Venus') == ()
        assert candidate('Neptune', 'Mars') == ('Jupiter', 'Saturn', 'Uranus')
        assert candidate('Uranus', 'Mars') == ('Jupiter', 'Saturn')
        assert candidate('zYEZNC', 'yuHunvTb') == ()
        assert candidate("Earth", "Mercury") == ("Venus",), "Second test error: " + str(candidate("Earth", "Mercury"))
        assert candidate('Saturn', 'Uranus') == ()
        assert candidate('NnRASam', 'kLreZ') == ()
        assert candidate('cmy', 'MPBqlP') == ()
        assert candidate('Mercury', 'Mercury') == ()
        assert candidate('Mars', 'Mercury') == ('Venus', 'Earth')
        assert candidate('tHQBLXkkh', 'XiMEyBQ') == ()
        assert candidate('Jupiter', 'Mars') == ()
        assert candidate('grjW', 'UOtjR') == ()
        assert candidate('MbdIWyQKKQv', 'ErIHtYqB') == ()
        assert candidate('NLnoeB', 'caeAE') == ()
        assert candidate('ufKZhFD', 'yyASc') == ()
        assert candidate('Mars', 'Mars') == ()
        assert candidate('Mars', 'Uranus') == ('Jupiter', 'Saturn')
        assert candidate("Mercury", "Uranus") == ("Venus", "Earth", "Mars", "Jupiter", "Saturn"), "Third test error: " + str(candidate("Mercury", "Uranus"))
        assert candidate('Mercury', 'Mars') == ('Venus', 'Earth')

if __name__ == '__main__':
    unittest.main()
