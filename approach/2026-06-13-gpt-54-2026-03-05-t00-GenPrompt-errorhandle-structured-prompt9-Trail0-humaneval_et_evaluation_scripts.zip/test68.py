
import unittest


def pluck(arr):
    """
    Given an array representing a branch of a tree that has non-negative integer nodes,
    return [smallest_even_value, index] for the smallest even value.
    If multiple nodes share that value, return the one with the smallest index.
    If the array is empty or contains no even values, return [].

    Error handling:
    - Raises TypeError if arr is not a list or tuple.
    - Raises TypeError if any element is not an integer.
    - Raises ValueError if any element is negative.
    """
    if arr is None:
        raise TypeError("arr must be a list or tuple, got None")

    if not isinstance(arr, (list, tuple)):
        raise TypeError(f"arr must be a list or tuple, got {type(arr).__name__}")

    smallest_even = None
    smallest_index = None

    for index, value in enumerate(arr):
        if not isinstance(value, int):
            raise TypeError(
                f"all elements must be integers; found {type(value).__name__} at index {index}"
            )
        if value < 0:
            raise ValueError(f"all elements must be non-negative; found {value} at index {index}")

        if value % 2 == 0:
            if smallest_even is None or value < smallest_even:
                smallest_even = value
                smallest_index = index

    if smallest_even is None:
        return []

    return [smallest_even, smallest_index]
candidate = pluck


class Test(unittest.TestCase):
    def test(self):
        assert candidate([5, 7, 3]) == []
        assert candidate([3, 5, 2, 5, 3, 2]) == [2, 2]
        assert candidate([2, 6, 9, 4, 8]) == [2, 0]
        assert candidate([7, 7, 8]) == [8, 2]
        assert candidate([3, 11, 6, 5]) == [6, 2]
        assert candidate([7, 4, 6, 4, 7, 7]) == [4, 1]
        assert candidate([6, 7, 10, 8, 8]) == [6, 0]
        assert candidate([8, 3, 2, 5]) == [2, 2]
        assert candidate([1, 1, 7, 4, 3, 7]) == [4, 3]
        assert candidate([8, 1, 12, 4, 4]) == [4, 3]
        assert candidate([7, 3, 1, 1, 3, 7]) == []
        assert candidate([8, 11, 2, 2]) == [2, 2]
        assert candidate([1, 3, 7, 2, 1, 3]) == [2, 3]
        assert candidate([1, 2, 3, 0, 5, 3]) == [0, 3], "Error"
        assert candidate([6, 3, 3, 2, 8, 7]) == [2, 3]
        assert candidate([3, 1, 8, 4, 5, 5]) == [4, 3]
        assert candidate([1, 4, 4, 3, 5, 4]) == [4, 1]
        assert candidate([5, 1, 6, 2, 4, 1]) == [2, 3]
        assert candidate([2, 5, 3, 1]) == [2, 0]
        assert candidate([]) == [], "Error"
        assert candidate([7, 6, 4]) == [4, 2]
        assert candidate([4,2,3]) == [2, 1], "Error"
        assert candidate([8, 2, 3, 1, 8, 3]) == [2, 1]
        assert candidate([1, 3, 6]) == [6, 2]
        assert candidate([6, 4, 4, 4, 8, 6]) == [4, 1]
        assert candidate([7, 9, 7, 1]) == [], "Error"
        assert candidate([1, 5, 5]) == []
        assert candidate([7, 5, 13, 4, 8]) == [4, 3]
        assert candidate([5, 0, 3, 0, 4, 2]) == [0, 1], "Error"

    # Check some edge cases that are easy to work out by hand.
        assert candidate([10, 9, 6, 6]) == [6, 2]
        assert candidate([5, 4, 8, 1]) == [4, 1]
        assert candidate([2, 7, 8]) == [2, 0]
        assert candidate([1, 1, 1]) == []
        assert candidate([6, 7, 2, 4, 5, 1]) == [2, 2]
        assert candidate([7, 6, 7, 1]) == [6, 1], "Error"
        assert candidate([11, 11, 3, 4]) == [4, 3]
        assert candidate([4, 6, 5, 4, 4, 2]) == [2, 5]
        assert candidate([5, 4, 2, 1, 3, 4]) == [2, 2]
        assert candidate([4, 2, 4]) == [2, 1]
        assert candidate([3, 1, 3, 3, 6, 4]) == [4, 5]
        assert candidate([9, 5, 2, 4, 9, 6]) == [2, 2]
        assert candidate([2, 7, 6, 5, 3]) == [2, 0]
        assert candidate([10, 1, 4, 3, 4]) == [4, 2]
        assert candidate([7, 1, 6]) == [6, 2]
        assert candidate([5, 7, 7, 5, 10, 7]) == [10, 4]
        assert candidate([1,2,3]) == [2, 1], "Error"
        assert candidate([9, 10, 3, 3]) == [10, 1]
        assert candidate([7, 7, 5]) == []
        assert candidate([5, 1, 2, 1, 6, 6]) == [2, 2]
        assert candidate([6, 9, 9, 4, 10]) == [4, 3]
        assert candidate([2, 4, 2, 2, 7, 4]) == [2, 0]
        assert candidate([5, 1, 4, 4, 10, 5]) == [4, 2]
        assert candidate([10, 6, 6, 3]) == [6, 1]
        assert candidate([]) == []
        assert candidate([6, 2, 6, 4, 8, 7]) == [2, 1]
        assert candidate([2, 3, 3]) == [2, 0]
        assert candidate([1, 4, 8]) == [4, 1]
        assert candidate([2, 11, 10, 5]) == [2, 0]
        assert candidate([5, 6, 8, 1, 5, 4]) == [4, 5]
        assert candidate([5, 4, 5, 5, 6, 6]) == [4, 1]
        assert candidate([5, 4, 8, 4 ,8]) == [4, 1], "Error"
        assert candidate([9, 1, 3, 5, 8, 1]) == [8, 4]
        assert candidate([7, 1, 5, 6, 13]) == [6, 3]
        assert candidate([3, 1, 1, 2, 1, 1]) == [2, 3]
        assert candidate([2, 1, 3, 8, 4]) == [2, 0]
        assert candidate([5, 5, 2]) == [2, 2]
        assert candidate([9, 2, 12, 8, 6]) == [2, 1]
        assert candidate([4, 3, 4]) == [4, 0]
        assert candidate([7, 3, 9, 3, 8]) == [8, 4]
        assert candidate([7, 3, 4]) == [4, 2]
        assert candidate([2, 4, 7]) == [2, 0]
        assert candidate([10, 5, 6, 3, 4, 2]) == [2, 5]
        assert candidate([2, 5, 7]) == [2, 0]
        assert candidate([6, 4, 5]) == [4, 1]
        assert candidate([12, 4, 12, 5]) == [4, 1]
        assert candidate([2, 1, 6]) == [2, 0]
        assert candidate([4, 1, 4, 3, 3, 6]) == [4, 0]
        assert candidate([5, 4, 1]) == [4, 1]
        assert candidate([4, 4, 6]) == [4, 0]
        assert candidate([7, 3, 12, 9, 13]) == [12, 2]
        assert candidate([8, 1, 8]) == [8, 0]
        assert candidate([4, 6, 5, 2, 7, 1]) == [2, 3]
        assert candidate([5, 9, 12, 1]) == [12, 2]
        assert candidate([1, 2, 4]) == [2, 1]
        assert candidate([7, 6, 7]) == [6, 1]
        assert candidate([5, 1, 13, 2, 13]) == [2, 3]
        assert candidate([4, 5, 8, 3, 9, 1]) == [4, 0]
        assert candidate([5, 3, 6]) == [6, 2]
        assert candidate([12, 1, 12, 1]) == [12, 0]
        assert candidate([3, 3, 1, 3, 2, 6]) == [2, 4]
        assert candidate([5, 6, 4, 1, 12]) == [4, 2]
        assert candidate([4, 4, 3, 7, 12]) == [4, 0]
        assert candidate([8, 6, 8]) == [6, 1]
        assert candidate([7, 6, 1]) == [6, 1]
        assert candidate([2, 8, 6, 5]) == [2, 0]
        assert candidate([3, 2, 9, 6]) == [2, 1]
        assert candidate([2, 4, 8]) == [2, 0]
        assert candidate([3, 7, 6]) == [6, 2]
        assert candidate([2, 2, 8]) == [2, 0]

if __name__ == '__main__':
    unittest.main()
