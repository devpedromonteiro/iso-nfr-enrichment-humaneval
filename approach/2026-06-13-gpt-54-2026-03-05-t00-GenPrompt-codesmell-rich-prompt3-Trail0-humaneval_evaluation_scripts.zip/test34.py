
import unittest
import re
import sys
import math
import copy



def _sorted_copy(values: list) -> list:
    """Return a sorted copy of the input list."""
    return sorted(values)


def _deduplicate_sorted(values: list) -> list:
    """Return unique elements from an already sorted list."""
    if not values:
        return []

    result = [values[0]]
    for item in values[1:]:
        if item != result[-1]:
            result.append(item)
    return result


def unique(l: list) -> list:
    """Return sorted unique elements in a list.

    >>> unique([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [0, 2, 3, 5, 9, 123]
    """
    sorted_values = _sorted_copy(l)
    return _deduplicate_sorted(sorted_values)
candidate = unique




METADATA = {}


def check(candidate):
    assert candidate([5, 3, 5, 2, 3, 3, 9, 0, 123]) == [0, 2, 3, 5, 9, 123]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
