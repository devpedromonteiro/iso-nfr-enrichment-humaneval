
import unittest
import re
import sys
import math
import copy


import re


def _extract_fruit_counts(description):
    """Return the sum of numeric fruit counts found in the description string."""
    numbers = re.findall(r"\d+", description)
    return sum(int(value) for value in numbers)


def fruit_distribution(s, n):
    """
    Given a string describing the number of apples and oranges in a basket
    and the total number of fruits, return the number of mangoes.

    Examples:
    fruit_distribution("5 apples and 6 oranges", 19) -> 8
    fruit_distribution("0 apples and 1 oranges", 3) -> 2
    fruit_distribution("2 apples and 3 oranges", 100) -> 95
    fruit_distribution("100 apples and 1 oranges", 120) -> 19
    """
    known_fruits = _extract_fruit_counts(s)
    return n - known_fruits
candidate = fruit_distribution


def check(candidate):

    # Check some simple cases
    assert candidate("5 apples and 6 oranges",19) == 8
    assert candidate("5 apples and 6 oranges",21) == 10
    assert candidate("0 apples and 1 oranges",3) == 2
    assert candidate("1 apples and 0 oranges",3) == 2
    assert candidate("2 apples and 3 oranges",100) == 95
    assert candidate("2 apples and 3 oranges",5) == 0
    assert candidate("1 apples and 100 oranges",120) == 19


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
