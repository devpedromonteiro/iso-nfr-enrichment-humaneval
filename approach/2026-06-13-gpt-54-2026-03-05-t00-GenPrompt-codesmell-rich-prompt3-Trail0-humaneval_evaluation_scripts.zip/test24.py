
import unittest
import re
import sys
import math
import copy



def largest_divisor(n: int) -> int:
    """Return the largest proper divisor of ``n``.

    A proper divisor divides ``n`` evenly and is smaller than ``n``.

    >>> largest_divisor(15)
    5
    >>> largest_divisor(13)
    1
    >>> largest_divisor(1)
    1
    """
    _validate_input(n)
    return _find_largest_proper_divisor(n)


def _validate_input(n: int) -> None:
    """Validate that the input is a positive integer."""
    if n < 1:
        raise ValueError("n must be a positive integer")


def _find_largest_proper_divisor(n: int) -> int:
    """Find the largest divisor of n that is smaller than n."""
    if n == 1:
        return 1

    for candidate in range(n // 2, 0, -1):
        if _is_divisor(n, candidate):
            return candidate

    return 1


def _is_divisor(n: int, candidate: int) -> bool:
    """Return True if candidate divides n evenly."""
    return n % candidate == 0
candidate = largest_divisor




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(3) == 1
    assert candidate(7) == 1
    assert candidate(10) == 5
    assert candidate(100) == 50
    assert candidate(49) == 7


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
