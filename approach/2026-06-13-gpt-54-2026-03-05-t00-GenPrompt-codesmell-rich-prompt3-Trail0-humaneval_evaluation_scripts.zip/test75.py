
import unittest
import re
import sys
import math
import copy


def is_multiply_prime(a):
    """Return True if ``a`` is the product of exactly 3 prime numbers.

    Prime factors may repeat, so values like 8 = 2 * 2 * 2 return True.
    Assumes ``a`` is less than 100, but works for larger positive integers too.
    """
    if a < 2:
        return False

    prime_factors = _get_prime_factors(a)
    return len(prime_factors) == 3 and _multiply(prime_factors) == a


def _get_prime_factors(number):
    """Return the prime factors of ``number`` including repeated factors."""
    factors = []
    divisor = 2
    remaining = number

    while divisor * divisor <= remaining:
        while remaining % divisor == 0:
            factors.append(divisor)
            remaining //= divisor
        divisor += 1

    if remaining > 1:
        factors.append(remaining)

    return factors


def _multiply(values):
    """Return the product of all values in the iterable."""
    result = 1
    for value in values:
        result *= value
    return result
candidate = is_multiply_prime


def check(candidate):

    assert candidate(5) == False
    assert candidate(30) == True
    assert candidate(8) == True
    assert candidate(10) == False
    assert candidate(125) == True
    assert candidate(3 * 5 * 7) == True
    assert candidate(3 * 6 * 7) == False
    assert candidate(9 * 9 * 9) == False
    assert candidate(11 * 9 * 9) == False
    assert candidate(11 * 13 * 7) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
