
import unittest
import re
import sys
import math
import copy



from typing import Iterable, Iterator, TypeVar

T = TypeVar("T")


def _adjacent_pairs(values: Iterable[T]) -> Iterator[tuple[T, T]]:
    """Yield consecutive pairs from an iterable."""
    iterator = iter(values)
    try:
        previous = next(iterator)
    except StopIteration:
        return

    for current in iterator:
        yield previous, current
        previous = current


def _is_non_decreasing(values: list[T]) -> bool:
    """Return True if values never decrease."""
    return all(left <= right for left, right in _adjacent_pairs(values))


def _is_non_increasing(values: list[T]) -> bool:
    """Return True if values never increase."""
    return all(left >= right for left, right in _adjacent_pairs(values))


def monotonic(l: list[T]) -> bool:
    """Return True is list elements are monotonically increasing or decreasing.
    >>> monotonic([1, 2, 4, 20])
    True
    >>> monotonic([1, 20, 4, 10])
    False
    >>> monotonic([4, 1, 0, -10])
    True
    """
    return _is_non_decreasing(l) or _is_non_increasing(l)
candidate = monotonic




METADATA = {}


def check(candidate):
    assert candidate([1, 2, 4, 10]) == True
    assert candidate([1, 2, 4, 20]) == True
    assert candidate([1, 20, 4, 10]) == False
    assert candidate([4, 1, 0, -10]) == True
    assert candidate([4, 1, 1, 0]) == True
    assert candidate([1, 2, 3, 2, 5, 60]) == False
    assert candidate([1, 2, 3, 4, 5, 60]) == True
    assert candidate([9, 9, 9, 9]) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
