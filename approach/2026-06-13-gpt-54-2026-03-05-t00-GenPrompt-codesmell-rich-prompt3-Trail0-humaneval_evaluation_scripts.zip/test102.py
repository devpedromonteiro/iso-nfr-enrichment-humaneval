
import unittest
import re
import sys
import math
import copy


def _is_invalid_range(start, end):
    return start > end


def _largest_even_at_most(value):
    return value if value % 2 == 0 else value - 1


def choose_num(x, y):
    """Return the largest even integer in the inclusive range [x, y].

    If the range is invalid or contains no even number, return -1.
    """
    if _is_invalid_range(x, y):
        return -1

    candidate = _largest_even_at_most(y)
    return candidate if candidate >= x else -1
candidate = choose_num


def check(candidate):

    # Check some simple cases
    assert candidate(12, 15) == 14
    assert candidate(13, 12) == -1
    assert candidate(33, 12354) == 12354
    assert candidate(5234, 5233) == -1
    assert candidate(6, 29) == 28
    assert candidate(27, 10) == -1

    # Check some edge cases that are easy to work out by hand.
    assert candidate(7, 7) == -1
    assert candidate(546, 546) == 546



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
