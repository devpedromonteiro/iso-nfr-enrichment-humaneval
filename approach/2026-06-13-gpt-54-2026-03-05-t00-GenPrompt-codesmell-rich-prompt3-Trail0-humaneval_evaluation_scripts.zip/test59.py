
import unittest
import re
import sys
import math
import copy



def largest_prime_factor(n: int) -> int:
    """Return the largest prime factor of n. Assume n > 1 and is not a prime.

    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    remaining = n
    largest = 1

    while remaining % 2 == 0:
        largest = 2
        remaining //= 2

    factor = 3
    while factor * factor <= remaining:
        while remaining % factor == 0:
            largest = factor
            remaining //= factor
        factor += 2

    return remaining if remaining > 1 else largest
candidate = largest_prime_factor




METADATA = {}


def check(candidate):
    assert candidate(15) == 5
    assert candidate(27) == 3
    assert candidate(63) == 7
    assert candidate(330) == 11
    assert candidate(13195) == 29



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
