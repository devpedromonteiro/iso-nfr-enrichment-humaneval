
import unittest
import re
import sys
import math
import copy


import operator as op


def _validate_inputs(operators, operands):
    if not isinstance(operators, list) or not isinstance(operands, list):
        raise TypeError("operators and operands must be lists")

    if len(operators) < 1:
        raise ValueError("operators must contain at least one operator")

    if len(operands) < 2:
        raise ValueError("operands must contain at least two values")

    if len(operators) != len(operands) - 1:
        raise ValueError("operators length must be equal to operands length minus one")


def _build_tokens(operators, operands):
    tokens = [operands[0]]
    for current_operator, current_operand in zip(operators, operands[1:]):
        tokens.append(current_operator)
        tokens.append(current_operand)
    return tokens


def _apply_operations(tokens, supported_operations):
    values = [tokens[0]]
    index = 1

    while index < len(tokens):
        current_operator = tokens[index]
        current_operand = tokens[index + 1]

        if current_operator not in supported_operations:
            raise ValueError(f"Unsupported operator: {current_operator}")

        operation_function = supported_operations[current_operator]
        values[-1] = operation_function(values[-1], current_operand)
        index += 2

    return values[0]


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and
    the second list is a list of integers. Use the two given lists to build the algebric
    expression and return the evaluation of this expression.

    The basic algebra operations:
    Addition ( + )
    Subtraction ( - )
    Multiplication ( * )
    Floor division ( // )
    Exponentiation ( ** )

    Example:
    operator['+', '*', '-']
    array = [2, 3, 4, 5]
    result = 2 + 3 * 4 - 5
    => result = 9

    Note:
        The length of operator list is equal to the length of operand list minus one.
        Operand is a list of of non-negative integers.
        Operator list has at least one operator, and operand list has at least two operands.
    """
    _validate_inputs(operator, operand)

    supported_operations = {
        "+": op.add,
        "-": op.sub,
        "*": op.mul,
        "//": op.floordiv,
        "**": op.pow,
    }

    tokens = _build_tokens(operator, operand)
    expression = "".join(str(token) for token in tokens)
    return eval(expression)
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
