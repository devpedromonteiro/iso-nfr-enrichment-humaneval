
import unittest
import re
import sys
import math
import copy


def _unique_char_count(word):
    """Return the number of unique characters in a word."""
    return len(set(word))


def _is_better_candidate(candidate, current_best):
    """Return True if candidate should replace current_best."""
    if current_best is None:
        return True

    candidate_score = _unique_char_count(candidate)
    best_score = _unique_char_count(current_best)

    if candidate_score > best_score:
        return True

    if candidate_score == best_score and candidate < current_best:
        return True

    return False


def find_max(words):
    """Return the word with the highest number of unique characters.

    If multiple words have the same maximum number of unique characters,
    return the lexicographically smallest one.
    """
    best_word = None

    for word in words:
        if _is_better_candidate(word, best_word):
            best_word = word

    return best_word if best_word is not None else ""
candidate = find_max


def check(candidate):

    # Check some simple cases
    assert (candidate(["name", "of", "string"]) == "string"), "t1"
    assert (candidate(["name", "enam", "game"]) == "enam"), 't2'
    assert (candidate(["aaaaaaa", "bb", "cc"]) == "aaaaaaa"), 't3'
    assert (candidate(["abc", "cba"]) == "abc"), 't4'
    assert (candidate(["play", "this", "game", "of","footbott"]) == "footbott"), 't5'
    assert (candidate(["we", "are", "gonna", "rock"]) == "gonna"), 't6'
    assert (candidate(["we", "are", "a", "mad", "nation"]) == "nation"), 't7'
    assert (candidate(["this", "is", "a", "prrk"]) == "this"), 't8'

    # Check some edge cases that are easy to work out by hand.
    assert (candidate(["b"]) == "b"), 't9'
    assert (candidate(["play", "play", "play"]) == "play"), 't10'



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
