
import unittest
import re
import sys
import math
import copy



def _update_balance(balance: int, bracket: str) -> int:
    """Return the updated balance for a single bracket."""
    if bracket == "(":
        return balance + 1
    return balance - 1


def _is_invalid_balance(balance: int) -> bool:
    """A negative balance means a closing bracket appeared too early."""
    return balance < 0


def correct_bracketing(brackets: str) -> bool:
    """brackets is a string of "(" and ")".
    Return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("(")
    False
    >>> correct_bracketing("()")
    True
    >>> correct_bracketing("(()())")
    True
    >>> correct_bracketing(")(()")
    False
    """
    balance = 0

    for bracket in brackets:
        balance = _update_balance(balance, bracket)
        if _is_invalid_balance(balance):
            return False

    return balance == 0
candidate = correct_bracketing




METADATA = {}


def check(candidate):
    assert candidate("()")
    assert candidate("(()())")
    assert candidate("()()(()())()")
    assert candidate("()()((()()())())(()()(()))")
    assert not candidate("((()())))")
    assert not candidate(")(()")
    assert not candidate("(")
    assert not candidate("((((")
    assert not candidate(")")
    assert not candidate("(()")
    assert not candidate("()()(()())())(()")
    assert not candidate("()()(()())()))()")



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
