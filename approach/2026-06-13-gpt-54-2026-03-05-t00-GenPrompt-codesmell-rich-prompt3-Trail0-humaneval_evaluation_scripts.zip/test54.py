
import unittest
import re
import sys
import math
import copy



from collections.abc import Iterable


def _unique_chars(text: str) -> set[str]:
    """Return the set of distinct characters in a string."""
    return set(text)


def _validate_string(value: str, name: str) -> None:
    """Validate that the provided value is a string."""
    if not isinstance(value, str):
        raise TypeError(f"{name} must be a string")


def same_chars(s0: str, s1: str) -> bool:
    """
    Check if two words have the same characters.

    >>> same_chars('eabcdzzzz', 'dddzzzzzzzddeddabc')
    True
    >>> same_chars('abcd', 'dddddddabc')
    True
    >>> same_chars('dddddddabc', 'abcd')
    True
    >>> same_chars('eabcd', 'dddddddabc')
    False
    >>> same_chars('abcd', 'dddddddabce')
    False
    >>> same_chars('eabcdzzzz', 'dddzzzzzzzddddabc')
    False
    """
    _validate_string(s0, "s0")
    _validate_string(s1, "s1")
    return _unique_chars(s0) == _unique_chars(s1)
candidate = same_chars




METADATA = {}


def check(candidate):
    assert candidate('eabcdzzzz', 'dddzzzzzzzddeddabc') == True
    assert candidate('abcd', 'dddddddabc') == True
    assert candidate('dddddddabc', 'abcd') == True
    assert candidate('eabcd', 'dddddddabc') == False
    assert candidate('abcd', 'dddddddabcf') == False
    assert candidate('eabcdzzzz', 'dddzzzzzzzddddabc') == False
    assert candidate('aabb', 'aaccc') == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
