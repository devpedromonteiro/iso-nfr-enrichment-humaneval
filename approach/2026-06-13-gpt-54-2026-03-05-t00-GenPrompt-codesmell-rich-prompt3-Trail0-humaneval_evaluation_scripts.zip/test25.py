
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def _extract_factor(value: int, factor: int, factors: List[int]) -> int:
    """Divide out `factor` from `value` as many times as possible."""
    while value % factor == 0:
        factors.append(factor)
        value //= factor
    return value


def _validate_input(n: int) -> None:
    """Validate that the input can be factorized into prime factors."""
    if n < 2:
        raise ValueError("n must be greater than or equal to 2")


def factorize(n: int) -> List[int]:
    """Return prime factors of `n` from smallest to largest.

    Each factor appears as many times as it occurs in the prime factorization.

    >>> factorize(8)
    [2, 2, 2]
    >>> factorize(25)
    [5, 5]
    >>> factorize(70)
    [2, 5, 7]
    """
    _validate_input(n)

    factors: List[int] = []
    remainder = n

    remainder = _extract_factor(remainder, 2, factors)

    divisor = 3
    while divisor * divisor <= remainder:
        remainder = _extract_factor(remainder, divisor, factors)
        divisor += 2

    if remainder > 1:
        factors.append(remainder)

    return factors
candidate = factorize




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(2) == [2]
    assert candidate(4) == [2, 2]
    assert candidate(8) == [2, 2, 2]
    assert candidate(3 * 19) == [3, 19]
    assert candidate(3 * 19 * 3 * 19) == [3, 3, 19, 19]
    assert candidate(3 * 19 * 3 * 19 * 3 * 19) == [3, 3, 3, 19, 19, 19]
    assert candidate(3 * 19 * 19 * 19) == [3, 19, 19, 19]
    assert candidate(3 * 2 * 3) == [2, 3, 3]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
