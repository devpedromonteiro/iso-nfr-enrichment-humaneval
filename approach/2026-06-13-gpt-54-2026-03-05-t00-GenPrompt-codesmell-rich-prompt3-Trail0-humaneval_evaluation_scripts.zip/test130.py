
import unittest
import re
import sys
import math
import copy


def _tri_value(index):
    """Return the Tribonacci value for a single index."""
    if index == 0:
        return 1
    if index == 1:
        return 3
    if index % 2 == 0:
        return 1 + index // 2

    previous_even = _tri_value(index - 1)
    previous_odd = _tri_value(index - 2)
    next_even = _tri_value(index + 1)
    return previous_even + previous_odd + next_even


def tri(n):
    """Return the first n + 1 numbers of the Tribonacci sequence."""
    if n < 0:
        raise ValueError("n must be a non-negative integer")

    values = [0] * (n + 1)
    values[0] = 1

    if n >= 1:
        values[1] = 3

    for index in range(2, n + 1):
        if index % 2 == 0:
            values[index] = 1 + index // 2
        else:
            values[index] = values[index - 1] + values[index - 2] + (1 + (index + 1) // 2)

    return values
candidate = tri


def check(candidate):

    # Check some simple cases
    
    assert candidate(3) == [1, 3, 2.0, 8.0]
    assert candidate(4) == [1, 3, 2.0, 8.0, 3.0]
    assert candidate(5) == [1, 3, 2.0, 8.0, 3.0, 15.0]
    assert candidate(6) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0]
    assert candidate(7) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0]
    assert candidate(8) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0]
    assert candidate(9) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0]
    assert candidate(20) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0, 6.0, 48.0, 7.0, 63.0, 8.0, 80.0, 9.0, 99.0, 10.0, 120.0, 11.0]

    # Check some edge cases that are easy to work out by hand.
    assert candidate(0) == [1]
    assert candidate(1) == [1, 3]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
