
import unittest
import re
import sys
import math
import copy


def file_name_check(file_name):
    """Return 'Yes' if file_name is valid, otherwise 'No'."""

    if not _has_single_dot(file_name):
        return "No"

    name_part, extension = _split_file_name(file_name)

    if not _has_valid_name_part(name_part):
        return "No"

    if not _has_valid_extension(extension):
        return "No"

    if _count_digits(file_name) > 3:
        return "No"

    return "Yes"


def _has_single_dot(file_name):
    return file_name.count(".") == 1


def _split_file_name(file_name):
    return file_name.split(".", 1)


def _has_valid_name_part(name_part):
    return bool(name_part) and name_part[0].isalpha() and _is_latin_letter(name_part[0])


def _is_latin_letter(char):
    return ("a" <= char <= "z") or ("A" <= char <= "Z")


def _has_valid_extension(extension):
    return extension in {"txt", "exe", "dll"}


def _count_digits(text):
    return sum(char.isdigit() for char in text)
candidate = file_name_check


def check(candidate):

    # Check some simple cases
    assert candidate("example.txt") == 'Yes'
    assert candidate("1example.dll") == 'No'
    assert candidate('s1sdf3.asd') == 'No'
    assert candidate('K.dll') == 'Yes'
    assert candidate('MY16FILE3.exe') == 'Yes'
    assert candidate('His12FILE94.exe') == 'No'
    assert candidate('_Y.txt') == 'No'
    assert candidate('?aREYA.exe') == 'No'
    assert candidate('/this_is_valid.dll') == 'No'
    assert candidate('this_is_valid.wow') == 'No'
    assert candidate('this_is_valid.txt') == 'Yes'
    assert candidate('this_is_valid.txtexe') == 'No'
    assert candidate('#this2_i4s_5valid.ten') == 'No'
    assert candidate('@this1_is6_valid.exe') == 'No'
    assert candidate('this_is_12valid.6exe4.txt') == 'No'
    assert candidate('all.exe.txt') == 'No'
    assert candidate('I563_No.exe') == 'Yes'
    assert candidate('Is3youfault.txt') == 'Yes'
    assert candidate('no_one#knows.dll') == 'Yes'
    assert candidate('1I563_Yes3.exe') == 'No'
    assert candidate('I563_Yes3.txtt') == 'No'
    assert candidate('final..txt') == 'No'
    assert candidate('final132') == 'No'
    assert candidate('_f4indsartal132.') == 'No'
    
        

    # Check some edge cases that are easy to work out by hand.
    assert candidate('.txt') == 'No'
    assert candidate('s.') == 'No'



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
