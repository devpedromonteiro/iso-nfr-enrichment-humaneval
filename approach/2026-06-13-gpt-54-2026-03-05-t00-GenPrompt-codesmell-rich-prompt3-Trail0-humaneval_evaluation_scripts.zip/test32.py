
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math
from typing import Sequence


def poly(coefficients: Sequence[float], x: float) -> float:
    """
    Evaluate a polynomial with coefficients at point x.

    coefficients[i] corresponds to the coefficient for x**i.
    """
    return sum(coeff * math.pow(x, power) for power, coeff in enumerate(coefficients))


def _validate_coefficients(coefficients: Sequence[float]) -> None:
    """
    Validate the constraints required by find_zero.
    """
    if not coefficients:
        raise ValueError("coefficients must not be empty")

    if len(coefficients) % 2 != 0:
        raise ValueError("find_zero requires an even number of coefficients")

    if coefficients[-1] == 0:
        raise ValueError("largest coefficient must be non-zero")


def _bisect_root(coefficients: Sequence[float], left: float, right: float, tolerance: float) -> float:
    """
    Find a root in [left, right] using the bisection method.
    Assumes the polynomial changes sign over the interval.
    """
    left_value = poly(coefficients, left)
    right_value = poly(coefficients, right)

    while right - left > tolerance:
        midpoint = (left + right) / 2
        midpoint_value = poly(coefficients, midpoint)

        if midpoint_value == 0:
            return midpoint

        if left_value * midpoint_value <= 0:
            right = midpoint
            right_value = midpoint_value
        else:
            left = midpoint
            left_value = midpoint_value

    return (left + right) / 2


def _find_bracketing_interval(coefficients: Sequence[float], start: float = 1.0) -> tuple[float, float]:
    """
    Find an interval [left, right] where the polynomial changes sign.
    """
    bound = start
    while True:
        left = -bound
        right = bound
        left_value = poly(coefficients, left)
        right_value = poly(coefficients, right)

        if left_value == 0:
            return left, left
        if right_value == 0:
            return right, right
        if left_value * right_value < 0:
            return left, right

        bound *= 2


def find_zero(coefficients: Sequence[float]) -> float:
    """coefficients are coefficients of a polynomial.

    find_zero finds x such that poly(coefficients, x) == 0.
    It returns one zero point, even if there are many.

    This function only accepts coefficient lists having an even number
    of coefficients and a non-zero highest-degree coefficient.

    >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2)  # (x - 1) * (x - 2) * (x - 3)
    1.0
    """
    _validate_coefficients(coefficients)

    left, right = _find_bracketing_interval(coefficients)
    if left == right:
        return left

    return _bisect_root(coefficients, left, right, tolerance=1e-12)
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
