
import unittest
import re
import sys
import math
import copy



def _validate_inputs(n: int, p: int) -> None:
    """Validate arguments for modular exponentiation."""
    if not isinstance(n, int) or not isinstance(p, int):
        raise TypeError("n and p must be integers")
    if n < 0:
        raise ValueError("n must be non-negative")
    if p <= 0:
        raise ValueError("p must be positive")


def _pow2_mod(n: int, p: int) -> int:
    """Compute 2^n mod p using fast modular exponentiation."""
    result = 1 % p
    base = 2 % p
    exponent = n

    while exponent > 0:
        if exponent & 1:
            result = (result * base) % p
        base = (base * base) % p
        exponent >>= 1

    return result


def modp(n: int, p: int):
    """Return 2^n modulo p (be aware of numerics).
    >>> modp(3, 5)
    3
    >>> modp(1101, 101)
    2
    >>> modp(0, 101)
    1
    >>> modp(3, 11)
    8
    >>> modp(100, 101)
    1
    """
    _validate_inputs(n, p)
    return _pow2_mod(n, p)
candidate = modp




METADATA = {}


def check(candidate):
    assert candidate(3, 5) == 3
    assert candidate(1101, 101) == 2
    assert candidate(0, 101) == 1
    assert candidate(3, 11) == 8
    assert candidate(100, 101) == 1
    assert candidate(30, 5) == 4
    assert candidate(31, 5) == 3



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
