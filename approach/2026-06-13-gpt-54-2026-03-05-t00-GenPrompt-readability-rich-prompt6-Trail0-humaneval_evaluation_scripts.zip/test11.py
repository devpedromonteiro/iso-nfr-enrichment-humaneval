
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def string_xor(left_bits: str, right_bits: str) -> str:
    """Return the bitwise XOR of two equal-length binary strings.

    Inputs must contain only '0' and '1' characters.

    >>> string_xor('010', '110')
    '100'
    """
    xor_result = []

    for left_bit, right_bit in zip(left_bits, right_bits):
        bits_are_different = left_bit != right_bit
        xor_result.append("1" if bits_are_different else "0")

    return "".join(xor_result)
candidate = string_xor




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('111000', '101010') == '010010'
    assert candidate('1', '1') == '0'
    assert candidate('0101', '0000') == '0101'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
