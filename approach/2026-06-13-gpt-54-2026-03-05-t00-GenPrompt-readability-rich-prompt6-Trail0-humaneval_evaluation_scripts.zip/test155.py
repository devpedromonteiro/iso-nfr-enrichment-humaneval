
import unittest
import re
import sys
import math
import copy


def even_odd_count(number):
    """Return a tuple with the count of even and odd digits in an integer.

    Examples:
        even_odd_count(-12) -> (1, 1)
        even_odd_count(123) -> (1, 2)
    """
    digit_text = str(abs(number))
    even_digit_count = 0
    odd_digit_count = 0

    for digit_character in digit_text:
        digit = int(digit_character)

        if digit % 2 == 0:
            even_digit_count += 1
        else:
            odd_digit_count += 1

    return even_digit_count, odd_digit_count
candidate = even_odd_count


def check(candidate):

    # Check some simple cases
    assert candidate(7) == (0, 1)
    assert candidate(-78) == (1, 1)
    assert candidate(3452) == (2, 2)
    assert candidate(346211) == (3, 3)
    assert candidate(-345821) == (3, 3)
    assert candidate(-2) == (1, 0)
    assert candidate(-45347) == (2, 3)
    assert candidate(0) == (1, 0)


    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
