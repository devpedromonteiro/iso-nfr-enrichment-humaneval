
import unittest
import re
import sys
import math
import copy


def can_arrange(numbers):
    """
    Return the largest index where the current element is smaller than
    the element immediately before it.

    If the list is already in strictly increasing order, return -1.

    Examples:
        can_arrange([1, 2, 4, 3, 5]) -> 3
        can_arrange([1, 2, 3]) -> -1
    """
    last_out_of_order_index = -1

    for current_index in range(1, len(numbers)):
        previous_number = numbers[current_index - 1]
        current_number = numbers[current_index]

        if current_number < previous_number:
            last_out_of_order_index = current_index

    return last_out_of_order_index
candidate = can_arrange


def check(candidate):

    # Check some simple cases
    assert candidate([1,2,4,3,5])==3
    assert candidate([1,2,4,5])==-1
    assert candidate([1,4,2,5,6,7,8,9,10])==2
    assert candidate([4,8,5,7,3])==4

    # Check some edge cases that are easy to work out by hand.
    assert candidate([])==-1



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
