
import unittest
import re
import sys
import math
import copy


def is_prime(number):
    """Return True if number is a prime, otherwise False."""
    if number < 2:
        return False

    for divisor in range(2, int(number ** 0.5) + 1):
        if number % divisor == 0:
            return False

    return True


def is_multiply_prime(number):
    """Return True if number is the product of exactly three prime numbers."""
    for first_prime in range(2, number + 1):
        if not is_prime(first_prime):
            continue

        for second_prime in range(2, number + 1):
            if not is_prime(second_prime):
                continue

            product_of_first_two = first_prime * second_prime
            if product_of_first_two > number:
                break

            if number % product_of_first_two != 0:
                continue

            third_prime = number // product_of_first_two
            if is_prime(third_prime):
                return True

    return False
candidate = is_multiply_prime


def check(candidate):

    assert candidate(5) == False
    assert candidate(30) == True
    assert candidate(8) == True
    assert candidate(10) == False
    assert candidate(125) == True
    assert candidate(3 * 5 * 7) == True
    assert candidate(3 * 6 * 7) == False
    assert candidate(9 * 9 * 9) == False
    assert candidate(11 * 9 * 9) == False
    assert candidate(11 * 13 * 7) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
