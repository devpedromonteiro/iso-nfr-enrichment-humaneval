
import unittest
import re
import sys
import math
import copy



def modp(exponent: int, modulus: int) -> int:
    """Return 2^exponent modulo modulus.

    Uses modular exponentiation to avoid creating very large intermediate values.

    >>> modp(3, 5)
    3
    >>> modp(1101, 101)
    2
    >>> modp(0, 101)
    1
    >>> modp(3, 11)
    8
    >>> modp(100, 101)
    1
    """
    result = 1
    current_power = 2 % modulus
    remaining_exponent = exponent

    while remaining_exponent > 0:
        if remaining_exponent % 2 == 1:
            result = (result * current_power) % modulus

        current_power = (current_power * current_power) % modulus
        remaining_exponent //= 2

    return result
candidate = modp




METADATA = {}


def check(candidate):
    assert candidate(3, 5) == 3
    assert candidate(1101, 101) == 2
    assert candidate(0, 101) == 1
    assert candidate(3, 11) == 8
    assert candidate(100, 101) == 1
    assert candidate(30, 5) == 4
    assert candidate(31, 5) == 3



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
