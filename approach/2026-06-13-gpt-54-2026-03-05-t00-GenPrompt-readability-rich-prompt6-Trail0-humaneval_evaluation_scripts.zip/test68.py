
import unittest
import re
import sys
import math
import copy


def pluck(branch_nodes):
    """
    Return [smallest_even_value, index] for the smallest even number in the list.

    If multiple nodes have the same smallest even value, return the one with
    the smallest index. If there are no even values, return [].
    """
    smallest_even_value = None
    smallest_even_index = None

    for index, node_value in enumerate(branch_nodes):
        is_even = node_value % 2 == 0

        if not is_even:
            continue

        if smallest_even_value is None or node_value < smallest_even_value:
            smallest_even_value = node_value
            smallest_even_index = index

    if smallest_even_value is None:
        return []

    return [smallest_even_value, smallest_even_index]
candidate = pluck


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([4,2,3]) == [2, 1], "Error"
    assert candidate([1,2,3]) == [2, 1], "Error"
    assert candidate([]) == [], "Error"
    assert candidate([5, 0, 3, 0, 4, 2]) == [0, 1], "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([1, 2, 3, 0, 5, 3]) == [0, 3], "Error"
    assert candidate([5, 4, 8, 4 ,8]) == [4, 1], "Error"
    assert candidate([7, 6, 7, 1]) == [6, 1], "Error"
    assert candidate([7, 9, 7, 1]) == [], "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
