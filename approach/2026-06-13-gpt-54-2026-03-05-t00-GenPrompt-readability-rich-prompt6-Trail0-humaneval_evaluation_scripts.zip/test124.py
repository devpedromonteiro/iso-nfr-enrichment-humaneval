
import unittest
import re
import sys
import math
import copy


def valid_date(date_string):
    """Return True if date_string is a valid date in mm-dd-yyyy format."""

    if not date_string:
        return False

    parts = date_string.split("-")
    if len(parts) != 3:
        return False

    month_text, day_text, year_text = parts

    if len(month_text) != 2 or len(day_text) != 2 or len(year_text) != 4:
        return False

    if not (month_text.isdigit() and day_text.isdigit() and year_text.isdigit()):
        return False

    month = int(month_text)
    day = int(day_text)

    if month < 1 or month > 12:
        return False

    days_in_month = {
        1: 31,
        2: 29,
        3: 31,
        4: 30,
        5: 31,
        6: 30,
        7: 31,
        8: 31,
        9: 30,
        10: 31,
        11: 30,
        12: 31,
    }

    maximum_day = days_in_month[month]
    return 1 <= day <= maximum_day
candidate = valid_date


def check(candidate):

    # Check some simple cases
    assert candidate('03-11-2000') == True

    assert candidate('15-01-2012') == False

    assert candidate('04-0-2040') == False

    assert candidate('06-04-2020') == True

    assert candidate('01-01-2007') == True

    assert candidate('03-32-2011') == False

    assert candidate('') == False

    assert candidate('04-31-3000') == False

    assert candidate('06-06-2005') == True

    assert candidate('21-31-2000') == False

    assert candidate('04-12-2003') == True

    assert candidate('04122003') == False

    assert candidate('20030412') == False

    assert candidate('2003-04') == False

    assert candidate('2003-04-12') == False

    assert candidate('04-2003') == False


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
