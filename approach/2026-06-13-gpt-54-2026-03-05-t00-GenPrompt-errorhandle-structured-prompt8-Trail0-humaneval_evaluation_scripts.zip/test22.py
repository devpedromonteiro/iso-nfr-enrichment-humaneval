
import unittest
import re
import sys
import math
import copy

from typing import List, Any


from typing import List, Any


def filter_integers(values: List[Any]) -> List[int]:
    """Filter given list of any python values only for integers.

    Rules:
    - Raises TypeError if `values` is not a list.
    - Keeps only values whose type is exactly `int` (excludes bool).

    >>> filter_integers(['a', 3.14, 5])
    [5]
    >>> filter_integers([1, 2, 3, 'abc', {}, []])
    [1, 2, 3]
    >>> filter_integers([True, False, 1, 2])
    [1, 2]
    """
    if not isinstance(values, list):
        raise TypeError(
            f"values must be of type list, got {type(values).__name__}"
        )

    try:
        return [value for value in values if type(value) is int]
    except TypeError as exc:
        # Defensive handling in case iteration fails unexpectedly.
        raise TypeError("values must be an iterable list of items") from exc
candidate = filter_integers




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == []
    assert candidate([4, {}, [], 23.2, 9, 'adasd']) == [4, 9]
    assert candidate([3, 'c', 3, 3, 'a', 'b']) == [3, 3, 3]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
