
import unittest
import re
import sys
import math
import copy



import math
from numbers import Real


def sum_squares(lst):
    """Return the sum of squares after applying math.ceil to each element.

    Args:
        lst: An iterable of real numbers.

    Returns:
        int: Sum of squared ceiling-transformed values.

    Raises:
        TypeError: If lst is None, not iterable, or contains non-numeric values.
        ValueError: If any element is NaN or infinite.
    """
    if lst is None:
        raise TypeError("lst must not be None")

    try:
        iterator = iter(lst)
    except TypeError as exc:
        raise TypeError("lst must be an iterable of real numbers") from exc

    total = 0
    for index, value in enumerate(iterator):
        if not isinstance(value, Real):
            raise TypeError(
                f"lst[{index}] must be a real number, got {type(value).__name__}"
            )
        if not math.isfinite(value):
            raise ValueError(f"lst[{index}] must be finite, got {value!r}")

        rounded = math.ceil(value)
        total += rounded ** 2

    return total
candidate = sum_squares


def check(candidate):

    # Check some simple cases
    assert candidate([1,2,3])==14, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1.0,2,3])==14, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,3,5,7])==84, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1.4,4.2,0])==29, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([-2.4,1,1])==6, "This prints if this assert fails 1 (good for debugging!)"

    assert candidate([100,1,15,2])==10230, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([10000,10000])==200000000, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([-1.4,4.6,6.3])==75, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([-1.4,17.9,18.9,19.9])==1086, "This prints if this assert fails 1 (good for debugging!)"


    # Check some edge cases that are easy to work out by hand.
    assert candidate([0])==0, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([-1])==1, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([-1,1,0])==2, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
