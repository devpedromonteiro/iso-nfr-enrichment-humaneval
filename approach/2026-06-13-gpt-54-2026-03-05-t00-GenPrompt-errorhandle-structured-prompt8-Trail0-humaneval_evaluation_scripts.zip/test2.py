
import unittest
import re
import sys
import math
import copy



import math


def truncate_number(number: float) -> float:
    """Return the decimal part of a positive floating point number.

    The decimal part is defined as:
        number - floor(number)

    Args:
        number: A positive finite float or int.

    Returns:
        The decimal part of the number.

    Raises:
        TypeError: If number is not a real numeric value.
        ValueError: If number is negative, NaN, or infinite.

    >>> truncate_number(3.5)
    0.5
    >>> truncate_number(7.0)
    0.0
    """
    if not isinstance(number, (int, float)):
        raise TypeError("number must be a real numeric value")

    if math.isnan(number) or math.isinf(number):
        raise ValueError("number must be a finite value")

    if number < 0:
        raise ValueError("number must be positive")

    return number - math.floor(number)
candidate = truncate_number




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(3.5) == 0.5
    assert abs(candidate(1.33) - 0.33) < 1e-6
    assert abs(candidate(123.456) - 0.456) < 1e-6


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
