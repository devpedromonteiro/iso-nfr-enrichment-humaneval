
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """Input to this function is a string representing multiple groups of
    nested parentheses separated by spaces.

    For each group, output the deepest level of nesting of parentheses.
    E.g. (()()) has maximum two levels of nesting while ((())) has three.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """
    if not isinstance(paren_string, str):
        raise TypeError("paren_string must be a string")

    if paren_string == "":
        return []

    groups = paren_string.split()
    result: List[int] = []

    for group in groups:
        depth = 0
        max_depth = 0

        for char in group:
            if char == "(":
                depth += 1
                if depth > max_depth:
                    max_depth = depth
            elif char == ")":
                depth -= 1
                if depth < 0:
                    raise ValueError(f"unbalanced parentheses in group: {group!r}")
            else:
                raise ValueError(
                    f"invalid character {char!r} in group {group!r}; only '(' and ')' are allowed"
                )

        if depth != 0:
            raise ValueError(f"unbalanced parentheses in group: {group!r}")

        result.append(max_depth)

    return result
candidate = parse_nested_parens




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('(()()) ((())) () ((())()())') == [2, 3, 1, 3]
    assert candidate('() (()) ((())) (((())))') == [1, 2, 3, 4]
    assert candidate('(()(())((())))') == [4]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
