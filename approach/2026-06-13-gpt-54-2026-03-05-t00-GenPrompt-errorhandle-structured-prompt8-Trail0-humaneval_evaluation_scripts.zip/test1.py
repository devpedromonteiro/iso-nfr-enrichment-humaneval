
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def separate_paren_groups(paren_string: str) -> List[str]:
    """Input to this function is a string containing multiple groups of nested parentheses.
    Your goal is to separate those groups into separate strings and return them as a list.

    Separate groups are balanced (each open parenthesis is properly closed) and not nested
    within each other. Ignore any spaces in the input string.

    >>> separate_paren_groups('( ) (( )) (( )( ))')
    ['()', '(())', '(()())']
    """
    if not isinstance(paren_string, str):
        raise TypeError("paren_string must be a string")

    groups: List[str] = []
    current_group: List[str] = []
    depth = 0

    for char in paren_string:
        if char == " ":
            continue
        if char not in ("(", ")"):
            raise ValueError(f"invalid character in input: {char!r}")

        if char == "(":
            depth += 1
            current_group.append(char)
        else:  # char == ")"
            if depth == 0:
                raise ValueError("unbalanced parentheses: unexpected closing parenthesis")
            current_group.append(char)
            depth -= 1

            if depth == 0:
                groups.append("".join(current_group))
                current_group = []

    if depth != 0:
        raise ValueError("unbalanced parentheses: missing closing parenthesis")

    return groups
candidate = separate_paren_groups




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('(()()) ((())) () ((())()())') == [
        '(()())', '((()))', '()', '((())()())'
    ]
    assert candidate('() (()) ((())) (((())))') == [
        '()', '(())', '((()))', '(((())))'
    ]
    assert candidate('(()(())((())))') == [
        '(()(())((())))'
    ]
    assert candidate('( ) (( )) (( )( ))') == ['()', '(())', '(()())']


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
