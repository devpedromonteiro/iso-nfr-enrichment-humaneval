
import unittest
import re
import sys
import math
import copy


def rounded_avg(n, m):
    """Compute the rounded average of all integers from n to m inclusive,
    then return that rounded value as a binary string.

    Rules:
    - n and m must be positive integers
    - if n > m, return -1
    - invalid inputs raise specific exceptions
    """
    if not isinstance(n, int) or not isinstance(m, int):
        raise TypeError("n and m must both be integers")

    if n <= 0 or m <= 0:
        raise ValueError("n and m must both be positive integers")

    if n > m:
        return -1

    total = (n + m) * (m - n + 1) / 2
    count = m - n + 1
    avg = round(total / count)

    return bin(avg)
candidate = rounded_avg


def check(candidate):

    # Check some simple cases
    assert candidate(1, 5) == "0b11"
    assert candidate(7, 13) == "0b1010"
    assert candidate(964,977) == "0b1111001010"
    assert candidate(996,997) == "0b1111100100"
    assert candidate(560,851) == "0b1011000010"
    assert candidate(185,546) == "0b101101110"
    assert candidate(362,496) == "0b110101101"
    assert candidate(350,902) == "0b1001110010"
    assert candidate(197,233) == "0b11010111"


    # Check some edge cases that are easy to work out by hand.
    assert candidate(7, 5) == -1
    assert candidate(5, 1) == -1
    assert candidate(5, 5) == "0b101"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
