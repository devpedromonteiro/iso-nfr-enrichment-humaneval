
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def remove_duplicates(numbers: List[int]) -> List[int]:
    """From a list of integers, remove all elements that occur more than once.
    Keep order of elements left the same as in the input.

    >>> remove_duplicates([1, 2, 3, 2, 4])
    [1, 3, 4]
    """
    if numbers is None:
        raise TypeError("numbers must be a list of integers, got None")

    if not isinstance(numbers, list):
        raise TypeError(f"numbers must be of type list, got {type(numbers).__name__}")

    for i, value in enumerate(numbers):
        if not isinstance(value, int):
            raise TypeError(
                f"all elements in numbers must be integers; "
                f"found {type(value).__name__} at index {i}"
            )

    counts = {}
    for number in numbers:
        counts[number] = counts.get(number, 0) + 1

    result = []
    for number in numbers:
        if counts[number] == 1:
            result.append(number)

    return result
candidate = remove_duplicates




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == []
    assert candidate([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert candidate([1, 2, 3, 2, 4, 3, 5]) == [1, 4, 5]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
