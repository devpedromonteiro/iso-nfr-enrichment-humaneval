
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    You are given a positive integer n. You have to create an integer array a of length n.
    For each i (1 â¤ i â¤ n), the value of a[i] = i * i - i + 1.
    Return the number of triples (a[i], a[j], a[k]) where i < j < k and
    a[i] + a[j] + a[k] is a multiple of 3.

    Example:
        Input: n = 5
        Output: 1
    """
    # Input validation: explicit and specific exceptions
    if isinstance(n, bool):
        raise TypeError("n must be a positive integer, not bool")
    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if n <= 0:
        raise ValueError("n must be a positive integer")

    try:
        # Since a[i] = i^2 - i + 1 = i(i-1) + 1
        # and i(i-1) is always divisible by 2, but we care mod 3:
        # Check pattern modulo 3:
        # i % 3 == 0 -> a[i] % 3 == 1
        # i % 3 == 1 -> a[i] % 3 == 1
        # i % 3 == 2 -> a[i] % 3 == 0
        #
        # So values fall into:
        # residue 1: indices i % 3 in {0, 1}
        # residue 0: indices i % 3 == 2
        #
        # For sum of three numbers to be divisible by 3, possible residue combos:
        # (0,0,0) or (1,1,1)

        count_mod_0 = n // 3
        count_mod_1 = n - count_mod_0

        def comb3(x):
            return x * (x - 1) * (x - 2) // 6 if x >= 3 else 0

        return comb3(count_mod_0) + comb3(count_mod_1)

    except OverflowError:
        # Explicitly re-raise specific exception to avoid silent failure
        raise OverflowError("integer computation overflowed while calculating triples")
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
