
import unittest
import re
import sys
import math
import copy



def fibfib(n: int):
    """Compute the n-th FibFib number.

    The FibFib sequence is defined as:
    - fibfib(0) = 0
    - fibfib(1) = 0
    - fibfib(2) = 1
    - fibfib(n) = fibfib(n-1) + fibfib(n-2) + fibfib(n-3) for n >= 3

    Args:
        n: Zero-based index into the FibFib sequence.

    Returns:
        The n-th FibFib number.

    Raises:
        TypeError: If n is not an integer.
        ValueError: If n is negative.

    >>> fibfib(1)
    0
    >>> fibfib(5)
    4
    >>> fibfib(8)
    24
    """
    if not isinstance(n, int):
        raise TypeError(f"n must be an integer, got {type(n).__name__}")
    if n < 0:
        raise ValueError("n must be non-negative")

    if n == 0:
        return 0
    if n == 1:
        return 0
    if n == 2:
        return 1

    a, b, c = 0, 0, 1
    for _ in range(3, n + 1):
        a, b, c = b, c, a + b + c

    return c
candidate = fibfib




METADATA = {}


def check(candidate):
    assert candidate(2) == 1
    assert candidate(1) == 0
    assert candidate(5) == 4
    assert candidate(8) == 24
    assert candidate(10) == 81
    assert candidate(12) == 274
    assert candidate(14) == 927



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
