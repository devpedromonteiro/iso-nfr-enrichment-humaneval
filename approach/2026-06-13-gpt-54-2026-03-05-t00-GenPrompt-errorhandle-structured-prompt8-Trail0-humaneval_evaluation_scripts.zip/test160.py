
import unittest
import re
import sys
import math
import copy


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and
    the second list is a list of integers. Use the two given lists to build the algebraic
    expression and return the evaluation of this expression.

    Supported operators:
    +, -, *, //, **

    Example:
    operator = ['+', '*', '-']
    operand = [2, 3, 4, 5]
    result = 2 + 3 * 4 - 5
    => 9
    """
    supported_operators = {"+", "-", "*", "//", "**"}

    # Validate container types
    if not isinstance(operator, list):
        raise TypeError("operator must be a list")
    if not isinstance(operand, list):
        raise TypeError("operand must be a list")

    # Validate lengths
    if len(operator) < 1:
        raise ValueError("operator list must contain at least one operator")
    if len(operand) < 2:
        raise ValueError("operand list must contain at least two operands")
    if len(operator) != len(operand) - 1:
        raise ValueError("length of operator must be equal to length of operand minus one")

    # Validate operators
    for op in operator:
        if not isinstance(op, str):
            raise TypeError("each operator must be a string")
        if op not in supported_operators:
            raise ValueError(f"unsupported operator: {op}")

    # Validate operands
    for value in operand:
        if not isinstance(value, int):
            raise TypeError("each operand must be an integer")
        if value < 0:
            raise ValueError("operands must be non-negative integers")

    # Build expression safely after validation
    expression_parts = [str(operand[0])]
    for op, value in zip(operator, operand[1:]):
        expression_parts.append(op)
        expression_parts.append(str(value))
    expression = " ".join(expression_parts)

    try:
        return eval(expression)
    except ZeroDivisionError:
        # Explicitly propagate specific arithmetic failure
        raise
    except OverflowError:
        raise
    except Exception as exc:
        # Preserve failure details and avoid silent swallowing
        raise RuntimeError(f"failed to evaluate expression: {expression}") from exc
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
