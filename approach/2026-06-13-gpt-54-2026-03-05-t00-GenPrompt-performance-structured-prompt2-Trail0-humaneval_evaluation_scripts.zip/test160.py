
import unittest
import re
import sys
import math
import copy


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and
    the second list is a list of integers. Use the two given lists to build the algebraic
    expression and return the evaluation of this expression.

    The evaluation follows normal Python operator precedence.
    """
    # First pass: resolve ** from right to left
    values = [operand[-1]]
    ops = []

    for i in range(len(operator) - 1, -1, -1):
        op = operator[i]
        left = operand[i]

        if op == '**':
            values[-1] = left ** values[-1]
        else:
            values.append(left)
            ops.append(op)

    values.reverse()
    ops.reverse()

    # Second pass: resolve * and // from left to right
    collapsed_values = [values[0]]
    collapsed_ops = []

    for i, op in enumerate(ops):
        right = values[i + 1]
        if op == '*':
            collapsed_values[-1] *= right
        elif op == '//':
            collapsed_values[-1] //= right
        else:
            collapsed_values.append(right)
            collapsed_ops.append(op)

    # Final pass: resolve + and - from left to right
    result = collapsed_values[0]
    for i, op in enumerate(collapsed_ops):
        if op == '+':
            result += collapsed_values[i + 1]
        else:  # op == '-'
            result -= collapsed_values[i + 1]

    return result
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
