
import unittest
import re
import sys
import math
import copy



def change_base(x: int, base: int):
    """Change numerical base of input number x to base.
    return string representation after the conversion.
    base numbers are less than 10.
    >>> change_base(8, 3)
    '22'
    >>> change_base(8, 2)
    '1000'
    >>> change_base(7, 2)
    '111'
    """
    if not isinstance(x, int) or not isinstance(base, int):
        raise TypeError("x and base must be integers")
    if base < 2 or base >= 10:
        raise ValueError("base must be between 2 and 9")
    if x == 0:
        return "0"

    negative = x < 0
    x = abs(x)

    digits = []
    while x:
        x, remainder = divmod(x, base)
        digits.append(chr(ord('0') + remainder))

    if negative:
        digits.append('-')

    return ''.join(reversed(digits))
candidate = change_base




METADATA = {}


def check(candidate):
    assert candidate(8, 3) == "22"
    assert candidate(9, 3) == "100"
    assert candidate(234, 2) == "11101010"
    assert candidate(16, 2) == "10000"
    assert candidate(8, 2) == "1000"
    assert candidate(7, 2) == "111"
    for x in range(2, 8):
        assert candidate(x, x + 1) == str(x)



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
