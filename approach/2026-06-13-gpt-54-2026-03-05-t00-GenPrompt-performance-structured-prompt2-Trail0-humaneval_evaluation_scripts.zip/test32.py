
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[2] * x^2 + .... xs[n] * x^n
    """
    # Horner's method: O(n) time, avoids repeated pow calls and extra allocations.
    result = 0.0
    for coeff in reversed(xs):
        result = result * x + coeff
    return result


def find_zero(xs: list):
    """ xs are coefficients of a polynomial.
    find_zero find x such that poly(x) = 0.
    find_zero returns only only zero point, even if there are many.
    Moreover, find_zero only takes list xs having even number of coefficients
    and largest non zero coefficient as it guarantees
    a solution.
    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3
    1.0
    """
    if not xs:
        raise ValueError("xs must not be empty")

    degree = len(xs) - 1
    while degree >= 0 and xs[degree] == 0:
        degree -= 1

    if degree < 1:
        raise ValueError("polynomial must have degree at least 1")

    lead = xs[degree]
    const = xs[0]

    # Fast path for linear polynomials.
    if degree == 1:
        return -const / lead

    # Cauchy bound: at least one real root exists in [-B, B] under stated assumptions.
    max_coeff = 0.0
    for i in range(degree):
        v = abs(xs[i])
        if v > max_coeff:
            max_coeff = v
    bound = 1.0 + max_coeff / abs(lead)

    left = -bound
    right = bound
    f_left = poly(xs, left)
    f_right = poly(xs, right)

    # Under the documented assumptions and odd degree, a root is bracketed here.
    if f_left == 0:
        return left
    if f_right == 0:
        return right

    # Bisection method: robust and bounded resource usage.
    for _ in range(100):
        mid = (left + right) / 2.0
        f_mid = poly(xs, mid)

        if f_mid == 0 or (right - left) <= 1e-12:
            return mid

        if f_left * f_mid <= 0:
            right = mid
            f_right = f_mid
        else:
            left = mid
            f_left = f_mid

    return (left + right) / 2.0
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
