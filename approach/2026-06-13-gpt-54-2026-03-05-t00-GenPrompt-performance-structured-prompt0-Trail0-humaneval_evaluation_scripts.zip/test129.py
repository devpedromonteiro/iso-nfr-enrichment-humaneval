
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Given a grid with N rows and N columns (N >= 2) and a positive integer k,
    each cell contains a unique value from 1 to N*N.

    Return the lexicographically smallest sequence of values obtainable by a
    path of exactly k visited cells, moving only up/down/left/right.
    """
    n = len(grid)
    if k <= 0:
        return []

    # Map each value to its position for O(1) access in value order.
    pos_of = [None] * (n * n + 1)
    for r in range(n):
        row = grid[r]
        for c in range(n):
            pos_of[row[c]] = (r, c)

    # For k == 1, the minimum path is just the globally minimum value.
    if k == 1:
        return [1]

    # Build adjacency by value, avoiding repeated boundary checks later.
    neighbors = [[] for _ in range(n * n + 1)]
    for v in range(1, n * n + 1):
        r, c = pos_of[v]
        adj = neighbors[v]
        if r > 0:
            adj.append(grid[r - 1][c])
        if r + 1 < n:
            adj.append(grid[r + 1][c])
        if c > 0:
            adj.append(grid[r][c - 1])
        if c + 1 < n:
            adj.append(grid[r][c + 1])

    # Start from the smallest possible first value.
    current = [1]
    answer = [1]

    # Repeatedly choose the smallest possible next value among all neighbors
    # of currently viable positions, then keep only positions achieving it.
    for _ in range(1, k):
        best_next = None

        # Find minimal next value.
        for v in current:
            for nv in neighbors[v]:
                if best_next is None or nv < best_next:
                    best_next = nv

        answer.append(best_next)

        # Keep all positions that can realize this minimal next value.
        next_current = []
        seen = set()
        for v in current:
            for nv in neighbors[v]:
                if nv == best_next and nv not in seen:
                    seen.add(nv)
                    next_current.append(nv)

        current = next_current

    return answer
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
