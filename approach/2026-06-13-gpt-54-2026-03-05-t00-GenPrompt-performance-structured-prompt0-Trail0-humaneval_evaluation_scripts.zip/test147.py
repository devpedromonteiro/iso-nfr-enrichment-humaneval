
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    You are given a positive integer n. You have to create an integer array a of length n.
    For each i (1 â¤ i â¤ n), the value of a[i] = i * i - i + 1.
    Return the number of triples (a[i], a[j], a[k]) of a where i < j < k,
    and a[i] + a[j] + a[k] is a multiple of 3.

    Optimized approach:
    - We do not build the array.
    - Since a[i] = i^2 - i + 1 = i(i-1) + 1, and i(i-1) is always divisible by 2,
      we only care about a[i] mod 3.
    - Checking i mod 3:
        i % 3 == 0 -> a[i] % 3 == 1
        i % 3 == 1 -> a[i] % 3 == 1
        i % 3 == 2 -> a[i] % 3 == 0
    - So values are only congruent to 0 or 1 modulo 3.
    - A triple sum is divisible by 3 only when residues are:
        (0, 0, 0) or (1, 1, 1)

    Let:
      c0 = count of indices i in [1..n] with i % 3 == 2
      c1 = n - c0

    Answer = C(c0, 3) + C(c1, 3)
    """

    def comb3(x):
        return x * (x - 1) * (x - 2) // 6 if x >= 3 else 0

    c0 = (n + 1) // 3
    c1 = n - c0

    return comb3(c0) + comb3(c1)
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
