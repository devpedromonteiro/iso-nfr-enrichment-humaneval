
import unittest
import re
import sys
import math
import copy


def by_length(arr):
    names = (
        "One", "Two", "Three", "Four", "Five",
        "Six", "Seven", "Eight", "Nine"
    )
    
    counts = [0] * 10  # indices 1..9 used
    for n in arr:
        if 1 <= n <= 9:
            counts[n] += 1

    result = []
    for n in range(9, 0, -1):
        count = counts[n]
        if count:
            result.extend([names[n - 1]] * count)

    return result
candidate = by_length


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([2, 1, 1, 4, 5, 8, 2, 3]) == ["Eight", "Five", "Four", "Three", "Two", "Two", "One", "One"], "Error"
    assert candidate([]) == [], "Error"
    assert candidate([1, -1 , 55]) == ['One'], "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([1, -1, 3, 2]) == ["Three", "Two", "One"]
    assert candidate([9, 4, 8]) == ["Nine", "Eight", "Four"]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
