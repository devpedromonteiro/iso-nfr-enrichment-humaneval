
import unittest
import re
import sys
import math
import copy


def closest_integer(value):
    s = value.strip()

    if "." not in s:
        return int(s)

    neg = s[0] == "-"
    if s[0] in "+-":
        num = s[1:]
    else:
        num = s

    whole, frac = num.split(".", 1)
    integer_part = int(whole) if whole else 0

    if not frac:
        return -integer_part if neg else integer_part

    first_frac_digit = frac[0]

    if first_frac_digit < "5":
        result = integer_part
    elif first_frac_digit > "5":
        result = integer_part + 1
    else:
        if any(ch != "0" for ch in frac[1:]):
            result = integer_part + 1
        else:
            result = integer_part + 1

    return -result if neg else result
candidate = closest_integer


def check(candidate):

    # Check some simple cases
    assert candidate("10") == 10, "Test 1"
    assert candidate("14.5") == 15, "Test 2"
    assert candidate("-15.5") == -16, "Test 3"
    assert candidate("15.3") == 15, "Test 3"

    # Check some edge cases that are easy to work out by hand.
    assert candidate("0") == 0, "Test 0"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
