
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """Input to this function is a string represented multiple groups for nested
    parentheses separated by spaces. For each group, output the deepest level of
    nesting of parentheses.

    E.g. (()()) has maximum two levels of nesting while ((())) has three.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """
    if not paren_string:
        return []

    result: List[int] = []
    current_depth = 0
    max_depth = 0
    in_group = False

    for ch in paren_string:
        if ch == '(':
            in_group = True
            current_depth += 1
            if current_depth > max_depth:
                max_depth = current_depth
        elif ch == ')':
            current_depth -= 1
        elif ch == ' ':
            if in_group:
                result.append(max_depth)
                current_depth = 0
                max_depth = 0
                in_group = False

    if in_group:
        result.append(max_depth)

    return result
candidate = parse_nested_parens




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('(()()) ((())) () ((())()())') == [2, 3, 1, 3]
    assert candidate('() (()) ((())) (((())))') == [1, 2, 3, 4]
    assert candidate('(()(())((())))') == [4]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
