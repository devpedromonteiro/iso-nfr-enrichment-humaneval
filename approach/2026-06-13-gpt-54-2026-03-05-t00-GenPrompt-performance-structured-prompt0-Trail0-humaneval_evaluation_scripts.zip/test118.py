
import unittest
import re
import sys
import math
import copy


def get_closest_vowel(word):
    """Return the rightmost vowel that is between two consonants.

    A vowel at the beginning or end does not count. Search is case-sensitive
    only in the returned character; vowel membership includes both cases.
    """
    vowels = "aeiouAEIOU"
    n = len(word)

    # Need at least 3 characters for a vowel to be between two consonants.
    if n < 3:
        return ""

    # Scan from right to left to find the closest qualifying vowel.
    for i in range(n - 2, 0, -1):
        c = word[i]
        if (
            c in vowels
            and word[i - 1] not in vowels
            and word[i + 1] not in vowels
        ):
            return c

    return ""
candidate = get_closest_vowel


def check(candidate):

    # Check some simple cases
    assert candidate("yogurt") == "u"
    assert candidate("full") == "u"
    assert candidate("easy") == ""
    assert candidate("eAsy") == ""
    assert candidate("ali") == ""
    assert candidate("bad") == "a"
    assert candidate("most") == "o"
    assert candidate("ab") == ""
    assert candidate("ba") == ""
    assert candidate("quick") == ""
    assert candidate("anime") == "i"
    assert candidate("Asia") == ""
    assert candidate("Above") == "o"

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
