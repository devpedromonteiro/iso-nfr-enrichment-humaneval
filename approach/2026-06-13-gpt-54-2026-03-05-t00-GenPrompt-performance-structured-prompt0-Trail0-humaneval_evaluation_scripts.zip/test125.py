
import unittest
import re
import sys
import math
import copy


def split_words(txt):
    """
    Given a string of words:
    - if it contains whitespace, split on whitespace
    - otherwise, if it contains commas, split on commas
    - otherwise, return the count of lowercase letters whose alphabet index is odd
      with ord('a') = 0, ..., ord('z') = 25
    """
    if any(ch.isspace() for ch in txt):
        return txt.split()

    if ',' in txt:
        return txt.split(',')

    count = 0
    for ch in txt:
        o = ord(ch)
        if 97 <= o <= 122 and ((o - 97) & 1):
            count += 1
    return count
candidate = split_words


def check(candidate):

    assert candidate("Hello world!") == ["Hello","world!"]
    assert candidate("Hello,world!") == ["Hello","world!"]
    assert candidate("Hello world,!") == ["Hello","world,!"]
    assert candidate("Hello,Hello,world !") == ["Hello,Hello,world","!"]
    assert candidate("abcdef") == 3
    assert candidate("aaabb") == 2
    assert candidate("aaaBb") == 1
    assert candidate("") == 0


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
