
import unittest
import re
import sys
import math
import copy


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and
    the second list is a list of integers. Use the two given lists to build the algebraic
    expression and return the evaluation of this expression.

    Supported operators:
    +, -, *, //, **

    The expression is evaluated using normal Python operator precedence.
    """
    values = operand[:]

    # First pass: exponentiation, right-to-left
    i = len(operator) - 1
    while i >= 0:
        if operator[i] == '**':
            values[i] = values[i] ** values[i + 1]
            del values[i + 1]
            del operator[i]
        i -= 1

    # Second pass: multiplication and floor division, left-to-right
    i = 0
    while i < len(operator):
        op = operator[i]
        if op == '*':
            values[i] = values[i] * values[i + 1]
            del values[i + 1]
            del operator[i]
        elif op == '//':
            values[i] = values[i] // values[i + 1]
            del values[i + 1]
            del operator[i]
        else:
            i += 1

    # Final pass: addition and subtraction, left-to-right
    result = values[0]
    for i, op in enumerate(operator):
        if op == '+':
            result += values[i + 1]
        else:  # op == '-'
            result -= values[i + 1]

    return result
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
