
import unittest
import re
import sys
import math
import copy



def flip_case(text: str) -> str:
    """Return a copy of the text with lowercase letters converted to uppercase
    and uppercase letters converted to lowercase.

    Non-alphabetic characters are left unchanged.

    >>> flip_case("Hello")
    'hELLO'
    >>> flip_case("Hello, World! 123")
    'hELLO, wORLD! 123'
    """
    flipped_characters = []

    for character in text:
        if character.islower():
            flipped_characters.append(character.upper())
        elif character.isupper():
            flipped_characters.append(character.lower())
        else:
            flipped_characters.append(character)

    return "".join(flipped_characters)
candidate = flip_case




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == ''
    assert candidate('Hello!') == 'hELLO!'
    assert candidate('These violent delights have violent ends') == 'tHESE VIOLENT DELIGHTS HAVE VIOLENT ENDS'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
