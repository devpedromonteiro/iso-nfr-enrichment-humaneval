
import unittest
import re
import sys
import math
import copy

from typing import List, Tuple


from typing import List, Tuple


def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    """Return the two numbers that are closest to each other.

    The returned pair is always ordered as (smaller_number, larger_number).

    Assumes:
        numbers contains at least two values.

    Examples:
        >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.2])
        (2.0, 2.2)
        >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.0])
        (2.0, 2.0)
    """
    sorted_numbers = sorted(numbers)

    closest_pair = (sorted_numbers[0], sorted_numbers[1])
    smallest_difference = sorted_numbers[1] - sorted_numbers[0]

    for index in range(1, len(sorted_numbers) - 1):
        left_number = sorted_numbers[index]
        right_number = sorted_numbers[index + 1]
        current_difference = right_number - left_number

        if current_difference < smallest_difference:
            smallest_difference = current_difference
            closest_pair = (left_number, right_number)

    return closest_pair
candidate = find_closest_elements




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([1.0, 2.0, 3.9, 4.0, 5.0, 2.2]) == (3.9, 4.0)
    assert candidate([1.0, 2.0, 5.9, 4.0, 5.0]) == (5.0, 5.9)
    assert candidate([1.0, 2.0, 3.0, 4.0, 5.0, 2.2]) == (2.0, 2.2)
    assert candidate([1.0, 2.0, 3.0, 4.0, 5.0, 2.0]) == (2.0, 2.0)
    assert candidate([1.1, 2.2, 3.1, 4.1, 5.1]) == (2.2, 3.1)



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
