
import unittest
import re
import sys
import math
import copy


def tri(n):
    """Return the first n + 1 values of the Tribonacci sequence.

    Sequence definition:
    - tri(0) = 1
    - tri(1) = 3
    - tri(k) = 1 + k / 2, when k is even and k >= 2
    - tri(k) = tri(k - 1) + tri(k - 2) + tri(k + 1), when k is odd and k >= 3

    Example:
    tri(3) -> [1, 3, 2, 8]
    """
    sequence = [1]

    if n == 0:
        return sequence

    sequence.append(3)

    for index in range(2, n + 1):
        if index % 2 == 0:
            value = 1 + index // 2
        else:
            next_even_value = 1 + (index + 1) // 2
            value = sequence[index - 1] + sequence[index - 2] + next_even_value

        sequence.append(value)

    return sequence
candidate = tri


def check(candidate):

    # Check some simple cases
    
    assert candidate(3) == [1, 3, 2.0, 8.0]
    assert candidate(4) == [1, 3, 2.0, 8.0, 3.0]
    assert candidate(5) == [1, 3, 2.0, 8.0, 3.0, 15.0]
    assert candidate(6) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0]
    assert candidate(7) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0]
    assert candidate(8) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0]
    assert candidate(9) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0]
    assert candidate(20) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0, 6.0, 48.0, 7.0, 63.0, 8.0, 80.0, 9.0, 99.0, 10.0, 120.0, 11.0]

    # Check some edge cases that are easy to work out by hand.
    assert candidate(0) == [1]
    assert candidate(1) == [1, 3]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
