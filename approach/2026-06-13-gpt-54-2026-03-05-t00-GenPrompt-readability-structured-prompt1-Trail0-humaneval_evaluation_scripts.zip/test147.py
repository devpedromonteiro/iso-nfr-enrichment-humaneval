
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    Return the number of index triples (i, j, k) with i < j < k such that
    a[i] + a[j] + a[k] is divisible by 3, where:

        a[x] = x * x - x + 1   for 1 <= x <= n

    Observation:
    Since divisibility by 3 depends only on remainders modulo 3, we analyze:

        a[x] = x^2 - x + 1

    For x mod 3:
        x â¡ 0 -> a[x] â¡ 1
        x â¡ 1 -> a[x] â¡ 1
        x â¡ 2 -> a[x] â¡ 0

    So every value in the array is congruent to either:
        1 mod 3  when index % 3 is 0 or 1
        0 mod 3  when index % 3 is 2

    A triple sum is divisible by 3 only in these cases:
        - all three values are 0 mod 3
        - one value is 0 mod 3 and the other two are 1 mod 3

    Let:
        zero_remainder_count = number of indices x in [1, n] with x % 3 == 2
        one_remainder_count  = n - zero_remainder_count

    Result:
        C(zero_remainder_count, 3) +
        zero_remainder_count * C(one_remainder_count, 2)
    """

    def combinations_of_two(count):
        return count * (count - 1) // 2 if count >= 2 else 0

    def combinations_of_three(count):
        return count * (count - 1) * (count - 2) // 6 if count >= 3 else 0

    zero_remainder_count = (n + 1) // 3
    one_remainder_count = n - zero_remainder_count

    triples_all_zero_remainder = combinations_of_three(zero_remainder_count)
    triples_one_zero_two_ones = zero_remainder_count * combinations_of_two(one_remainder_count)

    return triples_all_zero_remainder + triples_one_zero_two_ones
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
