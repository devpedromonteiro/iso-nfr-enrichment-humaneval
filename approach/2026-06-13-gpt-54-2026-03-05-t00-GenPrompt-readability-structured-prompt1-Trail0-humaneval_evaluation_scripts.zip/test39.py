
import unittest
import re
import sys
import math
import copy



def prime_fib(n: int) -> int:
    """
    Return the n-th Fibonacci number that is also prime.

    The sequence begins:
    2, 3, 5, 13, 89, ...

    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """
    if n < 1:
        raise ValueError("n must be a positive integer")

    def is_prime(number: int) -> bool:
        """Return True if number is prime, otherwise False."""
        if number < 2:
            return False
        if number == 2:
            return True
        if number % 2 == 0:
            return False

        divisor = 3
        while divisor * divisor <= number:
            if number % divisor == 0:
                return False
            divisor += 2
        return True

    previous_fib = 0
    current_fib = 1
    prime_fibonacci_count = 0

    while True:
        previous_fib, current_fib = current_fib, previous_fib + current_fib

        if is_prime(previous_fib):
            prime_fibonacci_count += 1
            if prime_fibonacci_count == n:
                return previous_fib
candidate = prime_fib




METADATA = {}


def check(candidate):
    assert candidate(1) == 2
    assert candidate(2) == 3
    assert candidate(3) == 5
    assert candidate(4) == 13
    assert candidate(5) == 89
    assert candidate(6) == 233
    assert candidate(7) == 1597
    assert candidate(8) == 28657
    assert candidate(9) == 514229
    assert candidate(10) == 433494437



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
