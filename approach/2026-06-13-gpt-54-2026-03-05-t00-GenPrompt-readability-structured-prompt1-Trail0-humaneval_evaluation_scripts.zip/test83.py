
import unittest
import re
import sys
import math
import copy


def starts_one_ends(digit_count):
    """
    Return how many n-digit positive integers start with 1 or end with 1.

    An n-digit positive integer:
    - starts with 1: 10^(n-1) numbers
    - ends with 1:   10^(n-1) numbers
    - both start and end with 1 are counted twice, so subtract them once

    For n = 1, the only valid number is 1.
    """
    if digit_count <= 0:
        raise ValueError("digit_count must be a positive integer")

    if digit_count == 1:
        return 1

    count_starting_with_one = 10 ** (digit_count - 1)
    count_ending_with_one = 10 ** (digit_count - 1)
    count_starting_and_ending_with_one = 10 ** (digit_count - 2)

    total_count = (
        count_starting_with_one
        + count_ending_with_one
        - count_starting_and_ending_with_one
    )

    return total_count
candidate = starts_one_ends


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(1) == 1
    assert candidate(2) == 18
    assert candidate(3) == 180
    assert candidate(4) == 1800
    assert candidate(5) == 18000

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
