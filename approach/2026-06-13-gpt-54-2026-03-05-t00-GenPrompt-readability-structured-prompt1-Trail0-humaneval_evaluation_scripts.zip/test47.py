
import unittest
import re
import sys
import math
import copy



def median(values: list):
    """Return the median of the elements in values.

    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    8.0
    """
    sorted_values = sorted(values)
    number_of_values = len(sorted_values)
    middle_index = number_of_values // 2

    if number_of_values % 2 == 1:
        return sorted_values[middle_index]

    left_middle_value = sorted_values[middle_index - 1]
    right_middle_value = sorted_values[middle_index]
    return (left_middle_value + right_middle_value) / 2
candidate = median




METADATA = {}


def check(candidate):
    assert candidate([3, 1, 2, 4, 5]) == 3
    assert candidate([-10, 4, 6, 1000, 10, 20]) == 8.0
    assert candidate([5]) == 5
    assert candidate([6, 5]) == 5.5
    assert candidate([8, 1, 3, 9, 9, 2, 7]) == 7 



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
