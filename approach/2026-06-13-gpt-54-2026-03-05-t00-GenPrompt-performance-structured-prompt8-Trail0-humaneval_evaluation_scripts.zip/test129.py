
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Given a grid with N rows and N columns (N >= 2) and a positive integer k,
    each cell of the grid contains a value. Every integer in the range [1, N * N]
    inclusive appears exactly once on the cells of the grid.

    Return the lexicographically smallest sequence of values obtainable by a path
    of length k, moving only between edge-sharing neighboring cells.
    """
    n = len(grid)

    # Map each value to its position for O(1) lookup by value.
    pos = [None] * (n * n + 1)
    for r in range(n):
        row = grid[r]
        for c in range(n):
            pos[row[c]] = (r, c)

    if k == 1:
        return [1]

    # Precompute neighbors for each value once to avoid repeated boundary checks
    # and redundant allocations during the main loop.
    neighbors = [[] for _ in range(n * n + 1)]
    for v in range(1, n * n + 1):
        r, c = pos[v]
        adj = neighbors[v]
        if r > 0:
            adj.append(grid[r - 1][c])
        if r + 1 < n:
            adj.append(grid[r + 1][c])
        if c > 0:
            adj.append(grid[r][c - 1])
        if c + 1 < n:
            adj.append(grid[r][c + 1])

    # Start from the globally smallest possible first value.
    path = [1]
    current = 1

    # To minimize lexicographically, at each step choose the smallest-valued
    # neighbor of the current cell. Since revisiting cells is allowed, this
    # greedy choice is optimal for lexicographic minimization.
    for _ in range(k - 1):
        nxt = min(neighbors[current])
        path.append(nxt)
        current = nxt

    return path
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
