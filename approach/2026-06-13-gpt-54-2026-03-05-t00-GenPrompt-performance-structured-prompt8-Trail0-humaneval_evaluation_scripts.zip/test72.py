
import unittest
import re
import sys
import math
import copy


def will_it_fly(q, w):
    left, right = 0, len(q) - 1
    total = 0

    while left <= right:
        if q[left] != q[right]:
            return False

        if left == right:
            total += q[left]
        else:
            total += q[left] + q[right]

        if total > w:
            return False

        left += 1
        right -= 1

    return True
candidate = will_it_fly


def check(candidate):

    # Check some simple cases
    assert candidate([3, 2, 3], 9) is True
    assert candidate([1, 2], 5) is False
    assert candidate([3], 5) is True
    assert candidate([3, 2, 3], 1) is False


    # Check some edge cases that are easy to work out by hand.
    assert candidate([1, 2, 3], 6) is False
    assert candidate([5], 5) is True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
