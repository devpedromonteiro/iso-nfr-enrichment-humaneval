
import unittest


def sorted_list_sum(lst):
    """Return a sorted list containing only the even-length strings from lst.

    Sorting rules:
    - primary: ascending by string length
    - secondary: alphabetical order for strings of equal length

    Error handling:
    - raises TypeError if lst is not a list
    - raises TypeError if any element of lst is not a string
    """
    if not isinstance(lst, list):
        raise TypeError("lst must be a list of strings")

    for i, item in enumerate(lst):
        if not isinstance(item, str):
            raise TypeError(f"lst[{i}] must be a string, got {type(item).__name__}")

    try:
        even_length_strings = [s for s in lst if len(s) % 2 == 0]
        return sorted(even_length_strings, key=lambda s: (len(s), s))
    except TypeError:
        raise
    except Exception as e:
        raise RuntimeError("failed to filter and sort the input list") from e
candidate = sorted_list_sum


class Test(unittest.TestCase):
    def test(self):
        assert candidate(['boalfyu', 'PTGHMN', 'pwgh', 't']) == ['pwgh', 'PTGHMN']
        assert candidate(['btr', 'GKKR', 'nue', 'x']) == ['GKKR']
        assert candidate(['k', 'y', 'x', 'r']) == []
        assert candidate(['mjt', 'GDRQVY', 'uxtapid', 'h']) == ['GDRQVY']
        assert candidate(['vdiny', 'qybrhvm', 'ctdvqb', 'noy']) == ['ctdvqb']
        assert candidate(['u', 'f', 'o', 'f', 'q', 'y']) == []
        assert candidate(['n', 'i', 'n', 'q', 'c', 'l']) == []
        assert candidate(['x', 'i', 'e', 'x']) == []
        assert candidate(['x', 'zgchziq', 'sysdvz', 'a']) == ['sysdvz']
        assert candidate(['b', 'qgpq', 'tpqegmwj', 'e']) == ['qgpq', 'tpqegmwj']
        assert candidate(['iuoyc', 'ullwfdp', 'pvkuk', 'cofc']) == ['cofc']
        assert candidate(['hjjpyxkf', 'HNCS', 'lxdufgfs', 'g']) == ['HNCS', 'hjjpyxkf', 'lxdufgfs']
        assert candidate(['jrfmz', 'g', 'tomvxr']) == ['tomvxr']
        assert candidate(['xstu', 'a', 'lqcsrpz']) == ['xstu']
        assert candidate(['qjwgympb', 'nhffndu', 'hdk', 'dzstfj']) == ['dzstfj', 'qjwgympb']
        assert candidate(['p', 'dizvipnth', 'dvgiu', 'r']) == []
        assert candidate(['ekxlt', 'o', 'tdeu']) == ['tdeu']
        assert candidate(['f', 'uyprdzr', 'ktv', 'q']) == []
        assert candidate(['EAS', 'dmd', 'hmhomw']) == ['hmhomw']
        assert candidate(['wwh', 'h', 'hnqzaekx']) == ['hnqzaekx']
        assert candidate(['pgenbrrjx', 'vanvcx', 'nlv', 'wtxxxh']) == ['vanvcx', 'wtxxxh']
        assert candidate(['AQWCDV', 'usbp', 'nmsau']) == ['usbp', 'AQWCDV']
        assert candidate(['QCJ', 'affdn', 'hww']) == []
        assert candidate(['gvjy', 'p', 'fuwizq']) == ['gvjy', 'fuwizq']
        assert candidate(['p', 'm', 'b', 'j', 'e', 'u']) == []
        assert candidate(['r', 'y', 'b', 'o', 'k', 'b']) == []
        assert candidate(['irmrfqffety', 'TXYO', 'yarx', 'o']) == ['TXYO', 'yarx']
        assert candidate(['tnvnoddoc', 'lsqqu', 'soxlba', 'axjfi']) == ['soxlba']
        assert candidate(['q', 'k', 'z', 'l']) == []
        assert candidate(['e', 'p', 'w', 't', 'm', 'y']) == []
        assert candidate(["d", "dcba", "abcd", "a"]) == ["abcd", "dcba"]

    # Check some edge cases that are easy to work out by hand.
        assert candidate(['h', 'kugihl', 'pvyzsh', 'c']) == ['kugihl', 'pvyzsh']
        assert candidate(['r', 'y', 'f', 's', 'c', 'd']) == []
        assert candidate(['l', 'j', 'q', 'i', 'w', 'a']) == []
        assert candidate(['p', 'w', 'c', 'z', 'z', 'w']) == []
        assert candidate(['mqbwrjooe', 'XTSZ', 'tazrjipd', 'b']) == ['XTSZ', 'tazrjipd']
        assert candidate(['k', 'k', 'v', 'b']) == []
        assert candidate(['mslllfrcp', 'XQUNEP', 'kugjguofd', 'd']) == ['XQUNEP']
        assert candidate(['PBEQI', 'sbkq', 'heblbq']) == ['sbkq', 'heblbq']
        assert candidate(['QYMOZ', 'uixbpt', 'hqgiu']) == ['uixbpt']
        assert candidate(['regohj', 'x', 'irqawkr']) == ['regohj']
        assert candidate(['FUOXV', 'qctut', 'svdeaj']) == ['svdeaj']
        assert candidate(["aa", "a", "aaa"]) == ["aa"]
        assert candidate(['o', 'm', 'w', 'u']) == []
        assert candidate(['m', 'bjptqzaty', 'inkkhfl', 's']) == []
        assert candidate(['MIF', 'swoat', 'jqf']) == []
        assert candidate(['ewbj', 'svvkcit', 'mjiwit', 'rpaxk']) == ['ewbj', 'mjiwit']
        assert candidate(['juqaehy', 'eheobjx', 'qbxc', 'ximw']) == ['qbxc', 'ximw']
        assert candidate(['t', 'k', 'g', 'p', 'r', 't']) == []
        assert candidate(['hrhr', 's', 'efyajpfr']) == ['hrhr', 'efyajpfr']
        assert candidate(['ucm', 'l', 'yveil']) == []
        assert candidate(['recwm', 'yeck', 'oqq', 'phyphd']) == ['yeck', 'phyphd']
        assert candidate(['q', 'xrjkdncyy', 'yduhelics', 'x']) == []
        assert candidate(['a', 'ugmgcxr', 'tnweggy', 'a']) == []
        assert candidate(['IUDPWX', 'yrvry', 'mcwkp']) == ['IUDPWX']
        assert candidate(['xuc', 'z', 'xqid']) == ['xqid']
        assert candidate(['sicstb', 'm', 'pzlzr']) == ['sicstb']
        assert candidate(['elk', 'itmt', 'ndqoy', 'wmuteq']) == ['itmt', 'wmuteq']
        assert candidate(['a', 'v', 'm', 'w']) == []
        assert candidate(['GZRA', 'xarpin', 'efnq']) == ['GZRA', 'efnq', 'xarpin']
        assert candidate(['ONSBIH', 'hxf', 'fzzcfd']) == ['ONSBIH', 'fzzcfd']
        assert candidate(['w', 'a', 'o', 't']) == []
        assert candidate(['bcbuca', 'm', 'cbbhjpl']) == ['bcbuca']
        assert candidate(['YIV', 'rcz', 'bpadif']) == ['bpadif']
        assert candidate(['HUHFA', 'pwp', 'atzqku']) == ['atzqku']
        assert candidate(['r', 'g', 'u', 'h', 'm', 't']) == []
        assert candidate(['OCNZ', 'msehtj', 'yorhll']) == ['OCNZ', 'msehtj', 'yorhll']
        assert candidate(['OTZVLC', 'qmbu', 'tzfllx']) == ['qmbu', 'OTZVLC', 'tzfllx']
        assert candidate(['m', 'q', 'f', 'z']) == []
        assert candidate(['GAD', 'hnpq', 'hjuj']) == ['hjuj', 'hnpq']
        assert candidate(["AI", "ai", "au"]) == ["AI", "ai", "au"]
        assert candidate(['e', 'ixpnz', 'wgzpg', 'z']) == []
        assert candidate(['r', 'o', 'n', 'm', 's', 'c']) == []
        assert candidate(['g', 'hmwftriyk', 'hciog', 'd']) == []
        assert candidate(['aaaa', 'bbbb', 'dd', 'cc']) == ["cc", "dd", "aaaa", "bbbb"]
        assert candidate(['p', 'd', 'y', 'f', 'q', 'b']) == []
        assert candidate(['z', 'w', 'e', 'y']) == []
        assert candidate(['n', 'x', 'h', 'l', 'g', 'x']) == []
        assert candidate(['fxxnym', 'YNVUK', 'sniixyr', 'u']) == ['fxxnym']
        assert candidate(['p', 'u', 'h', 'm']) == []
        assert candidate(['j', 'ncrylsgoq', 'thhjcjyhj', 'n']) == []
        assert candidate(['vpmbycpeghbq', 'FJNDFH', 'rphx', 'p']) == ['rphx', 'FJNDFH', 'vpmbycpeghbq']
        assert candidate(['pzifo', 'w', 'axbjjdkxp']) == []
        assert candidate(['b', 'lne', 'wacbgrdx', 'e']) == ['wacbgrdx']
        assert candidate(['i', 'p', 't', 'e', 'o', 'e']) == []
        assert candidate(['uexpcjhhqugm', 'FJCFLF', 'vegmlf', 'a']) == ['FJCFLF', 'vegmlf', 'uexpcjhhqugm']
        assert candidate(['cskx', 'eisx', 'rprb', 'tcdu']) == ['cskx', 'eisx', 'rprb', 'tcdu']
        assert candidate(['s', 'h', 'n', 'v', 'e', 'j']) == []
        assert candidate(["a", "b", "b", "c", "c", "a"]) == []
        assert candidate(['u', 'vhdpoppi', 'myg', 'v']) == ['vhdpoppi']
        assert candidate(['y', 'q', 'l', 'v']) == []
        assert candidate(['rxjv', 'JTH', 'gypzzns', 'g']) == ['rxjv']
        assert candidate(['bxyypq', 'wxxrhtl', 'viufyc', 'ikokkf']) == ['bxyypq', 'ikokkf', 'viufyc']
        assert candidate(['INSLDO', 'mubcsj', 'oxfw']) == ['oxfw', 'INSLDO', 'mubcsj']
        assert candidate(['j', 'j', 'h', 'o']) == []
        assert candidate(['y', 'g', 'g', 'n']) == []
        assert candidate(['iooz', 'ynxjvyin', 'rlt', 'tmlj']) == ['iooz', 'tmlj', 'ynxjvyin']
        assert candidate(['v', 'y', 'o', 'q', 'g', 'u']) == []
        assert candidate(['eqsgqwww', 'ttflnfbu', 'gsdjzv', 'pifc']) == ['pifc', 'gsdjzv', 'eqsgqwww', 'ttflnfbu']
        assert candidate(['fgjgsq', 'm', 'msri']) == ['msri', 'fgjgsq']
        assert candidate(['q', 'm', 'w', 'e']) == []
        assert candidate(["d", "b", "c", "a"]) == []
        assert candidate(['edos', 'ELAX', 'babcjwlc', 'j']) == ['ELAX', 'edos', 'babcjwlc']
        assert candidate(['yld', 'y', 'plufbbact']) == []
        assert candidate(['ebwm', 'y', 'pnzotmy']) == ['ebwm']
        assert candidate(['x', 'o', 'g', 'h']) == []
        assert candidate(['t', 'fogstld', 'mjpwpgxl', 'x']) == ['mjpwpgxl']
        assert candidate(['f', 'k', 'q', 'q']) == []
        assert candidate(["school", "AI", "asdf", "b"]) == ["AI", "asdf", "school"]
        assert candidate(['y', 'u', 'n', 'o', 'v', 'n']) == []
        assert candidate(['UKFCW', 'tusesk', 'pbci']) == ['pbci', 'tusesk']
        assert candidate(['y', 'dfcz', 'akkxahu', 't']) == ['dfcz']
        assert candidate(['usj', 'GIOJ', 'huwhiofpm', 'z']) == ['GIOJ']
        assert candidate(['xglff', 'lmahsr', 'hqbmy', 'ceykyf']) == ['ceykyf', 'lmahsr']
        assert candidate(['muu', 'EDEF', 'gkivpgs', 'f']) == ['EDEF']
        assert candidate(['muo', 'j', 'ckygjpxwg']) == []
        assert candidate(['qpy', 'gco', 'jmyh', 'uwxr']) == ['jmyh', 'uwxr']
        assert candidate(['tzl', 'o', 'slwk']) == ['slwk']
        assert candidate(['zxnubdtseq', 'QSLH', 'oywewn', 'b']) == ['QSLH', 'oywewn', 'zxnubdtseq']
        assert candidate(['a', 'c', 'e', 'x']) == []
        assert candidate(['m', 'v', 'g', 'g', 'y', 'd']) == []
        assert candidate(['g', 'u', 'u', 'q']) == []
        assert candidate(['jhsxxlwgy', 'NBF', 'aefmf', 'c']) == []
        assert candidate(['k', 'jydfagyx', 'fxovtjzr', 'q']) == ['fxovtjzr', 'jydfagyx']
        assert candidate(['lsxvhg', 'VIXMZX', 'vyng', 'n']) == ['vyng', 'VIXMZX', 'lsxvhg']
        assert candidate(['xnf', 'v', 'pjjsyo']) == ['pjjsyo']
        assert candidate(['wlqokjf', 'nbpsqnzh', 'tjrk', 'hexydi']) == ['tjrk', 'hexydi', 'nbpsqnzh']
        assert candidate(['l', 'iwkqccom', 'jsxm', 'g']) == ['jsxm', 'iwkqccom']
        assert candidate(['iiqufxt', 'bfjyqmjp', 'zzo', 'gevhmv']) == ['gevhmv', 'bfjyqmjp']
        assert candidate(['w', 'viox', 'adfohsvy', 'k']) == ['viox', 'adfohsvy']
        assert candidate(['llwuubhcb', 'TDJAL', 'kqsokna', 'm']) == []
        assert candidate(['kpbalcfbr', 'xiqozc', 'gckv', 'zfif']) == ['gckv', 'zfif', 'xiqozc']
        assert candidate(['DEJ', 'onmqey', 'ramziu']) == ['onmqey', 'ramziu']

if __name__ == '__main__':
    unittest.main()
