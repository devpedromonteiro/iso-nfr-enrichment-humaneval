
import unittest
import re
import sys
import math
import copy


def valid_date(date):
    """Validate a date string in mm-dd-yyyy format."""
    if not _is_non_empty_string(date):
        return False

    parts = _split_date_parts(date)
    if parts is None:
        return False

    month, day, year = parts
    if not _has_valid_lengths(month, day, year):
        return False

    if not _are_numeric_parts(month, day, year):
        return False

    month_num = int(month)
    day_num = int(day)

    if not _is_valid_month(month_num):
        return False

    return _is_valid_day_for_month(month_num, day_num)


def _is_non_empty_string(value):
    return isinstance(value, str) and value != ""


def _split_date_parts(date_string):
    parts = date_string.split("-")
    return parts if len(parts) == 3 else None


def _has_valid_lengths(month, day, year):
    return len(month) == 2 and len(day) == 2 and len(year) == 4


def _are_numeric_parts(month, day, year):
    return month.isdigit() and day.isdigit() and year.isdigit()


def _is_valid_month(month):
    return 1 <= month <= 12


def _is_valid_day_for_month(month, day):
    if day < 1:
        return False

    max_days_by_month = {
        1: 31, 2: 29, 3: 31, 4: 30,
        5: 31, 6: 30, 7: 31, 8: 31,
        9: 30, 10: 31, 11: 30, 12: 31,
    }
    return day <= max_days_by_month[month]
candidate = valid_date


def check(candidate):

    # Check some simple cases
    assert candidate('03-11-2000') == True

    assert candidate('15-01-2012') == False

    assert candidate('04-0-2040') == False

    assert candidate('06-04-2020') == True

    assert candidate('01-01-2007') == True

    assert candidate('03-32-2011') == False

    assert candidate('') == False

    assert candidate('04-31-3000') == False

    assert candidate('06-06-2005') == True

    assert candidate('21-31-2000') == False

    assert candidate('04-12-2003') == True

    assert candidate('04122003') == False

    assert candidate('20030412') == False

    assert candidate('2003-04') == False

    assert candidate('2003-04-12') == False

    assert candidate('04-2003') == False


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
