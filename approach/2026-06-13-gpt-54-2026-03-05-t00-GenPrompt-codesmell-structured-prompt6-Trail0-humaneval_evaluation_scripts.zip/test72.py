
import unittest
import re
import sys
import math
import copy


def is_palindrome(items):
    """Return True if the list reads the same forwards and backwards."""
    return items == items[::-1]


def is_within_weight_limit(items, max_weight):
    """Return True if the sum of items does not exceed max_weight."""
    return sum(items) <= max_weight


def will_it_fly(q, w):
    '''
    Return True if q will fly, False otherwise.

    An object will fly if:
    - it is balanced (a palindromic list), and
    - the sum of its elements is less than or equal to w.
    '''
    return is_palindrome(q) and is_within_weight_limit(q, w)
candidate = will_it_fly


def check(candidate):

    # Check some simple cases
    assert candidate([3, 2, 3], 9) is True
    assert candidate([1, 2], 5) is False
    assert candidate([3], 5) is True
    assert candidate([3, 2, 3], 1) is False


    # Check some edge cases that are easy to work out by hand.
    assert candidate([1, 2, 3], 6) is False
    assert candidate([5], 5) is True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
