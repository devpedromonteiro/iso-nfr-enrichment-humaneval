
import unittest
import re
import sys
import math
import copy



from typing import Sequence, Union

Number = Union[int, float]


def _validate_non_empty(values: Sequence[Number]) -> None:
    """Validate that the input sequence is not empty."""
    if not values:
        raise ValueError("median() arg is an empty sequence")


def _sorted_values(values: Sequence[Number]) -> list[Number]:
    """Return a sorted copy of the input values."""
    return sorted(values)


def _middle_index(length: int) -> int:
    """Return the middle index for a sequence length."""
    return length // 2


def _median_of_even_values(values: Sequence[Number], middle: int) -> float:
    """Return the median for an even-length sorted sequence."""
    return (values[middle - 1] + values[middle]) / 2


def _median_of_odd_values(values: Sequence[Number], middle: int) -> Number:
    """Return the median for an odd-length sorted sequence."""
    return values[middle]


def median(l: list[Number]) -> Number:
    """Return median of elements in the list l.

    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    15.0
    """
    _validate_non_empty(l)
    sorted_list = _sorted_values(l)
    middle = _middle_index(len(sorted_list))

    if len(sorted_list) % 2 == 0:
        return _median_of_even_values(sorted_list, middle)

    return _median_of_odd_values(sorted_list, middle)
candidate = median




METADATA = {}


def check(candidate):
    assert candidate([3, 1, 2, 4, 5]) == 3
    assert candidate([-10, 4, 6, 1000, 10, 20]) == 8.0
    assert candidate([5]) == 5
    assert candidate([6, 5]) == 5.5
    assert candidate([8, 1, 3, 9, 9, 2, 7]) == 7 



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
