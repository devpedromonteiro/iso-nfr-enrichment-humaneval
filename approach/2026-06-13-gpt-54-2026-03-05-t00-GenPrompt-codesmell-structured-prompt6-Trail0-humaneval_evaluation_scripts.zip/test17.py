
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List

_NOTE_TO_BEATS = {
    "o": 4,
    "o|": 2,
    ".|": 1,
}


def _parse_note(token: str) -> int:
    """Convert a single note token into its beat count."""
    try:
        return _NOTE_TO_BEATS[token]
    except KeyError as exc:
        raise ValueError(f"Invalid note: {token}") from exc


def parse_music(music_string: str) -> List[int]:
    """Parse a space-separated ASCII music string into beat counts.

    Legend:
    - 'o'  -> 4 beats
    - 'o|' -> 2 beats
    - '.|' -> 1 beat

    >>> parse_music('o o| .| o| o| .| .| .| .| o o')
    [4, 2, 1, 2, 2, 1, 1, 1, 1, 4, 4]
    """
    tokens = music_string.split()
    return [_parse_note(token) for token in tokens]
candidate = parse_music




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == []
    assert candidate('o o o o') == [4, 4, 4, 4]
    assert candidate('.| .| .| .|') == [1, 1, 1, 1]
    assert candidate('o| o| .| .| o o o o') == [2, 2, 1, 1, 4, 4, 4, 4]
    assert candidate('o| .| o| .| o o| o o|') == [2, 1, 2, 1, 4, 2, 4, 2]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
