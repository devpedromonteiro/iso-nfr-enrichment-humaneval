
import unittest
import re
import sys
import math
import copy


def _is_even_position(index):
    """Return True when the zero-based index represents an even position."""
    return index % 2 == 0


def _is_odd_number(value):
    """Return True when the value is odd."""
    return value % 2 != 0


def solution(lst):
    """Return the sum of odd elements located at even positions.

    Positions are interpreted as zero-based indexes.

    Examples:
        solution([5, 8, 7, 1]) == 12
        solution([3, 3, 3, 3, 3]) == 9
        solution([30, 13, 24, 321]) == 0
    """
    return sum(
        value
        for index, value in enumerate(lst)
        if _is_even_position(index) and _is_odd_number(value)
    )
candidate = solution


def check(candidate):

    # Check some simple cases
    assert candidate([5, 8, 7, 1])    == 12
    assert candidate([3, 3, 3, 3, 3]) == 9
    assert candidate([30, 13, 24, 321]) == 0
    assert candidate([5, 9]) == 5
    assert candidate([2, 4, 8]) == 0
    assert candidate([30, 13, 23, 32]) == 23
    assert candidate([3, 13, 2, 9]) == 3

    # Check some edge cases that are easy to work out by hand.



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
