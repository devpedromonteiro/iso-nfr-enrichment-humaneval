
import unittest
import re
import sys
import math
import copy


def _is_palindrome(number):
    """Return True if the integer reads the same forward and backward."""
    text = str(number)
    return text == text[::-1]


def _count_even_odd_palindromes(limit):
    """Count even and odd palindromic integers in the range 1..limit."""
    even_count = 0
    odd_count = 0

    for value in range(1, limit + 1):
        if _is_palindrome(value):
            if value % 2 == 0:
                even_count += 1
            else:
                odd_count += 1

    return even_count, odd_count


def even_odd_palindrome(n):
    """
    Given a positive integer n, return a tuple that has the number of even and odd
    integer palindromes that fall within the range(1, n), inclusive.

    Example 1:

        Input: 3
        Output: (1, 2)
        Explanation:
        Integer palindrome are 1, 2, 3. one of them is even, and two of them are odd.

    Example 2:

        Input: 12
        Output: (4, 6)
        Explanation:
        Integer palindrome are 1, 2, 3, 4, 5, 6, 7, 8, 9, 11. four of them are even, and 6 of them are odd.

    Note:
        1. 1 <= n <= 10^3
        2. returned tuple has the number of even and odd integer palindromes respectively.
    """
    return _count_even_odd_palindromes(n)
candidate = even_odd_palindrome


def check(candidate):

    # Check some simple cases
    assert candidate(123) == (8, 13)
    assert candidate(12) == (4, 6)
    assert candidate(3) == (1, 2)
    assert candidate(63) == (6, 8)
    assert candidate(25) == (5, 6)
    assert candidate(19) == (4, 6)
    assert candidate(9) == (4, 5), "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1) == (0, 1), "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
