
import unittest
import re
import sys
import math
import copy


def _is_valid_target(n):
    """Return True if n is an integer that can be checked for the rule."""
    return isinstance(n, int) and n > 0


def _minimum_sum_of_four_positive_even_numbers():
    """Return the smallest possible sum of 4 positive even numbers."""
    return 4 * 2


def is_equal_to_sum_even(n):
    """Evaluate whether n can be written as the sum of exactly 4 positive even numbers.

    Examples:
        is_equal_to_sum_even(4) == False
        is_equal_to_sum_even(6) == False
        is_equal_to_sum_even(8) == True
    """
    if not _is_valid_target(n):
        return False

    minimum_sum = _minimum_sum_of_four_positive_even_numbers()
    return n >= minimum_sum and n % 2 == 0
candidate = is_equal_to_sum_even


def check(candidate):
    assert candidate(4) == False
    assert candidate(6) == False
    assert candidate(8) == True
    assert candidate(10) == True
    assert candidate(11) == False
    assert candidate(12) == True
    assert candidate(13) == False
    assert candidate(16) == True


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
