
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def _starts_with_prefix(value: str, prefix: str) -> bool:
    """Return whether a string starts with the given prefix."""
    return value.startswith(prefix)


def filter_by_prefix(strings: List[str], prefix: str) -> List[str]:
    """Filter strings that start with a given prefix.

    >>> filter_by_prefix([], 'a')
    []
    >>> filter_by_prefix(['abc', 'bcd', 'cde', 'array'], 'a')
    ['abc', 'array']
    """
    return [value for value in strings if _starts_with_prefix(value, prefix)]
candidate = filter_by_prefix




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([], 'john') == []
    assert candidate(['xxx', 'asd', 'xxy', 'john doe', 'xxxAAA', 'xxx'], 'xxx') == ['xxx', 'xxxAAA', 'xxx']


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
