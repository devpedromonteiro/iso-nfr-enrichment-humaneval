
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    Return the number of triples (a[i], a[j], a[k]) with i < j < k such that
    a[i] + a[j] + a[k] is divisible by 3, where:

        a[i] = i*i - i + 1   for 1 <= i <= n

    Observation:
    Since divisibility by 3 depends only on values modulo 3, compute:

        i*i - i + 1 mod 3

    For i mod 3:
        1 -> 1
        2 -> 0
        0 -> 1

    So every term is either:
        1 mod 3  when i % 3 != 2
        0 mod 3  when i % 3 == 2

    A triple sum is divisible by 3 only in these cases:
        - three 0-mod-3 values
        - three 1-mod-3 values

    Therefore, if:
        c0 = count of indices i in [1..n] with i % 3 == 2
        c1 = n - c0

    answer = C(c0, 3) + C(c1, 3)
    """

    def combinations_of_three(count):
        if count < 3:
            return 0
        return count * (count - 1) * (count - 2) // 6

    def count_zero_mod_terms(length):
        # Indices with i % 3 == 2 are: 2, 5, 8, ...
        return (length + 1) // 3

    zero_mod_count = count_zero_mod_terms(n)
    one_mod_count = n - zero_mod_count

    return combinations_of_three(zero_mod_count) + combinations_of_three(one_mod_count)
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
