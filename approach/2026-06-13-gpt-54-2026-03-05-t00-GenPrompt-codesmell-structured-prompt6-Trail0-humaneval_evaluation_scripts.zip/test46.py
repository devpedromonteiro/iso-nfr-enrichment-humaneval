
import unittest
import re
import sys
import math
import copy



def fib4(n: int) -> int:
    """Return the n-th value of the Fib4 sequence.

    The sequence is defined as:
    fib4(0) = 0
    fib4(1) = 0
    fib4(2) = 2
    fib4(3) = 0
    fib4(n) = fib4(n-1) + fib4(n-2) + fib4(n-3) + fib4(n-4) for n >= 4

    The implementation is iterative and uses constant extra space.

    >>> fib4(5)
    4
    >>> fib4(6)
    8
    >>> fib4(7)
    14
    """
    if n < 0:
        raise ValueError("n must be non-negative")

    base_values = (0, 0, 2, 0)
    if n < len(base_values):
        return base_values[n]

    a, b, c, d = base_values
    for _ in range(4, n + 1):
        a, b, c, d = b, c, d, a + b + c + d

    return d
candidate = fib4




METADATA = {}


def check(candidate):
    assert candidate(5) == 4
    assert candidate(8) == 28
    assert candidate(10) == 104
    assert candidate(12) == 386



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
