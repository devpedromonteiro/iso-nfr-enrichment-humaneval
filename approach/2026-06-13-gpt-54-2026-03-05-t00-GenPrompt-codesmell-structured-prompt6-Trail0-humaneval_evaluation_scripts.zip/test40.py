
import unittest
import re
import sys
import math
import copy



from itertools import combinations


def _has_zero_sum_triplet(values: list[int]) -> bool:
    """Return True if any 3 distinct elements sum to zero."""
    return any(sum(triplet) == 0 for triplet in combinations(values, 3))


def triples_sum_to_zero(values: list[int]) -> bool:
    """
    Return True if there are three distinct elements in the list that sum to zero.

    >>> triples_sum_to_zero([1, 3, 5, 0])
    False
    >>> triples_sum_to_zero([1, 3, -2, 1])
    True
    >>> triples_sum_to_zero([1, 2, 3, 7])
    False
    >>> triples_sum_to_zero([2, 4, -5, 3, 9, 7])
    True
    >>> triples_sum_to_zero([1])
    False
    """
    if len(values) < 3:
        return False

    return _has_zero_sum_triplet(values)
candidate = triples_sum_to_zero




METADATA = {}


def check(candidate):
    assert candidate([1, 3, 5, 0]) == False
    assert candidate([1, 3, 5, -1]) == False
    assert candidate([1, 3, -2, 1]) == True
    assert candidate([1, 2, 3, 7]) == False
    assert candidate([1, 2, 5, 7]) == False
    assert candidate([2, 4, -5, 3, 9, 7]) == True
    assert candidate([1]) == False
    assert candidate([1, 3, 5, -100]) == False
    assert candidate([100, 3, 5, -100]) == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
