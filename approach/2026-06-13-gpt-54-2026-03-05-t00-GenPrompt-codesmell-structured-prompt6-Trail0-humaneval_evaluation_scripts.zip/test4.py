
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def _validate_numbers(numbers: List[float]) -> None:
    """Validate that the input list is not empty."""
    if not numbers:
        raise ValueError("numbers must not be empty")


def _calculate_mean(numbers: List[float]) -> float:
    """Return the arithmetic mean of the given numbers."""
    return sum(numbers) / len(numbers)


def _calculate_absolute_deviations(
    numbers: List[float], mean: float
def mean_absolute_deviation(numbers: List[float]) -> float:
    """Calculate mean absolute deviation around the mean.

    Mean Absolute Deviation is the average absolute difference between each
    element and the arithmetic mean of the dataset.

    MAD = average(|x - x_mean|)

    >>> mean_absolute_deviation([1.0, 2.0, 3.0, 4.0])
    1.0
    """
    _validate_numbers(numbers)
    mean = _calculate_mean(numbers)
    absolute_deviations = _calculate_absolute_deviations(numbers, mean)
    return _calculate_mean(absolute_deviations)
candidate = mean_absolute_deviation




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert abs(candidate([1.0, 2.0, 3.0]) - 2.0/3.0) < 1e-6
    assert abs(candidate([1.0, 2.0, 3.0, 4.0]) - 1.0) < 1e-6
    assert abs(candidate([1.0, 2.0, 3.0, 4.0, 5.0]) - 6.0/5.0) < 1e-6



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
