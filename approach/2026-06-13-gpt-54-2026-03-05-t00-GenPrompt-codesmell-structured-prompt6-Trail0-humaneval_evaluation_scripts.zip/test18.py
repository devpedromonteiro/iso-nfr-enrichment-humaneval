
import unittest
import re
import sys
import math
import copy



def _validate_inputs(string: str, substring: str) -> bool:
    """Return whether counting should proceed."""
    return bool(string) and bool(substring)


def _count_overlapping_occurrences(string: str, substring: str) -> int:
    """Count overlapping occurrences of substring in string."""
    count = 0
    start = 0

    while True:
        index = string.find(substring, start)
        if index == -1:
            return count
        count += 1
        start = index + 1


def how_many_times(string: str, substring: str) -> int:
    """Find how many times a given substring appears in the original string.

    Overlapping occurrences are counted.

    >>> how_many_times('', 'a')
    0
    >>> how_many_times('aaa', 'a')
    3
    >>> how_many_times('aaaa', 'aa')
    3
    """
    if not _validate_inputs(string, substring):
        return 0

    return _count_overlapping_occurrences(string, substring)
candidate = how_many_times




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('', 'x') == 0
    assert candidate('xyxyxyx', 'x') == 4
    assert candidate('cacacacac', 'cac') == 4
    assert candidate('john doe', 'john') == 1


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
