
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Given a grid with N rows and N columns (N >= 2) and a positive integer k,
    each cell of the grid contains a value. Every integer in the range [1, N * N]
    inclusive appears exactly once on the cells of the grid.

    Return the lexicographically smallest path of length k, where each move goes
    to an edge-adjacent cell and cells may be revisited.
    """
    positions = _build_value_positions(grid)
    start_value = 1
    start_row, start_col = positions[start_value]

    if k == 1:
        return [start_value]

    path = [start_value]
    current = (start_row, start_col)

    for _ in range(k - 1):
        current = _best_neighbor(current, grid)
        row, col = current
        path.append(grid[row][col])

    return path


def _build_value_positions(grid):
    """Map each cell value to its (row, col) position."""
    positions = {}
    for row_index, row in enumerate(grid):
        for col_index, value in enumerate(row):
            positions[value] = (row_index, col_index)
    return positions


def _best_neighbor(cell, grid):
    """Return the neighboring cell with the smallest value."""
    row, col = cell
    best_cell = None
    best_value = None

    for next_row, next_col in _neighbors(row, col, len(grid)):
        value = grid[next_row][next_col]
        if best_value is None or value < best_value:
            best_value = value
            best_cell = (next_row, next_col)

    return best_cell


def _neighbors(row, col, size):
    """Yield all valid edge-adjacent neighbors of a cell."""
    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]

    for d_row, d_col in directions:
        next_row = row + d_row
        next_col = col + d_col
        if 0 <= next_row < size and 0 <= next_col < size:
            yield next_row, next_col
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
