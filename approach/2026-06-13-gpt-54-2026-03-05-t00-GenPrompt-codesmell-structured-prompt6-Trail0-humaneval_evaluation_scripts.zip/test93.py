
import unittest
import re
import sys
import math
import copy


def _shift_vowel(char):
    """Return the vowel shifted two places forward in the alphabet."""
    vowel_map = {
        "a": "c",
        "e": "g",
        "i": "k",
        "o": "q",
        "u": "w",
    }
    return vowel_map.get(char, char)


def _encode_char(char):
    """Encode a single character according to the rules."""
    swapped = char.swapcase()
    return _shift_vowel(swapped.lower()).upper() if swapped.isupper() else _shift_vowel(swapped)


def encode(message):
    """
    Write a function that takes a message, and encodes in such a
    way that it swaps case of all letters, replaces all vowels in
    the message with the letter that appears 2 places ahead of that
    vowel in the english alphabet.
    Assume only letters.

    Examples:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """
    return "".join(_encode_char(char) for char in message)
candidate = encode


def check(candidate):

    # Check some simple cases
    assert candidate('TEST') == 'tgst', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('Mudasir') == 'mWDCSKR', "This prints if this assert fails 2 (good for debugging!)"
    assert candidate('YES') == 'ygs', "This prints if this assert fails 3 (good for debugging!)"
    
    # Check some edge cases that are easy to work out by hand.
    assert candidate('This is a message') == 'tHKS KS C MGSSCGG', "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate("I DoNt KnOw WhAt tO WrItE") == 'k dQnT kNqW wHcT Tq wRkTg', "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
