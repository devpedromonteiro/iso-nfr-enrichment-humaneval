
import unittest
import re
import sys
import math
import copy



def _remove_factor(value: int, factor: int) -> tuple[int, int]:
    """Divide value by factor until it is no longer divisible.

    Returns:
        A tuple of (reduced_value, factor_if_used_else_1).
    """
    used = False
    while value % factor == 0:
        value //= factor
        used = True
    return value, factor if used else 1


def largest_prime_factor(n: int) -> int:
    """Return the largest prime factor of n. Assume n > 1 and is not a prime.

    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    largest = 1

    n, factor_found = _remove_factor(n, 2)
    if factor_found > largest:
        largest = factor_found

    candidate = 3
    while candidate * candidate <= n:
        n, factor_found = _remove_factor(n, candidate)
        if factor_found > largest:
            largest = factor_found
        candidate += 2

    if n > 1:
        largest = n

    return largest
candidate = largest_prime_factor




METADATA = {}


def check(candidate):
    assert candidate(15) == 5
    assert candidate(27) == 3
    assert candidate(63) == 7
    assert candidate(330) == 11
    assert candidate(13195) == 29



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
