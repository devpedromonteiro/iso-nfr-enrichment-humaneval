
import unittest
import re
import sys
import math
import copy

from typing import List, Optional


from typing import List, Optional


def _is_better_candidate(candidate: str, current: Optional[str]) -> bool:
    """Return True if candidate should replace current as the longest string."""
    return current is None or len(candidate) > len(current)


def longest(strings: List[str]) -> Optional[str]:
    """Out of a list of strings, return the longest one.

    Return the first string in case of multiple strings with the same length.
    Return None if the input list is empty.

    >>> longest([])
    >>> longest(['a', 'b', 'c'])
    'a'
    >>> longest(['a', 'bb', 'ccc'])
    'ccc'
    """
    longest_string: Optional[str] = None

    for string in strings:
        if _is_better_candidate(string, longest_string):
            longest_string = string

    return longest_string
candidate = longest




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == None
    assert candidate(['x', 'y', 'z']) == 'x'
    assert candidate(['x', 'yyy', 'zzzz', 'www', 'kkkk', 'abc']) == 'zzzz'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
