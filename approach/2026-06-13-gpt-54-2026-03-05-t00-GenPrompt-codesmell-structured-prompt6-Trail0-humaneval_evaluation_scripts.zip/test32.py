
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math
from typing import Sequence


def poly(coefficients: Sequence[float], x: float) -> float:
    """
    Evaluate a polynomial with the given coefficients at point x.

    The polynomial is interpreted as:
        coefficients[0] + coefficients[1] * x + ... + coefficients[n] * x^n
    """
    return sum(coeff * math.pow(x, power) for power, coeff in enumerate(coefficients))


def _validate_coefficients(coefficients: Sequence[float]) -> None:
    """Validate the constraints required by find_zero."""
    if len(coefficients) == 0:
        raise ValueError("coefficients must not be empty")
    if len(coefficients) % 2 != 0:
        raise ValueError("coefficients must contain an even number of items")
    if coefficients[-1] == 0:
        raise ValueError("the highest-degree coefficient must be non-zero")


def _find_search_interval(coefficients: Sequence[float]) -> tuple[float, float]:
    """
    Find an interval [left, right] where the polynomial changes sign.

    For the supported input constraints, such an interval is guaranteed to exist.
    """
    left = -1.0
    right = 1.0
    left_value = poly(coefficients, left)
    right_value = poly(coefficients, right)

    while left_value * right_value > 0:
        left *= 2
        right *= 2
        left_value = poly(coefficients, left)
        right_value = poly(coefficients, right)

    return left, right


def _bisect_zero(
    coefficients: Sequence[float],
    left: float,
    right: float,
    tolerance: float = 1e-7,
    max_iterations: int = 10_000,
def find_zero(coefficients: Sequence[float]) -> float:
    """
    Find one zero of a polynomial defined by its coefficients.

    The function only supports coefficient lists with:
    - an even number of coefficients
    - a non-zero highest-degree coefficient

    Under these constraints, the polynomial degree is odd, which guarantees
    at least one real root.

    >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2)
    1.0
    """
    _validate_coefficients(coefficients)
    left, right = _find_search_interval(coefficients)
    return _bisect_zero(coefficients, left, right)
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
