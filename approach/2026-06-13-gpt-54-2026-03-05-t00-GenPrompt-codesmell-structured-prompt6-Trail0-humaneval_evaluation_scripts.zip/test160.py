
import unittest
import re
import sys
import math
import copy


def do_algebra(operator, operand):
    """
    Given two lists operator and operand, build the algebraic expression they represent
    and return its evaluated result using normal Python operator precedence.

    Supported operators:
    +   addition
    -   subtraction
    *   multiplication
    //  floor division
    **  exponentiation
    """
    expression = _build_expression(operator, operand)
    return eval(expression)


def _build_expression(operators, operands):
    """Create an algebraic expression string from operators and operands."""
    _validate_input(operators, operands)

    expression_parts = [str(operands[0])]
    for current_operator, current_operand in zip(operators, operands[1:]):
        expression_parts.append(current_operator)
        expression_parts.append(str(current_operand))

    return " ".join(expression_parts)


def _validate_input(operators, operands):
    """Validate structural assumptions for operators and operands."""
    if len(operators) != len(operands) - 1:
        raise ValueError("The number of operators must be exactly one less than the number of operands.")

    supported_operators = {"+", "-", "*", "//", "**"}
    invalid_operators = [op for op in operators if op not in supported_operators]
    if invalid_operators:
        raise ValueError(f"Unsupported operators found: {invalid_operators}")
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
