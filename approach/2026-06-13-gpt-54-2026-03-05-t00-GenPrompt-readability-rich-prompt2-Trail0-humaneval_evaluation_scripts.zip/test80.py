
import unittest
import re
import sys
import math
import copy


def is_happy(text):
    """Return True if the string is happy, otherwise False.

    A string is happy when:
    - its length is at least 3
    - every group of 3 consecutive characters contains only distinct letters

    Examples:
        is_happy("a") -> False
        is_happy("aa") -> False
        is_happy("abcd") -> True
        is_happy("aabb") -> False
        is_happy("adb") -> True
        is_happy("xyy") -> False
    """
    if len(text) < 3:
        return False

    for start_index in range(len(text) - 2):
        three_letter_group = text[start_index:start_index + 3]

        if len(set(three_letter_group)) != 3:
            return False

    return True
candidate = is_happy


def check(candidate):

    # Check some simple cases
    assert candidate("a") == False , "a"
    assert candidate("aa") == False , "aa"
    assert candidate("abcd") == True , "abcd"
    assert candidate("aabb") == False , "aabb"
    assert candidate("adb") == True , "adb"
    assert candidate("xyy") == False , "xyy"
    assert candidate("iopaxpoi") == True , "iopaxpoi"
    assert candidate("iopaxioi") == False , "iopaxioi"


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
