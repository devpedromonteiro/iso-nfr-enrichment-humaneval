
import unittest
import re
import sys
import math
import copy


def choose_num(start, end):
    """Return the largest even integer in the inclusive range [start, end].

    If the range is invalid or contains no even integer, return -1.

    Examples:
        choose_num(12, 15) -> 14
        choose_num(13, 12) -> -1
    """
    if start > end:
        return -1

    if end % 2 == 0:
        return end

    largest_even_in_range = end - 1

    if largest_even_in_range >= start:
        return largest_even_in_range

    return -1
candidate = choose_num


def check(candidate):

    # Check some simple cases
    assert candidate(12, 15) == 14
    assert candidate(13, 12) == -1
    assert candidate(33, 12354) == 12354
    assert candidate(5234, 5233) == -1
    assert candidate(6, 29) == 28
    assert candidate(27, 10) == -1

    # Check some edge cases that are easy to work out by hand.
    assert candidate(7, 7) == -1
    assert candidate(546, 546) == 546



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
