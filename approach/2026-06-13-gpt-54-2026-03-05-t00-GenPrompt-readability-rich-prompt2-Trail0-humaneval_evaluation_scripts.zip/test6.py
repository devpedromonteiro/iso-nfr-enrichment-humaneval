
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """Return the maximum nesting depth for each space-separated parentheses group.

    Each group contains only parentheses. The result includes one integer per group,
    representing the deepest nesting level in that group.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """
    groups = paren_string.split()
    max_depths = []

    for group in groups:
        current_depth = 0
        deepest_depth = 0

        for character in group:
            if character == "(":
                current_depth += 1
                if current_depth > deepest_depth:
                    deepest_depth = current_depth
            elif character == ")":
                current_depth -= 1

        max_depths.append(deepest_depth)

    return max_depths
candidate = parse_nested_parens




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('(()()) ((())) () ((())()())') == [2, 3, 1, 3]
    assert candidate('() (()) ((())) (((())))') == [1, 2, 3, 4]
    assert candidate('(()(())((())))') == [4]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
