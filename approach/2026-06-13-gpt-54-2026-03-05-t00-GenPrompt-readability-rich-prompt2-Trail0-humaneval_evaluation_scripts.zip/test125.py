
import unittest
import re
import sys
import math
import copy


def split_words(text):
    """
    Return words split from the input text based on the following rules:

    1. If the text contains whitespace, split on whitespace.
    2. Otherwise, if the text contains commas, split on commas.
    3. Otherwise, return the count of lowercase letters whose alphabet index is odd:
       a=0, b=1, ..., z=25.

    Examples:
        split_words("Hello world!") -> ["Hello", "world!"]
        split_words("Hello,world!") -> ["Hello", "world!"]
        split_words("abcdef") -> 3
    """
    if any(character.isspace() for character in text):
        return text.split()

    if "," in text:
        return text.split(",")

    odd_index_lowercase_count = 0

    for character in text:
        if character.islower():
            alphabet_index = ord(character) - ord("a")
            if alphabet_index % 2 == 1:
                odd_index_lowercase_count += 1

    return odd_index_lowercase_count
candidate = split_words


def check(candidate):

    assert candidate("Hello world!") == ["Hello","world!"]
    assert candidate("Hello,world!") == ["Hello","world!"]
    assert candidate("Hello world,!") == ["Hello","world,!"]
    assert candidate("Hello,Hello,world !") == ["Hello,Hello,world","!"]
    assert candidate("abcdef") == 3
    assert candidate("aaabb") == 2
    assert candidate("aaaBb") == 1
    assert candidate("") == 0


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
