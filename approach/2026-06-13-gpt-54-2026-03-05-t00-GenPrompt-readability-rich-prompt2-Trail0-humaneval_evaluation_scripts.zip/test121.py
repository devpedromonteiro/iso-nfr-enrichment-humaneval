
import unittest
import re
import sys
import math
import copy


def solution(numbers):
    """Return the sum of odd numbers located at even positions.

    Positions are counted starting from 1, so the even positions are
    2nd, 4th, 6th, and so on.

    Examples:
        solution([5, 8, 7, 1]) == 1
        solution([3, 3, 3, 3, 3]) == 6
        solution([30, 13, 24, 321]) == 334
    """
    total = 0

    for position, number in enumerate(numbers, start=1):
        is_even_position = position % 2 == 0
        is_odd_number = number % 2 != 0

        if is_even_position and is_odd_number:
            total += number

    return total
candidate = solution


def check(candidate):

    # Check some simple cases
    assert candidate([5, 8, 7, 1])    == 12
    assert candidate([3, 3, 3, 3, 3]) == 9
    assert candidate([30, 13, 24, 321]) == 0
    assert candidate([5, 9]) == 5
    assert candidate([2, 4, 8]) == 0
    assert candidate([30, 13, 23, 32]) == 23
    assert candidate([3, 13, 2, 9]) == 3

    # Check some edge cases that are easy to work out by hand.



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
