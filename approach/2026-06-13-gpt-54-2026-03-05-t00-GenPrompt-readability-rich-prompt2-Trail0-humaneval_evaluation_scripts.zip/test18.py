
import unittest
import re
import sys
import math
import copy



def how_many_times(text: str, pattern: str) -> int:
    """Return how many times ``pattern`` appears in ``text``, including overlaps.

    >>> how_many_times('', 'a')
    0
    >>> how_many_times('aaa', 'a')
    3
    >>> how_many_times('aaaa', 'aa')
    3
    """
    if not text or not pattern:
        return 0

    match_count = 0
    start_index = 0

    while True:
        found_index = text.find(pattern, start_index)

        if found_index == -1:
            return match_count

        match_count += 1
        start_index = found_index + 1
candidate = how_many_times




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('', 'x') == 0
    assert candidate('xyxyxyx', 'x') == 4
    assert candidate('cacacacac', 'cac') == 4
    assert candidate('john doe', 'john') == 1


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
