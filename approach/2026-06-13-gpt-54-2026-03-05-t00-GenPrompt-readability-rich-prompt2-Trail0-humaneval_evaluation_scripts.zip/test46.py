
import unittest
import re
import sys
import math
import copy



def fib4(index: int) -> int:
    """Return the n-th value in the Fib4 sequence.

    The sequence is defined as:
    fib4(0) = 0
    fib4(1) = 0
    fib4(2) = 2
    fib4(3) = 0
    fib4(n) = fib4(n-1) + fib4(n-2) + fib4(n-3) + fib4(n-4) for n >= 4

    >>> fib4(5)
    4
    >>> fib4(6)
    8
    >>> fib4(7)
    14
    """
    if index == 0:
        return 0
    if index == 1:
        return 0
    if index == 2:
        return 2
    if index == 3:
        return 0

    fourth_previous = 0  # fib4(0)
    third_previous = 0   # fib4(1)
    second_previous = 2  # fib4(2)
    previous = 0         # fib4(3)

    for _ in range(4, index + 1):
        current = (
            previous
            + second_previous
            + third_previous
            + fourth_previous
        )
        fourth_previous = third_previous
        third_previous = second_previous
        second_previous = previous
        previous = current

    return previous
candidate = fib4




METADATA = {}


def check(candidate):
    assert candidate(5) == 4
    assert candidate(8) == 28
    assert candidate(10) == 104
    assert candidate(12) == 386



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
