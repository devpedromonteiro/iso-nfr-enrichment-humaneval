
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Given a grid with N rows and N columns (N >= 2) and a positive integer k,
    each cell of the grid contains a unique value from 1 to N * N.

    Return the lexicographically smallest path of length k, where each step
    moves to a horizontally or vertically adjacent cell.
    """

    grid_size = len(grid)
    value_to_position = {}

    for row_index in range(grid_size):
        for column_index in range(grid_size):
            cell_value = grid[row_index][column_index]
            value_to_position[cell_value] = (row_index, column_index)

    def get_neighbors(row, column):
        neighbors = []

        if row > 0:
            neighbors.append((row - 1, column))
        if row < grid_size - 1:
            neighbors.append((row + 1, column))
        if column > 0:
            neighbors.append((row, column - 1))
        if column < grid_size - 1:
            neighbors.append((row, column + 1))

        return neighbors

    def can_reach_value(start_positions, target_value):
        target_row, target_column = value_to_position[target_value]

        for row, column in start_positions:
            for neighbor_row, neighbor_column in get_neighbors(row, column):
                if neighbor_row == target_row and neighbor_column == target_column:
                    return True

        return False

    current_positions = {
        value_to_position[cell_value]
        for cell_value in range(1, grid_size * grid_size + 1)
    }

    path_values = []

    for step_index in range(k):
        for candidate_value in range(1, grid_size * grid_size + 1):
            if step_index == 0:
                if value_to_position[candidate_value] in current_positions:
                    chosen_value = candidate_value
                    break
            else:
                if can_reach_value(current_positions, candidate_value):
                    chosen_value = candidate_value
                    break

        path_values.append(chosen_value)
        chosen_position = value_to_position[chosen_value]

        if step_index == 0:
            current_positions = {chosen_position}
        else:
            next_positions = set()

            for row, column in current_positions:
                for neighbor_row, neighbor_column in get_neighbors(row, column):
                    if (neighbor_row, neighbor_column) == chosen_position:
                        next_positions.add(chosen_position)

            current_positions = next_positions

    return path_values
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
