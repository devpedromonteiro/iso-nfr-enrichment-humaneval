
import unittest
import re
import sys
import math
import copy


def cycpattern_check(a, b):
    """You are given 2 words. You need to return True if the second word
    or any of its rotations is a substring in the first word.

    cycpattern_check("abcd","abd") => False
    cycpattern_check("hello","ell") => True
    cycpattern_check("whassup","psus") => False
    cycpattern_check("abab","baa") => True
    cycpattern_check("efef","eeff") => False
    cycpattern_check("himenss","simen") => True
    """
    lb = len(b)
    if lb == 0:
        return True
    if lb > len(a):
        return False

    # Any rotation of b is a substring of b+b.
    doubled = b + b

    # Check only rotations of exact length lb.
    for i in range(lb):
        if doubled[i:i + lb] in a:
            return True
    return False
candidate = cycpattern_check


def check(candidate):

    # Check some simple cases
    #assert True, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    #assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert  candidate("xyzw","xyw") == False , "test #0"
    assert  candidate("yello","ell") == True , "test #1"
    assert  candidate("whattup","ptut") == False , "test #2"
    assert  candidate("efef","fee") == True , "test #3"
    assert  candidate("abab","aabb") == False , "test #4"
    assert  candidate("winemtt","tinem") == True , "test #5"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
