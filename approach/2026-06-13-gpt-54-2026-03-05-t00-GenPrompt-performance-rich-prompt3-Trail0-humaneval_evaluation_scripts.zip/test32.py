
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[2] * x^2 + .... + xs[n] * x^n
    Uses Horner's method for better performance and lower allocation.
    """
    result = 0.0
    for coeff in reversed(xs):
        result = result * x + coeff
    return result


def find_zero(xs: list):
    """xs are coefficients of a polynomial.
    find_zero finds x such that poly(x) = 0.
    find_zero returns only one zero point, even if there are many.
    Moreover, find_zero only takes list xs having even number of coefficients
    and largest non-zero coefficient as it guarantees a solution.

    >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2)  # (x - 1) * (x - 2) * (x - 3)
    1.0
    """
    if not xs:
        raise ValueError("xs must not be empty")

    degree = len(xs) - 1
    if degree < 1:
        raise ValueError("polynomial degree must be at least 1")

    leading = xs[-1]
    if leading == 0:
        raise ValueError("largest coefficient must be non-zero")

    # Fast path for linear polynomial: a + bx = 0
    if degree == 1:
        return -xs[0] / xs[1]

    # Cauchy bound: every real root lies in [-B, B]
    an = abs(leading)
    max_coeff = 0.0
    for coeff in xs[:-1]:
        c = abs(coeff)
        if c > max_coeff:
            max_coeff = c
    bound = 1.0 + max_coeff / an

    left = -bound
    right = bound
    f_left = poly(xs, left)
    f_right = poly(xs, right)

    # Given the stated constraints, a root is guaranteed.
    # For odd degree, signs at the endpoints should differ.
    if f_left == 0:
        return left
    if f_right == 0:
        return right

    # Bisection method: bounded resource usage, robust convergence.
    for _ in range(100):
        mid = (left + right) * 0.5
        f_mid = poly(xs, mid)

        if f_mid == 0 or (right - left) <= 1e-12:
            return mid

        if f_left * f_mid <= 0:
            right = mid
            f_right = f_mid
        else:
            left = mid
            f_left = f_mid

    return (left + right) * 0.5
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
