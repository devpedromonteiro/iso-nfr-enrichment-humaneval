
import unittest
import re
import sys
import math
import copy



def common(l1: list, l2: list):
    """Return sorted unique common elements for two lists.
    >>> common([1, 4, 3, 34, 653, 2, 5], [5, 7, 1, 5, 9, 653, 121])
    [1, 5, 653]
    >>> common([5, 3, 2, 8], [3, 2])
    [2, 3]

    """
    if not l1 or not l2:
        return []

    # Build a set from the smaller list to reduce memory usage.
    if len(l1) <= len(l2):
        lookup = set(l1)
        other = l2
    else:
        lookup = set(l2)
        other = l1

    # Collect unique common elements without redundant work.
    result = set()
    for item in other:
        if item in lookup:
            result.add(item)

    return sorted(result)
candidate = common




METADATA = {}


def check(candidate):
    assert candidate([1, 4, 3, 34, 653, 2, 5], [5, 7, 1, 5, 9, 653, 121]) == [1, 5, 653]
    assert candidate([5, 3, 2, 8], [3, 2]) == [2, 3]
    assert candidate([4, 3, 2, 8], [3, 2, 4]) == [2, 3, 4]
    assert candidate([4, 3, 2, 8], []) == []



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
