
import unittest
import re
import sys
import math
import copy


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and
    the second list is a list of integers. Use the two given lists to build the algebraic
    expression and return the evaluation of this expression.

    The expression follows normal Python operator precedence:
    ** > * and // > + and -
    Exponentiation is right-associative.

    Example:
    operator = ['+', '*', '-']
    operand = [2, 3, 4, 5]
    result = 2 + 3 * 4 - 5
    => 9
    """
    n = len(operand)

    # First pass: collapse exponentiation chains right-to-left.
    values = [0] * n
    ops = []
    i = n - 1
    values_count = 0

    while i >= 0:
        value = operand[i]
        while i > 0 and operator[i - 1] == '**':
            i -= 1
            value = operand[i] ** value
        values[values_count] = value
        values_count += 1
        if i > 0:
            ops.append(operator[i - 1])
        i -= 1

    # Reverse the compacted values to restore left-to-right order.
    values = values[:values_count]
    values.reverse()
    ops.reverse()

    # Second pass: evaluate * and // immediately, defer + and -.
    total = 0
    term = values[0]

    for i, op in enumerate(ops):
        nxt = values[i + 1]
        if op == '*':
            term *= nxt
        elif op == '//':
            term //= nxt
        elif op == '+':
            total += term
            term = nxt
        else:  # '-'
            total += term
            term = -nxt

    return total + term
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
