
import unittest
import re
import sys
import math
import copy


def is_nested(string):
    """
    Return True iff the bracket string contains a valid bracket subsequence
    with nesting depth at least 2.

    Since only subsequences are allowed, we just need to know whether there
    exists some point where two '[' can be matched by two later ']':
        [ [ ... ] ... ]

    Equivalent linear scan condition:
    - track how many '[' have been seen so far
    - once we've seen at least two '[', any later ']' can serve as the inner close
    - after that, any later ']' can serve as the outer close

    This is O(n) time and O(1) space.
    """
    opens = 0
    found_inner_close = False

    for ch in string:
        if ch == '[':
            opens += 1
        else:  # ch == ']'
            if found_inner_close:
                return True
            if opens >= 2:
                found_inner_close = True

    return False
candidate = is_nested


def check(candidate):

    # Check some simple cases
    assert candidate('[[]]') == True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('[]]]]]]][[[[[]') == False
    assert candidate('[][]') == False
    assert candidate(('[]')) == False
    assert candidate('[[[[]]]]') == True
    assert candidate('[]]]]]]]]]]') == False
    assert candidate('[][][[]]') == True
    assert candidate('[[]') == False
    assert candidate('[]]') == False
    assert candidate('[[]][[') == True
    assert candidate('[[][]]') == True

    # Check some edge cases that are easy to work out by hand.
    assert candidate('') == False, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate('[[[[[[[[') == False
    assert candidate(']]]]]]]]') == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
