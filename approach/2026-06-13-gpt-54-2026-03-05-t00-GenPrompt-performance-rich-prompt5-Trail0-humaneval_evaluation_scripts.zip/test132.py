
import unittest
import re
import sys
import math
import copy


def is_nested(string):
    """
    Return True iff the bracket string contains a valid bracket subsequence
    with nesting depth at least 2.

    A nested valid subsequence exists exactly when, while scanning left to right,
    we can choose two '[' before two later ']' in order:
        [ [ ... ] ]
    i.e. there exists a subsequence "[[]]".

    This implementation is O(n) time and O(1) space.
    """
    opens = 0          # number of '[' seen so far
    pair_opens = 0     # whether we've seen at least two '[' before current position
    inner_closed = 0   # whether we've formed "[[" followed by a ']'

    for ch in string:
        if ch == '[':
            opens += 1
            if opens >= 2:
                pair_opens = 1
        else:  # ch == ']'
            if pair_opens:
                if inner_closed:
                    return True
                inner_closed = 1

    return False
candidate = is_nested


def check(candidate):

    # Check some simple cases
    assert candidate('[[]]') == True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('[]]]]]]][[[[[]') == False
    assert candidate('[][]') == False
    assert candidate(('[]')) == False
    assert candidate('[[[[]]]]') == True
    assert candidate('[]]]]]]]]]]') == False
    assert candidate('[][][[]]') == True
    assert candidate('[[]') == False
    assert candidate('[]]') == False
    assert candidate('[[]][[') == True
    assert candidate('[[][]]') == True

    # Check some edge cases that are easy to work out by hand.
    assert candidate('') == False, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate('[[[[[[[[') == False
    assert candidate(']]]]]]]]') == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
