
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    """Insert `delimeter` between every two consecutive elements of `numbers`.

    >>> intersperse([], 4)
    []
    >>> intersperse([1, 2, 3], 4)
    [1, 4, 2, 4, 3]
    """
    n = len(numbers)
    if n == 0:
        return []

    result = [0] * (2 * n - 1)
    result[0::2] = numbers
    result[1::2] = [delimeter] * (n - 1)
    return result
candidate = intersperse




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([], 7) == []
    assert candidate([5, 6, 3, 2], 8) == [5, 8, 6, 8, 3, 8, 2]
    assert candidate([2, 2, 2], 2) == [2, 2, 2, 2, 2]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
