
import unittest
import re
import sys
import math
import copy


def decimal_to_binary(decimal):
    if decimal == 0:
        return "db0db"

    negative = decimal < 0
    n = -decimal if negative else decimal
    bits = []

    while n:
        bits.append('1' if n & 1 else '0')
        n >>= 1

    if negative:
        bits.append('-')

    bits.reverse()
    return "db" + "".join(bits) + "db"
candidate = decimal_to_binary


def check(candidate):

    # Check some simple cases
    assert candidate(0) == "db0db"
    assert candidate(32) == "db100000db"
    assert candidate(103) == "db1100111db"
    assert candidate(15) == "db1111db", "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
