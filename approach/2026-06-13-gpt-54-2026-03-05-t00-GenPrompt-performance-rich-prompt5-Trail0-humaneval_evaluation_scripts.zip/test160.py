
import unittest
import re
import sys
import math
import copy


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and
    the second list is a list of integers. Use the two given lists to build the algebraic
    expression and return the evaluation of this expression.

    Supported operators:
    +, -, *, //, **

    The evaluation follows normal Python operator precedence.
    """
    n = len(operand)
    if n == 0:
        raise ValueError("operand must not be empty")
    if len(operator) != n - 1:
        raise ValueError("operator length must be operand length minus one")

    # First pass: collapse exponentiation right-to-left, since ** is right-associative.
    values = [0] * n
    ops = [None] * (n - 1)
    v_count = 0
    o_count = 0

    i = n - 1
    current = operand[i]

    while i > 0:
        op = operator[i - 1]
        left = operand[i - 1]

        if op == '**':
            current = left ** current
        else:
            values[v_count] = current
            v_count += 1
            ops[o_count] = op
            o_count += 1
            current = left
        i -= 1

    values[v_count] = current
    v_count += 1

    # Reverse the compacted arrays in-place logically by reading backward.
    # Second pass: handle * and // left-to-right.
    terms = [0] * v_count
    term_ops = [None] * o_count
    t_count = 0
    to_count = 0

    acc = values[v_count - 1]
    op_idx = o_count - 1
    val_idx = v_count - 2

    while op_idx >= 0:
        op = ops[op_idx]
        val = values[val_idx]

        if op == '*':
            acc *= val
        elif op == '//':
            acc //= val
        else:
            terms[t_count] = acc
            t_count += 1
            term_ops[to_count] = op
            to_count += 1
            acc = val

        op_idx -= 1
        val_idx -= 1

    terms[t_count] = acc
    t_count += 1

    # Third pass: handle + and - left-to-right.
    result = terms[t_count - 1]
    op_idx = to_count - 1
    val_idx = t_count - 2

    while op_idx >= 0:
        op = term_ops[op_idx]
        val = terms[val_idx]

        if op == '+':
            result += val
        else:  # op == '-'
            result -= val

        op_idx -= 1
        val_idx -= 1

    return result
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
