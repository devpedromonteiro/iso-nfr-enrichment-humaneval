
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Given a grid with N rows and N columns (N >= 2) and a positive integer k,
    each cell of the grid contains a value. Every integer in the range [1, N * N]
    inclusive appears exactly once on the cells of the grid.

    Return the lexicographically minimum path of length k.
    """
    n = len(grid)

    # Map each value to its position for O(1) lookup by value.
    pos = [None] * (n * n + 1)
    for r in range(n):
        row = grid[r]
        for c, v in enumerate(row):
            pos[v] = (r, c)

    # The first value of the optimal path must be the smallest possible value
    # from which a path of length k exists. Since revisiting is allowed and the
    # grid has at least 2 cells, any cell can generate a path of any length >= 1
    # by bouncing with a neighbor. Therefore the first value is always 1.
    start_r, start_c = pos[1]
    path = [1]

    if k == 1:
        return path

    # Precompute neighbors once to avoid repeated boundary checks/allocation.
    neighbors = [[None] * n for _ in range(n)]
    for r in range(n):
        for c in range(n):
            nb = []
            if r > 0:
                nb.append((r - 1, c))
            if r + 1 < n:
                nb.append((r + 1, c))
            if c > 0:
                nb.append((r, c - 1))
            if c + 1 < n:
                nb.append((r, c + 1))
            neighbors[r][c] = nb

    cur_r, cur_c = start_r, start_c

    # Greedy is optimal here:
    # for each next step, choose the neighboring cell with minimum value.
    # Since future paths always exist from any chosen neighbor (revisiting allowed),
    # lexicographic minimization reduces to minimizing each next element.
    for _ in range(1, k):
        best_r, best_c = neighbors[cur_r][cur_c][0]
        best_val = grid[best_r][best_c]

        for nr, nc in neighbors[cur_r][cur_c][1:]:
            v = grid[nr][nc]
            if v < best_val:
                best_val = v
                best_r, best_c = nr, nc

        path.append(best_val)
        cur_r, cur_c = best_r, best_c

    return path
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
