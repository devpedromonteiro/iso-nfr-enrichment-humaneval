
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def parse_music(music_string: str) -> List[int]:
    """Input to this function is a string representing musical notes in a special ASCII format.
    Your task is to parse this string and return list of integers corresponding to how many beats each
    note lasts.

    Legend:
    'o'  - whole note, lasts four beats
    'o|' - half note, lasts two beats
    '.|' - quarter note, lasts one beat

    >>> parse_music('o o| .| o| o| .| .| .| .| o o')
    [4, 2, 1, 2, 2, 1, 1, 1, 1, 4, 4]
    """
    result: List[int] = []
    i = 0
    n = len(music_string)

    while i < n:
        c = music_string[i]

        if c == ' ':
            i += 1
        elif c == 'o':
            if i + 1 < n and music_string[i + 1] == '|':
                result.append(2)
                i += 2
            else:
                result.append(4)
                i += 1
        elif c == '.':
            if i + 1 < n and music_string[i + 1] == '|':
                result.append(1)
                i += 2
            else:
                raise ValueError(f"Invalid note at position {i}: expected '.|'")
        else:
            raise ValueError(f"Invalid character at position {i}: {c!r}")

    return result
candidate = parse_music




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == []
    assert candidate('o o o o') == [4, 4, 4, 4]
    assert candidate('.| .| .| .|') == [1, 1, 1, 1]
    assert candidate('o| o| .| .| o o o o') == [2, 2, 1, 1, 4, 4, 4, 4]
    assert candidate('o| .| o| .| o o| o o|') == [2, 1, 2, 1, 4, 2, 4, 2]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
