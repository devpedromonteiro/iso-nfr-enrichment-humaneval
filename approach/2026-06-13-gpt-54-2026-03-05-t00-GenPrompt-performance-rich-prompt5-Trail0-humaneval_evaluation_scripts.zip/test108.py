
import unittest
import re
import sys
import math
import copy


def count_nums(arr):
    def digit_sum(n):
        if n == 0:
            return 0

        sign = -1 if n < 0 else 1
        n = abs(n)

        total = 0
        first = True
        while n:
            digit = n % 10
            n //= 10
            if n == 0 and first:
                total += sign * digit
            else:
                total += digit
            first = False
        return total

    count = 0
    for x in arr:
        if digit_sum(x) > 0:
            count += 1
    return count
candidate = count_nums


def check(candidate):

    # Check some simple cases
    assert candidate([]) == 0
    assert candidate([-1, -2, 0]) == 0
    assert candidate([1, 1, 2, -2, 3, 4, 5]) == 6
    assert candidate([1, 6, 9, -6, 0, 1, 5]) == 5
    assert candidate([1, 100, 98, -7, 1, -1]) == 4
    assert candidate([12, 23, 34, -45, -56, 0]) == 5
    assert candidate([-0, 1**0]) == 1
    assert candidate([1]) == 1

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
