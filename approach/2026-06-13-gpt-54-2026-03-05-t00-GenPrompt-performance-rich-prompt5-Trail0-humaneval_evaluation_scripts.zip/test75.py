
import unittest
import re
import sys
import math
import copy


def is_multiply_prime(a):
    """Return True if a is the product of exactly 3 primes, else False."""
    if a < 8:  # smallest product of 3 primes is 2*2*2
        return False

    prime_factors = 0
    n = a
    d = 2

    while d * d <= n and prime_factors <= 3:
        while n % d == 0:
            prime_factors += 1
            n //= d
            if prime_factors > 3:
                return False
        d += 1

    if n > 1:
        prime_factors += 1

    return prime_factors == 3
candidate = is_multiply_prime


def check(candidate):

    assert candidate(5) == False
    assert candidate(30) == True
    assert candidate(8) == True
    assert candidate(10) == False
    assert candidate(125) == True
    assert candidate(3 * 5 * 7) == True
    assert candidate(3 * 6 * 7) == False
    assert candidate(9 * 9 * 9) == False
    assert candidate(11 * 9 * 9) == False
    assert candidate(11 * 13 * 7) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
