
import unittest
import re
import sys
import math
import copy


def words_in_sentence(sentence):
    """
    Return a string containing only the words whose lengths are prime numbers,
    preserving their original order.

    Example 1:
        Input: sentence = "This is a test"
        Output: "is"

    Example 2:
        Input: sentence = "lets go for swimming"
        Output: "go for"
    """

    def is_prime(number):
        if number < 2:
            return False

        for divisor in range(2, int(number ** 0.5) + 1):
            if number % divisor == 0:
                return False

        return True

    words = sentence.split()
    words_with_prime_length = []

    for word in words:
        if is_prime(len(word)):
            words_with_prime_length.append(word)

    return " ".join(words_with_prime_length)
candidate = words_in_sentence


def check(candidate):

    # Check some simple cases
    assert candidate("This is a test") == "is"
    assert candidate("lets go for swimming") == "go for"
    assert candidate("there is no place available here") == "there is no place"
    assert candidate("Hi I am Hussein") == "Hi am Hussein"
    assert candidate("go for it") == "go for it"

    # Check some edge cases that are easy to work out by hand.
    assert candidate("here") == ""
    assert candidate("here is") == "is"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
