
import unittest
import re
import sys
import math
import copy


def reverse_delete(text, characters_to_remove):
    """Remove all characters from `text` that appear in `characters_to_remove`,
    then return the filtered string and whether it is a palindrome.

    Examples:
        reverse_delete("abcde", "ae") -> ("bcd", False)
        reverse_delete("abcdef", "b") -> ("acdef", False)
        reverse_delete("abcdedcba", "ab") -> ("cdedc", True)
    """
    removable_characters = set(characters_to_remove)

    filtered_text = "".join(
        character for character in text
        if character not in removable_characters
    )

    is_palindrome = filtered_text == filtered_text[::-1]

    return filtered_text, is_palindrome
candidate = reverse_delete


def check(candidate):

    assert candidate("abcde","ae") == ('bcd',False)
    assert candidate("abcdef", "b") == ('acdef',False)
    assert candidate("abcdedcba","ab") == ('cdedc',True)
    assert candidate("dwik","w") == ('dik',False)
    assert candidate("a","a") == ('',True)
    assert candidate("abcdedcba","") == ('abcdedcba',True)
    assert candidate("abcdedcba","v") == ('abcdedcba',True)
    assert candidate("vabba","v") == ('abba',True)
    assert candidate("mamma", "mia") == ("", True)


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
