
import unittest
import re
import sys
import math
import copy


def encode(message):
    """
    Encode a message by:
    1. Swapping the case of every letter.
    2. Replacing each vowel with the letter two places ahead
       in the alphabet, preserving the swapped case.

    Assumes the input contains only letters and spaces.

    Examples:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """
    vowel_replacements = {
        "a": "c",
        "e": "g",
        "i": "k",
        "o": "q",
        "u": "w",
    }

    encoded_characters = []

    for character in message:
        swapped_character = character.swapcase()
        lowercase_character = swapped_character.lower()

        if lowercase_character in vowel_replacements:
            replacement = vowel_replacements[lowercase_character]
            if swapped_character.isupper():
                encoded_characters.append(replacement.upper())
            else:
                encoded_characters.append(replacement)
        else:
            encoded_characters.append(swapped_character)

    return "".join(encoded_characters)
candidate = encode


def check(candidate):

    # Check some simple cases
    assert candidate('TEST') == 'tgst', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('Mudasir') == 'mWDCSKR', "This prints if this assert fails 2 (good for debugging!)"
    assert candidate('YES') == 'ygs', "This prints if this assert fails 3 (good for debugging!)"
    
    # Check some edge cases that are easy to work out by hand.
    assert candidate('This is a message') == 'tHKS KS C MGSSCGG', "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate("I DoNt KnOw WhAt tO WrItE") == 'k dQnT kNqW wHcT Tq wRkTg', "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
