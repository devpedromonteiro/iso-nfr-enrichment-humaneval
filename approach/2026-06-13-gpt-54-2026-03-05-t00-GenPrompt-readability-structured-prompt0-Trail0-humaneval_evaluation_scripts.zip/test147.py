
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    Return the number of index triples (i, j, k), with i < j < k, such that
    a[i] + a[j] + a[k] is divisible by 3, where:

        a[x] = x * x - x + 1   for 1 <= x <= n

    Observation:
    Since divisibility by 3 depends only on remainders modulo 3, we analyze:

        a[x] = x^2 - x + 1

    For x modulo 3:
        x % 3 == 0  -> a[x] % 3 == 1
        x % 3 == 1  -> a[x] % 3 == 1
        x % 3 == 2  -> a[x] % 3 == 0

    So every array value is either:
        - remainder 1, when index % 3 is 0 or 1
        - remainder 0, when index % 3 is 2

    A triple sum is divisible by 3 only in these cases:
        1) three values with remainder 0
        2) three values with remainder 1

    Therefore, if:
        count_remainder_0 = number of indices x in [1..n] where x % 3 == 2
        count_remainder_1 = n - count_remainder_0

    then the answer is:
        C(count_remainder_0, 3) + C(count_remainder_1, 3)
    """

    def combinations_of_three(count):
        """Return the number of ways to choose 3 items from count items."""
        if count < 3:
            return 0
        return count * (count - 1) * (count - 2) // 6

    count_remainder_0 = (n + 1) // 3
    count_remainder_1 = n - count_remainder_0

    return (
        combinations_of_three(count_remainder_0)
        + combinations_of_three(count_remainder_1)
    )
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
