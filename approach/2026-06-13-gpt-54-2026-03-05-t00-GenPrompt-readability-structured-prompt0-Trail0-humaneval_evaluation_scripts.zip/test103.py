
import unittest
import re
import sys
import math
import copy


def rounded_avg(start, end):
    """Return the rounded average of all integers from start to end as binary.

    If start is greater than end, return -1.
    """
    if start > end:
        return -1

    total_numbers = end - start + 1
    total_sum = (start + end) * total_numbers / 2
    rounded_average = round(total_sum / total_numbers)

    return bin(rounded_average)
candidate = rounded_avg


def check(candidate):

    # Check some simple cases
    assert candidate(1, 5) == "0b11"
    assert candidate(7, 13) == "0b1010"
    assert candidate(964,977) == "0b1111001010"
    assert candidate(996,997) == "0b1111100100"
    assert candidate(560,851) == "0b1011000010"
    assert candidate(185,546) == "0b101101110"
    assert candidate(362,496) == "0b110101101"
    assert candidate(350,902) == "0b1001110010"
    assert candidate(197,233) == "0b11010111"


    # Check some edge cases that are easy to work out by hand.
    assert candidate(7, 5) == -1
    assert candidate(5, 1) == -1
    assert candidate(5, 5) == "0b101"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
