
import unittest
import re
import sys
import math
import copy


def is_multiply_prime(number):
    """Return True if number is the product of exactly three primes, else False."""
    if number < 2:
        return False

    prime_factors_found = 0
    divisor = 2
    remaining_value = number

    while divisor * divisor <= remaining_value and prime_factors_found <= 3:
        while remaining_value % divisor == 0:
            prime_factors_found += 1
            remaining_value //= divisor

            if prime_factors_found > 3:
                return False

        divisor += 1

    if remaining_value > 1:
        prime_factors_found += 1

    return prime_factors_found == 3
candidate = is_multiply_prime


def check(candidate):

    assert candidate(5) == False
    assert candidate(30) == True
    assert candidate(8) == True
    assert candidate(10) == False
    assert candidate(125) == True
    assert candidate(3 * 5 * 7) == True
    assert candidate(3 * 6 * 7) == False
    assert candidate(9 * 9 * 9) == False
    assert candidate(11 * 9 * 9) == False
    assert candidate(11 * 13 * 7) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
