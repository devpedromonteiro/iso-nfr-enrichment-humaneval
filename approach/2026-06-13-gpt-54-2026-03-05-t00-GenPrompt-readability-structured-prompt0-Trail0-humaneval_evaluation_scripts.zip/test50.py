
import unittest
import re
import sys
import math
import copy



def encode_shift(s: str):
    """
    returns encoded string by shifting every character by 5 in the alphabet.
    """
    return "".join([chr(((ord(ch) + 5 - ord("a")) % 26) + ord("a")) for ch in s])


def encode_shift(text: str) -> str:
    """
    Return a new string where each lowercase letter is shifted forward by 5.
    """
    shifted_characters = []

    for character in text:
        shifted_position = (ord(character) - ord("a") + 5) % 26
        shifted_character = chr(ord("a") + shifted_position)
        shifted_characters.append(shifted_character)

    return "".join(shifted_characters)


def decode_shift(text: str) -> str:
    """
    Return the original string by shifting each lowercase letter backward by 5.
    """
    original_characters = []

    for character in text:
        original_position = (ord(character) - ord("a") - 5) % 26
        original_character = chr(ord("a") + original_position)
        original_characters.append(original_character)

    return "".join(original_characters)
candidate = decode_shift




METADATA = {}


def check(candidate):
    from random import randint, choice
    import copy
    import string

    letters = string.ascii_lowercase
    for _ in range(100):
        str = ''.join(choice(letters) for i in range(randint(10, 20)))
        encoded_str = encode_shift(str)
        assert candidate(copy.deepcopy(encoded_str)) == str



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
