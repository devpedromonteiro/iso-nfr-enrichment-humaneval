
import unittest
import re
import sys
import math
import copy

from typing import List, Any


from typing import Any, List


def filter_integers(values: List[Any]) -> List[int]:
    """Return only integer values from the given list.

    Note:
        Booleans are excluded, even though `bool` is a subclass of `int`.

    >>> filter_integers(['a', 3.14, 5])
    [5]
    >>> filter_integers([1, 2, 3, 'abc', {}, []])
    [1, 2, 3]
    """
    integers = []

    for value in values:
        is_integer = isinstance(value, int)
        is_boolean = isinstance(value, bool)

        if is_integer and not is_boolean:
            integers.append(value)

    return integers
candidate = filter_integers




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == []
    assert candidate([4, {}, [], 23.2, 9, 'adasd']) == [4, 9]
    assert candidate([3, 'c', 3, 3, 'a', 'b']) == [3, 3, 3]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
