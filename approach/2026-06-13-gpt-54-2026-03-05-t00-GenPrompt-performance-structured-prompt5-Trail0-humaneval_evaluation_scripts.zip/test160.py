
import unittest
import re
import sys
import math
import copy


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and
    the second list is a list of integers. Use the two given lists to build the algebraic
    expression and return the evaluation of this expression.

    Supported operators:
    +, -, *, //, **

    The evaluation follows normal Python operator precedence.
    """
    # Precedence groups, from highest to lowest
    precedence_levels = (
        {"**"},
        {"*", "//"},
        {"+", "-"},
    )

    nums = operand[:]
    ops = operator[:]

    for level in precedence_levels:
        new_nums = [nums[0]]
        new_ops = []

        for i, op in enumerate(ops):
            if op in level:
                left = new_nums.pop()
                right = nums[i + 1]

                if op == "+":
                    new_nums.append(left + right)
                elif op == "-":
                    new_nums.append(left - right)
                elif op == "*":
                    new_nums.append(left * right)
                elif op == "//":
                    new_nums.append(left // right)
                else:  # op == "**"
                    new_nums.append(left ** right)
            else:
                new_ops.append(op)
                new_nums.append(nums[i + 1])

        nums = new_nums
        ops = new_ops

    return nums[0]
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
