
import unittest

from typing import List


from typing import List


WHOLE_NOTE = "o"
HALF_NOTE = "o|"
QUARTER_NOTE = ".|"

BEATS_BY_NOTE = {
    WHOLE_NOTE: 4,
    HALF_NOTE: 2,
    QUARTER_NOTE: 1,
}


def parse_music(music_string: str) -> List[int]:
    """Parse a space-separated ASCII music string into note durations in beats.

    Legend:
    - 'o'  : whole note   -> 4 beats
    - 'o|' : half note    -> 2 beats
    - '.|' : quarter note -> 1 beat

    >>> parse_music('o o| .| o| o| .| .| .| .| o o')
    [4, 2, 1, 2, 2, 1, 1, 1, 1, 4, 4]
    """
    note_symbols = music_string.split()
    beats_per_note: List[int] = []

    for note_symbol in note_symbols:
        beats_per_note.append(BEATS_BY_NOTE[note_symbol])

    return beats_per_note
candidate = parse_music


class Test(unittest.TestCase):
    def test(self):
        assert candidate(".| o .| o o o o| o| o| .| o o o .| .|") == [1, 4, 1, 4, 4, 4, 2, 2, 2, 1, 4, 4, 4, 1, 1]
        assert candidate(".| o o| o| o .| .| .| o .| o o| o| .| o| o o| o| .|") == [1, 4, 2, 2, 4, 1, 1, 1, 4, 1, 4, 2, 2, 1, 2, 4, 2, 2, 1]
        assert candidate("o| o o| .| .| .| .| o| o| .| o o| o| o| .| .| o|") == [2, 4, 2, 1, 1, 1, 1, 2, 2, 1, 4, 2, 2, 2, 1, 1, 2]
        assert candidate("o .| o .| o o o| o| o| o| o o .| o|") == [4, 1, 4, 1, 4, 4, 2, 2, 2, 2, 4, 4, 1, 2]
        assert candidate("o| o| o| o o o .| .| o o| o| o o| o o| o|") == [2, 2, 2, 4, 4, 4, 1, 1, 4, 2, 2, 4, 2, 4, 2, 2]
        assert candidate("o o| o .| o o| .| o| .| .| o o| o| o o| o| .|") == [4, 2, 4, 1, 4, 2, 1, 2, 1, 1, 4, 2, 2, 4, 2, 2, 1]
        assert candidate("o| .| .| o| o o o o o|") == [2, 1, 1, 2, 4, 4, 4, 4, 2]
        assert candidate("o o| o o o| .| o| o .|") == [4, 2, 4, 4, 2, 1, 2, 4, 1]
        assert candidate("o| o") == [2, 4]
        assert candidate("o o o| .| o| .| .| .| o| o o") == [4, 4, 2, 1, 2, 1, 1, 1, 2, 4, 4]
        assert candidate('o| o| .| .| o o o o') == [2, 2, 1, 1, 4, 4, 4, 4]
        assert candidate("o o o") == [4, 4, 4]
        assert candidate("o .| o| o| .| o .| o| .| o|") == [4, 1, 2, 2, 1, 4, 1, 2, 1, 2]
        assert candidate(".| .| o o| .| o .| o| o o| o o| o| .| o| o .|") == [1, 1, 4, 2, 1, 4, 1, 2, 4, 2, 4, 2, 2, 1, 2, 4, 1]
        assert candidate("o") == [4]
        assert candidate("o| .| o o| .| .| o .| o .| o .| .| o o .|") == [2, 1, 4, 2, 1, 1, 4, 1, 4, 1, 4, 1, 1, 4, 4, 1]
        assert candidate(".| o| .| o| o .| o| o| .| o| o| o| .| o|") == [1, 2, 1, 2, 4, 1, 2, 2, 1, 2, 2, 2, 1, 2]
        assert candidate(".| .|") == [1, 1]
        assert candidate(".| .| o .| o| o o| o o| o .| .| o o o .| o") == [1, 1, 4, 1, 2, 4, 2, 4, 2, 4, 1, 1, 4, 4, 4, 1, 4]
        assert candidate("o o .| o| o o o o o o| o o| .| o") == [4, 4, 1, 2, 4, 4, 4, 4, 4, 2, 4, 2, 1, 4]
        assert candidate(".| o o| .| .|") == [1, 4, 2, 1, 1]
        assert candidate(".| o o| o| .| o .| .| o") == [1, 4, 2, 2, 1, 4, 1, 1, 4]
        assert candidate("o| o o| .| .| o o o| .| o .| o| o") == [2, 4, 2, 1, 1, 4, 4, 2, 1, 4, 1, 2, 4]
        assert candidate("o| o o| o| .| .| .| .| o|") == [2, 4, 2, 2, 1, 1, 1, 1, 2]
        assert candidate("o|") == [2]
        assert candidate("o| o o o o o o .| o| o| o") == [2, 4, 4, 4, 4, 4, 4, 1, 2, 2, 4]
        assert candidate("o| o| o| o o o o o| .|") == [2, 2, 2, 4, 4, 4, 4, 2, 1]
        assert candidate('o| .| o| .| o o| o o|') == [2, 1, 2, 1, 4, 2, 4, 2]
        assert candidate("o| o| .| .| o| .| o| o o| .| o| o| o|") == [2, 2, 1, 1, 2, 1, 2, 4, 2, 1, 2, 2, 2]
        assert candidate("o| .| .| o .| o") == [2, 1, 1, 4, 1, 4]
        assert candidate("o o o .| o| o| o") == [4, 4, 4, 1, 2, 2, 4]
        assert candidate("o| .| o| .| o| o| o| .| o| .| o| o| o| o .| o o| o|") == [2, 1, 2, 1, 2, 2, 2, 1, 2, 1, 2, 2, 2, 4, 1, 4, 2, 2]
        assert candidate("o| o| o o| o| o o| o| .| .| o o .| .| o o o .|") == [2, 2, 4, 2, 2, 4, 2, 2, 1, 1, 4, 4, 1, 1, 4, 4, 4, 1]
        assert candidate(".| o| .| o o .| .| o o| o| o o| .| .| .|") == [1, 2, 1, 4, 4, 1, 1, 4, 2, 2, 4, 2, 1, 1, 1]
        assert candidate(".|") == [1]
        assert candidate("o| .| o| o| o| o| o .|") == [2, 1, 2, 2, 2, 2, 4, 1]
        assert candidate(".| .| o o .| o|") == [1, 1, 4, 4, 1, 2]
        assert candidate("o o o .| o o| o| o .| o o o .| o o| o o") == [4, 4, 4, 1, 4, 2, 2, 4, 1, 4, 4, 4, 1, 4, 2, 4, 4]
        assert candidate(".| o") == [1, 4]
        assert candidate("o| .| o| o| o| o| o| o| o| .| o| o| o .| o o| .| o o|") == [2, 1, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 4, 1, 4, 2, 1, 4, 2]
        assert candidate("o o o| o") == [4, 4, 2, 4]
        assert candidate("o| o .| o| o| o| o .| .| o| .| o| .|") == [2, 4, 1, 2, 2, 2, 4, 1, 1, 2, 1, 2, 1]
        assert candidate("o o o o| o| o o| o") == [4, 4, 4, 2, 2, 4, 2, 4]
        assert candidate("o| .| o| o o o| o o o| o .| .| .| o .|") == [2, 1, 2, 4, 4, 2, 4, 4, 2, 4, 1, 1, 1, 4, 1]
        assert candidate(".| .| o| o| o o o| o| o o| o o .| .| o o o") == [1, 1, 2, 2, 4, 4, 2, 2, 4, 2, 4, 4, 1, 1, 4, 4, 4]
        assert candidate(".| o| o .| o|") == [1, 2, 4, 1, 2]
        assert candidate("o| o .| o o| .|") == [2, 4, 1, 4, 2, 1]
        assert candidate(".| o .| o .| o| .| o .| o|") == [1, 4, 1, 4, 1, 2, 1, 4, 1, 2]
        assert candidate("o| o| o|") == [2, 2, 2]
        assert candidate(".| o| o .| .|") == [1, 2, 4, 1, 1]
        assert candidate("o| .| .| .| .|") == [2, 1, 1, 1, 1]
        assert candidate("o o| o o .| o| o|") == [4, 2, 4, 4, 1, 2, 2]
        assert candidate(".| o| o o .| .| .| o .| o| .| .| .| o| o| o o .| .|") == [1, 2, 4, 4, 1, 1, 1, 4, 1, 2, 1, 1, 1, 2, 2, 4, 4, 1, 1]
        assert candidate(".| .| o| o o o .| o|") == [1, 1, 2, 4, 4, 4, 1, 2]
        assert candidate("o| .| o| o| .| o| o| o .| .| .| o| o o| .| o .| .|") == [2, 1, 2, 2, 1, 2, 2, 4, 1, 1, 1, 2, 4, 2, 1, 4, 1, 1]
        assert candidate("o .| .| o .| o| .| o|") == [4, 1, 1, 4, 1, 2, 1, 2]
        assert candidate("o .| .|") == [4, 1, 1]
        assert candidate("o| .| o| o") == [2, 1, 2, 4]
        assert candidate(".| o .| o o| .| o o o|") == [1, 4, 1, 4, 2, 1, 4, 4, 2]
        assert candidate(".| .| o| .| .| o| o| .| o| o o| .| .| .|") == [1, 1, 2, 1, 1, 2, 2, 1, 2, 4, 2, 1, 1, 1]
        assert candidate(".| o| o|") == [1, 2, 2]
        assert candidate("o .| o o| .| o| .| o o| .| o") == [4, 1, 4, 2, 1, 2, 1, 4, 2, 1, 4]
        assert candidate("o o o| o| o| o| o| o| o|") == [4, 4, 2, 2, 2, 2, 2, 2, 2]
        assert candidate(".| o| o| o| o o| o| o| o| o o| .| o") == [1, 2, 2, 2, 4, 2, 2, 2, 2, 4, 2, 1, 4]
        assert candidate("o .|") == [4, 1]
        assert candidate(".| .| o .| o| .| o .| o| o o| o|") == [1, 1, 4, 1, 2, 1, 4, 1, 2, 4, 2, 2]
        assert candidate("o .| o o .| o o| o| o o .|") == [4, 1, 4, 4, 1, 4, 2, 2, 4, 4, 1]
        assert candidate("o| o .| .| o .| o o| .| o o| o| o") == [2, 4, 1, 1, 4, 1, 4, 2, 1, 4, 2, 2, 4]
        assert candidate("o o| .| .| o| .| .| .|") == [4, 2, 1, 1, 2, 1, 1, 1]
        assert candidate("o o| .| .|") == [4, 2, 1, 1]
        assert candidate(".| o| o o .| o|") == [1, 2, 4, 4, 1, 2]
        assert candidate('.| .| .| .|') == [1, 1, 1, 1]
        assert candidate(".| .| .| o| .| o| .| o o| o") == [1, 1, 1, 2, 1, 2, 1, 4, 2, 4]
        assert candidate("o| o| o| o .| o o| o|") == [2, 2, 2, 4, 1, 4, 2, 2]
        assert candidate(".| .| .| o .| .| o| o o .| o| o o .| o| o| .|") == [1, 1, 1, 4, 1, 1, 2, 4, 4, 1, 2, 4, 4, 1, 2, 2, 1]
        assert candidate(".| o| o") == [1, 2, 4]
        assert candidate("o| o| .| o .|") == [2, 2, 1, 4, 1]
        assert candidate(".| .| o o| .| o o .| o| o .| o o| .| o o| o o| o o") == [1, 1, 4, 2, 1, 4, 4, 1, 2, 4, 1, 4, 2, 1, 4, 2, 4, 2, 4, 4]
        assert candidate("o .| o|") == [4, 1, 2]
        assert candidate(".| o o| o") == [1, 4, 2, 4]
        assert candidate("o| .| o| .| o o o| .|") == [2, 1, 2, 1, 4, 4, 2, 1]
        assert candidate('o o o o') == [4, 4, 4, 4]
        assert candidate("o| .| o o| .| o .| o o .| o| .| o| o| .|") == [2, 1, 4, 2, 1, 4, 1, 4, 4, 1, 2, 1, 2, 2, 1]
        assert candidate(".| o| .| o| o| .| o .| o") == [1, 2, 1, 2, 2, 1, 4, 1, 4]
        assert candidate('') == []
        assert candidate(".| o o o .|") == [1, 4, 4, 4, 1]
        assert candidate(".| .| o| .| o|") == [1, 1, 2, 1, 2]
        assert candidate("o o o .| o|") == [4, 4, 4, 1, 2]
        assert candidate(".| .| o o| o| .| o .| .| o .| .| .| o|") == [1, 1, 4, 2, 2, 1, 4, 1, 1, 4, 1, 1, 1, 2]
        assert candidate("o o .|") == [4, 4, 1]
        assert candidate(".| o o o o o o o o| .| o o .| o o| o|") == [1, 4, 4, 4, 4, 4, 4, 4, 2, 1, 4, 4, 1, 4, 2, 2]
        assert candidate("o| o .| o|") == [2, 4, 1, 2]
        assert candidate(".| .| o o| o o o o o| .| .| o| .| .| o| .| o| .| o|") == [1, 1, 4, 2, 4, 4, 4, 4, 2, 1, 1, 2, 1, 1, 2, 1, 2, 1, 2]
        assert candidate("o o .| o| o o o o| .| o o o o| o .|") == [4, 4, 1, 2, 4, 4, 4, 2, 1, 4, 4, 4, 2, 4, 1]
        assert candidate("o o o o| o o|") == [4, 4, 4, 2, 4, 2]
        assert candidate("o .| o o| o o o o o| .| o o o| .|") == [4, 1, 4, 2, 4, 4, 4, 4, 2, 1, 4, 4, 2, 1]
        assert candidate(".| o| o o o| o o|") == [1, 2, 4, 4, 2, 4, 2]
        assert candidate("o o| o| .|") == [4, 2, 2, 1]
        assert candidate(".| o| o| .| o o| o o| o o .| o| o| o| o o .|") == [1, 2, 2, 1, 4, 2, 4, 2, 4, 4, 1, 2, 2, 2, 4, 4, 1]
        assert candidate(".| o| .| o .| o| o o .| o| o| o o .| o o .|") == [1, 2, 1, 4, 1, 2, 4, 4, 1, 2, 2, 4, 4, 1, 4, 4, 1]
        assert candidate(".| o| o o| o") == [1, 2, 4, 2, 4]
        assert candidate("o| o| o .| o| o o o| o o .|") == [2, 2, 4, 1, 2, 4, 4, 2, 4, 4, 1]
        assert candidate(".| o o| .| o o o o| o .| o") == [1, 4, 2, 1, 4, 4, 4, 2, 4, 1, 4]
        assert candidate(".| o| .| o .| o .| .| o .| o o o .| o o .| .|") == [1, 2, 1, 4, 1, 4, 1, 1, 4, 1, 4, 4, 4, 1, 4, 4, 1, 1]
        assert candidate("o .| o| o|") == [4, 1, 2, 2]
        assert candidate(".| o| o| .| o") == [1, 2, 2, 1, 4]
        assert candidate("o| o o| o") == [2, 4, 2, 4]
        assert candidate("o o o o o o| .| o| o .| o o|") == [4, 4, 4, 4, 4, 2, 1, 2, 4, 1, 4, 2]
        assert candidate(".| o| o o|") == [1, 2, 4, 2]
        assert candidate("o| o o|") == [2, 4, 2]
        assert candidate("o o|") == [4, 2]
        assert candidate("o .| .| o") == [4, 1, 1, 4]
        assert candidate(".| .| .| .| o| .| .| o o .| o| o .|") == [1, 1, 1, 1, 2, 1, 1, 4, 4, 1, 2, 4, 1]
        assert candidate("o o o o| o| .| o o| o o .| o .| o|") == [4, 4, 4, 2, 2, 1, 4, 2, 4, 4, 1, 4, 1, 2]
        assert candidate("o o| o| .| .| o| o|") == [4, 2, 2, 1, 1, 2, 2]
        assert candidate(".| o| .| .| .| o .| o| o| o o .| o") == [1, 2, 1, 1, 1, 4, 1, 2, 2, 4, 4, 1, 4]
        assert candidate("o o o .| o o| o| o o .| o| o| o| o") == [4, 4, 4, 1, 4, 2, 2, 4, 4, 1, 2, 2, 2, 4]
        assert candidate("o| .| o| o| .| o| .| o .| .| .| .| o o o| o") == [2, 1, 2, 2, 1, 2, 1, 4, 1, 1, 1, 1, 4, 4, 2, 4]
        assert candidate("o o| .| o| o .| o o| o| o o| o o") == [4, 2, 1, 2, 4, 1, 4, 2, 2, 4, 2, 4, 4]
        assert candidate("o| o .| .| o| .| o| o| o") == [2, 4, 1, 1, 2, 1, 2, 2, 4]
        assert candidate("o o o| o o o| o") == [4, 4, 2, 4, 4, 2, 4]
        assert candidate("o o o| .| o") == [4, 4, 2, 1, 4]
        assert candidate("o .| o| o .| .| .| o o| o") == [4, 1, 2, 4, 1, 1, 1, 4, 2, 4]
        assert candidate(".| o| .|") == [1, 2, 1]
        assert candidate("o| o|") == [2, 2]
        assert candidate(".| .| .| o| o| o o .| o o .| o") == [1, 1, 1, 2, 2, 4, 4, 1, 4, 4, 1, 4]
        assert candidate("o| o o .| o o| o| o o| o o .|") == [2, 4, 4, 1, 4, 2, 2, 4, 2, 4, 4, 1]
        assert candidate("o| o| .| o| .| o o o o| o o| o| .| o o o o|") == [2, 2, 1, 2, 1, 4, 4, 4, 2, 4, 2, 2, 1, 4, 4, 4, 2]
        assert candidate("o o .| o") == [4, 4, 1, 4]

if __name__ == '__main__':
    unittest.main()
