
import unittest


def match_parens(strings):
    """
    You are given a list of two strings, both strings consist of open
    parentheses '(' or close parentheses ')' only.

    Check whether concatenating the two strings in either order can produce
    a balanced parentheses string.

    Return:
        'Yes' if a valid order exists, otherwise 'No'
    """

    def is_balanced(parentheses_text):
        balance = 0

        for character in parentheses_text:
            if character == '(':
                balance += 1
            else:
                balance -= 1

            if balance < 0:
                return False

        return balance == 0

    first_string, second_string = strings

    if is_balanced(first_string + second_string):
        return 'Yes'

    if is_balanced(second_string + first_string):
        return 'Yes'

    return 'No'
candidate = match_parens


class Test(unittest.TestCase):
    def test(self):
        assert candidate((')())', '(()()(')) == 'Yes'
        assert candidate(('((((', ')')) == 'No'
        assert candidate(('()(', '())')) == 'Yes'
        assert candidate(('())', '((((')) == 'No'
        assert candidate(('(()(', '()(')) == 'No'
        assert candidate(('())', '(()()(')) == 'No'
        assert candidate([')', ')']) == 'No'
        assert candidate(('()(', ')')) == 'Yes'
        assert candidate(('(()(())', '()(')) == 'No'
        assert candidate(('(()()(', '())())')) == 'Yes'
        assert candidate(('())', ')())')) == 'No'
        assert candidate(('((((', '((((')) == 'No'
        assert candidate((')(', '(()()(')) == 'No'
        assert candidate((')())', ')())')) == 'No'
        assert candidate((')())', '((())')) == 'No'
        assert candidate(('()', '()(')) == 'No'
        assert candidate(('(()(())', '())())')) == 'No'
        assert candidate(('(', ')')) == 'Yes'
        assert candidate(('(())))', '()(')) == 'No'
        assert candidate(('()', '(()())((')) == 'No'
        assert candidate(('())())', '()(')) == 'No'
        assert candidate(('())())', '(()()(')) == 'Yes'
        assert candidate(('()(', '())())')) == 'No'
        assert candidate(('()))()', '())')) == 'No'
        assert candidate(('(())))', '((())')) == 'No'
        assert candidate(['()', '())']) == 'No'
        assert candidate(['(())))', '(()())((']) == 'Yes'
        assert candidate((')', '(())))')) == 'No'
        assert candidate([')())', '(()()(']) == 'Yes'
        assert candidate(('(()()(', '(()()(')) == 'No'
        assert candidate((')', '(()(())')) == 'Yes'
        assert candidate([')(()', '(()(']) == 'No'
        assert candidate(('(()(())', ')')) == 'Yes'
        assert candidate((')(', '()(')) == 'No'
        assert candidate(('(()()(', ')(()')) == 'No'
        assert candidate(('()(', '(()(())')) == 'No'
        assert candidate((')', '()(')) == 'Yes'
        assert candidate(('())', ')')) == 'No'
        assert candidate(('(()())((', '(()(())')) == 'No'
        assert candidate(('(()(', ')(()')) == 'No'
        assert candidate(('())())', ')())')) == 'No'
        assert candidate(('())', ')(')) == 'No'
        assert candidate(('(()(())', ')(')) == 'No'
        assert candidate(('()', '())')) == 'No'
        assert candidate((')())', '()(')) == 'No'
        assert candidate([')(', ')(']) == 'No'
    

    # Check some edge cases that are easy to work out by hand.
        assert candidate(('(()(', '(()())((')) == 'No'
        assert candidate((')', '(()()(')) == 'No'
        assert candidate(('()(', '(()())((')) == 'No'
        assert candidate(('((())', '(()(')) == 'No'
        assert candidate((')', '())())')) == 'No'
        assert candidate(('()(', '()(')) == 'No'
        assert candidate(['()(', ')']) == 'Yes'
        assert candidate(('(()()(', '(()(())')) == 'No'
        assert candidate(('())())', '()')) == 'No'
        assert candidate(('(()(())', '())')) == 'Yes'
        assert candidate(['(()(', '()))()']) == 'Yes'
        assert candidate(('(()(', '(()(')) == 'No'
        assert candidate(('(())))', '(())))')) == 'No'
        assert candidate(('()(', '(()(')) == 'No'
        assert candidate(('(', '(()())((')) == 'No'
        assert candidate(['(', ')']) == 'Yes'
        assert candidate(['((((', '((())']) == 'No'
        assert candidate(('())())', '(()(())')) == 'No'
        assert candidate(('())', '()')) == 'No'
        assert candidate(('(', '()))()')) == 'No'
        assert candidate(('())())', '(()(')) == 'Yes'
        assert candidate(('(()(())', ')())')) == 'No'
        assert candidate(('((((', '()')) == 'No'
        assert candidate((')())', '(())))')) == 'No'
        assert candidate(('(()())((', ')')) == 'No'
        assert candidate(('()(', ')())')) == 'No'
        assert candidate(('())', '()(')) == 'Yes'
        assert candidate(('()', '(()(())')) == 'No'
        assert candidate((')(()', '(())))')) == 'No'
        assert candidate(('(()()(', '()(')) == 'No'
        assert candidate(('())())', ')')) == 'No'
        assert candidate(['(()(())', '())())']) == 'No'
        assert candidate((')', ')')) == 'No'
        assert candidate(('())())', ')(()')) == 'No'
        assert candidate(('()))()', '(()(')) == 'Yes'
        assert candidate((')())', '((((')) == 'No'
        assert candidate(('(()(())', '(()()(')) == 'No'
        assert candidate(('()', ')())')) == 'No'
        assert candidate(('(())))', '(()()(')) == 'Yes'
        assert candidate((')(', ')(()')) == 'No'
        assert candidate(('(()()(', '(())))')) == 'Yes'
        assert candidate(('(())))', '(()(())')) == 'No'
        assert candidate(('((((', '(()(')) == 'No'
        assert candidate([')', '(']) == 'Yes'
        assert candidate((')(()', '())')) == 'No'
        assert candidate((')())', '())())')) == 'No'

if __name__ == '__main__':
    unittest.main()
