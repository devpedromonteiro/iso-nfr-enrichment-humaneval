
import unittest

from typing import List


from typing import List


def separate_paren_groups(paren_string: str) -> List[str]:
    """Input to this function is a string containing multiple groups of nested parentheses.
    Your goal is to separate those groups into separate strings and return the list of those.

    Separate groups are balanced (each open brace is properly closed) and not nested within each other.
    Ignore any spaces in the input string.

    >>> separate_paren_groups('( ) (( )) (( )( ))')
    ['()', '(())', '(()())']
    """
    if not isinstance(paren_string, str):
        raise TypeError("paren_string must be a string")

    groups: List[str] = []
    current_group: List[str] = []
    balance = 0

    for index, char in enumerate(paren_string):
        if char == " ":
            continue
        if char not in ("(", ")"):
            raise ValueError(
                f"Invalid character at index {index}: {char!r}. Only '(', ')' and spaces are allowed."
            )

        if char == "(":
            balance += 1
            current_group.append(char)
        else:  # char == ")"
            if balance == 0:
                raise ValueError(
                    f"Unbalanced parentheses: unexpected ')' at index {index}"
                )
            balance -= 1
            current_group.append(char)

            if balance == 0:
                groups.append("".join(current_group))
                current_group = []

    if balance != 0:
        raise ValueError("Unbalanced parentheses: missing closing ')'")

    if current_group:
        # Defensive check: should not happen if balance logic is correct.
        raise RuntimeError("Internal error: incomplete group remains after parsing")

    return groups
candidate = separate_paren_groups


class Test(unittest.TestCase):
    def test(self):
        assert candidate("(()())(()())(())") == ['(()())', '(()())', '(())']
        assert candidate("(())(((())))(((())))(((())))") == ['(())', '(((())))', '(((())))', '(((())))']
        assert candidate("()(())((()))(())") == ['()', '(())', '((()))', '(())']
        assert candidate("(()())()((())()())((()))") == ['(()())', '()', '((())()())', '((()))']
        assert candidate("(()())(()())((()))((()))") == ['(()())', '(()())', '((()))', '((()))']
        assert candidate("((()))()()((())()())") == ['((()))', '()', '()', '((())()())']
        assert candidate("(())()()") == ['(())', '()', '()']
        assert candidate("(((())))((()))((()))(((())))") == ['(((())))', '((()))', '((()))', '(((())))']
        assert candidate("((()))(())((()))(((())))") == ['((()))', '(())', '((()))', '(((())))']
        assert candidate("(())()(())") == ['(())', '()', '(())']
        assert candidate("(())(()())(())") == ['(())', '(()())', '(())']
        assert candidate("()()(()())") == ['()', '()', '(()())']
        assert candidate("(())(())(())") == ['(())', '(())', '(())']
        assert candidate("((())()())((()))((())()())((())()())") == ['((())()())', '((()))', '((())()())', '((())()())']
        assert candidate("()((())()())((()))((())()())") == ['()', '((())()())', '((()))', '((())()())']
        assert candidate("()((())()())((())()())((()))") == ['()', '((())()())', '((())()())', '((()))']
        assert candidate("((()))()()(((())))") == ['((()))', '()', '()', '(((())))']
        assert candidate("()()()((()))") == ['()', '()', '()', '((()))']
        assert candidate("()(((())))(((())))(())") == ['()', '(((())))', '(((())))', '(())']
        assert candidate("((())()())((())()())((())()())()") == ['((())()())', '((())()())', '((())()())', '()']
        assert candidate("(((())))(((())))(())(())") == ['(((())))', '(((())))', '(())', '(())']
        assert candidate("()(())()") == ['()', '(())', '()']
        assert candidate("((()))()((())()())(()())") == ['((()))', '()', '((())()())', '(()())']
        assert candidate("((())()())(()())((())()())()") == ['((())()())', '(()())', '((())()())', '()']
        assert candidate("(((())))(())()()") == ['(((())))', '(())', '()', '()']
        assert candidate("()(()())(()())((()))") == ['()', '(()())', '(()())', '((()))']
        assert candidate("(())(())(()())") == ['(())', '(())', '(()())']
        assert candidate("()(()())(()())()") == ['()', '(()())', '(()())', '()']
        assert candidate("(()())()(()())") == ['(()())', '()', '(()())']
        assert candidate("(()())(()())()((())()())") == ['(()())', '(()())', '()', '((())()())']
        assert candidate("()(())(())") == ['()', '(())', '(())']
        assert candidate("()(()())(())") == ['()', '(()())', '(())']
        assert candidate('(()()) ((())) () ((())()())') == [
        '(()())', '((()))', '()', '((())()())'
    ]
        assert candidate("(())((()))()(((())))") == ['(())', '((()))', '()', '(((())))']
        assert candidate("((())()())((()))((()))((()))") == ['((())()())', '((()))', '((()))', '((()))']
        assert candidate('() (()) ((())) (((())))') == [
        '()', '(())', '((()))', '(((())))'
    ]
        assert candidate("()()()((())()())") == ['()', '()', '()', '((())()())']
        assert candidate("()(((())))(())((()))") == ['()', '(((())))', '(())', '((()))']
        assert candidate("(())(()())()") == ['(())', '(()())', '()']
        assert candidate("((()))(((())))(())()") == ['((()))', '(((())))', '(())', '()']
        assert candidate("(()())()((()))()") == ['(()())', '()', '((()))', '()']
        assert candidate('( ) (( )) (( )( ))') == ['()', '(())', '(()())']
        assert candidate("()(())(((())))(((())))") == ['()', '(())', '(((())))', '(((())))']
        assert candidate("((()))(((())))((()))((()))") == ['((()))', '(((())))', '((()))', '((()))']
        assert candidate("(((())))(())(())(((())))") == ['(((())))', '(())', '(())', '(((())))']
        assert candidate("((()))()(()())((()))") == ['((()))', '()', '(()())', '((()))']
        assert candidate("()(((())))()(())") == ['()', '(((())))', '()', '(())']
        assert candidate("(())()(()())") == ['(())', '()', '(()())']
        assert candidate("()()()") == ['()', '()', '()']
        assert candidate("((()))(()())((()))()") == ['((()))', '(()())', '((()))', '()']
        assert candidate("((()))(()())()((())()())") == ['((()))', '(()())', '()', '((())()())']
        assert candidate("(()())(()())(()())") == ['(()())', '(()())', '(()())']
        assert candidate('(()(())((())))') == [
        '(()(())((())))'
    ]
        assert candidate("()(())()(())") == ['()', '(())', '()', '(())']
        assert candidate("(())()(())(((())))") == ['(())', '()', '(())', '(((())))']
        assert candidate("()((())()())((())()())()") == ['()', '((())()())', '((())()())', '()']
        assert candidate("()()(())((()))") == ['()', '()', '(())', '((()))']
        assert candidate("(())((()))((()))(((())))") == ['(())', '((()))', '((()))', '(((())))']
        assert candidate("((()))(())(())(())") == ['((()))', '(())', '(())', '(())']
        assert candidate("((()))()()((()))") == ['((()))', '()', '()', '((()))']
        assert candidate("(()())((()))((())()())(()())") == ['(()())', '((()))', '((())()())', '(()())']
        assert candidate("(())(())()()") == ['(())', '(())', '()', '()']
        assert candidate("(()(())((())))") == ['(()(())((())))']
        assert candidate("(((())))((()))(((())))((()))") == ['(((())))', '((()))', '(((())))', '((()))']
        assert candidate("()()(())") == ['()', '()', '(())']
        assert candidate("()(())(()())") == ['()', '(())', '(()())']
        assert candidate("(()())()(()())(()())") == ['(()())', '()', '(()())', '(()())']
        assert candidate("(()())()(())") == ['(()())', '()', '(())']
        assert candidate("((()))(())(())()") == ['((()))', '(())', '(())', '()']

if __name__ == '__main__':
    unittest.main()
