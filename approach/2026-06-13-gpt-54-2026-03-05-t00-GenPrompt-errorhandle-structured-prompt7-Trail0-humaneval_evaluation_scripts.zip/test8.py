
import unittest
import re
import sys
import math
import copy

from typing import List, Tuple


from typing import List, Tuple


def sum_product(numbers: List[int]) -> Tuple[int, int]:
    """For a given list of integers, return a tuple consisting of the sum
    and the product of all integers in the list.

    Empty sum is 0 and empty product is 1.

    >>> sum_product([])
    (0, 1)
    >>> sum_product([1, 2, 3, 4])
    (10, 24)
    """
    if numbers is None:
        raise TypeError("numbers must be a list of integers, got None")

    if not isinstance(numbers, list):
        raise TypeError(f"numbers must be of type list, got {type(numbers).__name__}")

    total = 0
    product = 1

    for index, value in enumerate(numbers):
        if not isinstance(value, int):
            raise TypeError(
                f"all elements must be integers; found {type(value).__name__} at index {index}"
            )
        total += value
        product *= value

    return total, product
candidate = sum_product




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == (0, 1)
    assert candidate([1, 1, 1]) == (3, 1)
    assert candidate([100, 0]) == (100, 0)
    assert candidate([3, 5, 7]) == (3 + 5 + 7, 3 * 5 * 7)
    assert candidate([10]) == (10, 10)


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
