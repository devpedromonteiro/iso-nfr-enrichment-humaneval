
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def factorize(n: int) -> List[int]:
    """Return list of prime factors of given integer in ascending order.

    Each factor is repeated according to its multiplicity in the prime factorization.

    Input number should be equal to the product of all returned factors.

    >>> factorize(8)
    [2, 2, 2]
    >>> factorize(25)
    [5, 5]
    >>> factorize(70)
    [2, 5, 7]
    """
    if not isinstance(n, int):
        raise TypeError(f"n must be an integer, got {type(n).__name__}")
    if n <= 1:
        raise ValueError("n must be an integer greater than 1")

    factors: List[int] = []
    remainder = n

    try:
        divisor = 2
        while divisor * divisor <= remainder:
            while remainder % divisor == 0:
                factors.append(divisor)
                remainder //= divisor
            divisor += 1

        if remainder > 1:
            factors.append(remainder)

        product = 1
        for factor in factors:
            product *= factor
        if product != n:
            raise ArithmeticError(
                f"factorization failed: product of factors {product} does not match input {n}"
            )

        return factors

    except (TypeError, ValueError, ArithmeticError):
        raise
candidate = factorize




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(2) == [2]
    assert candidate(4) == [2, 2]
    assert candidate(8) == [2, 2, 2]
    assert candidate(3 * 19) == [3, 19]
    assert candidate(3 * 19 * 3 * 19) == [3, 3, 19, 19]
    assert candidate(3 * 19 * 3 * 19 * 3 * 19) == [3, 3, 3, 19, 19, 19]
    assert candidate(3 * 19 * 19 * 19) == [3, 19, 19, 19]
    assert candidate(3 * 2 * 3) == [2, 3, 3]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
