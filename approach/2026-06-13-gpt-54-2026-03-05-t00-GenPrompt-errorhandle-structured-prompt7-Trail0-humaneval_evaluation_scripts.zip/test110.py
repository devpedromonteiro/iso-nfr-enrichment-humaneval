
import unittest
import re
import sys
import math
import copy


def exchange(lst1, lst2):
    """Determine whether lst1 can be made all-even by exchanging elements with lst2.

    An exchange can swap any number of elements between the two lists. This means
    lst1 can be made all-even iff lst2 contains at least as many even numbers as
    lst1 contains odd numbers.

    Args:
        lst1: Non-empty list of integers.
        lst2: Non-empty list of integers.

    Returns:
        "YES" if lst1 can be made all-even, otherwise "NO".

    Raises:
        TypeError: If either argument is not a list, or contains non-integer values.
        ValueError: If either list is empty.
    """
    if not isinstance(lst1, list):
        raise TypeError("lst1 must be a list")
    if not isinstance(lst2, list):
        raise TypeError("lst2 must be a list")

    if not lst1:
        raise ValueError("lst1 must be non-empty")
    if not lst2:
        raise ValueError("lst2 must be non-empty")

    if not all(isinstance(x, int) for x in lst1):
        raise TypeError("lst1 must contain only integers")
    if not all(isinstance(x, int) for x in lst2):
        raise TypeError("lst2 must contain only integers")

    odd_count_lst1 = sum(1 for x in lst1 if x % 2 != 0)
    even_count_lst2 = sum(1 for x in lst2 if x % 2 == 0)

    return "YES" if even_count_lst2 >= odd_count_lst1 else "NO"
candidate = exchange


def check(candidate):

    # Check some simple cases
    assert candidate([1, 2, 3, 4], [1, 2, 3, 4]) == "YES"
    assert candidate([1, 2, 3, 4], [1, 5, 3, 4]) == "NO"
    assert candidate([1, 2, 3, 4], [2, 1, 4, 3]) == "YES" 
    assert candidate([5, 7, 3], [2, 6, 4]) == "YES"
    assert candidate([5, 7, 3], [2, 6, 3]) == "NO" 
    assert candidate([3, 2, 6, 1, 8, 9], [3, 5, 5, 1, 1, 1]) == "NO"

    # Check some edge cases that are easy to work out by hand.
    assert candidate([100, 200], [200, 200]) == "YES"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
