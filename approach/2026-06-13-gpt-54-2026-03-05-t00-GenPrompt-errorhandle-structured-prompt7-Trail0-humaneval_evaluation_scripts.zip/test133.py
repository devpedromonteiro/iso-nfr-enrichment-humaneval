
import unittest
import re
import sys
import math
import copy



import math


def sum_squares(lst):
    """Return the sum of squares of the ceiling of each number in lst.

    Examples:
        [1, 2, 3] -> 14
        [1, 4, 9] -> 98
        [1, 3, 5, 7] -> 84
        [1.4, 4.2, 0] -> 29
        [-2.4, 1, 1] -> 6
    """
    if lst is None:
        raise TypeError("lst must be an iterable of numbers, got None")

    if not isinstance(lst, list):
        raise TypeError(f"lst must be a list, got {type(lst).__name__}")

    total = 0
    for index, value in enumerate(lst):
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            raise TypeError(
                f"lst[{index}] must be a number (int or float), got {type(value).__name__}"
            )
        if not math.isfinite(value):
            raise ValueError(f"lst[{index}] must be a finite number, got {value}")

        rounded = math.ceil(value)
        total += rounded ** 2

    return total
candidate = sum_squares


def check(candidate):

    # Check some simple cases
    assert candidate([1,2,3])==14, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1.0,2,3])==14, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,3,5,7])==84, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1.4,4.2,0])==29, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([-2.4,1,1])==6, "This prints if this assert fails 1 (good for debugging!)"

    assert candidate([100,1,15,2])==10230, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([10000,10000])==200000000, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([-1.4,4.6,6.3])==75, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([-1.4,17.9,18.9,19.9])==1086, "This prints if this assert fails 1 (good for debugging!)"


    # Check some edge cases that are easy to work out by hand.
    assert candidate([0])==0, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([-1])==1, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([-1,1,0])==2, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
