
import unittest
import re
import sys
import math
import copy


def compare(game, guess):
    """Return element-wise absolute differences between actual scores and guesses.

    If a guess matches the score, the corresponding result is 0.

    Args:
        game: Sequence of numeric actual scores.
        guess: Sequence of numeric guessed scores.

    Returns:
        A list of absolute differences.

    Raises:
        TypeError: If either argument is not a list or tuple, or contains non-numeric values.
        ValueError: If the input sequences do not have the same length.
    """
    if not isinstance(game, (list, tuple)):
        raise TypeError("game must be a list or tuple of numbers")
    if not isinstance(guess, (list, tuple)):
        raise TypeError("guess must be a list or tuple of numbers")

    if len(game) != len(guess):
        raise ValueError("game and guess must have the same length")

    result = []

    for index, (score, predicted) in enumerate(zip(game, guess)):
        if not isinstance(score, (int, float)):
            raise TypeError(f"game[{index}] must be a number")
        if not isinstance(predicted, (int, float)):
            raise TypeError(f"guess[{index}] must be a number")

        result.append(abs(score - predicted))

    return result
candidate = compare


def check(candidate):

    # Check some simple cases
    assert candidate([1,2,3,4,5,1],[1,2,3,4,2,-2])==[0,0,0,0,3,3], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([0,0,0,0,0,0],[0,0,0,0,0,0])==[0,0,0,0,0,0], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,2,3],[-1,-2,-3])==[2,4,6], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,2,3,5],[-1,2,3,4])==[2,0,0,1], "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
