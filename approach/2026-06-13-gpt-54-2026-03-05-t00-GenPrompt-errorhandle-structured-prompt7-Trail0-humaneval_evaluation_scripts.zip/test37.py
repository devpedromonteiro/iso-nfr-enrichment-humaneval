
import unittest
import re
import sys
import math
import copy



def sort_even(l: list):
    """Return a new list where values at even indices are sorted, while odd indices remain unchanged.

    Even indices are 0, 2, 4, ...

    Args:
        l: A list of comparable values.

    Returns:
        A new list with even-indexed elements sorted in ascending order.

    Raises:
        TypeError: If l is not a list.
        ValueError: If elements at even indices cannot be compared for sorting.

    >>> sort_even([1, 2, 3])
    [1, 2, 3]
    >>> sort_even([5, 6, 3, 4])
    [3, 6, 5, 4]
    """
    if not isinstance(l, list):
        raise TypeError(f"Expected a list, got {type(l).__name__}")

    result = l.copy()

    try:
        even_values = sorted(result[::2])
    except TypeError as exc:
        raise ValueError("Elements at even indices must be mutually comparable") from exc

    result[::2] = even_values
    return result
candidate = sort_even




METADATA = {}


def check(candidate):
    assert tuple(candidate([1, 2, 3])) == tuple([1, 2, 3])
    assert tuple(candidate([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])) == tuple([-10, 3, -5, 2, -3, 3, 5, 0, 9, 1, 123])
    assert tuple(candidate([5, 8, -12, 4, 23, 2, 3, 11, 12, -10])) == tuple([-12, 8, 3, 4, 5, 2, 12, 11, 23, -10])



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
