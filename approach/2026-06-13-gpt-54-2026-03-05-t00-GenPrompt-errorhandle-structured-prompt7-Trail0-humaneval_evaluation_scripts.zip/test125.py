
import unittest
import re
import sys
import math
import copy


def split_words(txt):
    '''
    Given a string of words, return a list of words split on whitespace.
    If no whitespace exists in the text, split on commas ','.
    If no commas exist, return the number of lower-case letters with odd order
    in the alphabet, where ord('a') = 0, ord('b') = 1, ... ord('z') = 25.

    Examples
    split_words("Hello world!") -> ["Hello", "world!"]
    split_words("Hello,world!") -> ["Hello", "world!"]
    split_words("abcdef") -> 3
    '''
    if not isinstance(txt, str):
        raise TypeError("txt must be a string")

    try:
        if any(ch.isspace() for ch in txt):
            return txt.split()

        if ',' in txt:
            return txt.split(',')

        count = 0
        for ch in txt:
            if 'a' <= ch <= 'z':
                if (ord(ch) - ord('a')) % 2 == 1:
                    count += 1
        return count

    except TypeError:
        # Re-raise specific type errors without swallowing them
        raise
    except Exception as exc:
        # Wrap unexpected failures in a specific exception type
        raise ValueError(f"Failed to process input: {exc}") from exc
candidate = split_words


def check(candidate):

    assert candidate("Hello world!") == ["Hello","world!"]
    assert candidate("Hello,world!") == ["Hello","world!"]
    assert candidate("Hello world,!") == ["Hello","world,!"]
    assert candidate("Hello,Hello,world !") == ["Hello,Hello,world","!"]
    assert candidate("abcdef") == 3
    assert candidate("aaabb") == 2
    assert candidate("aaaBb") == 1
    assert candidate("") == 0


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
