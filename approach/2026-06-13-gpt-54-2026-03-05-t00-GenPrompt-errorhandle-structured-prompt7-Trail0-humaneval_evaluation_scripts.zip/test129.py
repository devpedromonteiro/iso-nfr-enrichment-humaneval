
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Given a grid with N rows and N columns (N >= 2) and a positive integer k,
    each cell of the grid contains a value. Every integer in the range [1, N * N]
    inclusive appears exactly once on the cells of the grid.

    Return the lexicographically minimum path of length k as a list of values.
    """

    # Input validation
    if not isinstance(grid, list) or not grid:
        raise TypeError("grid must be a non-empty list of lists")

    if not all(isinstance(row, list) for row in grid):
        raise TypeError("grid must be a list of lists")

    n = len(grid)
    if n < 2:
        raise ValueError("grid must have at least 2 rows")

    if any(len(row) != n for row in grid):
        raise ValueError("grid must be square (N x N)")

    if not isinstance(k, int):
        raise TypeError("k must be an integer")
    if k <= 0:
        raise ValueError("k must be a positive integer")

    values = []
    for row in grid:
        for val in row:
            if not isinstance(val, int):
                raise TypeError("all grid values must be integers")
            values.append(val)

    expected = set(range(1, n * n + 1))
    actual = set(values)
    if actual != expected or len(values) != len(actual):
        raise ValueError(
            "grid must contain each integer from 1 to N*N exactly once"
        )

    # Build value -> position map
    pos = {}
    for i in range(n):
        for j in range(n):
            pos[grid[i][j]] = (i, j)

    def neighbors(i, j):
        result = []
        if i > 0:
            result.append((i - 1, j))
        if i < n - 1:
            result.append((i + 1, j))
        if j > 0:
            result.append((i, j - 1))
        if j < n - 1:
            result.append((i, j + 1))
        return result

    try:
        # Start from the globally minimum value, since lexicographic order
        # is determined first by the first element.
        start_value = 1
        i, j = pos[start_value]
        path = [start_value]

        # Greedily choose the smallest-valued neighbor at each step.
        # This is correct because revisiting cells is allowed and the path
        # comparison is lexicographic.
        for _ in range(k - 1):
            next_cells = neighbors(i, j)
            if not next_cells:
                raise RuntimeError("no valid neighbor found; grid state is inconsistent")

            ni, nj = min(next_cells, key=lambda cell: grid[cell[0]][cell[1]])
            path.append(grid[ni][nj])
            i, j = ni, nj

        return path

    except KeyError as exc:
        raise RuntimeError("grid position lookup failed due to inconsistent internal state") from exc
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
