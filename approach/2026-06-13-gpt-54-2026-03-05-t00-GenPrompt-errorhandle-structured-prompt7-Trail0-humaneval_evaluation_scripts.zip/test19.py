
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def sort_numbers(numbers: str) -> str:
    """Input is a space-delimited string of numerals from 'zero' to 'nine'.
    Valid choices are 'zero', 'one', 'two', 'three', 'four', 'five',
    'six', 'seven', 'eight' and 'nine'.

    Return the string with numbers sorted from smallest to largest.

    >>> sort_numbers('three one five')
    'one three five'
    """
    if not isinstance(numbers, str):
        raise TypeError("numbers must be a string")

    word_to_value = {
        "zero": 0,
        "one": 1,
        "two": 2,
        "three": 3,
        "four": 4,
        "five": 5,
        "six": 6,
        "seven": 7,
        "eight": 8,
        "nine": 9,
    }

    if numbers.strip() == "":
        return ""

    parts = numbers.split()
    invalid_parts = [part for part in parts if part not in word_to_value]
    if invalid_parts:
        raise ValueError(
            f"invalid numeral(s): {', '.join(invalid_parts)}; "
            f"valid values are: {', '.join(word_to_value.keys())}"
        )

    try:
        sorted_parts = sorted(parts, key=lambda part: word_to_value[part])
    except KeyError as exc:
        # Defensive safeguard: preserve explicit failure with a specific exception
        raise ValueError(f"unexpected invalid numeral: {exc.args[0]}") from exc

    return " ".join(sorted_parts)
candidate = sort_numbers




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == ''
    assert candidate('three') == 'three'
    assert candidate('three five nine') == 'three five nine'
    assert candidate('five zero four seven nine eight') == 'zero four five seven eight nine'
    assert candidate('six five four three two one zero') == 'zero one two three four five six'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
