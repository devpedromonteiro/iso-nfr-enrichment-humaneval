
import unittest



def prime_fib(n: int):
    """
    prime_fib returns n-th number that is a Fibonacci number and it's also prime.
    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """
    if n < 1:
        raise ValueError("n must be a positive integer")

    def is_prime(x: int) -> bool:
        if x < 2:
            return False
        if x == 2:
            return True
        if x % 2 == 0:
            return False
        i = 3
        while i * i <= x:
            if x % i == 0:
                return False
            i += 2
        return True

    # Fibonacci sequence: 0, 1, 1, 2, 3, 5, ...
    # All prime Fibonacci numbers occur at prime indices, except F(4)=3.
    if n == 1:
        return 2  # F(3)
    if n == 2:
        return 3  # F(4)

    count = 2
    a, b = 2, 3      # F(3), F(4)
    prev, curr = 3, 4  # corresponding indices

    while True:
        a, b = b, a + b
        curr = prev + curr
        prev = curr - prev

        if is_prime(curr) and is_prime(b):
            count += 1
            if count == n:
                return b
candidate = prime_fib


class Test(unittest.TestCase):
    def test(self):
        assert candidate(2) == 3
        assert candidate(12) == 99194853094755497
        assert candidate(6) == 233
        assert candidate(10) == 433494437
        assert candidate(3) == 5
        assert candidate(5) == 89
        assert candidate(8) == 28657
        assert candidate(11) == 2971215073
        assert candidate(1) == 2
        assert candidate(4) == 13
        assert candidate(9) == 514229
        assert candidate(7) == 1597

if __name__ == '__main__':
    unittest.main()
