
import unittest


def is_equal_to_sum_even(n):
    """Evaluate whether the given number n can be written as the sum of exactly 4 positive even numbers.

    Example
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """
    # The smallest sum of 4 positive even numbers is 2 + 2 + 2 + 2 = 8.
    # Any even n >= 8 can be formed by using 2, 2, 2, and n - 6,
    # where n - 6 is also a positive even number.
    return n >= 8 and n % 2 == 0
candidate = is_equal_to_sum_even


class Test(unittest.TestCase):
    def test(self):
        assert candidate(337) == False
        assert candidate(568) == True
        assert candidate(7672) == True
        assert candidate(3099) == False
        assert candidate(6383) == False
        assert candidate(6) == False
        assert candidate(8105) == False
        assert candidate(319) == False
        assert candidate(5283) == False
        assert candidate(7636) == True
        assert candidate(7789) == False
        assert candidate(8814) == True
        assert candidate(9933) == False
        assert candidate(3111) == False
        assert candidate(4) == False
        assert candidate(5584) == True
        assert candidate(13) == False
        assert candidate(6802) == True
        assert candidate(2758) == True
        assert candidate(3875) == False
        assert candidate(206) == True
        assert candidate(890) == True
        assert candidate(6190) == True
        assert candidate(6751) == False
        assert candidate(3136) == True
        assert candidate(2063) == False
        assert candidate(9340) == True
        assert candidate(6772) == True
        assert candidate(8510) == True
        assert candidate(6647) == False
        assert candidate(4212) == True
        assert candidate(2985) == False
        assert candidate(4852) == True
        assert candidate(2094) == True
        assert candidate(2520) == True
        assert candidate(3538) == True
        assert candidate(2086) == True
        assert candidate(2873) == False
        assert candidate(2652) == True
        assert candidate(4963) == False
        assert candidate(947) == False
        assert candidate(2952) == True
        assert candidate(605) == False
        assert candidate(87) == False
        assert candidate(1746) == True
        assert candidate(8090) == True
        assert candidate(8172) == True
        assert candidate(3922) == True
        assert candidate(6636) == True
        assert candidate(5983) == False
        assert candidate(9594) == True
        assert candidate(6074) == True
        assert candidate(6455) == False
        assert candidate(3182) == True
        assert candidate(6459) == False
        assert candidate(8079) == False
        assert candidate(293) == False
        assert candidate(1010) == True
        assert candidate(5036) == True
        assert candidate(1738) == True
        assert candidate(3370) == True
        assert candidate(9839) == False
        assert candidate(9739) == False
        assert candidate(5321) == False
        assert candidate(654) == True
        assert candidate(6302) == True
        assert candidate(118) == True
        assert candidate(9668) == True
        assert candidate(6518) == True
        assert candidate(8670) == True
        assert candidate(355) == False
        assert candidate(5668) == True
        assert candidate(2361) == False
        assert candidate(9829) == False
        assert candidate(8330) == True
        assert candidate(7487) == False
        assert candidate(1635) == False
        assert candidate(9185) == False
        assert candidate(1208) == True
        assert candidate(8475) == False
        assert candidate(9451) == False
        assert candidate(8163) == False
        assert candidate(4833) == False
        assert candidate(5335) == False
        assert candidate(16) == True
        assert candidate(512) == True
        assert candidate(2890) == True
        assert candidate(10) == True
        assert candidate(5048) == True
        assert candidate(11) == False
        assert candidate(5369) == False
        assert candidate(1608) == True
        assert candidate(1496) == True
        assert candidate(6938) == True
        assert candidate(9600) == True
        assert candidate(6877) == False
        assert candidate(9483) == False
        assert candidate(12) == True
        assert candidate(2487) == False
        assert candidate(7885) == False
        assert candidate(3671) == False
        assert candidate(8924) == True
        assert candidate(8004) == True
        assert candidate(572) == True
        assert candidate(4569) == False
        assert candidate(6745) == False
        assert candidate(2720) == True
        assert candidate(1731) == False
        assert candidate(4830) == True
        assert candidate(8) == True
        assert candidate(8705) == False
        assert candidate(7373) == False
        assert candidate(7666) == True
        assert candidate(2365) == False
        assert candidate(3820) == True
        assert candidate(3769) == False
        assert candidate(1467) == False
        assert candidate(6023) == False
        assert candidate(5592) == True
        assert candidate(1834) == True
        assert candidate(4390) == True
        assert candidate(9234) == True
        assert candidate(8550) == True
        assert candidate(9510) == True
        assert candidate(2583) == False
        assert candidate(8851) == False
        assert candidate(8883) == False

if __name__ == '__main__':
    unittest.main()
