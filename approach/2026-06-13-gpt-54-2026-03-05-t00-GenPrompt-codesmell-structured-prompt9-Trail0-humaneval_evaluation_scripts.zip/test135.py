
import unittest
import re
import sys
import math
import copy


def _is_out_of_order(previous, current):
    """Return True when the current value breaks strict ascending order."""
    return current <= previous


def can_arrange(arr):
    """Return the largest index where ascending order is violated.

    A violation occurs when an element is less than or equal to the element
    immediately before it. If the array is strictly increasing, return -1.

    Examples:
        can_arrange([1, 2, 4, 3, 5]) -> 3
        can_arrange([1, 2, 3]) -> -1
    """
    last_invalid_index = -1

    for index in range(1, len(arr)):
        if _is_out_of_order(arr[index - 1], arr[index]):
            last_invalid_index = index

    return last_invalid_index
candidate = can_arrange


def check(candidate):

    # Check some simple cases
    assert candidate([1,2,4,3,5])==3
    assert candidate([1,2,4,5])==-1
    assert candidate([1,4,2,5,6,7,8,9,10])==2
    assert candidate([4,8,5,7,3])==4

    # Check some edge cases that are easy to work out by hand.
    assert candidate([])==-1



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
