
import unittest
import re
import sys
import math
import copy


import operator as op


def _build_namespace():
    """Return the supported algebra operations."""
    return {
        "+": op.add,
        "-": op.sub,
        "*": op.mul,
        "//": op.floordiv,
        "**": op.pow,
    }


def _validate_inputs(operators, operands):
    """Validate input structure and supported operators."""
    if len(operators) != len(operands) - 1:
        raise ValueError("The number of operators must be exactly one less than the number of operands.")

    supported = _build_namespace()
    invalid = [symbol for symbol in operators if symbol not in supported]
    if invalid:
        raise ValueError(f"Unsupported operator(s): {invalid}")


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and
    the second list is a list of integers. Use the two given lists to build the algebraic
    expression and return the evaluation of this expression.

    The basic algebra operations:
    Addition ( + )
    Subtraction ( - )
    Multiplication ( * )
    Floor division ( // )
    Exponentiation ( ** )
    """
    _validate_inputs(operator, operand)
    operations = _build_namespace()

    expression = [str(operand[0])]
    for symbol, value in zip(operator, operand[1:]):
        expression.append(symbol)
        expression.append(str(value))

    return eval(" ".join(expression), {"__builtins__": None}, {})
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
