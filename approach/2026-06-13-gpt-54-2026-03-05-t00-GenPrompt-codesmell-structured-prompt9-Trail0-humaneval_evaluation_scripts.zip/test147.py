
import unittest
import re
import sys
import math
import copy


def _count_by_modulo(n):
    """
    Count how many values a[i] = i*i - i + 1 fall into each residue class modulo 3
    for 1 <= i <= n.

    Since:
        a[i] = i^2 - i + 1
    and modulo 3:
        i % 3 == 0 -> a[i] % 3 == 1
        i % 3 == 1 -> a[i] % 3 == 1
        i % 3 == 2 -> a[i] % 3 == 0

    So only residues 0 and 1 appear.
    """
    count_mod_0 = n // 3
    count_mod_1 = n - count_mod_0
    return count_mod_0, count_mod_1


def _n_choose_3(x):
    """Return C(x, 3), or 0 if x < 3."""
    if x < 3:
        return 0
    return x * (x - 1) * (x - 2) // 6


def _n_choose_2(x):
    """Return C(x, 2), or 0 if x < 2."""
    if x < 2:
        return 0
    return x * (x - 1) // 2


def get_max_triples(n):
    """
    You are given a positive integer n. You have to create an integer array a of length n.
    For each i (1 â¤ i â¤ n), the value of a[i] = i * i - i + 1.

    Return the number of triples (a[i], a[j], a[k]) where i < j < k and
    a[i] + a[j] + a[k] is a multiple of 3.

    Example:
        Input: n = 5
        Output: 1
        Explanation:
        a = [1, 3, 7, 13, 21]
        The only valid triple is (1, 7, 13).
    """
    if n < 3:
        return 0

    count_mod_0, count_mod_1 = _count_by_modulo(n)

    # Valid modulo combinations summing to 0 mod 3:
    # (0, 0, 0) and (1, 1, 1)
    return _n_choose_3(count_mod_0) + _n_choose_3(count_mod_1)
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
