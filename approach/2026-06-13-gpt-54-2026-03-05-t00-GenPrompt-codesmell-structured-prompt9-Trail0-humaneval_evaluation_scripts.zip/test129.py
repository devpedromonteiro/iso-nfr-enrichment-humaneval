
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Given a grid with N rows and N columns (N >= 2) and a positive integer k,
    each cell of the grid contains a value. Every integer in the range [1, N * N]
    inclusive appears exactly once on the cells of the grid.

    Return the lexicographically smallest path of length k, where each move goes
    to an edge-adjacent cell and cells may be revisited.
    """
    n = len(grid)

    def build_positions():
        positions = [None] * (n * n + 1)
        for r in range(n):
            for c in range(n):
                positions[grid[r][c]] = (r, c)
        return positions

    def neighbors(r, c):
        result = []
        if r > 0:
            result.append(grid[r - 1][c])
        if r + 1 < n:
            result.append(grid[r + 1][c])
        if c > 0:
            result.append(grid[r][c - 1])
        if c + 1 < n:
            result.append(grid[r][c + 1])
        return result

    def build_adjacency(positions):
        adjacency = [[] for _ in range(n * n + 1)]
        for value in range(1, n * n + 1):
            r, c = positions[value]
            adjacency[value] = sorted(neighbors(r, c))
        return adjacency

    def smallest_reachable_values(adjacency):
        reachable = [set() for _ in range(n * n + 1)]
        for value in range(1, n * n + 1):
            reachable[value].add(value)
            reachable[value].update(adjacency[value])
        return [sorted(values) for values in reachable]

    if k == 1:
        return [1]

    positions = build_positions()
    adjacency = build_adjacency(positions)

    path = [1]
    current_candidates = {1}

    for _ in range(1, k):
        next_candidates = set()
        min_next_value = float("inf")

        for current in current_candidates:
            for nxt in adjacency[current]:
                if nxt < min_next_value:
                    min_next_value = nxt
                    next_candidates = {nxt}
                elif nxt == min_next_value:
                    next_candidates.add(nxt)

        path.append(min_next_value)
        current_candidates = next_candidates

    return path
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
