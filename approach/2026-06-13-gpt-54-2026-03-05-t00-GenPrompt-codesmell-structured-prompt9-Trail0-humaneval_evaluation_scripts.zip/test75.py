
import unittest
import re
import sys
import math
import copy


def _is_prime(n):
    """Return True if n is a prime number, otherwise False."""
    if n < 2:
        return False
    if n == 2:
        return True
    if n % 2 == 0:
        return False

    divisor = 3
    while divisor * divisor <= n:
        if n % divisor == 0:
            return False
        divisor += 2
    return True


def is_multiply_prime(a):
    """Return True if a is the product of exactly 3 prime numbers, else False."""
    if a < 2:
        return False

    prime_factors_count = 0
    remaining = a
    divisor = 2

    while divisor * divisor <= remaining and prime_factors_count < 3:
        while remaining % divisor == 0:
            if not _is_prime(divisor):
                return False
            remaining //= divisor
            prime_factors_count += 1
            if prime_factors_count > 3:
                return False
        divisor += 1

    if remaining > 1:
        if not _is_prime(remaining):
            return False
        prime_factors_count += 1

    return prime_factors_count == 3
candidate = is_multiply_prime


def check(candidate):

    assert candidate(5) == False
    assert candidate(30) == True
    assert candidate(8) == True
    assert candidate(10) == False
    assert candidate(125) == True
    assert candidate(3 * 5 * 7) == True
    assert candidate(3 * 6 * 7) == False
    assert candidate(9 * 9 * 9) == False
    assert candidate(11 * 9 * 9) == False
    assert candidate(11 * 13 * 7) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
