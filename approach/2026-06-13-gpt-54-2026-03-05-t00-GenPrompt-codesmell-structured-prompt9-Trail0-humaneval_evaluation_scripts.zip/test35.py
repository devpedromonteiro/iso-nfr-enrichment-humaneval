
import unittest
import re
import sys
import math
import copy



def _validate_non_empty_list(values: list) -> None:
    if not values:
        raise ValueError("max_element() arg is an empty list")


def max_element(values: list):
    """Return maximum element in the list.
    >>> max_element([1, 2, 3])
    3
    >>> max_element([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    123
    """
    _validate_non_empty_list(values)

    maximum = values[0]
    for value in values[1:]:
        if value > maximum:
            maximum = value
    return maximum
candidate = max_element




METADATA = {}


def check(candidate):
    assert candidate([1, 2, 3]) == 3
    assert candidate([5, 3, -5, 2, -3, 3, 9, 0, 124, 1, -10]) == 124


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
