
import unittest
import re
import sys
import math
import copy


def _factorial(value):
    result = 1
    for number in range(1, value + 1):
        result *= number
    return result


def _sum_to(value):
    return value * (value + 1) // 2


def _value_for_index(index):
    if index % 2 == 0:
        return _factorial(index)
    return _sum_to(index)


def f(n):
    """Return a list of size n where:
    - element at 1-based index i is factorial(i) if i is even
    - element at 1-based index i is sum(1..i) if i is odd

    Example:
        f(5) == [1, 2, 6, 24, 15]
    """
    return [_value_for_index(i) for i in range(1, n + 1)]
candidate = f


def check(candidate):

    assert candidate(5) == [1, 2, 6, 24, 15]
    assert candidate(7) == [1, 2, 6, 24, 15, 720, 28]
    assert candidate(1) == [1]
    assert candidate(3) == [1, 2, 6]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
