
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math
from typing import List


def poly(coefficients: List[float], x: float) -> float:
    """
    Evaluate a polynomial with coefficients at point x.

    The polynomial is:
        coefficients[0] + coefficients[1] * x + ... + coefficients[n] * x^n
    """
    return sum(coeff * math.pow(x, power) for power, coeff in enumerate(coefficients))


def _validate_coefficients(coefficients: List[float]) -> None:
    """Validate input constraints required by find_zero."""
    if not coefficients:
        raise ValueError("coefficients must not be empty")

    if len(coefficients) % 2 != 0:
        raise ValueError("find_zero requires an even number of coefficients")

    if coefficients[-1] == 0:
        raise ValueError("highest-degree coefficient must be non-zero")


def _find_sign_change_interval(coefficients: List[float], start: float = 1.0) -> tuple[float, float]:
    """
    Find an interval [left, right] where the polynomial changes sign.
    """
    f0 = poly(coefficients, 0.0)
    if f0 == 0:
        return 0.0, 0.0

    step = start
    while True:
        left = -step
        right = step
        f_left = poly(coefficients, left)
        f_right = poly(coefficients, right)

        if f_left == 0:
            return left, left
        if f_right == 0:
            return right, right
        if f_left * f0 < 0:
            return left, 0.0
        if f0 * f_right < 0:
            return 0.0, right

        step *= 2


def _bisect_zero(coefficients: List[float], left: float, right: float, tolerance: float = 1e-12) -> float:
    """
    Find a zero in [left, right] using the bisection method.
    """
    f_left = poly(coefficients, left)
    f_right = poly(coefficients, right)

    if f_left == 0:
        return left
    if f_right == 0:
        return right

    while abs(right - left) > tolerance:
        mid = (left + right) / 2
        f_mid = poly(coefficients, mid)

        if f_mid == 0:
            return mid

        if f_left * f_mid < 0:
            right = mid
            f_right = f_mid
        else:
            left = mid
            f_left = f_mid

    return (left + right) / 2


def find_zero(coefficients: List[float]) -> float:
    """ 
    coefficients are coefficients of a polynomial.

    find_zero finds x such that poly(coefficients, x) == 0.
    It returns one zero point, even if there are many.

    This function only accepts coefficient lists with:
    - an even number of coefficients
    - a non-zero highest-degree coefficient

    >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2)  # (x - 1) * (x - 2) * (x - 3)
    1.0
    """
    _validate_coefficients(coefficients)
    left, right = _find_sign_change_interval(coefficients)

    if left == right:
        return left

    return _bisect_zero(coefficients, left, right)
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
