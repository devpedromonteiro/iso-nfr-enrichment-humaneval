
import unittest
import re
import sys
import math
import copy


def split_words(txt):
    """
    Given a string of words:
    - split on whitespace if any whitespace exists
    - otherwise split on commas if any commas exist
    - otherwise return the count of lowercase letters whose alphabet index is odd
      (a=0, b=1, ..., z=25)

    Examples:
    split_words("Hello world!") -> ["Hello", "world!"]
    split_words("Hello,world!") -> ["Hello", "world!"]
    split_words("abcdef") -> 3
    """
    if _contains_whitespace(txt):
        return txt.split()

    if _contains_comma(txt):
        return txt.split(",")

    return _count_odd_index_lowercase_letters(txt)


def _contains_whitespace(text):
    return any(char.isspace() for char in text)


def _contains_comma(text):
    return "," in text


def _count_odd_index_lowercase_letters(text):
    return sum(1 for char in text if _is_odd_index_lowercase_letter(char))


def _is_odd_index_lowercase_letter(char):
    return char.islower() and char.isalpha() and (ord(char) - ord("a")) % 2 == 1
candidate = split_words


def check(candidate):

    assert candidate("Hello world!") == ["Hello","world!"]
    assert candidate("Hello,world!") == ["Hello","world!"]
    assert candidate("Hello world,!") == ["Hello","world,!"]
    assert candidate("Hello,Hello,world !") == ["Hello,Hello,world","!"]
    assert candidate("abcdef") == 3
    assert candidate("aaabb") == 2
    assert candidate("aaaBb") == 1
    assert candidate("") == 0


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
