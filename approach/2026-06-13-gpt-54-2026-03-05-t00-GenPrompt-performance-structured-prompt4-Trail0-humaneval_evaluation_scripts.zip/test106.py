
import unittest
import re
import sys
import math
import copy


def f(n):
    res = []
    fact = 1
    running_sum = 0

    for i in range(1, n + 1):
        fact *= i
        running_sum += i

        if i % 2 == 0:
            res.append(fact)
        else:
            res.append(running_sum)

    return res
candidate = f


def check(candidate):

    assert candidate(5) == [1, 2, 6, 24, 15]
    assert candidate(7) == [1, 2, 6, 24, 15, 720, 28]
    assert candidate(1) == [1]
    assert candidate(3) == [1, 2, 6]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
