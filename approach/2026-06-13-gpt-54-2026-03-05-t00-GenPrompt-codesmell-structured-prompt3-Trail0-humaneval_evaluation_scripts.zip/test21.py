
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List, Tuple


def _find_bounds(numbers: List[float]) -> Tuple[float, float]:
    """Return the minimum and maximum values from the input list."""
    return min(numbers), max(numbers)


def _validate_input(numbers: List[float]) -> None:
    """Validate input constraints for rescaling."""
    if len(numbers) < 2:
        raise ValueError("numbers must contain at least two elements")

    minimum, maximum = _find_bounds(numbers)
    if minimum == maximum:
        raise ValueError("numbers must not all be equal")


def _scale_value(value: float, minimum: float, scale: float) -> float:
    """Scale a single value into the [0, 1] range."""
    return (value - minimum) / scale


def rescale_to_unit(numbers: List[float]) -> List[float]:
    """Given a list of numbers, apply a linear transform so that the
    smallest number becomes 0 and the largest becomes 1.

    >>> rescale_to_unit([1.0, 2.0, 3.0, 4.0, 5.0])
    [0.0, 0.25, 0.5, 0.75, 1.0]
    """
    _validate_input(numbers)
    minimum, maximum = _find_bounds(numbers)
    scale = maximum - minimum
    return [_scale_value(value, minimum, scale) for value in numbers]
candidate = rescale_to_unit




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([2.0, 49.9]) == [0.0, 1.0]
    assert candidate([100.0, 49.9]) == [1.0, 0.0]
    assert candidate([1.0, 2.0, 3.0, 4.0, 5.0]) == [0.0, 0.25, 0.5, 0.75, 1.0]
    assert candidate([2.0, 1.0, 5.0, 3.0, 4.0]) == [0.25, 0.0, 1.0, 0.5, 0.75]
    assert candidate([12.0, 11.0, 15.0, 13.0, 14.0]) == [0.25, 0.0, 1.0, 0.5, 0.75]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
