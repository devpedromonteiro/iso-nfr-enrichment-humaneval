
import unittest
import re
import sys
import math
import copy



def _remove_factor(n: int, factor: int) -> tuple[int, bool]:
    """Divide n by factor until it no longer divides evenly.

    Returns the reduced value and whether the factor was found at least once.
    """
    found = False
    while n % factor == 0:
        n //= factor
        found = True
    return n, found


def largest_prime_factor(n: int):
    """Return the largest prime factor of n. Assume n > 1 and is not a prime.

    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    largest = None

    n, found = _remove_factor(n, 2)
    if found:
        largest = 2

    factor = 3
    while factor * factor <= n:
        n, found = _remove_factor(n, factor)
        if found:
            largest = factor
        factor += 2

    return n if n > 1 else largest
candidate = largest_prime_factor




METADATA = {}


def check(candidate):
    assert candidate(15) == 5
    assert candidate(27) == 3
    assert candidate(63) == 7
    assert candidate(330) == 11
    assert candidate(13195) == 29



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
