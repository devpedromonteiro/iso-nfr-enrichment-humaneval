
import unittest
import re
import sys
import math
import copy


def _convert_positive_decimal_to_binary(value):
    """Convert a non-negative integer to its binary representation."""
    if value == 0:
        return "0"

    bits = []
    while value > 0:
        bits.append(str(value % 2))
        value //= 2

    return "".join(reversed(bits))


def decimal_to_binary(decimal):
    """Convert a decimal integer to a binary string wrapped with 'db'.

    Examples:
    decimal_to_binary(15)   # returns "db1111db"
    decimal_to_binary(32)   # returns "db100000db"
    """
    binary_value = _convert_positive_decimal_to_binary(decimal)
    return f"db{binary_value}db"
candidate = decimal_to_binary


def check(candidate):

    # Check some simple cases
    assert candidate(0) == "db0db"
    assert candidate(32) == "db100000db"
    assert candidate(103) == "db1100111db"
    assert candidate(15) == "db1111db", "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
