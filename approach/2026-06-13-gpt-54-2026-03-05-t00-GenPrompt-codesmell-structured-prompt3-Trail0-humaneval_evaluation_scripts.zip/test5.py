
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def _append_with_delimiter(result: List[int], value: int, delimiter: int, is_first: bool) -> None:
    """Append `value` to `result`, inserting `delimiter` first when needed."""
    if not is_first:
        result.append(delimiter)
    result.append(value)


def intersperse(numbers: List[int], delimiter: int) -> List[int]:
    """Insert `delimiter` between every two consecutive elements of `numbers`.

    >>> intersperse([], 4)
    []
    >>> intersperse([1, 2, 3], 4)
    [1, 4, 2, 4, 3]
    """
    result: List[int] = []

    for index, number in enumerate(numbers):
        _append_with_delimiter(
            result=result,
            value=number,
            delimiter=delimiter,
            is_first=(index == 0),
        )

    return result
candidate = intersperse




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([], 7) == []
    assert candidate([5, 6, 3, 2], 8) == [5, 8, 6, 8, 3, 8, 2]
    assert candidate([2, 2, 2], 2) == [2, 2, 2, 2, 2]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
