
import unittest
import re
import sys
import math
import copy


def _has_minimum_length(text):
    return len(text) >= 3


def _all_consecutive_triplets_distinct(text):
    for i in range(len(text) - 2):
        a, b, c = text[i], text[i + 1], text[i + 2]
        if a == b or b == c or a == c:
            return False
    return True


def is_happy(s):
    """Check whether a string is happy.

    A string is happy if:
    - its length is at least 3
    - every 3 consecutive letters are distinct
    """
    if not _has_minimum_length(s):
        return False

    return _all_consecutive_triplets_distinct(s)
candidate = is_happy


def check(candidate):

    # Check some simple cases
    assert candidate("a") == False , "a"
    assert candidate("aa") == False , "aa"
    assert candidate("abcd") == True , "abcd"
    assert candidate("aabb") == False , "aabb"
    assert candidate("adb") == True , "adb"
    assert candidate("xyy") == False , "xyy"
    assert candidate("iopaxpoi") == True , "iopaxpoi"
    assert candidate("iopaxioi") == False , "iopaxioi"


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
