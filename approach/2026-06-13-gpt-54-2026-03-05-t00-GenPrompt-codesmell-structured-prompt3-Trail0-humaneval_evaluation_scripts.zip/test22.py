
import unittest
import re
import sys
import math
import copy

from typing import List, Any


from typing import Any, List


def _is_strict_integer(value: Any) -> bool:
    """Return True only for integers, excluding booleans."""
    return isinstance(value, int) and not isinstance(value, bool)


def filter_integers(values: List[Any]) -> List[int]:
    """Filter a list and return only integer values.

    Booleans are excluded, even though ``bool`` is a subclass of ``int``.

    >>> filter_integers(['a', 3.14, 5])
    [5]
    >>> filter_integers([1, 2, 3, 'abc', {}, []])
    [1, 2, 3]
    >>> filter_integers([True, False, 1, 0, -2])
    [1, 0, -2]
    """
    return [value for value in values if _is_strict_integer(value)]
candidate = filter_integers




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == []
    assert candidate([4, {}, [], 23.2, 9, 'adasd']) == [4, 9]
    assert candidate([3, 'c', 3, 3, 'a', 'b']) == [3, 3, 3]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
