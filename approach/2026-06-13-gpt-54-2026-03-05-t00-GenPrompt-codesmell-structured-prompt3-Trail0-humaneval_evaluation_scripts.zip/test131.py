
import unittest
import re
import sys
import math
import copy


def _odd_digits(number):
    """Yield the odd digits in a non-negative integer."""
    for char in str(number):
        digit = int(char)
        if digit % 2 == 1:
            yield digit


def digits(n):
    """Given a positive integer n, return the product of the odd digits.
    Return 0 if all digits are even.

    Examples:
        digits(1) == 1
        digits(4) == 0
        digits(235) == 15
    """
    product = 1
    found_odd = False

    for digit in _odd_digits(n):
        product *= digit
        found_odd = True

    return product if found_odd else 0
candidate = digits


def check(candidate):

    # Check some simple cases
    assert candidate(5) == 5
    assert candidate(54) == 5
    assert candidate(120) ==1
    assert candidate(5014) == 5
    assert candidate(98765) == 315
    assert candidate(5576543) == 2625

    # Check some edge cases that are easy to work out by hand.
    assert candidate(2468) == 0



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
