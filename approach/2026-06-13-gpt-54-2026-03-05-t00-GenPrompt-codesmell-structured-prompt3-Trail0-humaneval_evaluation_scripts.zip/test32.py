
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math
from typing import Sequence


def poly(coefficients: Sequence[float], x: float) -> float:
    """
    Evaluate a polynomial with the given coefficients at point x.

    coefficients[i] is the coefficient for x**i.

    Example:
        poly([1, 2, 3], 2) == 1 + 2*2 + 3*2**2
    """
    return sum(coeff * math.pow(x, power) for power, coeff in enumerate(coefficients))


def _validate_coefficients(coefficients: Sequence[float]) -> None:
    """Validate the coefficient list expected by find_zero."""
    if len(coefficients) == 0:
        raise ValueError("coefficients must not be empty")
    if len(coefficients) % 2 != 0:
        raise ValueError("find_zero requires an even number of coefficients")
    if coefficients[-1] == 0:
        raise ValueError("the largest-degree coefficient must be non-zero")


def _find_bracketing_interval(coefficients: Sequence[float]) -> tuple[float, float]:
    """
    Find an interval [left, right] where the polynomial changes sign.
    Under the documented constraints, such an interval is guaranteed to exist.
    """
    left, right = -1.0, 1.0
    f_left = poly(coefficients, left)
    f_right = poly(coefficients, right)

    while f_left * f_right > 0:
        left *= 2
        right *= 2
        f_left = poly(coefficients, left)
        f_right = poly(coefficients, right)

    return left, right


def _bisect_zero(
    coefficients: Sequence[float],
    left: float,
    right: float,
    tolerance: float = 1e-7,
    max_iterations: int = 10_000,
def find_zero(coefficients: Sequence[float]) -> float:
    """Find one real zero of a polynomial.

    coefficients are polynomial coefficients in ascending power order:
    coefficients[i] corresponds to x**i.

    This function expects:
    - an even number of coefficients
    - a non-zero highest-degree coefficient

    These constraints imply an odd-degree polynomial, which guarantees
    at least one real root.

    >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2)
    1.0
    """
    _validate_coefficients(coefficients)
    left, right = _find_bracketing_interval(coefficients)
    return _bisect_zero(coefficients, left, right)
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
