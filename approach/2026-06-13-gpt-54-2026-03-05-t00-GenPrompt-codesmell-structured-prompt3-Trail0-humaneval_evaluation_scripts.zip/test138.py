
import unittest
import re
import sys
import math
import copy


def _minimum_sum_of_positive_even_numbers(count):
    """Return the minimum sum achievable with `count` positive even numbers."""
    smallest_positive_even = 2
    return count * smallest_positive_even


def is_equal_to_sum_even(n):
    """Return whether `n` can be written as the sum of exactly 4 positive even numbers.

    Examples:
        is_equal_to_sum_even(4) == False
        is_equal_to_sum_even(6) == False
        is_equal_to_sum_even(8) == True
    """
    required_terms = 4

    if n % 2 != 0:
        return False

    return n >= _minimum_sum_of_positive_even_numbers(required_terms)
candidate = is_equal_to_sum_even


def check(candidate):
    assert candidate(4) == False
    assert candidate(6) == False
    assert candidate(8) == True
    assert candidate(10) == True
    assert candidate(11) == False
    assert candidate(12) == True
    assert candidate(13) == False
    assert candidate(16) == True


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
