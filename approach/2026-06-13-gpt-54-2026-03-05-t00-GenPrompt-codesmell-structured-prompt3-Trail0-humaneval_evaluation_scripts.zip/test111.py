
import unittest
import re
import sys
import math
import copy


from collections import Counter


def _count_letters(text):
    """Return occurrences of each space-separated letter."""
    if not text:
        return Counter()
    return Counter(text.split())


def _max_frequency(counts):
    """Return the highest frequency found in counts."""
    return max(counts.values(), default=0)


def _filter_most_frequent(counts, max_count):
    """Return only letters whose count matches max_count."""
    return {letter: count for letter, count in counts.items() if count == max_count}


def histogram(test):
    """Given a string representing space-separated lowercase letters, return a dictionary
    containing the letter(s) with the highest repetition and their corresponding count.

    Example:
    histogram('a b c') == {'a': 1, 'b': 1, 'c': 1}
    histogram('a b b a') == {'a': 2, 'b': 2}
    histogram('a b c a b') == {'a': 2, 'b': 2}
    histogram('b b b b a') == {'b': 4}
    histogram('') == {}
    """
    counts = _count_letters(test)
    max_count = _max_frequency(counts)
    return _filter_most_frequent(counts, max_count)
candidate = histogram


def check(candidate):

    # Check some simple cases
    assert candidate('a b b a') == {'a':2,'b': 2}, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('a b c a b') == {'a': 2, 'b': 2}, "This prints if this assert fails 2 (good for debugging!)"
    assert candidate('a b c d g') == {'a': 1, 'b': 1, 'c': 1, 'd': 1, 'g': 1}, "This prints if this assert fails 3 (good for debugging!)"
    assert candidate('r t g') == {'r': 1,'t': 1,'g': 1}, "This prints if this assert fails 4 (good for debugging!)"
    assert candidate('b b b b a') == {'b': 4}, "This prints if this assert fails 5 (good for debugging!)"
    assert candidate('r t g') == {'r': 1,'t': 1,'g': 1}, "This prints if this assert fails 6 (good for debugging!)"
    
    
    # Check some edge cases that are easy to work out by hand.
    assert candidate('') == {}, "This prints if this assert fails 7 (also good for debugging!)"
    assert candidate('a') == {'a': 1}, "This prints if this assert fails 8 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
