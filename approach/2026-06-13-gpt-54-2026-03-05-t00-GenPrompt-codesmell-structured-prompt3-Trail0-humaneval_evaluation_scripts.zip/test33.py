
import unittest
import re
import sys
import math
import copy



from typing import List, Sequence, TypeVar

T = TypeVar("T")


def _third_index_values(items: Sequence[T]) -> List[T]:
    """Return values located at indices divisible by three."""
    return [items[index] for index in range(0, len(items), 3)]


def _merge_sorted_third_values(items: Sequence[T], sorted_third_values: Sequence[T]) -> List[T]:
    """Return a new list with sorted values placed at indices divisible by three."""
    result = list(items)
    for index, value in zip(range(0, len(result), 3), sorted_third_values):
        result[index] = value
    return result


def sort_third(l: list):
    """Return a copy of l where values at indices divisible by three are sorted.

    Indices not divisible by three remain unchanged.

    >>> sort_third([1, 2, 3])
    [1, 2, 3]
    >>> sort_third([5, 6, 3, 4, 8, 9, 2])
    [2, 6, 3, 4, 8, 9, 5]
    """
    sorted_third_values = sorted(_third_index_values(l))
    return _merge_sorted_third_values(l, sorted_third_values)
candidate = sort_third




METADATA = {}


def check(candidate):
    assert tuple(candidate([1, 2, 3])) == tuple(sort_third([1, 2, 3]))
    assert tuple(candidate([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])) == tuple(sort_third([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10]))
    assert tuple(candidate([5, 8, -12, 4, 23, 2, 3, 11, 12, -10])) == tuple(sort_third([5, 8, -12, 4, 23, 2, 3, 11, 12, -10]))
    assert tuple(candidate([5, 6, 3, 4, 8, 9, 2])) == tuple([2, 6, 3, 4, 8, 9, 5])
    assert tuple(candidate([5, 8, 3, 4, 6, 9, 2])) == tuple([2, 8, 3, 4, 6, 9, 5])
    assert tuple(candidate([5, 6, 9, 4, 8, 3, 2])) == tuple([2, 6, 9, 4, 8, 3, 5])
    assert tuple(candidate([5, 6, 3, 4, 8, 9, 2, 1])) == tuple([2, 6, 3, 4, 8, 9, 5, 1])



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
