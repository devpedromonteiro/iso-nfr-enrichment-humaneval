
import unittest
import re
import sys
import math
import copy



def _has_divisor(n, candidate):
    """Return True if ``candidate`` divides ``n`` evenly."""
    return n % candidate == 0


def _is_invalid_prime_candidate(n):
    """Return True when ``n`` cannot be a prime number."""
    return n <= 1


def _has_trivial_prime_result(n):
    """Handle small-number prime cases."""
    return n <= 3


def _is_even(n):
    """Return True if ``n`` is even."""
    return n % 2 == 0


def is_prime(n):
    """Return true if a given number is prime, and false otherwise.
    >>> is_prime(6)
    False
    >>> is_prime(101)
    True
    >>> is_prime(11)
    True
    >>> is_prime(13441)
    True
    >>> is_prime(61)
    True
    >>> is_prime(4)
    False
    >>> is_prime(1)
    False
    """
    if _is_invalid_prime_candidate(n):
        return False

    if _has_trivial_prime_result(n):
        return True

    if _is_even(n):
        return False

    divisor = 3
    while divisor * divisor <= n:
        if _has_divisor(n, divisor):
            return False
        divisor += 2

    return True
candidate = is_prime




METADATA = {}


def check(candidate):
    assert candidate(6) == False
    assert candidate(101) == True
    assert candidate(11) == True
    assert candidate(13441) == True
    assert candidate(61) == True
    assert candidate(4) == False
    assert candidate(1) == False
    assert candidate(5) == True
    assert candidate(11) == True
    assert candidate(17) == True
    assert candidate(5 * 17) == False
    assert candidate(11 * 7) == False
    assert candidate(13441 * 19) == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
