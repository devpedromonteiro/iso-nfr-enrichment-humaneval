
import unittest
import re
import sys
import math
import copy


def _count_descending_breaks(arr):
    """Count positions where the non-decreasing order is broken."""
    breaks = 0
    for current, nxt in zip(arr, arr[1:]):
        if current > nxt:
            breaks += 1
    return breaks


def _wraps_correctly(arr):
    """Check that the last element can rotate before the first."""
    return not arr or arr[-1] <= arr[0]


def move_one_ball(arr):
    """Return True if some number of right shifts can sort the array."""
    if not arr:
        return True

    descending_breaks = _count_descending_breaks(arr)

    if descending_breaks == 0:
        return True

    if descending_breaks == 1 and _wraps_correctly(arr):
        return True

    return False
candidate = move_one_ball


def check(candidate):

    # Check some simple cases
    assert candidate([3, 4, 5, 1, 2])==True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([3, 5, 10, 1, 2])==True
    assert candidate([4, 3, 1, 2])==False
    # Check some edge cases that are easy to work out by hand.
    assert candidate([3, 5, 4, 1, 2])==False, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([])==True


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
