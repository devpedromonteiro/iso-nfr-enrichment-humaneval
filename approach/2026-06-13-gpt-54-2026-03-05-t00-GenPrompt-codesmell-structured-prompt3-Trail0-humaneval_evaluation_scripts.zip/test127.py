
import unittest
import re
import sys
import math
import copy


def _intersection_length(interval1, interval2):
    start = max(interval1[0], interval2[0])
    end = min(interval1[1], interval2[1])

    if start > end:
        return 0

    return end - start


def _is_prime(number):
    if number < 2:
        return False

    divisor = 2
    while divisor * divisor <= number:
        if number % divisor == 0:
            return False
        divisor += 1

    return True


def intersection(interval1, interval2):
    """Determine whether the length of the intersection of two closed intervals is prime.

    The intersection length is computed as geometric length, so for an intersection
    (a, b) the length is b - a.

    Examples:
        intersection((1, 2), (2, 3)) == "NO"
        intersection((-1, 1), (0, 4)) == "NO"
        intersection((-3, -1), (-5, 5)) == "YES"
    """
    length = _intersection_length(interval1, interval2)
    return "YES" if _is_prime(length) else "NO"
candidate = intersection


def check(candidate):

    # Check some simple cases
    assert candidate((1, 2), (2, 3)) == "NO"
    assert candidate((-1, 1), (0, 4)) == "NO"
    assert candidate((-3, -1), (-5, 5)) == "YES"
    assert candidate((-2, 2), (-4, 0)) == "YES"

    # Check some edge cases that are easy to work out by hand.
    assert candidate((-11, 2), (-1, -1)) == "NO"
    assert candidate((1, 2), (3, 5)) == "NO"
    assert candidate((1, 2), (1, 2)) == "NO"
    assert candidate((-2, -2), (-3, -2)) == "NO"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
