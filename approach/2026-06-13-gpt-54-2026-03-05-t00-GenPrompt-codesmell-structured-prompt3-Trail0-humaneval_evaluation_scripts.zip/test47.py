
import unittest
import re
import sys
import math
import copy



def median(values: list):
    """Return the median of the elements in ``values``.

    The input list is not modified.

    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    8.0
    """
    sorted_values = _sorted_copy(values)
    size = len(sorted_values)

    if size == 0:
        raise ValueError("median() arg is an empty list")

    middle_index = size // 2

    if _is_odd(size):
        return sorted_values[middle_index]

    return _average_middle_pair(sorted_values, middle_index)


def _sorted_copy(values: list) -> list:
    """Return a sorted copy of the input values."""
    return sorted(values)


def _is_odd(number: int) -> bool:
    """Return True when number is odd."""
    return number % 2 == 1


def _average_middle_pair(sorted_values: list, right_middle_index: int) -> float:
    """Return the average of the two middle values in a sorted list."""
    left_middle_index = right_middle_index - 1
    left_value = sorted_values[left_middle_index]
    right_value = sorted_values[right_middle_index]
    return (left_value + right_value) / 2
candidate = median




METADATA = {}


def check(candidate):
    assert candidate([3, 1, 2, 4, 5]) == 3
    assert candidate([-10, 4, 6, 1000, 10, 20]) == 8.0
    assert candidate([5]) == 5
    assert candidate([6, 5]) == 5.5
    assert candidate([8, 1, 3, 9, 9, 2, 7]) == 7 



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
