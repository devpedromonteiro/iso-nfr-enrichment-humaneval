
import unittest
import re
import sys
import math
import copy


def get_closest_vowel(word):
    """Return the rightmost vowel that is between two consonants.

    A vowel qualifies only if it is not at the beginning or end of the word
    and both adjacent characters are consonants. Search is performed from
    right to left. Returns an empty string if no such vowel exists.
    """
    vowels = {"a", "e", "i", "o", "u", "A", "E", "I", "O", "U"}

    def is_vowel(char):
        return char in vowels

    def is_consonant(char):
        return char.isalpha() and not is_vowel(char)

    for index in range(len(word) - 2, 0, -1):
        current = word[index]
        if (
            is_vowel(current)
            and is_consonant(word[index - 1])
            and is_consonant(word[index + 1])
        ):
            return current

    return ""
candidate = get_closest_vowel


def check(candidate):

    # Check some simple cases
    assert candidate("yogurt") == "u"
    assert candidate("full") == "u"
    assert candidate("easy") == ""
    assert candidate("eAsy") == ""
    assert candidate("ali") == ""
    assert candidate("bad") == "a"
    assert candidate("most") == "o"
    assert candidate("ab") == ""
    assert candidate("ba") == ""
    assert candidate("quick") == ""
    assert candidate("anime") == "i"
    assert candidate("Asia") == ""
    assert candidate("Above") == "o"

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
