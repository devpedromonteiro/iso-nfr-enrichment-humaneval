
import unittest
import re
import sys
import math
import copy



def _validate_fib4_input(n: int) -> None:
    """Validate the input for fib4."""
    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if n < 0:
        raise ValueError("n must be non-negative")


def _fib4_base_case(n: int):
    """Return the base-case value for fib4, or None if n is not a base case."""
    base_cases = (0, 0, 2, 0)
    if n < len(base_cases):
        return base_cases[n]
    return None


def fib4(n: int):
    """Compute the n-th element of the Fib4 sequence iteratively.

    The Fib4 sequence is defined as:
    fib4(0) -> 0
    fib4(1) -> 0
    fib4(2) -> 2
    fib4(3) -> 0
    fib4(n) -> fib4(n-1) + fib4(n-2) + fib4(n-3) + fib4(n-4)

    >>> fib4(5)
    4
    >>> fib4(6)
    8
    >>> fib4(7)
    14
    """
    _validate_fib4_input(n)

    base_case = _fib4_base_case(n)
    if base_case is not None:
        return base_case

    a, b, c, d = 0, 0, 2, 0
    for _ in range(4, n + 1):
        a, b, c, d = b, c, d, a + b + c + d

    return d
candidate = fib4




METADATA = {}


def check(candidate):
    assert candidate(5) == 4
    assert candidate(8) == 28
    assert candidate(10) == 104
    assert candidate(12) == 386



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
