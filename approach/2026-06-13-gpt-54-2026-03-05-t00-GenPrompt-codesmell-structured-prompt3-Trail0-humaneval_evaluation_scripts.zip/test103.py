
import unittest
import re
import sys
import math
import copy


def _average_of_range(start, end):
    """Return the arithmetic mean of all integers in the inclusive range."""
    count = end - start + 1
    total = (start + end) * count / 2
    return total / count


def _rounded_binary(value):
    """Round a numeric value to the nearest integer and return its binary form."""
    return bin(round(value))


def rounded_avg(n, m):
    """Compute the rounded average of integers from n to m and return it in binary.

    If n is greater than m, return -1.
    """
    if n > m:
        return -1

    average = _average_of_range(n, m)
    return _rounded_binary(average)
candidate = rounded_avg


def check(candidate):

    # Check some simple cases
    assert candidate(1, 5) == "0b11"
    assert candidate(7, 13) == "0b1010"
    assert candidate(964,977) == "0b1111001010"
    assert candidate(996,997) == "0b1111100100"
    assert candidate(560,851) == "0b1011000010"
    assert candidate(185,546) == "0b101101110"
    assert candidate(362,496) == "0b110101101"
    assert candidate(350,902) == "0b1001110010"
    assert candidate(197,233) == "0b11010111"


    # Check some edge cases that are easy to work out by hand.
    assert candidate(7, 5) == -1
    assert candidate(5, 1) == -1
    assert candidate(5, 5) == "0b101"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
