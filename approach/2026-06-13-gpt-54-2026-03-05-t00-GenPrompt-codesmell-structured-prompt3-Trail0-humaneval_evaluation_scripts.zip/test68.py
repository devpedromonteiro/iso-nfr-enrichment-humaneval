
import unittest
import re
import sys
import math
import copy


def pluck(arr):
    smallest_even_value = None
    smallest_even_index = None

    for index, value in enumerate(arr):
        if _is_even(value) and _is_better_candidate(value, smallest_even_value):
            smallest_even_value = value
            smallest_even_index = index

    return _build_result(smallest_even_value, smallest_even_index)


def _is_even(value):
    return value % 2 == 0


def _is_better_candidate(value, current_smallest):
    return current_smallest is None or value < current_smallest


def _build_result(value, index):
    if value is None:
        return []
    return [value, index]
candidate = pluck


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([4,2,3]) == [2, 1], "Error"
    assert candidate([1,2,3]) == [2, 1], "Error"
    assert candidate([]) == [], "Error"
    assert candidate([5, 0, 3, 0, 4, 2]) == [0, 1], "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([1, 2, 3, 0, 5, 3]) == [0, 3], "Error"
    assert candidate([5, 4, 8, 4 ,8]) == [4, 1], "Error"
    assert candidate([7, 6, 7, 1]) == [6, 1], "Error"
    assert candidate([7, 9, 7, 1]) == [], "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
