
import unittest
import re
import sys
import math
import copy


from functools import lru_cache


def minPath(grid, k):
    """
    Given a grid with N rows and N columns (N >= 2) and a positive integer k,
    each cell of the grid contains a value. Every integer in the range [1, N * N]
    inclusive appears exactly once on the cells of the grid.

    Return the lexicographically smallest path of length k, represented by the
    ordered list of visited cell values.
    """
    if not grid or not grid[0] or k <= 0:
        return []

    rows = len(grid)
    cols = len(grid[0])

    value_to_position = _build_value_position_map(grid)
    neighbors = _build_neighbors(rows, cols)

    @lru_cache(maxsize=None)
    def best_suffix_from(cell, remaining_length):
        if remaining_length == 1:
            return (grid[cell[0]][cell[1]],)

        current_value = grid[cell[0]][cell[1]]
        candidate_suffixes = []

        for neighbor in neighbors[cell]:
            candidate_suffixes.append(best_suffix_from(neighbor, remaining_length - 1))

        return (current_value,) + min(candidate_suffixes)

    smallest_start_value = min(value_to_position)
    start_cell = value_to_position[smallest_start_value]

    return list(best_suffix_from(start_cell, k))


def _build_value_position_map(grid):
    value_to_position = {}
    for row_index, row in enumerate(grid):
        for col_index, value in enumerate(row):
            value_to_position[value] = (row_index, col_index)
    return value_to_position


def _build_neighbors(rows, cols):
    neighbors = {}
    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]

    for row in range(rows):
        for col in range(cols):
            cell_neighbors = []
            for d_row, d_col in directions:
                next_row = row + d_row
                next_col = col + d_col
                if 0 <= next_row < rows and 0 <= next_col < cols:
                    cell_neighbors.append((next_row, next_col))
            neighbors[(row, col)] = cell_neighbors

    return neighbors
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
