
import unittest
import re
import sys
import math
import copy


def _should_sort_ascending(array):
    """Return True when the first and last values sum to an odd number."""
    return (array[0] + array[-1]) % 2 == 1


def sort_array(array):
    """
    Given an array of non-negative integers, return a copy of the given array after sorting.
    Sort in ascending order if the sum of the first and last values is odd,
    otherwise sort in descending order if the sum is even.

    Note:
    * don't change the given array.
    """
    if len(array) < 2:
        return array.copy()

    reverse = not _should_sort_ascending(array)
    return sorted(array, reverse=reverse)
candidate = sort_array


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([]) == [], "Error"
    assert candidate([5]) == [5], "Error"
    assert candidate([2, 4, 3, 0, 1, 5]) == [0, 1, 2, 3, 4, 5], "Error"
    assert candidate([2, 4, 3, 0, 1, 5, 6]) == [6, 5, 4, 3, 2, 1, 0], "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([2, 1]) == [1, 2], "Error"
    assert candidate([15, 42, 87, 32 ,11, 0]) == [0, 11, 15, 32, 42, 87], "Error"
    assert candidate([21, 14, 23, 11]) == [23, 21, 14, 11], "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
