
import unittest


def match_parens(lst):
    """
    Given two strings made only of '(' and ')', determine whether
    concatenating them in either order can produce a balanced
    parentheses string.

    A balanced string must:
    1. Have the same number of '(' and ')'
    2. Never have more ')' than '(' at any point while scanning left to right

    Returns:
        'Yes' if either concatenation order is balanced, otherwise 'No'
    """

    def is_balanced(s):
        balance = 0
        for char in s:
            if char == '(':
                balance += 1
            else:
                balance -= 1

            if balance < 0:
                return False

        return balance == 0

    first, second = lst

    if is_balanced(first + second) or is_balanced(second + first):
        return 'Yes'
    return 'No'
candidate = match_parens


class Test(unittest.TestCase):
    def test(self):
        assert candidate((')())', '(()()(')) == 'Yes'
        assert candidate(('((((', ')')) == 'No'
        assert candidate(('()(', '())')) == 'Yes'
        assert candidate(('())', '((((')) == 'No'
        assert candidate(('(()(', '()(')) == 'No'
        assert candidate(('())', '(()()(')) == 'No'
        assert candidate([')', ')']) == 'No'
        assert candidate(('()(', ')')) == 'Yes'
        assert candidate(('(()(())', '()(')) == 'No'
        assert candidate(('(()()(', '())())')) == 'Yes'
        assert candidate(('())', ')())')) == 'No'
        assert candidate(('((((', '((((')) == 'No'
        assert candidate((')(', '(()()(')) == 'No'
        assert candidate((')())', ')())')) == 'No'
        assert candidate((')())', '((())')) == 'No'
        assert candidate(('()', '()(')) == 'No'
        assert candidate(('(()(())', '())())')) == 'No'
        assert candidate(('(', ')')) == 'Yes'
        assert candidate(('(())))', '()(')) == 'No'
        assert candidate(('()', '(()())((')) == 'No'
        assert candidate(('())())', '()(')) == 'No'
        assert candidate(('())())', '(()()(')) == 'Yes'
        assert candidate(('()(', '())())')) == 'No'
        assert candidate(('()))()', '())')) == 'No'
        assert candidate(('(())))', '((())')) == 'No'
        assert candidate(['()', '())']) == 'No'
        assert candidate(['(())))', '(()())((']) == 'Yes'
        assert candidate((')', '(())))')) == 'No'
        assert candidate([')())', '(()()(']) == 'Yes'
        assert candidate(('(()()(', '(()()(')) == 'No'
        assert candidate((')', '(()(())')) == 'Yes'
        assert candidate([')(()', '(()(']) == 'No'
        assert candidate(('(()(())', ')')) == 'Yes'
        assert candidate((')(', '()(')) == 'No'
        assert candidate(('(()()(', ')(()')) == 'No'
        assert candidate(('()(', '(()(())')) == 'No'
        assert candidate((')', '()(')) == 'Yes'
        assert candidate(('())', ')')) == 'No'
        assert candidate(('(()())((', '(()(())')) == 'No'
        assert candidate(('(()(', ')(()')) == 'No'
        assert candidate(('())())', ')())')) == 'No'
        assert candidate(('())', ')(')) == 'No'
        assert candidate(('(()(())', ')(')) == 'No'
        assert candidate(('()', '())')) == 'No'
        assert candidate((')())', '()(')) == 'No'
        assert candidate([')(', ')(']) == 'No'
    

    # Check some edge cases that are easy to work out by hand.
        assert candidate(('(()(', '(()())((')) == 'No'
        assert candidate((')', '(()()(')) == 'No'
        assert candidate(('()(', '(()())((')) == 'No'
        assert candidate(('((())', '(()(')) == 'No'
        assert candidate((')', '())())')) == 'No'
        assert candidate(('()(', '()(')) == 'No'
        assert candidate(['()(', ')']) == 'Yes'
        assert candidate(('(()()(', '(()(())')) == 'No'
        assert candidate(('())())', '()')) == 'No'
        assert candidate(('(()(())', '())')) == 'Yes'
        assert candidate(['(()(', '()))()']) == 'Yes'
        assert candidate(('(()(', '(()(')) == 'No'
        assert candidate(('(())))', '(())))')) == 'No'
        assert candidate(('()(', '(()(')) == 'No'
        assert candidate(('(', '(()())((')) == 'No'
        assert candidate(['(', ')']) == 'Yes'
        assert candidate(['((((', '((())']) == 'No'
        assert candidate(('())())', '(()(())')) == 'No'
        assert candidate(('())', '()')) == 'No'
        assert candidate(('(', '()))()')) == 'No'
        assert candidate(('())())', '(()(')) == 'Yes'
        assert candidate(('(()(())', ')())')) == 'No'
        assert candidate(('((((', '()')) == 'No'
        assert candidate((')())', '(())))')) == 'No'
        assert candidate(('(()())((', ')')) == 'No'
        assert candidate(('()(', ')())')) == 'No'
        assert candidate(('())', '()(')) == 'Yes'
        assert candidate(('()', '(()(())')) == 'No'
        assert candidate((')(()', '(())))')) == 'No'
        assert candidate(('(()()(', '()(')) == 'No'
        assert candidate(('())())', ')')) == 'No'
        assert candidate(['(()(())', '())())']) == 'No'
        assert candidate((')', ')')) == 'No'
        assert candidate(('())())', ')(()')) == 'No'
        assert candidate(('()))()', '(()(')) == 'Yes'
        assert candidate((')())', '((((')) == 'No'
        assert candidate(('(()(())', '(()()(')) == 'No'
        assert candidate(('()', ')())')) == 'No'
        assert candidate(('(())))', '(()()(')) == 'Yes'
        assert candidate((')(', ')(()')) == 'No'
        assert candidate(('(()()(', '(())))')) == 'Yes'
        assert candidate(('(())))', '(()(())')) == 'No'
        assert candidate(('((((', '(()(')) == 'No'
        assert candidate([')', '(']) == 'Yes'
        assert candidate((')(()', '())')) == 'No'
        assert candidate((')())', '())())')) == 'No'

if __name__ == '__main__':
    unittest.main()
