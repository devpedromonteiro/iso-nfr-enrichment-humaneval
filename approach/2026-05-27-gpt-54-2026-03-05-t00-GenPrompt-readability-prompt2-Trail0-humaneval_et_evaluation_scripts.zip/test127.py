
import unittest


def intersection(interval1, interval2):
    """
    Determine whether the length of the intersection of two closed intervals
    is a prime number.

    Each interval is represented as a tuple: (start, end), where start <= end.
    Closed intervals include both endpoints, but the length is calculated as:
        intersection_end - intersection_start

    Returns:
        "YES" if the intersection length is a prime number
        "NO" otherwise

    Examples:
        intersection((1, 2), (2, 3)) -> "NO"
        intersection((-1, 1), (0, 4)) -> "NO"
        intersection((-3, -1), (-5, 5)) -> "YES"
    """

    def is_prime(number):
        """Return True if number is prime, otherwise False."""
        if number < 2:
            return False

        for divisor in range(2, int(number ** 0.5) + 1):
            if number % divisor == 0:
                return False

        return True

    start1, end1 = interval1
    start2, end2 = interval2

    intersection_start = max(start1, start2)
    intersection_end = min(end1, end2)

    if intersection_start >= intersection_end:
        return "NO"

    intersection_length = intersection_end - intersection_start

    return "YES" if is_prime(intersection_length) else "NO"
candidate = intersection


class Test(unittest.TestCase):
    def test(self):
        assert candidate((-1, 1), (0, 4)) == "NO"
        assert candidate((-1, 6), (2, 5)) == 'YES'
        assert candidate((4, 3), (3, 6)) == 'NO'
        assert candidate((-2, 2), (-10, 8)) == 'NO'
        assert candidate((-9, 5), (-2, -3)) == 'NO'
        assert candidate((-2, -1), (-4, 4)) == 'NO'
        assert candidate((5, 7), (6, 3)) == 'NO'
        assert candidate((1, 5), (7, 6)) == 'NO'
        assert candidate((6, 2), (3, 2)) == 'NO'
        assert candidate((-7, -6), (0, -3)) == 'NO'
        assert candidate((-12, 1), (-4, -5)) == 'NO'
        assert candidate((-8, 2), (-4, 2)) == 'NO'
        assert candidate((-7, 1), (-4, 2)) == 'YES'
        assert candidate((-1, 6), (-9, 4)) == 'YES'
        assert candidate((1, 6), (8, 7)) == 'NO'
        assert candidate((6, 4), (3, 6)) == 'NO'
        assert candidate((5, 1), (1, 9)) == 'NO'
        assert candidate((0, 1), (-2, -3)) == 'NO'
        assert candidate((-6, 4), (-7, 2)) == 'NO'
        assert candidate((5, 4), (4, 7)) == 'NO'
        assert candidate((-6, 4), (0, 1)) == 'NO'
        assert candidate((-2, -2), (-3, -2)) == "NO"
        assert candidate((-3, -3), (-2, 9)) == 'NO'
        assert candidate((6, 2), (7, 8)) == 'NO'
        assert candidate((2, 3), (6, 1)) == 'NO'
        assert candidate((1, 6), (0, 2)) == 'NO'
        assert candidate((-11, 2), (-1, -1)) == "NO"
        assert candidate((-3, 5), (-5, 1)) == 'NO'
        assert candidate((-6, -2), (-7, -5)) == 'NO'
        assert candidate((3, 5), (8, 1)) == 'NO'
        assert candidate((-6, -3), (-7, 8)) == 'YES'
        assert candidate((1, 7), (4, 1)) == 'NO'
        assert candidate((4, 1), (2, 5)) == 'NO'
        assert candidate((6, 7), (4, 2)) == 'NO'
        assert candidate((3, 6), (2, 6)) == 'YES'
        assert candidate((6, 7), (2, 6)) == 'NO'
        assert candidate((-5, 6), (4, 9)) == 'YES'
        assert candidate((1, 2), (3, 5)) == "NO"
        assert candidate((-15, 4), (-3, -1)) == 'YES'
        assert candidate((4, 5), (6, 3)) == 'NO'
        assert candidate((4, 2), (2, 1)) == 'NO'
        assert candidate((-3, 0), (-7, 2)) == 'YES'
        assert candidate((-2, 1), (1, 1)) == 'NO'
        assert candidate((3, 1), (4, 5)) == 'NO'
        assert candidate((-2, 5), (5, 1)) == 'NO'
        assert candidate((6, 3), (7, 4)) == 'NO'
        assert candidate((5, 7), (5, 3)) == 'NO'
        assert candidate((0, -2), (-8, 7)) == 'NO'
        assert candidate((-3, 5), (1, 4)) == 'YES'
        assert candidate((-6, 1), (4, 1)) == 'NO'
        assert candidate((2, 3), (4, 3)) == 'NO'
        assert candidate((4, 6), (4, 8)) == 'YES'
        assert candidate((-7, 5), (-6, 4)) == 'NO'
        assert candidate((5, 6), (6, 3)) == 'NO'
        assert candidate((5, 5), (3, 3)) == 'NO'
        assert candidate((3, 1), (3, 9)) == 'NO'
        assert candidate((4, 7), (4, 4)) == 'NO'
        assert candidate((-9, 3), (4, -4)) == 'NO'
        assert candidate((-16, 6), (-6, -4)) == 'YES'
        assert candidate((2, 3), (8, 2)) == 'NO'
        assert candidate((3, 4), (5, 7)) == 'NO'
        assert candidate((5, 7), (5, 1)) == 'NO'
        assert candidate((-3, -6), (-9, 8)) == 'NO'
        assert candidate((-6, 1), (-3, 2)) == 'NO'
        assert candidate((-8, 4), (-3, -3)) == 'NO'
        assert candidate((-14, 6), (-1, -6)) == 'NO'
        assert candidate((-2, 1), (-9, 5)) == 'YES'
        assert candidate((-15, 1), (2, 1)) == 'NO'
        assert candidate((-1, -1), (-2, -3)) == 'NO'
        assert candidate((-6, 3), (-6, 1)) == 'YES'
        assert candidate((-1, 0), (-5, 3)) == 'NO'
        assert candidate((1, 6), (4, 1)) == 'NO'
        assert candidate((-1, 2), (-8, 10)) == 'YES'
        assert candidate((1, -7), (-2, 3)) == 'NO'
        assert candidate((1, 1), (1, 9)) == 'NO'
        assert candidate((-6, 7), (-2, 2)) == 'NO'
        assert candidate((1, 4), (2, 6)) == 'YES'
        assert candidate((5, 7), (2, 1)) == 'NO'
        assert candidate((1, 1), (5, 3)) == 'NO'
        assert candidate((-4, -1), (0, -3)) == 'NO'
        assert candidate((1, 2), (2, 3)) == "NO"
        assert candidate((0, 5), (2, 2)) == 'NO'
        assert candidate((5, 4), (8, 8)) == 'NO'
        assert candidate((1, 2), (1, 2)) == "NO"
        assert candidate((2, 2), (8, 8)) == 'NO'
        assert candidate((0, 5), (3, 8)) == 'YES'
        assert candidate((-8, 2), (-3, -5)) == 'NO'
        assert candidate((2, -4), (-4, 1)) == 'NO'
        assert candidate((1, 5), (3, 3)) == 'NO'
        assert candidate((5, 3), (7, 8)) == 'NO'
        assert candidate((2, 1), (4, 6)) == 'NO'
        assert candidate((3, 6), (1, 2)) == 'NO'
        assert candidate((0, 2), (-10, 10)) == 'YES'
        assert candidate((-3, -1), (-5, 5)) == "YES"
        assert candidate((-5, 5), (3, 9)) == 'YES'
        assert candidate((1, 2), (2, 10)) == 'NO'
        assert candidate((-12, 2), (1, -6)) == 'NO'
        assert candidate((5, 6), (6, 4)) == 'NO'
        assert candidate((-4, -4), (-2, 4)) == 'NO'
        assert candidate((0, 6), (-2, 2)) == 'YES'
        assert candidate((-12, 4), (-2, 4)) == 'NO'
        assert candidate((2, 6), (4, 6)) == 'YES'
        assert candidate((2, 1), (5, 4)) == 'NO'
        assert candidate((2, 4), (1, 5)) == 'YES'
        assert candidate((0, -1), (-2, -7)) == 'NO'
        assert candidate((4, 2), (4, 3)) == 'NO'
        assert candidate((2, 5), (0, 5)) == 'YES'
        assert candidate((2, 3), (-1, 4)) == 'NO'
        assert candidate((-6, 0), (-7, 0)) == 'NO'
        assert candidate((3, 2), (1, 3)) == 'NO'
        assert candidate((-5, 2), (1, 4)) == 'NO'
        assert candidate((-3, 4), (-1, 8)) == 'YES'
        assert candidate((0, 2), (-8, 7)) == 'YES'
        assert candidate((-1, 1), (-2, 3)) == 'YES'
        assert candidate((-4, 7), (1, 5)) == 'NO'
        assert candidate((5, 7), (3, 4)) == 'NO'
        assert candidate((5, 7), (4, 5)) == 'NO'
        assert candidate((3, 3), (-3, 2)) == 'NO'
        assert candidate((-2, -7), (-5, -4)) == 'NO'
        assert candidate((-3, 2), (-5, -1)) == 'YES'
        assert candidate((5, 3), (6, 2)) == 'NO'
        assert candidate((-16, 3), (-4, 2)) == 'NO'
        assert candidate((-4, 3), (0, -3)) == 'NO'
        assert candidate((-2, 2), (-4, 0)) == "YES"

    # Check some edge cases that are easy to work out by hand.
        assert candidate((-3, -1), (-2, 5)) == 'NO'
        assert candidate((1, 2), (4, 7)) == 'NO'
        assert candidate((6, 3), (3, 3)) == 'NO'

if __name__ == '__main__':
    unittest.main()
