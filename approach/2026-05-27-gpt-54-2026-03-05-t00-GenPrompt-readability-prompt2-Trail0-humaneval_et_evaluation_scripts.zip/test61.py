
import unittest



def correct_bracketing(brackets: str) -> bool:
    """Return True if the parentheses in `brackets` are balanced.

    A string is correctly bracketed when:
    - every opening "(" has a matching closing ")"
    - no closing bracket appears before its matching opening bracket

    >>> correct_bracketing("(")
    False
    >>> correct_bracketing("()")
    True
    >>> correct_bracketing("(()())")
    True
    >>> correct_bracketing(")(()")
    False
    """
    balance = 0

    for bracket in brackets:
        if bracket == "(":
            balance += 1
        else:  # bracket == ")"
            balance -= 1

        # More closing brackets than opening ones at some point
        if balance < 0:
            return False

    # All opening brackets must be closed
    return balance == 0
candidate = correct_bracketing


class Test(unittest.TestCase):
    def test(self):
        assert candidate("(") == False
        assert candidate("))()))((())((()()((((") == False
        assert candidate(")((((((()())())()(((") == False
        assert candidate(")((())))()(()))())") == False
        assert not candidate("(()")
        assert candidate("(()())") == True
        assert candidate("(()())()()((()()())())(()()(()))()") == True
        assert candidate("()))") == False
        assert not candidate(")")
        assert candidate("()()") == True
        assert candidate(")())()())))(((") == False
        assert candidate("))((((((()") == False
        assert candidate(")((((") == False
        assert candidate("()(()())") == True
        assert candidate("(()())()()((()()())())(()()(()))") == True
        assert candidate("((())()))") == False
        assert candidate("()()()(())(") == False
        assert candidate("))())") == False
        assert candidate("()()(()())()")
        assert candidate("()()(()())()") == True
        assert candidate(")") == False
        assert candidate("()()()") == True
        assert candidate("()))()(") == False
        assert candidate("(())") == True
        assert candidate("()()(()())()()()(()())()") == True
        assert candidate("()()(()())()()()(()())()()()((()()())())(()()(()))") == True
        assert candidate("(()())()(()())") == True
        assert candidate("(()))))()") == False
        assert candidate(")(()())(") == False
        assert candidate("((((") == False
        assert candidate("(()())")
        assert candidate("(((()") == False
        assert candidate("))()") == False
        assert candidate(")))((") == False
        assert candidate(")()())") == False
        assert candidate("(()") == False
        assert candidate("(()())(()())()") == True
        assert candidate("(()())()()(()())()") == True
        assert candidate("()()(()())()(()())()") == True
        assert not candidate("((((")
        assert candidate("))))") == False
        assert candidate("()") == True
        assert candidate("())") == False
        assert candidate(")()(())()((()())") == False
        assert candidate("))()))))(()()(") == False
        assert candidate("()())())(") == False
        assert candidate("()()()()(()())()") == True
        assert candidate(")()(") == False
        assert candidate("((((((") == False
        assert candidate("()()()((()()(") == False
        assert candidate("()()((()()())())(()()(()))()()(()())()()") == True
        assert not candidate("((()())))")
        assert candidate("()")
        assert not candidate("(")
        assert candidate("())())((()()))") == False
        assert candidate("(()())()") == True
        assert candidate(")(()))(((()((()") == False
        assert candidate("()))))") == False
        assert candidate("))())()))(())") == False
        assert candidate(")())())()") == False
        assert candidate(")((()))))((()(") == False
        assert candidate("()())())))(()(())()") == False
        assert candidate(")((((((") == False
        assert not candidate(")(()")
        assert candidate("((())()()") == False
        assert not candidate("()()(()())()))()")
        assert candidate(")(()(())((())((())") == False
        assert candidate(")(()") == False
        assert candidate(")()") == False
        assert candidate("()()(()())()()()((()()())())(()()(()))(()())") == True
        assert candidate("()()(()())()()") == True
        assert candidate("(()())()()((()()())())(()()(()))(()())") == True
        assert candidate("()()((()()())())(()()(()))")
        assert candidate("(((") == False
        assert candidate("") == True
        assert not candidate("()()(()())())(()")
        assert candidate("()(())()()()") == True
        assert candidate(")()()(()(())(") == False
        assert candidate("))()()())(())") == False

if __name__ == '__main__':
    unittest.main()
