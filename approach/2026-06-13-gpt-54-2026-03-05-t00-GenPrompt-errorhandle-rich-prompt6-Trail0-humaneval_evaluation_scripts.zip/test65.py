
import unittest
import re
import sys
import math
import copy


def circular_shift(x, shift):
    """Circular shift the digits of the integer x, shifting right by ``shift``
    positions, and return the result as a string.

    If ``shift`` is greater than the number of digits, return the digits reversed.

    Args:
        x: Integer whose digits will be shifted.
        shift: Non-negative integer shift amount.

    Returns:
        A string containing the shifted digits.

    Raises:
        TypeError: If ``x`` or ``shift`` is not an integer.
        ValueError: If ``shift`` is negative.

    Examples:
        >>> circular_shift(12, 1)
        '21'
        >>> circular_shift(12, 2)
        '12'
        >>> circular_shift(1234, 1)
        '4123'
        >>> circular_shift(1234, 5)
        '4321'
    """
    if not isinstance(x, int):
        raise TypeError(f"x must be an integer, got {type(x).__name__}")
    if not isinstance(shift, int):
        raise TypeError(f"shift must be an integer, got {type(shift).__name__}")
    if shift < 0:
        raise ValueError("shift must be non-negative")

    digits = str(abs(x))
    sign = "-" if x < 0 else ""

    if len(digits) == 0:
        # Defensive check; should never occur for valid integers.
        raise ValueError("x must contain at least one digit")

    if shift > len(digits):
        result = digits[::-1]
    else:
        effective_shift = shift % len(digits)
        result = digits[-effective_shift:] + digits[:-effective_shift] if effective_shift else digits

    return sign + result
candidate = circular_shift


def check(candidate):

    # Check some simple cases
    assert candidate(100, 2) == "001"
    assert candidate(12, 2) == "12"
    assert candidate(97, 8) == "79"
    assert candidate(12, 1) == "21", "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(11, 101) == "11", "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
