
import unittest
import re
import sys
import math
import copy


def get_closest_vowel(word):
    """Return the rightmost vowel that is between two consonants.

    A vowel at the beginning or end of the word does not count.
    The search is case sensitive in the sense that the original character
    is returned unchanged.

    Args:
        word: A string containing English letters only.

    Returns:
        The closest vowel from the right that is surrounded by consonants,
        or an empty string if no such vowel exists.

    Raises:
        TypeError: If word is not a string.
        ValueError: If word contains non-alphabetic characters.
    """
    if not isinstance(word, str):
        raise TypeError("word must be a string")

    if not word.isalpha():
        raise ValueError("word must contain English letters only")

    if len(word) < 3:
        return ""

    vowels = {"a", "e", "i", "o", "u", "A", "E", "I", "O", "U"}

    for i in range(len(word) - 2, 0, -1):
        ch = word[i]
        if (
            ch in vowels
            and word[i - 1] not in vowels
            and word[i + 1] not in vowels
        ):
            return ch

    return ""
candidate = get_closest_vowel


def check(candidate):

    # Check some simple cases
    assert candidate("yogurt") == "u"
    assert candidate("full") == "u"
    assert candidate("easy") == ""
    assert candidate("eAsy") == ""
    assert candidate("ali") == ""
    assert candidate("bad") == "a"
    assert candidate("most") == "o"
    assert candidate("ab") == ""
    assert candidate("ba") == ""
    assert candidate("quick") == ""
    assert candidate("anime") == "i"
    assert candidate("Asia") == ""
    assert candidate("Above") == "o"

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
