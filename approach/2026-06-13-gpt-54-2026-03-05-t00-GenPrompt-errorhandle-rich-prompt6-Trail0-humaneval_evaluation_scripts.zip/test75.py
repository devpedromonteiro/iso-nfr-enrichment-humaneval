
import unittest
import re
import sys
import math
import copy


def is_multiply_prime(a):
    """Return True if `a` is the product of exactly 3 prime numbers, else False.

    The 3 prime factors do not need to be distinct.
    Examples:
        30 = 2 * 3 * 5  -> True
         8 = 2 * 2 * 2  -> True
        12 = 2 * 2 * 3  -> True
         7               -> False

    Constraints handled:
    - validates input explicitly
    - raises specific exceptions for invalid arguments
    - does not silently swallow errors
    """
    if isinstance(a, bool):
        raise TypeError("a must be an integer, not bool")
    if not isinstance(a, int):
        raise TypeError("a must be an integer")
    if a < 0:
        raise ValueError("a must be non-negative")
    if a >= 100:
        raise ValueError("a must be less than 100")

    if a < 8:
        return False

    def is_prime(n):
        if n < 2:
            return False
        for i in range(2, int(n ** 0.5) + 1):
            if n % i == 0:
                return False
        return True

    primes = [p for p in range(2, a + 1) if is_prime(p)]

    for i in primes:
        for j in primes:
            for k in primes:
                if i * j * k == a:
                    return True

    return False
candidate = is_multiply_prime


def check(candidate):

    assert candidate(5) == False
    assert candidate(30) == True
    assert candidate(8) == True
    assert candidate(10) == False
    assert candidate(125) == True
    assert candidate(3 * 5 * 7) == True
    assert candidate(3 * 6 * 7) == False
    assert candidate(9 * 9 * 9) == False
    assert candidate(11 * 9 * 9) == False
    assert candidate(11 * 13 * 7) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
