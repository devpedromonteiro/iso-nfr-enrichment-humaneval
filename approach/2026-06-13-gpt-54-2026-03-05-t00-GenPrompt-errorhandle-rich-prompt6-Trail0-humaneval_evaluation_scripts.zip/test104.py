
import unittest
import re
import sys
import math
import copy


def unique_digits(x):
    """Given a list of positive integers x, return a sorted list of all
    elements that do not contain any even digit.

    Note: Returned list is sorted in increasing order.

    For example:
    >>> unique_digits([15, 33, 1422, 1])
    [1, 15, 33]
    >>> unique_digits([152, 323, 1422, 10])
    []

    Error handling:
    - Raises TypeError if x is not a list or if any element is not an integer.
    - Raises ValueError if any element is not a positive integer.
    """
    if not isinstance(x, list):
        raise TypeError("x must be a list of positive integers")

    result = []

    for item in x:
        if not isinstance(item, int):
            raise TypeError(f"All elements must be integers, got {type(item).__name__}")
        if item <= 0:
            raise ValueError(f"All elements must be positive integers, got {item}")

        try:
            if all(int(digit) % 2 != 0 for digit in str(item)):
                result.append(item)
        except ValueError as exc:
            # Defensive handling in case digit conversion fails unexpectedly
            raise ValueError(f"Invalid numeric content in element {item}") from exc

    return sorted(result)
candidate = unique_digits


def check(candidate):

    # Check some simple cases
    assert candidate([15, 33, 1422, 1]) == [1, 15, 33]
    assert candidate([152, 323, 1422, 10]) == []
    assert candidate([12345, 2033, 111, 151]) == [111, 151]
    assert candidate([135, 103, 31]) == [31, 135]

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
