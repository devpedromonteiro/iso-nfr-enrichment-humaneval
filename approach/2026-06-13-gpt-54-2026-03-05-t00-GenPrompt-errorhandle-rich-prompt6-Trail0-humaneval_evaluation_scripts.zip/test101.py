
import unittest
import re
import sys
import math
import copy


def words_string(s):
    """
    You will be given a string of words separated by commas or spaces. Your task is
    to split the string into words and return a list of the words.

    Examples:
        words_string("Hi, my name is John") -> ["Hi", "my", "name", "is", "John"]
        words_string("One, two, three, four, five, six") ->
            ["One", "two", "three", "four", "five", "six"]
    """
    if s is None:
        raise TypeError("Input cannot be None.")
    if not isinstance(s, str):
        raise TypeError(f"Input must be a string, got {type(s).__name__}.")
    if s == "":
        raise ValueError("Input string cannot be empty.")

    try:
        normalized = s.replace(",", " ")
        words = normalized.split()

        if not words:
            raise ValueError("Input must contain at least one word.")

        return words
    except AttributeError as exc:
        # Defensive handling in case string-like assumptions are violated
        raise TypeError("Failed to process input as a string.") from exc
candidate = words_string


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate("Hi, my name is John") == ["Hi", "my", "name", "is", "John"]
    assert candidate("One, two, three, four, five, six") == ["One", "two", "three", "four", "five", "six"]
    assert candidate("Hi, my name") == ["Hi", "my", "name"]
    assert candidate("One,, two, three, four, five, six,") == ["One", "two", "three", "four", "five", "six"]

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate("") == []
    assert candidate("ahmed     , gamal") == ["ahmed", "gamal"]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
