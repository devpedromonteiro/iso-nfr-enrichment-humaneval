
import unittest
import re
import sys
import math
import copy


def total_match(lst1, lst2):
    '''
    Accepts two lists of strings and returns the list whose total number of
    characters across all strings is smaller.

    If both totals are equal, returns the first list.

    Raises:
        TypeError: if either argument is not a list, or if any element is not a string.
        ValueError: if either argument is None.

    Examples:
        total_match([], []) -> []
        total_match(['hi', 'admin'], ['hI', 'Hi']) -> ['hI', 'Hi']
        total_match(['hi', 'admin'], ['hi', 'hi', 'admin', 'project']) -> ['hi', 'admin']
        total_match(['hi', 'admin'], ['hI', 'hi', 'hi']) -> ['hI', 'hi', 'hi']
        total_match(['4'], ['1', '2', '3', '4', '5']) -> ['4']
    '''
    if lst1 is None or lst2 is None:
        raise ValueError("Input lists must not be None.")

    if not isinstance(lst1, list):
        raise TypeError(f"lst1 must be a list, got {type(lst1).__name__}.")
    if not isinstance(lst2, list):
        raise TypeError(f"lst2 must be a list, got {type(lst2).__name__}.")

    for i, item in enumerate(lst1):
        if not isinstance(item, str):
            raise TypeError(f"All elements in lst1 must be strings; found {type(item).__name__} at index {i}.")

    for i, item in enumerate(lst2):
        if not isinstance(item, str):
            raise TypeError(f"All elements in lst2 must be strings; found {type(item).__name__} at index {i}.")

    total1 = sum(len(s) for s in lst1)
    total2 = sum(len(s) for s in lst2)

    return lst1 if total1 <= total2 else lst2
candidate = total_match


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([], []) == []
    assert candidate(['hi', 'admin'], ['hi', 'hi']) == ['hi', 'hi']
    assert candidate(['hi', 'admin'], ['hi', 'hi', 'admin', 'project']) == ['hi', 'admin']
    assert candidate(['4'], ['1', '2', '3', '4', '5']) == ['4']
    assert candidate(['hi', 'admin'], ['hI', 'Hi']) == ['hI', 'Hi']
    assert candidate(['hi', 'admin'], ['hI', 'hi', 'hi']) == ['hI', 'hi', 'hi']
    assert candidate(['hi', 'admin'], ['hI', 'hi', 'hii']) == ['hi', 'admin']


    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([], ['this']) == []
    assert candidate(['this'], []) == []



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
