
import unittest
import re
import sys
import math
import copy


def do_algebra(operator, operand):
    """
    Given two lists operator and operand, build the algebraic expression and
    return its evaluated result.

    Supported operators:
        +   addition
        -   subtraction
        *   multiplication
        //  floor division
        **  exponentiation

    Example:
        operator = ['+', '*', '-']
        operand = [2, 3, 4, 5]
        result = 2 + 3 * 4 - 5
        => 9
    """
    if not isinstance(operator, list):
        raise TypeError("operator must be a list")
    if not isinstance(operand, list):
        raise TypeError("operand must be a list")

    if len(operator) < 1:
        raise ValueError("operator list must contain at least one operator")
    if len(operand) < 2:
        raise ValueError("operand list must contain at least two operands")
    if len(operator) != len(operand) - 1:
        raise ValueError(
            "length of operator list must be equal to length of operand list minus one"
        )

    valid_operators = {"+", "-", "*", "//", "**"}
    for op in operator:
        if not isinstance(op, str):
            raise TypeError("each operator must be a string")
        if op not in valid_operators:
            raise ValueError(f"unsupported operator: {op}")

    for value in operand:
        if not isinstance(value, int):
            raise TypeError("each operand must be an integer")
        if value < 0:
            raise ValueError("operands must be non-negative integers")

    expression = [str(operand[0])]
    for i, op in enumerate(operator):
        next_operand = operand[i + 1]

        if op == "//" and next_operand == 0:
            raise ZeroDivisionError("floor division by zero is not allowed")

        expression.append(op)
        expression.append(str(next_operand))

    expr = " ".join(expression)

    try:
        return eval(expr, {"__builtins__": {}}, {})
    except ZeroDivisionError:
        raise
    except OverflowError:
        raise
    except SyntaxError as exc:
        raise ValueError(f"failed to build a valid algebraic expression: {expr}") from exc
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
