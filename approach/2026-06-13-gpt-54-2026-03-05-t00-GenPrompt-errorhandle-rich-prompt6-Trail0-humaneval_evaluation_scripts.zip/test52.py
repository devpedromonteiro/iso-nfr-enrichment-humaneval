
import unittest
import re
import sys
import math
import copy



def below_threshold(l: list, t: int):
    """Return True if all numbers in the list l are below threshold t.

    Validates inputs explicitly and raises specific exceptions for invalid
    arguments.

    >>> below_threshold([1, 2, 4, 10], 100)
    True
    >>> below_threshold([1, 20, 4, 10], 5)
    False
    """
    if not isinstance(l, list):
        raise TypeError(f"l must be a list, got {type(l).__name__}")
    if not isinstance(t, int):
        raise TypeError(f"t must be an int, got {type(t).__name__}")

    for i, value in enumerate(l):
        if not isinstance(value, (int, float)):
            raise TypeError(
                f"all elements of l must be numbers; "
                f"found {type(value).__name__} at index {i}"
            )
        if value >= t:
            return False

    return True
candidate = below_threshold




METADATA = {}


def check(candidate):
    assert candidate([1, 2, 4, 10], 100)
    assert not candidate([1, 20, 4, 10], 5)
    assert candidate([1, 20, 4, 10], 21)
    assert candidate([1, 20, 4, 10], 22)
    assert candidate([1, 8, 4, 10], 11)
    assert not candidate([1, 8, 4, 10], 10)



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
