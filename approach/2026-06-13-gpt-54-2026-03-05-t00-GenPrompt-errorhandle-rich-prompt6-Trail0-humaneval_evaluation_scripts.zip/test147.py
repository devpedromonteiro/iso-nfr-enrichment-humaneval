
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    You are given a positive integer n. You have to create an integer array a of length n.
        For each i (1 â¤ i â¤ n), the value of a[i] = i * i - i + 1.
        Return the number of triples (a[i], a[j], a[k]) of a where i < j < k,
    and a[i] + a[j] + a[k] is a multiple of 3.

    Example :
        Input: n = 5
        Output: 1
        Explanation:
        a = [1, 3, 7, 13, 21]
        The only valid triple is (1, 7, 13).
    """
    if isinstance(n, bool):
        raise TypeError("n must be an integer, not bool")
    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if n <= 0:
        raise ValueError("n must be a positive integer")

    try:
        # a[i] = i^2 - i + 1
        # Mod 3 pattern:
        # i % 3 == 0 -> a[i] % 3 == 1
        # i % 3 == 1 -> a[i] % 3 == 1
        # i % 3 == 2 -> a[i] % 3 == 0
        #
        # Valid triple sums divisible by 3 only when residues are:
        # (0,1,2) impossible here since residue 2 never occurs
        # (0,0,0) or (1,1,1)
        #
        # So answer = C(count0, 3) + C(count1, 3)

        count0 = n // 3                  # indices where i % 3 == 2
        count1 = n - count0              # remaining indices

        def comb3(x):
            if x < 3:
                return 0
            return x * (x - 1) * (x - 2) // 6

        return comb3(count0) + comb3(count1)

    except OverflowError:
        raise OverflowError("numeric overflow occurred while computing triples")
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
