
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[2] * x^2 + .... + xs[n] * x^n
    """
    if not isinstance(xs, list):
        raise TypeError("xs must be a list of numeric coefficients")
    if len(xs) == 0:
        raise ValueError("xs must not be empty")
    if not isinstance(x, (int, float)):
        raise TypeError("x must be a number")

    for i, coeff in enumerate(xs):
        if not isinstance(coeff, (int, float)):
            raise TypeError(f"coefficient at index {i} must be numeric")

    return sum(coeff * math.pow(x, i) for i, coeff in enumerate(xs))


def find_zero(xs: list):
    """ xs are coefficients of a polynomial.
    find_zero find x such that poly(x) = 0.
    find_zero returns only only zero point, even if there are many.
    Moreover, find_zero only takes list xs having even number of coefficients
    and largest non zero coefficient as it guarantees
    a solution.
    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3
    1.0
    """
    if not isinstance(xs, list):
        raise TypeError("xs must be a list of numeric coefficients")
    if len(xs) == 0:
        raise ValueError("xs must not be empty")

    for i, coeff in enumerate(xs):
        if not isinstance(coeff, (int, float)):
            raise TypeError(f"coefficient at index {i} must be numeric")

    if len(xs) % 2 != 0:
        raise ValueError("xs must contain an even number of coefficients")

    # Remove trailing zeros safely so the actual degree is well-defined.
    coeffs = xs[:]
    while coeffs and coeffs[-1] == 0:
        coeffs.pop()

    if not coeffs:
        raise ValueError("polynomial must not be identically zero")

    # Requirement: largest non-zero coefficient should guarantee a solution.
    # Interpreting this as: highest-degree non-zero term must have odd degree,
    # which is equivalent here to having an even number of coefficients.
    degree = len(coeffs) - 1
    if degree % 2 == 0:
        raise ValueError("polynomial degree must be odd to guarantee a real zero")

    # Fast path for linear polynomial.
    if degree == 1:
        a0, a1 = coeffs[0], coeffs[1]
        if a1 == 0:
            raise ZeroDivisionError("leading coefficient must be non-zero")
        return -a0 / a1

    def f(x):
        return poly(coeffs, x)

    # Find a bracket [left, right] with sign change.
    left, right = -1.0, 1.0
    try:
        f_left = f(left)
        f_right = f(right)
    except (OverflowError, ValueError) as e:
        raise ArithmeticError("failed to evaluate polynomial during bracketing") from e

    max_expand = 10_000
    expand_count = 0

    while f_left == 0 or f_right == 0 or f_left * f_right > 0:
        if f_left == 0:
            return left
        if f_right == 0:
            return right

        left *= 2.0
        right *= 2.0
        expand_count += 1

        if expand_count > max_expand:
            raise RuntimeError("failed to bracket a root within expansion limit")

        try:
            f_left = f(left)
            f_right = f(right)
        except (OverflowError, ValueError) as e:
            raise ArithmeticError("failed to evaluate polynomial during bracketing") from e

    # Bisection method: robust once a sign-changing bracket is found.
    tolerance = 1e-12
    max_iter = 10_000

    for _ in range(max_iter):
        mid = (left + right) / 2.0
        try:
            f_mid = f(mid)
        except (OverflowError, ValueError) as e:
            raise ArithmeticError("failed to evaluate polynomial during root finding") from e

        if abs(f_mid) < tolerance or abs(right - left) < tolerance:
            return mid

        if f_left * f_mid <= 0:
            right = mid
            f_right = f_mid
        else:
            left = mid
            f_left = f_mid

    raise RuntimeError("root finding did not converge within iteration limit")
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
