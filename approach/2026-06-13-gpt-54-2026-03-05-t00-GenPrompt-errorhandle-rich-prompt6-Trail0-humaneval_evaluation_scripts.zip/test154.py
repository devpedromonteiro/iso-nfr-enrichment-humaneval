
import unittest
import re
import sys
import math
import copy


def cycpattern_check(a, b):
    """Return True if b or any rotation of b is a substring of a.

    Examples:
        cycpattern_check("abcd", "abd") -> False
        cycpattern_check("hello", "ell") -> True
        cycpattern_check("whassup", "psus") -> False
        cycpattern_check("abab", "baa") -> True
        cycpattern_check("efef", "eeff") -> False
        cycpattern_check("himenss", "simen") -> True
    """
    if not isinstance(a, str):
        raise TypeError(f"'a' must be of type str, got {type(a).__name__}")
    if not isinstance(b, str):
        raise TypeError(f"'b' must be of type str, got {type(b).__name__}")

    if a == "" or b == "":
        raise ValueError("Inputs must be non-empty strings")

    # If b is longer than a, no rotation can be a substring of a.
    if len(b) > len(a):
        return False

    try:
        for i in range(len(b)):
            rotated = b[i:] + b[:i]
            if rotated in a:
                return True
        return False
    except TypeError:
        # Re-raise specific exceptions without swallowing them.
        raise
    except Exception as exc:
        # Wrap unexpected errors with context while preserving the cause.
        raise RuntimeError("Unexpected error while checking cyclic pattern") from exc
candidate = cycpattern_check


def check(candidate):

    # Check some simple cases
    #assert True, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    #assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert  candidate("xyzw","xyw") == False , "test #0"
    assert  candidate("yello","ell") == True , "test #1"
    assert  candidate("whattup","ptut") == False , "test #2"
    assert  candidate("efef","fee") == True , "test #3"
    assert  candidate("abab","aabb") == False , "test #4"
    assert  candidate("winemtt","tinem") == True , "test #5"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
