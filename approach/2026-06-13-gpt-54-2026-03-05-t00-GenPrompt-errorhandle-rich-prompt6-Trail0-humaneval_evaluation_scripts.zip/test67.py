
import unittest
import re
import sys
import math
import copy


import re


def fruit_distribution(s, n):
    """
    Given a string describing the number of apples and oranges in a basket,
    and an integer representing the total number of fruits, return the number
    of mangoes.

    Examples:
        fruit_distribution("5 apples and 6 oranges", 19) -> 8
        fruit_distribution("0 apples and 1 oranges", 3) -> 2
        fruit_distribution("2 apples and 3 oranges", 100) -> 95
        fruit_distribution("100 apples and 1 oranges", 120) -> 19

    Raises:
        TypeError: if input types are invalid.
        ValueError: if the string format is invalid, counts are negative,
                    or total fruits is less than apples + oranges.
    """
    if not isinstance(s, str):
        raise TypeError("s must be a string")
    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if n < 0:
        raise ValueError("n must be non-negative")

    pattern = r"^\s*(\d+)\s+apples\s+and\s+(\d+)\s+oranges\s*$"
    match = re.match(pattern, s)
    if match is None:
        raise ValueError(
            's must match the format: "<non-negative int> apples and <non-negative int> oranges"'
        )

    apples = int(match.group(1))
    oranges = int(match.group(2))

    total_known = apples + oranges
    if total_known > n:
        raise ValueError(
            "total fruits cannot be less than the sum of apples and oranges"
        )

    return n - total_known
candidate = fruit_distribution


def check(candidate):

    # Check some simple cases
    assert candidate("5 apples and 6 oranges",19) == 8
    assert candidate("5 apples and 6 oranges",21) == 10
    assert candidate("0 apples and 1 oranges",3) == 2
    assert candidate("1 apples and 0 oranges",3) == 2
    assert candidate("2 apples and 3 oranges",100) == 95
    assert candidate("2 apples and 3 oranges",5) == 0
    assert candidate("1 apples and 100 oranges",120) == 19


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
