
import unittest
import re
import sys
import math
import copy


def fix_spaces(text):
    """
    Given a string text, replace spaces as follows:
    - single spaces become "_"
    - runs of 3 or more consecutive spaces become "-"
    - runs of exactly 2 spaces remain "__" under the single-space rule

    Examples:
        fix_spaces("Example") == "Example"
        fix_spaces("Example 1") == "Example_1"
        fix_spaces(" Example 2") == "_Example_2"
        fix_spaces(" Example   3") == "_Example-3"
    """
    if text is None:
        raise TypeError("text must be a string, got None")
    if not isinstance(text, str):
        raise TypeError(f"text must be a string, got {type(text).__name__}")

    result = []
    i = 0
    n = len(text)

    while i < n:
        if text[i] != " ":
            result.append(text[i])
            i += 1
            continue

        start = i
        while i < n and text[i] == " ":
            i += 1
        space_count = i - start

        if space_count > 2:
            result.append("-")
        else:
            result.append("_" * space_count)

    return "".join(result)
candidate = fix_spaces


def check(candidate):

    # Check some simple cases
    assert candidate("Example") == "Example", "This prints if this assert fails 1 (good for debugging!)"
    assert candidate("Mudasir Hanif ") == "Mudasir_Hanif_", "This prints if this assert fails 2 (good for debugging!)"
    assert candidate("Yellow Yellow  Dirty  Fellow") == "Yellow_Yellow__Dirty__Fellow", "This prints if this assert fails 3 (good for debugging!)"
    
    # Check some edge cases that are easy to work out by hand.
    assert candidate("Exa   mple") == "Exa-mple", "This prints if this assert fails 4 (good for debugging!)"
    assert candidate("   Exa 1 2 2 mple") == "-Exa_1_2_2_mple", "This prints if this assert fails 4 (good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
