
import unittest
import re
import sys
import math
import copy


def tri(n):
    """Return a list containing the first n + 1 Tribonacci values.

    Sequence definition:
    - tri(0) = 1
    - tri(1) = 3
    - tri(n) = 1 + n / 2, if n is even and n >= 2
    - tri(n) = tri(n - 1) + tri(n - 2) + tri(n + 1), if n is odd and n >= 3

    Examples:
        tri(3) -> [1, 3, 2, 8]

    Raises:
        TypeError: if n is not an integer.
        ValueError: if n is negative.
    """
    if isinstance(n, bool):
        raise TypeError("n must be a non-negative integer, not bool")
    if not isinstance(n, int):
        raise TypeError("n must be a non-negative integer")
    if n < 0:
        raise ValueError("n must be non-negative")

    try:
        seq = [0] * (n + 1)

        seq[0] = 1
        if n >= 1:
            seq[1] = 3

        for i in range(2, n + 1):
            if i % 2 == 0:
                seq[i] = 1 + i // 2
            else:
                # tri(i) = tri(i - 1) + tri(i - 2) + tri(i + 1)
                # and for odd i, tri(i + 1) is even:
                # tri(i + 1) = 1 + (i + 1) / 2
                seq[i] = seq[i - 1] + seq[i - 2] + 1 + ((i + 1) // 2)

        return seq

    except MemoryError:
        raise
    except OverflowError:
        raise
    except Exception as exc:
        raise RuntimeError("failed to compute Tribonacci sequence") from exc
candidate = tri


def check(candidate):

    # Check some simple cases
    
    assert candidate(3) == [1, 3, 2.0, 8.0]
    assert candidate(4) == [1, 3, 2.0, 8.0, 3.0]
    assert candidate(5) == [1, 3, 2.0, 8.0, 3.0, 15.0]
    assert candidate(6) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0]
    assert candidate(7) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0]
    assert candidate(8) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0]
    assert candidate(9) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0]
    assert candidate(20) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0, 6.0, 48.0, 7.0, 63.0, 8.0, 80.0, 9.0, 99.0, 10.0, 120.0, 11.0]

    # Check some edge cases that are easy to work out by hand.
    assert candidate(0) == [1]
    assert candidate(1) == [1, 3]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
