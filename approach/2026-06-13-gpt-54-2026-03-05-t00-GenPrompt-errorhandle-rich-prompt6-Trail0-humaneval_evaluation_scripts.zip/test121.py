
import unittest
import re
import sys
import math
import copy


def solution(lst):
    """Given a non-empty list of integers, return the sum of all odd elements
    that are in even positions (0-based indexing).

    Examples
    solution([5, 8, 7, 1]) ==> 12
    solution([3, 3, 3, 3, 3]) ==> 9
    solution([30, 13, 24, 321]) ==> 0
    """
    if lst is None:
        raise TypeError("lst must be a non-empty list of integers, got None")

    if not isinstance(lst, list):
        raise TypeError(f"lst must be of type list, got {type(lst).__name__}")

    if len(lst) == 0:
        raise ValueError("lst must be a non-empty list")

    for i, value in enumerate(lst):
        if not isinstance(value, int):
            raise TypeError(
                f"all elements must be integers; element at index {i} is {type(value).__name__}"
            )

    try:
        return sum(value for index, value in enumerate(lst) if index % 2 == 0 and value % 2 == 1)
    except TypeError as exc:
        raise TypeError("failed to process list elements as integers") from exc
candidate = solution


def check(candidate):

    # Check some simple cases
    assert candidate([5, 8, 7, 1])    == 12
    assert candidate([3, 3, 3, 3, 3]) == 9
    assert candidate([30, 13, 24, 321]) == 0
    assert candidate([5, 9]) == 5
    assert candidate([2, 4, 8]) == 0
    assert candidate([30, 13, 23, 32]) == 23
    assert candidate([3, 13, 2, 9]) == 3

    # Check some edge cases that are easy to work out by hand.



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
