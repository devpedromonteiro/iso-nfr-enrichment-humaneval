
import unittest
import re
import sys
import math
import copy



def encode_shift(s: str):
    """
    returns encoded string by shifting every character by 5 in the alphabet.
    """
    return "".join([chr(((ord(ch) + 5 - ord("a")) % 26) + ord("a")) for ch in s])


SHIFT = 5
ALPHABET_START = ord("a")
ALPHABET_SIZE = 26


def _shift_char(ch: str, shift: int) -> str:
    """
    Shift a single lowercase alphabetic character by the given amount.
    """
    return chr(((ord(ch) - ALPHABET_START + shift) % ALPHABET_SIZE) + ALPHABET_START)


def _transform_text(text: str, shift: int) -> str:
    """
    Apply a character shift to every character in the input text.
    """
    return "".join(_shift_char(ch, shift) for ch in text)


def encode_shift(s: str) -> str:
    """
    Return an encoded string by shifting every character by 5 in the alphabet.
    """
    return _transform_text(s, SHIFT)


def decode_shift(s: str) -> str:
    """
    Take as input a string encoded with encode_shift and return the decoded string.
    """
    return _transform_text(s, -SHIFT)
candidate = decode_shift




METADATA = {}


def check(candidate):
    from random import randint, choice
    import copy
    import string

    letters = string.ascii_lowercase
    for _ in range(100):
        str = ''.join(choice(letters) for i in range(randint(10, 20)))
        encoded_str = encode_shift(str)
        assert candidate(copy.deepcopy(encoded_str)) == str



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
