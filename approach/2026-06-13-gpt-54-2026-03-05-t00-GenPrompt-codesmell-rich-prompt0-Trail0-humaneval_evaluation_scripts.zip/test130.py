
import unittest
import re
import sys
import math
import copy


def tri(n):
    """Return the first n + 1 values of the Tribonacci sequence.

    Sequence definition:
    - tri(0) = 1
    - tri(1) = 3
    - tri(k) = 1 + k / 2, if k is even and k >= 2
    - tri(k) = tri(k - 1) + tri(k - 2) + tri(k + 1), if k is odd and k >= 3

    Examples:
    >>> tri(3)
    [1, 3, 2, 8]
    """
    def even_value(index):
        return 1 + index // 2

    def build_sequence(limit):
        if limit == 0:
            return [1]
        if limit == 1:
            return [1, 3]

        sequence = [0] * (limit + 1)
        sequence[0] = 1
        sequence[1] = 3

        for index in range(2, limit + 1):
            if index % 2 == 0:
                sequence[index] = even_value(index)
            else:
                next_even = even_value(index + 1)
                sequence[index] = sequence[index - 1] + sequence[index - 2] + next_even

        return sequence

    return build_sequence(n)
candidate = tri


def check(candidate):

    # Check some simple cases
    
    assert candidate(3) == [1, 3, 2.0, 8.0]
    assert candidate(4) == [1, 3, 2.0, 8.0, 3.0]
    assert candidate(5) == [1, 3, 2.0, 8.0, 3.0, 15.0]
    assert candidate(6) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0]
    assert candidate(7) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0]
    assert candidate(8) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0]
    assert candidate(9) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0]
    assert candidate(20) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0, 6.0, 48.0, 7.0, 63.0, 8.0, 80.0, 9.0, 99.0, 10.0, 120.0, 11.0]

    # Check some edge cases that are easy to work out by hand.
    assert candidate(0) == [1]
    assert candidate(1) == [1, 3]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
