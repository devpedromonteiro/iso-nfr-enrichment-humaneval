
import unittest
import re
import sys
import math
import copy


def _split_date_parts(date_string):
    """Split a date string into month, day, and year parts."""
    if not date_string or not isinstance(date_string, str):
        return None

    parts = date_string.split("-")
    if len(parts) != 3:
        return None

    month, day, year = parts
    return month, day, year


def _has_valid_format(month, day, year):
    """Check whether date parts match the required mm-dd-yyyy format."""
    return (
        len(month) == 2
        and len(day) == 2
        and len(year) == 4
        and month.isdigit()
        and day.isdigit()
        and year.isdigit()
    )


def _days_in_month(month):
    """Return the maximum valid day for a given month."""
    if month == 2:
        return 29
    if month in {4, 6, 9, 11}:
        return 30
    return 31


def _is_valid_month(month):
    """Check whether the month is within the valid range."""
    return 1 <= month <= 12


def _is_valid_day(month, day):
    """Check whether the day is valid for the given month."""
    return 1 <= day <= _days_in_month(month)


def valid_date(date):
    """Validate a date string in mm-dd-yyyy format."""
    parts = _split_date_parts(date)
    if parts is None:
        return False

    month_str, day_str, year_str = parts
    if not _has_valid_format(month_str, day_str, year_str):
        return False

    month = int(month_str)
    day = int(day_str)

    if not _is_valid_month(month):
        return False

    return _is_valid_day(month, day)
candidate = valid_date


def check(candidate):

    # Check some simple cases
    assert candidate('03-11-2000') == True

    assert candidate('15-01-2012') == False

    assert candidate('04-0-2040') == False

    assert candidate('06-04-2020') == True

    assert candidate('01-01-2007') == True

    assert candidate('03-32-2011') == False

    assert candidate('') == False

    assert candidate('04-31-3000') == False

    assert candidate('06-06-2005') == True

    assert candidate('21-31-2000') == False

    assert candidate('04-12-2003') == True

    assert candidate('04122003') == False

    assert candidate('20030412') == False

    assert candidate('2003-04') == False

    assert candidate('2003-04-12') == False

    assert candidate('04-2003') == False


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
