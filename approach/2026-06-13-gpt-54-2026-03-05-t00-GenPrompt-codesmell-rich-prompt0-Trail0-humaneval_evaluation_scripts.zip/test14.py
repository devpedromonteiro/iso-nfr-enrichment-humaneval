
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def _prefix_at(string: str, end_index: int) -> str:
    """Return the prefix of ``string`` ending at ``end_index``."""
    return string[:end_index]


def all_prefixes(string: str) -> List[str]:
    """Return list of all prefixes from shortest to longest of the input string.

    >>> all_prefixes('abc')
    ['a', 'ab', 'abc']
    """
    return [_prefix_at(string, end_index) for end_index in range(1, len(string) + 1)]
candidate = all_prefixes




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == []
    assert candidate('asdfgh') == ['a', 'as', 'asd', 'asdf', 'asdfg', 'asdfgh']
    assert candidate('WWW') == ['W', 'WW', 'WWW']


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
