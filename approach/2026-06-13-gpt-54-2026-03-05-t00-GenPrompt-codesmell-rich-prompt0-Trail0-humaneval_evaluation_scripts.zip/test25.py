
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def _validate_input(n: int) -> None:
    """Validate that the input can be factorized."""
    if n < 2:
        raise ValueError("n must be greater than or equal to 2")


def _extract_factor(n: int, factor: int, factors: List[int]) -> int:
    """Extract all occurrences of a factor from n and append them to factors."""
    while n % factor == 0:
        factors.append(factor)
        n //= factor
    return n


def factorize(n: int) -> List[int]:
    """Return prime factors of n in ascending order.

    Each prime factor appears as many times as its multiplicity in the factorization.

    >>> factorize(8)
    [2, 2, 2]
    >>> factorize(25)
    [5, 5]
    >>> factorize(70)
    [2, 5, 7]
    """
    _validate_input(n)

    factors: List[int] = []
    n = _extract_factor(n, 2, factors)

    divisor = 3
    while divisor * divisor <= n:
        n = _extract_factor(n, divisor, factors)
        divisor += 2

    if n > 1:
        factors.append(n)

    return factors
candidate = factorize




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(2) == [2]
    assert candidate(4) == [2, 2]
    assert candidate(8) == [2, 2, 2]
    assert candidate(3 * 19) == [3, 19]
    assert candidate(3 * 19 * 3 * 19) == [3, 3, 19, 19]
    assert candidate(3 * 19 * 3 * 19 * 3 * 19) == [3, 3, 3, 19, 19, 19]
    assert candidate(3 * 19 * 19 * 19) == [3, 19, 19, 19]
    assert candidate(3 * 2 * 3) == [2, 3, 3]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
