
import unittest
import re
import sys
import math
import copy


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and
    the second list is a list of integers. Use the two given lists to build the algebraic
    expression and return the evaluation of this expression.

    Supported operations:
    Addition ( + )
    Subtraction ( - )
    Multiplication ( * )
    Floor division ( // )
    Exponentiation ( ** )
    """
    _validate_inputs(operator, operand)
    tokens = _build_tokens(operator, operand)
    return _evaluate_expression(tokens)


def _validate_inputs(operator, operand):
    if len(operator) != len(operand) - 1:
        raise ValueError("operator length must be operand length minus one")
    if len(operator) < 1 or len(operand) < 2:
        raise ValueError("operator must have at least one item and operand at least two")
    if any(not isinstance(value, int) or value < 0 for value in operand):
        raise ValueError("operand must contain only non-negative integers")

    valid_operators = {"+", "-", "*", "//", "**"}
    invalid = [op for op in operator if op not in valid_operators]
    if invalid:
        raise ValueError(f"unsupported operators: {invalid}")


def _build_tokens(operator, operand):
    tokens = [operand[0]]
    for op, value in zip(operator, operand[1:]):
        tokens.extend([op, value])
    return tokens


def _evaluate_expression(tokens):
    precedence_groups = [
        {"**"},
        {"*", "//"},
        {"+", "-"},
    ]

    working_tokens = tokens[:]
    for operators in precedence_groups:
        working_tokens = _reduce_by_precedence(working_tokens, operators)

    return working_tokens[0]


def _reduce_by_precedence(tokens, target_operators):
    reduced = [tokens[0]]
    index = 1

    while index < len(tokens):
        operator = tokens[index]
        right_operand = tokens[index + 1]

        if operator in target_operators:
            left_operand = reduced.pop()
            reduced.append(_apply_operator(operator, left_operand, right_operand))
        else:
            reduced.extend([operator, right_operand])

        index += 2

    return reduced


def _apply_operator(operator, left, right):
    operations = {
        "+": lambda a, b: a + b,
        "-": lambda a, b: a - b,
        "*": lambda a, b: a * b,
        "//": lambda a, b: a // b,
        "**": lambda a, b: a ** b,
    }
    return operations[operator](left, right)
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
