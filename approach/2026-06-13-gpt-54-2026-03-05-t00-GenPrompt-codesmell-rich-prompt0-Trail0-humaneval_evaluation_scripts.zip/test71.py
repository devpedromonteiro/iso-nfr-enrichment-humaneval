
import unittest
import re
import sys
import math
import copy


from math import sqrt


def triangle_area(a, b, c):
    """
    Given the lengths of the three sides of a triangle, return the area of
    the triangle rounded to 2 decimal points if the three sides form a valid
    triangle. Otherwise return -1.

    Three sides make a valid triangle when the sum of any two sides is greater
    than the third side.

    Example:
    triangle_area(3, 4, 5) == 6.00
    triangle_area(1, 2, 10) == -1
    """
    if not _is_valid_triangle(a, b, c):
        return -1

    return _rounded_heron_area(a, b, c)


def _is_valid_triangle(a, b, c):
    """Return True if the provided sides can form a valid triangle."""
    sides = (a, b, c)
    return _all_sides_positive(sides) and _satisfies_triangle_inequality(sides)


def _all_sides_positive(sides):
    """Return True if all triangle sides are greater than zero."""
    return all(side > 0 for side in sides)


def _satisfies_triangle_inequality(sides):
    """Return True if the sides satisfy the triangle inequality."""
    x, y, z = sorted(sides)
    return x + y > z


def _rounded_heron_area(a, b, c):
    """Compute triangle area using Heron's formula and round to 2 decimals."""
    semi_perimeter = _semi_perimeter(a, b, c)
    area = sqrt(
        semi_perimeter
        * (semi_perimeter - a)
        * (semi_perimeter - b)
        * (semi_perimeter - c)
    )
    return round(area, 2)


def _semi_perimeter(a, b, c):
    """Return the semi-perimeter of a triangle."""
    return (a + b + c) / 2
candidate = triangle_area


def check(candidate):

    # Check some simple cases
    assert candidate(3, 4, 5) == 6.00, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(1, 2, 10) == -1
    assert candidate(4, 8, 5) == 8.18
    assert candidate(2, 2, 2) == 1.73
    assert candidate(1, 2, 3) == -1
    assert candidate(10, 5, 7) == 16.25
    assert candidate(2, 6, 3) == -1

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1, 1, 1) == 0.43, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate(2, 2, 10) == -1



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
