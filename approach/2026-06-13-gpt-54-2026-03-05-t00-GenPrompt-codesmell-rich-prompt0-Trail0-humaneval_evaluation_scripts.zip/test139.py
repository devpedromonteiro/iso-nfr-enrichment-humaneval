
import unittest
import re
import sys
import math
import copy


def _validate_positive_integer(value):
    """Validate that the input is a positive integer."""
    if not isinstance(value, int) or isinstance(value, bool):
        raise TypeError("n must be a positive integer")
    if value <= 0:
        raise ValueError("n must be greater than 0")


def _factorial_sequence_product(n):
    """Return the product n! * (n-1)! * ... * 1!."""
    running_factorial = 1
    total = 1

    for current in range(1, n + 1):
        running_factorial *= current
        total *= running_factorial

    return total


def special_factorial(n):
    """The Brazilian factorial is defined as:
    brazilian_factorial(n) = n! * (n-1)! * (n-2)! * ... * 1!
    where n > 0

    For example:
    >>> special_factorial(4)
    288

    The function will receive an integer as input and should return the special
    factorial of this integer.
    """
    _validate_positive_integer(n)
    return _factorial_sequence_product(n)
candidate = special_factorial


def check(candidate):

    # Check some simple cases
    assert candidate(4) == 288, "Test 4"
    assert candidate(5) == 34560, "Test 5"
    assert candidate(7) == 125411328000, "Test 7"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1) == 1, "Test 1"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
