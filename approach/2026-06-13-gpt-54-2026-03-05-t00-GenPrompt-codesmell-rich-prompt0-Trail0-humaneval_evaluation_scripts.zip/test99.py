
import unittest
import re
import sys
import math
import copy


from decimal import Decimal, ROUND_HALF_UP, ROUND_HALF_DOWN


def _to_decimal(value):
    """Convert the incoming string value to Decimal."""
    return Decimal(value.strip())


def _round_half_away_from_zero(number):
    """Round a Decimal to the nearest integer, breaking ties away from zero."""
    rounding_mode = ROUND_HALF_UP if number >= 0 else ROUND_HALF_DOWN
    return int(number.quantize(Decimal("1"), rounding=rounding_mode))


def closest_integer(value):
    '''
    Create a function that takes a value (string) representing a number
    and returns the closest integer to it. If the number is equidistant
    from two integers, round it away from zero.

    Examples
    >>> closest_integer("10")
    10
    >>> closest_integer("15.3")
    15

    Note:
    Rounding away from zero means that if the given number is equidistant
    from two integers, the one you should return is the one that is the
    farthest from zero. For example closest_integer("14.5") should
    return 15 and closest_integer("-14.5") should return -15.
    '''
    number = _to_decimal(value)
    return _round_half_away_from_zero(number)
candidate = closest_integer


def check(candidate):

    # Check some simple cases
    assert candidate("10") == 10, "Test 1"
    assert candidate("14.5") == 15, "Test 2"
    assert candidate("-15.5") == -16, "Test 3"
    assert candidate("15.3") == 15, "Test 3"

    # Check some edge cases that are easy to work out by hand.
    assert candidate("0") == 0, "Test 0"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
