
import unittest
import re
import sys
import math
import copy


def circular_shift(x, shift):
    """Circular shift the digits of the integer x, shift the digits right by shift
    and return the result as a string.
    If shift > number of digits, return digits reversed.

    >>> circular_shift(12, 1)
    "21"
    >>> circular_shift(12, 2)
    "12"
    """
    digits = _to_digit_string(x)
    length = len(digits)

    if shift > length:
        return _reverse_string(digits)

    normalized_shift = _normalize_shift(shift, length)
    return _shift_right(digits, normalized_shift)


def _to_digit_string(value):
    return str(value)


def _reverse_string(text):
    return text[::-1]


def _normalize_shift(shift, length):
    return shift % length if length else 0


def _shift_right(text, shift):
    if shift == 0:
        return text
    return text[-shift:] + text[:-shift]
candidate = circular_shift


def check(candidate):

    # Check some simple cases
    assert candidate(100, 2) == "001"
    assert candidate(12, 2) == "12"
    assert candidate(97, 8) == "79"
    assert candidate(12, 1) == "21", "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(11, 101) == "11", "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
