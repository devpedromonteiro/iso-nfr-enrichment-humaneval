
import unittest
import re
import sys
import math
import copy



from collections import deque


def _validate_index(n: int) -> None:
    """Validate the requested sequence index."""
    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if n < 0:
        raise ValueError("n must be non-negative")


def _base_fib4_value(n: int) -> int | None:
    """Return the Fib4 base-case value, or None if n is not a base case."""
    base_cases = (0, 0, 2, 0)
    return base_cases[n] if n < len(base_cases) else None


def fib4(n: int):
    """The Fib4 number sequence is a sequence similar to the Fibbonacci sequnece that's defined as follows:
    fib4(0) -> 0
    fib4(1) -> 0
    fib4(2) -> 2
    fib4(3) -> 0
    fib4(n) -> fib4(n-1) + fib4(n-2) + fib4(n-3) + fib4(n-4).
    Please write a function to efficiently compute the n-th element of the fib4 number sequence.  Do not use recursion.
    >>> fib4(5)
    4
    >>> fib4(6)
    8
    >>> fib4(7)
    14
    """
    _validate_index(n)

    base_value = _base_fib4_value(n)
    if base_value is not None:
        return base_value

    window = deque((0, 0, 2, 0), maxlen=4)
    current = 0

    for _ in range(4, n + 1):
        current = sum(window)
        window.append(current)

    return current
candidate = fib4




METADATA = {}


def check(candidate):
    assert candidate(5) == 4
    assert candidate(8) == 28
    assert candidate(10) == 104
    assert candidate(12) == 386



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
