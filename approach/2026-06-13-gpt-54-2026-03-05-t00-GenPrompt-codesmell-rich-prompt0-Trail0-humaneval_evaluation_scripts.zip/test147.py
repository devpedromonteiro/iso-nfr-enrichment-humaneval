
import unittest
import re
import sys
import math
import copy


from collections import Counter
from math import comb


def get_max_triples(n):
    """
    You are given a positive integer n. You have to create an integer array a of length n.
    For each i (1 â¤ i â¤ n), the value of a[i] = i * i - i + 1.

    Return the number of triples (a[i], a[j], a[k]) where i < j < k and
    a[i] + a[j] + a[k] is a multiple of 3.

    Example:
        Input: n = 5
        Output: 1
        Explanation:
        a = [1, 3, 7, 13, 21]
        The only valid triple is (1, 7, 13).
    """
    residue_counts = _count_residues_modulo_three(n)
    return _count_valid_triples(residue_counts)


def _count_residues_modulo_three(n):
    """Count how many values of a[i] fall into each residue class modulo 3."""
    counts = Counter()

    for i in range(1, n + 1):
        value_mod_3 = (i * i - i + 1) % 3
        counts[value_mod_3] += 1

    return counts


def _count_valid_triples(residue_counts):
    """
    Count triples whose sum is divisible by 3 using residue frequencies.

    Valid residue combinations are:
    - (0, 0, 0)
    - (1, 1, 1)
    - (2, 2, 2)
    - (0, 1, 2)
    """
    count_0 = residue_counts[0]
    count_1 = residue_counts[1]
    count_2 = residue_counts[2]

    same_residue_triples = (
        _choose_three(count_0) +
        _choose_three(count_1) +
        _choose_three(count_2)
    )
    mixed_residue_triples = count_0 * count_1 * count_2

    return same_residue_triples + mixed_residue_triples


def _choose_three(count):
    """Safely compute nC3."""
    return comb(count, 3) if count >= 3 else 0
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
