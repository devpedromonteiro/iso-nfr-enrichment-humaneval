
import unittest
import re
import sys
import math
import copy


def _count_odds(values):
    """Return the number of odd elements in the iterable."""
    return sum(1 for value in values if value % 2 != 0)


def _count_evens(values):
    """Return the number of even elements in the iterable."""
    return sum(1 for value in values if value % 2 == 0)


def _can_replace_all_odds(lst1, lst2):
    """Check whether lst2 has enough even numbers to replace all odd numbers in lst1."""
    odd_count_in_lst1 = _count_odds(lst1)
    even_count_in_lst2 = _count_evens(lst2)
    return even_count_in_lst2 >= odd_count_in_lst1


def exchange(lst1, lst2):
    """Determine whether exchanges can make all elements of lst1 even.

    An odd element in lst1 must be exchanged with an even element from lst2.
    Since there is no limit on the number of exchanges, this is possible exactly
    when lst2 contains at least as many even numbers as lst1 contains odd numbers.
    """
    return "YES" if _can_replace_all_odds(lst1, lst2) else "NO"
candidate = exchange


def check(candidate):

    # Check some simple cases
    assert candidate([1, 2, 3, 4], [1, 2, 3, 4]) == "YES"
    assert candidate([1, 2, 3, 4], [1, 5, 3, 4]) == "NO"
    assert candidate([1, 2, 3, 4], [2, 1, 4, 3]) == "YES" 
    assert candidate([5, 7, 3], [2, 6, 4]) == "YES"
    assert candidate([5, 7, 3], [2, 6, 3]) == "NO" 
    assert candidate([3, 2, 6, 1, 8, 9], [3, 5, 5, 1, 1, 1]) == "NO"

    # Check some edge cases that are easy to work out by hand.
    assert candidate([100, 200], [200, 200]) == "YES"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
