
import unittest
import re
import sys
import math
import copy



def normalize_text(text: str) -> str:
    """Return a normalized representation for case-insensitive comparison."""
    return text.lower()


def extract_distinct_characters(text: str) -> set[str]:
    """Return the distinct characters from the given text."""
    return set(text)


def count_distinct_characters(string: str) -> int:
    """Given a string, find how many distinct characters it contains, regardless of case.

    >>> count_distinct_characters('xyzXYZ')
    3
    >>> count_distinct_characters('Jerry')
    4
    """
    normalized = normalize_text(string)
    distinct_characters = extract_distinct_characters(normalized)
    return len(distinct_characters)
candidate = count_distinct_characters




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == 0
    assert candidate('abcde') == 5
    assert candidate('abcde' + 'cade' + 'CADE') == 5
    assert candidate('aaaaAAAAaaaa') == 1
    assert candidate('Jerry jERRY JeRRRY') == 5


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
