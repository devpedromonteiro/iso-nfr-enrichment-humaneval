
import unittest
import re
import sys
import math
import copy


def anti_shuffle(s):
    """
    Return a version of the input string where each word's characters are sorted
    in ascending ASCII order, while preserving the original positions of spaces.

    Examples:
        anti_shuffle('Hi') -> 'Hi'
        anti_shuffle('hello') -> 'ehllo'
        anti_shuffle('Hello World!!!') -> 'Hello !!!Wdlor'
    """
    return "".join(_sorted_token(token) for token in _split_preserving_spaces(s))


def _split_preserving_spaces(text):
    """Split text into alternating word/space tokens while preserving spaces."""
    tokens = []
    current = []

    for char in text:
        if char == " ":
            if current:
                tokens.append("".join(current))
                current = []
            tokens.append(char)
        else:
            current.append(char)

    if current:
        tokens.append("".join(current))

    return tokens


def _sorted_token(token):
    """Sort non-space tokens; return spaces unchanged."""
    return token if token == " " else "".join(sorted(token))
candidate = anti_shuffle


def check(candidate):

    # Check some simple cases
    assert candidate('Hi') == 'Hi'
    assert candidate('hello') == 'ehllo'
    assert candidate('number') == 'bemnru'
    assert candidate('abcd') == 'abcd'
    assert candidate('Hello World!!!') == 'Hello !!!Wdlor'
    assert candidate('') == ''
    assert candidate('Hi. My name is Mister Robot. How are you?') == '.Hi My aemn is Meirst .Rboot How aer ?ouy'
    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
