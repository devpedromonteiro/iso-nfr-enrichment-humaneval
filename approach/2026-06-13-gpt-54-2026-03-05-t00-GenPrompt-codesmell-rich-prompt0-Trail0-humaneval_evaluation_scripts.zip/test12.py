
import unittest
import re
import sys
import math
import copy

from typing import List, Optional


from typing import List, Optional


def _is_better_candidate(candidate: str, current_best: Optional[str]) -> bool:
    """Return True if candidate should replace current_best."""
    return current_best is None or len(candidate) > len(current_best)


def longest(strings: List[str]) -> Optional[str]:
    """Out of list of strings, return the longest one.

    Return the first one in case of multiple strings of the same length.
    Return None in case the input list is empty.

    >>> longest([])

    >>> longest(['a', 'b', 'c'])
    'a'
    >>> longest(['a', 'bb', 'ccc'])
    'ccc'
    """
    best: Optional[str] = None

    for value in strings:
        if _is_better_candidate(value, best):
            best = value

    return best
candidate = longest




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == None
    assert candidate(['x', 'y', 'z']) == 'x'
    assert candidate(['x', 'yyy', 'zzzz', 'www', 'kkkk', 'abc']) == 'zzzz'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
