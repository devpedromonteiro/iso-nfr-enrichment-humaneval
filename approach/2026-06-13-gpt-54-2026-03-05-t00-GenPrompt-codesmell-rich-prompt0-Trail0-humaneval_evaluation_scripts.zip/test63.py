
import unittest
import re
import sys
import math
import copy



def _validate_index(n: int) -> None:
    """Validate the sequence index."""
    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if n < 0:
        raise ValueError("n must be non-negative")


def _is_base_case(n: int) -> bool:
    """Return whether n is a base-case index."""
    return n in (0, 1, 2)


def _base_case_value(n: int) -> int:
    """Return the FibFib base-case value for n."""
    base_values = (0, 0, 1)
    return base_values[n]


def _compute_fibfib_iterative(n: int) -> int:
    """Compute the n-th FibFib number iteratively."""
    a, b, c = 0, 0, 1
    for _ in range(3, n + 1):
        a, b, c = b, c, a + b + c
    return c


def fibfib(n: int):
    """The FibFib number sequence is a sequence similar to the Fibbonacci sequnece that's defined as follows:
    fibfib(0) == 0
    fibfib(1) == 0
    fibfib(2) == 1
    fibfib(n) == fibfib(n-1) + fibfib(n-2) + fibfib(n-3).
    Please write a function to efficiently compute the n-th element of the fibfib number sequence.
    >>> fibfib(1)
    0
    >>> fibfib(5)
    4
    >>> fibfib(8)
    24
    """
    _validate_index(n)

    if _is_base_case(n):
        return _base_case_value(n)

    return _compute_fibfib_iterative(n)
candidate = fibfib




METADATA = {}


def check(candidate):
    assert candidate(2) == 1
    assert candidate(1) == 0
    assert candidate(5) == 4
    assert candidate(8) == 24
    assert candidate(10) == 81
    assert candidate(12) == 274
    assert candidate(14) == 927



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
