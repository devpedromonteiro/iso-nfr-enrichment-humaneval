
import unittest
import re
import sys
import math
import copy



def triples_sum_to_zero(l: list):
    """
    triples_sum_to_zero takes a list of integers as an input.
    it returns True if there are three distinct elements in the list that
    sum to zero, and False otherwise.

    >>> triples_sum_to_zero([1, 3, 5, 0])
    False
    >>> triples_sum_to_zero([1, 3, -2, 1])
    True
    >>> triples_sum_to_zero([1, 2, 3, 7])
    False
    >>> triples_sum_to_zero([2, 4, -5, 3, 9, 7])
    True
    >>> triples_sum_to_zero([1])
    False
    """
    if len(l) < 3:
        return False

    sorted_values = sorted(l)
    return _has_zero_sum_triplet(sorted_values)


def _has_zero_sum_triplet(sorted_values: list) -> bool:
    """Return True if any three distinct elements sum to zero."""
    for index, value in enumerate(sorted_values[:-2]):
        if _has_pair_with_target_sum(sorted_values, index + 1, -value):
            return True
    return False


def _has_pair_with_target_sum(values: list, start_index: int, target: int) -> bool:
    """Check whether a pair in values[start_index:] sums to target."""
    left = start_index
    right = len(values) - 1

    while left < right:
        current_sum = values[left] + values[right]
        if current_sum == target:
            return True
        if current_sum < target:
            left += 1
        else:
            right -= 1

    return False
candidate = triples_sum_to_zero




METADATA = {}


def check(candidate):
    assert candidate([1, 3, 5, 0]) == False
    assert candidate([1, 3, 5, -1]) == False
    assert candidate([1, 3, -2, 1]) == True
    assert candidate([1, 2, 3, 7]) == False
    assert candidate([1, 2, 5, 7]) == False
    assert candidate([2, 4, -5, 3, 9, 7]) == True
    assert candidate([1]) == False
    assert candidate([1, 3, 5, -100]) == False
    assert candidate([100, 3, 5, -100]) == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
