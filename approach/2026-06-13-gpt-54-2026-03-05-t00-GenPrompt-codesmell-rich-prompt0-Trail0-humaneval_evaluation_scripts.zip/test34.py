
import unittest
import re
import sys
import math
import copy



def _deduplicate(items: list) -> set:
    """Return the unique elements from a list."""
    return set(items)


def _sort_items(items: set) -> list:
    """Return a sorted list from a collection of unique items."""
    return sorted(items)


def unique(l: list) -> list:
    """Return sorted unique elements in a list.

    >>> unique([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [0, 2, 3, 5, 9, 123]
    """
    unique_items = _deduplicate(l)
    return _sort_items(unique_items)
candidate = unique




METADATA = {}


def check(candidate):
    assert candidate([5, 3, 5, 2, 3, 3, 9, 0, 123]) == [0, 2, 3, 5, 9, 123]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
