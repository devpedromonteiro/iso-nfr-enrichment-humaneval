
import unittest
import re
import sys
import math
import copy


def is_nested(string):
    """
    Return True if the input contains a valid bracket subsequence
    with at least one nested pair of square brackets.

    A nested structure exists when, while scanning left to right,
    an opening bracket is encountered before a previous opening
    bracket has been closed.

    Examples:
        is_nested('[[]]') -> True
        is_nested('[]]]]]]][[[[[]') -> False
        is_nested('[][]') -> False
        is_nested('[]') -> False
        is_nested('[[][]]') -> True
        is_nested('[[]][[') -> True
    """
    return _has_nested_brackets(string)


def _has_nested_brackets(brackets):
    depth = 0

    for char in brackets:
        if char == '[':
            depth += 1
            if depth >= 2:
                return True
        elif char == ']' and depth > 0:
            depth -= 1

    return False
candidate = is_nested


def check(candidate):

    # Check some simple cases
    assert candidate('[[]]') == True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('[]]]]]]][[[[[]') == False
    assert candidate('[][]') == False
    assert candidate(('[]')) == False
    assert candidate('[[[[]]]]') == True
    assert candidate('[]]]]]]]]]]') == False
    assert candidate('[][][[]]') == True
    assert candidate('[[]') == False
    assert candidate('[]]') == False
    assert candidate('[[]][[') == True
    assert candidate('[[][]]') == True

    # Check some edge cases that are easy to work out by hand.
    assert candidate('') == False, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate('[[[[[[[[') == False
    assert candidate(']]]]]]]]') == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
