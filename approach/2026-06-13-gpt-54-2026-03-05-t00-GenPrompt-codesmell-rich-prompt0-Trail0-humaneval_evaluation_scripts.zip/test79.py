
import unittest
import re
import sys
import math
import copy


def decimal_to_binary(decimal):
    """Convert a non-negative decimal integer to the required binary string format.

    The returned value is wrapped with 'db' at the beginning and end.

    Examples:
        decimal_to_binary(15) -> "db1111db"
        decimal_to_binary(32) -> "db100000db"
    """
    binary = _to_binary_string(decimal)
    return _wrap_with_db(binary)


def _to_binary_string(decimal):
    """Convert a non-negative integer to its binary representation."""
    if decimal == 0:
        return "0"

    bits = []
    current = decimal

    while current > 0:
        bits.append(str(current % 2))
        current //= 2

    return "".join(reversed(bits))


def _wrap_with_db(binary_string):
    """Wrap a binary string with the required 'db' markers."""
    return f"db{binary_string}db"
candidate = decimal_to_binary


def check(candidate):

    # Check some simple cases
    assert candidate(0) == "db0db"
    assert candidate(32) == "db100000db"
    assert candidate(103) == "db1100111db"
    assert candidate(15) == "db1111db", "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
