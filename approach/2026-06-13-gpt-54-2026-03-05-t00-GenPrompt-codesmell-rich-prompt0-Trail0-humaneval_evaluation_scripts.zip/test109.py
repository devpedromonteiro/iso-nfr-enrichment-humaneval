
import unittest
import re
import sys
import math
import copy


def move_one_ball(arr):
    """Return True if some number of right shifts can sort the array.

    A right shift rotates the array by one position, moving the last element
    to the front. The function returns True when the input is already sorted,
    can become sorted through rotation, or is empty.
    """

    if not arr:
        return True

    return _has_at_most_one_descending_break(arr)


def _has_at_most_one_descending_break(values):
    """Check whether the sequence has at most one descending break.

    A rotated non-decreasing array with unique elements can contain only one
    position where values[i] > values[i + 1], considering the wrap-around
    from the last element back to the first.
    """
    descending_breaks = 0
    size = len(values)

    for index in range(size):
        current_value = values[index]
        next_value = values[(index + 1) % size]

        if current_value > next_value:
            descending_breaks += 1
            if descending_breaks > 1:
                return False

    return True
candidate = move_one_ball


def check(candidate):

    # Check some simple cases
    assert candidate([3, 4, 5, 1, 2])==True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([3, 5, 10, 1, 2])==True
    assert candidate([4, 3, 1, 2])==False
    # Check some edge cases that are easy to work out by hand.
    assert candidate([3, 5, 4, 1, 2])==False, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([])==True


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
