
import unittest
import re
import sys
import math
import copy



def _validate_non_empty(items: list) -> None:
    """Validate that the input list is not empty."""
    if not items:
        raise ValueError("max_element() arg is an empty list")


def _find_max(items: list):
    """Return the maximum value from a non-empty list."""
    maximum = items[0]
    for item in items[1:]:
        if item > maximum:
            maximum = item
    return maximum


def max_element(l: list):
    """Return maximum element in the list.

    >>> max_element([1, 2, 3])
    3
    >>> max_element([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    123
    """
    _validate_non_empty(l)
    return _find_max(l)
candidate = max_element




METADATA = {}


def check(candidate):
    assert candidate([1, 2, 3]) == 3
    assert candidate([5, 3, -5, 2, -3, 3, 9, 0, 124, 1, -10]) == 124


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
