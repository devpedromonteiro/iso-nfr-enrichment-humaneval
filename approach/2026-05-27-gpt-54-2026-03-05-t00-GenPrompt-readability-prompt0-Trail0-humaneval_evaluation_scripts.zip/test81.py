
import unittest
import re
import sys
import math
import copy


def numerical_letter_grade(grades):
    result = []

    for g in grades:
        if g == 4.0:
            result.append("A+")
        elif g > 3.7:
            result.append("A")
        elif g > 3.3:
            result.append("A-")
        elif g > 3.0:
            result.append("B+")
        elif g > 2.7:
            result.append("B")
        elif g > 2.3:
            result.append("B-")
        elif g > 2.0:
            result.append("C+")
        elif g > 1.7:
            result.append("C")
        elif g > 1.3:
            result.append("C-")
        elif g > 1.0:
            result.append("D+")
        elif g > 0.7:
            result.append("D")
        elif g > 0.0:
            result.append("D-")
        else:
            result.append("E")

    return result
candidate = numerical_letter_grade


def check(candidate):

    # Check some simple cases
    assert candidate([4.0, 3, 1.7, 2, 3.5]) == ['A+', 'B', 'C-', 'C', 'A-']
    assert candidate([1.2]) == ['D+']
    assert candidate([0.5]) == ['D-']
    assert candidate([0.0]) == ['E']
    assert candidate([1, 0.3, 1.5, 2.8, 3.3]) == ['D', 'D-', 'C-', 'B', 'B+']
    assert candidate([0, 0.7]) == ['E', 'D-']

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
