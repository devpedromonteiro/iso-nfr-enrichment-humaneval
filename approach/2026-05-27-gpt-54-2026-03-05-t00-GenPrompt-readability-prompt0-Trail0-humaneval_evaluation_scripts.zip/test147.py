
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    You are given a positive integer n. You have to create an integer array a of length n.
    For each i (1 â¤ i â¤ n), the value of a[i] = i * i - i + 1.
    Return the number of triples (a[i], a[j], a[k]) of a where i < j < k,
    and a[i] + a[j] + a[k] is a multiple of 3.

    Example:
        Input: n = 5
        Output: 1
        Explanation:
        a = [1, 3, 7, 13, 21]
        The only valid triple is (1, 7, 13).
    """
    def comb3(x):
        return x * (x - 1) * (x - 2) // 6 if x >= 3 else 0

    def comb2(x):
        return x * (x - 1) // 2 if x >= 2 else 0

    count_mod_0 = 0
    count_mod_1 = 0
    count_mod_2 = 0

    for i in range(1, n + 1):
        value_mod = (i * i - i + 1) % 3
        if value_mod == 0:
            count_mod_0 += 1
        elif value_mod == 1:
            count_mod_1 += 1
        else:
            count_mod_2 += 1

    return (
        comb3(count_mod_0) +
        comb3(count_mod_1) +
        comb3(count_mod_2) +
        count_mod_0 * count_mod_1 * count_mod_2
    )
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
