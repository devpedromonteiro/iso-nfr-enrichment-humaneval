
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    Return the number of triples (a[i], a[j], a[k]) with i < j < k such that
    a[i] + a[j] + a[k] is divisible by 3, where:

        a[i] = i*i - i + 1   for 1 <= i <= n

    Example:
        n = 5
        a = [1, 3, 7, 13, 21]
        Valid triples count = 1
    """
    if not isinstance(n, int) or n <= 0:
        raise ValueError("n must be a positive integer")

    # Since a[i] = i^2 - i + 1 = i(i-1) + 1
    # and i(i-1) is always divisible by 2, but we only care mod 3:
    #
    # i % 3 == 0 -> a[i] % 3 == 1
    # i % 3 == 1 -> a[i] % 3 == 1
    # i % 3 == 2 -> a[i] % 3 == 0
    #
    # So values are only in residue classes:
    #   0 mod 3  -> count of indices where i % 3 == 2
    #   1 mod 3  -> all remaining indices
    #
    # A triple sum is divisible by 3 only for:
    #   (0, 0, 0) or (1, 1, 1)
    #
    # Therefore answer = C(count0, 3) + C(count1, 3)

    count0 = (n + 1) // 3          # indices i in [1..n] with i % 3 == 2
    count1 = n - count0            # indices with a[i] % 3 == 1

    def comb3(x):
        return x * (x - 1) * (x - 2) // 6 if x >= 3 else 0

    return comb3(count0) + comb3(count1)
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
