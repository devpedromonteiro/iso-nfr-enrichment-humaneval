
import unittest
import re
import sys
import math
import copy



def encode_cyclic(s: str):
    """
    returns encoded string by cycling groups of three characters.
    """
    # split string to groups. Each of length 3.
    groups = [s[(3 * i):min((3 * i + 3), len(s))] for i in range((len(s) + 2) // 3)]
    # cycle elements in each group. Unless group has fewer elements than 3.
    groups = [(group[1:] + group[0]) if len(group) == 3 else group for group in groups]
    return "".join(groups)


def encode_cyclic(s: str) -> str:
    """
    Encode a string by rotating each group of three characters left by one.

    Examples:
        "abcdef" -> "bcaefd"
        "abcde"  -> "bcaed"
    """
    result = []

    for i in range(0, len(s), 3):
        group = s[i:i + 3]
        if len(group) == 3:
            result.append(group[1:] + group[0])
        else:
            result.append(group)

    return "".join(result)


def decode_cyclic(s: str) -> str:
    """
    Decode a string produced by encode_cyclic by rotating each full
    group of three characters right by one.

    Examples:
        "bcaefd" -> "abcdef"
        "bcaed"  -> "abcde"
    """
    result = []

    for i in range(0, len(s), 3):
        group = s[i:i + 3]
        if len(group) == 3:
            result.append(group[-1] + group[:-1])
        else:
            result.append(group)

    return "".join(result)
candidate = decode_cyclic




METADATA = {}


def check(candidate):
    from random import randint, choice
    import string

    letters = string.ascii_lowercase
    for _ in range(100):
        str = ''.join(choice(letters) for i in range(randint(10, 20)))
        encoded_str = encode_cyclic(str)
        assert candidate(encoded_str) == str



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
