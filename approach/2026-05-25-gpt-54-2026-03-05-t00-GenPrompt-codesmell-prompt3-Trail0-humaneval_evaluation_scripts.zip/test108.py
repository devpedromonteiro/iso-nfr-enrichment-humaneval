
import unittest
import re
import sys
import math
import copy


def count_nums(arr):
    """
    Return the number of integers whose signed digit sum is greater than 0.

    If a number is negative, only its first digit is negative:
    -123 -> -1 + 2 + 3 = 4

    >>> count_nums([]) == 0
    True
    >>> count_nums([-1, 11, -11]) == 1
    True
    >>> count_nums([1, 1, 2]) == 3
    True
    """
    def signed_digit_sum(n):
        digits = [int(d) for d in str(abs(n))]
        total = sum(digits)
        if n < 0:
            total -= 2 * digits[0]
        return total

    return sum(1 for num in arr if signed_digit_sum(num) > 0)
candidate = count_nums


def check(candidate):

    # Check some simple cases
    assert candidate([]) == 0
    assert candidate([-1, -2, 0]) == 0
    assert candidate([1, 1, 2, -2, 3, 4, 5]) == 6
    assert candidate([1, 6, 9, -6, 0, 1, 5]) == 5
    assert candidate([1, 100, 98, -7, 1, -1]) == 4
    assert candidate([12, 23, 34, -45, -56, 0]) == 5
    assert candidate([-0, 1**0]) == 1
    assert candidate([1]) == 1

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
