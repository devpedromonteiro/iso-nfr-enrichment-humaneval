
import unittest
import re
import sys
import math
import copy


def split_words(txt):
    """
    Given a string of words:
    - If it contains whitespace, return the words split on whitespace.
    - Otherwise, if it contains commas, return the words split on commas.
    - Otherwise, return the number of lowercase letters whose alphabet index is odd
      where ord('a') = 0, ord('b') = 1, ..., ord('z') = 25.
    """
    if any(char.isspace() for char in txt):
        return txt.split()

    if ',' in txt:
        return txt.split(',')

    return sum(
        1
        for char in txt
        if char.islower() and (ord(char) - ord('a')) % 2 == 1
    )
candidate = split_words


def check(candidate):

    assert candidate("Hello world!") == ["Hello","world!"]
    assert candidate("Hello,world!") == ["Hello","world!"]
    assert candidate("Hello world,!") == ["Hello","world,!"]
    assert candidate("Hello,Hello,world !") == ["Hello,Hello,world","!"]
    assert candidate("abcdef") == 3
    assert candidate("aaabb") == 2
    assert candidate("aaaBb") == 1
    assert candidate("") == 0


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
