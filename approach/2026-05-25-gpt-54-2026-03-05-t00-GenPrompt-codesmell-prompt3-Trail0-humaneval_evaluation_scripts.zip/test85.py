
import unittest
import re
import sys
import math
import copy


def add(lst):
    """
    Return the sum of even elements located at odd indices in a non-empty list of integers.

    Example:
        add([4, 2, 6, 7]) == 2
    """
    return sum(value for index, value in enumerate(lst) if index % 2 == 1 and value % 2 == 0)
candidate = add


def check(candidate):

    # Check some simple cases
    assert candidate([4, 88]) == 88
    assert candidate([4, 5, 6, 7, 2, 122]) == 122
    assert candidate([4, 0, 6, 7]) == 0
    assert candidate([4, 4, 6, 8]) == 12

    # Check some edge cases that are easy to work out by hand.
    


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
