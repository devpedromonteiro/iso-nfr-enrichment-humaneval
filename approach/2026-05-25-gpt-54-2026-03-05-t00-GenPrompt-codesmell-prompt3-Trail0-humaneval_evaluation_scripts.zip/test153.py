
import unittest
import re
import sys
import math
import copy


def Strongest_Extension(class_name, extensions):
    """Return 'ClassName.StrongestExtensionName' for the strongest extension.

    Strength is defined as:
        number_of_uppercase_letters - number_of_lowercase_letters

    If multiple extensions have the same strength, the first one is chosen.
    """

    def strength(extension):
        upper_count = sum(1 for ch in extension if ch.isupper())
        lower_count = sum(1 for ch in extension if ch.islower())
        return upper_count - lower_count

    strongest = extensions[0]
    max_strength = strength(strongest)

    for extension in extensions[1:]:
        current_strength = strength(extension)
        if current_strength > max_strength:
            strongest = extension
            max_strength = current_strength

    return f"{class_name}.{strongest}"
candidate = Strongest_Extension


def check(candidate):

    # Check some simple cases
    assert candidate('Watashi', ['tEN', 'niNE', 'eIGHt8OKe']) == 'Watashi.eIGHt8OKe'
    assert candidate('Boku123', ['nani', 'NazeDa', 'YEs.WeCaNe', '32145tggg']) == 'Boku123.YEs.WeCaNe'
    assert candidate('__YESIMHERE', ['t', 'eMptY', 'nothing', 'zeR00', 'NuLl__', '123NoooneB321']) == '__YESIMHERE.NuLl__'
    assert candidate('K', ['Ta', 'TAR', 't234An', 'cosSo']) == 'K.TAR'
    assert candidate('__HAHA', ['Tab', '123', '781345', '-_-']) == '__HAHA.123'
    assert candidate('YameRore', ['HhAas', 'okIWILL123', 'WorkOut', 'Fails', '-_-']) == 'YameRore.okIWILL123'
    assert candidate('finNNalLLly', ['Die', 'NowW', 'Wow', 'WoW']) == 'finNNalLLly.WoW'

    # Check some edge cases that are easy to work out by hand.
    assert candidate('_', ['Bb', '91245']) == '_.Bb'
    assert candidate('Sp', ['671235', 'Bb']) == 'Sp.671235'
    


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
