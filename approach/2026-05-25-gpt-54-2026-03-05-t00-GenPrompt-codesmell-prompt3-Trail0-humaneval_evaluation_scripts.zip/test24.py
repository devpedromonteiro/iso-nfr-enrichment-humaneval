
import unittest
import re
import sys
import math
import copy



def largest_divisor(n: int) -> int:
    """Return the largest positive divisor of n that is smaller than n.

    For prime numbers, this returns 1.

    Args:
        n: A positive integer greater than 1.

    Returns:
        The largest number that divides n evenly and is smaller than n.

    Raises:
        ValueError: If n is less than or equal to 1.

    >>> largest_divisor(15)
    5
    >>> largest_divisor(13)
    1
    >>> largest_divisor(16)
    8
    """
    if n <= 1:
        raise ValueError("n must be greater than 1")

    for divisor in range(2, int(n ** 0.5) + 1):
        if n % divisor == 0:
            return n // divisor

    return 1
candidate = largest_divisor




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(3) == 1
    assert candidate(7) == 1
    assert candidate(10) == 5
    assert candidate(100) == 50
    assert candidate(49) == 7


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
