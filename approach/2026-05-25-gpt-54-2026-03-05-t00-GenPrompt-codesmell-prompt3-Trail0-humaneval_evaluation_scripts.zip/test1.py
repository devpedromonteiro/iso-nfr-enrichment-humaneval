
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def separate_paren_groups(paren_string: str) -> List[str]:
    """
    Input to this function is a string containing multiple groups of nested parentheses.
    Return those groups as separate strings.

    Separate groups are balanced and not nested within each other.
    Ignore any spaces in the input string.

    >>> separate_paren_groups('( ) (( )) (( )( ))')
    ['()', '(())', '(()())']
    """
    groups: List[str] = []
    current_group: List[str] = []
    balance = 0

    for char in paren_string:
        if char == " ":
            continue

        if char == "(":
            balance += 1
            current_group.append(char)
        elif char == ")":
            balance -= 1
            current_group.append(char)

            if balance == 0:
                groups.append("".join(current_group))
                current_group = []

    return groups
candidate = separate_paren_groups




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('(()()) ((())) () ((())()())') == [
        '(()())', '((()))', '()', '((())()())'
    ]
    assert candidate('() (()) ((())) (((())))') == [
        '()', '(())', '((()))', '(((())))'
    ]
    assert candidate('(()(())((())))') == [
        '(()(())((())))'
    ]
    assert candidate('( ) (( )) (( )( ))') == ['()', '(())', '(()())']


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
