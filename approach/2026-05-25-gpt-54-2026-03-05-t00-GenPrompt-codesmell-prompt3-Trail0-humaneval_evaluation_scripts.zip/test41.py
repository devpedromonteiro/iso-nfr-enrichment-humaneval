
import unittest
import re
import sys
import math
import copy



def car_race_collision(n: int) -> int:
    """
    Return the total number of collisions between two groups of cars.

    There are:
    - n cars moving left to right
    - n cars moving right to left

    Every left-to-right car will collide exactly once with every right-to-left car,
    so the total number of collisions is n * n.

    Args:
        n: Number of cars in each group. Must be a non-negative integer.

    Returns:
        Total number of collisions.

    Raises:
        TypeError: If n is not an integer.
        ValueError: If n is negative.
    """
    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if n < 0:
        raise ValueError("n must be non-negative")

    return n * n
candidate = car_race_collision




METADATA = {}


def check(candidate):
    assert candidate(2) == 4
    assert candidate(3) == 9
    assert candidate(4) == 16
    assert candidate(8) == 64
    assert candidate(10) == 100



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
