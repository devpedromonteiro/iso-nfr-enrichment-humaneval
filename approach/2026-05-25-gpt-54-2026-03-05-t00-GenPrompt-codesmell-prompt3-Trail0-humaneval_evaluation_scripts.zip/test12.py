
import unittest
import re
import sys
import math
import copy

from typing import List, Optional


from typing import List, Optional


def longest(strings: List[str]) -> Optional[str]:
    """Return the longest string in the list.

    If multiple strings have the same maximum length, return the first one.
    Return None if the input list is empty.

    >>> longest([]) is None
    True
    >>> longest(['a', 'b', 'c'])
    'a'
    >>> longest(['a', 'bb', 'ccc'])
    'ccc'
    >>> longest(['aa', 'bb', 'c'])
    'aa'
    """
    if not strings:
        return None

    longest_string = strings[0]
    for s in strings[1:]:
        if len(s) > len(longest_string):
            longest_string = s

    return longest_string
candidate = longest




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == None
    assert candidate(['x', 'y', 'z']) == 'x'
    assert candidate(['x', 'yyy', 'zzzz', 'www', 'kkkk', 'abc']) == 'zzzz'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
