
import unittest
import re
import sys
import math
import copy


FIX = """
Add more test cases.
"""

FIX = """
Code smells addressed:
- Missing implementation.
- No automated tests despite the note saying to add more test cases.
- Potential case-sensitivity bug.
- Edge case for 'y' only counting at the end.
"""

def vowels_count(s):
    """Return the number of vowels in a word.

    Vowels are: a, e, i, o, u.
    The letter 'y' counts as a vowel only when it appears at the end
    of the word.

    Example:
    >>> vowels_count("abcde")
    2
    >>> vowels_count("ACEDY")
    3
    """
    if not isinstance(s, str):
        raise TypeError("s must be a string")

    word = s.lower()
    count = sum(1 for ch in word if ch in "aeiou")

    if word.endswith("y"):
        count += 1

    return count


def _test_vowels_count():
    assert vowels_count("abcde") == 2
    assert vowels_count("ACEDY") == 3
    assert vowels_count("") == 0
    assert vowels_count("bcd") == 0
    assert vowels_count("aeiou") == 5
    assert vowels_count("AEIOU") == 5
    assert vowels_count("y") == 1
    assert vowels_count("yy") == 1
    assert vowels_count("happy") == 2
    assert vowels_count("yellow") == 2
    assert vowels_count("rhythm") == 0
    assert vowels_count("rhythmy") == 1
candidate = vowels_count


def check(candidate):

    # Check some simple cases
    assert candidate("abcde") == 2, "Test 1"
    assert candidate("Alone") == 3, "Test 2"
    assert candidate("key") == 2, "Test 3"
    assert candidate("bye") == 1, "Test 4"
    assert candidate("keY") == 2, "Test 5"
    assert candidate("bYe") == 1, "Test 6"
    assert candidate("ACEDY") == 3, "Test 7"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
