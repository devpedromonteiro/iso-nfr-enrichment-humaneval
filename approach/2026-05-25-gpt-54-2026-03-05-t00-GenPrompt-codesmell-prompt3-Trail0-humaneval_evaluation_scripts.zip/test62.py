
import unittest
import re
import sys
import math
import copy



def derivative(xs: list[float]) -> list[float]:
    """Return the derivative of a polynomial given by its coefficients.

    The polynomial is represented as:
        xs[0] + xs[1] * x + xs[2] * x^2 + ...

    The derivative is returned in the same coefficient form.

    Examples:
    >>> derivative([3, 1, 2, 4, 5])
    [1, 4, 12, 20]
    >>> derivative([1, 2, 3])
    [2, 6]
    >>> derivative([7])
    []
    >>> derivative([])
    []
    """
    return [i * xs[i] for i in range(1, len(xs))]
candidate = derivative




METADATA = {}


def check(candidate):
    assert candidate([3, 1, 2, 4, 5]) == [1, 4, 12, 20]
    assert candidate([1, 2, 3]) == [2, 6]
    assert candidate([3, 2, 1]) == [2, 2]
    assert candidate([3, 2, 1, 0, 4]) == [2, 2, 0, 16]
    assert candidate([1]) == []



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
