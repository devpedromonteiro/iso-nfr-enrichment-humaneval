
import unittest
import re
import sys
import math
import copy


def do_algebra(operator, operand):
    """
    Evaluate an algebraic expression built from operators and operands.

    The expression is formed by placing each operator between consecutive operands,
    then evaluating it using normal Python operator precedence.

    Example:
        operator = ['+', '*', '-']
        operand = [2, 3, 4, 5]

        Expression: 2 + 3 * 4 - 5
        Result: 9
    """
    if len(operator) != len(operand) - 1:
        raise ValueError("operator list length must be exactly one less than operand list length")

    expression = str(operand[0])
    for op, value in zip(operator, operand[1:]):
        expression += f" {op} {value}"

    return eval(expression)
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
