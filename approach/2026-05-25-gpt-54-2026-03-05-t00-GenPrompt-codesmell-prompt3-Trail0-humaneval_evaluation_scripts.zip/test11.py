
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def string_xor(a: str, b: str) -> str:
    """Return the bitwise XOR of two equal-length binary strings.

    Inputs must contain only '0' and '1'.

    >>> string_xor('010', '110')
    '100'
    """
    if len(a) != len(b):
        raise ValueError("Inputs must have the same length.")

    if any(ch not in {"0", "1"} for ch in a + b):
        raise ValueError("Inputs must contain only '0' and '1'.")

    return "".join("1" if left != right else "0" for left, right in zip(a, b))
candidate = string_xor




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('111000', '101010') == '010010'
    assert candidate('1', '1') == '0'
    assert candidate('0101', '0000') == '0101'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
