
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math
from typing import Sequence


def poly(coefficients: Sequence[float], x: float) -> float:
    """
    Evaluate a polynomial at point x.

    The polynomial is defined by coefficients:
        coefficients[0] + coefficients[1] * x + coefficients[2] * x^2 + ... + coefficients[n] * x^n

    Uses Horner's method for better readability and efficiency.
    """
    result = 0.0
    for coefficient in reversed(coefficients):
        result = result * x + coefficient
    return result


def find_zero(coefficients: Sequence[float], *, tolerance: float = 1e-10, max_iter: int = 10_000) -> float:
    """
    Find one real zero of a polynomial.

    Assumptions:
    - `coefficients` contains an even number of coefficients.
    - The highest non-zero coefficient corresponds to an odd degree polynomial,
      which guarantees at least one real root.

    Returns one real root.

    >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2)  # (x - 1) * (x - 2) * (x - 3)
    1.0
    """
    if not coefficients:
        raise ValueError("coefficients must not be empty")

    # Remove trailing zeros to determine the actual degree.
    coefficients = list(coefficients)
    while coefficients and coefficients[-1] == 0:
        coefficients.pop()

    if not coefficients:
        raise ValueError("polynomial must not be identically zero")

    if len(coefficients) % 2 != 0:
        raise ValueError("coefficients must contain an even number of items")

    def f(x: float) -> float:
        return poly(coefficients, x)

    # First try to find an interval [left, right] with a sign change.
    left, right = -1.0, 1.0
    f_left, f_right = f(left), f(right)

    for _ in range(max_iter):
        if abs(f_left) < tolerance:
            return left
        if abs(f_right) < tolerance:
            return right

        if f_left * f_right <= 0:
            break

        left *= 2
        right *= 2
        f_left, f_right = f(left), f(right)
    else:
        raise RuntimeError("failed to bracket a root")

    # Bisection method.
    for _ in range(max_iter):
        mid = (left + right) / 2
        f_mid = f(mid)

        if abs(f_mid) < tolerance or abs(right - left) < tolerance:
            return mid

        if f_left * f_mid <= 0:
            right = mid
            f_right = f_mid
        else:
            left = mid
            f_left = f_mid

    raise RuntimeError("failed to converge to a root")
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
