
import unittest
import re
import sys
import math
import copy



def triples_sum_to_zero(nums: list[int]) -> bool:
    """
    Return True if there are three distinct elements in nums whose sum is 0,
    and False otherwise.

    The implementation avoids common code smells by:
    - using a descriptive parameter name (`nums` instead of `l`)
    - handling small inputs early
    - avoiding brute-force O(n^3) nested loops
    - keeping the logic clear and focused

    >>> triples_sum_to_zero([1, 3, 5, 0])
    False
    >>> triples_sum_to_zero([1, 3, -2, 1])
    True
    >>> triples_sum_to_zero([1, 2, 3, 7])
    False
    >>> triples_sum_to_zero([2, 4, -5, 3, 9, 7])
    True
    >>> triples_sum_to_zero([1])
    False
    """
    if len(nums) < 3:
        return False

    nums = sorted(nums)

    for i in range(len(nums) - 2):
        left = i + 1
        right = len(nums) - 1

        while left < right:
            total = nums[i] + nums[left] + nums[right]

            if total == 0:
                return True
            if total < 0:
                left += 1
            else:
                right -= 1

    return False
candidate = triples_sum_to_zero




METADATA = {}


def check(candidate):
    assert candidate([1, 3, 5, 0]) == False
    assert candidate([1, 3, 5, -1]) == False
    assert candidate([1, 3, -2, 1]) == True
    assert candidate([1, 2, 3, 7]) == False
    assert candidate([1, 2, 5, 7]) == False
    assert candidate([2, 4, -5, 3, 9, 7]) == True
    assert candidate([1]) == False
    assert candidate([1, 3, 5, -100]) == False
    assert candidate([100, 3, 5, -100]) == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
