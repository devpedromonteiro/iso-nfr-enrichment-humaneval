
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def separate_paren_groups(paren_string: str) -> List[str]:
    """Separate balanced parenthesis groups from the input string.

    The input contains multiple balanced groups of parentheses. Groups may be
    nested internally, but separate groups are not nested within each other.
    Spaces in the input are ignored.

    >>> separate_paren_groups('( ) (( )) (( )( ))')
    ['()', '(())', '(()())']
    """
    groups: List[str] = []
    current_group = []
    nesting_level = 0

    for character in paren_string:
        if character == " ":
            continue

        current_group.append(character)

        if character == "(":
            nesting_level += 1
        elif character == ")":
            nesting_level -= 1

            if nesting_level == 0:
                groups.append("".join(current_group))
                current_group = []

    return groups
candidate = separate_paren_groups




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('(()()) ((())) () ((())()())') == [
        '(()())', '((()))', '()', '((())()())'
    ]
    assert candidate('() (()) ((())) (((())))') == [
        '()', '(())', '((()))', '(((())))'
    ]
    assert candidate('(()(())((())))') == [
        '(()(())((())))'
    ]
    assert candidate('( ) (( )) (( )( ))') == ['()', '(())', '(()())']


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
