
import unittest
import re
import sys
import math
import copy



def car_race_collision(number_of_cars_per_direction: int) -> int:
    """
    Return the total number of collisions between two groups of cars.

    A group of `number_of_cars_per_direction` cars moves from left to right,
    while another group of the same size moves from right to left. Every car
    moving right meets every car moving left exactly once, so the total number
    of collisions is:

        number_of_cars_per_direction * number_of_cars_per_direction
    """
    return number_of_cars_per_direction ** 2
candidate = car_race_collision




METADATA = {}


def check(candidate):
    assert candidate(2) == 4
    assert candidate(3) == 9
    assert candidate(4) == 16
    assert candidate(8) == 64
    assert candidate(10) == 100



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
