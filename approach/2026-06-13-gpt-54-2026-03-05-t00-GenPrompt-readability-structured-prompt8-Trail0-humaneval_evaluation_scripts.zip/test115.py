
import unittest
import re
import sys
import math
import copy


import math


def max_fill(grid, capacity):
    """
    Calculate how many bucket lowerings are needed to empty all wells.

    Each row in the grid represents one well.
    Each value of 1 represents one unit of water in that well.
    A bucket can remove up to `capacity` units of water from a single well
    each time it is lowered.

    Args:
        grid: A rectangular list of lists containing 0s and 1s.
        capacity: The number of water units a bucket can carry per lowering.

    Returns:
        The total number of bucket lowerings needed to empty all wells.
    """
    total_bucket_lowerings = 0

    for well in grid:
        water_units_in_well = sum(well)
        bucket_lowerings_for_well = math.ceil(water_units_in_well / capacity)
        total_bucket_lowerings += bucket_lowerings_for_well

    return total_bucket_lowerings
candidate = max_fill


def check(candidate):


    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([[0,0,1,0], [0,1,0,0], [1,1,1,1]], 1) == 6, "Error"
    assert candidate([[0,0,1,1], [0,0,0,0], [1,1,1,1], [0,1,1,1]], 2) == 5, "Error"
    assert candidate([[0,0,0], [0,0,0]], 5) == 0, "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([[1,1,1,1], [1,1,1,1]], 2) == 4, "Error"
    assert candidate([[1,1,1,1], [1,1,1,1]], 9) == 2, "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
