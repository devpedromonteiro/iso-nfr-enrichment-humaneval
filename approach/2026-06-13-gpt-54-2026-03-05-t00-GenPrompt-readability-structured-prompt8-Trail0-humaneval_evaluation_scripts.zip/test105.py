
import unittest
import re
import sys
import math
import copy


def by_length(numbers):
    """
    Return the valid digits from the input as their English names, ordered from
    largest to smallest.

    Rules:
    - Only integers from 1 to 9 are considered valid.
    - Invalid values are ignored.
    - Valid numbers are sorted in descending order.
    - Each number is replaced with its corresponding name.

    Examples:
    - [2, 1, 1, 4, 5, 8, 2, 3] -> ["Eight", "Five", "Four", "Three", "Two", "Two", "One", "One"]
    - [] -> []
    - [1, -1, 55] -> ["One"]
    """
    digit_names = {
        1: "One",
        2: "Two",
        3: "Three",
        4: "Four",
        5: "Five",
        6: "Six",
        7: "Seven",
        8: "Eight",
        9: "Nine",
    }

    valid_numbers = [number for number in numbers if number in digit_names]
    sorted_numbers_descending = sorted(valid_numbers, reverse=True)

    return [digit_names[number] for number in sorted_numbers_descending]
candidate = by_length


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([2, 1, 1, 4, 5, 8, 2, 3]) == ["Eight", "Five", "Four", "Three", "Two", "Two", "One", "One"], "Error"
    assert candidate([]) == [], "Error"
    assert candidate([1, -1 , 55]) == ['One'], "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([1, -1, 3, 2]) == ["Three", "Two", "One"]
    assert candidate([9, 4, 8]) == ["Nine", "Eight", "Four"]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
