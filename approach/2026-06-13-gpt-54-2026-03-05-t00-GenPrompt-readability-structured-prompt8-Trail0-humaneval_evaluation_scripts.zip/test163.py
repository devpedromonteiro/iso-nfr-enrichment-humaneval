
import unittest
import re
import sys
import math
import copy


def generate_integers(first_number, second_number):
    """
    Return all even digits between two positive integers, in ascending order.

    Only single-digit even numbers are included: 2, 4, 6, and 8.

    Examples:
        generate_integers(2, 8) -> [2, 4, 6, 8]
        generate_integers(8, 2) -> [2, 4, 6, 8]
        generate_integers(10, 14) -> []
    """
    lower_bound = min(first_number, second_number)
    upper_bound = max(first_number, second_number)

    even_digits = [2, 4, 6, 8]

    return [
        digit
        for digit in even_digits
        if lower_bound <= digit <= upper_bound
    ]
candidate = generate_integers


def check(candidate):

    # Check some simple cases
    assert candidate(2, 10) == [2, 4, 6, 8], "Test 1"
    assert candidate(10, 2) == [2, 4, 6, 8], "Test 2"
    assert candidate(132, 2) == [2, 4, 6, 8], "Test 3"
    assert candidate(17,89) == [], "Test 4"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
