
import unittest
import re
import sys
import math
import copy


def histogram(text):
    """Return the most frequent letters from a space-separated lowercase string.

    The result is a dictionary where:
    - each key is a letter with the highest frequency
    - each value is that letter's count

    Examples:
        histogram('a b c') == {'a': 1, 'b': 1, 'c': 1}
        histogram('a b b a') == {'a': 2, 'b': 2}
        histogram('a b c a b') == {'a': 2, 'b': 2}
        histogram('b b b b a') == {'b': 4}
        histogram('') == {}
    """
    if not text:
        return {}

    letters = text.split()
    counts = {}

    for letter in letters:
        counts[letter] = counts.get(letter, 0) + 1

    highest_count = max(counts.values())
    most_frequent_letters = {}

    for letter, count in counts.items():
        if count == highest_count:
            most_frequent_letters[letter] = count

    return most_frequent_letters
candidate = histogram


def check(candidate):

    # Check some simple cases
    assert candidate('a b b a') == {'a':2,'b': 2}, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('a b c a b') == {'a': 2, 'b': 2}, "This prints if this assert fails 2 (good for debugging!)"
    assert candidate('a b c d g') == {'a': 1, 'b': 1, 'c': 1, 'd': 1, 'g': 1}, "This prints if this assert fails 3 (good for debugging!)"
    assert candidate('r t g') == {'r': 1,'t': 1,'g': 1}, "This prints if this assert fails 4 (good for debugging!)"
    assert candidate('b b b b a') == {'b': 4}, "This prints if this assert fails 5 (good for debugging!)"
    assert candidate('r t g') == {'r': 1,'t': 1,'g': 1}, "This prints if this assert fails 6 (good for debugging!)"
    
    
    # Check some edge cases that are easy to work out by hand.
    assert candidate('') == {}, "This prints if this assert fails 7 (also good for debugging!)"
    assert candidate('a') == {'a': 1}, "This prints if this assert fails 8 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
