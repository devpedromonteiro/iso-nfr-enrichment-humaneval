
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def remove_duplicates(numbers: List[int]) -> List[int]:
    """Return the integers that appear exactly once, preserving input order.

    Any value that occurs more than once is removed entirely.

    >>> remove_duplicates([1, 2, 3, 2, 4])
    [1, 3, 4]
    """
    occurrence_count = {}

    for number in numbers:
        occurrence_count[number] = occurrence_count.get(number, 0) + 1

    unique_numbers_in_order = []

    for number in numbers:
        if occurrence_count[number] == 1:
            unique_numbers_in_order.append(number)

    return unique_numbers_in_order
candidate = remove_duplicates




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == []
    assert candidate([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert candidate([1, 2, 3, 2, 4, 3, 5]) == [1, 4, 5]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
