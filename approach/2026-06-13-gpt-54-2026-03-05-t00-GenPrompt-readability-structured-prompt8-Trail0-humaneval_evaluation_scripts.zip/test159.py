
import unittest
import re
import sys
import math
import copy


def eat(eaten_so_far, carrots_needed, carrots_remaining):
    """
    Return the rabbit's total eaten carrots and remaining stock after eating.

    The rabbit will eat as many carrots as needed, up to the number available.
    If there are not enough carrots remaining, it eats all of them.

    Args:
        eaten_so_far (int): Number of carrots already eaten.
        carrots_needed (int): Number of additional carrots the rabbit wants to eat.
        carrots_remaining (int): Number of carrots currently available.

    Returns:
        list[int]: [total_eaten, remaining_after_eating]

    Examples:
        eat(5, 6, 10) -> [11, 4]
        eat(4, 8, 9) -> [12, 1]
        eat(1, 10, 10) -> [11, 0]
        eat(2, 11, 5) -> [7, 0]
    """
    carrots_to_eat = min(carrots_needed, carrots_remaining)
    total_eaten = eaten_so_far + carrots_to_eat
    remaining_after_eating = carrots_remaining - carrots_to_eat

    return [total_eaten, remaining_after_eating]
candidate = eat


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(5, 6, 10) == [11, 4], "Error"
    assert candidate(4, 8, 9) == [12, 1], "Error"
    assert candidate(1, 10, 10) == [11, 0], "Error"
    assert candidate(2, 11, 5) == [7, 0], "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate(4, 5, 7) == [9, 2], "Error"
    assert candidate(4, 5, 1) == [5, 0], "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
