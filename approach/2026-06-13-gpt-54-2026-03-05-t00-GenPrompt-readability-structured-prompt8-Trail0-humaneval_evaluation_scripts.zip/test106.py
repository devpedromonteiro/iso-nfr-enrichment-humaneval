
import unittest
import re
import sys
import math
import copy


def f(n):
    """Return a list of length n based on each 1-based position.

    For each position i from 1 to n:
    - if i is even, store i!
    - if i is odd, store the sum of numbers from 1 to i

    Example:
        f(5) == [1, 2, 6, 24, 15]
    """
    result = []
    factorial_so_far = 1
    running_sum = 0

    for number in range(1, n + 1):
        factorial_so_far *= number
        running_sum += number

        if number % 2 == 0:
            result.append(factorial_so_far)
        else:
            result.append(running_sum)

    return result
candidate = f


def check(candidate):

    assert candidate(5) == [1, 2, 6, 24, 15]
    assert candidate(7) == [1, 2, 6, 24, 15, 720, 28]
    assert candidate(1) == [1]
    assert candidate(3) == [1, 2, 6]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
