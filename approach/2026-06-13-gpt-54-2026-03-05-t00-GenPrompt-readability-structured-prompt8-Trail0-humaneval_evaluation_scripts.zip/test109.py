
import unittest
import re
import sys
import math
import copy


def move_one_ball(numbers):
    """Return True if some number of right shifts can sort the list.

    A right shift moves the last element to the front. The function returns True
    when the given list is already sorted, can become sorted after some right
    shifts, or is empty.

    The list is guaranteed to contain unique elements.
    """
    if not numbers:
        return True

    drop_count = 0
    total_numbers = len(numbers)

    for index in range(total_numbers):
        current_value = numbers[index]
        next_value = numbers[(index + 1) % total_numbers]

        if current_value > next_value:
            drop_count += 1
            if drop_count > 1:
                return False

    return True
candidate = move_one_ball


def check(candidate):

    # Check some simple cases
    assert candidate([3, 4, 5, 1, 2])==True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([3, 5, 10, 1, 2])==True
    assert candidate([4, 3, 1, 2])==False
    # Check some edge cases that are easy to work out by hand.
    assert candidate([3, 5, 4, 1, 2])==False, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([])==True


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
