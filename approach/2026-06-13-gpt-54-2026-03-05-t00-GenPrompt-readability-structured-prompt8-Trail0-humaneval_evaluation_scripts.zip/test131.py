
import unittest
import re
import sys
import math
import copy


def digits(number):
    """Return the product of the odd digits in a positive integer.

    If the number contains no odd digits, return 0.

    Examples:
        digits(1) == 1
        digits(4) == 0
        digits(235) == 15
    """
    odd_digit_product = 1
    found_odd_digit = False

    for digit_character in str(number):
        digit = int(digit_character)

        if digit % 2 == 1:
            odd_digit_product *= digit
            found_odd_digit = True

    if not found_odd_digit:
        return 0

    return odd_digit_product
candidate = digits


def check(candidate):

    # Check some simple cases
    assert candidate(5) == 5
    assert candidate(54) == 5
    assert candidate(120) ==1
    assert candidate(5014) == 5
    assert candidate(98765) == 315
    assert candidate(5576543) == 2625

    # Check some edge cases that are easy to work out by hand.
    assert candidate(2468) == 0



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
