
import unittest
import re
import sys
import math
import copy



def median(numbers: list):
    """Return the median of the values in ``numbers``.

    The median is the middle value of the sorted list when the number of
    elements is odd. When the number of elements is even, it is the average
    of the two middle values.

    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    15.0
    """
    sorted_numbers = sorted(numbers)
    item_count = len(sorted_numbers)
    middle_index = item_count // 2

    if item_count % 2 == 1:
        return sorted_numbers[middle_index]

    left_middle = sorted_numbers[middle_index - 1]
    right_middle = sorted_numbers[middle_index]
    return (left_middle + right_middle) / 2
candidate = median




METADATA = {}


def check(candidate):
    assert candidate([3, 1, 2, 4, 5]) == 3
    assert candidate([-10, 4, 6, 1000, 10, 20]) == 8.0
    assert candidate([5]) == 5
    assert candidate([6, 5]) == 5.5
    assert candidate([8, 1, 3, 9, 9, 2, 7]) == 7 



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
