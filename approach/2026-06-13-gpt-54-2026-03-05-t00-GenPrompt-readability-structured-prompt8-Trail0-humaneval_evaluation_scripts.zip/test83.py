
import unittest
import re
import sys
import math
import copy


def starts_one_ends(digit_count):
    """
    Return how many positive integers with exactly `digit_count` digits
    start with 1 or end with 1.

    Examples:
        - For 1 digit: only "1" matches, so the result is 1.
        - For 2 digits: 10, 11, 21, 31, ..., 91, so the result is 18.
    """
    if digit_count <= 0:
        raise ValueError("digit_count must be a positive integer")

    if digit_count == 1:
        return 1

    numbers_starting_with_1 = 10 ** (digit_count - 1)
    numbers_ending_with_1 = 9 * (10 ** (digit_count - 2))
    numbers_starting_and_ending_with_1 = 10 ** (digit_count - 2)

    total_matching_numbers = (
        numbers_starting_with_1
        + numbers_ending_with_1
        - numbers_starting_and_ending_with_1
    )

    return total_matching_numbers
candidate = starts_one_ends


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(1) == 1
    assert candidate(2) == 18
    assert candidate(3) == 180
    assert candidate(4) == 1800
    assert candidate(5) == 18000

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
