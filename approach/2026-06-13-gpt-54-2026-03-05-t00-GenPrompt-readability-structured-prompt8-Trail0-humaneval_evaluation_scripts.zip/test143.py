
import unittest
import re
import sys
import math
import copy


def words_in_sentence(sentence):
    """
    Return a space-separated string containing only the words
    whose lengths are prime numbers.

    The original word order is preserved.

    Examples:
        words_in_sentence("This is a test") -> "is"
        words_in_sentence("lets go for swimming") -> "go for"
    """

    def is_prime(number):
        """Return True if number is a prime number, otherwise False."""
        if number < 2:
            return False

        for divisor in range(2, int(number ** 0.5) + 1):
            if number % divisor == 0:
                return False

        return True

    words = sentence.split()
    words_with_prime_length = []

    for word in words:
        if is_prime(len(word)):
            words_with_prime_length.append(word)

    return " ".join(words_with_prime_length)
candidate = words_in_sentence


def check(candidate):

    # Check some simple cases
    assert candidate("This is a test") == "is"
    assert candidate("lets go for swimming") == "go for"
    assert candidate("there is no place available here") == "there is no place"
    assert candidate("Hi I am Hussein") == "Hi am Hussein"
    assert candidate("go for it") == "go for it"

    # Check some edge cases that are easy to work out by hand.
    assert candidate("here") == ""
    assert candidate("here is") == "is"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
