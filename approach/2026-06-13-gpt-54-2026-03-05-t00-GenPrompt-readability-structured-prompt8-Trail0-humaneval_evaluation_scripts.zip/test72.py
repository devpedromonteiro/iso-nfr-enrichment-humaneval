
import unittest
import re
import sys
import math
import copy


def will_it_fly(object_weights, maximum_weight):
    """
    Return True if the object will fly, otherwise False.

    An object will fly when:
    1. It is balanced, meaning its list of weights is a palindrome.
    2. The total weight is less than or equal to the maximum allowed weight.
    """
    is_balanced = object_weights == object_weights[::-1]
    total_weight = sum(object_weights)

    return is_balanced and total_weight <= maximum_weight
candidate = will_it_fly


def check(candidate):

    # Check some simple cases
    assert candidate([3, 2, 3], 9) is True
    assert candidate([1, 2], 5) is False
    assert candidate([3], 5) is True
    assert candidate([3, 2, 3], 1) is False


    # Check some edge cases that are easy to work out by hand.
    assert candidate([1, 2, 3], 6) is False
    assert candidate([5], 5) is True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
