
import unittest
import re
import sys
import math
import copy



def flip_case(text: str) -> str:
    """Return a copy of the text with each letter's case reversed.

    Lowercase letters become uppercase, and uppercase letters become
    lowercase. Non-alphabetic characters are left unchanged.

    >>> flip_case("Hello")
    'hELLO'
    """
    return text.swapcase()
candidate = flip_case




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == ''
    assert candidate('Hello!') == 'hELLO!'
    assert candidate('These violent delights have violent ends') == 'tHESE VIOLENT DELIGHTS HAVE VIOLENT ENDS'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
