
import unittest
import re
import sys
import math
import copy


import math


def triangle_area(side_a, side_b, side_c):
    """
    Return the area of a triangle rounded to 2 decimal places.

    If the three side lengths do not form a valid triangle, return -1.

    A triangle is valid when the sum of any two sides is greater than the third:
    - side_a + side_b > side_c
    - side_a + side_c > side_b
    - side_b + side_c > side_a

    Examples:
        triangle_area(3, 4, 5) == 6.0
        triangle_area(1, 2, 10) == -1
    """
    is_valid_triangle = (
        side_a + side_b > side_c
        and side_a + side_c > side_b
        and side_b + side_c > side_a
    )

    if not is_valid_triangle:
        return -1

    semi_perimeter = (side_a + side_b + side_c) / 2
    area = math.sqrt(
        semi_perimeter
        * (semi_perimeter - side_a)
        * (semi_perimeter - side_b)
        * (semi_perimeter - side_c)
    )

    return round(area, 2)
candidate = triangle_area


def check(candidate):

    # Check some simple cases
    assert candidate(3, 4, 5) == 6.00, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(1, 2, 10) == -1
    assert candidate(4, 8, 5) == 8.18
    assert candidate(2, 2, 2) == 1.73
    assert candidate(1, 2, 3) == -1
    assert candidate(10, 5, 7) == 16.25
    assert candidate(2, 6, 3) == -1

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1, 1, 1) == 0.43, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate(2, 2, 10) == -1



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
