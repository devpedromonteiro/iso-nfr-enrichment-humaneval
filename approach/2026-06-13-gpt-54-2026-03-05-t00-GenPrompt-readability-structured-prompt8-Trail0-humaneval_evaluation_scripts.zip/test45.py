
import unittest
import re
import sys
import math
import copy



def triangle_area(base_length, height):
    """Return the area of a triangle.

    Args:
        base_length: The length of the triangle's base.
        height: The height corresponding to that base.

    Returns:
        The triangle's area.

    >>> triangle_area(5, 3)
    7.5
    """
    return (base_length * height) / 2
candidate = triangle_area




METADATA = {}


def check(candidate):
    assert candidate(5, 3) == 7.5
    assert candidate(2, 2) == 2.0
    assert candidate(10, 8) == 40.0



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
