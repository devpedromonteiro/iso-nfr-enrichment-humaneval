
import unittest


def starts_one_ends(n):
    """
    Return the number of n-digit positive integers that start or end with 1.

    An n-digit number:
    - starts with 1: 10^(n - 1) possibilities
    - ends with 1:   9 * 10^(n - 2) possibilities for n >= 2

    Numbers that both start and end with 1 are counted twice, so subtract:
    - both start and end with 1: 10^(n - 2) possibilities for n >= 2

    This simplifies to:
    - n == 1: only the number 1 -> 1
    - n >= 2: 18 * 10^(n - 2)
    """
    if n <= 0:
        raise ValueError("n must be a positive integer")

    if n == 1:
        return 1

    return 18 * (10 ** (n - 2))
candidate = starts_one_ends


class Test(unittest.TestCase):
    def test(self):
        assert candidate(12) == 180000000000
        assert candidate(2) == 18
        assert candidate(14) == 18000000000000
        assert candidate(3) == 180
        assert candidate(19) == 1800000000000000000
        assert candidate(1) == 1
        assert candidate(8) == 18000000
        assert candidate(13) == 1800000000000
        assert candidate(16) == 1800000000000000
        assert candidate(11) == 18000000000
        assert candidate(17) == 18000000000000000
        assert candidate(4) == 1800
        assert candidate(20) == 18000000000000000000
        assert candidate(9) == 180000000
        assert candidate(6) == 180000
        assert candidate(15) == 180000000000000
        assert candidate(5) == 18000
        assert candidate(18) == 180000000000000000
        assert candidate(5) == 18000

    # Check some edge cases that are easy to work out by hand.
        assert candidate(7) == 1800000
        assert candidate(10) == 1800000000

if __name__ == '__main__':
    unittest.main()
