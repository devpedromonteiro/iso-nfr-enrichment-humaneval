
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math
from typing import List


def poly(xs: List[float], x: float) -> float:
    """
    Evaluate a polynomial with coefficients ``xs`` at point ``x``.

    The polynomial is interpreted as:
        xs[0] + xs[1] * x + xs[2] * x^2 + ... + xs[n] * x^n
    """
    return sum(coeff * math.pow(x, i) for i, coeff in enumerate(xs))


def find_zero(xs: List[float]) -> float:
    """
    Find one real zero of a polynomial given by coefficients ``xs``.

    Assumptions:
    - ``xs`` has an even number of coefficients
    - the highest-degree coefficient is non-zero

    Under these assumptions, the polynomial has odd degree, so it is
    guaranteed to have at least one real root.

    The function returns one such root.

    >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2)  # (x - 1)(x - 2)(x - 3)
    1.0
    """
    def f(x: float) -> float:
        return poly(xs, x)

    # First find an interval [left, right] where the polynomial changes sign.
    left, right = -1.0, 1.0
    f_left, f_right = f(left), f(right)

    while f_left * f_right > 0:
        left *= 2
        right *= 2
        f_left, f_right = f(left), f(right)

    # Binary search on the sign-changing interval.
    for _ in range(100):
        mid = (left + right) / 2
        f_mid = f(mid)

        if abs(f_mid) < 1e-12:
            return mid

        if f_left * f_mid <= 0:
            right = mid
            f_right = f_mid
        else:
            left = mid
            f_left = f_mid

    return (left + right) / 2
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
