
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    You are given a positive integer n. You have to create an integer array a of length n.
        For each i (1 â¤ i â¤ n), the value of a[i] = i * i - i + 1.
        Return the number of triples (a[i], a[j], a[k]) of a where i < j < k,
    and a[i] + a[j] + a[k] is a multiple of 3.

    Example :
        Input: n = 5
        Output: 1
        Explanation:
        a = [1, 3, 7, 13, 21]
        The only valid triple is (1, 7, 13).
    """
    # Observe:
    # a[i] = i^2 - i + 1 = i(i - 1) + 1
    # Since i(i - 1) is always divisible by 2, but we care about mod 3:
    #
    # Check i mod 3:
    # i â¡ 0 -> a[i] â¡ 1 (mod 3)
    # i â¡ 1 -> a[i] â¡ 1 (mod 3)
    # i â¡ 2 -> a[i] â¡ 0 (mod 3)
    #
    # So values in the array are only of two residue types modulo 3:
    #   count0 = number of terms divisible by 3
    #   count1 = number of terms congruent to 1 mod 3
    #
    # A triple sum is divisible by 3 only in these cases:
    #   0 + 0 + 0 = 0
    #   1 + 1 + 1 = 3 â¡ 0
    #
    # Therefore answer = C(count0, 3) + C(count1, 3)

    def comb3(x):
        return x * (x - 1) * (x - 2) // 6 if x >= 3 else 0

    # Indices i with i % 3 == 2 give a[i] % 3 == 0
    count0 = n // 3 + (1 if n % 3 >= 2 else 0)

    # Remaining indices give a[i] % 3 == 1
    count1 = n - count0

    return comb3(count0) + comb3(count1)
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
