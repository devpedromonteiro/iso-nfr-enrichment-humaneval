
import unittest
import re
import sys
import math
import copy


from math import factorial
from functools import reduce
from operator import mul


def special_factorial(n):
    """Return the Brazilian factorial of n.

    The Brazilian factorial is defined as:
        n! * (n-1)! * (n-2)! * ... * 1!

    Example:
        >>> special_factorial(4)
        288
    """
    return reduce(mul, (factorial(i) for i in range(1, n + 1)), 1)
candidate = special_factorial


def check(candidate):

    # Check some simple cases
    assert candidate(4) == 288, "Test 4"
    assert candidate(5) == 34560, "Test 5"
    assert candidate(7) == 125411328000, "Test 7"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1) == 1, "Test 1"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
