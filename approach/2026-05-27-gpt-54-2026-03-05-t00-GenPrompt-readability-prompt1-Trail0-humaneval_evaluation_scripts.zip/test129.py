
import unittest
import re
import sys
import math
import copy


from functools import lru_cache

def minPath(grid, k):
    """
    Return the lexicographically smallest valid path of length k.

    A path:
    - starts at any cell
    - moves only up/down/left/right
    - visits exactly k cells
    - may revisit cells

    Since every value from 1..N^2 appears exactly once, the smallest possible
    first value is always preferred. After fixing the current cell, the rest of
    the answer is simply the smallest path of length `remaining` starting there.
    """

    n = len(grid)

    # Map each value to its position for quick lookup.
    value_to_pos = {}
    for r in range(n):
        for c in range(n):
            value_to_pos[grid[r][c]] = (r, c)

    def neighbors(r, c):
        """Yield valid 4-directional neighbors of (r, c)."""
        if r > 0:
            yield r - 1, c
        if r + 1 < n:
            yield r + 1, c
        if c > 0:
            yield r, c - 1
        if c + 1 < n:
            yield r, c + 1

    @lru_cache(None)
    def best_from(r, c, length):
        """
        Return the lexicographically smallest tuple of values for a path
        of given length starting from cell (r, c).
        """
        current = grid[r][c]

        if length == 1:
            return (current,)

        best_suffix = min(
            best_from(nr, nc, length - 1)
            for nr, nc in neighbors(r, c)
        )
        return (current,) + best_suffix

    # Because values are unique and lexicographic order compares from left to right,
    # the optimal path must start at the globally smallest value.
    start_r, start_c = value_to_pos[1]
    return list(best_from(start_r, start_c, k))
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
