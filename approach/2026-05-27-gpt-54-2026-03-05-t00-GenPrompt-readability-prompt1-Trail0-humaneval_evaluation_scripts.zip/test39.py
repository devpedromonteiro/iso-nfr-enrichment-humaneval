
import unittest
import re
import sys
import math
import copy



def prime_fib(n: int) -> int:
    """
    Return the n-th Fibonacci number that is also prime.

    The prime Fibonacci sequence begins:
    2, 3, 5, 13, 89, 233, ...

    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """
    if n < 1:
        raise ValueError("n must be a positive integer")

    def is_prime(num: int) -> bool:
        """Return True if num is prime, otherwise False."""
        if num < 2:
            return False
        if num == 2:
            return True
        if num % 2 == 0:
            return False

        divisor = 3
        while divisor * divisor <= num:
            if num % divisor == 0:
                return False
            divisor += 2
        return True

    count = 0
    a, b = 0, 1

    while True:
        a, b = b, a + b  # next Fibonacci number
        if is_prime(a):
            count += 1
            if count == n:
                return a
candidate = prime_fib




METADATA = {}


def check(candidate):
    assert candidate(1) == 2
    assert candidate(2) == 3
    assert candidate(3) == 5
    assert candidate(4) == 13
    assert candidate(5) == 89
    assert candidate(6) == 233
    assert candidate(7) == 1597
    assert candidate(8) == 28657
    assert candidate(9) == 514229
    assert candidate(10) == 433494437



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
