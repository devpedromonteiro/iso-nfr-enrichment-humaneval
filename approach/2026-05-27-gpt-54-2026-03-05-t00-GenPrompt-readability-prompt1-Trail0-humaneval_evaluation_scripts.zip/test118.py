
import unittest
import re
import sys
import math
import copy


def get_closest_vowel(word):
    """Return the rightmost vowel that is between two consonants.

    A vowel counts only if:
    - it is not at the beginning or end of the word
    - the characters immediately on both sides are consonants

    The function is case sensitive and assumes English letters only.
    """
    vowels = "aeiouAEIOU"

    if len(word) < 3:
        return ""

    for index in range(len(word) - 2, 0, -1):
        current_char = word[index]
        left_char = word[index - 1]
        right_char = word[index + 1]

        if (
            current_char in vowels
            and left_char not in vowels
            and right_char not in vowels
        ):
            return current_char

    return ""
candidate = get_closest_vowel


def check(candidate):

    # Check some simple cases
    assert candidate("yogurt") == "u"
    assert candidate("full") == "u"
    assert candidate("easy") == ""
    assert candidate("eAsy") == ""
    assert candidate("ali") == ""
    assert candidate("bad") == "a"
    assert candidate("most") == "o"
    assert candidate("ab") == ""
    assert candidate("ba") == ""
    assert candidate("quick") == ""
    assert candidate("anime") == "i"
    assert candidate("Asia") == ""
    assert candidate("Above") == "o"

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
