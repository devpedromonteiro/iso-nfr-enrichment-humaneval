
import unittest


def match_parens(lst):
    '''
    You are given a list of two strings, both strings consist of open
    parentheses '(' or close parentheses ')' only.
    Your job is to check if it is possible to concatenate the two strings in
    some order, that the resulting string will be good.
    A string S is considered to be good if and only if all parentheses in S
    are balanced. For example: the string '(())()' is good, while the string
    '())' is not.
    Return 'Yes' if there's a way to make a good string, and return 'No' otherwise.

    Examples:
    match_parens(['()(', ')']) == 'Yes'
    match_parens([')', ')']) == 'No'
    '''
    if not isinstance(lst, list):
        raise TypeError("lst must be a list of exactly two strings")

    if len(lst) != 2:
        raise ValueError("lst must contain exactly two strings")

    if not all(isinstance(item, str) for item in lst):
        raise TypeError("both elements of lst must be strings")

    for item in lst:
        if any(ch not in '()' for ch in item):
            raise ValueError("strings must contain only '(' and ')' characters")

    def is_good(s):
        balance = 0
        for ch in s:
            if ch == '(':
                balance += 1
            elif ch == ')':
                balance -= 1
            else:
                # Defensive check; should never happen due to earlier validation
                raise ValueError("encountered invalid character while processing")
            if balance < 0:
                return False
        return balance == 0

    first, second = lst

    if is_good(first + second) or is_good(second + first):
        return 'Yes'
    return 'No'
candidate = match_parens


class Test(unittest.TestCase):
    def test(self):
        assert candidate((')())', '(()()(')) == 'Yes'
        assert candidate(('((((', ')')) == 'No'
        assert candidate(('()(', '())')) == 'Yes'
        assert candidate(('())', '((((')) == 'No'
        assert candidate(('(()(', '()(')) == 'No'
        assert candidate(('())', '(()()(')) == 'No'
        assert candidate([')', ')']) == 'No'
        assert candidate(('()(', ')')) == 'Yes'
        assert candidate(('(()(())', '()(')) == 'No'
        assert candidate(('(()()(', '())())')) == 'Yes'
        assert candidate(('())', ')())')) == 'No'
        assert candidate(('((((', '((((')) == 'No'
        assert candidate((')(', '(()()(')) == 'No'
        assert candidate((')())', ')())')) == 'No'
        assert candidate((')())', '((())')) == 'No'
        assert candidate(('()', '()(')) == 'No'
        assert candidate(('(()(())', '())())')) == 'No'
        assert candidate(('(', ')')) == 'Yes'
        assert candidate(('(())))', '()(')) == 'No'
        assert candidate(('()', '(()())((')) == 'No'
        assert candidate(('())())', '()(')) == 'No'
        assert candidate(('())())', '(()()(')) == 'Yes'
        assert candidate(('()(', '())())')) == 'No'
        assert candidate(('()))()', '())')) == 'No'
        assert candidate(('(())))', '((())')) == 'No'
        assert candidate(['()', '())']) == 'No'
        assert candidate(['(())))', '(()())((']) == 'Yes'
        assert candidate((')', '(())))')) == 'No'
        assert candidate([')())', '(()()(']) == 'Yes'
        assert candidate(('(()()(', '(()()(')) == 'No'
        assert candidate((')', '(()(())')) == 'Yes'
        assert candidate([')(()', '(()(']) == 'No'
        assert candidate(('(()(())', ')')) == 'Yes'
        assert candidate((')(', '()(')) == 'No'
        assert candidate(('(()()(', ')(()')) == 'No'
        assert candidate(('()(', '(()(())')) == 'No'
        assert candidate((')', '()(')) == 'Yes'
        assert candidate(('())', ')')) == 'No'
        assert candidate(('(()())((', '(()(())')) == 'No'
        assert candidate(('(()(', ')(()')) == 'No'
        assert candidate(('())())', ')())')) == 'No'
        assert candidate(('())', ')(')) == 'No'
        assert candidate(('(()(())', ')(')) == 'No'
        assert candidate(('()', '())')) == 'No'
        assert candidate((')())', '()(')) == 'No'
        assert candidate([')(', ')(']) == 'No'
    

    # Check some edge cases that are easy to work out by hand.
        assert candidate(('(()(', '(()())((')) == 'No'
        assert candidate((')', '(()()(')) == 'No'
        assert candidate(('()(', '(()())((')) == 'No'
        assert candidate(('((())', '(()(')) == 'No'
        assert candidate((')', '())())')) == 'No'
        assert candidate(('()(', '()(')) == 'No'
        assert candidate(['()(', ')']) == 'Yes'
        assert candidate(('(()()(', '(()(())')) == 'No'
        assert candidate(('())())', '()')) == 'No'
        assert candidate(('(()(())', '())')) == 'Yes'
        assert candidate(['(()(', '()))()']) == 'Yes'
        assert candidate(('(()(', '(()(')) == 'No'
        assert candidate(('(())))', '(())))')) == 'No'
        assert candidate(('()(', '(()(')) == 'No'
        assert candidate(('(', '(()())((')) == 'No'
        assert candidate(['(', ')']) == 'Yes'
        assert candidate(['((((', '((())']) == 'No'
        assert candidate(('())())', '(()(())')) == 'No'
        assert candidate(('())', '()')) == 'No'
        assert candidate(('(', '()))()')) == 'No'
        assert candidate(('())())', '(()(')) == 'Yes'
        assert candidate(('(()(())', ')())')) == 'No'
        assert candidate(('((((', '()')) == 'No'
        assert candidate((')())', '(())))')) == 'No'
        assert candidate(('(()())((', ')')) == 'No'
        assert candidate(('()(', ')())')) == 'No'
        assert candidate(('())', '()(')) == 'Yes'
        assert candidate(('()', '(()(())')) == 'No'
        assert candidate((')(()', '(())))')) == 'No'
        assert candidate(('(()()(', '()(')) == 'No'
        assert candidate(('())())', ')')) == 'No'
        assert candidate(['(()(())', '())())']) == 'No'
        assert candidate((')', ')')) == 'No'
        assert candidate(('())())', ')(()')) == 'No'
        assert candidate(('()))()', '(()(')) == 'Yes'
        assert candidate((')())', '((((')) == 'No'
        assert candidate(('(()(())', '(()()(')) == 'No'
        assert candidate(('()', ')())')) == 'No'
        assert candidate(('(())))', '(()()(')) == 'Yes'
        assert candidate((')(', ')(()')) == 'No'
        assert candidate(('(()()(', '(())))')) == 'Yes'
        assert candidate(('(())))', '(()(())')) == 'No'
        assert candidate(('((((', '(()(')) == 'No'
        assert candidate([')', '(']) == 'Yes'
        assert candidate((')(()', '())')) == 'No'
        assert candidate((')())', '())())')) == 'No'

if __name__ == '__main__':
    unittest.main()
