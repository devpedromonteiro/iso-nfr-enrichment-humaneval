
import unittest


def strange_sort_list(lst):
    '''
    Given list of integers, return list in strange order.
    Strange sorting, is when you start with the minimum value,
    then maximum of the remaining integers, then minimum and so on.

    Examples:
    strange_sort_list([1, 2, 3, 4]) == [1, 4, 2, 3]
    strange_sort_list([5, 5, 5, 5]) == [5, 5, 5, 5]
    strange_sort_list([]) == []
    '''
    if lst is None:
        raise TypeError("lst must be a list of integers, got None")

    if not isinstance(lst, list):
        raise TypeError(f"lst must be of type list, got {type(lst).__name__}")

    for i, value in enumerate(lst):
        if not isinstance(value, int):
            raise TypeError(
                f"all elements must be integers; found {type(value).__name__} at index {i}"
            )

    if not lst:
        return []

    sorted_lst = sorted(lst)
    result = []

    left = 0
    right = len(sorted_lst) - 1

    while left <= right:
        result.append(sorted_lst[left])
        left += 1

        if left <= right:
            result.append(sorted_lst[right])
            right -= 1

    return result
candidate = strange_sort_list


class Test(unittest.TestCase):
    def test(self):
        assert candidate([5, 1, 6, 3, 2]) == [1, 6, 2, 5, 3]
        assert candidate([1, 2, 1, 3, 5, 8, -8, -4]) == [-8, 8, -4, 5, 1, 3, 1, 2]
        assert candidate([8, 8, 8, 6, 12, 5]) == [5, 12, 6, 8, 8, 8]
        assert candidate([5, 6, 4, 6, 6]) == [4, 6, 5, 6, 6]
        assert candidate([9, 3, 5, 7]) == [3, 9, 5, 7]
        assert candidate([6, 6, 2, 12, 13]) == [2, 13, 6, 12, 6]
        assert candidate([3, 2, 4, 9, 9, 6, 7, 4]) == [2, 9, 3, 9, 4, 7, 4, 6]
        assert candidate([1, 11, 9, 10, 9]) == [1, 11, 9, 10, 9]
        assert candidate([4, 4, 5, 1, 4]) == [1, 5, 4, 4, 4]
        assert candidate([6, 3, 1, 6, 10]) == [1, 10, 3, 6, 6]
        assert candidate([2, 5, 3, 4, 9, 11, 2, 3]) == [2, 11, 2, 9, 3, 5, 3, 4]
        assert candidate([9, 8, 5, 2]) == [2, 9, 5, 8]
        assert candidate([5, 2, 7, 5, 2, 4, -3, -1]) == [-3, 7, -1, 5, 2, 5, 2, 4]
        assert candidate([6, 2, 5, 5]) == [2, 6, 5, 5]
        assert candidate([10, 10, 2, 11, 10]) == [2, 11, 10, 10, 10]
        assert candidate([5, 9, 4, 2]) == [2, 9, 4, 5]
        assert candidate([1,2,3,4,5,6,7,8]) == [1, 8, 2, 7, 3, 6, 4, 5]
        assert candidate([5, 2, 2, 1]) == [1, 5, 2, 2]
        assert candidate([8, 2, 9, 9]) == [2, 9, 8, 9]
        assert candidate([2, 2, 6, 8, 6]) == [2, 8, 2, 6, 6]
        assert candidate([2, 1, 8, 9, 2, 4, 8, 6]) == [1, 9, 2, 8, 2, 8, 4, 6]
        assert candidate([]) == []
        assert candidate([6, 2, 1, 4]) == [1, 6, 2, 4]
        assert candidate([7, 2, 5, 8, 7, 2]) == [2, 8, 2, 7, 5, 7]
        assert candidate([3, 4, 1, 7, 4, 6, 3, 12]) == [1, 12, 3, 7, 3, 6, 4, 4]
        assert candidate([4, 4, 8, 8]) == [4, 8, 4, 8]
        assert candidate([111111]) == [111111]

    # Check some edge cases that are easy to work out by hand.
        assert candidate([8, 4, 9, 7]) == [4, 9, 7, 8]
        assert candidate([5, 6, 7, 8, 9, 1]) == [1, 9, 5, 8, 6, 7]
        assert candidate([5, 6, 7, 8, 9]) == [5, 9, 6, 8, 7]
        assert candidate([1, 6, 6, 3]) == [1, 6, 3, 6]
        assert candidate([1, 6, 5, 7, 3, 2, -7, -6]) == [-7, 7, -6, 6, 1, 5, 2, 3]
        assert candidate([4, 8, 10, 4, 4]) == [4, 10, 4, 8, 4]
        assert candidate([6, 4, 4, 8]) == [4, 8, 4, 6]
        assert candidate([3, 1, 3, 4, 10, 3, 9, 5]) == [1, 10, 3, 9, 3, 5, 3, 4]
        assert candidate([4, 6, 4, 7, 7, 3, -1, -7]) == [-7, 7, -1, 7, 3, 6, 4, 4]
        assert candidate([2, 6, 4, 2, 9, 5, -1, -6]) == [-6, 9, -1, 6, 2, 5, 2, 4]
        assert candidate([1, 5, 7, 3, 8, 6]) == [1, 8, 3, 7, 5, 6]
        assert candidate([3, 7, 1, 7, 4]) == [1, 7, 3, 7, 4]
        assert candidate([4, 7, 6, 6, 1, 4, -2, -5]) == [-5, 7, -2, 6, 1, 6, 4, 4]
        assert candidate([9, 3, 2, 5, 14]) == [2, 14, 3, 9, 5]
        assert candidate([4, 10, 10, 4, 13]) == [4, 13, 4, 10, 10]
        assert candidate([2, 4, 3, 4]) == [2, 4, 3, 4]
        assert candidate([1, 1, 6, 7, 14]) == [1, 14, 1, 7, 6]
        assert candidate([3, 5, 7, 8, 5]) == [3, 8, 5, 7, 5]
        assert candidate([5, 1, 7, 5, 8]) == [1, 8, 5, 7, 5]
        assert candidate([5, 6, 8, 1, 3, 1, 10, 5]) == [1, 10, 1, 8, 3, 6, 5, 5]
        assert candidate([10, 4, 7, 9]) == [4, 10, 7, 9]
        assert candidate([6, 2, 7, 5]) == [2, 7, 5, 6]
        assert candidate([5, 4, 5, 1, 7, 2, -3, -8]) == [-8, 7, -3, 5, 1, 5, 2, 4]
        assert candidate([1, 3, 7, 3, 9, 11, 4, 6]) == [1, 11, 3, 9, 3, 7, 4, 6]
        assert candidate([2, 3, 2, 2, 7, 7, 2, 7]) == [2, 7, 2, 7, 2, 7, 2, 3]
        assert candidate([3, 1, 3, 4]) == [1, 4, 3, 3]
        assert candidate([1, 1, 3, 6, 3, 10, -6, -1]) == [-6, 10, -1, 6, 1, 3, 1, 3]
        assert candidate([2, 3, 7, 5, 4, 10, -6, -9]) == [-9, 10, -6, 7, 2, 5, 3, 4]
        assert candidate([5, 4, 2, 5, 12, 5]) == [2, 12, 4, 5, 5, 5]
        assert candidate([1, 4, 1, 4, 8]) == [1, 8, 1, 4, 4]
        assert candidate([1, 2, 7, 3]) == [1, 7, 2, 3]
        assert candidate([1, 2, 3, 4]) == [1, 4, 2, 3]
        assert candidate([3, 4, 3, 7, 9]) == [3, 9, 3, 7, 4]
        assert candidate([9, 3, 9, 1]) == [1, 9, 3, 9]
        assert candidate([7, 9, 2, 6, 4]) == [2, 9, 4, 7, 6]
        assert candidate([2, 2, 4, 4, 7, 4]) == [2, 7, 2, 4, 4, 4]
        assert candidate([6, 7, 4, 5, 14, 5]) == [4, 14, 5, 7, 5, 6]
        assert candidate([7, 4, 2, 4, 14, 5]) == [2, 14, 4, 7, 4, 5]
        assert candidate([10, 11, 9, 6, 12]) == [6, 12, 9, 11, 10]
        assert candidate([4, 5, 2, 2]) == [2, 5, 2, 4]
        assert candidate([1, 1, 1, 2, 1]) == [1, 2, 1, 1, 1]
        assert candidate([5, 1, 7, 2, 10, 7, 5, 5]) == [1, 10, 2, 7, 5, 7, 5, 5]
        assert candidate([2, 3, 6, 3, 8, 3, 7, 4]) == [2, 8, 3, 7, 3, 6, 3, 4]
        assert candidate([4, 6, 1, 1]) == [1, 6, 1, 4]
        assert candidate([3, 1, 3, 6, 3, 10, 7, 13]) == [1, 13, 3, 10, 3, 7, 3, 6]
        assert candidate([1, 4, 5, 8]) == [1, 8, 4, 5]
        assert candidate([3, 2, 3, 2]) == [2, 3, 2, 3]
        assert candidate([4, 9, 7, 9]) == [4, 9, 7, 9]
        assert candidate([7, 1, 4, 13, 10]) == [1, 13, 4, 10, 7]
        assert candidate([2, 3, 6, 6]) == [2, 6, 3, 6]
        assert candidate([1, 3, 5, 4, 9, 1, -9, -10]) == [-10, 9, -9, 5, 1, 4, 1, 3]
        assert candidate([5, 5, 5, 8, 14]) == [5, 14, 5, 8, 5]
        assert candidate([8, 9, 2, 8]) == [2, 9, 8, 8]
        assert candidate([4, 4, 5, 11, 8, 4]) == [4, 11, 4, 8, 4, 5]
        assert candidate([2, 2, 5, 6, 6, 10, -4, -6]) == [-6, 10, -4, 6, 2, 6, 2, 5]
        assert candidate([1, 6, 12, 6, 9, 6]) == [1, 12, 6, 9, 6, 6]
        assert candidate([1, 1, 1, 5, 5, 9, -7, -8]) == [-8, 9, -7, 5, 1, 5, 1, 1]
        assert candidate([3, 4, 3, 5, 7]) == [3, 7, 3, 5, 4]
        assert candidate([3, 5, 2, 4, 3, 6, -3, 0]) == [-3, 6, 0, 5, 2, 4, 3, 3]
        assert candidate([8, 3, 9, 5, 5]) == [3, 9, 5, 8, 5]
        assert candidate([1, 4, 6, 5, 10, 7, 5, 3]) == [1, 10, 3, 7, 4, 6, 5, 5]
        assert candidate([4, 2, 9, 6, 5, 1]) == [1, 9, 2, 6, 4, 5]
        assert candidate([5, 5, 5, 6, 2]) == [2, 6, 5, 5, 5]
        assert candidate([1, 1, 6, 1, 4]) == [1, 6, 1, 4, 1]
        assert candidate([7, 2, 6, 11, 10]) == [2, 11, 6, 10, 7]
        assert candidate([4, 1, 8, 7, 9, 3, 12, 5]) == [1, 12, 3, 9, 4, 8, 5, 7]
        assert candidate([10, 7, 5, 3]) == [3, 10, 5, 7]
        assert candidate([1, 2, 3, 4, 5]) == [1, 5, 2, 4, 3]
        assert candidate([5, 6, 6, 9]) == [5, 9, 6, 6]
        assert candidate([7, 8, 12, 11, 11, 5]) == [5, 12, 7, 11, 8, 11]
        assert candidate([2, 2, 4, 7, 2, 6, 6, 3]) == [2, 7, 2, 6, 2, 6, 3, 4]
        assert candidate([5, 5, 5, 5]) == [5, 5, 5, 5]
        assert candidate([8, 6, 12, 4, 4, 4]) == [4, 12, 4, 8, 4, 6]
        assert candidate([0,2,2,2,5,5,-5,-5]) == [-5, 5, -5, 5, 0, 2, 2, 2]
        assert candidate([6, 2, 5, 1]) == [1, 6, 2, 5]
        assert candidate([1, 7, 9, 11, 4]) == [1, 11, 4, 9, 7]
        assert candidate([2, 7, 12, 13, 8, 2]) == [2, 13, 2, 12, 7, 8]
        assert candidate([4, 7, 7, 1, 10, 3, 0, -6]) == [-6, 10, 0, 7, 1, 7, 3, 4]
        assert candidate([4, 9, 6, 8, 11, 3]) == [3, 11, 4, 9, 6, 8]
        assert candidate([4, 3, 1, 6]) == [1, 6, 3, 4]

if __name__ == '__main__':
    unittest.main()
