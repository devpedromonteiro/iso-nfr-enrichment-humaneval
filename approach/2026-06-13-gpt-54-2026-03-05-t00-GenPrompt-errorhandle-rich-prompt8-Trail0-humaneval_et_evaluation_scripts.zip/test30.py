
import unittest



def get_positive(l: list):
    """Return only positive numbers in the list.

    >>> get_positive([-1, 2, -4, 5, 6])
    [2, 5, 6]
    >>> get_positive([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    [5, 3, 2, 3, 9, 123, 1]
    """
    if not isinstance(l, list):
        raise TypeError("l must be a list")

    result = []
    for i, value in enumerate(l):
        if not isinstance(value, (int, float)):
            raise TypeError(f"list element at index {i} must be a number")
        if value > 0:
            result.append(value)

    return result
candidate = get_positive


class Test(unittest.TestCase):
    def test(self):
        assert candidate([-1, -2]) == []
        assert candidate([2, 0]) == [2]
        assert candidate([3, -2]) == [3]
        assert candidate([6, 5, -10, 6, 8, 7, 7, 5, 124, 2, -7]) == [6, 5, 6, 8, 7, 7, 5, 124, 2]
        assert candidate([]) == []
        assert candidate([3, 1]) == [3, 1]
        assert candidate([7, 8, -9, 5, 7, 7, 13, 1, 121, 4, -13]) == [7, 8, 5, 7, 7, 13, 1, 121, 4]
        assert candidate([3, 0, 9, 9, 1]) == [3, 9, 9, 1]
        assert candidate([2, 4, -1, 6, 8, 8, 14, 3, 128, 5, -12]) == [2, 4, 6, 8, 8, 14, 3, 128, 5]
        assert candidate([5, 3, -5, 2, 3, 3, 9, 0, 123, 1, -10]) == [5, 3, 2, 3, 3, 9, 123, 1]
        assert candidate([-4, -4]) == []
        assert candidate([-1, -3, 9, 6, 2]) == [9, 6, 2]
        assert candidate([-2, 3]) == [3]
        assert candidate([1, 5, -2, 1, 3, 6, 4, 5, 124, 1, -5]) == [1, 5, 1, 3, 6, 4, 5, 124, 1]
        assert candidate([-2, -3]) == []
        assert candidate([-6, 1, 6, 9, 10]) == [1, 6, 9, 10]
        assert candidate([3, 3, 6, 8, 2]) == [3, 3, 6, 8, 2]
        assert candidate([6, 2, -8, 4, 6, 8, 8, 3, 122, 1, -9]) == [6, 2, 4, 6, 8, 8, 3, 122, 1]
        assert candidate([3, 4, -2, 5, 3, 8, 6, 2, 128, 2, -13]) == [3, 4, 5, 3, 8, 6, 2, 128, 2]
        assert candidate([2, 3, -1, 3, 2, 2, 4, 2, 123, 4, -12]) == [2, 3, 3, 2, 2, 4, 2, 123, 4]
        assert candidate([-5, -5]) == []
        assert candidate([6, 3, -5, 2, 5, 7, 4, 4, 128, 4, -14]) == [6, 3, 2, 5, 7, 4, 4, 128, 4]
        assert candidate([1, -6]) == [1]
        assert candidate([3, -1, 7, 7, 9]) == [3, 7, 7, 9]
        assert candidate([-3, -1]) == []
        assert candidate([-1, -6]) == []
        assert candidate([8, 5, -10, 3, 1, 2, 13, 4, 119, 1, -6]) == [8, 5, 3, 1, 2, 13, 4, 119, 1]
        assert candidate([2, -7, 8, 3, 10]) == [2, 8, 3, 10]
        assert candidate([7, 1, -3, 3, 1, 7, 7, 4, 118, 5, -5]) == [7, 1, 3, 1, 7, 7, 4, 118, 5]
        assert candidate([6, 1, -6, 2, 5, 8, 13, 5, 128, 2, -10]) == [6, 1, 2, 5, 8, 13, 5, 128, 2]
        assert candidate([-3, -3]) == []
        assert candidate([2, -4, 5, 4, 10]) == [2, 5, 4, 10]
        assert candidate([-4, 0, 2, 5, 5]) == [2, 5, 5]
        assert candidate([3, 0]) == [3]
        assert candidate([2, 2, -1, 6, 5, 6, 13, 4, 126, 2, -8]) == [2, 2, 6, 5, 6, 13, 4, 126, 2]
        assert candidate([6, 8, -8, 2, 5, 2, 6, 5, 125, 6, -12]) == [6, 8, 2, 5, 2, 6, 5, 125, 6]
        assert candidate([-5, -7]) == []
        assert candidate([-4, 1, 3, 2, 10]) == [1, 3, 2, 10]
        assert candidate([7, 6, -6, 1, 7, 5, 13, 3, 127, 4, -8]) == [7, 6, 1, 7, 5, 13, 3, 127, 4]
        assert candidate([1, -4, 9, 3, 9]) == [1, 9, 3, 9]
        assert candidate([3, 1, 3, 4, 3]) == [3, 1, 3, 4, 3]
        assert candidate([5, 5, -7, 6, 1, 7, 9, 4, 123, 6, -13]) == [5, 5, 6, 1, 7, 9, 4, 123, 6]
        assert candidate([9, 3, -10, 4, 4, 3, 12, 5, 122, 2, -7]) == [9, 3, 4, 4, 3, 12, 5, 122, 2]
        assert candidate([8, 5, -6, 1, 3, 3, 6, 3, 128, 5, -5]) == [8, 5, 1, 3, 3, 6, 3, 128, 5]
        assert candidate([5, 6, -7, 1, 6, 6, 11, 5, 124, 2, -15]) == [5, 6, 1, 6, 6, 11, 5, 124, 2]
        assert candidate([1, 3, -9, 5, 5, 3, 4, 1, 124, 2, -12]) == [1, 3, 5, 5, 3, 4, 1, 124, 2]
        assert candidate([3, 3, 8, 7, 8]) == [3, 3, 8, 7, 8]
        assert candidate([-4, 2]) == [2]
        assert candidate([6, 1, -9, 1, 6, 8, 5, 5, 126, 5, -7]) == [6, 1, 1, 6, 8, 5, 5, 126, 5]
        assert candidate([-4, -2]) == []
        assert candidate([2, 3, -9, 4, 5, 4, 10, 2, 118, 3, -14]) == [2, 3, 4, 5, 4, 10, 2, 118, 3]
        assert candidate([1, 5, -6, 1, 8, 2, 10, 3, 122, 2, -15]) == [1, 5, 1, 8, 2, 10, 3, 122, 2]
        assert candidate([0, -4]) == []
        assert candidate([-6, -1, 8, 8, 5]) == [8, 8, 5]
        assert candidate([-2, -4]) == []
        assert candidate([-6, -3]) == []
        assert candidate([-3, -2, 3, 9, 4]) == [3, 9, 4]
        assert candidate([7, 4, -8, 1, 2, 7, 14, 2, 126, 5, -15]) == [7, 4, 1, 2, 7, 14, 2, 126, 5]
        assert candidate([-3, -1, 5, 2, 6]) == [5, 2, 6]
        assert candidate([-3, -7, 3, 5, 8]) == [3, 5, 8]
        assert candidate([0, 1, 5, 7, 5]) == [1, 5, 7, 5]
        assert candidate([3, -1, 8, 7, 5]) == [3, 8, 7, 5]
        assert candidate([3, 1, 3, 8, 11]) == [3, 1, 3, 8, 11]
        assert candidate([4, -4]) == [4]
        assert candidate([-2, -3, 1, 6, 2]) == [1, 6, 2]
        assert candidate([1, 2, -9, 4, 3, 4, 5, 2, 127, 5, -14]) == [1, 2, 4, 3, 4, 5, 2, 127, 5]
        assert candidate([10, 5, -1, 3, 3, 2, 4, 3, 121, 4, -11]) == [10, 5, 3, 3, 2, 4, 3, 121, 4]
        assert candidate([3, 1, 1, 1, 7]) == [3, 1, 1, 1, 7]
        assert candidate([4, -2, 3, 2, 11]) == [4, 3, 2, 11]
        assert candidate([-2, 1, 8, 8, 6]) == [1, 8, 8, 6]
        assert candidate([-5, 1, 3, 10, 3]) == [1, 3, 10, 3]
        assert candidate([6, 8, -5, 7, 4, 3, 7, 2, 128, 2, -12]) == [6, 8, 7, 4, 3, 7, 2, 128, 2]
        assert candidate([-4, -2, 6, 2, 4]) == [6, 2, 4]
        assert candidate([6, 6, -10, 7, 2, 7, 12, 1, 126, 2, -5]) == [6, 6, 7, 2, 7, 12, 1, 126, 2]
        assert candidate([5, 3, -10, 6, 7, 7, 4, 1, 124, 5, -14]) == [5, 3, 6, 7, 7, 4, 1, 124, 5]
        assert candidate([4, -3, 9, 7, 11]) == [4, 9, 7, 11]
        assert candidate([-2, -2]) == []
        assert candidate([0, -4, 1, 2, 3]) == [1, 2, 3]
        assert candidate([-2, -5]) == []
        assert candidate([-3, -6]) == []
        assert candidate([-3, 0, 4, 6, 6]) == [4, 6, 6]
        assert candidate([-1, 2]) == [2]
        assert candidate([-1, -2, 4, 5, 6]) == [4, 5, 6]
        assert candidate([1, -2]) == [1]
        assert candidate([2, 2, 7, 4, 3]) == [2, 2, 7, 4, 3]
        assert candidate([3, 8, -10, 1, 1, 1, 12, 2, 125, 6, -9]) == [3, 8, 1, 1, 1, 12, 2, 125, 6]
        assert candidate([1, 1]) == [1, 1]
        assert candidate([-1, 2, 7, 10, 3]) == [2, 7, 10, 3]
        assert candidate([4, 8, -8, 1, 6, 1, 14, 4, 122, 3, -7]) == [4, 8, 1, 6, 1, 14, 4, 122, 3]
        assert candidate([4, -1, 9, 8, 9]) == [4, 9, 8, 9]
        assert candidate([-3, 0]) == []
        assert candidate([6, 7, -9, 6, 3, 2, 14, 1, 124, 3, -15]) == [6, 7, 6, 3, 2, 14, 1, 124, 3]
        assert candidate([7, 6, -8, 4, 3, 5, 7, 4, 128, 2, -13]) == [7, 6, 4, 3, 5, 7, 4, 128, 2]
        assert candidate([1, 3, 1, 9, 2]) == [1, 3, 1, 9, 2]
        assert candidate([2, 2]) == [2, 2]
        assert candidate([1, -5]) == [1]

if __name__ == '__main__':
    unittest.main()
