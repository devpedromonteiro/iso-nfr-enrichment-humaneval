
import unittest
import re
import sys
import math
import copy


from math import gcd


def simplify(fraction_a, fraction_b):
    """
    Return True if the product of two fractions is a whole number, otherwise False.

    Each input must be a string in the format "numerator/denominator".
    """

    numerator_a, denominator_a = parse_fraction(fraction_a)
    numerator_b, denominator_b = parse_fraction(fraction_b)

    product_numerator = numerator_a * numerator_b
    product_denominator = denominator_a * denominator_b

    greatest_common_divisor = gcd(product_numerator, product_denominator)
    simplified_denominator = product_denominator // greatest_common_divisor

    return simplified_denominator == 1


def parse_fraction(fraction_text):
    """Convert a fraction string like '3/4' into a pair of integers."""
    numerator_text, denominator_text = fraction_text.split("/")
    numerator = int(numerator_text)
    denominator = int(denominator_text)
    return numerator, denominator
candidate = simplify


def check(candidate):

    # Check some simple cases
    assert candidate("1/5", "5/1") == True, 'test1'
    assert candidate("1/6", "2/1") == False, 'test2'
    assert candidate("5/1", "3/1") == True, 'test3'
    assert candidate("7/10", "10/2") == False, 'test4'
    assert candidate("2/10", "50/10") == True, 'test5'
    assert candidate("7/2", "4/2") == True, 'test6'
    assert candidate("11/6", "6/1") == True, 'test7'
    assert candidate("2/3", "5/2") == False, 'test8'
    assert candidate("5/2", "3/5") == False, 'test9'
    assert candidate("2/4", "8/4") == True, 'test10'


    # Check some edge cases that are easy to work out by hand.
    assert candidate("2/4", "4/2") == True, 'test11'
    assert candidate("1/5", "5/1") == True, 'test12'
    assert candidate("1/5", "1/5") == False, 'test13'



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
