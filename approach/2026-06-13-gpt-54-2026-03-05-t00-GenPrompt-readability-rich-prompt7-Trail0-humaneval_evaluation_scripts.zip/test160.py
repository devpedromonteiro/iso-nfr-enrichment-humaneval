
import unittest
import re
import sys
import math
import copy


def do_algebra(operators, operands):
    """
    Evaluate an algebraic expression built from a list of operators and operands.

    The expression is formed by placing each operator between consecutive operands,
    preserving normal Python operator precedence.

    Supported operators:
        +   addition
        -   subtraction
        *   multiplication
        //  floor division
        **  exponentiation

    Example:
        operators = ['+', '*', '-']
        operands = [2, 3, 4, 5]

        Expression: 2 + 3 * 4 - 5
        Result: 9
    """
    expression_parts = [str(operands[0])]

    for index, operator_symbol in enumerate(operators):
        next_operand = operands[index + 1]
        expression_parts.append(operator_symbol)
        expression_parts.append(str(next_operand))

    expression = " ".join(expression_parts)
    return eval(expression)
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
