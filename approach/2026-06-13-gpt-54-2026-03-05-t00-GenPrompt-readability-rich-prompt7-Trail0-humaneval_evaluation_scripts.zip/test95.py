
import unittest
import re
import sys
import math
import copy


def check_dict_case(input_dict):
    """
    Return True if all dictionary keys are strings and are either all lowercase
    or all uppercase. Return False for an empty dictionary or if any key is not
    a string.

    Examples:
        check_dict_case({"a": "apple", "b": "banana"}) -> True
        check_dict_case({"a": "apple", "A": "banana", "B": "banana"}) -> False
        check_dict_case({"a": "apple", 8: "banana"}) -> False
        check_dict_case({"Name": "John", "Age": "36", "City": "Houston"}) -> False
        check_dict_case({"STATE": "NC", "ZIP": "12345"}) -> True
    """
    if not input_dict:
        return False

    keys = input_dict.keys()

    if not all(isinstance(key, str) for key in keys):
        return False

    all_lowercase = all(key.islower() for key in keys)
    all_uppercase = all(key.isupper() for key in keys)

    return all_lowercase or all_uppercase
candidate = check_dict_case


def check(candidate):

    # Check some simple cases
    assert candidate({"p":"pineapple", "b":"banana"}) == True, "First test error: " + str(candidate({"p":"pineapple", "b":"banana"}))
    assert candidate({"p":"pineapple", "A":"banana", "B":"banana"}) == False, "Second test error: " + str(candidate({"p":"pineapple", "A":"banana", "B":"banana"}))
    assert candidate({"p":"pineapple", 5:"banana", "a":"apple"}) == False, "Third test error: " + str(candidate({"p":"pineapple", 5:"banana", "a":"apple"}))
    assert candidate({"Name":"John", "Age":"36", "City":"Houston"}) == False, "Fourth test error: " + str(candidate({"Name":"John", "Age":"36", "City":"Houston"}))
    assert candidate({"STATE":"NC", "ZIP":"12345" }) == True, "Fifth test error: " + str(candidate({"STATE":"NC", "ZIP":"12345" }))      
    assert candidate({"fruit":"Orange", "taste":"Sweet" }) == True, "Fourth test error: " + str(candidate({"fruit":"Orange", "taste":"Sweet" }))      


    # Check some edge cases that are easy to work out by hand.
    assert candidate({}) == False, "1st edge test error: " + str(candidate({}))



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
