
import unittest
import re
import sys
import math
import copy


def factorial(number):
    """Return the factorial of a positive integer."""
    result = 1
    for value in range(1, number + 1):
        result *= value
    return result


def sum_from_one_to(number):
    """Return the sum of all integers from 1 to the given number."""
    return sum(range(1, number + 1))


def f(n):
    """Return a list of size n based on the position rules.

    For each position i starting from 1:
    - if i is even, store factorial(i)
    - if i is odd, store the sum of numbers from 1 to i

    Example:
        f(5) == [1, 2, 6, 24, 15]
    """
    values = []

    for index in range(1, n + 1):
        if index % 2 == 0:
            values.append(factorial(index))
        else:
            values.append(sum_from_one_to(index))

    return values
candidate = f


def check(candidate):

    assert candidate(5) == [1, 2, 6, 24, 15]
    assert candidate(7) == [1, 2, 6, 24, 15, 720, 28]
    assert candidate(1) == [1]
    assert candidate(3) == [1, 2, 6]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
