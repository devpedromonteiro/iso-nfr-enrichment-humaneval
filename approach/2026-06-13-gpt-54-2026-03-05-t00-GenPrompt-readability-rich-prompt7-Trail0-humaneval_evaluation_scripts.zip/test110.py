
import unittest
import re
import sys
import math
import copy


def exchange(first_list, second_list):
    """Return "YES" if first_list can be made all even by exchanging elements.

    Any number of exchanges is allowed between the two lists. Since exchanged
    elements can be chosen freely, first_list can end up containing any set of
    elements from the combined lists, as long as its length stays the same.

    Therefore, the task is possible if the total number of even numbers across
    both lists is at least the length of first_list.
    """
    required_even_count = len(first_list)

    total_even_count = 0
    for number in first_list:
        if number % 2 == 0:
            total_even_count += 1

    for number in second_list:
        if number % 2 == 0:
            total_even_count += 1

    if total_even_count >= required_even_count:
        return "YES"

    return "NO"
candidate = exchange


def check(candidate):

    # Check some simple cases
    assert candidate([1, 2, 3, 4], [1, 2, 3, 4]) == "YES"
    assert candidate([1, 2, 3, 4], [1, 5, 3, 4]) == "NO"
    assert candidate([1, 2, 3, 4], [2, 1, 4, 3]) == "YES" 
    assert candidate([5, 7, 3], [2, 6, 4]) == "YES"
    assert candidate([5, 7, 3], [2, 6, 3]) == "NO" 
    assert candidate([3, 2, 6, 1, 8, 9], [3, 5, 5, 1, 1, 1]) == "NO"

    # Check some edge cases that are easy to work out by hand.
    assert candidate([100, 200], [200, 200]) == "YES"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
