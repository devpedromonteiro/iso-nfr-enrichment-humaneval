
import unittest
import re
import sys
import math
import copy



def encode_shift(s: str):
    """
    returns encoded string by shifting every character by 5 in the alphabet.
    """
    return "".join([chr(((ord(ch) + 5 - ord("a")) % 26) + ord("a")) for ch in s])


def encode_shift(text: str) -> str:
    """
    Return a new string where each lowercase letter is shifted forward by 5.

    Example:
        "abc" -> "fgh"
        "xyz" -> "cde"
    """
    shift_amount = 5
    encoded_characters = []

    for character in text:
        original_position = ord(character) - ord("a")
        shifted_position = (original_position + shift_amount) % 26
        encoded_character = chr(shifted_position + ord("a"))
        encoded_characters.append(encoded_character)

    return "".join(encoded_characters)


def decode_shift(text: str) -> str:
    """
    Return the original string by shifting each lowercase letter backward by 5.

    This function reverses the transformation performed by encode_shift.
    """
    shift_amount = 5
    decoded_characters = []

    for character in text:
        encoded_position = ord(character) - ord("a")
        original_position = (encoded_position - shift_amount) % 26
        decoded_character = chr(original_position + ord("a"))
        decoded_characters.append(decoded_character)

    return "".join(decoded_characters)
candidate = decode_shift




METADATA = {}


def check(candidate):
    from random import randint, choice
    import copy
    import string

    letters = string.ascii_lowercase
    for _ in range(100):
        str = ''.join(choice(letters) for i in range(randint(10, 20)))
        encoded_str = encode_shift(str)
        assert candidate(copy.deepcopy(encoded_str)) == str



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
