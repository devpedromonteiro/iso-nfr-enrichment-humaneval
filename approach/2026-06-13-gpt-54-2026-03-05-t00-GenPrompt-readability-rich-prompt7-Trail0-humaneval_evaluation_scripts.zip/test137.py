
import unittest
import re
import sys
import math
import copy


def compare_one(first_value, second_value):
    """
    Return the larger of two real-number values while preserving the original type.

    The inputs may be:
    - int
    - float
    - str representing a real number

    If a string uses a comma as the decimal separator, it is treated like a dot.
    Return None if both values are numerically equal.

    Examples:
        compare_one(1, 2.5) -> 2.5
        compare_one(1, "2,3") -> "2,3"
        compare_one("5,1", "6") -> "6"
        compare_one("1", 1) -> None
    """

    def to_number(value):
        if isinstance(value, str):
            normalized_value = value.replace(",", ".")
            return float(normalized_value)
        return float(value)

    first_number = to_number(first_value)
    second_number = to_number(second_value)

    if first_number == second_number:
        return None
    if first_number > second_number:
        return first_value
    return second_value
candidate = compare_one


def check(candidate):

    # Check some simple cases
    assert candidate(1, 2) == 2
    assert candidate(1, 2.5) == 2.5
    assert candidate(2, 3) == 3
    assert candidate(5, 6) == 6
    assert candidate(1, "2,3") == "2,3"
    assert candidate("5,1", "6") == "6"
    assert candidate("1", "2") == "2"
    assert candidate("1", 1) == None

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
