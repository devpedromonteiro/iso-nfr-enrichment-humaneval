
import unittest
import re
import sys
import math
import copy



def common(first_list: list, second_list: list) -> list:
    """Return sorted unique elements that appear in both lists.

    >>> common([1, 4, 3, 34, 653, 2, 5], [5, 7, 1, 5, 9, 653, 121])
    [1, 5, 653]
    >>> common([5, 3, 2, 8], [3, 2])
    [2, 3]
    """
    unique_first_items = set(first_list)
    unique_second_items = set(second_list)

    shared_items = unique_first_items.intersection(unique_second_items)
    sorted_shared_items = sorted(shared_items)

    return sorted_shared_items
candidate = common




METADATA = {}


def check(candidate):
    assert candidate([1, 4, 3, 34, 653, 2, 5], [5, 7, 1, 5, 9, 653, 121]) == [1, 5, 653]
    assert candidate([5, 3, 2, 8], [3, 2]) == [2, 3]
    assert candidate([4, 3, 2, 8], [3, 2, 4]) == [2, 3, 4]
    assert candidate([4, 3, 2, 8], []) == []



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
