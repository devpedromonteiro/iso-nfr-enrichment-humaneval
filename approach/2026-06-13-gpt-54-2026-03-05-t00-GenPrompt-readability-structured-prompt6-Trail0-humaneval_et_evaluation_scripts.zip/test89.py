
import unittest


def encrypt(text):
    """Return a new string with each lowercase letter shifted forward by 4.

    The encryption rotates the alphabet, so letters near the end wrap around:
    - encrypt("hi") -> "lm"
    - encrypt("asdfghjkl") -> "ewhjklnop"
    - encrypt("gf") -> "kj"
    - encrypt("et") -> "ix"
    """
    shift_amount = 4
    alphabet_size = 26
    first_letter_code = ord("a")

    encrypted_characters = []

    for character in text:
        original_position = ord(character) - first_letter_code
        shifted_position = (original_position + shift_amount) % alphabet_size
        encrypted_character = chr(first_letter_code + shifted_position)
        encrypted_characters.append(encrypted_character)

    return "".join(encrypted_characters)
candidate = encrypt


class Test(unittest.TestCase):
    def test(self):
        assert candidate("icep") == 'mgit'
        assert candidate("rshsbzuwunhkyfla") == 'vwlwfdyayrlocjpe'
        assert candidate("xefukaqfllnckjbsshsuruxojimpploykicgbijpgfenkvyku") == 'bijyoeujpprgonfwwlwyvybsnmqttpscomgkfmntkjirozcoy'
        assert candidate("eoieom") == 'ismisq'
        assert candidate("jyacovitrlbvmooowiredgrqaeoufrzjqvrvmbbfqifg") == 'ncegszmxvpfzqsssamvihkvueisyjvdnuzvzqffjumjk'
        assert candidate("btijac") == 'fxmneg'
        assert candidate("xhkwgznkc") == 'bloakdrog'
        assert candidate("mlcf") == 'qpgj'
        assert candidate("vjld") == 'znph'
        assert candidate("edos") == 'ihsw'
        assert candidate("ecvxboifogyvhhndxqmrwzrycvvzumjrmpuokojfhoyjrrsvqys") == 'igzbfsmjskczllrhbuqvadvcgzzdyqnvqtysosnjlscnvvwzucw'
        assert candidate("xnspkq") == 'brwtou'
        assert candidate("kemsjc") == 'oiqwng'
        assert candidate("hqc") == 'lug'
        assert candidate("iucuekiixpeocogw") == 'mygyiommbtisgska'
        assert candidate("iweg") == 'maik'
        assert candidate("wryepbt") == 'avcitfx'
        assert candidate("oqzpfpvmstecwor") == 'sudtjtzqwxigasv'
        assert candidate("zvnrqh") == 'dzrvul'
        assert candidate("khdzqn") == 'olhdur'
        assert candidate("okcgikrnpkwhdxjjt") == 'sogkmovrtoalhbnnx'
        assert candidate("dfkku") == 'hjooy'
        assert candidate("cbu") == 'gfy'
        assert candidate("ydbsopfos") == 'chfwstjsw'
        assert candidate("apemxwhfoivo") == 'etiqbaljsmzs'
        assert candidate("dvprq") == 'hztvu'
        assert candidate('et') == 'ix'
        assert candidate("pdkwkxl") == 'thoaobp'
        assert candidate("zuxjxvgmbe") == 'dybnbzkqfi'
        assert candidate("qufnwybuudtnstebb") == 'uyjracfyyhxrwxiff'
        assert candidate("cbnkip") == 'gfromt'
        assert candidate("dhvb") == 'hlzf'
        assert candidate("xcegcyrndybwwdnis") == 'bgikgcvrhcfaahrmw'
        assert candidate("vpf") == 'ztj'
        assert candidate("ylyahikkdltvcwhmgf") == 'cpcelmoohpxzgalqkj'
        assert candidate("fwycjuyymmhkzehzifkxyxpshiakkthethvnlkcjufunkag") == 'jacgnyccqqlodildmjobcbtwlmeooxlixlzrpognyjyroek'
        assert candidate("snrp") == 'wrvt'
        assert candidate("gjv") == 'knz'
        assert candidate("scckvgqaqvgtrpjxscrttodtfddygbogmsejojgqpolqitdupu") == 'wggozkueuzkxvtnbwgvxxshxjhhckfskqwinsnkutspumxhyty'
        assert candidate("jigty") == 'nmkxc'
        assert candidate("ltoqiorhbefpupjriabdqcsogcuerqihuxqbrbkgrdtmasa") == 'pxsumsvlfijtytnvmefhugwskgyivumlybufvfokvhxqewe'
        assert candidate("omqyojvvdgdtzoweweuxguoewqemqvzjrgxpxfvcysiibrsb") == 'squcsnzzhkhxdsaiaiybkysiauiquzdnvkbtbjzgcwmmfvwf'
        assert candidate("jigeiwr") == 'nmkimav'
        assert candidate("vndetsxgjgjyo") == 'zrhixwbknkncs'
        assert candidate("kljfcu") == 'opnjgy'
        assert candidate("bcdyegdqur") == 'fghcikhuyv'
        assert candidate("inqgyxjjbxjivfaumwuwlaictecgedssmtfxyreihxoftc") == 'mrukcbnnfbnmzjeyqayapemgxigkihwwqxjbcvimlbsjxg'
        assert candidate("hiozaupjaxn") == 'lmsdeytnebr'
        assert candidate("zkeab") == 'doief'
        assert candidate("pincbgwsxcgd") == 'tmrgfkawbgkh'
        assert candidate("ootuhtsyoclpfz") == 'ssxylxwcsgptjd'
        assert candidate("fthxiuur") == 'jxlbmyyv'
        assert candidate("ppnfsbzpkrlgc") == 'ttrjwfdtovpkg'
        assert candidate("jmfqkenawveukey") == 'nqjuoireaziyoic'
        assert candidate("eamlxvxtmyq") == 'ieqpbzbxqcu'
        assert candidate("lovcfz") == 'pszgjd'
        assert candidate("qug") == 'uyk'
        assert candidate("qlwbifaxvfpbtigmd") == 'upafmjebzjtfxmkqh'
        assert candidate("jdtgdqerkvdjo") == 'nhxkhuivozhns'
        assert candidate('faewfawefaewg')=='jeiajeaijeiak'
        assert candidate("jesneksjqo") == 'niwriownus'
        assert candidate("dwjksymbefjbdttbozxljxnivsdygyektzoevzcludwmzzv") == 'hanowcqfijnfhxxfsdbpnbrmzwhckcioxdsizdgpyhaqddz'
        assert candidate("kejihadgwjawxllizcdymgesbstydszfsvisnfoprrmh") == 'oinmlehkaneabppmdghcqkiwfwxchwdjwzmwrjstvvql'
        assert candidate("qxy") == 'ubc'
        assert candidate("wbqrfuufjolm") == 'afuvjyyjnspq'
        assert candidate("igd") == 'mkh'
        assert candidate("bacpsnyuqihtc") == 'fegtwrcyumlxg'
        assert candidate("iyhglogovmaivb") == 'mclkpskszqemzf'
        assert candidate('a')=='e'
        assert candidate("xtkq") == 'bxou'
        assert candidate("hzwcknqyfdy") == 'ldagorucjhc'
        assert candidate("qxnl") == 'ubrp'
        assert candidate("ghpevdaov") == 'kltizhesz'
        assert candidate("tgwoggktxwxlkcutrmpoegpnwryeegqtunvtchgdlstw") == 'xkaskkoxbabpogyxvqtsiktravciikuxyrzxglkhpwxa'
        assert candidate("osr") == 'swv'
        assert candidate('asdfghjkl') == 'ewhjklnop'
        assert candidate("nqb") == 'ruf'
        assert candidate("qzoowqmdpgs") == 'udssauqhtkw'
        assert candidate("uldvv") == 'yphzz'
        assert candidate("hssxlrbvcza") == 'lwwbpvfzgde'
        assert candidate("eszlshy") == 'iwdpwlc'
        assert candidate("gryaomsjpheksgfl") == 'kvcesqwntliowkjp'
        assert candidate('gf') == 'kj'
        assert candidate("wahnwedqvdrhzkoczaqgfulcpkdwxlxfutmwoxfxhtihx") == 'aelraihuzhvldosgdeukjypgtohabpbjyxqasbjblxmlb'
        assert candidate("qydzk") == 'uchdo'
        assert candidate("qodfsxptaswjxea") == 'ushjwbtxewanbie'
        assert candidate("pfafbn") == 'tjejfr'
        assert candidate('dxzdlmnilfuhmilufhlihufnmlimnufhlimnufhfucufh')=='hbdhpqrmpjylqmpyjlpmlyjrqpmqryjlpmqryjljygyjl'
        assert candidate("uiccmyfyikhtpneemoiglrphjsfyudawcethrgeewwg") == 'ymggqcjcmolxtriiqsmkpvtlnwjcyheagixlvkiiaak'
        assert candidate("iaaqxr") == 'meeubv'
        assert candidate("cxjqzxyj") == 'gbnudbcn'
        assert candidate("yfmlxmzfjwpagz") == 'cjqpbqdjnatekd'
        assert candidate("tcgkwaoxisclqjuhcg") == 'xgkoaesbmwgpunylgk'
        assert candidate("pxuqg") == 'tbyuk'
        assert candidate("srzakihijmoxy") == 'wvdeomlmnqsbc'
        assert candidate('hellomyfriend')=='lippsqcjvmirh'
        assert candidate("srsba") == 'wvwfe'
        assert candidate('hi') == 'lm'
        assert candidate("gudkyx") == 'kyhocb'
        assert candidate("hqmdzalclkbjfknjkiesfhckhkffveoykjypxavcroiyrawesb") == 'luqhdepgpofnjornomiwjlgolojjzisconctbezgvsmcveaiwf'
        assert candidate("wxssoiwft") == 'abwwsmajx'
        assert candidate("mghcjd") == 'qklgnh'
        assert candidate("bjhpaepqdvdxe") == 'fnlteituhzhbi'
        assert candidate("vcjcpaipaotbrhwzwkzqvdnotysiqjquxjfcyfxdsnycowlxw") == 'zgngtemtesxfvladaoduzhrsxcwmunuybnjgcjbhwrcgsapba'
        assert candidate("dkbwxzxweek") == 'hofabdbaiio'
        assert candidate("apycxz") == 'etcgbd'
        assert candidate("orwoj") == 'svasn'
        assert candidate("rbonb") == 'vfsrf'
        assert candidate("zzeb") == 'ddif'
        assert candidate("sxzd") == 'wbdh'
        assert candidate("dodbzraky") == 'hshfdveoc'
        assert candidate("yvjmva") == 'cznqze'
        assert candidate("myqyqo") == 'qcucus'

if __name__ == '__main__':
    unittest.main()
