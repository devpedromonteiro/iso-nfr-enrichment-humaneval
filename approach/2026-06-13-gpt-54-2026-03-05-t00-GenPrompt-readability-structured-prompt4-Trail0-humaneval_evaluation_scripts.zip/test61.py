
import unittest
import re
import sys
import math
import copy



def correct_bracketing(brackets: str) -> bool:
    """Return True when the parentheses are balanced.

    A balanced string never closes more brackets than it has opened,
    and finishes with no unmatched opening brackets.

    >>> correct_bracketing("(")
    False
    >>> correct_bracketing("()")
    True
    >>> correct_bracketing("(()())")
    True
    >>> correct_bracketing(")(()")
    False
    """
    open_bracket_count = 0

    for bracket in brackets:
        if bracket == "(":
            open_bracket_count += 1
        else:
            open_bracket_count -= 1

        if open_bracket_count < 0:
            return False

    return open_bracket_count == 0
candidate = correct_bracketing




METADATA = {}


def check(candidate):
    assert candidate("()")
    assert candidate("(()())")
    assert candidate("()()(()())()")
    assert candidate("()()((()()())())(()()(()))")
    assert not candidate("((()())))")
    assert not candidate(")(()")
    assert not candidate("(")
    assert not candidate("((((")
    assert not candidate(")")
    assert not candidate("(()")
    assert not candidate("()()(()())())(()")
    assert not candidate("()()(()())()))()")



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
