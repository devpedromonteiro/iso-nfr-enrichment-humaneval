
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    Return the number of index triples (i, j, k) with i < j < k such that
    a[i] + a[j] + a[k] is divisible by 3, where:

        a[i] = i * i - i + 1    for 1 <= i <= n

    Example:
        n = 5
        a = [1, 3, 7, 13, 21]
        Valid triple count = 1
    """

    def combinations_of_three(count):
        """Return the number of ways to choose 3 items from count items."""
        if count < 3:
            return 0
        return count * (count - 1) * (count - 2) // 6

    def combinations_of_two(count):
        """Return the number of ways to choose 2 items from count items."""
        if count < 2:
            return 0
        return count * (count - 1) // 2

    remainder_counts = [0, 0, 0]

    for index in range(1, n + 1):
        value_remainder = (index * index - index + 1) % 3
        remainder_counts[value_remainder] += 1

    count_remainder_0 = remainder_counts[0]
    count_remainder_1 = remainder_counts[1]
    count_remainder_2 = remainder_counts[2]

    valid_triples = 0

    # Triples where all three numbers have the same remainder.
    valid_triples += combinations_of_three(count_remainder_0)
    valid_triples += combinations_of_three(count_remainder_1)
    valid_triples += combinations_of_three(count_remainder_2)

    # Triples with one number from each remainder class: 0, 1, and 2.
    valid_triples += count_remainder_0 * count_remainder_1 * count_remainder_2

    return valid_triples
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
