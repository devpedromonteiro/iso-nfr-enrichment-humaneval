
import unittest
import re
import sys
import math
import copy


def is_nested(bracket_string):
    """
    Return True when the string contains a valid bracket subsequence
    with at least one nested pair of square brackets.

    A nested structure exists when, while scanning left to right,
    an opening bracket is found before a previous opening bracket
    has been closed.
    """
    open_bracket_depth = 0

    for bracket in bracket_string:
        if bracket == "[":
            open_bracket_depth += 1
            if open_bracket_depth >= 2:
                return True
        else:  # bracket == "]"
            if open_bracket_depth > 0:
                open_bracket_depth -= 1

    return False
candidate = is_nested


def check(candidate):

    # Check some simple cases
    assert candidate('[[]]') == True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('[]]]]]]][[[[[]') == False
    assert candidate('[][]') == False
    assert candidate(('[]')) == False
    assert candidate('[[[[]]]]') == True
    assert candidate('[]]]]]]]]]]') == False
    assert candidate('[][][[]]') == True
    assert candidate('[[]') == False
    assert candidate('[]]') == False
    assert candidate('[[]][[') == True
    assert candidate('[[][]]') == True

    # Check some edge cases that are easy to work out by hand.
    assert candidate('') == False, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate('[[[[[[[[') == False
    assert candidate(']]]]]]]]') == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
