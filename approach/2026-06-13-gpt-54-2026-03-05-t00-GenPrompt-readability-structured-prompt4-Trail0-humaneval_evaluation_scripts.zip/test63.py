
import unittest
import re
import sys
import math
import copy



def fibfib(n: int) -> int:
    """Return the n-th FibFib number.

    The FibFib sequence is defined as:
    - fibfib(0) = 0
    - fibfib(1) = 0
    - fibfib(2) = 1
    - fibfib(n) = fibfib(n - 1) + fibfib(n - 2) + fibfib(n - 3) for n >= 3

    >>> fibfib(1)
    0
    >>> fibfib(5)
    4
    >>> fibfib(8)
    24
    """
    if n == 0 or n == 1:
        return 0
    if n == 2:
        return 1

    third_previous = 0  # fibfib(0)
    second_previous = 0  # fibfib(1)
    previous = 1  # fibfib(2)

    for _ in range(3, n + 1):
        current = previous + second_previous + third_previous
        third_previous = second_previous
        second_previous = previous
        previous = current

    return previous
candidate = fibfib




METADATA = {}


def check(candidate):
    assert candidate(2) == 1
    assert candidate(1) == 0
    assert candidate(5) == 4
    assert candidate(8) == 24
    assert candidate(10) == 81
    assert candidate(12) == 274
    assert candidate(14) == 927



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
