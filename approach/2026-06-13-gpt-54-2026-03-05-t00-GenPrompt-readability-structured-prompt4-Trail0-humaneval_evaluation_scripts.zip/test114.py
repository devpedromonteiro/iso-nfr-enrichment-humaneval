
import unittest
import re
import sys
import math
import copy


def minSubArraySum(numbers):
    """
    Return the minimum sum of any non-empty contiguous subarray.

    Examples:
        minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
        minSubArraySum([-1, -2, -3]) == -6
    """
    if not numbers:
        raise ValueError("numbers must contain at least one value")

    smallest_ending_here = numbers[0]
    smallest_so_far = numbers[0]

    for current_number in numbers[1:]:
        smallest_ending_here = min(
            current_number,
            smallest_ending_here + current_number,
        )
        smallest_so_far = min(smallest_so_far, smallest_ending_here)

    return smallest_so_far
candidate = minSubArraySum


def check(candidate):

    # Check some simple cases
    assert candidate([2, 3, 4, 1, 2, 4]) == 1, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([-1, -2, -3]) == -6
    assert candidate([-1, -2, -3, 2, -10]) == -14
    assert candidate([-9999999999999999]) == -9999999999999999
    assert candidate([0, 10, 20, 1000000]) == 0
    assert candidate([-1, -2, -3, 10, -5]) == -6
    assert candidate([100, -1, -2, -3, 10, -5]) == -6
    assert candidate([10, 11, 13, 8, 3, 4]) == 3
    assert candidate([100, -33, 32, -1, 0, -2]) == -33

    # Check some edge cases that are easy to work out by hand.
    assert candidate([-10]) == -10, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([7]) == 7
    assert candidate([1, -1]) == -1


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
