
import unittest
import re
import sys
import math
import copy


import hashlib


def string_to_md5(text):
    """
    Given a string 'text', return its md5 hash equivalent string.
    If 'text' is an empty string, return None.

    >>> string_to_md5('Hello world') == '3e25960a79dbc69b674cd4ec67a72c62'
    """
    if text is None:
        raise TypeError("text must be a string, got None")

    if not isinstance(text, str):
        raise TypeError(f"text must be a string, got {type(text).__name__}")

    if text == "":
        return None

    try:
        return hashlib.md5(text.encode("utf-8")).hexdigest()
    except UnicodeEncodeError as exc:
        raise ValueError("text could not be encoded as UTF-8") from exc
candidate = string_to_md5


def check(candidate):

    # Check some simple cases
    assert candidate('Hello world') == '3e25960a79dbc69b674cd4ec67a72c62'
    assert candidate('') == None
    assert candidate('A B C') == '0ef78513b0cb8cef12743f5aeb35f888'
    assert candidate('password') == '5f4dcc3b5aa765d61d8327deb882cf99'

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
