
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def sort_numbers(numbers: str) -> str:
    """Input is a space-delimited string of numerals from 'zero' to 'nine'.
    Valid choices are 'zero', 'one', 'two', 'three', 'four', 'five',
    'six', 'seven', 'eight' and 'nine'.

    Return the string with numbers sorted from smallest to largest.

    >>> sort_numbers('three one five')
    'one three five'
    """
    if not isinstance(numbers, str):
        raise TypeError("numbers must be a string")

    number_map = {
        "zero": 0,
        "one": 1,
        "two": 2,
        "three": 3,
        "four": 4,
        "five": 5,
        "six": 6,
        "seven": 7,
        "eight": 8,
        "nine": 9,
    }

    tokens = numbers.split()

    invalid_tokens = [token for token in tokens if token not in number_map]
    if invalid_tokens:
        raise ValueError(
            f"invalid numeral(s): {', '.join(invalid_tokens)}; "
            f"valid values are: {', '.join(number_map.keys())}"
        )

    try:
        sorted_tokens = sorted(tokens, key=number_map.__getitem__)
    except KeyError as exc:
        # Defensive fallback: should not occur because inputs are validated above.
        raise ValueError(f"unexpected invalid numeral: {exc.args[0]}") from exc

    return " ".join(sorted_tokens)
candidate = sort_numbers




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == ''
    assert candidate('three') == 'three'
    assert candidate('three five nine') == 'three five nine'
    assert candidate('five zero four seven nine eight') == 'zero four five seven eight nine'
    assert candidate('six five four three two one zero') == 'zero one two three four five six'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
