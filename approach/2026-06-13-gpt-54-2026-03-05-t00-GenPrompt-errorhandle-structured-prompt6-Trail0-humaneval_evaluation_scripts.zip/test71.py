
import unittest
import re
import sys
import math
import copy


import math


def triangle_area(a, b, c):
    '''
    Given the lengths of the three sides of a triangle. Return the area of
    the triangle rounded to 2 decimal points if the three sides form a valid triangle.
    Otherwise return -1
    Three sides make a valid triangle when the sum of any two sides is greater
    than the third side.
    Example:
    triangle_area(3, 4, 5) == 6.00
    triangle_area(1, 2, 10) == -1
    '''
    try:
        # Validate argument count/type expectations explicitly
        for side in (a, b, c):
            if isinstance(side, bool):
                raise TypeError("Triangle side lengths must be numeric, not bool.")
            if not isinstance(side, (int, float)):
                raise TypeError("Triangle side lengths must be int or float.")
            if math.isnan(side) or math.isinf(side):
                raise ValueError("Triangle side lengths must be finite numbers.")
            if side <= 0:
                raise ValueError("Triangle side lengths must be greater than 0.")

        # Triangle inequality check
        if a + b <= c or a + c <= b or b + c <= a:
            return -1

        # Heron's formula
        s = (a + b + c) / 2
        area_squared = s * (s - a) * (s - b) * (s - c)

        # Guard against unexpected floating-point edge cases
        if area_squared < 0:
            raise ArithmeticError("Computed invalid intermediate area value.")

        return round(math.sqrt(area_squared), 2)

    except (TypeError, ValueError, ArithmeticError):
        # Re-raise specific exceptions to avoid silently swallowing errors
        raise
candidate = triangle_area


def check(candidate):

    # Check some simple cases
    assert candidate(3, 4, 5) == 6.00, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(1, 2, 10) == -1
    assert candidate(4, 8, 5) == 8.18
    assert candidate(2, 2, 2) == 1.73
    assert candidate(1, 2, 3) == -1
    assert candidate(10, 5, 7) == 16.25
    assert candidate(2, 6, 3) == -1

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1, 1, 1) == 0.43, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate(2, 2, 10) == -1



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
