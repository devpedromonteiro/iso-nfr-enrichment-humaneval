
import unittest
import re
import sys
import math
import copy


def decimal_to_binary(decimal):
    """Convert a non-negative decimal integer to a binary string wrapped with 'db'.

    Examples:
        decimal_to_binary(15) -> "db1111db"
        decimal_to_binary(32) -> "db100000db"
    """
    if isinstance(decimal, bool):
        raise TypeError("decimal must be an integer, not bool")

    if not isinstance(decimal, int):
        raise TypeError("decimal must be an integer")

    if decimal < 0:
        raise ValueError("decimal must be a non-negative integer")

    try:
        binary = format(decimal, "b")
        return f"db{binary}db"
    except (ValueError, TypeError) as exc:
        raise RuntimeError("failed to convert decimal to binary") from exc
candidate = decimal_to_binary


def check(candidate):

    # Check some simple cases
    assert candidate(0) == "db0db"
    assert candidate(32) == "db100000db"
    assert candidate(103) == "db1100111db"
    assert candidate(15) == "db1111db", "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
