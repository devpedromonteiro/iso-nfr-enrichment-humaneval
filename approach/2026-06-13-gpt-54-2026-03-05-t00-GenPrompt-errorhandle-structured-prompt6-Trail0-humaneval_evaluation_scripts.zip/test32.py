
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[2] * x^2 + .... + xs[n] * x^n
    """
    if not isinstance(xs, list):
        raise TypeError("xs must be a list of numeric coefficients")
    if len(xs) == 0:
        raise ValueError("xs must not be empty")
    if not isinstance(x, (int, float)):
        raise TypeError("x must be a numeric value")

    total = 0.0
    for i, coeff in enumerate(xs):
        if not isinstance(coeff, (int, float)):
            raise TypeError(f"coefficient at index {i} must be numeric")
        total += coeff * math.pow(x, i)
    return total


def find_zero(xs: list):
    """xs are coefficients of a polynomial.

    find_zero finds x such that poly(xs, x) == 0.
    find_zero returns only one zero point, even if there are many.

    This implementation validates the documented preconditions:
    - xs must be a non-empty list
    - xs must have an even number of coefficients
    - coefficients must be numeric
    - the largest non-zero coefficient must correspond to an odd degree,
      which guarantees a real solution for the polynomial

    >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2)  # (x - 1) * (x - 2) * (x - 3)
    1.0
    """
    if not isinstance(xs, list):
        raise TypeError("xs must be a list of numeric coefficients")
    if len(xs) == 0:
        raise ValueError("xs must not be empty")
    if len(xs) % 2 != 0:
        raise ValueError("xs must contain an even number of coefficients")

    for i, coeff in enumerate(xs):
        if not isinstance(coeff, (int, float)):
            raise TypeError(f"coefficient at index {i} must be numeric")

    degree = None
    for i in range(len(xs) - 1, -1, -1):
        if xs[i] != 0:
            degree = i
            break

    if degree is None:
        raise ValueError("zero polynomial has infinitely many zeros")

    if degree % 2 == 0:
        raise ValueError(
            "largest non-zero coefficient must correspond to an odd degree "
            "to guarantee a real zero"
        )

    # Handle linear case directly.
    if degree == 1:
        if xs[1] == 0:
            raise ZeroDivisionError("cannot solve linear polynomial with zero x coefficient")
        return -xs[0] / xs[1]

    def f(v: float) -> float:
        return poly(xs, v)

    # Since odd-degree polynomials have opposite signs at sufficiently
    # large negative and positive x, expand an interval until a sign change
    # is found.
    left = -1.0
    right = 1.0
    f_left = f(left)
    f_right = f(right)

    if f_left == 0:
        return left
    if f_right == 0:
        return right

    max_expansions = 10_000
    expansions = 0
    while f_left * f_right > 0:
        left *= 2.0
        right *= 2.0
        f_left = f(left)
        f_right = f(right)
        expansions += 1
        if expansions > max_expansions:
            raise RuntimeError("failed to bracket a root")

    # Bisection method keeps state consistent and converges on a root
    # within the bracketing interval.
    tolerance = 1e-12
    max_iterations = 10_000

    for _ in range(max_iterations):
        mid = (left + right) / 2.0
        f_mid = f(mid)

        if abs(f_mid) < tolerance:
            return mid

        if f_left * f_mid <= 0:
            right = mid
            f_right = f_mid
        else:
            left = mid
            f_left = f_mid

        if abs(right - left) < tolerance:
            return (left + right) / 2.0

    raise RuntimeError("bisection method did not converge")
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
