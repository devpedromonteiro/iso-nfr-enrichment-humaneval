
import unittest
import re
import sys
import math
import copy


def count_upper(s):
    """
    Given a string s, count the number of uppercase vowels in even indices.

    For example:
    count_upper('aBCdEf') returns 1
    count_upper('abcdefg') returns 0
    count_upper('dBBE') returns 0
    """
    if not isinstance(s, str):
        raise TypeError("count_upper expects a string argument")

    count = 0
    uppercase_vowels = {"A", "E", "I", "O", "U"}

    try:
        for i, ch in enumerate(s):
            if i % 2 == 0 and ch in uppercase_vowels:
                count += 1
    except TypeError:
        # Re-raise with clearer context while preserving specific failure type
        raise TypeError("input must be an iterable string of characters")

    return count
candidate = count_upper


def check(candidate):

    # Check some simple cases
    assert candidate('aBCdEf')  == 1
    assert candidate('abcdefg') == 0
    assert candidate('dBBE') == 0
    assert candidate('B')  == 0
    assert candidate('U')  == 1
    assert candidate('') == 0
    assert candidate('EEEE') == 2

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
