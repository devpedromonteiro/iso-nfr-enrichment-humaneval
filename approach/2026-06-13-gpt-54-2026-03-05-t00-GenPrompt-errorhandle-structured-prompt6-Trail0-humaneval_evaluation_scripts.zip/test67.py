
import unittest
import re
import sys
import math
import copy


import re


def fruit_distribution(s, n):
    """
    Given a string describing apples and oranges and an integer total fruit count,
    return the number of mangoes.

    Examples:
        fruit_distribution("5 apples and 6 oranges", 19) -> 8
        fruit_distribution("0 apples and 1 oranges", 3) -> 2

    Raises:
        TypeError: if input types are invalid
        ValueError: if the string format is invalid or counts are inconsistent
    """
    if not isinstance(s, str):
        raise TypeError("s must be a string")
    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if n < 0:
        raise ValueError("n must be non-negative")

    pattern = r"^\s*(\d+)\s+apples\s+and\s+(\d+)\s+oranges\s*$"
    match = re.match(pattern, s)
    if match is None:
        raise ValueError(
            's must match the format "<apples> apples and <oranges> oranges"'
        )

    apples = int(match.group(1))
    oranges = int(match.group(2))
    mangoes = n - apples - oranges

    if mangoes < 0:
        raise ValueError(
            "total fruit count cannot be less than the sum of apples and oranges"
        )

    return mangoes
candidate = fruit_distribution


def check(candidate):

    # Check some simple cases
    assert candidate("5 apples and 6 oranges",19) == 8
    assert candidate("5 apples and 6 oranges",21) == 10
    assert candidate("0 apples and 1 oranges",3) == 2
    assert candidate("1 apples and 0 oranges",3) == 2
    assert candidate("2 apples and 3 oranges",100) == 95
    assert candidate("2 apples and 3 oranges",5) == 0
    assert candidate("1 apples and 100 oranges",120) == 19


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
