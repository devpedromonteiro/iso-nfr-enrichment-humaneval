
import unittest
import re
import sys
import math
import copy


def by_length(arr):
    """
    Given an array of integers, sort the integers that are between 1 and 9 inclusive,
    reverse the resulting array, and then replace each digit by its corresponding name from
    "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine".

    For example:
      arr = [2, 1, 1, 4, 5, 8, 2, 3]
            -> sort arr -> [1, 1, 2, 2, 3, 4, 5, 8]
            -> reverse arr -> [8, 5, 4, 3, 2, 2, 1, 1]
      return ["Eight", "Five", "Four", "Three", "Two", "Two", "One", "One"]

      If the array is empty, return an empty array:
      arr = []
      return []

      If the array has any strange number ignore it:
      arr = [1, -1 , 55]
            -> sort arr -> [-1, 1, 55]
            -> reverse arr -> [55, 1, -1]
      return = ['One']
    """
    digit_names = {
        1: "One",
        2: "Two",
        3: "Three",
        4: "Four",
        5: "Five",
        6: "Six",
        7: "Seven",
        8: "Eight",
        9: "Nine",
    }

    if arr is None:
        raise TypeError("arr must be an iterable of integers, got None")

    if not isinstance(arr, (list, tuple)):
        raise TypeError(f"arr must be a list or tuple of integers, got {type(arr).__name__}")

    invalid_types = [type(x).__name__ for x in arr if not isinstance(x, int) or isinstance(x, bool)]
    if invalid_types:
        raise ValueError(
            "arr must contain only integers between any range; "
            f"found invalid element types: {invalid_types}"
        )

    try:
        valid_numbers = [x for x in arr if 1 <= x <= 9]
        valid_numbers.sort()
        valid_numbers.reverse()
        return [digit_names[x] for x in valid_numbers]
    except KeyError as exc:
        raise ValueError(f"Encountered unsupported digit during conversion: {exc}") from exc
candidate = by_length


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([2, 1, 1, 4, 5, 8, 2, 3]) == ["Eight", "Five", "Four", "Three", "Two", "Two", "One", "One"], "Error"
    assert candidate([]) == [], "Error"
    assert candidate([1, -1 , 55]) == ['One'], "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([1, -1, 3, 2]) == ["Three", "Two", "One"]
    assert candidate([9, 4, 8]) == ["Nine", "Eight", "Four"]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
