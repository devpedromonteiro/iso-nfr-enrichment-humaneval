
import unittest
import re
import sys
import math
import copy



def max_element(l: list):
    """Return maximum element in the list.

    >>> max_element([1, 2, 3])
    3
    >>> max_element([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    123
    """
    if not isinstance(l, list):
        raise TypeError("max_element expects a list")
    if not l:
        raise ValueError("max_element cannot operate on an empty list")

    try:
        maximum = l[0]
    except IndexError as exc:
        # Defensive guard, though empty lists are already handled above.
        raise ValueError("max_element cannot operate on an empty list") from exc

    for index, item in enumerate(l[1:], start=1):
        try:
            if item > maximum:
                maximum = item
        except TypeError as exc:
            raise TypeError(
                f"elements must be mutually comparable; failed at index {index}"
            ) from exc

    return maximum
candidate = max_element




METADATA = {}


def check(candidate):
    assert candidate([1, 2, 3]) == 3
    assert candidate([5, 3, -5, 2, -3, 3, 9, 0, 124, 1, -10]) == 124


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
