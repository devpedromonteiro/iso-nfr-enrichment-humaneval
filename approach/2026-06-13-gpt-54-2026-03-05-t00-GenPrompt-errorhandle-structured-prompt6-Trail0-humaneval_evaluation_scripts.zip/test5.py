
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    """Insert `delimeter` between every two consecutive elements of `numbers`.

    >>> intersperse([], 4)
    []
    >>> intersperse([1, 2, 3], 4)
    [1, 4, 2, 4, 3]
    """
    if numbers is None:
        raise TypeError("numbers must be a list of integers, got None")

    if not isinstance(numbers, list):
        raise TypeError(f"numbers must be a list, got {type(numbers).__name__}")

    if not isinstance(delimeter, int):
        raise TypeError(f"delimeter must be an int, got {type(delimeter).__name__}")

    for i, value in enumerate(numbers):
        if not isinstance(value, int):
            raise TypeError(
                f"all elements in numbers must be ints; "
                f"found {type(value).__name__} at index {i}"
            )

    if not numbers:
        return []

    result: List[int] = []
    for i, value in enumerate(numbers):
        result.append(value)
        if i < len(numbers) - 1:
            result.append(delimeter)

    return result
candidate = intersperse




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([], 7) == []
    assert candidate([5, 6, 3, 2], 8) == [5, 8, 6, 8, 3, 8, 2]
    assert candidate([2, 2, 2], 2) == [2, 2, 2, 2, 2]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
