
import unittest


def exchange(lst1, lst2):
    """Determine whether lst1 can be made all-even by exchanging elements with lst2.

    An exchange allows moving any number of elements between the two lists. This means
    lst1 can be made all-even iff there are at least len(lst1) even numbers available
    across both lists combined.

    Args:
        lst1: A non-empty list of numbers.
        lst2: A non-empty list of numbers.

    Returns:
        "YES" if lst1 can be made all-even, otherwise "NO".

    Raises:
        TypeError: If either argument is not a list, or contains non-numeric elements.
        ValueError: If either list is empty.
    """
    if not isinstance(lst1, list):
        raise TypeError("lst1 must be a list")
    if not isinstance(lst2, list):
        raise TypeError("lst2 must be a list")
    if not lst1:
        raise ValueError("lst1 must be non-empty")
    if not lst2:
        raise ValueError("lst2 must be non-empty")

    for i, value in enumerate(lst1):
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            raise TypeError(f"lst1[{i}] must be a numeric value")
        if isinstance(value, float) and not value.is_integer():
            raise ValueError(f"lst1[{i}] must be an integer-valued number")

    for i, value in enumerate(lst2):
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            raise TypeError(f"lst2[{i}] must be a numeric value")
        if isinstance(value, float) and not value.is_integer():
            raise ValueError(f"lst2[{i}] must be an integer-valued number")

    total_even = sum(1 for x in lst1 if int(x) % 2 == 0) + sum(1 for x in lst2 if int(x) % 2 == 0)

    return "YES" if total_even >= len(lst1) else "NO"
candidate = exchange


class Test(unittest.TestCase):
    def test(self):
        assert candidate([100, 204], [202, 200]) == 'YES'
        assert candidate([1, 6, 7, 1], [3, 9, 1, 2]) == 'NO'
        assert candidate([2, 7, 8, 8], [1, 8, 6, 7]) == 'YES'
        assert candidate([100, 197], [202, 204]) == 'YES'
        assert candidate([5, 11, 8], [5, 7, 9]) == 'NO'
        assert candidate([2, 3, 7, 6], [1, 6, 2, 3]) == 'YES'
        assert candidate([1, 5, 4, 8], [3, 1, 8, 4]) == 'YES'
        assert candidate([6, 10, 7], [6, 3, 5]) == 'YES'
        assert candidate([100, 203], [199, 204]) == 'YES'
        assert candidate([1, 5, 4, 7], [2, 9, 7, 1]) == 'NO'
        assert candidate([5, 5, 7, 7], [4, 2, 6, 4]) == 'YES'
        assert candidate([7, 8, 3], [6, 8, 7]) == 'YES'
        assert candidate([2, 1, 8, 6], [6, 10, 5, 8]) == 'YES'
        assert candidate([10, 12, 4], [1, 9, 5]) == 'YES'
        assert candidate([3, 6, 5, 7], [5, 3, 1, 6]) == 'NO'
        assert candidate([3, 4, 1], [2, 11, 4]) == 'YES'
        assert candidate([6, 4, 4, 4], [6, 6, 5, 2]) == 'YES'
        assert candidate([6, 8, 5], [7, 5, 1]) == 'NO'
        assert candidate([10, 10, 3], [5, 7, 1]) == 'NO'
        assert candidate([2, 4, 4, 5], [6, 4, 2, 3]) == 'YES'
        assert candidate([103, 201], [205, 203]) == 'NO'
        assert candidate([5, 7, 3], [2, 6, 3]) == "NO"
        assert candidate([3, 6, 8, 3], [1, 5, 1, 1]) == 'NO'
        assert candidate([10, 2, 3], [7, 6, 1]) == 'YES'
        assert candidate([6, 7, 3, 5], [2, 4, 3, 8]) == 'YES'
        assert candidate([8, 2, 1], [6, 10, 4]) == 'YES'
        assert candidate([4, 5, 5], [5, 10, 5]) == 'NO'
        assert candidate([8, 6, 2], [7, 8, 5]) == 'YES'
        assert candidate([5, 4, 7, 2, 13, 10], [7, 7, 10, 4, 5, 6]) == 'YES'
        assert candidate([5, 2, 2, 5], [3, 2, 4, 8]) == 'YES'
        assert candidate([1, 7, 1, 2], [3, 2, 4, 4]) == 'YES'
        assert candidate([5, 2, 2, 8], [6, 6, 1, 6]) == 'YES'
        assert candidate([6, 5, 3, 1], [2, 1, 1, 4]) == 'NO'
        assert candidate([4, 1, 11, 6, 8, 9], [1, 9, 3, 2, 2, 6]) == 'YES'
        assert candidate([3, 2, 6, 1, 8, 9], [3, 5, 5, 1, 1, 1]) == "NO"

    # Check some edge cases that are easy to work out by hand.
        assert candidate([99, 202], [199, 197]) == 'NO'
        assert candidate([4, 1, 4, 7], [1, 2, 6, 6]) == 'YES'
        assert candidate([105, 205], [201, 195]) == 'NO'
        assert candidate([4, 2, 6, 5], [2, 1, 2, 8]) == 'YES'
        assert candidate([6, 1, 5, 5], [5, 3, 5, 7]) == 'NO'
        assert candidate([2, 3, 7, 3], [6, 2, 7, 6]) == 'YES'
        assert candidate([7, 5, 6], [4, 10, 6]) == 'YES'
        assert candidate([99, 198], [202, 199]) == 'YES'
        assert candidate([2, 6, 5, 6], [5, 5, 2, 4]) == 'YES'
        assert candidate([3, 7, 1, 7], [4, 6, 1, 8]) == 'NO'
        assert candidate([5, 7, 3], [2, 6, 4]) == "YES"
        assert candidate([1, 6, 1], [5, 4, 3]) == 'NO'
        assert candidate([8, 11, 1], [4, 2, 4]) == 'YES'
        assert candidate([6, 3, 3], [5, 1, 6]) == 'NO'
        assert candidate([10, 9, 5], [7, 5, 7]) == 'NO'
        assert candidate([9, 4, 2], [4, 5, 7]) == 'YES'
        assert candidate([3, 4, 2, 1, 3, 7], [3, 6, 8, 2, 6, 2]) == 'YES'
        assert candidate([1, 9, 6], [1, 2, 4]) == 'YES'
        assert candidate([1, 3, 4, 2, 6, 6], [5, 1, 5, 4, 3, 5]) == 'NO'
        assert candidate([6, 4, 8, 7], [4, 5, 3, 1]) == 'YES'
        assert candidate([99, 195], [200, 200]) == 'YES'
        assert candidate([3, 4, 10, 1, 8, 4], [8, 10, 3, 4, 1, 2]) == 'YES'
        assert candidate([9, 9, 6], [7, 10, 8]) == 'YES'
        assert candidate([5, 6, 4, 7], [5, 6, 1, 8]) == 'YES'
        assert candidate([3, 5, 5], [3, 10, 5]) == 'NO'
        assert candidate([99, 202], [195, 197]) == 'NO'
        assert candidate([2, 1, 8, 9], [4, 7, 2, 9]) == 'YES'
        assert candidate([1, 2, 7, 4, 4, 10], [4, 6, 7, 2, 5, 5]) == 'YES'
        assert candidate([4, 5, 5, 8], [1, 5, 3, 1]) == 'NO'
        assert candidate([8, 6, 10, 1, 10, 9], [5, 5, 2, 6, 4, 5]) == 'YES'
        assert candidate([1, 6, 3], [4, 10, 7]) == 'YES'
        assert candidate([4, 3, 4, 8], [4, 4, 7, 7]) == 'YES'
        assert candidate([10, 9, 6], [2, 10, 9]) == 'YES'
        assert candidate([2, 3, 8, 7], [2, 1, 3, 1]) == 'NO'
        assert candidate([1, 2, 3, 4], [1, 2, 3, 4]) == "YES"
        assert candidate([6, 5, 6, 4, 11, 5], [3, 4, 3, 6, 5, 1]) == 'NO'
        assert candidate([3, 10, 8], [7, 3, 1]) == 'NO'
        assert candidate([95, 198], [200, 204]) == 'YES'
        assert candidate([100, 203], [196, 196]) == 'YES'
        assert candidate([3, 7, 8, 4], [4, 3, 6, 1]) == 'YES'
        assert candidate([6, 6, 7, 3, 5, 11], [5, 1, 3, 3, 2, 4]) == 'NO'
        assert candidate([4, 3, 11, 3, 7, 12], [4, 4, 5, 3, 3, 3]) == 'NO'
        assert candidate([5, 1, 5, 6, 9, 13], [6, 9, 3, 5, 4, 4]) == 'NO'
        assert candidate([9, 6, 3], [1, 6, 6]) == 'YES'
        assert candidate([95, 200], [195, 197]) == 'NO'
        assert candidate([8, 7, 7], [1, 6, 2]) == 'YES'
        assert candidate([3, 10, 6], [4, 6, 6]) == 'YES'
        assert candidate([98, 203], [195, 199]) == 'NO'
        assert candidate([3, 6, 8, 4], [6, 2, 7, 6]) == 'YES'
        assert candidate([5, 6, 3, 8], [5, 4, 4, 6]) == 'YES'
        assert candidate([4, 7, 6, 4], [4, 9, 7, 8]) == 'YES'
        assert candidate([4, 4, 5, 7], [1, 5, 1, 9]) == 'NO'
        assert candidate([100, 204], [201, 204]) == 'YES'
        assert candidate([5, 1, 4, 2], [5, 2, 4, 3]) == 'YES'
        assert candidate([5, 4, 1], [7, 11, 1]) == 'NO'
        assert candidate([97, 204], [203, 203]) == 'NO'
        assert candidate([5, 7, 5, 7], [4, 6, 7, 1]) == 'NO'
        assert candidate([6, 4, 4, 5], [1, 4, 1, 4]) == 'YES'
        assert candidate([1, 1, 2, 1], [4, 1, 8, 2]) == 'YES'
        assert candidate([2, 7, 2, 8], [3, 6, 5, 8]) == 'YES'
        assert candidate([100, 200], [200, 200]) == "YES"
        assert candidate([1, 2, 3, 4], [1, 5, 3, 4]) == "NO"
        assert candidate([4, 8, 4], [6, 11, 5]) == 'YES'
        assert candidate([1, 4, 3, 3], [4, 6, 8, 8]) == 'YES'
        assert candidate([5, 4, 3, 7], [4, 5, 2, 6]) == 'YES'
        assert candidate([1, 2, 3, 4], [2, 1, 4, 3]) == "YES"
        assert candidate([2, 10, 7], [1, 5, 7]) == 'NO'
        assert candidate([5, 1, 3, 6, 12, 9], [3, 6, 10, 1, 5, 6]) == 'NO'
        assert candidate([102, 204], [202, 203]) == 'YES'
        assert candidate([8, 3, 1, 2, 7, 9], [4, 5, 3, 1, 2, 1]) == 'NO'
        assert candidate([5, 2, 3, 1], [5, 3, 8, 8]) == 'NO'
        assert candidate([2, 12, 8], [2, 11, 3]) == 'YES'
        assert candidate([7, 6, 3, 4, 3, 8], [7, 2, 5, 6, 1, 2]) == 'YES'
        assert candidate([3, 2, 3, 3, 13, 7], [1, 5, 9, 1, 6, 3]) == 'NO'
        assert candidate([4, 2, 8, 9], [2, 1, 4, 8]) == 'YES'
        assert candidate([2, 4, 1, 7], [5, 8, 8, 7]) == 'YES'
        assert candidate([5, 11, 8], [6, 10, 6]) == 'YES'
        assert candidate([3, 7, 2], [6, 9, 7]) == 'NO'
        assert candidate([3, 3, 4, 5], [2, 2, 1, 5]) == 'NO'
        assert candidate([5, 6, 3], [6, 5, 5]) == 'NO'
        assert candidate([5, 11, 2], [5, 7, 1]) == 'NO'
        assert candidate([1, 1, 4, 2], [6, 6, 2, 9]) == 'YES'
        assert candidate([6, 5, 6, 1], [4, 4, 8, 1]) == 'YES'
        assert candidate([1, 7, 7, 6], [2, 7, 5, 9]) == 'NO'
        assert candidate([7, 10, 8], [2, 1, 3]) == 'YES'
        assert candidate([1, 2, 11, 2, 7, 5], [4, 10, 2, 6, 2, 2]) == 'YES'
        assert candidate([6, 7, 8, 4, 10, 5], [8, 6, 8, 5, 6, 3]) == 'YES'
        assert candidate([1, 7, 6, 6, 12, 13], [6, 9, 7, 2, 6, 1]) == 'YES'
        assert candidate([6, 2, 5, 8], [1, 6, 6, 2]) == 'YES'
        assert candidate([3, 3, 1, 1], [6, 4, 9, 4]) == 'NO'
        assert candidate([3, 4, 7, 3], [1, 3, 5, 8]) == 'NO'
        assert candidate([6, 7, 8], [5, 10, 2]) == 'YES'
        assert candidate([3, 5, 6, 6], [1, 5, 8, 4]) == 'YES'
        assert candidate([97, 196], [203, 201]) == 'NO'
        assert candidate([4, 2, 6, 1], [7, 5, 8, 8]) == 'YES'
        assert candidate([5, 6, 7, 7], [4, 3, 9, 2]) == 'NO'
        assert candidate([6, 4, 4, 6], [1, 2, 3, 4]) == 'YES'
        assert candidate([105, 204], [197, 203]) == 'NO'

if __name__ == '__main__':
    unittest.main()
