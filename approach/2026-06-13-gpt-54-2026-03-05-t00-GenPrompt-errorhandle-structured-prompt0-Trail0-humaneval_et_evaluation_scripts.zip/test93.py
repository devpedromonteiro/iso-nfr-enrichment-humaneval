
import unittest


def encode(message):
    """
    Write a function that takes a message, and encodes in such a
    way that it swaps case of all letters, replaces all vowels in
    the message with the letter that appears 2 places ahead of that
    vowel in the english alphabet.
    Assume only letters.

    Examples:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """
    if not isinstance(message, str):
        raise TypeError("message must be a string")

    vowel_map = {
        'a': 'c',
        'e': 'g',
        'i': 'k',
        'o': 'q',
        'u': 'w',
        'A': 'C',
        'E': 'G',
        'I': 'K',
        'O': 'Q',
        'U': 'W',
    }

    encoded_chars = []

    for char in message:
        if not (char.isalpha() or char.isspace()):
            raise ValueError("message must contain only letters and spaces")

        transformed = vowel_map.get(char, char)
        encoded_chars.append(transformed.swapcase())

    return ''.join(encoded_chars)
candidate = encode


class Test(unittest.TestCase):
    def test(self):
        assert candidate("ZUvOnpFUjJGGWcJQYQmTY W") == 'zwVqNPfwJjggwCjqyqMty w'
        assert candidate("SgPXbDsCxLlYIAFFhhIbRfXHjaZ") == 'sGpxBdScXlLykcffHHkBrFxhJCz'
        assert candidate("TEPUFH") == 'tgpwfh'
        assert candidate("FKRTJOGJR") == 'fkrtjqgjr'
        assert candidate("GWHK") == 'gwhk'
        assert candidate("ElaZse dYXHgdVq") == 'gLCzSG DyxhGDvQ'
        assert candidate("SETPXKRTE") == 'sgtpxkrtg'
        assert candidate("JRG") == 'jrg'
        assert candidate("XQAXbNmLpmobUzQtNvacz") == 'xqcxBnMlPMQBwZqTnVCCZ'
        assert candidate("FPENQAZGK") == 'fpgnqczgk'
        assert candidate("TEIPDCVYN") == 'tgkpdcvyn'
        assert candidate("gIVppcmTSMtmvhg ZjTdBs") == 'GkvPPCMtsmTMVHG zJtDbS'
        assert candidate("nds") == 'NDS'
        assert candidate("CVLBOWSP") == 'cvlbqwsp'
        assert candidate("BRVLN") == 'brvln'
        assert candidate("hnbzSknod dSFfSG") == 'HNBZsKNQD DsfFsg'
        assert candidate("BnHJZme") == 'bNhjzMG'
        assert candidate("zTBpeQNFrEsJ") == 'ZtbPGqnfRgSj'
        assert candidate("IstxgcEpahvkDruGyiK") == 'kSTXGCgPCHVKdRWgYKk'
        assert candidate("HzEMwPWyLehG jFTacHALOraUoB") == 'hZgmWpwYlGHg JftCChclqRCwQb'
        assert candidate(" BuOTEofYkQJauJaclURS") == ' bWqtgQFyKqjCWjCCLwrs'
        assert candidate("FHEcvmCWtbF aJg") == 'fhgCVMcwTBf CjG'
        assert candidate("RHO") == 'rhq'
        assert candidate("OJMQGVupooekW") == 'qjmqgvWPQQGKw'
        assert candidate("DARS") == 'dcrs'
        assert candidate("ZTTSSFEL") == 'zttssfgl'
        assert candidate("kkAuzPMaJbY") == 'KKcWZpmCjBy'
        assert candidate("kwfcMJBvOIscxpuRJYMQxX") == 'KWFCmjbVqkSCXPWrjymqXx'
        assert candidate("pUgmIEYWAnzEuqFElVbVs") == 'PwGMkgywcNZgWQfgLvBvS'
        assert candidate("kzLQOefkAweHvGBycjn") == 'KZlqqGFKcWGhVgbYCJN'
        assert candidate("CLY") == 'cly'
        assert candidate("GUAU") == 'gwcw'
        assert candidate("YcxmhivPyJIw") == 'yCXMHKVpYjkW'
        assert candidate('TEST') == 'tgst'
        assert candidate("oSYVfHWo kWWvnziVt") == 'QsyvFhwQ KwwVNZKvT'
        assert candidate("TXAFFIW") == 'txcffkw'
        assert candidate("EORCSH") == 'gqrcsh'
        assert candidate("ETMDXUEBC") == 'gtmdxwgbc'
        assert candidate("TQRZQWU") == 'tqrzqww'
        assert candidate("DPGWLEVT") == 'dpgwlgvt'
        assert candidate("PRREkliEYbvcKGoNqvSfsJ") == 'prrgKLKgyBVCkgQnQVsFSj'
        assert candidate("WWBsZMYcpjfNzyCeVVgesJoJhjy") == 'wwbSzmyCPJFnZYcGvvGGSjQjHJY'
        assert candidate("I DoNt KnOw WhAt tO WrItE") == 'k dQnT kNqW wHcT Tq wRkTg'
        assert candidate("gnJhAIkj") == 'GNjHckKJ'
        assert candidate("OHUJlX") == 'qhwjLx'
        assert candidate("EoisHGBfMOUHhIftINGIdF DJqugm") == 'gQKShgbFmqwhHkFTkngkDf djQWGM'
        assert candidate("JJWNGDOT") == 'jjwngdqt'
        assert candidate("DXZBFN") == 'dxzbfn'
        assert candidate("DVKfMTlbOESs") == 'dvkFmtLBqgsS'
        assert candidate("UEeG") == 'wgGg'
        assert candidate("BCKPNMVO") == 'bckpnmvq'
        assert candidate("IMIJTK") == 'kmkjtk'
        assert candidate("ZyWrbakVZJKkkAmmKNRmUPDCi") == 'zYwRBCKvzjkKKcMMknrMwpdcK'
        assert candidate("URMC") == 'wrmc'
        assert candidate("CNJ") == 'cnj'
        assert candidate("grukYfBTTJtVX") == 'GRWKyFbttjTvx'
        assert candidate("FDMjHnZkEhmsNmlJNItsJQlasO") == 'fdmJhNzKgHMSnMLjnkTSjqLCSq'
        assert candidate("rRrZwWEjxTIMMSNiS") == 'RrRzWwgJXtkmmsnKs'
        assert candidate("LHfTwSNWVA") == 'lhFtWsnwvc'
        assert candidate("QwJoXypNyPZVVwtdhDxHhBKXS") == 'qWjQxYPnYpzvvWTDHdXhHbkxs'
        assert candidate("cJbiuaENQvBuUexfhUuJRbvP") == 'CjBKWCgnqVbWwGXFHwWjrBVp'
        assert candidate("Sjf") == 'sJF'
        assert candidate("DZAXVXQ") == 'dzcxvxq'
        assert candidate("HNDsWbIhInLlAGVoRFZw") == 'hndSwBkHkNlLcgvQrfzW'
        assert candidate("YaFsT") == 'yCfSt'
        assert candidate("WNYEUHDUE") == 'wnygwhdwg'
        assert candidate("ROWVCETC") == 'rqwvcgtc'
        assert candidate("Hmj") == 'hMJ'
        assert candidate("ApBJTja") == 'cPbjtJC'
        assert candidate("NNoTLfuGwSHDJdTlRXSyC") == 'nnQtlFWgWshdjDtLrxsYc'
        assert candidate("pvQeerpuzVbW") == 'PVqGGRPWZvBw'
        assert candidate("LCLBDYXRN") == 'lclbdyxrn'
        assert candidate("RcQZkLoILujJnUJ BK lQgY") == 'rCqzKlQklWJjNwj bk LqGy'
        assert candidate("IzXkNbTRYEDDLFF") == 'kZxKnBtrygddlff'
        assert candidate("bBSM") == 'Bbsm'
        assert candidate("rhgAVJOAnVugEnMSSKWsc") == 'RHGcvjqcNvWGgNmsskwSC'
        assert candidate("KTBXLNF") == 'ktbxlnf'
        assert candidate("gEQTanRJKhLxXlJDZQHPwvbnq") == 'GgqtCNrjkHlXxLjdzqhpWVBNQ'
        assert candidate("EjhSPNSJMPQ") == 'gJHspnsjmpq'
        assert candidate("TLU") == 'tlw'
        assert candidate("rjXQvzxCjzaWcAuNeOiaXPpdYVoxCt") == 'RJxqVZXcJZCwCcWnGqKCxpPDyvQXcT'
        assert candidate("ZVS") == 'zvs'
        assert candidate("BODPGNO") == 'bqdpgnq'
        assert candidate('This is a message') == 'tHKS KS C MGSSCGG'
        assert candidate("jZheceVgKgTLjRwOLeRrrtwbE") == 'JzHGCGvGkGtlJrWqlGrRRTWBg'
        assert candidate("AZOCBJD") == 'czqcbjd'
        assert candidate("HrRcDpPaxYYXID") == 'hRrCdPpCXyyxkd'
        assert candidate("DNHIUUVX") == 'dnhkwwvx'
        assert candidate("TEGPKXNB") == 'tggpkxnb'
        assert candidate("OBEcrSHMuaCS") == 'qbgCRshmWCcs'
        assert candidate("jAqqTMHiqs") == 'JcQQtmhKQS'
        assert candidate("IYS") == 'kys'
        assert candidate("HKWXPGN") == 'hkwxpgn'
        assert candidate("aZPgQ vnmhPPOLdLIutuJO") == 'CzpGq VNMHppqlDlkWTWjq'
        assert candidate("fZoHFcbTcLTUWG VdZ") == 'FzQhfCBtCltwwg vDz'
        assert candidate("SSMAQL") == 'ssmcql'
        assert candidate("ITNaCJiUmgbbsXbJggeE") == 'ktnCcjKwMGBBSxBjGGGg'
        assert candidate("PKKLGPQOY") == 'pkklgpqqy'
        assert candidate("XgnELkHHAAUiCCpSfJ") == 'xGNglKhhccwKccPsFj'
        assert candidate("jjHqlFViqHz") == 'JJhQLfvKQhZ'
        assert candidate('Mudasir') == 'mWDCSKR'
        assert candidate("OpzdoaiWPrtwH") == 'qPZDQCKwpRTWh'
        assert candidate(" dNVahxVjKzB JTneIFjKfXsk ") == ' DnvCHXvJkZb jtNGkfJkFxSK '
        assert candidate("c XkUXkBchEddL") == 'C xKwxKbCHgDDl'
        assert candidate("PSBSBey") == 'psbsbGY'
        assert candidate("mejsPoZxTWVZINkltbTC") == 'MGJSpQzXtwvzknKLTBtc'
        assert candidate("RkeGn HyKwTJKYqIJSWnu") == 'rKGgN hYkWtjkyQkjswNW'
        assert candidate("JMFDUNNFN") == 'jmfdwnnfn'
        assert candidate("DWUOPpLjiGck") == 'dwwqpPlJKgCK'
        assert candidate("KtvgHCwhJPHhZoPrTShCCFjb") == 'kTVGhcWHjphHzQpRtsHccfJB'
        assert candidate("BGPB") == 'bgpb'
        assert candidate("FVABgUJcvAO") == 'fvcbGwjCVcq'
        assert candidate("LPVHOUZC") == 'lpvhqwzc'
        assert candidate("vFk rhQEfvOP ZgydPEhvIVWD") == 'VfK RHqgFVqp zGYDpgHVkvwd'
        assert candidate("QRX") == 'qrx'
        assert candidate("DXV") == 'dxv'
        assert candidate("qmjcLnfY lObRZrX") == 'QMJClNFy LqBrzRx'
        assert candidate('YES') == 'ygs'
        assert candidate("lljsyoqvdrgHLkvty") == 'LLJSYQQVDRGhlKVTY'
        assert candidate("OSWDQFIR") == 'qswdqfkr'
        assert candidate("ZfDqK") == 'zFdQk'
        assert candidate("BYRAIVE") == 'byrckvg'
        assert candidate("AGMBICYE") == 'cgmbkcyg'
        assert candidate("kqmseH") == 'KQMSGh'
        assert candidate("WYLLSZM") == 'wyllszm'
        assert candidate("hgxUMf") == 'HGXwmF'
        assert candidate("xOzJhrPNcVCLkJeMgwsBcYm") == 'XqZjHRpnCvclKjGmGWSbCyM'
        assert candidate("rKELArbzBNVyXuUr") == 'RkglcRBZbnvYxWwR'
        assert candidate("WNRIIJWGO") == 'wnrkkjwgq'
        assert candidate("UNVEY") == 'wnvgy'

if __name__ == '__main__':
    unittest.main()
