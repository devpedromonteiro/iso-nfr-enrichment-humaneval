
import unittest



def remove_vowels(text):
    """
    remove_vowels is a function that takes string and returns string without vowels.

    >>> remove_vowels('')
    ''
    >>> remove_vowels("abcdef\nghijklm")
    'bcdf\nghjklm'
    >>> remove_vowels('abcdef')
    'bcdf'
    >>> remove_vowels('aaaaa')
    ''
    >>> remove_vowels('aaBAA')
    'B'
    >>> remove_vowels('zbcd')
    'zbcd'
    """
    if text is None:
        raise TypeError("text must be a string, got None")

    if not isinstance(text, str):
        raise TypeError(f"text must be a string, got {type(text).__name__}")

    vowels = {"a", "e", "i", "o", "u", "A", "E", "I", "O", "U"}

    try:
        return "".join(char for char in text if char not in vowels)
    except Exception as exc:
        raise RuntimeError("failed to remove vowels from input text") from exc
candidate = remove_vowels


class Test(unittest.TestCase):
    def test(self):
        assert candidate("bdmye") == 'bdmy'
        assert candidate('fedcba') == 'fdcb'
        assert candidate("lz") == 'lz'
        assert candidate("zzxuoc") == 'zzxc'
        assert candidate("sywqxabq") == 'sywqxbq'
        assert candidate("omdwqqfx") == 'mdwqqfx'
        assert candidate("BgbpQbQaw") == 'BgbpQbQw'
        assert candidate("oOPb") == 'Pb'
        assert candidate("jffdqepm") == 'jffdqpm'
        assert candidate("nznwcimzc") == 'nznwcmzc'
        assert candidate("g") == 'g'
        assert candidate("wtvG") == 'wtvG'
        assert candidate("fc") == 'fc'
        assert candidate("qeuwbkovm") == 'qwbkvm'
        assert candidate("zlwflag") == 'zlwflg'
        assert candidate("oe") == ''
        assert candidate("lbCFKE") == 'lbCFK'
        assert candidate("vloipqtgtveawjtn") == 'vlpqtgtvwjtn'
        assert candidate("KYTpFEg") == 'KYTpFg'
        assert candidate("ktewddk") == 'ktwddk'
        assert candidate("quzstvdfqg") == 'qzstvdfqg'
        assert candidate("XHpLhU") == 'XHpLh'
        assert candidate("obrhtxhtuo") == 'brhtxht'
        assert candidate("pYlsLbTc") == 'pYlsLbTc'
        assert candidate("gbuxhmi") == 'gbxhm'
        assert candidate("LHVZaDp") == 'LHVZDp'
        assert candidate("otbpmulzy") == 'tbpmlzy'
        assert candidate("fnhkm") == 'fnhkm'
        assert candidate("uhp") == 'hp'
        assert candidate("rAvZcBVYv") == 'rvZcBVYv'
        assert candidate('eeeee') == ''
        assert candidate("xqhpsau") == 'xqhps'
        assert candidate("fmdf") == 'fmdf'
        assert candidate("Yvyqaz") == 'Yvyqz'
        assert candidate("nhxkmmvs") == 'nhxkmmvs'
        assert candidate("KGQT") == 'KGQT'
        assert candidate("ezHfoXGJ") == 'zHfXGJ'
        assert candidate("fjv") == 'fjv'
        assert candidate("vlymdry") == 'vlymdry'
        assert candidate("ietqwb") == 'tqwb'
        assert candidate("arhlhqhb") == 'rhlhqhb'
        assert candidate("uoapunbirpsl") == 'pnbrpsl'
        assert candidate("qdaloer") == 'qdlr'
        assert candidate("YfkwJX") == 'YfkwJX'
        assert candidate("OVY") == 'VY'
        assert candidate("hmz") == 'hmz'
        assert candidate('') == ''
        assert candidate("okjhzsyzhmvuhlpyf") == 'kjhzsyzhmvhlpyf'
        assert candidate("Edk") == 'dk'
        assert candidate("soeug") == 'sg'
        assert candidate("gmhwwwtgrozmhgdl") == 'gmhwwwtgrzmhgdl'
        assert candidate("TaXZTHehL") == 'TXZTHhL'
        assert candidate("uslgojzvdg") == 'slgjzvdg'
        assert candidate("adeqwnjqvrkws") == 'dqwnjqvrkws'
        assert candidate("eeeuvn") == 'vn'
        assert candidate("sebzrlkjqv") == 'sbzrlkjqv'
        assert candidate("Ujttg") == 'jttg'
        assert candidate("pwjqwt") == 'pwjqwt'
        assert candidate("abcdef\nghijklm") == 'bcdf\nghjklm'
        assert candidate("tplzjz") == 'tplzjz'
        assert candidate("ywbdg") == 'ywbdg'
        assert candidate("ewci") == 'wc'
        assert candidate("jt") == 'jt'
        assert candidate("msykqq") == 'msykqq'
        assert candidate("WkCb") == 'WkCb'
        assert candidate("oHlrLv") == 'HlrLv'
        assert candidate("acaqnyjoz") == 'cqnyjz'
        assert candidate("ktmsFf") == 'ktmsFf'
        assert candidate("siz") == 'sz'
        assert candidate("yrk") == 'yrk'
        assert candidate("urCjrM") == 'rCjrM'
        assert candidate("duprwgecbaziaj") == 'dprwgcbzj'
        assert candidate("f") == 'f'
        assert candidate("zsgnhflpl") == 'zsgnhflpl'
        assert candidate("EMI") == 'M'
        assert candidate("lnurjnjxpk") == 'lnrjnjxpk'
        assert candidate("WxqQBVxrN") == 'WxqQBVxrN'
        assert candidate("bsb") == 'bsb'
        assert candidate("TOheHtN") == 'ThHtN'
        assert candidate("watQnnp") == 'wtQnnp'
        assert candidate("iknfvadtb") == 'knfvdtb'
        assert candidate("w") == 'w'
        assert candidate("arnhwhzbhkqu") == 'rnhwhzbhkq'
        assert candidate("ew") == 'w'
        assert candidate("vntgnznokuiysrb") == 'vntgnznkysrb'
        assert candidate("qzzqkb") == 'qzzqkb'
        assert candidate("shkzkuzxkngkecko") == 'shkzkzxkngkck'
        assert candidate("guevbhcrsxgp") == 'gvbhcrsxgp'
        assert candidate("xTziZy") == 'xTzZy'
        assert candidate("ebsrnvw") == 'bsrnvw'
        assert candidate("DEgyM") == 'DgyM'
        assert candidate("cvs") == 'cvs'
        assert candidate('ybcd') == 'ybcd'
        assert candidate("isw") == 'sw'
        assert candidate("jnveoi") == 'jnv'
        assert candidate("XEkdmDJSS") == 'XkdmDJSS'
        assert candidate("wugjkvbmg") == 'wgjkvbmg'
        assert candidate("xx") == 'xx'
        assert candidate("axuukexsgyaawidj") == 'xkxsgywdj'
        assert candidate("rbFdSSwun") == 'rbFdSSwn'
        assert candidate("eJO") == 'J'
        assert candidate("lg") == 'lg'
        assert candidate("vxr") == 'vxr'
        assert candidate("sadxzpakrln") == 'sdxzpkrln'
        assert candidate("foza") == 'fz'
        assert candidate("zxog") == 'zxg'
        assert candidate("mufpjfkgadzyb") == 'mfpjfkgdzyb'
        assert candidate("pfyoglmdc") == 'pfyglmdc'
        assert candidate("cg") == 'cg'
        assert candidate('acBAA') == 'cB'
        assert candidate("dEI") == 'd'
        assert candidate("ofskfbosycskpze") == 'fskfbsycskpz'
        assert candidate("fshdmulqnytjokyosn") == 'fshdmlqnytjkysn'
        assert candidate("k") == 'k'
        assert candidate("zgpdfazw") == 'zgpdfzw'
        assert candidate("aic") == 'c'
        assert candidate("azqNA") == 'zqN'
        assert candidate("Frhrepr") == 'Frhrpr'
        assert candidate('EcBOO') == 'cB'
        assert candidate("evovy") == 'vvy'
        assert candidate("azcgydxylp") == 'zcgydxylp'
        assert candidate("baWXDZniw") == 'bWXDZnw'
        assert candidate("juqegxhhusfivzjr") == 'jqgxhhsfvzjr'
        assert candidate("gsbodwzfa") == 'gsbdwzf'
        assert candidate("Xxi") == 'Xx'
        assert candidate("uyktjllxr") == 'yktjllxr'
        assert candidate("bewqm") == 'bwqm'
        assert candidate("lwxqqrcfxs") == 'lwxqqrcfxs'
        assert candidate("siryb") == 'sryb'
        assert candidate("lgowxjffr") == 'lgwxjffr'
        assert candidate("ftwmovee") == 'ftwmv'
        assert candidate("prwzqwrux") == 'prwzqwrx'
        assert candidate("gxgtdglcoq") == 'gxgtdglcq'

if __name__ == '__main__':
    unittest.main()
