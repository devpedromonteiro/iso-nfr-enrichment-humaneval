
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Return the lexicographically smallest path of length k in the grid.

    A path:
    - starts at any cell
    - visits exactly k cells
    - moves only up/down/left/right
    - may revisit cells

    Since every value from 1 to N*N appears exactly once, the smallest possible
    first value is always 1. Therefore, the optimal path must start from the
    cell containing 1.

    After that, at each step, to keep the whole sequence lexicographically
    minimal, we should move to the neighboring cell with the smallest value.
    Repeating this greedily produces the unique minimum path.
    """
    n = len(grid)

    # Directions: up, down, left, right
    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]

    # Find the position of value 1
    start_row = start_col = -1
    for row in range(n):
        for col in range(n):
            if grid[row][col] == 1:
                start_row, start_col = row, col
                break
        if start_row != -1:
            break

    path = [1]
    row, col = start_row, start_col

    # Build the remaining k - 1 steps
    for _ in range(k - 1):
        best_next_value = float("inf")
        best_next_position = None

        for dr, dc in directions:
            nr, nc = row + dr, col + dc
            if 0 <= nr < n and 0 <= nc < n:
                if grid[nr][nc] < best_next_value:
                    best_next_value = grid[nr][nc]
                    best_next_position = (nr, nc)

        row, col = best_next_position
        path.append(best_next_value)

    return path
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
