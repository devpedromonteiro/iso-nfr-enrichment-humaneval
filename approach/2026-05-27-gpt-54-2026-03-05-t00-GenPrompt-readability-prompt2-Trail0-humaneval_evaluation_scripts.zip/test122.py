
import unittest
import re
import sys
import math
import copy


def add_elements(arr, k):
    """
    Return the sum of numbers with at most two digits
    among the first k elements of arr.

    A number has at most two digits if its absolute value is less than 100.

    Example:
        arr = [111, 21, 3, 4000, 5, 6, 7, 8, 9], k = 4
        -> 24  # 21 + 3
    """
    total = 0

    for value in arr[:k]:
        if abs(value) < 100:
            total += value

    return total
candidate = add_elements


def check(candidate):

    # Check some simple cases
    assert candidate([1,-2,-3,41,57,76,87,88,99], 3) == -4
    assert candidate([111,121,3,4000,5,6], 2) == 0
    assert candidate([11,21,3,90,5,6,7,8,9], 4) == 125
    assert candidate([111,21,3,4000,5,6,7,8,9], 4) == 24, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate([1], 1) == 1, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
