
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math


def poly(coefficients: list[float], x: float) -> float:
    """
    Evaluate a polynomial at point x.

    The polynomial is given by its coefficients:
        coefficients[0] + coefficients[1] * x + coefficients[2] * x^2 + ... + coefficients[n] * x^n

    Example:
        poly([1, 2], 3) = 1 + 2 * 3 = 7
    """
    return sum(coefficient * (x ** power) for power, coefficient in enumerate(coefficients))


def find_zero(coefficients: list[float], epsilon: float = 1e-12) -> float:
    """
    Find one real zero of a polynomial.

    Assumptions:
    - `coefficients` contains an even number of items, so the polynomial degree is odd.
    - The leading coefficient is non-zero.

    Under these assumptions, the polynomial is guaranteed to have at least one real root.

    The function returns one such root using binary search.

    >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2)  # (x - 1) * (x - 2) * (x - 3)
    1.0
    """
    if not coefficients:
        raise ValueError("coefficients must not be empty")

    if len(coefficients) % 2 != 0:
        raise ValueError("coefficients must contain an even number of items")

    if coefficients[-1] == 0:
        raise ValueError("leading coefficient must be non-zero")

    def f(x: float) -> float:
        return poly(coefficients, x)

    # Find an interval [left, right] where the polynomial changes sign.
    left = -1.0
    right = 1.0
    f_left = f(left)
    f_right = f(right)

    while f_left * f_right > 0:
        left *= 2
        right *= 2
        f_left = f(left)
        f_right = f(right)

    # Binary search for the root in [left, right].
    while right - left > epsilon:
        mid = (left + right) / 2
        f_mid = f(mid)

        if abs(f_mid) < epsilon:
            return mid

        if f_left * f_mid <= 0:
            right = mid
            f_right = f_mid
        else:
            left = mid
            f_left = f_mid

    return (left + right) / 2
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
