
import unittest
import re
import sys
import math
import copy


def circular_shift(x, shift):
    """Circularly shift the digits of x to the right by `shift`.

    Returns the result as a string.

    Rules:
    - Shift digits to the right by `shift` positions.
    - If `shift` is greater than the number of digits, return the digits reversed.

    Examples:
    >>> circular_shift(12, 1)
    '21'
    >>> circular_shift(12, 2)
    '12'
    """
    digits = str(x)
    length = len(digits)

    if shift > length:
        return digits[::-1]

    shift = shift % length
    return digits[-shift:] + digits[:-shift] if shift else digits
candidate = circular_shift


def check(candidate):

    # Check some simple cases
    assert candidate(100, 2) == "001"
    assert candidate(12, 2) == "12"
    assert candidate(97, 8) == "79"
    assert candidate(12, 1) == "21", "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(11, 101) == "11", "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
