
import unittest
import re
import sys
import math
import copy


def strange_sort_list(numbers):
    """
    Return the list in "strange" order:
    smallest, largest, second smallest, second largest, ...

    Examples:
    strange_sort_list([1, 2, 3, 4]) -> [1, 4, 2, 3]
    strange_sort_list([5, 5, 5, 5]) -> [5, 5, 5, 5]
    strange_sort_list([]) -> []
    """
    sorted_numbers = sorted(numbers)
    result = []

    left = 0
    right = len(sorted_numbers) - 1

    while left <= right:
        result.append(sorted_numbers[left])
        left += 1

        if left <= right:
            result.append(sorted_numbers[right])
            right -= 1

    return result
candidate = strange_sort_list


def check(candidate):

    # Check some simple cases
    assert candidate([1, 2, 3, 4]) == [1, 4, 2, 3]
    assert candidate([5, 6, 7, 8, 9]) == [5, 9, 6, 8, 7]
    assert candidate([1, 2, 3, 4, 5]) == [1, 5, 2, 4, 3]
    assert candidate([5, 6, 7, 8, 9, 1]) == [1, 9, 5, 8, 6, 7]
    assert candidate([5, 5, 5, 5]) == [5, 5, 5, 5]
    assert candidate([]) == []
    assert candidate([1,2,3,4,5,6,7,8]) == [1, 8, 2, 7, 3, 6, 4, 5]
    assert candidate([0,2,2,2,5,5,-5,-5]) == [-5, 5, -5, 5, 0, 2, 2, 2]
    assert candidate([111111]) == [111111]

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
