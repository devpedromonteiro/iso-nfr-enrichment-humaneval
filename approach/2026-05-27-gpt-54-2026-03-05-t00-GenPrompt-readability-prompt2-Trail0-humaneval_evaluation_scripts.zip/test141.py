
import unittest
import re
import sys
import math
import copy


def file_name_check(file_name):
    """Return 'Yes' if the file name is valid, otherwise return 'No'.

    Rules:
    - The file name must contain no more than 3 digits.
    - It must contain exactly one dot.
    - The part before the dot must be non-empty and start with a Latin letter.
    - The extension must be one of: 'txt', 'exe', 'dll'.
    """
    allowed_extensions = {"txt", "exe", "dll"}

    # Rule 1: no more than 3 digits in the whole file name
    digit_count = sum(char.isdigit() for char in file_name)
    if digit_count > 3:
        return "No"

    # Rule 2: exactly one dot
    if file_name.count(".") != 1:
        return "No"

    name_part, extension = file_name.split(".")

    # Rule 3: name part must not be empty and must start with a letter
    if not name_part or not name_part[0].isalpha():
        return "No"

    # Rule 4: extension must be valid
    if extension not in allowed_extensions:
        return "No"

    return "Yes"
candidate = file_name_check


def check(candidate):

    # Check some simple cases
    assert candidate("example.txt") == 'Yes'
    assert candidate("1example.dll") == 'No'
    assert candidate('s1sdf3.asd') == 'No'
    assert candidate('K.dll') == 'Yes'
    assert candidate('MY16FILE3.exe') == 'Yes'
    assert candidate('His12FILE94.exe') == 'No'
    assert candidate('_Y.txt') == 'No'
    assert candidate('?aREYA.exe') == 'No'
    assert candidate('/this_is_valid.dll') == 'No'
    assert candidate('this_is_valid.wow') == 'No'
    assert candidate('this_is_valid.txt') == 'Yes'
    assert candidate('this_is_valid.txtexe') == 'No'
    assert candidate('#this2_i4s_5valid.ten') == 'No'
    assert candidate('@this1_is6_valid.exe') == 'No'
    assert candidate('this_is_12valid.6exe4.txt') == 'No'
    assert candidate('all.exe.txt') == 'No'
    assert candidate('I563_No.exe') == 'Yes'
    assert candidate('Is3youfault.txt') == 'Yes'
    assert candidate('no_one#knows.dll') == 'Yes'
    assert candidate('1I563_Yes3.exe') == 'No'
    assert candidate('I563_Yes3.txtt') == 'No'
    assert candidate('final..txt') == 'No'
    assert candidate('final132') == 'No'
    assert candidate('_f4indsartal132.') == 'No'
    
        

    # Check some edge cases that are easy to work out by hand.
    assert candidate('.txt') == 'No'
    assert candidate('s.') == 'No'



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
