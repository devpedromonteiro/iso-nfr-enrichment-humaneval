
import unittest
import re
import sys
import math
import copy



def how_many_times(string: str, substring: str) -> int:
    """
    Return the number of times `substring` appears in `string`,
    including overlapping matches.

    Examples:
    >>> how_many_times('', 'a')
    0
    >>> how_many_times('aaa', 'a')
    3
    >>> how_many_times('aaaa', 'aa')
    3
    """
    if not string or not substring:
        return 0

    count = 0
    substring_length = len(substring)

    for index in range(len(string) - substring_length + 1):
        if string[index:index + substring_length] == substring:
            count += 1

    return count
candidate = how_many_times




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('', 'x') == 0
    assert candidate('xyxyxyx', 'x') == 4
    assert candidate('cacacacac', 'cac') == 4
    assert candidate('john doe', 'john') == 1


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
