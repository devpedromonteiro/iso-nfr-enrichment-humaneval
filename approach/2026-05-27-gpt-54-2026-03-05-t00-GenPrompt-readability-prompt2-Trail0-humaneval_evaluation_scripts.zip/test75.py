
import unittest
import re
import sys
import math
import copy


def is_prime(n):
    """Return True if n is a prime number, otherwise False."""
    if n < 2:
        return False

    for divisor in range(2, int(n ** 0.5) + 1):
        if n % divisor == 0:
            return False

    return True


def is_multiply_prime(a):
    """Return True if a can be written as the product of exactly 3 prime numbers."""
    for first in range(2, a):
        if not is_prime(first):
            continue

        for second in range(2, a):
            if not is_prime(second):
                continue

            for third in range(2, a):
                if not is_prime(third):
                    continue

                if first * second * third == a:
                    return True

    return False
candidate = is_multiply_prime


def check(candidate):

    assert candidate(5) == False
    assert candidate(30) == True
    assert candidate(8) == True
    assert candidate(10) == False
    assert candidate(125) == True
    assert candidate(3 * 5 * 7) == True
    assert candidate(3 * 6 * 7) == False
    assert candidate(9 * 9 * 9) == False
    assert candidate(11 * 9 * 9) == False
    assert candidate(11 * 13 * 7) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
