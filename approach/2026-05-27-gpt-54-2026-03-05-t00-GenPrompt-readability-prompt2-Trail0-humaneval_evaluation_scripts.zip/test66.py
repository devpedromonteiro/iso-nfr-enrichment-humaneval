
import unittest
import re
import sys
import math
import copy


def digitSum(text):
    """
    Return the sum of ASCII codes for uppercase letters in the input string.

    Examples:
        digitSum("") == 0
        digitSum("abAB") == 131
        digitSum("abcCd") == 67
        digitSum("helloE") == 69
        digitSum("woArBld") == 131
        digitSum("aAaaaXa") == 153
    """
    return sum(ord(char) for char in text if char.isupper())
candidate = digitSum


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate("") == 0, "Error"
    assert candidate("abAB") == 131, "Error"
    assert candidate("abcCd") == 67, "Error"
    assert candidate("helloE") == 69, "Error"
    assert candidate("woArBld") == 131, "Error"
    assert candidate("aAaaaXa") == 153, "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate(" How are yOu?") == 151, "Error"
    assert candidate("You arE Very Smart") == 327, "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
