
import unittest
import re
import sys
import math
import copy


def do_algebra(operators, operands):
    """
    Build and evaluate an algebraic expression from operators and operands.

    Args:
        operators (list[str]): A list of algebra operators such as
            '+', '-', '*', '//', '**'.
        operands (list[int]): A list of non-negative integers.

    Returns:
        int: The result of evaluating the expression.

    Example:
        operators = ['+', '*', '-']
        operands = [2, 3, 4, 5]

        Expression:
            2 + 3 * 4 - 5

        Result:
            9
    """
    expression = str(operands[0])

    for operator, operand in zip(operators, operands[1:]):
        expression += f" {operator} {operand}"

    return eval(expression)
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
