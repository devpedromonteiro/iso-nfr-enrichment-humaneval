
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    Return the number of triples (a[i], a[j], a[k]) with i < j < k such that
    a[i] + a[j] + a[k] is divisible by 3, where:

        a[i] = i^2 - i + 1   for 1 <= i <= n

    Observation:
    Since we only care about divisibility by 3, compute:

        a[i] = i^2 - i + 1 (mod 3)

    Checking i modulo 3:
        i % 3 == 0 -> a[i] % 3 == 1
        i % 3 == 1 -> a[i] % 3 == 1
        i % 3 == 2 -> a[i] % 3 == 0

    So every element is either:
        - 1 mod 3, or
        - 0 mod 3

    A triple sum is divisible by 3 only in these cases:
        1) 0 + 0 + 0
        2) 1 + 1 + 1

    Therefore:
        answer = C(count_0, 3) + C(count_1, 3)

    where:
        count_0 = number of indices i in [1..n] with i % 3 == 2
        count_1 = n - count_0
    """

    def comb3(x):
        """Return C(x, 3), or 0 if x < 3."""
        return x * (x - 1) * (x - 2) // 6 if x >= 3 else 0

    count_mod_0 = (n + 1) // 3   # indices where i % 3 == 2
    count_mod_1 = n - count_mod_0

    return comb3(count_mod_0) + comb3(count_mod_1)
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
