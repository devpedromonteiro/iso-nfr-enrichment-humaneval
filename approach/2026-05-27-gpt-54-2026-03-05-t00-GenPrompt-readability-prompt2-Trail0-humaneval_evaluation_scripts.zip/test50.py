
import unittest
import re
import sys
import math
import copy



def encode_shift(s: str):
    """
    returns encoded string by shifting every character by 5 in the alphabet.
    """
    return "".join([chr(((ord(ch) + 5 - ord("a")) % 26) + ord("a")) for ch in s])


SHIFT = 5
ALPHABET_SIZE = 26
ASCII_LOWERCASE_A = ord("a")


def shift_char(ch: str, shift: int) -> str:
    """Shift a lowercase character by the given amount within the alphabet."""
    return chr((ord(ch) - ASCII_LOWERCASE_A + shift) % ALPHABET_SIZE + ASCII_LOWERCASE_A)


def encode_shift(s: str) -> str:
    """
    Return a string encoded by shifting each lowercase character forward by 5.
    """
    return "".join(shift_char(ch, SHIFT) for ch in s)


def decode_shift(s: str) -> str:
    """
    Decode a string that was encoded with encode_shift.
    """
    return "".join(shift_char(ch, -SHIFT) for ch in s)
candidate = decode_shift




METADATA = {}


def check(candidate):
    from random import randint, choice
    import copy
    import string

    letters = string.ascii_lowercase
    for _ in range(100):
        str = ''.join(choice(letters) for i in range(randint(10, 20)))
        encoded_str = encode_shift(str)
        assert candidate(copy.deepcopy(encoded_str)) == str



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
