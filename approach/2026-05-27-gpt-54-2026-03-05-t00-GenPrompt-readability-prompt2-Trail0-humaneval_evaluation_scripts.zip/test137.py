
import unittest
import re
import sys
import math
import copy


def compare_one(a, b):
    """
    Compare two values that may be ints, floats, or strings representing real numbers.

    Returns:
        - the larger original value (preserving its original type)
        - None if both values are numerically equal

    Notes:
        - Strings may use either "." or "," as the decimal separator.
        - Comparison is done numerically, but the returned value is the original input.

    Examples:
        compare_one(1, 2.5)      -> 2.5
        compare_one(1, "2,3")    -> "2,3"
        compare_one("5,1", "6")  -> "6"
        compare_one("1", 1)      -> None
    """

    def to_number(value):
        """Convert value to a float for comparison."""
        if isinstance(value, str):
            value = value.replace(",", ".")
        return float(value)

    num_a = to_number(a)
    num_b = to_number(b)

    if num_a == num_b:
        return None
    return a if num_a > num_b else b
candidate = compare_one


def check(candidate):

    # Check some simple cases
    assert candidate(1, 2) == 2
    assert candidate(1, 2.5) == 2.5
    assert candidate(2, 3) == 3
    assert candidate(5, 6) == 6
    assert candidate(1, "2,3") == "2,3"
    assert candidate("5,1", "6") == "6"
    assert candidate("1", "2") == "2"
    assert candidate("1", 1) == None

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
