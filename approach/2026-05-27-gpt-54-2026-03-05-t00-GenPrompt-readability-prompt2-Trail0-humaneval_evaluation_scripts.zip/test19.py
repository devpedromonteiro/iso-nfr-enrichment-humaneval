
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import Dict, List

WORD_TO_VALUE: Dict[str, int] = {
    "zero": 0,
    "one": 1,
    "two": 2,
    "three": 3,
    "four": 4,
    "five": 5,
    "six": 6,
    "seven": 7,
    "eight": 8,
    "nine": 9,
}


def sort_numbers(numbers: str) -> str:
    """Sort space-delimited number words from smallest to largest.

    Input must contain number words from "zero" to "nine", separated by spaces.

    >>> sort_numbers("three one five")
    'one three five'
    """
    number_words: List[str] = numbers.split()
    sorted_words = sorted(number_words, key=lambda word: WORD_TO_VALUE[word])
    return " ".join(sorted_words)
candidate = sort_numbers




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == ''
    assert candidate('three') == 'three'
    assert candidate('three five nine') == 'three five nine'
    assert candidate('five zero four seven nine eight') == 'zero four five seven eight nine'
    assert candidate('six five four three two one zero') == 'zero one two three four five six'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
