
import unittest
import re
import sys
import math
import copy


def f(n):
    """
    Return a list of length n where:
    - for odd i, the value is the sum of numbers from 1 to i
    - for even i, the value is i!

    Indexing starts from 1.

    Example:
        f(5) -> [1, 2, 6, 24, 15]
    """
    result = []

    for i in range(1, n + 1):
        if i % 2 == 0:
            # Compute factorial for even i
            factorial = 1
            for num in range(1, i + 1):
                factorial *= num
            result.append(factorial)
        else:
            # Compute sum from 1 to i for odd i
            total = 0
            for num in range(1, i + 1):
                total += num
            result.append(total)

    return result
candidate = f


def check(candidate):

    assert candidate(5) == [1, 2, 6, 24, 15]
    assert candidate(7) == [1, 2, 6, 24, 15, 720, 28]
    assert candidate(1) == [1]
    assert candidate(3) == [1, 2, 6]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
