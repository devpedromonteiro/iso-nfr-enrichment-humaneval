
import unittest
import re
import sys
import math
import copy


import math

def max_fill(grid, capacity):
    """
    Return the total number of bucket lowers needed to empty all wells.

    Each row in `grid` represents one well.
    Each `1` in a row represents one unit of water.
    A bucket can remove at most `capacity` units of water per lower.

    So for each row:
        lowers_needed = ceil(units_of_water / capacity)

    The final answer is the sum across all rows.

    Examples:
        max_fill([[0,0,1,0], [0,1,0,0], [1,1,1,1]], 1) -> 6
        max_fill([[0,0,1,1], [0,0,0,0], [1,1,1,1], [0,1,1,1]], 2) -> 5
        max_fill([[0,0,0], [0,0,0]], 5) -> 0
    """
    total_lowers = 0

    for well in grid:
        water_units = sum(well)
        total_lowers += math.ceil(water_units / capacity)

    return total_lowers
candidate = max_fill


def check(candidate):


    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([[0,0,1,0], [0,1,0,0], [1,1,1,1]], 1) == 6, "Error"
    assert candidate([[0,0,1,1], [0,0,0,0], [1,1,1,1], [0,1,1,1]], 2) == 5, "Error"
    assert candidate([[0,0,0], [0,0,0]], 5) == 0, "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([[1,1,1,1], [1,1,1,1]], 2) == 4, "Error"
    assert candidate([[1,1,1,1], [1,1,1,1]], 9) == 2, "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
