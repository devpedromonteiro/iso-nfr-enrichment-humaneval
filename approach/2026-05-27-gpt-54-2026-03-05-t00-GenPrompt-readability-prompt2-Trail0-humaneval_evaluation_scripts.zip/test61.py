
import unittest
import re
import sys
import math
import copy



def correct_bracketing(brackets: str) -> bool:
    """Return True if the parentheses in `brackets` are balanced.

    A string is correctly bracketed when:
    - every opening "(" has a matching closing ")"
    - no closing bracket appears before its matching opening bracket

    >>> correct_bracketing("(")
    False
    >>> correct_bracketing("()")
    True
    >>> correct_bracketing("(()())")
    True
    >>> correct_bracketing(")(()")
    False
    """
    balance = 0

    for bracket in brackets:
        if bracket == "(":
            balance += 1
        else:  # bracket == ")"
            balance -= 1

        # More closing brackets than opening ones at some point
        if balance < 0:
            return False

    # All opening brackets must be closed
    return balance == 0
candidate = correct_bracketing




METADATA = {}


def check(candidate):
    assert candidate("()")
    assert candidate("(()())")
    assert candidate("()()(()())()")
    assert candidate("()()((()()())())(()()(()))")
    assert not candidate("((()())))")
    assert not candidate(")(()")
    assert not candidate("(")
    assert not candidate("((((")
    assert not candidate(")")
    assert not candidate("(()")
    assert not candidate("()()(()())())(()")
    assert not candidate("()()(()())()))()")



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
