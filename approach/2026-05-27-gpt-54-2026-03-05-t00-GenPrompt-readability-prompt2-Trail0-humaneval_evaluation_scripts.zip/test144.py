
import unittest
import re
import sys
import math
import copy


from math import gcd


def simplify(x: str, n: str) -> bool:
    """
    Return True if the product of fractions x and n is a whole number.

    Both x and n are strings in the form "numerator/denominator".

    Examples:
        simplify("1/5", "5/1")   -> True
        simplify("1/6", "2/1")   -> False
        simplify("7/10", "10/2") -> False
    """

    def parse_fraction(fraction: str) -> tuple[int, int]:
        numerator, denominator = map(int, fraction.split("/"))
        return numerator, denominator

    x_num, x_den = parse_fraction(x)
    n_num, n_den = parse_fraction(n)

    # Multiply the fractions:
    # (x_num / x_den) * (n_num / n_den) = (x_num * n_num) / (x_den * n_den)
    numerator = x_num * n_num
    denominator = x_den * n_den

    # Reduce the fraction and check whether the denominator becomes 1
    common_divisor = gcd(numerator, denominator)
    simplified_denominator = denominator // common_divisor

    return simplified_denominator == 1
candidate = simplify


def check(candidate):

    # Check some simple cases
    assert candidate("1/5", "5/1") == True, 'test1'
    assert candidate("1/6", "2/1") == False, 'test2'
    assert candidate("5/1", "3/1") == True, 'test3'
    assert candidate("7/10", "10/2") == False, 'test4'
    assert candidate("2/10", "50/10") == True, 'test5'
    assert candidate("7/2", "4/2") == True, 'test6'
    assert candidate("11/6", "6/1") == True, 'test7'
    assert candidate("2/3", "5/2") == False, 'test8'
    assert candidate("5/2", "3/5") == False, 'test9'
    assert candidate("2/4", "8/4") == True, 'test10'


    # Check some edge cases that are easy to work out by hand.
    assert candidate("2/4", "4/2") == True, 'test11'
    assert candidate("1/5", "5/1") == True, 'test12'
    assert candidate("1/5", "1/5") == False, 'test13'



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
