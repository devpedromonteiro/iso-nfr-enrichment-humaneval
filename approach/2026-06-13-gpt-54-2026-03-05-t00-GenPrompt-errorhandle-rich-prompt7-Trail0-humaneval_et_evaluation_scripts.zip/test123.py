
import unittest


def get_odd_collatz(n):
    """
    Given a positive integer n, return a sorted list containing the odd numbers
    in the Collatz sequence for n.

    The returned list is sorted in increasing order.

    Args:
        n: A positive integer.

    Returns:
        A sorted list of odd integers from the Collatz sequence.

    Raises:
        TypeError: If n is not an integer.
        ValueError: If n is not a positive integer.
    """
    if isinstance(n, bool) or not isinstance(n, int):
        raise TypeError("n must be an integer")
    if n <= 0:
        raise ValueError("n must be a positive integer")

    odd_numbers = set()
    current = n

    while True:
        if current % 2 == 1:
            odd_numbers.add(current)

        if current == 1:
            break

        if current % 2 == 0:
            current //= 2
        else:
            current = 3 * current + 1

    return sorted(odd_numbers)
candidate = get_odd_collatz


class Test(unittest.TestCase):
    def test(self):
        assert candidate(57) == [1, 5, 7, 11, 13, 17, 37, 43, 49, 57, 65]
        assert candidate(12) == [1, 3, 5]
        assert candidate(20) == [1, 5]
        assert candidate(58) == [1, 5, 11, 13, 17, 29]
        assert candidate(29) == [1, 5, 11, 13, 17, 29]
        assert candidate(68) == [1, 5, 13, 17]
        assert candidate(30) == [1, 5, 15, 23, 35, 53]
        assert candidate(16) == [1]
        assert candidate(31) == [1, 5, 23, 31, 35, 47, 53, 61, 71, 91, 103, 107, 121, 137, 155, 161, 167, 175, 233, 251, 263, 283, 319, 325, 377, 395, 425, 433, 445, 479, 577, 593, 719, 911, 1079, 1367, 1619, 2051, 2429, 3077]
        assert candidate(66) == [1, 5, 11, 13, 17, 19, 25, 29, 33]
        assert candidate(17) == [1, 5, 13, 17]
        assert candidate(84) == [1, 21]
        assert candidate(62) == [1, 5, 23, 31, 35, 47, 53, 61, 71, 91, 103, 107, 121, 137, 155, 161, 167, 175, 233, 251, 263, 283, 319, 325, 377, 395, 425, 433, 445, 479, 577, 593, 719, 911, 1079, 1367, 1619, 2051, 2429, 3077]
        assert candidate(92) == [1, 5, 23, 35, 53]
        assert candidate(75) == [1, 75, 85, 113]
        assert candidate(12) == [1, 3, 5]
        assert candidate(44) == [1, 5, 11, 13, 17]
        assert candidate(81) == [1, 5, 23, 35, 53, 61, 81]
        assert candidate(35) == [1, 5, 35, 53]
        assert candidate(3) == [1, 3, 5]
        assert candidate(8) == [1]
        assert candidate(63) == [1, 5, 23, 35, 53, 61, 63, 91, 95, 103, 137, 143, 155, 167, 175, 215, 233, 251, 263, 283, 319, 323, 325, 377, 395, 425, 433, 445, 479, 485, 577, 593, 719, 911, 1079, 1367, 1619, 2051, 2429, 3077]
        assert candidate(23) == [1, 5, 23, 35, 53]
        assert candidate(1) == [1]
        assert candidate(52) == [1, 5, 13]
        assert candidate(89) == [1, 5, 11, 13, 17, 19, 29, 67, 89, 101]
        assert candidate(100) == [1, 5, 11, 13, 17, 19, 25, 29]
        assert candidate(4) == [1]
        assert candidate(56) == [1, 5, 7, 11, 13, 17]
        assert candidate(18) == [1, 5, 7, 9, 11, 13, 17]
        assert candidate(60) == [1, 5, 15, 23, 35, 53]
        assert candidate(43) == [1, 5, 7, 11, 13, 17, 37, 43, 49, 65]
        assert candidate(38) == [1, 5, 11, 13, 17, 19, 29]
        assert candidate(46) == [1, 5, 23, 35, 53]
        assert candidate(37) == [1, 5, 7, 11, 13, 17, 37]
        assert candidate(11) == [1, 5, 11, 13, 17]
        assert candidate(25) == [1, 5, 11, 13, 17, 19, 25, 29]
        assert candidate(70) == [1, 5, 35, 53]
        assert candidate(59) == [1, 5, 11, 13, 17, 19, 29, 59, 67, 89, 101]
        assert candidate(79) == [1, 5, 11, 13, 17, 19, 29, 79, 101, 119, 179, 269]
        assert candidate(40) == [1, 5]
        assert candidate(61) == [1, 5, 23, 35, 53, 61]
        assert candidate(88) == [1, 5, 11, 13, 17]
        assert candidate(77) == [1, 5, 11, 13, 17, 29, 77]
        assert candidate(67) == [1, 5, 11, 13, 17, 19, 29, 67, 101]
        assert candidate(80) == [1, 5]
        assert candidate(96) == [1, 3, 5]
        assert candidate(51) == [1, 5, 11, 13, 17, 29, 51, 77]
        assert candidate(73) == [1, 5, 23, 35, 47, 53, 55, 61, 71, 73, 83, 91, 103, 107, 121, 125, 137, 155, 161, 167, 175, 233, 251, 263, 283, 319, 325, 377, 395, 425, 433, 445, 479, 577, 593, 719, 911, 1079, 1367, 1619, 2051, 2429, 3077]
        assert candidate(69) == [1, 5, 13, 69]
        assert candidate(72) == [1, 5, 7, 9, 11, 13, 17]
        assert candidate(22) == [1, 5, 11, 13, 17]
        assert candidate(94) == [1, 5, 23, 35, 47, 53, 61, 71, 91, 103, 107, 121, 137, 155, 161, 167, 175, 233, 251, 263, 283, 319, 325, 377, 395, 425, 433, 445, 479, 577, 593, 719, 911, 1079, 1367, 1619, 2051, 2429, 3077]
        assert candidate(28) == [1, 5, 7, 11, 13, 17]
        assert candidate(95) == [1, 5, 23, 35, 53, 61, 91, 95, 103, 137, 143, 155, 167, 175, 215, 233, 251, 263, 283, 319, 323, 325, 377, 395, 425, 433, 445, 479, 485, 577, 593, 719, 911, 1079, 1367, 1619, 2051, 2429, 3077]
        assert candidate(36) == [1, 5, 7, 9, 11, 13, 17]
        assert candidate(5) == [1, 5]
        assert candidate(82) == [1, 5, 23, 31, 35, 41, 47, 53, 61, 71, 91, 103, 107, 121, 137, 155, 161, 167, 175, 233, 251, 263, 283, 319, 325, 377, 395, 425, 433, 445, 479, 577, 593, 719, 911, 1079, 1367, 1619, 2051, 2429, 3077]
        assert candidate(49) == [1, 5, 7, 11, 13, 17, 37, 49]
        assert candidate(87) == [1, 5, 7, 11, 13, 17, 37, 87, 131, 197]
        assert candidate(1) == [1]
        assert candidate(21) == [1, 21]
        assert candidate(10) == [1, 5]
        assert candidate(19) == [1, 5, 11, 13, 17, 19, 29]
        assert candidate(93) == [1, 5, 35, 53, 93]
        assert candidate(34) == [1, 5, 13, 17]
        assert candidate(32) == [1]
        assert candidate(53) == [1, 5, 53]
        assert candidate(78) == [1, 5, 11, 13, 17, 19, 29, 39, 59, 67, 89, 101]
        assert candidate(24) == [1, 3, 5]
        assert candidate(33) == [1, 5, 11, 13, 17, 19, 25, 29, 33]
        assert candidate(15) == [1, 5, 15, 23, 35, 53]
        assert candidate(14) == [1, 5, 7, 11, 13, 17]

if __name__ == '__main__':
    unittest.main()
