
import unittest


def reverse_delete(s, c):
    """Remove from s all characters that appear in c, then check if the result is a palindrome.

    Args:
        s (str): Source string.
        c (str): Characters to remove from s.

    Returns:
        tuple[str, bool]: A tuple of (filtered_string, is_palindrome).

    Raises:
        TypeError: If s or c is not a string.
        ValueError: If s or c is None.
    """
    if s is None or c is None:
        raise ValueError("Inputs 's' and 'c' must not be None.")

    if not isinstance(s, str):
        raise TypeError(f"Input 's' must be of type str, got {type(s).__name__}.")
    if not isinstance(c, str):
        raise TypeError(f"Input 'c' must be of type str, got {type(c).__name__}.")

    try:
        chars_to_remove = set(c)
        result = "".join(ch for ch in s if ch not in chars_to_remove)
        is_palindrome = result == result[::-1]
        return result, is_palindrome
    except Exception as exc:
        raise RuntimeError("Failed to process reverse_delete operation.") from exc
candidate = reverse_delete


class Test(unittest.TestCase):
    def test(self):
        assert candidate('foykuf', 'kr') == ('foyuf', False)
        assert candidate('hekrw', 'bkeirip') == ('hw', False)
        assert candidate('xqfvdunvktkfjx', 'z') == ('xqfvdunvktkfjx', False)
        assert candidate('hsjs', 'j') == ('hss', False)
        assert candidate("mamma", "mia") == ("", True)
        assert candidate('edzw', 'zmwt') == ('ed', False)
        assert candidate('qwgwt', 't') == ('qwgw', False)
        assert candidate('iufxejqwc', 'l') == ('iufxejqwc', False)
        assert candidate('lfmxfbalnkb', 'o') == ('lfmxfbalnkb', False)
        assert candidate('zuhw', 'wmkcu') == ('zh', False)
        assert candidate('dahyb', 'zxgbehahj') == ('dy', False)
        assert candidate('lsnvhjucpduae', 'sxqlk') == ('nvhjucpduae', False)
        assert candidate('h', 'n') == ('h', True)
        assert candidate('keeviwsiwcx', 'h') == ('keeviwsiwcx', False)
        assert candidate('slyyhbixlapcvrw', 'qzrzyd') == ('slhbixlapcvw', False)
        assert candidate('gngvwzmgrie', 'wcfd') == ('gngvzmgrie', False)
        assert candidate('c', 'd') == ('c', True)
        assert candidate('pdpflwpnyou', 'n') == ('pdpflwpyou', False)
        assert candidate("abcde","ae") == ('bcd',False)
        assert candidate('zddkptut', 's') == ('zddkptut', False)
        assert candidate('nqfqjdw', 'tlvtok') == ('nqfqjdw', False)
        assert candidate('ovvchivfesdnzee', 'xrkym') == ('ovvchivfesdnzee', False)
        assert candidate('ejywjnnguvxzzne', 'x') == ('ejywjnnguvzzne', False)
        assert candidate('bvjfmwzwv', 'anz') == ('bvjfmwwv', False)
        assert candidate('nlwjpcnc', 'kj') == ('nlwpcnc', False)
        assert candidate('tikrit', 'y') == ('tikrit', False)
        assert candidate('zwvtfe', 'xiq') == ('zwvtfe', False)
        assert candidate('abnjeb', 'a') == ('bnjeb', False)
        assert candidate("abcdedcba","ab") == ('cdedc',True)
        assert candidate('squtkmvrpmxi', 'i') == ('squtkmvrpmx', False)
        assert candidate('tovgjfskcu', 'j') == ('tovgfskcu', False)
        assert candidate('fcolefdp', 't') == ('fcolefdp', False)
        assert candidate('bidipogteb', 'e') == ('bidipogtb', False)
        assert candidate('q', 'g') == ('q', True)
        assert candidate('rrs', 'j') == ('rrs', False)
        assert candidate('arrvtwoe', 'zvxaao') == ('rrtwe', False)
        assert candidate("abcdef", "b") == ('acdef',False)
        assert candidate('yyi', 'ndx') == ('yyi', False)
        assert candidate('qgx', 'dyia') == ('qgx', False)
        assert candidate("abcdedcba","v") == ('abcdedcba',True)
        assert candidate('fciyayatwwev', 'r') == ('fciyayatwwev', False)
        assert candidate('fuqqnaxcd', 'n') == ('fuqqaxcd', False)
        assert candidate('lhr', 'h') == ('lr', False)
        assert candidate('o', 'l') == ('o', True)
        assert candidate('ptucpefoeswx', 'y') == ('ptucpefoeswx', False)
        assert candidate('xobcogdevmjda', 'q') == ('xobcogdevmjda', False)
        assert candidate('vagijbi', 'j') == ('vagibi', False)
        assert candidate('h', 't') == ('h', True)
        assert candidate('t', 'w') == ('t', True)
        assert candidate('tvfx', 'b') == ('tvfx', False)
        assert candidate('jmyuypfd', 'ykchk') == ('jmupfd', False)
        assert candidate('nrgjjngx', 'a') == ('nrgjjngx', False)
        assert candidate("a","a") == ('',True)
        assert candidate('aia', 't') == ('aia', True)
        assert candidate('thtflwmws', 'zcxtm') == ('hflwws', False)
        assert candidate("abcdedcba","") == ('abcdedcba',True)
        assert candidate('jgwqwgbefwsiz', 'w') == ('jgqgbefsiz', False)
        assert candidate('blyzlhnmlqnn', 'i') == ('blyzlhnmlqnn', False)
        assert candidate('xfhio', 'u') == ('xfhio', False)
        assert candidate('mniqmjy', 'xhe') == ('mniqmjy', False)
        assert candidate('d', 'h') == ('d', True)
        assert candidate('plzitgbsboly', 'v') == ('plzitgbsboly', False)
        assert candidate('zwrhlh', 'ivktpy') == ('zwrhlh', False)
        assert candidate('z', 'v') == ('z', True)
        assert candidate('dbuygmfnkii', 'o') == ('dbuygmfnkii', False)
        assert candidate('lekkc', 'nizlup') == ('ekkc', False)
        assert candidate('ovytondmfhurx', 'giutpo') == ('vyndmfhrx', False)
        assert candidate("vabba","v") == ('abba',True)
        assert candidate('vjp', 'l') == ('vjp', False)
        assert candidate('yfemjie', 'i') == ('yfemje', False)
        assert candidate('toeu', 'lbgzto') == ('eu', False)
        assert candidate('vmpgswphznw', 'z') == ('vmpgswphnw', False)
        assert candidate('u', 'e') == ('u', True)
        assert candidate('onpy', 'dzrc') == ('onpy', False)
        assert candidate('noat', 'zjmg') == ('noat', False)
        assert candidate('gzts', 'z') == ('gts', False)
        assert candidate('dbybvrsyblrwpi', 'sqm') == ('dbybvryblrwpi', False)
        assert candidate('cjiyggtsoqcuhuu', 'qql') == ('cjiyggtsocuhuu', False)
        assert candidate('pbeyehmn', 'hicw') == ('pbeyemn', False)
        assert candidate('i', 'f') == ('i', True)
        assert candidate('fcbtofx', 'a') == ('fcbtofx', False)
        assert candidate('ksfvx', 'fglwvgd') == ('ksx', False)
        assert candidate('rzfyurtld', 'n') == ('rzfyurtld', False)
        assert candidate('wbpv', 'nnpvcperv') == ('wb', False)
        assert candidate('xcqsxmllm', 'joey') == ('xcqsxmllm', False)
        assert candidate('elly', 'qyeboj') == ('ll', True)
        assert candidate('rfrwhwi', 'vpuf') == ('rrwhwi', False)
        assert candidate('nrhkr', 'p') == ('nrhkr', False)
        assert candidate('ior', 'adpk') == ('ior', False)
        assert candidate('laxepw', 'e') == ('laxpw', False)
        assert candidate('kskh', 'bqmu') == ('kskh', False)
        assert candidate('wczeqsnib', 'e') == ('wczqsnib', False)
        assert candidate('hoqxvvmle', 'zjy') == ('hoqxvvmle', False)
        assert candidate('orm', 'a') == ('orm', False)
        assert candidate('mlltftbw', 'aaeqkz') == ('mlltftbw', False)
        assert candidate('wsqlilxao', 'z') == ('wsqlilxao', False)
        assert candidate('pgsqectg', 'wqbkvn') == ('pgsectg', False)
        assert candidate('dyauaigkyl', 'x') == ('dyauaigkyl', False)
        assert candidate('frdzjcdrxn', 'i') == ('frdzjcdrxn', False)
        assert candidate('xtwqdmbqwj', 'emb') == ('xtwqdqwj', False)
        assert candidate('klfixuynt', 'q') == ('klfixuynt', False)
        assert candidate('apewbuhby', 'nfp') == ('aewbuhby', False)
        assert candidate('wbaehwkm', 'g') == ('wbaehwkm', False)
        assert candidate('nnkwsqy', 'm') == ('nnkwsqy', False)
        assert candidate('iwkhapzilupkyyg', 'h') == ('iwkapzilupkyyg', False)
        assert candidate('pcqrus', 't') == ('pcqrus', False)
        assert candidate('ltnalh', 'h') == ('ltnal', False)
        assert candidate('i', 'i') == ('', True)
        assert candidate('wkwm', 'q') == ('wkwm', False)
        assert candidate('aigbd', 'xrfsbh') == ('aigd', False)
        assert candidate('nwskifsihaem', 'bcx') == ('nwskifsihaem', False)
        assert candidate('uewzybhhlo', 'm') == ('uewzybhhlo', False)
        assert candidate('pmonxbjingmp', 'zrhsdd') == ('pmonxbjingmp', False)
        assert candidate('rpsveo', 't') == ('rpsveo', False)
        assert candidate('fjrnrgzlbr', 'b') == ('fjrnrgzlr', False)
        assert candidate('cywbg', 'r') == ('cywbg', False)
        assert candidate('jltmfeiq', 'mbst') == ('jlfeiq', False)
        assert candidate('g', 's') == ('g', True)
        assert candidate('aaath', 'v') == ('aaath', False)
        assert candidate('uctcbtx', 'w') == ('uctcbtx', False)
        assert candidate('uttzaxhqphjikef', 's') == ('uttzaxhqphjikef', False)
        assert candidate('p', 'l') == ('p', True)
        assert candidate('slfocylsw', 'p') == ('slfocylsw', False)
        assert candidate('hoxlpyprusuch', 'khb') == ('oxlpyprusuc', False)
        assert candidate('jrijhuql', 'b') == ('jrijhuql', False)
        assert candidate('bgoysxv', 'z') == ('bgoysxv', False)
        assert candidate("dwik","w") == ('dik',False)
        assert candidate('bdyxulrsnqe', 'whz') == ('bdyxulrsnqe', False)
        assert candidate('xqfoondu', 'h') == ('xqfoondu', False)
        assert candidate('bfexlxcpk', 'ed') == ('bfxlxcpk', False)
        assert candidate('sdgrjwfrhonmpk', 'ljqr') == ('sdgwfhonmpk', False)
        assert candidate('d', 'x') == ('d', True)
        assert candidate('bpscieh', 'fodcicggw') == ('bpseh', False)
        assert candidate('puhwartp', 'y') == ('puhwartp', False)
        assert candidate('bnuuch', 'n') == ('buuch', False)

if __name__ == '__main__':
    unittest.main()
