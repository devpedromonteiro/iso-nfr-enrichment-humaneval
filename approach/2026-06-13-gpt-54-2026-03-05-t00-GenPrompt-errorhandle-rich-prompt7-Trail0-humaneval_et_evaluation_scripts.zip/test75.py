
import unittest


def is_multiply_prime(a):
    """Return True if `a` is the product of exactly 3 prime numbers, else False.

    A prime factor may repeat, e.g. 8 = 2 * 2 * 2 -> True.

    Constraints handled:
    - validates input type and value explicitly
    - raises specific exceptions for invalid arguments
    - does not silently swallow errors
    """
    if isinstance(a, bool):
        raise TypeError("a must be an integer, not bool")
    if not isinstance(a, int):
        raise TypeError("a must be an integer")
    if a < 0:
        raise ValueError("a must be non-negative")
    if a >= 100:
        raise ValueError("a must be less than 100")

    def is_prime(n):
        if n < 2:
            return False
        for i in range(2, int(n ** 0.5) + 1):
            if n % i == 0:
                return False
        return True

    prime_factors_count = 0
    remaining = a

    for i in range(2, a + 1):
        while remaining % i == 0:
            if not is_prime(i):
                return False
            prime_factors_count += 1
            remaining //= i
            if prime_factors_count > 3:
                return False

    return prime_factors_count == 3 and remaining == 1
candidate = is_multiply_prime


class Test(unittest.TestCase):
    def test(self):
        assert candidate(121) == False
        assert candidate(890) == True
        assert candidate(894) == False
        assert candidate(734) == False
        assert candidate(122) == False
        assert candidate(32) == False
        assert candidate(130) == True
        assert candidate(106) == False
        assert candidate(109) == False
        assert candidate(728) == False
        assert candidate(893) == False
        assert candidate(889) == False
        assert candidate(31) == False
        assert candidate(729) == False
        assert candidate(25) == False
        assert candidate(8) == True
        assert candidate(127) == False
        assert candidate(7) == False
        assert candidate(125) == True
        assert candidate(104) == False
        assert candidate(724) == False
        assert candidate(131) == False
        assert candidate(887) == False
        assert candidate(3) == False
        assert candidate(895) == False
        assert candidate(725) == True
        assert candidate(9 * 9 * 9) == False
        assert candidate(10) == False
        assert candidate(128) == False
        assert candidate(891) == False
        assert candidate(1) == False
        assert candidate(6) == False
        assert candidate(727) == False
        assert candidate(14) == False
        assert candidate(3 * 6 * 7) == False
        assert candidate(9) == False
        assert candidate(124) == True
        assert candidate(126) == False
        assert candidate(27) == True
        assert candidate(26) == False
        assert candidate(726) == False
        assert candidate(2) == False
        assert candidate(30) == True
        assert candidate(13) == False
        assert candidate(5) == False
        assert candidate(11 * 9 * 9) == False
        assert candidate(129) == False
        assert candidate(12) == True
        assert candidate(11) == False
        assert candidate(107) == False
        assert candidate(3 * 5 * 7) == True
        assert candidate(101) == False
        assert candidate(28) == True
        assert candidate(11 * 13 * 7) == True
        assert candidate(730) == True
        assert candidate(110) == True

if __name__ == '__main__':
    unittest.main()
