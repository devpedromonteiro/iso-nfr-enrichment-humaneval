
import unittest
import re
import sys
import math
import copy



def is_palindrome(string: str) -> bool:
    """ Test if given string is a palindrome """
    return string == string[::-1]


def is_palindrome(string: str) -> bool:
    """Test if given string is a palindrome."""
    return string == string[::-1]


def make_palindrome(string: str) -> str:
    """Find the shortest palindrome that begins with a supplied string.

    Algorithm:
    - Find the longest suffix of the string that is a palindrome.
    - Append the reverse of the remaining prefix.

    >>> make_palindrome('')
    ''
    >>> make_palindrome('cat')
    'catac'
    >>> make_palindrome('cata')
    'catac'
    """
    n = len(string)
    if n < 2:
        return string

    for i in range(n):
        left, right = i, n - 1
        while left < right and string[left] == string[right]:
            left += 1
            right -= 1
        if left >= right:
            return string + string[:i][::-1]

    return string + string[:-1][::-1]
candidate = make_palindrome




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == ''
    assert candidate('x') == 'x'
    assert candidate('xyz') == 'xyzyx'
    assert candidate('xyx') == 'xyx'
    assert candidate('jerry') == 'jerryrrej'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
