
import unittest
import re
import sys
import math
import copy


def is_bored(S):
    count = 0
    start_of_sentence = True
    i = 0
    n = len(S)

    while i < n:
        ch = S[i]

        if ch in ".!?":
            start_of_sentence = True
            i += 1
            continue

        if start_of_sentence:
            while i < n and S[i] == " ":
                i += 1

            if i < n:
                if S[i] == "I" and (i + 1 == n or S[i + 1] in " .!?"):
                    count += 1
                start_of_sentence = False
            continue

        i += 1

    return count
candidate = is_bored


def check(candidate):

    # Check some simple cases
    assert candidate("Hello world") == 0, "Test 1"
    assert candidate("Is the sky blue?") == 0, "Test 2"
    assert candidate("I love It !") == 1, "Test 3"
    assert candidate("bIt") == 0, "Test 4"
    assert candidate("I feel good today. I will be productive. will kill It") == 2, "Test 5"
    assert candidate("You and I are going for a walk") == 0, "Test 6"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
