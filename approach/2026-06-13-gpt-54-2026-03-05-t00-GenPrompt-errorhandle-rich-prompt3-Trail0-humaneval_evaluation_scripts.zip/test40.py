
import unittest
import re
import sys
import math
import copy



def triples_sum_to_zero(l: list):
    """
    triples_sum_to_zero takes a list of integers as input.
    It returns True if there are three distinct elements in the list that
    sum to zero, and False otherwise.

    Error handling:
    - Raises TypeError if `l` is not a list.
    - Raises TypeError if any element of `l` is not an integer.

    >>> triples_sum_to_zero([1, 3, 5, 0])
    False
    >>> triples_sum_to_zero([1, 3, -2, 1])
    True
    >>> triples_sum_to_zero([1, 2, 3, 7])
    False
    >>> triples_sum_to_zero([2, 4, -5, 3, 9, 7])
    True
    >>> triples_sum_to_zero([1])
    False
    """
    if not isinstance(l, list):
        raise TypeError(f"Expected a list, got {type(l).__name__}")

    for i, value in enumerate(l):
        if not isinstance(value, int):
            raise TypeError(
                f"All elements must be integers; element at index {i} "
                f"is {type(value).__name__}"
            )

    n = len(l)
    if n < 3:
        return False

    for i in range(n - 2):
        seen = set()
        target = -l[i]
        for j in range(i + 1, n):
            needed = target - l[j]
            if needed in seen:
                return True
            seen.add(l[j])

    return False
candidate = triples_sum_to_zero




METADATA = {}


def check(candidate):
    assert candidate([1, 3, 5, 0]) == False
    assert candidate([1, 3, 5, -1]) == False
    assert candidate([1, 3, -2, 1]) == True
    assert candidate([1, 2, 3, 7]) == False
    assert candidate([1, 2, 5, 7]) == False
    assert candidate([2, 4, -5, 3, 9, 7]) == True
    assert candidate([1]) == False
    assert candidate([1, 3, 5, -100]) == False
    assert candidate([100, 3, 5, -100]) == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
