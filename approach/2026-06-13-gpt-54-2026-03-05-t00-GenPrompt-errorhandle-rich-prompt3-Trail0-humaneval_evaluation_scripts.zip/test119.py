
import unittest
import re
import sys
import math
import copy


def match_parens(lst):
    '''
    You are given a list of two strings, both strings consist of open
    parentheses '(' or close parentheses ')' only.
    Your job is to check if it is possible to concatenate the two strings in
    some order, that the resulting string will be good.
    A string S is considered to be good if and only if all parentheses in S
    are balanced. For example: the string '(())()' is good, while the string
    '())' is not.
    Return 'Yes' if there's a way to make a good string, and return 'No' otherwise.

    Examples:
    match_parens(['()(', ')']) == 'Yes'
    match_parens([')', ')']) == 'No'
    '''
    if not isinstance(lst, list):
        raise TypeError("lst must be a list of exactly two strings")

    if len(lst) != 2:
        raise ValueError("lst must contain exactly two strings")

    for i, item in enumerate(lst):
        if not isinstance(item, str):
            raise TypeError(f"lst[{i}] must be a string")
        invalid_chars = set(item) - {"(", ")"}
        if invalid_chars:
            raise ValueError(
                f"lst[{i}] contains invalid characters: {sorted(invalid_chars)}"
            )

    def is_good(s):
        balance = 0
        for ch in s:
            if ch == "(":
                balance += 1
            else:  # ch == ")"
                balance -= 1
            if balance < 0:
                return False
        return balance == 0

    a, b = lst
    return "Yes" if is_good(a + b) or is_good(b + a) else "No"
candidate = match_parens


def check(candidate):

    # Check some simple cases
    assert candidate(['()(', ')']) == 'Yes'
    assert candidate([')', ')']) == 'No'
    assert candidate(['(()(())', '())())']) == 'No'
    assert candidate([')())', '(()()(']) == 'Yes'
    assert candidate(['(())))', '(()())((']) == 'Yes'
    assert candidate(['()', '())']) == 'No'
    assert candidate(['(()(', '()))()']) == 'Yes'
    assert candidate(['((((', '((())']) == 'No'
    assert candidate([')(()', '(()(']) == 'No'
    assert candidate([')(', ')(']) == 'No'
    

    # Check some edge cases that are easy to work out by hand.
    assert candidate(['(', ')']) == 'Yes'
    assert candidate([')', '(']) == 'Yes' 



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
