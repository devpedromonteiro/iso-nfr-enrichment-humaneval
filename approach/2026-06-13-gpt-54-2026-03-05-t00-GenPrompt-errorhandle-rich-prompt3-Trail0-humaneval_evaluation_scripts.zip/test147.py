
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    Return the number of triples (a[i], a[j], a[k]) with i < j < k such that
    a[i] + a[j] + a[k] is divisible by 3, where:

        a[i] = i*i - i + 1   for 1 <= i <= n

    Args:
        n (int): Positive integer length of the array.

    Returns:
        int: Number of valid triples.

    Raises:
        TypeError: If n is not an integer.
        ValueError: If n is not positive.
    """
    if isinstance(n, bool):
        raise TypeError("n must be an integer, not bool")
    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if n <= 0:
        raise ValueError("n must be a positive integer")

    # For i mod 3:
    # i = 0 -> a[i] = 1 mod 3
    # i = 1 -> a[i] = 1 mod 3
    # i = 2 -> a[i] = 0 mod 3
    #
    # So values in a are only 0 or 1 modulo 3.
    # A triple sum is divisible by 3 only when residues are:
    #   (1,1,1) or (0,0,0)

    count_mod_0 = n // 3                 # indices congruent to 2 mod 3
    count_mod_1 = n - count_mod_0        # remaining indices

    def comb3(x):
        if x < 3:
            return 0
        return x * (x - 1) * (x - 2) // 6

    return comb3(count_mod_0) + comb3(count_mod_1)
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
