
import unittest
import re
import sys
import math
import copy



def monotonic(l: list):
    """Return True if list elements are monotonically increasing or decreasing.

    A list is considered monotonic if it is entirely non-decreasing or
    entirely non-increasing.

    >>> monotonic([1, 2, 4, 20])
    True
    >>> monotonic([1, 20, 4, 10])
    False
    >>> monotonic([4, 1, 0, -10])
    True
    """
    if not isinstance(l, list):
        raise TypeError("monotonic() expects a list")

    if len(l) < 2:
        return True

    try:
        non_decreasing = True
        non_increasing = True

        for i in range(1, len(l)):
            if l[i] < l[i - 1]:
                non_decreasing = False
            if l[i] > l[i - 1]:
                non_increasing = False

        return non_decreasing or non_increasing

    except TypeError as exc:
        raise TypeError(
            "all list elements must be mutually comparable"
        ) from exc
candidate = monotonic




METADATA = {}


def check(candidate):
    assert candidate([1, 2, 4, 10]) == True
    assert candidate([1, 2, 4, 20]) == True
    assert candidate([1, 20, 4, 10]) == False
    assert candidate([4, 1, 0, -10]) == True
    assert candidate([4, 1, 1, 0]) == True
    assert candidate([1, 2, 3, 2, 5, 60]) == False
    assert candidate([1, 2, 3, 4, 5, 60]) == True
    assert candidate([9, 9, 9, 9]) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
