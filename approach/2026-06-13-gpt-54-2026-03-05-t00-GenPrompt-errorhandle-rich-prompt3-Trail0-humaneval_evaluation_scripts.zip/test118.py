
import unittest
import re
import sys
import math
import copy


def get_closest_vowel(word):
    """Return the closest vowel from the right that is between two consonants.

    A vowel qualifies only if:
    - it is not the first or last character
    - the characters immediately before and after it are consonants

    The search is case sensitive in the sense that the original character is returned,
    but vowel/consonant detection supports both uppercase and lowercase English letters.

    Args:
        word: A string containing English letters only.

    Returns:
        The matching vowel as a one-character string, or "" if none exists.

    Raises:
        TypeError: If word is not a string.
        ValueError: If word contains non-English-letter characters.
    """
    if not isinstance(word, str):
        raise TypeError("word must be a string")

    if not word.isalpha():
        raise ValueError("word must contain English letters only")

    vowels = set("aeiouAEIOU")

    def is_vowel(ch):
        return ch in vowels

    def is_consonant(ch):
        return ch.isalpha() and ch not in vowels

    if len(word) < 3:
        return ""

    for i in range(len(word) - 2, 0, -1):
        if is_vowel(word[i]) and is_consonant(word[i - 1]) and is_consonant(word[i + 1]):
            return word[i]

    return ""
candidate = get_closest_vowel


def check(candidate):

    # Check some simple cases
    assert candidate("yogurt") == "u"
    assert candidate("full") == "u"
    assert candidate("easy") == ""
    assert candidate("eAsy") == ""
    assert candidate("ali") == ""
    assert candidate("bad") == "a"
    assert candidate("most") == "o"
    assert candidate("ab") == ""
    assert candidate("ba") == ""
    assert candidate("quick") == ""
    assert candidate("anime") == "i"
    assert candidate("Asia") == ""
    assert candidate("Above") == "o"

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
