
import unittest
import re
import sys
import math
import copy


def tri(n):
    """Return the first n + 1 values of the Tribonacci sequence.

    Sequence definition:
    - tri(1) = 3
    - tri(k) = 1 + k / 2, if k is even
    - tri(k) = tri(k - 1) + tri(k - 2) + tri(k + 1), if k is odd

    Notes:
    - The example implies tri(0) = 1, so the returned list starts with 1.
    - Input must be a non-negative integer.

    Raises:
        TypeError: if n is not an integer.
        ValueError: if n is negative.
    """
    if isinstance(n, bool) or not isinstance(n, int):
        raise TypeError("n must be a non-negative integer")
    if n < 0:
        raise ValueError("n must be a non-negative integer")

    result = [1]  # tri(0) inferred from the example

    if n == 0:
        return result

    # Build values deterministically so failures do not leave partial external state.
    for k in range(1, n + 1):
        if k == 1:
            result.append(3)
        elif k % 2 == 0:
            result.append(1 + k // 2)
        else:
            # For odd k, tri(k + 1) is even, so it can be computed directly.
            tri_k_plus_1 = 1 + (k + 1) // 2
            result.append(result[k - 1] + result[k - 2] + tri_k_plus_1)

    return result
candidate = tri


def check(candidate):

    # Check some simple cases
    
    assert candidate(3) == [1, 3, 2.0, 8.0]
    assert candidate(4) == [1, 3, 2.0, 8.0, 3.0]
    assert candidate(5) == [1, 3, 2.0, 8.0, 3.0, 15.0]
    assert candidate(6) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0]
    assert candidate(7) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0]
    assert candidate(8) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0]
    assert candidate(9) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0]
    assert candidate(20) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0, 6.0, 48.0, 7.0, 63.0, 8.0, 80.0, 9.0, 99.0, 10.0, 120.0, 11.0]

    # Check some edge cases that are easy to work out by hand.
    assert candidate(0) == [1]
    assert candidate(1) == [1, 3]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
