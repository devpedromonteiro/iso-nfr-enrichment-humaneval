
import unittest
import re
import sys
import math
import copy



def encode_cyclic(s: str):
    """
    returns encoded string by cycling groups of three characters.
    """
    # split string to groups. Each of length 3.
    groups = [s[(3 * i):min((3 * i + 3), len(s))] for i in range((len(s) + 2) // 3)]
    # cycle elements in each group. Unless group has fewer elements than 3.
    groups = [(group[1:] + group[0]) if len(group) == 3 else group for group in groups]
    return "".join(groups)


def encode_cyclic(s: str):
    """
    Returns encoded string by cycling groups of three characters.

    Raises:
        TypeError: if s is not a string.
    """
    if not isinstance(s, str):
        raise TypeError(f"encode_cyclic expected str, got {type(s).__name__}")

    # split string to groups. Each of length 3.
    groups = [s[(3 * i):min((3 * i + 3), len(s))] for i in range((len(s) + 2) // 3)]
    # cycle elements in each group. Unless group has fewer elements than 3.
    groups = [(group[1:] + group[0]) if len(group) == 3 else group for group in groups]
    return "".join(groups)


def decode_cyclic(s: str):
    """
    Takes as input string encoded with encode_cyclic function.
    Returns decoded string.

    Raises:
        TypeError: if s is not a string.
    """
    if not isinstance(s, str):
        raise TypeError(f"decode_cyclic expected str, got {type(s).__name__}")

    try:
        # split string to groups of length 3
        groups = [s[(3 * i):min((3 * i + 3), len(s))] for i in range((len(s) + 2) // 3)]
        # reverse the cycle for full groups of 3: "bca" -> "abc"
        groups = [(group[-1] + group[:-1]) if len(group) == 3 else group for group in groups]
        return "".join(groups)
    except Exception as exc:
        # preserve failure information with explicit context
        raise ValueError("Failed to decode cyclic string") from exc
candidate = decode_cyclic




METADATA = {}


def check(candidate):
    from random import randint, choice
    import string

    letters = string.ascii_lowercase
    for _ in range(100):
        str = ''.join(choice(letters) for i in range(randint(10, 20)))
        encoded_str = encode_cyclic(str)
        assert candidate(encoded_str) == str



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
