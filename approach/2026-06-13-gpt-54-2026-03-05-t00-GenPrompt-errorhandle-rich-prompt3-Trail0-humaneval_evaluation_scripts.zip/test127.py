
import unittest
import re
import sys
import math
import copy


def intersection(interval1, interval2):
    """Determine whether the length of the intersection of two closed intervals is prime.

    Each interval must be a pair of integers in the form (start, end), with start <= end.
    The intersection length is computed geometrically for closed integer endpoints:
    intersection (a, b) and (c, d) has length max(0, min(b, d) - max(a, c)).

    Returns:
        "YES" if the intersection length is a prime number, otherwise "NO".

    Raises:
        TypeError: If either interval is not a 2-item list/tuple of integers.
        ValueError: If an interval does not satisfy start <= end.
    """

    def _validate_interval(interval, name):
        if not isinstance(interval, (tuple, list)):
            raise TypeError(f"{name} must be a tuple or list of two integers, got {type(interval).__name__}")
        if len(interval) != 2:
            raise ValueError(f"{name} must contain exactly two elements")
        start, end = interval
        if not isinstance(start, int) or not isinstance(end, int):
            raise TypeError(f"{name} must contain only integers")
        if start > end:
            raise ValueError(f"{name} must satisfy start <= end")
        return start, end

    def _is_prime(n):
        if n < 2:
            return False
        if n == 2:
            return True
        if n % 2 == 0:
            return False
        i = 3
        while i * i <= n:
            if n % i == 0:
                return False
            i += 2
        return True

    start1, end1 = _validate_interval(interval1, "interval1")
    start2, end2 = _validate_interval(interval2, "interval2")

    left = max(start1, start2)
    right = min(end1, end2)

    if left >= right:
        return "NO"

    length = right - left
    return "YES" if _is_prime(length) else "NO"
candidate = intersection


def check(candidate):

    # Check some simple cases
    assert candidate((1, 2), (2, 3)) == "NO"
    assert candidate((-1, 1), (0, 4)) == "NO"
    assert candidate((-3, -1), (-5, 5)) == "YES"
    assert candidate((-2, 2), (-4, 0)) == "YES"

    # Check some edge cases that are easy to work out by hand.
    assert candidate((-11, 2), (-1, -1)) == "NO"
    assert candidate((1, 2), (3, 5)) == "NO"
    assert candidate((1, 2), (1, 2)) == "NO"
    assert candidate((-2, -2), (-3, -2)) == "NO"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
