
import unittest
import re
import sys
import math
import copy


def specialFilter(nums):
    """Return the count of numbers > 10 whose first and last digits are odd.

    Rules:
    - Input must be a list or tuple of integers/floats representing whole numbers.
    - Values greater than 10 are considered.
    - A qualifying number must have both its first and last decimal digits odd.
    - Negative numbers are allowed as input, but since the value must be > 10,
      only positive numbers can qualify.

    Raises:
        TypeError: if nums is not a list/tuple, or contains non-numeric values.
        ValueError: if a numeric element is NaN, infinite, or not a whole number.
    """
    if not isinstance(nums, (list, tuple)):
        raise TypeError("nums must be a list or tuple of numbers")

    count = 0

    for i, n in enumerate(nums):
        if isinstance(n, bool) or not isinstance(n, (int, float)):
            raise TypeError(f"Element at index {i} is not a valid number: {n!r}")

        if isinstance(n, float):
            if n != n or n in (float("inf"), float("-inf")):
                raise ValueError(f"Element at index {i} must be a finite whole number: {n!r}")
            if not n.is_integer():
                raise ValueError(f"Element at index {i} must be a whole number: {n!r}")
            n = int(n)

        if n > 10:
            s = str(abs(n))
            first_digit = int(s[0])
            last_digit = int(s[-1])

            if first_digit % 2 == 1 and last_digit % 2 == 1:
                count += 1

    return count
candidate = specialFilter


def check(candidate):

    # Check some simple cases
    assert candidate([5, -2, 1, -5]) == 0  
    assert candidate([15, -73, 14, -15]) == 1
    assert candidate([33, -2, -3, 45, 21, 109]) == 2
    assert candidate([43, -12, 93, 125, 121, 109]) == 4
    assert candidate([71, -2, -33, 75, 21, 19]) == 3


    # Check some edge cases that are easy to work out by hand.
    assert candidate([1]) == 0              
    assert candidate([]) == 0                   



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
