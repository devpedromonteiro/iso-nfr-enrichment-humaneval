
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Given a grid with N rows and N columns (N >= 2) and a positive integer k,
    each cell of the grid contains a value. Every integer in the range [1, N * N]
    inclusive appears exactly once on the cells of the grid.

    Return the lexicographically minimum path of length k, where each move goes
    to an edge-adjacent neighbor cell.

    Error handling:
    - Raises TypeError for incorrect argument types.
    - Raises ValueError for invalid argument values or malformed grid contents.
    """
    # Validate k
    if not isinstance(k, int):
        raise TypeError("k must be an integer")
    if k <= 0:
        raise ValueError("k must be a positive integer")

    # Validate grid container
    if not isinstance(grid, list):
        raise TypeError("grid must be a list of lists")
    if len(grid) < 2:
        raise ValueError("grid must have at least 2 rows")

    n = len(grid)

    # Validate rows and contents
    seen = set()
    for i, row in enumerate(grid):
        if not isinstance(row, list):
            raise TypeError(f"grid row {i} must be a list")
        if len(row) != n:
            raise ValueError("grid must be square (N x N)")
        for j, value in enumerate(row):
            if not isinstance(value, int):
                raise TypeError(f"grid[{i}][{j}] must be an integer")
            if value < 1 or value > n * n:
                raise ValueError(f"grid[{i}][{j}] must be in range [1, {n * n}]")
            if value in seen:
                raise ValueError("grid values must be unique")
            seen.add(value)

    if len(seen) != n * n:
        raise ValueError(f"grid must contain every integer in [1, {n * n}] exactly once")

    # Map each value to its position
    pos = {}
    for i in range(n):
        for j in range(n):
            pos[grid[i][j]] = (i, j)

    # Since values are unique and answer is lexicographically minimal,
    # greedily build the path:
    # - choose the smallest possible starting value
    # - then repeatedly choose the smallest-valued neighbor
    start_value = 1
    r, c = pos[start_value]
    path = [start_value]

    def neighbors(row, col):
        for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            nr, nc = row + dr, col + dc
            if 0 <= nr < n and 0 <= nc < n:
                yield nr, nc

    for _ in range(k - 1):
        next_candidates = []
        for nr, nc in neighbors(r, c):
            next_candidates.append((grid[nr][nc], nr, nc))

        if not next_candidates:
            # Defensive check; should never happen in a valid N>=2 grid.
            raise RuntimeError("No valid moves available from current cell")

        next_value, r, c = min(next_candidates, key=lambda x: x[0])
        path.append(next_value)

    return path
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
