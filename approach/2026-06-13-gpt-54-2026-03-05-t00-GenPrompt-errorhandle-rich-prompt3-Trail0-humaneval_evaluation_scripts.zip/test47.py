
import unittest
import re
import sys
import math
import copy



def median(l: list):
    """Return median of elements in the list l.

    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    8.0
    """
    if not isinstance(l, list):
        raise TypeError("median() expects a list")

    if not l:
        raise ValueError("median() cannot be computed for an empty list")

    try:
        sorted_list = sorted(l)
    except TypeError as e:
        raise TypeError("median() expects a list of mutually comparable values") from e

    n = len(sorted_list)
    mid = n // 2

    if n % 2 == 1:
        return sorted_list[mid]

    try:
        return (sorted_list[mid - 1] + sorted_list[mid]) / 2
    except TypeError as e:
        raise TypeError(
            "median() expects numeric values for even-length lists"
        ) from e
candidate = median




METADATA = {}


def check(candidate):
    assert candidate([3, 1, 2, 4, 5]) == 3
    assert candidate([-10, 4, 6, 1000, 10, 20]) == 8.0
    assert candidate([5]) == 5
    assert candidate([6, 5]) == 5.5
    assert candidate([8, 1, 3, 9, 9, 2, 7]) == 7 



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
