
import unittest
import re
import sys
import math
import copy


def is_multiply_prime(a):
    """Return True if ``a`` is the product of exactly 3 prime numbers, else False.

    A prime factor may repeat, so values like 8 = 2 * 2 * 2 return True.

    Constraints handled:
    - Input must be an integer.
    - Invalid arguments raise specific exceptions.
    - Errors are not silently swallowed.

    Examples:
        is_multiply_prime(30) -> True   # 2 * 3 * 5
        is_multiply_prime(8)  -> True   # 2 * 2 * 2
        is_multiply_prime(12) -> True   # 2 * 2 * 3
        is_multiply_prime(7)  -> False
    """
    if isinstance(a, bool):
        raise TypeError("Input must be an integer, not bool.")
    if not isinstance(a, int):
        raise TypeError("Input must be an integer.")
    if a < 0:
        raise ValueError("Input must be non-negative.")
    if a >= 100:
        raise ValueError("Input must be less than 100.")

    if a < 8:
        return False

    remaining = a
    prime_factor_count = 0
    divisor = 2

    while divisor * divisor <= remaining and prime_factor_count <= 3:
        while remaining % divisor == 0:
            prime_factor_count += 1
            remaining //= divisor
            if prime_factor_count > 3:
                return False
        divisor += 1

    if remaining > 1:
        prime_factor_count += 1

    return prime_factor_count == 3
candidate = is_multiply_prime


def check(candidate):

    assert candidate(5) == False
    assert candidate(30) == True
    assert candidate(8) == True
    assert candidate(10) == False
    assert candidate(125) == True
    assert candidate(3 * 5 * 7) == True
    assert candidate(3 * 6 * 7) == False
    assert candidate(9 * 9 * 9) == False
    assert candidate(11 * 9 * 9) == False
    assert candidate(11 * 13 * 7) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
