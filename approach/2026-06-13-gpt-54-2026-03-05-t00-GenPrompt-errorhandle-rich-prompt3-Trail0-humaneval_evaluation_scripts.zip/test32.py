
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[2] * x^2 + .... + xs[n] * x^n
    """
    if not isinstance(xs, list):
        raise TypeError("xs must be a list of numeric coefficients")
    if not xs:
        raise ValueError("xs must not be empty")
    if not isinstance(x, (int, float)):
        raise TypeError("x must be a numeric value")

    for i, coeff in enumerate(xs):
        if not isinstance(coeff, (int, float)):
            raise TypeError(f"coefficient at index {i} must be numeric")

    return sum(coeff * math.pow(x, i) for i, coeff in enumerate(xs))


def find_zero(xs: list):
    """xs are coefficients of a polynomial.
    find_zero finds x such that poly(xs, x) == 0.
    find_zero returns only one zero point, even if there are many.

    Constraints:
    - xs must be a list
    - xs must have an even number of coefficients
    - xs must not be empty
    - coefficients must be numeric
    - the largest non-zero coefficient must be the last one

    >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2)  # (x - 1) * (x - 2) * (x - 3)
    1.0
    """
    if not isinstance(xs, list):
        raise TypeError("xs must be a list of numeric coefficients")
    if not xs:
        raise ValueError("xs must not be empty")
    if len(xs) % 2 != 0:
        raise ValueError("xs must contain an even number of coefficients")

    for i, coeff in enumerate(xs):
        if not isinstance(coeff, (int, float)):
            raise TypeError(f"coefficient at index {i} must be numeric")

    non_zero_indices = [i for i, coeff in enumerate(xs) if coeff != 0]
    if not non_zero_indices:
        raise ValueError("polynomial must have at least one non-zero coefficient")

    degree = non_zero_indices[-1]
    if degree != len(xs) - 1:
        raise ValueError("largest non-zero coefficient must be the last coefficient")

    leading_coeff = xs[-1]
    if leading_coeff == 0:
        raise ValueError("leading coefficient must be non-zero")

    # Linear case: a + bx = 0
    if len(xs) == 2:
        return -xs[0] / xs[1]

    # Search for a root using bisection.
    # For odd-degree polynomials, a real root is guaranteed.
    def f(val):
        return poly(xs, val)

    left, right = -1.0, 1.0
    f_left, f_right = f(left), f(right)

    # Expand interval until it brackets a root or fails safely.
    max_expansions = 100
    expansions = 0
    while f_left * f_right > 0:
        left *= 2
        right *= 2
        f_left, f_right = f(left), f(right)
        expansions += 1
        if expansions > max_expansions:
            raise ArithmeticError("failed to bracket a root for the polynomial")

    if f_left == 0:
        return left
    if f_right == 0:
        return right

    # Bisection method
    max_iterations = 200
    tolerance = 1e-12

    for _ in range(max_iterations):
        mid = (left + right) / 2.0
        f_mid = f(mid)

        if abs(f_mid) < tolerance:
            return mid

        if f_left * f_mid < 0:
            right = mid
            f_right = f_mid
        else:
            left = mid
            f_left = f_mid

    raise ArithmeticError("bisection did not converge to a root")
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
