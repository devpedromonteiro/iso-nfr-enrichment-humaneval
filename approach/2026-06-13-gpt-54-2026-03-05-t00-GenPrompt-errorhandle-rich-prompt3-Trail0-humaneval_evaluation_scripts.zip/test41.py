
import unittest
import re
import sys
import math
import copy



def car_race_collision(n: int) -> int:
    """
    Calculate the number of collisions between two groups of cars.

    Imagine a straight infinitely long road:
    - n cars move from left to right
    - n different cars move from right to left
    - all cars move at the same speed
    - cars continue unaffected after collisions

    Each left-to-right car collides exactly once with each right-to-left car,
    so the total number of collisions is n * n.

    Args:
        n: Number of cars in each group. Must be a non-negative integer.

    Returns:
        The total number of collisions.

    Raises:
        TypeError: If n is not an integer.
        ValueError: If n is negative.
    """
    if isinstance(n, bool):
        raise TypeError("n must be an integer, not bool")

    if not isinstance(n, int):
        raise TypeError("n must be an integer")

    if n < 0:
        raise ValueError("n must be non-negative")

    return n * n
candidate = car_race_collision




METADATA = {}


def check(candidate):
    assert candidate(2) == 4
    assert candidate(3) == 9
    assert candidate(4) == 16
    assert candidate(8) == 64
    assert candidate(10) == 100



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
