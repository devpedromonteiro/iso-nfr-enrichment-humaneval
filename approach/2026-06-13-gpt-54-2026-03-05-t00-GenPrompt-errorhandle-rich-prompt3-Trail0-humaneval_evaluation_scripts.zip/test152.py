
import unittest
import re
import sys
import math
import copy


def compare(game, guess):
    """Return absolute differences between actual scores and guesses.

    Each element in `game` is compared with the element at the same index in
    `guess`. If equal, the result is 0; otherwise, the absolute difference.

    Args:
        game: A list or tuple of numeric scores.
        guess: A list or tuple of numeric guesses.

    Returns:
        A list of absolute differences.

    Raises:
        TypeError: If `game` or `guess` is not a list/tuple, or contains
            non-numeric values.
        ValueError: If `game` and `guess` do not have the same length.
    """
    if not isinstance(game, (list, tuple)):
        raise TypeError("game must be a list or tuple")
    if not isinstance(guess, (list, tuple)):
        raise TypeError("guess must be a list or tuple")

    if len(game) != len(guess):
        raise ValueError("game and guess must have the same length")

    result = []

    for i, (g, q) in enumerate(zip(game, guess)):
        if not isinstance(g, (int, float)):
            raise TypeError(f"game[{i}] must be numeric, got {type(g).__name__}")
        if not isinstance(q, (int, float)):
            raise TypeError(f"guess[{i}] must be numeric, got {type(q).__name__}")

        result.append(abs(g - q))

    return result
candidate = compare


def check(candidate):

    # Check some simple cases
    assert candidate([1,2,3,4,5,1],[1,2,3,4,2,-2])==[0,0,0,0,3,3], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([0,0,0,0,0,0],[0,0,0,0,0,0])==[0,0,0,0,0,0], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,2,3],[-1,-2,-3])==[2,4,6], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,2,3,5],[-1,2,3,4])==[2,0,0,1], "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
