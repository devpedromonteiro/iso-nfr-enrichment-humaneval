
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    You are given a positive integer n. You have to create an integer array a of length n.
    For each i (1 â¤ i â¤ n), the value of a[i] = i * i - i + 1.
    Return the number of triples (a[i], a[j], a[k]) of a where i < j < k,
    and a[i] + a[j] + a[k] is a multiple of 3.

    Example:
        Input: n = 5
        Output: 1
        Explanation:
        a = [1, 3, 7, 13, 21]
        The only valid triple is (1, 7, 13).
    """
    # a[i] = i^2 - i + 1 = i(i-1) + 1
    # Since i(i-1) is always divisible by 2, but we care about mod 3:
    # Check pattern modulo 3:
    # i % 3 == 0 -> a[i] % 3 = 1
    # i % 3 == 1 -> a[i] % 3 = 1
    # i % 3 == 2 -> a[i] % 3 = 0
    #
    # So values are only of type 0 or 1 modulo 3.
    # For sum of three numbers to be divisible by 3, the only possible residue combo is:
    # 1 + 1 + 1 = 3 â¡ 0 (mod 3)
    # Since we never get residue 2, other combinations do not work.
    #
    # Therefore answer = C(count_1, 3)
    # where count_1 is number of indices i in [1..n] with i % 3 != 2.

    count_zero_mod_index = n // 3          # indices congruent to 0 mod 3
    count_one_mod_index = (n + 2) // 3     # indices congruent to 1 mod 3
    count_two_mod_index = (n + 1) // 3     # indices congruent to 2 mod 3

    count_1 = count_zero_mod_index + count_one_mod_index  # a[i] % 3 == 1

    if count_1 < 3:
        return 0

    return count_1 * (count_1 - 1) * (count_1 - 2) // 6
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
