
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Given a grid with N rows and N columns (N >= 2) and a positive integer k, 
    each cell of the grid contains a value. Every integer in the range [1, N * N]
    inclusive appears exactly once on the cells of the grid.

    Return the lexicographically smallest path of length k, where each move goes
    to a 4-directionally adjacent cell and cells may be revisited.
    """
    n = len(grid)

    # Map each value to its position for O(1) lookup.
    pos = {}
    for r in range(n):
        for c in range(n):
            pos[grid[r][c]] = (r, c)

    # Build adjacency by value instead of by coordinates.
    neighbors = {}
    for value in range(1, n * n + 1):
        r, c = pos[value]
        adj = []
        if r > 0:
            adj.append(grid[r - 1][c])
        if r + 1 < n:
            adj.append(grid[r + 1][c])
        if c > 0:
            adj.append(grid[r][c - 1])
        if c + 1 < n:
            adj.append(grid[r][c + 1])
        neighbors[value] = sorted(adj)

    # dp[x] = lexicographically smallest sequence of length `step`
    # starting from value x.
    dp = {value: [value] for value in range(1, n * n + 1)}

    for _ in range(2, k + 1):
        new_dp = {}
        for value in range(1, n * n + 1):
            best_suffix = None
            for nxt in neighbors[value]:
                candidate = dp[nxt]
                if best_suffix is None or candidate < best_suffix:
                    best_suffix = candidate
            new_dp[value] = [value] + best_suffix
        dp = new_dp

    # Choose the best starting value.
    best_path = None
    for value in range(1, n * n + 1):
        if best_path is None or dp[value] < best_path:
            best_path = dp[value]

    return best_path
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
