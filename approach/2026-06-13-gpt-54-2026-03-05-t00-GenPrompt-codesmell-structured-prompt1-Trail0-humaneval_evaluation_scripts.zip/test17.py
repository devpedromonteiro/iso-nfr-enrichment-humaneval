
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


NOTE_DURATIONS = {
    "o": 4,
    "o|": 2,
    ".|": 1,
}


def parse_music(music_string: str) -> List[int]:
    """Parse a space-separated ASCII music string into note durations.

    Legend:
    - 'o'  -> 4 beats
    - 'o|' -> 2 beats
    - '.|' -> 1 beat

    >>> parse_music('o o| .| o| o| .| .| .| .| o o')
    [4, 2, 1, 2, 2, 1, 1, 1, 1, 4, 4]
    """
    return [_parse_note(note) for note in music_string.split()]


def _parse_note(note: str) -> int:
    """Convert a single note token into its beat duration."""
    return NOTE_DURATIONS[note]
candidate = parse_music




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == []
    assert candidate('o o o o') == [4, 4, 4, 4]
    assert candidate('.| .| .| .|') == [1, 1, 1, 1]
    assert candidate('o| o| .| .| o o o o') == [2, 2, 1, 1, 4, 4, 4, 4]
    assert candidate('o| .| o| .| o o| o o|') == [2, 1, 2, 1, 4, 2, 4, 2]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
