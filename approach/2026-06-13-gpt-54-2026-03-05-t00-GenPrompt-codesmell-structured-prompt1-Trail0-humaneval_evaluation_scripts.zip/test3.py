
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def _running_balance(operations: List[int]):
    """Yield the account balance after each operation."""
    balance = 0
    for operation in operations:
        balance += operation
        yield balance


def below_zero(operations: List[int]) -> bool:
    """Return True if the account balance drops below zero at any point.

    The account starts with a balance of zero.

    >>> below_zero([1, 2, 3])
    False
    >>> below_zero([1, 2, -4, 5])
    True
    """
    return any(balance < 0 for balance in _running_balance(operations))
candidate = below_zero




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == False
    assert candidate([1, 2, -3, 1, 2, -3]) == False
    assert candidate([1, 2, -4, 5, 6]) == True
    assert candidate([1, -1, 2, -2, 5, -5, 4, -4]) == False
    assert candidate([1, -1, 2, -2, 5, -5, 4, -5]) == True
    assert candidate([1, -2, 2, -2, 5, -5, 4, -4]) == True


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
