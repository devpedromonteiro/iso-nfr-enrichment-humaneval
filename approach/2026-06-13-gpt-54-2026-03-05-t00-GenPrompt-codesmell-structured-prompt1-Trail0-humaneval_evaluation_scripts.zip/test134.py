
import unittest
import re
import sys
import math
import copy


def check_if_last_char_is_a_letter(txt):
    """
    Return True if the last character of the string is a letter and forms
    a single-letter word; otherwise return False.

    A word is defined as a group of characters separated by spaces.
    """
    if not txt or txt[-1] == " ":
        return False

    last_char = txt[-1]
    if not last_char.isalpha():
        return False

    words = txt.split(" ")
    last_word = words[-1]

    return len(last_word) == 1
candidate = check_if_last_char_is_a_letter


def check(candidate):

    # Check some simple cases
    assert candidate("apple") == False
    assert candidate("apple pi e") == True
    assert candidate("eeeee") == False
    assert candidate("A") == True
    assert candidate("Pumpkin pie ") == False
    assert candidate("Pumpkin pie 1") == False
    assert candidate("") == False
    assert candidate("eeeee e ") == False
    assert candidate("apple pie") == False
    assert candidate("apple pi e ") == False

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
