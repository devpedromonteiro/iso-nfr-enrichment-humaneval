
import unittest
import re
import sys
import math
import copy


def intersection(interval1, interval2):
    """Determine whether the length of the intersection of two closed intervals is prime.

    Each interval is a tuple of integers (start, end), inclusive.
    Returns "YES" if the intersection length is a prime number, otherwise "NO".
    """

    def intersection_length(first, second):
        start = max(first[0], second[0])
        end = min(first[1], second[1])
        if start > end:
            return 0
        return end - start

    def is_prime(number):
        if number < 2:
            return False
        if number == 2:
            return True
        if number % 2 == 0:
            return False

        divisor = 3
        while divisor * divisor <= number:
            if number % divisor == 0:
                return False
            divisor += 2
        return True

    length = intersection_length(interval1, interval2)
    return "YES" if is_prime(length) else "NO"
candidate = intersection


def check(candidate):

    # Check some simple cases
    assert candidate((1, 2), (2, 3)) == "NO"
    assert candidate((-1, 1), (0, 4)) == "NO"
    assert candidate((-3, -1), (-5, 5)) == "YES"
    assert candidate((-2, 2), (-4, 0)) == "YES"

    # Check some edge cases that are easy to work out by hand.
    assert candidate((-11, 2), (-1, -1)) == "NO"
    assert candidate((1, 2), (3, 5)) == "NO"
    assert candidate((1, 2), (1, 2)) == "NO"
    assert candidate((-2, -2), (-3, -2)) == "NO"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
