
import unittest
import re
import sys
import math
import copy


def get_closest_vowel(word):
    """Return the rightmost vowel that is between two consonants.

    A vowel at the beginning or end of the word does not count.
    The search is case sensitive and scans from right to left.

    Examples:
        get_closest_vowel("yogurt") -> "u"
        get_closest_vowel("FULL") -> "U"
        get_closest_vowel("quick") -> ""
        get_closest_vowel("ab") -> ""
    """
    vowels = set("aeiouAEIOU")

    def is_vowel(char):
        return char in vowels

    for index in range(len(word) - 2, 0, -1):
        current = word[index]
        if (
            is_vowel(current)
            and not is_vowel(word[index - 1])
            and not is_vowel(word[index + 1])
        ):
            return current

    return ""
candidate = get_closest_vowel


def check(candidate):

    # Check some simple cases
    assert candidate("yogurt") == "u"
    assert candidate("full") == "u"
    assert candidate("easy") == ""
    assert candidate("eAsy") == ""
    assert candidate("ali") == ""
    assert candidate("bad") == "a"
    assert candidate("most") == "o"
    assert candidate("ab") == ""
    assert candidate("ba") == ""
    assert candidate("quick") == ""
    assert candidate("anime") == "i"
    assert candidate("Asia") == ""
    assert candidate("Above") == "o"

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
