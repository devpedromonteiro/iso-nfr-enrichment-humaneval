
import unittest
import re
import sys
import math
import copy


def _remove_characters(source, chars_to_remove):
    removal_set = set(chars_to_remove)
    return "".join(char for char in source if char not in removal_set)


def _is_palindrome(text):
    return text == text[::-1]


def reverse_delete(s, c):
    """Remove from s all characters found in c, then check whether the result is a palindrome.

    Returns:
        tuple[str, bool]: (filtered_string, is_palindrome)
    """
    filtered = _remove_characters(s, c)
    return filtered, _is_palindrome(filtered)
candidate = reverse_delete


def check(candidate):

    assert candidate("abcde","ae") == ('bcd',False)
    assert candidate("abcdef", "b") == ('acdef',False)
    assert candidate("abcdedcba","ab") == ('cdedc',True)
    assert candidate("dwik","w") == ('dik',False)
    assert candidate("a","a") == ('',True)
    assert candidate("abcdedcba","") == ('abcdedcba',True)
    assert candidate("abcdedcba","v") == ('abcdedcba',True)
    assert candidate("vabba","v") == ('abba',True)
    assert candidate("mamma", "mia") == ("", True)


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
