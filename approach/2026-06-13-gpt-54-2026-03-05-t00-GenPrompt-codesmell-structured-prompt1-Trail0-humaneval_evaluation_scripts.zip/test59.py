
import unittest
import re
import sys
import math
import copy



def _remove_factor(n: int, factor: int) -> tuple[int, int]:
    """Divide n by factor until it no longer divides.

    Returns the reduced value of n and the last factor removed.
    """
    last_factor = factor
    while n % factor == 0:
        n //= factor
    return n, last_factor


def largest_prime_factor(n: int):
    """Return the largest prime factor of n. Assume n > 1 and is not a prime.
    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    largest = None

    if n % 2 == 0:
        n, largest = _remove_factor(n, 2)

    factor = 3
    while factor * factor <= n:
        if n % factor == 0:
            n, largest = _remove_factor(n, factor)
        factor += 2

    return n if n > 1 else largest
candidate = largest_prime_factor




METADATA = {}


def check(candidate):
    assert candidate(15) == 5
    assert candidate(27) == 3
    assert candidate(63) == 7
    assert candidate(330) == 11
    assert candidate(13195) == 29



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
