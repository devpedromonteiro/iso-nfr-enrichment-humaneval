
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List
from collections import Counter


def _find_unique_values(numbers: List[int]) -> set[int]:
    """Return the values that occur exactly once."""
    counts = Counter(numbers)
    return {number for number, count in counts.items() if count == 1}


def remove_duplicates(numbers: List[int]) -> List[int]:
    """From a list of integers, remove all elements that occur more than once.
    Keep order of elements left the same as in the input.

    >>> remove_duplicates([1, 2, 3, 2, 4])
    [1, 3, 4]
    """
    unique_values = _find_unique_values(numbers)
    return [number for number in numbers if number in unique_values]
candidate = remove_duplicates




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == []
    assert candidate([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert candidate([1, 2, 3, 2, 4, 3, 5]) == [1, 4, 5]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
