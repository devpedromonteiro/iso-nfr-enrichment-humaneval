
import unittest
import re
import sys
import math
import copy


def move_one_ball(arr):
    """Return True if some number of right rotations makes arr non-decreasing.

    A right rotation preserves the circular order of elements, so the array can
    be rotated into sorted order iff there is at most one position where the
    order decreases when scanning left to right, including the wrap-around from
    the last element to the first.

    An empty array is considered sortable.
    """
    if not arr:
        return True

    return _count_descending_transitions(arr) <= 1


def _count_descending_transitions(arr):
    """Count positions i where arr[i] > arr[(i + 1) % len(arr)]."""
    size = len(arr)
    descending_transitions = 0

    for index in range(size):
        if arr[index] > arr[(index + 1) % size]:
            descending_transitions += 1

    return descending_transitions
candidate = move_one_ball


def check(candidate):

    # Check some simple cases
    assert candidate([3, 4, 5, 1, 2])==True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([3, 5, 10, 1, 2])==True
    assert candidate([4, 3, 1, 2])==False
    # Check some edge cases that are easy to work out by hand.
    assert candidate([3, 5, 4, 1, 2])==False, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([])==True


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
