
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    You are given a positive integer n. You have to create an integer array a of length n.
    For each i (1 â¤ i â¤ n), the value of a[i] = i * i - i + 1.

    Return the number of triples (a[i], a[j], a[k]) where i < j < k and
    a[i] + a[j] + a[k] is a multiple of 3.

    Example:
        Input: n = 5
        Output: 1
        Explanation:
        a = [1, 3, 7, 13, 21]
        The only valid triple is (1, 7, 13).
    """

    def combinations_of_three(count):
        if count < 3:
            return 0
        return count * (count - 1) * (count - 2) // 6

    def combinations_of_two(count):
        if count < 2:
            return 0
        return count * (count - 1) // 2

    remainder_counts = [0, 0, 0]

    for i in range(1, n + 1):
        value_mod_3 = (i * i - i + 1) % 3
        remainder_counts[value_mod_3] += 1

    count_0, count_1, count_2 = remainder_counts

    return (
        combinations_of_three(count_0) +
        combinations_of_three(count_1) +
        combinations_of_three(count_2) +
        count_0 * count_1 * count_2
    )
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
