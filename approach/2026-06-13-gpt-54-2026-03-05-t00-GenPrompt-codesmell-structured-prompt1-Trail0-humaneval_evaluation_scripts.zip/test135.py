
import unittest
import re
import sys
import math
import copy


def can_arrange(arr):
    """Return the largest index where ordering stops being strictly increasing.

    An index i is returned when arr[i] <= arr[i - 1].
    If the whole array is strictly increasing, return -1.

    Examples:
        can_arrange([1, 2, 4, 3, 5]) == 3
        can_arrange([1, 2, 3]) == -1
    """
    for index in range(len(arr) - 1, 0, -1):
        if arr[index] <= arr[index - 1]:
            return index
    return -1
candidate = can_arrange


def check(candidate):

    # Check some simple cases
    assert candidate([1,2,4,3,5])==3
    assert candidate([1,2,4,5])==-1
    assert candidate([1,4,2,5,6,7,8,9,10])==2
    assert candidate([4,8,5,7,3])==4

    # Check some edge cases that are easy to work out by hand.
    assert candidate([])==-1



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
