
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math
from typing import Sequence


def poly(coefficients: Sequence[float], x: float) -> float:
    """
    Evaluate a polynomial with the given coefficients at point x.

    coefficients[i] is the coefficient for x**i.

    Example:
        poly([1, 2, 3], 2) = 1 + 2*2 + 3*2^2
    """
    return sum(coeff * math.pow(x, i) for i, coeff in enumerate(coefficients))


def _validate_coefficients(coefficients: Sequence[float]) -> None:
    """Validate the constraints required by find_zero."""
    if not coefficients:
        raise ValueError("coefficients must not be empty")

    if len(coefficients) % 2 != 0:
        raise ValueError("find_zero requires an even number of coefficients")

    if coefficients[-1] == 0:
        raise ValueError("the largest-degree coefficient must be non-zero")


def _derivative_coefficients(coefficients: Sequence[float]) -> list[float]:
    """Return the coefficients of the derivative polynomial."""
    return [i * coeff for i, coeff in enumerate(coefficients)][1:]


def _bisect_root(coefficients: Sequence[float], left: float, right: float, tolerance: float = 1e-7) -> float:
    """Find a root in [left, right] assuming a sign change exists."""
    left_value = poly(coefficients, left)
    right_value = poly(coefficients, right)

    if left_value == 0:
        return left
    if right_value == 0:
        return right

    while right - left > tolerance:
        mid = (left + right) / 2
        mid_value = poly(coefficients, mid)

        if mid_value == 0:
            return mid

        if left_value * mid_value < 0:
            right = mid
            right_value = mid_value
        else:
            left = mid
            left_value = mid_value

    return (left + right) / 2


def _find_search_interval(coefficients: Sequence[float]) -> tuple[float, float]:
    """
    Find an interval [left, right] that brackets at least one root.
    For odd-degree polynomials, such an interval always exists.
    """
    left, right = -1.0, 1.0
    left_value = poly(coefficients, left)
    right_value = poly(coefficients, right)

    while left_value * right_value > 0:
        left *= 2
        right *= 2
        left_value = poly(coefficients, left)
        right_value = poly(coefficients, right)

    return left, right


def find_zero(coefficients: Sequence[float]) -> float:
    """Find one real zero of a polynomial.

    The polynomial is defined by `coefficients`, where coefficients[i]
    corresponds to the coefficient of x**i.

    This function assumes:
    - the number of coefficients is even
    - the highest-degree coefficient is non-zero

    These constraints imply an odd-degree polynomial, which guarantees
    at least one real root.

    >>> round(find_zero([1, 2]), 2)
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2)
    1.0
    """
    _validate_coefficients(coefficients)
    left, right = _find_search_interval(coefficients)
    return _bisect_root(coefficients, left, right)
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
