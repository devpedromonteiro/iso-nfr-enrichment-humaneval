
import unittest
import re
import sys
import math
import copy



def largest_prime_factor(n: int):
    """Return the largest prime factor of n. Assume n > 1 and is not a prime.
    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if isinstance(n, bool):
        raise TypeError("n must be an integer, not bool")
    if n <= 1:
        raise ValueError("n must be greater than 1")

    original_n = n
    largest = None

    try:
        while n % 2 == 0:
            largest = 2
            n //= 2

        factor = 3
        while factor * factor <= n:
            while n % factor == 0:
                largest = factor
                n //= factor
            factor += 2

        if n > 1:
            if largest is None:
                raise ValueError(f"n must not be prime: {original_n}")
            largest = n

        if largest is None:
            raise ArithmeticError("failed to determine largest prime factor")

        return largest

    except (TypeError, ValueError):
        raise
    except Exception as exc:
        raise ArithmeticError(
            f"unexpected error while computing largest prime factor for {original_n}"
        ) from exc
candidate = largest_prime_factor




METADATA = {}


def check(candidate):
    assert candidate(15) == 5
    assert candidate(27) == 3
    assert candidate(63) == 7
    assert candidate(330) == 11
    assert candidate(13195) == 29



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
