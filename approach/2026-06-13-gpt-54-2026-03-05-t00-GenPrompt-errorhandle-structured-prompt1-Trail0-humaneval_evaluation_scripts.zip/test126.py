
import unittest
import re
import sys
import math
import copy


def is_sorted(lst):
    '''
    Given a list of numbers, return whether or not they are sorted
    in ascending order. If list has more than 1 duplicate of the same
    number, return False. Assume no negative numbers and only integers.

    Examples
    is_sorted([5]) â True
    is_sorted([1, 2, 3, 4, 5]) â True
    is_sorted([1, 3, 2, 4, 5]) â False
    is_sorted([1, 2, 3, 4, 5, 6]) â True
    is_sorted([1, 2, 3, 4, 5, 6, 7]) â True
    is_sorted([1, 3, 2, 4, 5, 6, 7]) â False
    is_sorted([1, 2, 2, 3, 3, 4]) â True
    is_sorted([1, 2, 2, 2, 3, 4]) â False
    '''
    if not isinstance(lst, list):
        raise TypeError("Input must be a list.")

    try:
        seen_counts = {}

        for i, value in enumerate(lst):
            if not isinstance(value, int):
                raise TypeError(f"All elements must be integers. Invalid element at index {i}: {value!r}")
            if value < 0:
                raise ValueError(f"All elements must be non-negative. Invalid element at index {i}: {value}")

            seen_counts[value] = seen_counts.get(value, 0) + 1
            if seen_counts[value] > 2:
                return False

            if i > 0 and lst[i] < lst[i - 1]:
                return False

        return True

    except (TypeError, ValueError):
        raise
    except Exception as exc:
        raise RuntimeError("Unexpected error while checking whether the list is sorted.") from exc
candidate = is_sorted


def check(candidate):

    # Check some simple cases
    assert candidate([5]) == True
    assert candidate([1, 2, 3, 4, 5]) == True
    assert candidate([1, 3, 2, 4, 5]) == False
    assert candidate([1, 2, 3, 4, 5, 6]) == True
    assert candidate([1, 2, 3, 4, 5, 6, 7]) == True
    assert candidate([1, 3, 2, 4, 5, 6, 7]) == False, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([]) == True, "This prints if this assert fails 2 (good for debugging!)"
    assert candidate([1]) == True, "This prints if this assert fails 3 (good for debugging!)"
    assert candidate([3, 2, 1]) == False, "This prints if this assert fails 4 (good for debugging!)"
    
    # Check some edge cases that are easy to work out by hand.
    assert candidate([1, 2, 2, 2, 3, 4]) == False, "This prints if this assert fails 5 (good for debugging!)"
    assert candidate([1, 2, 3, 3, 3, 4]) == False, "This prints if this assert fails 6 (good for debugging!)"
    assert candidate([1, 2, 2, 3, 3, 4]) == True, "This prints if this assert fails 7 (good for debugging!)"
    assert candidate([1, 2, 3, 4]) == True, "This prints if this assert fails 8 (good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
