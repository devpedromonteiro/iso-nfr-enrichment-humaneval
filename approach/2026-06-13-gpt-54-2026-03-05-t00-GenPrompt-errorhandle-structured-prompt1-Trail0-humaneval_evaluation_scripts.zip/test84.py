
import unittest
import re
import sys
import math
import copy


def solve(N):
    """Given a non-negative integer N, return the binary representation of
    the sum of its decimal digits.

    Examples:
        solve(1000) -> "1"
        solve(150)  -> "110"
        solve(147)  -> "1100"

    Args:
        N: An integer such that 0 <= N <= 10000.

    Returns:
        A string containing the binary representation of the sum of digits.

    Raises:
        TypeError: If N is not an integer.
        ValueError: If N is outside the allowed range [0, 10000].
    """
    if not isinstance(N, int):
        raise TypeError("N must be an integer")
    if N < 0 or N > 10000:
        raise ValueError("N must be between 0 and 10000 inclusive")

    try:
        digit_sum = sum(int(ch) for ch in str(N))
        return bin(digit_sum)[2:]
    except ValueError as exc:
        # Defensive handling: should not occur after validation,
        # but preserves explicit error reporting.
        raise ValueError("Failed to compute digit sum from input") from exc
candidate = solve


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(1000) == "1", "Error"
    assert candidate(150) == "110", "Error"
    assert candidate(147) == "1100", "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate(333) == "1001", "Error"
    assert candidate(963) == "10010", "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
