
import unittest
import re
import sys
import math
import copy


def sort_array(arr):
    """
    Sort an array of integers by the number of ones in their binary representation
    in ascending order. If two numbers have the same number of ones, sort them
    by their decimal value.

    Examples:
    >>> sort_array([1, 5, 2, 3, 4])
    [1, 2, 4, 3, 5]
    >>> sort_array([-2, -3, -4, -5, -6])
    [-4, -2, -6, -5, -3]
    >>> sort_array([1, 0, 2, 3, 4])
    [0, 1, 2, 4, 3]
    """
    if arr is None:
        raise TypeError("arr must not be None")

    if not isinstance(arr, (list, tuple)):
        raise TypeError("arr must be a list or tuple of integers")

    for i, value in enumerate(arr):
        if isinstance(value, bool) or not isinstance(value, int):
            raise TypeError(f"arr[{i}] must be an integer, got {type(value).__name__}")

    try:
        return sorted(arr, key=lambda x: (bin(x).count("1"), x))
    except TypeError as exc:
        raise TypeError("failed to sort array due to invalid element types") from exc
    except Exception as exc:
        raise RuntimeError("unexpected error occurred while sorting the array") from exc
candidate = sort_array


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,5,2,3,4]) == [1, 2, 4, 3, 5]
    assert candidate([-2,-3,-4,-5,-6]) == [-4, -2, -6, -5, -3]
    assert candidate([1,0,2,3,4]) == [0, 1, 2, 4, 3]
    assert candidate([]) == []
    assert candidate([2,5,77,4,5,3,5,7,2,3,4]) == [2, 2, 4, 4, 3, 3, 5, 5, 5, 7, 77]
    assert candidate([3,6,44,12,32,5]) == [32, 3, 5, 6, 12, 44]
    assert candidate([2,4,8,16,32]) == [2, 4, 8, 16, 32]
    assert candidate([2,4,8,16,32]) == [2, 4, 8, 16, 32]

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
