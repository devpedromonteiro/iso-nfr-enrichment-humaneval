
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def factorize(n: int) -> List[int]:
    """Return list of prime factors of given integer in ascending order.

    Each factor appears as many times as it occurs in the prime factorization.

    Input number should be equal to the product of all factors.

    >>> factorize(8)
    [2, 2, 2]
    >>> factorize(25)
    [5, 5]
    >>> factorize(70)
    [2, 5, 7]
    """
    if not isinstance(n, int):
        raise TypeError(f"n must be an integer, got {type(n).__name__}")
    if isinstance(n, bool):
        raise TypeError("n must be an integer, not bool")
    if n <= 1:
        raise ValueError("n must be greater than 1")

    factors: List[int] = []
    original_n = n

    try:
        divisor = 2
        while divisor * divisor <= n:
            while n % divisor == 0:
                factors.append(divisor)
                n //= divisor
            divisor += 1

        if n > 1:
            factors.append(n)

        product = 1
        for factor in factors:
            product *= factor

        if product != original_n:
            raise ArithmeticError(
                f"inconsistent factorization result: product {product} != input {original_n}"
            )

        return factors

    except (TypeError, ValueError, ArithmeticError):
        raise
    except Exception as exc:
        raise RuntimeError("unexpected error during factorization") from exc
candidate = factorize




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(2) == [2]
    assert candidate(4) == [2, 2]
    assert candidate(8) == [2, 2, 2]
    assert candidate(3 * 19) == [3, 19]
    assert candidate(3 * 19 * 3 * 19) == [3, 3, 19, 19]
    assert candidate(3 * 19 * 3 * 19 * 3 * 19) == [3, 3, 3, 19, 19, 19]
    assert candidate(3 * 19 * 19 * 19) == [3, 19, 19, 19]
    assert candidate(3 * 2 * 3) == [2, 3, 3]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
