
import unittest
import re
import sys
import math
import copy



def correct_bracketing(brackets: str) -> bool:
    """brackets is a string of "(" and ")".
    Return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("(")
    False
    >>> correct_bracketing("()")
    True
    >>> correct_bracketing("(()())")
    True
    >>> correct_bracketing(")(()")
    False
    """
    if not isinstance(brackets, str):
        raise TypeError("brackets must be a string")

    balance = 0

    for i, ch in enumerate(brackets):
        if ch == "(":
            balance += 1
        elif ch == ")":
            balance -= 1
        else:
            raise ValueError(
                f"invalid character at index {i}: {ch!r}; only '(' and ')' are allowed"
            )

        if balance < 0:
            return False

    return balance == 0
candidate = correct_bracketing




METADATA = {}


def check(candidate):
    assert candidate("()")
    assert candidate("(()())")
    assert candidate("()()(()())()")
    assert candidate("()()((()()())())(()()(()))")
    assert not candidate("((()())))")
    assert not candidate(")(()")
    assert not candidate("(")
    assert not candidate("((((")
    assert not candidate(")")
    assert not candidate("(()")
    assert not candidate("()()(()())())(()")
    assert not candidate("()()(()())()))()")



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
