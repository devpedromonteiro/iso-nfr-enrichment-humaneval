
import unittest
import re
import sys
import math
import copy



def derivative(xs: list):
    """xs represent coefficients of a polynomial.
    xs[0] + xs[1] * x + xs[2] * x^2 + ....
    Return derivative of this polynomial in the same form.

    >>> derivative([3, 1, 2, 4, 5])
    [1, 4, 12, 20]
    >>> derivative([1, 2, 3])
    [2, 6]
    """
    if xs is None:
        raise TypeError("xs must be a list of numeric coefficients, got None")

    if not isinstance(xs, list):
        raise TypeError(f"xs must be a list, got {type(xs).__name__}")

    if len(xs) == 0:
        return []

    result = []
    for i, coeff in enumerate(xs[1:], start=1):
        if not isinstance(coeff, (int, float, complex)):
            raise TypeError(
                f"coefficient at index {i} must be numeric, got {type(coeff).__name__}"
            )
        result.append(i * coeff)

    # Validate xs[0] as well for consistency, even though it does not affect output.
    if not isinstance(xs[0], (int, float, complex)):
        raise TypeError(
            f"coefficient at index 0 must be numeric, got {type(xs[0]).__name__}"
        )

    return result
candidate = derivative




METADATA = {}


def check(candidate):
    assert candidate([3, 1, 2, 4, 5]) == [1, 4, 12, 20]
    assert candidate([1, 2, 3]) == [2, 6]
    assert candidate([3, 2, 1]) == [2, 2]
    assert candidate([3, 2, 1, 0, 4]) == [2, 2, 0, 16]
    assert candidate([1]) == []



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
