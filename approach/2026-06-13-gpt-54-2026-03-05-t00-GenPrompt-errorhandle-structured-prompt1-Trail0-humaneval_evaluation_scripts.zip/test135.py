
import unittest
import re
import sys
import math
import copy


def can_arrange(arr):
    """Return the largest index i such that arr[i] <= arr[i - 1].

    If no such index exists, return -1.

    The input array is expected to contain no duplicate values.

    Examples:
        can_arrange([1, 2, 4, 3, 5]) -> 3
        can_arrange([1, 2, 3]) -> -1
    """
    if arr is None:
        raise TypeError("arr must not be None")

    if not isinstance(arr, (list, tuple)):
        raise TypeError("arr must be a list or tuple")

    if len(arr) < 2:
        return -1

    try:
        for i in range(len(arr) - 1, 0, -1):
            if arr[i] <= arr[i - 1]:
                return i
    except TypeError as exc:
        raise TypeError(
            "all elements in arr must be mutually comparable"
        ) from exc
    except IndexError as exc:
        raise ValueError(
            "arr is in an invalid state for sequential comparison"
        ) from exc

    return -1
candidate = can_arrange


def check(candidate):

    # Check some simple cases
    assert candidate([1,2,4,3,5])==3
    assert candidate([1,2,4,5])==-1
    assert candidate([1,4,2,5,6,7,8,9,10])==2
    assert candidate([4,8,5,7,3])==4

    # Check some edge cases that are easy to work out by hand.
    assert candidate([])==-1



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
