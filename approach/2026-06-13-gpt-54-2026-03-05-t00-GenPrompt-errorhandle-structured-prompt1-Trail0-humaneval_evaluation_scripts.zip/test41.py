
import unittest
import re
import sys
import math
import copy



def car_race_collision(n: int):
    """
    Imagine a road that's a perfectly straight infinitely long line.
    n cars are driving left to right; simultaneously, a different set of n cars
    are driving right to left. The two sets of cars start out being very far from
    each other. All cars move at the same speed. Two cars are said to collide
    when a car that's moving left to right hits a car that's moving right to left.
    However, the cars are infinitely sturdy and strong; as a result, they continue moving
    in their trajectory as if they did not collide.

    This function outputs the number of such collisions.

    Error handling:
    - Raises TypeError if n is not an integer.
    - Raises ValueError if n is negative.
    """
    try:
        if isinstance(n, bool) or not isinstance(n, int):
            raise TypeError("n must be an integer")
        if n < 0:
            raise ValueError("n must be non-negative")

        # Each left-to-right car collides with each right-to-left car.
        return n * n

    except (TypeError, ValueError):
        # Re-raise specific validation errors unchanged.
        raise
    except Exception as exc:
        # Wrap unexpected errors with context instead of silently swallowing them.
        raise RuntimeError("Unexpected error while calculating car race collisions") from exc
candidate = car_race_collision




METADATA = {}


def check(candidate):
    assert candidate(2) == 4
    assert candidate(3) == 9
    assert candidate(4) == 16
    assert candidate(8) == 64
    assert candidate(10) == 100



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
