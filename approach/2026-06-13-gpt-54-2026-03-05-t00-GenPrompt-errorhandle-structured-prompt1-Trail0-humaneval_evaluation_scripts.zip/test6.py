
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """Input to this function is a string represented multiple groups for nested
    parentheses separated by spaces. For each group, output the deepest level of
    nesting of parentheses.

    E.g. (()()) has maximum two levels of nesting while ((())) has three.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """
    if not isinstance(paren_string, str):
        raise TypeError("paren_string must be a string")

    if not paren_string.strip():
        return []

    groups = paren_string.split()
    result: List[int] = []

    for group in groups:
        if not group:
            raise ValueError("Empty parenthesis group is not allowed")

        depth = 0
        max_depth = 0

        for char in group:
            if char == "(":
                depth += 1
                if depth > max_depth:
                    max_depth = depth
            elif char == ")":
                depth -= 1
                if depth < 0:
                    raise ValueError(f"Unbalanced parentheses: too many closing parentheses in group '{group}'")
            else:
                raise ValueError(f"Invalid character '{char}' in group '{group}'. Only '(' and ')' are allowed.")

        if depth != 0:
            raise ValueError(f"Unbalanced parentheses: missing closing parentheses in group '{group}'")

        result.append(max_depth)

    return result
candidate = parse_nested_parens




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('(()()) ((())) () ((())()())') == [2, 3, 1, 3]
    assert candidate('() (()) ((())) (((())))') == [1, 2, 3, 4]
    assert candidate('(()(())((())))') == [4]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
