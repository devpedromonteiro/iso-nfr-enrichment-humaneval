
import unittest
import re
import sys
import math
import copy



def add(x: int, y: int) -> int:
    """Add two numbers x and y.

    >>> add(2, 3)
    5
    >>> add(5, 7)
    12
    >>> add("2", 3)
    Traceback (most recent call last):
    ...
    TypeError: x must be an int, got str
    >>> add(2, None)
    Traceback (most recent call last):
    ...
    TypeError: y must be an int, got NoneType
    """
    try:
        if not isinstance(x, int):
            raise TypeError(f"x must be an int, got {type(x).__name__}")
        if not isinstance(y, int):
            raise TypeError(f"y must be an int, got {type(y).__name__}")

        result = x + y

    except TypeError:
        # Re-raise specific validation/type errors without swallowing them
        raise
    except Exception as exc:
        # Wrap unexpected failures in a specific runtime error
        raise RuntimeError("unexpected failure while adding values") from exc

    return result
candidate = add




METADATA = {}


def check(candidate):
    import random

    assert candidate(0, 1) == 1
    assert candidate(1, 0) == 1
    assert candidate(2, 3) == 5
    assert candidate(5, 7) == 12
    assert candidate(7, 5) == 12

    for i in range(100):
        x, y = random.randint(0, 1000), random.randint(0, 1000)
        assert candidate(x, y) == x + y



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
