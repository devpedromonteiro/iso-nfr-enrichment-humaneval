
import unittest
import re
import sys
import math
import copy


def closest_integer(value):
    '''
    Create a function that takes a value (string) representing a number
    and returns the closest integer to it. If the number is equidistant
    from two integers, round it away from zero.

    Examples
    >>> closest_integer("10")
    10
    >>> closest_integer("15.3")
    15

    Note:
    Rounding away from zero means that if the given number is equidistant
    from two integers, the one you should return is the one that is the
    farthest from zero. For example closest_integer("14.5") should
    return 15 and closest_integer("-14.5") should return -15.
    '''
    if not isinstance(value, str):
        raise TypeError("value must be a string representing a number")

    value = value.strip()
    if not value:
        raise ValueError("value cannot be an empty string")

    try:
        number = float(value)
    except ValueError as exc:
        raise ValueError(f"invalid numeric string: {value!r}") from exc

    if number == float("inf") or number == float("-inf"):
        raise ValueError("value must be a finite number")

    if number != number:  # NaN check
        raise ValueError("value must not be NaN")

    integer_part = int(number)
    fractional_part = abs(number - integer_part)

    if number >= 0:
        if fractional_part < 0.5:
            return integer_part
        return integer_part + 1
    else:
        if fractional_part < 0.5:
            return integer_part
        return integer_part - 1
candidate = closest_integer


def check(candidate):

    # Check some simple cases
    assert candidate("10") == 10, "Test 1"
    assert candidate("14.5") == 15, "Test 2"
    assert candidate("-15.5") == -16, "Test 3"
    assert candidate("15.3") == 15, "Test 3"

    # Check some edge cases that are easy to work out by hand.
    assert candidate("0") == 0, "Test 0"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
