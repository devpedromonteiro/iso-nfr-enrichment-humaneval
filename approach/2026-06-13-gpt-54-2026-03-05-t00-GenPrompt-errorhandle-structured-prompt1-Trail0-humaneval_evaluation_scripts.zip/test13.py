
import unittest
import re
import sys
import math
import copy



def greatest_common_divisor(a: int, b: int) -> int:
    """Return the greatest common divisor of two integers a and b.

    Validates inputs explicitly and raises specific exceptions for invalid
    arguments.

    >>> greatest_common_divisor(3, 5)
    1
    >>> greatest_common_divisor(25, 15)
    5
    """
    if not isinstance(a, int) or isinstance(a, bool):
        raise TypeError(f"a must be an integer, got {type(a).__name__}")
    if not isinstance(b, int) or isinstance(b, bool):
        raise TypeError(f"b must be an integer, got {type(b).__name__}")

    if a == 0 and b == 0:
        raise ValueError("greatest common divisor is undefined for a=0 and b=0")

    a, b = abs(a), abs(b)

    try:
        while b != 0:
            a, b = b, a % b
        return a
    except ZeroDivisionError as exc:
        # Defensive handling: preserve explicit failure semantics
        raise ArithmeticError("unexpected arithmetic failure during GCD computation") from exc
candidate = greatest_common_divisor




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(3, 7) == 1
    assert candidate(10, 15) == 5
    assert candidate(49, 14) == 7
    assert candidate(144, 60) == 12


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
