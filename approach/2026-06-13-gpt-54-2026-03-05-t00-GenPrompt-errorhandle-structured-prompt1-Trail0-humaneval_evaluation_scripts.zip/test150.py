
import unittest
import re
import sys
import math
import copy


def x_or_y(n, x, y):
    """Return x if n is prime, otherwise return y.

    Examples:
    >>> x_or_y(7, 34, 12)
    34
    >>> x_or_y(15, 8, 5)
    5
    """

    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if n < 0:
        raise ValueError("n must be a non-negative integer")

    def is_prime(value):
        if value < 2:
            return False
        if value == 2:
            return True
        if value % 2 == 0:
            return False

        limit = int(value ** 0.5) + 1
        for i in range(3, limit, 2):
            if value % i == 0:
                return False
        return True

    return x if is_prime(n) else y
candidate = x_or_y


def check(candidate):

    # Check some simple cases
    assert candidate(7, 34, 12) == 34
    assert candidate(15, 8, 5) == 5
    assert candidate(3, 33, 5212) == 33
    assert candidate(1259, 3, 52) == 3
    assert candidate(7919, -1, 12) == -1
    assert candidate(3609, 1245, 583) == 583
    assert candidate(91, 56, 129) == 129
    assert candidate(6, 34, 1234) == 1234
    

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1, 2, 0) == 0
    assert candidate(2, 2, 0) == 2



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
