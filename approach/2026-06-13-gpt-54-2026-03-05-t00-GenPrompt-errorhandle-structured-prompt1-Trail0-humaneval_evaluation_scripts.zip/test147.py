
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    You are given a positive integer n. Create an array a of length n where:
        a[i] = i * i - i + 1   for 1 <= i <= n

    Return the number of triples (a[i], a[j], a[k]) such that i < j < k and
    a[i] + a[j] + a[k] is divisible by 3.

    Example:
        n = 5
        a = [1, 3, 7, 13, 21]
        valid triple count = 1
    """
    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if isinstance(n, bool):
        raise TypeError("n must be an integer, not bool")
    if n <= 0:
        raise ValueError("n must be a positive integer")

    try:
        # a[i] = i^2 - i + 1
        # Mod 3 pattern:
        # i % 3 == 0 -> a[i] % 3 == 1
        # i % 3 == 1 -> a[i] % 3 == 1
        # i % 3 == 2 -> a[i] % 3 == 0
        #
        # So array elements are only congruent to 0 or 1 mod 3.
        # A triple sum is divisible by 3 only when residues are:
        # (1,1,1) or (0,1,2) etc.
        # Since residue 2 never occurs, only (1,1,1) works.

        count_mod_1 = 0
        for i in range(1, n + 1):
            if (i * i - i + 1) % 3 == 1:
                count_mod_1 += 1

        if count_mod_1 < 3:
            return 0

        return count_mod_1 * (count_mod_1 - 1) * (count_mod_1 - 2) // 6

    except OverflowError as exc:
        raise OverflowError("numeric overflow occurred while computing triples") from exc
    except Exception:
        # Re-raise unexpected exceptions to avoid silently swallowing errors
        raise
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
