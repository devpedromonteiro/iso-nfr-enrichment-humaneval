
import unittest
import re
import sys
import math
import copy


def make_a_pile(n):
    """
    Given a positive integer n, make a pile of n levels of stones.

    The first level has n stones.
    Each next level increases by 2, preserving odd/even parity.

    Examples:
    >>> make_a_pile(3)
    [3, 5, 7]
    >>> make_a_pile(4)
    [4, 6, 8, 10]
    """
    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if isinstance(n, bool):
        raise TypeError("n must be an integer, not bool")
    if n <= 0:
        raise ValueError("n must be a positive integer")

    try:
        pile = [n + 2 * i for i in range(n)]
    except OverflowError as e:
        raise OverflowError("integer value too large to build pile") from e
    except Exception:
        # Re-raise unexpected exceptions to avoid silently swallowing errors
        raise

    if len(pile) != n:
        raise RuntimeError("failed to construct a consistent pile")

    return pile
candidate = make_a_pile


def check(candidate):

    # Check some simple cases
    assert candidate(3) == [3, 5, 7], "Test 3"
    assert candidate(4) == [4,6,8,10], "Test 4"
    assert candidate(5) == [5, 7, 9, 11, 13]
    assert candidate(6) == [6, 8, 10, 12, 14, 16]
    assert candidate(8) == [8, 10, 12, 14, 16, 18, 20, 22]

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
