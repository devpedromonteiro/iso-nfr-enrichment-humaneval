
import unittest
import re
import sys
import math
import copy


def generate_integers(a, b):
    """
    Given two positive integers a and b, return the even digits between a
    and b, in ascending order.

    For example:
    generate_integers(2, 8) => [2, 4, 6, 8]
    generate_integers(8, 2) => [2, 4, 6, 8]
    generate_integers(10, 14) => []

    Raises:
        TypeError: If a or b is not an integer.
        ValueError: If a or b is not a positive integer.
    """
    try:
        if not isinstance(a, int) or not isinstance(b, int):
            raise TypeError("Both a and b must be integers.")

        if a <= 0 or b <= 0:
            raise ValueError("Both a and b must be positive integers.")

        start, end = sorted((a, b))

        result = []
        for n in range(start, end + 1):
            if 0 <= n <= 9 and n % 2 == 0:
                result.append(n)

        return result

    except (TypeError, ValueError):
        # Re-raise specific validation errors so callers can handle them explicitly.
        raise
    except Exception as exc:
        # Wrap unexpected errors to avoid silent failure while preserving context.
        raise RuntimeError("Unexpected error while generating integers.") from exc
candidate = generate_integers


def check(candidate):

    # Check some simple cases
    assert candidate(2, 10) == [2, 4, 6, 8], "Test 1"
    assert candidate(10, 2) == [2, 4, 6, 8], "Test 2"
    assert candidate(132, 2) == [2, 4, 6, 8], "Test 3"
    assert candidate(17,89) == [], "Test 4"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
