
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[2] * x^2 + .... + xs[n] * x^n
    """
    if not isinstance(xs, list):
        raise TypeError("xs must be a list of numeric coefficients")
    if len(xs) == 0:
        raise ValueError("xs must not be empty")
    if not isinstance(x, (int, float)):
        raise TypeError("x must be a numeric value")

    total = 0.0
    for i, coeff in enumerate(xs):
        if not isinstance(coeff, (int, float)):
            raise TypeError(f"coefficient at index {i} must be numeric")
        total += coeff * math.pow(x, i)
    return total


def find_zero(xs: list):
    """xs are coefficients of a polynomial.
    find_zero finds x such that poly(x) = 0.
    find_zero returns only one zero point, even if there are many.
    Moreover, find_zero only takes list xs having even number of coefficients
    and largest non-zero coefficient as positive, which guarantees
    a solution.

    >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2)  # (x - 1) * (x - 2) * (x - 3)
    1.0
    """
    if not isinstance(xs, list):
        raise TypeError("xs must be a list of numeric coefficients")
    if len(xs) == 0:
        raise ValueError("xs must not be empty")
    if len(xs) % 2 != 0:
        raise ValueError("xs must contain an even number of coefficients")

    for i, coeff in enumerate(xs):
        if not isinstance(coeff, (int, float)):
            raise TypeError(f"coefficient at index {i} must be numeric")

    # Remove trailing zeros safely to determine the actual degree.
    coeffs = xs[:]
    while coeffs and coeffs[-1] == 0:
        coeffs.pop()

    if not coeffs:
        raise ValueError("polynomial must not be the zero polynomial")

    if coeffs[-1] <= 0:
        raise ValueError("largest non-zero coefficient must be positive")

    # Linear case: a + bx = 0
    if len(coeffs) == 2:
        a, b = coeffs
        if b == 0:
            raise ZeroDivisionError("linear polynomial has zero leading coefficient")
        return -a / b

    def f(value: float) -> float:
        return poly(coeffs, value)

    # Since degree is odd (original even number of coefficients => odd degree
    # after valid trailing-zero trimming with positive leading coefficient),
    # search for a sign change.
    left = -1.0
    right = 1.0

    try:
        f_left = f(left)
        f_right = f(right)
    except (TypeError, ValueError, OverflowError) as exc:
        raise RuntimeError("failed to evaluate polynomial during bracketing") from exc

    # Expand interval until a root is bracketed or exact root found.
    max_iterations = 10_000
    iterations = 0
    while f_left * f_right > 0:
        iterations += 1
        if iterations > max_iterations:
            raise RuntimeError("failed to bracket a root within iteration limit")

        left *= 2
        right *= 2

        try:
            f_left = f(left)
            f_right = f(right)
        except OverflowError as exc:
            raise OverflowError("numeric overflow while searching for a root interval") from exc

    if f_left == 0:
        return left
    if f_right == 0:
        return right

    # Bisection method on a valid bracket.
    for _ in range(200):
        mid = (left + right) / 2.0
        f_mid = f(mid)

        if abs(f_mid) < 1e-12:
            return mid

        if f_left * f_mid <= 0:
            right = mid
            f_right = f_mid
        else:
            left = mid
            f_left = f_mid

    # Return best approximation without leaving inconsistent state.
    return (left + right) / 2.0
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
