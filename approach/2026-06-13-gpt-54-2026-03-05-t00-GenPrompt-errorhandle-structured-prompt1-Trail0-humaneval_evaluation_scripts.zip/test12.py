
import unittest
import re
import sys
import math
import copy

from typing import List, Optional


from typing import List, Optional


def longest(strings: List[str]) -> Optional[str]:
    """Out of list of strings, return the longest one.

    Return the first one in case of multiple strings of the same length.
    Return None in case the input list is empty.

    >>> longest([])

    >>> longest(['a', 'b', 'c'])
    'a'
    >>> longest(['a', 'bb', 'ccc'])
    'ccc'
    """
    if strings is None:
        raise TypeError("strings must be a list of strings, got None")

    if not isinstance(strings, list):
        raise TypeError(f"strings must be a list of strings, got {type(strings).__name__}")

    if len(strings) == 0:
        return None

    longest_string: Optional[str] = None
    max_length = -1

    for index, value in enumerate(strings):
        if value is None:
            raise TypeError(f"element at index {index} must be str, got None")
        if not isinstance(value, str):
            raise TypeError(
                f"element at index {index} must be str, got {type(value).__name__}"
            )

        current_length = len(value)
        if current_length > max_length:
            longest_string = value
            max_length = current_length

    return longest_string
candidate = longest




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == None
    assert candidate(['x', 'y', 'z']) == 'x'
    assert candidate(['x', 'yyy', 'zzzz', 'www', 'kkkk', 'abc']) == 'zzzz'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
