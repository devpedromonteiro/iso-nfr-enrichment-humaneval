
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """Check if any two numbers in the list are closer than the given threshold.

    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """
    if numbers is None:
        raise TypeError("numbers must not be None")
    if not isinstance(numbers, list):
        raise TypeError("numbers must be a list of numeric values")
    if threshold is None:
        raise TypeError("threshold must not be None")
    if not isinstance(threshold, (int, float)):
        raise TypeError("threshold must be a numeric value")
    if threshold < 0:
        raise ValueError("threshold must be non-negative")

    try:
        validated_numbers = []
        for i, value in enumerate(numbers):
            if not isinstance(value, (int, float)):
                raise TypeError(f"numbers[{i}] must be numeric, got {type(value).__name__}")
            validated_numbers.append(float(value))
        validated_threshold = float(threshold)
    except (TypeError, ValueError) as exc:
        raise exc

    sorted_numbers = sorted(validated_numbers)

    for i in range(len(sorted_numbers) - 1):
        if abs(sorted_numbers[i + 1] - sorted_numbers[i]) < validated_threshold:
            return True

    return False
candidate = has_close_elements




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([1.0, 2.0, 3.9, 4.0, 5.0, 2.2], 0.3) == True
    assert candidate([1.0, 2.0, 3.9, 4.0, 5.0, 2.2], 0.05) == False
    assert candidate([1.0, 2.0, 5.9, 4.0, 5.0], 0.95) == True
    assert candidate([1.0, 2.0, 5.9, 4.0, 5.0], 0.8) == False
    assert candidate([1.0, 2.0, 3.0, 4.0, 5.0, 2.0], 0.1) == True
    assert candidate([1.1, 2.2, 3.1, 4.1, 5.1], 1.0) == True
    assert candidate([1.1, 2.2, 3.1, 4.1, 5.1], 0.5) == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
