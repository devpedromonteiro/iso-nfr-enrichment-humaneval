
import unittest
import re
import sys
import math
import copy


FIX = """
Add more test cases.
"""

FIX = """
Add more test cases.
"""

def vowels_count(s):
    """Write a function vowels_count which takes a string representing
    a word as input and returns the number of vowels in the string.
    Vowels in this case are 'a', 'e', 'i', 'o', 'u'. Here, 'y' is also a
    vowel, but only when it is at the end of the given word.

    Example:
    >>> vowels_count("abcde")
    2
    >>> vowels_count("ACEDY")
    3
    >>> vowels_count("sky")
    1
    >>> vowels_count("why")
    1
    >>> vowels_count("yellow")
    2
    >>> vowels_count("")
    0
    >>> vowels_count(None)
    Traceback (most recent call last):
    ...
    TypeError: s must be a string
    >>> vowels_count(123)
    Traceback (most recent call last):
    ...
    TypeError: s must be a string
    """
    if s is None:
        raise TypeError("s must be a string")
    if not isinstance(s, str):
        raise TypeError("s must be a string")

    word = s.lower()
    count = sum(1 for ch in word if ch in "aeiou")

    if word.endswith("y"):
        count += 1

    return count
candidate = vowels_count


def check(candidate):

    # Check some simple cases
    assert candidate("abcde") == 2, "Test 1"
    assert candidate("Alone") == 3, "Test 2"
    assert candidate("key") == 2, "Test 3"
    assert candidate("bye") == 1, "Test 4"
    assert candidate("keY") == 2, "Test 5"
    assert candidate("bYe") == 1, "Test 6"
    assert candidate("ACEDY") == 3, "Test 7"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
