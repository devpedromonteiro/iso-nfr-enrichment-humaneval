
import unittest


def solve(N):
    """Given a non-negative integer N, return the binary representation
    of the sum of its decimal digits.

    Examples:
        solve(1000) -> "1"
        solve(150)  -> "110"
        solve(147)  -> "1100"

    Args:
        N: Integer in the range 0 <= N <= 10000.

    Returns:
        A string containing the binary representation of the sum of digits.

    Raises:
        TypeError: If N is not an integer.
        ValueError: If N is outside the allowed range.
    """
    if not isinstance(N, int):
        raise TypeError("N must be an integer")

    if N < 0 or N > 10000:
        raise ValueError("N must satisfy 0 <= N <= 10000")

    digit_sum = sum(int(ch) for ch in str(N))
    return bin(digit_sum)[2:]
candidate = solve


class Test(unittest.TestCase):
    def test(self):
        assert candidate(8319) == '10101'
        assert candidate(4714) == '10000'
        assert candidate(615) == '1100'
        assert candidate(856) == '10011'
        assert candidate(5052) == '1100'
        assert candidate(9844) == '11001'
        assert candidate(150) == "110", "Error"
        assert candidate(4963) == '10110'
        assert candidate(5389) == '11001'
        assert candidate(6758) == '11010'
        assert candidate(4145) == '1110'
        assert candidate(4237) == '10000'
        assert candidate(2617) == '10000'
        assert candidate(8688) == '11110'
        assert candidate(963) == "10010", "Error"
        assert candidate(3678) == '11000'
        assert candidate(4324) == '1101'
        assert candidate(4354) == '10000'
        assert candidate(147) == "1100", "Error"

    # Check some edge cases that are easy to work out by hand.
        assert candidate(1154) == '1011'
        assert candidate(2206) == '1010'
        assert candidate(8259) == '11000'
        assert candidate(7793) == '11010'
        assert candidate(1649) == '10100'
        assert candidate(1000) == "1", "Error"
        assert candidate(8782) == '11001'
        assert candidate(7181) == '10001'
        assert candidate(9566) == '11010'
        assert candidate(8524) == '10011'
        assert candidate(388) == '10011'
        assert candidate(1651) == '1101'
        assert candidate(529) == '10000'
        assert candidate(1583) == '10001'
        assert candidate(4743) == '10010'
        assert candidate(336) == '1100'
        assert candidate(8438) == '10111'
        assert candidate(1939) == '10110'
        assert candidate(8774) == '11010'
        assert candidate(6286) == '10110'
        assert candidate(9391) == '10110'
        assert candidate(8677) == '11100'
        assert candidate(4076) == '10001'
        assert candidate(1718) == '10001'
        assert candidate(2762) == '10001'
        assert candidate(1259) == '10001'
        assert candidate(9046) == '10011'
        assert candidate(3304) == '1010'
        assert candidate(2717) == '10001'
        assert candidate(9350) == '10001'
        assert candidate(1421) == '1000'
        assert candidate(4647) == '10101'
        assert candidate(6789) == '11110'
        assert candidate(9688) == '11111'
        assert candidate(8769) == '11110'
        assert candidate(4558) == '10110'
        assert candidate(9085) == '10110'
        assert candidate(8671) == '10110'
        assert candidate(4701) == '1100'
        assert candidate(2193) == '1111'
        assert candidate(5383) == '10011'
        assert candidate(120) == '11'
        assert candidate(5749) == '11001'
        assert candidate(6795) == '11011'
        assert candidate(8540) == '10001'
        assert candidate(1105) == '111'
        assert candidate(8888) == '100000'
        assert candidate(8992) == '11100'
        assert candidate(6033) == '1100'
        assert candidate(9932) == '10111'
        assert candidate(122) == '101'
        assert candidate(4420) == '1010'
        assert candidate(6281) == '10001'
        assert candidate(4809) == '10101'
        assert candidate(6013) == '1010'
        assert candidate(7839) == '11011'
        assert candidate(7944) == '11000'
        assert candidate(4906) == '10011'
        assert candidate(1488) == '10101'
        assert candidate(4876) == '11001'
        assert candidate(5084) == '10001'
        assert candidate(6183) == '10010'
        assert candidate(7459) == '11001'
        assert candidate(5881) == '10110'
        assert candidate(7579) == '11100'
        assert candidate(9468) == '11011'
        assert candidate(5037) == '1111'
        assert candidate(8961) == '11000'
        assert candidate(5396) == '10111'
        assert candidate(8811) == '10010'
        assert candidate(333) == "1001", "Error"
        assert candidate(4989) == '11110'
        assert candidate(1011) == '11'
        assert candidate(4399) == '11001'
        assert candidate(6580) == '10011'
        assert candidate(9508) == '10110'
        assert candidate(7187) == '10111'
        assert candidate(445) == '1101'
        assert candidate(9641) == '10100'
        assert candidate(8490) == '10101'
        assert candidate(7814) == '10100'
        assert candidate(6028) == '10000'
        assert candidate(8525) == '10100'
        assert candidate(8429) == '10111'
        assert candidate(2226) == '1100'
        assert candidate(8757) == '11011'

if __name__ == '__main__':
    unittest.main()
