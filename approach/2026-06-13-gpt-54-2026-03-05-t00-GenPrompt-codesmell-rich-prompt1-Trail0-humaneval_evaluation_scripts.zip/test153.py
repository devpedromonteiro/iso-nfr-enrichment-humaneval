
import unittest
import re
import sys
import math
import copy


def _extension_strength(extension):
    """Compute strength as uppercase count minus lowercase count."""
    upper_count = sum(1 for char in extension if char.isupper())
    lower_count = sum(1 for char in extension if char.islower())
    return upper_count - lower_count


def _strongest_extension(extensions):
    """Return the strongest extension, preserving first occurrence on ties."""
    best_extension = extensions[0]
    best_strength = _extension_strength(best_extension)

    for extension in extensions[1:]:
        current_strength = _extension_strength(extension)
        if current_strength > best_strength:
            best_extension = extension
            best_strength = current_strength

    return best_extension


def Strongest_Extension(class_name, extensions):
    """Return 'ClassName.StrongestExtensionName' for the strongest extension."""
    strongest = _strongest_extension(extensions)
    return f"{class_name}.{strongest}"
candidate = Strongest_Extension


def check(candidate):

    # Check some simple cases
    assert candidate('Watashi', ['tEN', 'niNE', 'eIGHt8OKe']) == 'Watashi.eIGHt8OKe'
    assert candidate('Boku123', ['nani', 'NazeDa', 'YEs.WeCaNe', '32145tggg']) == 'Boku123.YEs.WeCaNe'
    assert candidate('__YESIMHERE', ['t', 'eMptY', 'nothing', 'zeR00', 'NuLl__', '123NoooneB321']) == '__YESIMHERE.NuLl__'
    assert candidate('K', ['Ta', 'TAR', 't234An', 'cosSo']) == 'K.TAR'
    assert candidate('__HAHA', ['Tab', '123', '781345', '-_-']) == '__HAHA.123'
    assert candidate('YameRore', ['HhAas', 'okIWILL123', 'WorkOut', 'Fails', '-_-']) == 'YameRore.okIWILL123'
    assert candidate('finNNalLLly', ['Die', 'NowW', 'Wow', 'WoW']) == 'finNNalLLly.WoW'

    # Check some edge cases that are easy to work out by hand.
    assert candidate('_', ['Bb', '91245']) == '_.Bb'
    assert candidate('Sp', ['671235', 'Bb']) == 'Sp.671235'
    


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
