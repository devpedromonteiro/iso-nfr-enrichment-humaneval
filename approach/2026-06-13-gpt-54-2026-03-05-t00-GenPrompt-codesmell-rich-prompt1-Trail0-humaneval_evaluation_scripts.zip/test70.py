
import unittest
import re
import sys
import math
import copy


def _take_from_ends(sorted_values, left_index, right_index, take_min):
    """Return the next value and updated pointers."""
    if take_min:
        return sorted_values[left_index], left_index + 1, right_index
    return sorted_values[right_index], left_index, right_index - 1


def strange_sort_list(lst):
    '''
    Given list of integers, return list in strange order.
    Strange sorting, is when you start with the minimum value,
    then maximum of the remaining integers, then minimum and so on.

    Examples:
    strange_sort_list([1, 2, 3, 4]) == [1, 4, 2, 3]
    strange_sort_list([5, 5, 5, 5]) == [5, 5, 5, 5]
    strange_sort_list([]) == []
    '''
    sorted_values = sorted(lst)
    result = []

    left_index = 0
    right_index = len(sorted_values) - 1
    take_min = True

    while left_index <= right_index:
        value, left_index, right_index = _take_from_ends(
            sorted_values,
            left_index,
            right_index,
            take_min,
        )
        result.append(value)
        take_min = not take_min

    return result
candidate = strange_sort_list


def check(candidate):

    # Check some simple cases
    assert candidate([1, 2, 3, 4]) == [1, 4, 2, 3]
    assert candidate([5, 6, 7, 8, 9]) == [5, 9, 6, 8, 7]
    assert candidate([1, 2, 3, 4, 5]) == [1, 5, 2, 4, 3]
    assert candidate([5, 6, 7, 8, 9, 1]) == [1, 9, 5, 8, 6, 7]
    assert candidate([5, 5, 5, 5]) == [5, 5, 5, 5]
    assert candidate([]) == []
    assert candidate([1,2,3,4,5,6,7,8]) == [1, 8, 2, 7, 3, 6, 4, 5]
    assert candidate([0,2,2,2,5,5,-5,-5]) == [-5, 5, -5, 5, 0, 2, 2, 2]
    assert candidate([111111]) == [111111]

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
