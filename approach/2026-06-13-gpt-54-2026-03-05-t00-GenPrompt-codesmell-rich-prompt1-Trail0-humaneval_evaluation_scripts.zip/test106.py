
import unittest
import re
import sys
import math
import copy


def factorial(value):
    """Return the factorial of a positive integer."""
    result = 1
    for number in range(1, value + 1):
        result *= number
    return result


def sum_to(value):
    """Return the sum of integers from 1 to value."""
    return value * (value + 1) // 2


def value_for_index(index):
    """Return the required value for a 1-based index."""
    if index % 2 == 0:
        return factorial(index)
    return sum_to(index)


def f(n):
    """Return a list of size n following the required rule.

    For each 1-based index i:
    - if i is even, the value is factorial(i)
    - otherwise, the value is sum(1..i)
    """
    return [value_for_index(i) for i in range(1, n + 1)]
candidate = f


def check(candidate):

    assert candidate(5) == [1, 2, 6, 24, 15]
    assert candidate(7) == [1, 2, 6, 24, 15, 720, 28]
    assert candidate(1) == [1]
    assert candidate(3) == [1, 2, 6]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
