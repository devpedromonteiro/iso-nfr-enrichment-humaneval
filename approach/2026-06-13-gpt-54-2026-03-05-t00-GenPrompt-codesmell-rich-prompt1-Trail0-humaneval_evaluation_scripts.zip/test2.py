
import unittest
import re
import sys
import math
import copy



def _integer_part(number: float) -> int:
    """Return the integer part of a positive floating point number."""
    return int(number)


def _decimal_part(number: float, integer_part: int) -> float:
    """Return the decimal part from a number and its integer part."""
    return number - integer_part


def truncate_number(number: float) -> float:
    """Given a positive floating point number, return its decimal part.

    >>> truncate_number(3.5)
    0.5
    """
    integer_part = _integer_part(number)
    return _decimal_part(number, integer_part)
candidate = truncate_number




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(3.5) == 0.5
    assert abs(candidate(1.33) - 0.33) < 1e-6
    assert abs(candidate(123.456) - 0.456) < 1e-6


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
