
import unittest
import re
import sys
import math
import copy


def _count_odds(numbers):
    """Return the number of odd values in the given list."""
    return sum(1 for number in numbers if number % 2 != 0)


def exchange(lst1, lst2):
    """Determine whether lst1 can be made entirely even via exchanges with lst2.

    An exchange can swap any number of elements between the two lists. Since only
    parity matters, lst1 can become all even iff lst2 contains at least as many
    even numbers as lst1 has odd numbers.
    """
    odd_count_in_lst1 = _count_odds(lst1)
    even_count_in_lst2 = len(lst2) - _count_odds(lst2)

    return "YES" if even_count_in_lst2 >= odd_count_in_lst1 else "NO"
candidate = exchange


def check(candidate):

    # Check some simple cases
    assert candidate([1, 2, 3, 4], [1, 2, 3, 4]) == "YES"
    assert candidate([1, 2, 3, 4], [1, 5, 3, 4]) == "NO"
    assert candidate([1, 2, 3, 4], [2, 1, 4, 3]) == "YES" 
    assert candidate([5, 7, 3], [2, 6, 4]) == "YES"
    assert candidate([5, 7, 3], [2, 6, 3]) == "NO" 
    assert candidate([3, 2, 6, 1, 8, 9], [3, 5, 5, 1, 1, 1]) == "NO"

    # Check some edge cases that are easy to work out by hand.
    assert candidate([100, 200], [200, 200]) == "YES"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
