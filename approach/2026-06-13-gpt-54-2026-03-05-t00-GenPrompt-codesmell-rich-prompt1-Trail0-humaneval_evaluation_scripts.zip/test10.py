
import unittest
import re
import sys
import math
import copy



def is_palindrome(string: str) -> bool:
    """ Test if given string is a palindrome """
    return string == string[::-1]


def is_palindrome(string: str) -> bool:
    """Test if given string is a palindrome."""
    return string == string[::-1]


def _longest_palindromic_suffix_start(string: str) -> int:
    """Return the start index of the longest palindromic suffix."""
    for start in range(len(string)):
        if is_palindrome(string[start:]):
            return start
    return len(string)


def _suffix_to_append(string: str, palindrome_start: int) -> str:
    """Return the reversed non-palindromic prefix to append."""
    return string[:palindrome_start][::-1]


def make_palindrome(string: str) -> str:
    """Find the shortest palindrome that begins with a supplied string.

    Algorithm:
    - Find the longest postfix of supplied string that is a palindrome.
    - Append to the end of the string the reverse of the prefix that
      comes before the palindromic suffix.

    >>> make_palindrome('')
    ''
    >>> make_palindrome('cat')
    'catac'
    >>> make_palindrome('cata')
    'catac'
    """
    palindrome_start = _longest_palindromic_suffix_start(string)
    return string + _suffix_to_append(string, palindrome_start)
candidate = make_palindrome




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == ''
    assert candidate('x') == 'x'
    assert candidate('xyz') == 'xyzyx'
    assert candidate('xyx') == 'xyx'
    assert candidate('jerry') == 'jerryrrej'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
