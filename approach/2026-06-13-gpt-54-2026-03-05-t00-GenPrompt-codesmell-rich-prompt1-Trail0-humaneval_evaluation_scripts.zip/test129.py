
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Given a grid with N rows and N columns (N >= 2) and a positive integer k,
    each cell of the grid contains a value. Every integer in the range [1, N * N]
    inclusive appears exactly once on the cells of the grid.

    Return the lexicographically minimum path of length k, represented by the
    ordered list of visited cell values.
    """
    size = len(grid)
    positions = _build_value_positions(grid)
    adjacency = _build_adjacency(grid, positions, size)

    start_value = 1
    path = [start_value]

    if k == 1:
        return path

    current_value = start_value
    for _ in range(k - 1):
        current_value = _smallest_neighbor_value(current_value, adjacency)
        path.append(current_value)

    return path


def _build_value_positions(grid):
    """Map each cell value to its (row, col) position."""
    positions = {}
    for row_index, row in enumerate(grid):
        for col_index, value in enumerate(row):
            positions[value] = (row_index, col_index)
    return positions


def _build_adjacency(grid, positions, size):
    """Build a mapping from each value to the sorted values of its neighbors."""
    adjacency = {}
    for value, (row, col) in positions.items():
        neighbors = []
        for next_row, next_col in _neighbor_coordinates(row, col, size):
            neighbors.append(grid[next_row][next_col])
        adjacency[value] = sorted(neighbors)
    return adjacency


def _neighbor_coordinates(row, col, size):
    """Yield valid orthogonal neighbor coordinates."""
    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]

    for row_delta, col_delta in directions:
        next_row = row + row_delta
        next_col = col + col_delta
        if 0 <= next_row < size and 0 <= next_col < size:
            yield next_row, next_col


def _smallest_neighbor_value(value, adjacency):
    """Return the smallest neighbor value for the given cell value."""
    return adjacency[value][0]
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
