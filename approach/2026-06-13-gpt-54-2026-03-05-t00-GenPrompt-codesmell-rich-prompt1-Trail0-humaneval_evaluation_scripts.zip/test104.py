
import unittest
import re
import sys
import math
import copy


def _has_only_odd_digits(number):
    """Return True if all digits in number are odd."""
    return all((int(digit) % 2) == 1 for digit in str(number))


def _filter_numbers_with_only_odd_digits(numbers):
    """Return numbers that contain no even digits."""
    return [number for number in numbers if _has_only_odd_digits(number)]


def unique_digits(x):
    """Given a list of positive integers x, return a sorted list of all
    elements that haven't any even digit.

    Note: Returned list should be sorted in increasing order.

    For example:
    >>> unique_digits([15, 33, 1422, 1])
    [1, 15, 33]
    >>> unique_digits([152, 323, 1422, 10])
    []
    """
    return sorted(_filter_numbers_with_only_odd_digits(x))
candidate = unique_digits


def check(candidate):

    # Check some simple cases
    assert candidate([15, 33, 1422, 1]) == [1, 15, 33]
    assert candidate([152, 323, 1422, 10]) == []
    assert candidate([12345, 2033, 111, 151]) == [111, 151]
    assert candidate([135, 103, 31]) == [31, 135]

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
