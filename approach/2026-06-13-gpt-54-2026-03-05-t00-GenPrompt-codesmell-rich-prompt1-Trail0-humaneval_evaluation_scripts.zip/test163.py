
import unittest
import re
import sys
import math
import copy


def _sorted_bounds(a, b):
    """Return the bounds in ascending order."""
    return (a, b) if a <= b else (b, a)


def _is_even_digit(value):
    """Return True if value is an even digit."""
    return 0 <= value <= 9 and value % 2 == 0


def generate_integers(a, b):
    """
    Given two positive integers a and b, return the even digits between a
    and b, in ascending order.

    For example:
    generate_integers(2, 8) => [2, 4, 6, 8]
    generate_integers(8, 2) => [2, 4, 6, 8]
    generate_integers(10, 14) => []
    """
    start, end = _sorted_bounds(a, b)
    return [number for number in range(start, end + 1) if _is_even_digit(number)]
candidate = generate_integers


def check(candidate):

    # Check some simple cases
    assert candidate(2, 10) == [2, 4, 6, 8], "Test 1"
    assert candidate(10, 2) == [2, 4, 6, 8], "Test 2"
    assert candidate(132, 2) == [2, 4, 6, 8], "Test 3"
    assert candidate(17,89) == [], "Test 4"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
