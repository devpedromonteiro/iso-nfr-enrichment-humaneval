
import unittest



def common(l1: list, l2: list):
    """Return sorted unique common elements for two lists.
    >>> common([1, 4, 3, 34, 653, 2, 5], [5, 7, 1, 5, 9, 653, 121])
    [1, 5, 653]
    >>> common([5, 3, 2, 8], [3, 2])
    [2, 3]

    """
    if not l1 or not l2:
        return []

    # Build a set from the smaller list to reduce memory usage.
    if len(l1) <= len(l2):
        small, large = l1, l2
    else:
        small, large = l2, l1

    small_set = set(small)
    result = set()

    for item in large:
        if item in small_set:
            result.add(item)

    return sorted(result)
candidate = common


class Test(unittest.TestCase):
    def test(self):
        assert candidate([6, 5, 7, 10], [8, 4]) == []
        assert candidate([6, 3, 2, 37, 657, 2, 6], [5, 9, 1, 6, 4, 654, 125]) == [6]
        assert candidate([1, 6, 5, 9], [1, 6, 1]) == [1, 6]
        assert candidate([8, 7, 6, 13], [7, 2]) == [7]
        assert candidate([1, 1, 3, 11], [5, 3, 2]) == [3]
        assert candidate([7, 8, 6, 11], [4, 5, 9]) == []
        assert candidate([1, 6, 5, 34, 651, 3, 3], [7, 8, 1, 7, 9, 653, 121]) == [1]
        assert candidate([6, 6, 4, 12], [3, 1]) == []
        assert candidate([6, 1, 5, 36, 648, 1, 6], [3, 4, 2, 1, 12, 654, 123]) == [1]
        assert candidate([6, 3, 7, 6], [3, 5, 7]) == [3, 7]
        assert candidate([4, 8, 2, 9], [3, 1]) == []
        assert candidate([3, 5, 5, 8], [7, 6]) == []
        assert candidate([1, 8, 3, 4], [8, 7, 6]) == [8]
        assert candidate([5, 2, 6, 30, 650, 7, 3], [7, 10, 2, 4, 4, 651, 126]) == [2, 7]
        assert candidate([4, 6, 6, 7], [8, 6, 9]) == [6]
        assert candidate([3, 7, 6, 3], [2, 4, 5]) == []
        assert candidate([7, 4, 3, 10], [3, 1]) == [3]
        assert candidate([3, 3, 1, 4], [4, 6, 4]) == [4]
        assert candidate([4, 5, 2, 5], [1, 7, 5]) == [5]
        assert candidate([5, 3, 4, 35, 652, 1, 1], [9, 6, 2, 8, 6, 653, 122]) == []
        assert candidate([3, 1, 6, 11], [6, 6]) == [6]
        assert candidate([7, 4, 7, 13], [8, 4]) == [4]
        assert candidate([4, 4, 4, 34, 652, 5, 10], [8, 2, 1, 4, 5, 652, 117]) == [4, 5, 652]
        assert candidate([2, 8, 3, 29, 650, 1, 7], [3, 6, 2, 3, 7, 652, 116]) == [2, 3, 7]
        assert candidate([5, 8, 7, 3], [6, 4]) == []
        assert candidate([2, 2, 1, 29, 650, 4, 2], [3, 10, 6, 2, 11, 651, 119]) == [2]
        assert candidate([3, 3, 2, 30, 656, 3, 4], [6, 11, 2, 4, 4, 652, 123]) == [2, 4]
        assert candidate([6, 1, 4, 33, 651, 4, 3], [4, 10, 1, 10, 12, 657, 126]) == [1, 4]
        assert candidate([6, 6, 4, 5], [3, 3, 8]) == []
        assert candidate([5, 5, 4, 34, 648, 5, 5], [3, 7, 6, 2, 10, 648, 116]) == [648]
        assert candidate([2, 1, 7, 9], [6, 3]) == []
        assert candidate([4, 1, 4, 12], [5, 1, 7]) == [1]
        assert candidate([7, 6, 3, 9], [6, 5]) == [6]
        assert candidate([2, 3, 3, 9], [5, 2]) == [2]
        assert candidate([1, 4, 1, 32, 657, 7, 6], [4, 10, 2, 2, 4, 650, 124]) == [4]
        assert candidate([8, 3, 4, 10], [8, 7]) == [8]
        assert candidate([4, 3, 2, 8], [3, 2, 4]) == [2, 3, 4]
        assert candidate([5, 2, 2, 30, 654, 5, 1], [3, 3, 2, 10, 6, 657, 126]) == [2]
        assert candidate([2, 7, 4, 3], [8, 7, 5]) == [7]
        assert candidate([4, 5, 7, 12], [7, 1]) == [7]
        assert candidate([9, 3, 7, 4], [4, 2, 4]) == [4]
        assert candidate([3, 1, 3, 10], [3, 3, 9]) == [3]
        assert candidate([4, 4, 1, 37, 654, 7, 5], [3, 11, 2, 6, 9, 656, 120]) == []
        assert candidate([2, 6, 2, 8], [5, 2]) == [2]
        assert candidate([2, 4, 3, 12], [4, 5, 6]) == [4]
        assert candidate([4, 4, 7, 8], [4, 4, 9]) == [4]
        assert candidate([1, 6, 6, 12], [6, 2, 9]) == [6]
        assert candidate([2, 7, 1, 4], [1, 2, 1]) == [1, 2]
        assert candidate([2, 5, 6, 32, 649, 3, 9], [8, 6, 1, 4, 4, 658, 117]) == [6]
        assert candidate([2, 1, 5, 37, 657, 7, 1], [4, 9, 3, 1, 12, 649, 122]) == [1]
        assert candidate([5, 5, 7, 7], [5, 2]) == [5]
        assert candidate([5, 3, 2, 8], [3, 2]) == [2, 3]
        assert candidate([5, 4, 5, 32, 655, 6, 2], [2, 10, 4, 2, 14, 656, 117]) == [2, 4]
        assert candidate([3, 4, 4, 8], [3, 3, 9]) == [3]
        assert candidate([5, 2, 1, 3], [8, 3]) == [3]
        assert candidate([3, 8, 3, 35, 651, 4, 2], [1, 12, 6, 10, 4, 654, 119]) == [4]
        assert candidate([5, 6, 4, 8], [3, 7, 2]) == []
        assert candidate([7, 7, 5, 11], [3, 4]) == []
        assert candidate([4, 3, 2, 8], []) == []
        assert candidate([7, 7, 7, 3], [2, 4]) == []
        assert candidate([2, 9, 3, 36, 649, 6, 7], [10, 12, 4, 4, 14, 656, 116]) == []
        assert candidate([3, 8, 6, 6], [4, 3, 3]) == [3]
        assert candidate([1, 8, 7, 3], [2, 6]) == []
        assert candidate([1, 4, 5, 11], [1, 6, 1]) == [1]
        assert candidate([6, 2, 3, 8], [7, 6, 8]) == [6, 8]
        assert candidate([1, 7, 4, 30, 653, 1, 1], [6, 9, 2, 2, 13, 650, 120]) == []
        assert candidate([6, 8, 4, 32, 657, 7, 6], [4, 10, 1, 5, 14, 652, 120]) == [4]
        assert candidate([2, 7, 7, 32, 650, 5, 6], [7, 2, 4, 3, 13, 654, 117]) == [2, 7]
        assert candidate([1, 4, 7, 30, 658, 3, 10], [6, 7, 3, 10, 10, 658, 117]) == [3, 7, 10, 658]
        assert candidate([8, 4, 1, 9], [6, 3]) == []
        assert candidate([2, 1, 4, 37, 657, 3, 7], [8, 5, 5, 10, 7, 654, 121]) == [7]
        assert candidate([9, 7, 7, 7], [5, 2]) == []
        assert candidate([4, 6, 3, 31, 648, 7, 10], [1, 10, 4, 7, 7, 653, 117]) == [4, 7, 10]
        assert candidate([6, 5, 2, 3], [3, 3, 3]) == [3]
        assert candidate([4, 4, 1, 8], [1, 5, 7]) == [1]
        assert candidate([8, 4, 6, 5], [1, 1]) == []
        assert candidate([4, 5, 3, 10], [7, 5]) == [5]
        assert candidate([7, 1, 7, 13], [3, 1]) == [1]
        assert candidate([1, 5, 5, 29, 655, 4, 1], [5, 3, 2, 1, 5, 648, 118]) == [1, 5]
        assert candidate([1, 4, 3, 34, 653, 2, 5], [5, 7, 1, 5, 9, 653, 121]) == [1, 5, 653]
        assert candidate([7, 7, 1, 4], [5, 6]) == []
        assert candidate([5, 4, 2, 36, 648, 7, 10], [6, 8, 1, 5, 11, 649, 126]) == [5]
        assert candidate([8, 1, 1, 3], [5, 6]) == []
        assert candidate([6, 3, 6, 3], [8, 5, 8]) == []
        assert candidate([6, 8, 7, 32, 654, 7, 3], [7, 7, 2, 5, 10, 654, 123]) == [7, 654]
        assert candidate([2, 2, 6, 11], [5, 6, 1]) == [6]
        assert candidate([1, 4, 6, 39, 653, 4, 3], [6, 12, 2, 3, 14, 654, 116]) == [3, 6]
        assert candidate([1, 3, 4, 9], [7, 3]) == [3]
        assert candidate([9, 6, 6, 7], [7, 7, 1]) == [7]
        assert candidate([5, 6, 2, 34, 654, 3, 7], [7, 9, 1, 7, 8, 650, 122]) == [7]
        assert candidate([8, 2, 7, 4], [7, 7, 1]) == [7]
        assert candidate([3, 2, 1, 37, 654, 7, 6], [2, 3, 2, 6, 4, 649, 123]) == [2, 3, 6]
        assert candidate([9, 2, 7, 4], [5, 4, 1]) == [4]
        assert candidate([8, 1, 4, 10], [4, 2]) == [4]
        assert candidate([2, 8, 5, 10], [8, 4]) == [8]
        assert candidate([8, 4, 4, 6], [3, 6]) == [6]
        assert candidate([3, 6, 6, 7], [7, 4, 2]) == [7]
        assert candidate([3, 4, 3, 11], [4, 1, 7]) == [4]
        assert candidate([3, 1, 4, 5], [1, 1]) == [1]
        assert candidate([3, 2, 5, 37, 652, 2, 3], [5, 4, 6, 7, 9, 651, 120]) == [5]

if __name__ == '__main__':
    unittest.main()
