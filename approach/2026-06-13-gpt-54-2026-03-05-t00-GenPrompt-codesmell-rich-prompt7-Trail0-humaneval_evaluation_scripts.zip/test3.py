
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def update_balance(balance: int, operation: int) -> int:
    """Return the new balance after applying a single operation."""
    return balance + operation


def is_below_zero(balance: int) -> bool:
    """Check whether the balance is below zero."""
    return balance < 0


def below_zero(operations: List[int]) -> bool:
    """Detect whether the account balance ever drops below zero.

    The account starts with a zero balance. Each value in `operations`
    represents a deposit (positive) or withdrawal (negative).

    >>> below_zero([1, 2, 3])
    False
    >>> below_zero([1, 2, -4, 5])
    True
    """
    balance = 0

    for operation in operations:
        balance = update_balance(balance, operation)
        if is_below_zero(balance):
            return True

    return False
candidate = below_zero




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == False
    assert candidate([1, 2, -3, 1, 2, -3]) == False
    assert candidate([1, 2, -4, 5, 6]) == True
    assert candidate([1, -1, 2, -2, 5, -5, 4, -4]) == False
    assert candidate([1, -1, 2, -2, 5, -5, 4, -5]) == True
    assert candidate([1, -2, 2, -2, 5, -5, 4, -4]) == True


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
