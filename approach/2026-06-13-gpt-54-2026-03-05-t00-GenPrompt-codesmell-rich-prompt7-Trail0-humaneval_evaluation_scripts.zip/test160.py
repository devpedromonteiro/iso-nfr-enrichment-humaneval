
import unittest
import re
import sys
import math
import copy


def _validate_inputs(operators, operands):
    if not isinstance(operators, list) or not isinstance(operands, list):
        raise TypeError("operators and operands must be lists")

    if len(operators) < 1:
        raise ValueError("operators must contain at least one operator")

    if len(operands) < 2:
        raise ValueError("operands must contain at least two values")

    if len(operators) != len(operands) - 1:
        raise ValueError("operators length must be equal to operands length minus one")

    supported = {"+", "-", "*", "//", "**"}
    for op in operators:
        if op not in supported:
            raise ValueError(f"unsupported operator: {op}")

    for value in operands:
        if not isinstance(value, int) or value < 0:
            raise ValueError("operands must be non-negative integers")


def _build_expression(operators, operands):
    expression_parts = [str(operands[0])]
    for op, value in zip(operators, operands[1:]):
        expression_parts.append(op)
        expression_parts.append(str(value))
    return " ".join(expression_parts)


def _evaluate_expression(expression):
    return eval(expression)


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and
    the second list is a list of integers. Use the two given lists to build the algebric
    expression and return the evaluation of this expression.

    The basic algebra operations:
    Addition ( + )
    Subtraction ( - )
    Multiplication ( * )
    Floor division ( // )
    Exponentiation ( ** )

    Example:
    operator['+', '*', '-']
    array = [2, 3, 4, 5]
    result = 2 + 3 * 4 - 5
    => result = 9

    Note:
        The length of operator list is equal to the length of operand list minus one.
        Operand is a list of of non-negative integers.
        Operator list has at least one operator, and operand list has at least two operands.

    """
    _validate_inputs(operator, operand)
    expression = _build_expression(operator, operand)
    return _evaluate_expression(expression)
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
