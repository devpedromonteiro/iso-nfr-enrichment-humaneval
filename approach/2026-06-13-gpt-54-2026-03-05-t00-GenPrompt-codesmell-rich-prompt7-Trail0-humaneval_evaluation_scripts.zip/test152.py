
import unittest
import re
import sys
import math
import copy


def _absolute_difference(actual, predicted):
    """Return the absolute difference between a score and a guess."""
    return abs(actual - predicted)


def compare(game, guess):
    """Return per-match differences between actual scores and guessed scores.

    Each result is 0 when the guess is correct, otherwise the absolute
    difference between the actual score and the guessed score.
    """
    return [_absolute_difference(actual, predicted) for actual, predicted in zip(game, guess)]
candidate = compare


def check(candidate):

    # Check some simple cases
    assert candidate([1,2,3,4,5,1],[1,2,3,4,2,-2])==[0,0,0,0,3,3], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([0,0,0,0,0,0],[0,0,0,0,0,0])==[0,0,0,0,0,0], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,2,3],[-1,-2,-3])==[2,4,6], "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([1,2,3,5],[-1,2,3,4])==[2,0,0,1], "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
