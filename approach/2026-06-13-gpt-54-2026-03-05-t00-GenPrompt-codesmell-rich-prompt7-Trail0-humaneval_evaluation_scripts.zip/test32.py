
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math
from typing import List


def poly(coefficients: List[float], x: float) -> float:
    """
    Evaluate a polynomial with coefficients at point x.

    coefficients[i] is the coefficient for x**i.
    """
    return sum(coeff * math.pow(x, power) for power, coeff in enumerate(coefficients))


def _validate_coefficients(coefficients: List[float]) -> None:
    """Validate input constraints for root finding."""
    if not coefficients:
        raise ValueError("coefficients must not be empty")

    if len(coefficients) % 2 != 0:
        raise ValueError("find_zero requires an even number of coefficients")

    if coefficients[-1] == 0:
        raise ValueError("largest coefficient must be non-zero")


def _derivative_coefficients(coefficients: List[float]) -> List[float]:
    """Return coefficients of the derivative polynomial."""
    return [power * coeff for power, coeff in enumerate(coefficients)][1:]


def _bisect_root(coefficients: List[float], left: float, right: float, tolerance: float = 1e-7) -> float:
    """Find a root in [left, right] assuming a sign change exists."""
    left_value = poly(coefficients, left)
    right_value = poly(coefficients, right)

    if left_value == 0:
        return left
    if right_value == 0:
        return right

    while abs(right - left) > tolerance:
        midpoint = (left + right) / 2
        midpoint_value = poly(coefficients, midpoint)

        if midpoint_value == 0:
            return midpoint

        if left_value * midpoint_value < 0:
            right = midpoint
            right_value = midpoint_value
        else:
            left = midpoint
            left_value = midpoint_value

    return (left + right) / 2


def _find_bracketing_interval(coefficients: List[float], start: float = 1.0) -> tuple[float, float]:
    """
    Find an interval [left, right] where the polynomial changes sign.
    For odd-degree polynomials, such an interval is guaranteed to exist.
    """
    left = -start
    right = start
    left_value = poly(coefficients, left)
    right_value = poly(coefficients, right)

    while left_value * right_value > 0:
        left *= 2
        right *= 2
        left_value = poly(coefficients, left)
        right_value = poly(coefficients, right)

    return left, right


def find_zero(coefficients: List[float]) -> float:
    """
    Find one zero of a polynomial defined by coefficients.

    coefficients[i] is the coefficient for x**i.

    The function assumes:
    - the number of coefficients is even
    - the highest-degree coefficient is non-zero

    >>> round(find_zero([1, 2]), 2)
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2)
    1.0
    """
    _validate_coefficients(coefficients)

    if len(coefficients) == 2:
        constant_term, linear_term = coefficients
        return -constant_term / linear_term

    derivative = _derivative_coefficients(coefficients)
    critical_point = find_zero(derivative)

    if poly(coefficients, critical_point) == 0:
        return critical_point

    left, right = _find_bracketing_interval(coefficients)
    return _bisect_root(coefficients, left, right)
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
