
import unittest
import re
import sys
import math
import copy



def _validate_non_negative_integer(value: int) -> None:
    """Validate that the input is a non-negative integer."""
    if not isinstance(value, int):
        raise TypeError("n must be an integer")
    if value < 0:
        raise ValueError("n must be non-negative")


def _build_sequence_parts(n: int) -> list[str]:
    """Build the sequence elements from 0 to n as strings."""
    return [str(number) for number in range(n + 1)]


def string_sequence(n: int) -> str:
    """Return a space-delimited string of numbers from 0 to n inclusive.

    >>> string_sequence(0)
    '0'
    >>> string_sequence(5)
    '0 1 2 3 4 5'
    """
    _validate_non_negative_integer(n)
    return " ".join(_build_sequence_parts(n))
candidate = string_sequence




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(0) == '0'
    assert candidate(3) == '0 1 2 3'
    assert candidate(10) == '0 1 2 3 4 5 6 7 8 9 10'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
