
import unittest
import re
import sys
import math
import copy


def _get_last_token(txt):
    """Return the last space-separated token, or an empty string."""
    if not txt or txt.endswith(" "):
        return ""
    return txt.split(" ")[-1]


def _is_single_letter(token):
    """Return True when the token is exactly one alphabetical character."""
    return len(token) == 1 and token.isalpha()


def check_if_last_char_is_a_letter(txt):
    '''
    Create a function that returns True if the last character
    of a given string is an alphabetical character and is not
    a part of a word, and False otherwise.
    Note: "word" is a group of characters separated by space.

    Examples:
    check_if_last_char_is_a_letter("apple pie") â False
    check_if_last_char_is_a_letter("apple pi e") â True
    check_if_last_char_is_a_letter("apple pi e ") â False
    check_if_last_char_is_a_letter("") â False 
    '''
    last_token = _get_last_token(txt)
    return _is_single_letter(last_token)
candidate = check_if_last_char_is_a_letter


def check(candidate):

    # Check some simple cases
    assert candidate("apple") == False
    assert candidate("apple pi e") == True
    assert candidate("eeeee") == False
    assert candidate("A") == True
    assert candidate("Pumpkin pie ") == False
    assert candidate("Pumpkin pie 1") == False
    assert candidate("") == False
    assert candidate("eeeee e ") == False
    assert candidate("apple pie") == False
    assert candidate("apple pi e ") == False

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
