
import unittest
import re
import sys
import math
import copy


def _odd_digits(number_str):
    """Yield odd digits from a numeric string."""
    for ch in number_str:
        digit = int(ch)
        if digit % 2 == 1:
            yield digit


def _product(values):
    """Return the product of an iterable of integers."""
    result = 1
    for value in values:
        result *= value
    return result


def digits(n):
    """Given a positive integer n, return the product of the odd digits.
    Return 0 if all digits are even.

    Examples:
        digits(1) == 1
        digits(4) == 0
        digits(235) == 15
    """
    odd_values = list(_odd_digits(str(n)))
    if not odd_values:
        return 0
    return _product(odd_values)
candidate = digits


def check(candidate):

    # Check some simple cases
    assert candidate(5) == 5
    assert candidate(54) == 5
    assert candidate(120) ==1
    assert candidate(5014) == 5
    assert candidate(98765) == 315
    assert candidate(5576543) == 2625

    # Check some edge cases that are easy to work out by hand.
    assert candidate(2468) == 0



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
