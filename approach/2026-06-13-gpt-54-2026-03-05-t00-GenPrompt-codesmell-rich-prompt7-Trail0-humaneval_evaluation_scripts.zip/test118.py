
import unittest
import re
import sys
import math
import copy


def is_vowel(char):
    """Return True if the character is a vowel."""
    return char in "aeiouAEIOU"


def is_surrounded_by_consonants(word, index):
    """Return True if word[index] is between two consonants."""
    return (
        not is_vowel(word[index - 1])
        and not is_vowel(word[index + 1])
    )


def get_closest_vowel(word):
    """Find the rightmost vowel that is between two consonants.

    Vowels at the beginning or end of the word do not count.
    Return an empty string if no such vowel exists.
    """
    for index in range(len(word) - 2, 0, -1):
        if is_vowel(word[index]) and is_surrounded_by_consonants(word, index):
            return word[index]
    return ""
candidate = get_closest_vowel


def check(candidate):

    # Check some simple cases
    assert candidate("yogurt") == "u"
    assert candidate("full") == "u"
    assert candidate("easy") == ""
    assert candidate("eAsy") == ""
    assert candidate("ali") == ""
    assert candidate("bad") == "a"
    assert candidate("most") == "o"
    assert candidate("ab") == ""
    assert candidate("ba") == ""
    assert candidate("quick") == ""
    assert candidate("anime") == "i"
    assert candidate("Asia") == ""
    assert candidate("Above") == "o"

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
