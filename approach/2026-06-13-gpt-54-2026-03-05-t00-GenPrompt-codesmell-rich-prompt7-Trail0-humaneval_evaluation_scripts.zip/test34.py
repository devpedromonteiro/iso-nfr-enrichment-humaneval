
import unittest
import re
import sys
import math
import copy



def _validate_list(values: list) -> None:
    """Validate the input type for unique()."""
    if not isinstance(values, list):
        raise TypeError("unique() expects a list")


def _sorted_unique_values(values: list) -> list:
    """Build a sorted list of unique values."""
    return sorted(set(values))


def unique(l: list):
    """Return sorted unique elements in a list.

    >>> unique([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [0, 2, 3, 5, 9, 123]
    """
    _validate_list(l)
    return _sorted_unique_values(l)
candidate = unique




METADATA = {}


def check(candidate):
    assert candidate([5, 3, 5, 2, 3, 3, 9, 0, 123]) == [0, 2, 3, 5, 9, 123]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
