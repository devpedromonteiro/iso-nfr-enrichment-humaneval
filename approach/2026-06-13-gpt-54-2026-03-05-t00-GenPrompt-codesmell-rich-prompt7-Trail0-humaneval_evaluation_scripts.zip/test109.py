
import unittest
import re
import sys
import math
import copy


def _count_descending_transitions(arr):
    """Count positions where the order decreases from one element to the next,
    treating the array as circular.
    """
    size = len(arr)
    transitions = 0

    for index in range(size):
        current = arr[index]
        next_value = arr[(index + 1) % size]
        if current > next_value:
            transitions += 1

    return transitions


def move_one_ball(arr):
    """Return True if some number of right shifts can sort the array.

    A right-shifted sortable array must be a rotation of a non-decreasing array.
    For arrays with unique elements, this is true iff there is at most one
    descending transition in the circular sequence.
    """
    if len(arr) <= 1:
        return True

    return _count_descending_transitions(arr) <= 1
candidate = move_one_ball


def check(candidate):

    # Check some simple cases
    assert candidate([3, 4, 5, 1, 2])==True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([3, 5, 10, 1, 2])==True
    assert candidate([4, 3, 1, 2])==False
    # Check some edge cases that are easy to work out by hand.
    assert candidate([3, 5, 4, 1, 2])==False, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([])==True


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
