
import unittest
import re
import sys
import math
import copy



def _validate_positive_integer(n: int) -> None:
    """Validate that n is a positive integer greater than 1."""
    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if n <= 1:
        raise ValueError("n must be greater than 1")


def _find_smallest_divisor(n: int) -> int:
    """Return the smallest divisor of n greater than 1."""
    for candidate in range(2, int(n**0.5) + 1):
        if n % candidate == 0:
            return candidate
    return n


def largest_divisor(n: int) -> int:
    """For a given number n, find the largest number that divides n evenly, smaller than n.

    >>> largest_divisor(15)
    5
    """
    _validate_positive_integer(n)
    smallest_divisor = _find_smallest_divisor(n)
    return n // smallest_divisor
candidate = largest_divisor




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(3) == 1
    assert candidate(7) == 1
    assert candidate(10) == 5
    assert candidate(100) == 50
    assert candidate(49) == 7


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
