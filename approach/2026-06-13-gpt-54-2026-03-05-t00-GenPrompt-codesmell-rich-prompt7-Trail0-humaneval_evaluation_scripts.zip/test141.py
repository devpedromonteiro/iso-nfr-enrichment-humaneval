
import unittest
import re
import sys
import math
import copy


def file_name_check(file_name):
    """Return 'Yes' if the file name is valid, otherwise 'No'."""

    allowed_extensions = {"txt", "exe", "dll"}

    def has_valid_dot_structure(name):
        return name.count(".") == 1

    def split_name(name):
        return name.split(".", 1)

    def starts_with_latin_letter(name_part):
        return bool(name_part) and name_part[0].isalpha() and name_part[0].isascii()

    def has_valid_extension(extension):
        return extension in allowed_extensions

    def has_at_most_three_digits(name):
        digit_count = sum(char.isdigit() for char in name)
        return digit_count <= 3

    if not has_valid_dot_structure(file_name):
        return "No"

    name_part, extension = split_name(file_name)

    checks = (
        starts_with_latin_letter(name_part),
        has_valid_extension(extension),
        has_at_most_three_digits(file_name),
    )

    return "Yes" if all(checks) else "No"
candidate = file_name_check


def check(candidate):

    # Check some simple cases
    assert candidate("example.txt") == 'Yes'
    assert candidate("1example.dll") == 'No'
    assert candidate('s1sdf3.asd') == 'No'
    assert candidate('K.dll') == 'Yes'
    assert candidate('MY16FILE3.exe') == 'Yes'
    assert candidate('His12FILE94.exe') == 'No'
    assert candidate('_Y.txt') == 'No'
    assert candidate('?aREYA.exe') == 'No'
    assert candidate('/this_is_valid.dll') == 'No'
    assert candidate('this_is_valid.wow') == 'No'
    assert candidate('this_is_valid.txt') == 'Yes'
    assert candidate('this_is_valid.txtexe') == 'No'
    assert candidate('#this2_i4s_5valid.ten') == 'No'
    assert candidate('@this1_is6_valid.exe') == 'No'
    assert candidate('this_is_12valid.6exe4.txt') == 'No'
    assert candidate('all.exe.txt') == 'No'
    assert candidate('I563_No.exe') == 'Yes'
    assert candidate('Is3youfault.txt') == 'Yes'
    assert candidate('no_one#knows.dll') == 'Yes'
    assert candidate('1I563_Yes3.exe') == 'No'
    assert candidate('I563_Yes3.txtt') == 'No'
    assert candidate('final..txt') == 'No'
    assert candidate('final132') == 'No'
    assert candidate('_f4indsartal132.') == 'No'
    
        

    # Check some edge cases that are easy to work out by hand.
    assert candidate('.txt') == 'No'
    assert candidate('s.') == 'No'



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
