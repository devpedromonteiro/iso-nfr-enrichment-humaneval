
import unittest
import re
import sys
import math
import copy


def _sum_decimal_digits(number):
    """Return the sum of decimal digits of a non-negative integer."""
    return sum(int(digit) for digit in str(number))


def _to_binary_string(number):
    """Convert a non-negative integer to its binary representation as a string."""
    return bin(number)[2:]


def solve(N):
    """Given a positive integer N, return the binary representation of the sum of its digits.
    
    Example
        For N = 1000, the sum of digits is 1, so the output should be "1".
        For N = 150, the sum of digits is 6, so the output should be "110".
        For N = 147, the sum of digits is 12, so the output should be "1100".
    
    Variables:
        @N integer
             Constraints: 0 â¤ N â¤ 10000.
    Output:
         a string of binary number
    """
    digit_sum = _sum_decimal_digits(N)
    return _to_binary_string(digit_sum)
candidate = solve


def check(candidate):

    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate(1000) == "1", "Error"
    assert candidate(150) == "110", "Error"
    assert candidate(147) == "1100", "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate(333) == "1001", "Error"
    assert candidate(963) == "10010", "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
