
import unittest
import re
import sys
import math
import copy


def _rotations(word):
    """Generate all cyclic rotations of a word."""
    for index in range(len(word)):
        yield word[index:] + word[:index]


def _is_substring(text, pattern):
    """Return True if pattern is a substring of text."""
    return pattern in text


def cycpattern_check(a, b):
    """Return True if b or any of its rotations is a substring of a.

    Examples:
        cycpattern_check("abcd", "abd") -> False
        cycpattern_check("hello", "ell") -> True
        cycpattern_check("whassup", "psus") -> False
        cycpattern_check("abab", "baa") -> True
        cycpattern_check("efef", "eeff") -> False
        cycpattern_check("himenss", "simen") -> True
    """
    if not b:
        return True

    return any(_is_substring(a, rotation) for rotation in _rotations(b))
candidate = cycpattern_check


def check(candidate):

    # Check some simple cases
    #assert True, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    #assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert  candidate("xyzw","xyw") == False , "test #0"
    assert  candidate("yello","ell") == True , "test #1"
    assert  candidate("whattup","ptut") == False , "test #2"
    assert  candidate("efef","fee") == True , "test #3"
    assert  candidate("abab","aabb") == False , "test #4"
    assert  candidate("winemtt","tinem") == True , "test #5"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
