
import unittest
import re
import sys
import math
import copy


from math import gcd


def simplify(x, n):
    """Return True if the product of two fractions is a whole number."""
    x_num, x_den = _parse_fraction(x)
    n_num, n_den = _parse_fraction(n)

    num, den = _multiply_fractions(x_num, x_den, n_num, n_den)
    return _is_whole_number(num, den)


def _parse_fraction(value):
    """Parse a fraction string into numerator and denominator integers."""
    numerator, denominator = value.split("/")
    return int(numerator), int(denominator)


def _multiply_fractions(a_num, a_den, b_num, b_den):
    """Multiply two fractions and reduce cross-factors early."""
    a_num, b_den = _reduce_pair(a_num, b_den)
    b_num, a_den = _reduce_pair(b_num, a_den)
    return a_num * b_num, a_den * b_den


def _reduce_pair(left, right):
    """Reduce two integers by their greatest common divisor."""
    divisor = gcd(left, right)
    return left // divisor, right // divisor


def _is_whole_number(numerator, denominator):
    """Check whether a fraction represents a whole number."""
    return numerator % denominator == 0
candidate = simplify


def check(candidate):

    # Check some simple cases
    assert candidate("1/5", "5/1") == True, 'test1'
    assert candidate("1/6", "2/1") == False, 'test2'
    assert candidate("5/1", "3/1") == True, 'test3'
    assert candidate("7/10", "10/2") == False, 'test4'
    assert candidate("2/10", "50/10") == True, 'test5'
    assert candidate("7/2", "4/2") == True, 'test6'
    assert candidate("11/6", "6/1") == True, 'test7'
    assert candidate("2/3", "5/2") == False, 'test8'
    assert candidate("5/2", "3/5") == False, 'test9'
    assert candidate("2/4", "8/4") == True, 'test10'


    # Check some edge cases that are easy to work out by hand.
    assert candidate("2/4", "4/2") == True, 'test11'
    assert candidate("1/5", "5/1") == True, 'test12'
    assert candidate("1/5", "1/5") == False, 'test13'



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
