
import unittest
import re
import sys
import math
import copy


def _count_residues_mod_3(n):
    """
    Count how many values of a[i] fall into each residue class modulo 3,
    without explicitly building the array.

    a[i] = i*i - i + 1 = i(i-1) + 1
    Since i(i-1) is always divisible by 2 and modulo 3:
        i = 0 -> a[i] % 3 = 1
        i = 1 -> a[i] % 3 = 1
        i = 2 -> a[i] % 3 = 0

    So over indices 1..n:
        i % 3 in {0, 1} => a[i] % 3 = 1
        i % 3 == 2      => a[i] % 3 = 0
    """
    count_mod_0 = n // 3
    count_mod_1 = n - count_mod_0
    return count_mod_0, count_mod_1


def _combinations_of_three(x):
    """Return C(x, 3)."""
    if x < 3:
        return 0
    return x * (x - 1) * (x - 2) // 6


def get_max_triples(n):
    """
    You are given a positive integer n. You have to create an integer array a of length n.
    For each i (1 â¤ i â¤ n), the value of a[i] = i * i - i + 1.
    Return the number of triples (a[i], a[j], a[k]) of a where i < j < k,
    and a[i] + a[j] + a[k] is a multiple of 3.

    Example:
        Input: n = 5
        Output: 1
    """
    count_mod_0, count_mod_1 = _count_residues_mod_3(n)

    # Valid sums modulo 3:
    # 0 + 0 + 0 = 0
    # 1 + 1 + 1 = 0 (mod 3)
    triples_all_mod_0 = _combinations_of_three(count_mod_0)
    triples_all_mod_1 = _combinations_of_three(count_mod_1)

    return triples_all_mod_0 + triples_all_mod_1
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
