
import unittest
import re
import sys
import math
import copy


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and
    the second list is a list of integers. Use the two given lists to build the algebraic
    expression and return the evaluation of this expression.

    Supported operations:
    +, -, *, //, **

    The expression is evaluated using normal Python operator precedence.
    """
    # Fast path: single operator
    if len(operator) == 1:
        a, b = operand[0], operand[1]
        op = operator[0]
        if op == '+':
            return a + b
        if op == '-':
            return a - b
        if op == '*':
            return a * b
        if op == '//':
            return a // b
        return a ** b

    # Shunting-yard style evaluation with two stacks.
    # O(n) time, bounded auxiliary space, no string building/eval.
    values = [operand[0]]
    ops = []

    precedence = {'+': 1, '-': 1, '*': 2, '//': 2, '**': 3}

    def apply_top():
        op = ops.pop()
        b = values.pop()
        a = values.pop()
        if op == '+':
            values.append(a + b)
        elif op == '-':
            values.append(a - b)
        elif op == '*':
            values.append(a * b)
        elif op == '//':
            values.append(a // b)
        else:  # '**'
            values.append(a ** b)

    for i, op in enumerate(operator):
        curr = operand[i + 1]

        # '**' is right-associative; others are left-associative
        while ops and (
            precedence[ops[-1]] > precedence[op] or
            (precedence[ops[-1]] == precedence[op] and op != '**')
        ):
            apply_top()

        ops.append(op)
        values.append(curr)

    while ops:
        apply_top()

    return values[0]
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
