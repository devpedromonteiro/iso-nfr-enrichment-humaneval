
import unittest
import re
import sys
import math
import copy



def prime_fib(n: int):
    """
    prime_fib returns n-th number that is a Fibonacci number and it's also prime.
    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """
    if n < 1:
        raise ValueError("n must be a positive integer")

    def is_prime(x: int) -> bool:
        if x < 2:
            return False
        if x == 2:
            return True
        if x % 2 == 0:
            return False
        i = 3
        while i * i <= x:
            if x % i == 0:
                return False
            i += 2
        return True

    # Prime Fibonacci numbers occur at Fibonacci indices:
    # 3, 4, 5, 7, 11, 13, ...
    # For prime indices p, F(p) can be prime (except F(4)=3).
    count = 0
    a, b = 0, 1  # Fibonacci pair
    idx = 0

    while True:
        if idx >= 3 and (idx == 4 or is_prime(idx)):
            if is_prime(a):
                count += 1
                if count == n:
                    return a
        a, b = b, a + b
        idx += 1
candidate = prime_fib




METADATA = {}


def check(candidate):
    assert candidate(1) == 2
    assert candidate(2) == 3
    assert candidate(3) == 5
    assert candidate(4) == 13
    assert candidate(5) == 89
    assert candidate(6) == 233
    assert candidate(7) == 1597
    assert candidate(8) == 28657
    assert candidate(9) == 514229
    assert candidate(10) == 433494437



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
