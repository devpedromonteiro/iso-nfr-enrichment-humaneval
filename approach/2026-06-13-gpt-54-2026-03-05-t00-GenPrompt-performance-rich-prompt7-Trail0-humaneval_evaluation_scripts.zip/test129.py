
import unittest
import re
import sys
import math
import copy


def minPath(grid, k):
    """
    Given a grid with N rows and N columns (N >= 2) and a positive integer k,
    each cell of the grid contains a value. Every integer in the range [1, N * N]
    inclusive appears exactly once on the cells of the grid.

    Return the lexicographically minimum path of length k.
    """
    n = len(grid)

    # Map each value to its position for O(1) lookup by value.
    pos = [None] * (n * n + 1)
    for r in range(n):
        row = grid[r]
        for c in range(n):
            pos[row[c]] = (r, c)

    # Best first value must be the globally smallest value.
    start_val = 1
    if k == 1:
        return [start_val]

    r, c = pos[start_val]

    # Precompute neighbor values of the starting cell and take the minimum.
    best_next = None
    if r > 0:
        best_next = grid[r - 1][c]
    if r + 1 < n:
        v = grid[r + 1][c]
        if best_next is None or v < best_next:
            best_next = v
    if c > 0:
        v = grid[r][c - 1]
        if best_next is None or v < best_next:
            best_next = v
    if c + 1 < n:
        v = grid[r][c + 1]
        if best_next is None or v < best_next:
            best_next = v

    # Since revisiting cells is allowed, once we start at the minimum cell,
    # the lexicographically smallest continuation is to alternate between
    # value 1 and the smallest neighbor of cell 1.
    res = [0] * k
    res[0] = start_val
    for i in range(1, k):
        res[i] = best_next if i & 1 else start_val

    return res
candidate = minPath


def check(candidate):

    # Check some simple cases
    print
    assert candidate([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 3) == [1, 2, 1]
    assert candidate([[5, 9, 3], [4, 1, 6], [7, 8, 2]], 1) == [1]
    assert candidate([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], 4) == [1, 2, 1, 2]
    assert candidate([[6, 4, 13, 10], [5, 7, 12, 1], [3, 16, 11, 15], [8, 14, 9, 2]], 7) == [1, 10, 1, 10, 1, 10, 1]
    assert candidate([[8, 14, 9, 2], [6, 4, 13, 15], [5, 7, 1, 12], [3, 10, 11, 16]], 5) == [1, 7, 1, 7, 1]
    assert candidate([[11, 8, 7, 2], [5, 16, 14, 4], [9, 3, 15, 6], [12, 13, 10, 1]], 9) == [1, 6, 1, 6, 1, 6, 1, 6, 1]
    assert candidate([[12, 13, 10, 1], [9, 3, 15, 6], [5, 16, 14, 4], [11, 8, 7, 2]], 12) == [1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6]
    assert candidate([[2, 7, 4], [3, 1, 5], [6, 8, 9]], 8) == [1, 3, 1, 3, 1, 3, 1, 3]
    assert candidate([[6, 1, 5], [3, 8, 9], [2, 7, 4]], 8) == [1, 5, 1, 5, 1, 5, 1, 5]

    # Check some edge cases that are easy to work out by hand.
    assert candidate([[1, 2], [3, 4]], 10) == [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    assert candidate([[1, 3], [3, 2]], 10) == [1, 3, 1, 3, 1, 3, 1, 3, 1, 3]



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
