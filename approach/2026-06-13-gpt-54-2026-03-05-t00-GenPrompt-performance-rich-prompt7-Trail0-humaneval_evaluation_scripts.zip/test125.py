
import unittest
import re
import sys
import math
import copy


def split_words(txt):
    """
    Given a string of words, return a list of words split on whitespace.
    If no whitespace exists in the text, split on commas ','.
    If no commas exist, return the number of lower-case letters with odd
    order in the alphabet: a=0, b=1, ..., z=25.

    Examples:
    split_words("Hello world!") -> ["Hello", "world!"]
    split_words("Hello,world!") -> ["Hello", "world!"]
    split_words("abcdef") -> 3
    """
    # Fast path: whitespace split
    if any(c.isspace() for c in txt):
        return txt.split()

    # Next: comma split
    if ',' in txt:
        return txt.split(',')

    # Final: count lowercase letters with odd alphabet index
    count = 0
    for c in txt:
        if 'a' <= c <= 'z' and ((ord(c) - ord('a')) & 1):
            count += 1
    return count
candidate = split_words


def check(candidate):

    assert candidate("Hello world!") == ["Hello","world!"]
    assert candidate("Hello,world!") == ["Hello","world!"]
    assert candidate("Hello world,!") == ["Hello","world,!"]
    assert candidate("Hello,Hello,world !") == ["Hello,Hello,world","!"]
    assert candidate("abcdef") == 3
    assert candidate("aaabb") == 2
    assert candidate("aaaBb") == 1
    assert candidate("") == 0


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
