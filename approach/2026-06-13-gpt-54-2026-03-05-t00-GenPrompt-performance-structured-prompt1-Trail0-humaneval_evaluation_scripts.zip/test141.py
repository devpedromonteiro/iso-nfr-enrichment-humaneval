
import unittest
import re
import sys
import math
import copy


def file_name_check(file_name):
    digits = 0
    dot_index = -1
    dot_count = 0

    for i, ch in enumerate(file_name):
        if '0' <= ch <= '9':
            digits += 1
            if digits > 3:
                return 'No'
        elif ch == '.':
            dot_count += 1
            if dot_count > 1:
                return 'No'
            dot_index = i

    if dot_count != 1 or dot_index == 0 or dot_index == len(file_name) - 1:
        return 'No'

    first = file_name[0]
    if not (('a' <= first <= 'z') or ('A' <= first <= 'Z')):
        return 'No'

    extension = file_name[dot_index + 1:]
    if extension not in ('txt', 'exe', 'dll'):
        return 'No'

    return 'Yes'
candidate = file_name_check


def check(candidate):

    # Check some simple cases
    assert candidate("example.txt") == 'Yes'
    assert candidate("1example.dll") == 'No'
    assert candidate('s1sdf3.asd') == 'No'
    assert candidate('K.dll') == 'Yes'
    assert candidate('MY16FILE3.exe') == 'Yes'
    assert candidate('His12FILE94.exe') == 'No'
    assert candidate('_Y.txt') == 'No'
    assert candidate('?aREYA.exe') == 'No'
    assert candidate('/this_is_valid.dll') == 'No'
    assert candidate('this_is_valid.wow') == 'No'
    assert candidate('this_is_valid.txt') == 'Yes'
    assert candidate('this_is_valid.txtexe') == 'No'
    assert candidate('#this2_i4s_5valid.ten') == 'No'
    assert candidate('@this1_is6_valid.exe') == 'No'
    assert candidate('this_is_12valid.6exe4.txt') == 'No'
    assert candidate('all.exe.txt') == 'No'
    assert candidate('I563_No.exe') == 'Yes'
    assert candidate('Is3youfault.txt') == 'Yes'
    assert candidate('no_one#knows.dll') == 'Yes'
    assert candidate('1I563_Yes3.exe') == 'No'
    assert candidate('I563_Yes3.txtt') == 'No'
    assert candidate('final..txt') == 'No'
    assert candidate('final132') == 'No'
    assert candidate('_f4indsartal132.') == 'No'
    
        

    # Check some edge cases that are easy to work out by hand.
    assert candidate('.txt') == 'No'
    assert candidate('s.') == 'No'



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
