
import unittest
import re
import sys
import math
import copy


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and
    the second list is a list of integers. Use the two given lists to build the algebraic
    expression and return the evaluation of this expression.

    Supported operations:
    +, -, *, //, **

    The expression follows normal Python operator precedence.
    """
    # Two-pass evaluation to preserve precedence without building strings
    # or using eval(), keeping time O(n) and memory O(n) in the worst case.

    values = [operand[0]]
    ops = []

    for i, op in enumerate(operator):
        right = operand[i + 1]

        if op == '**':
            values[-1] = values[-1] ** right
        elif op == '*':
            values[-1] = values[-1] * right
        elif op == '//':
            values[-1] = values[-1] // right
        else:
            ops.append(op)
            values.append(right)

    result = values[0]
    for i, op in enumerate(ops):
        if op == '+':
            result += values[i + 1]
        else:  # op == '-'
            result -= values[i + 1]

    return result
candidate = do_algebra


def check(candidate):

    # Check some simple cases
    assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
    assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
    assert candidate(['//', '*'], [7, 3, 4]) == 8, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
