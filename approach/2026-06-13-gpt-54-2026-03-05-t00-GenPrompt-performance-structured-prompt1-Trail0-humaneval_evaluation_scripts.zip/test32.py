
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[2] * x^2 + .... xs[n] * x^n
    Uses Horner's method to minimize time complexity and allocations.
    """
    result = 0.0
    for coeff in reversed(xs):
        result = result * x + coeff
    return result


def find_zero(xs: list):
    """ xs are coefficients of a polynomial.
    find_zero find x such that poly(x) = 0.
    find_zero returns only only zero point, even if there are many.
    Moreover, find_zero only takes list xs having even number of coefficients
    and largest non zero coefficient as it guarantees
    a solution.
    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3
    1.0
    """
    if not xs:
        raise ValueError("xs must not be empty")

    degree = len(xs) - 1
    while degree >= 0 and xs[degree] == 0:
        degree -= 1

    if degree < 1:
        raise ValueError("polynomial must have degree at least 1")

    xs = xs[:degree + 1]

    def f(x):
        return poly(xs, x)

    if degree == 1:
        return -xs[0] / xs[1]

    lead = xs[-1]
    bound = 1.0 + max(abs(c) for c in xs[:-1]) / abs(lead)

    left = -bound
    right = bound
    f_left = f(left)
    f_right = f(right)

    if f_left == 0:
        return left
    if f_right == 0:
        return right

    # For odd-degree polynomials, a root is guaranteed in [-bound, bound].
    # Scan for a sign change to avoid assuming endpoints already bracket a root.
    steps = 1024
    step = (right - left) / steps
    prev_x = left
    prev_f = f_left

    for i in range(1, steps + 1):
        curr_x = left + i * step
        curr_f = f(curr_x)

        if curr_f == 0:
            return curr_x

        if prev_f * curr_f < 0:
            left, right = prev_x, curr_x
            f_left, f_right = prev_f, curr_f
            break

        prev_x, prev_f = curr_x, curr_f
    else:
        raise ValueError("could not bracket a root")

    for _ in range(100):
        mid = (left + right) / 2.0
        f_mid = f(mid)

        if abs(f_mid) < 1e-12 or (right - left) < 1e-12:
            return mid

        if f_left * f_mid <= 0:
            right = mid
            f_right = f_mid
        else:
            left = mid
            f_left = f_mid

    return (left + right) / 2.0
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
