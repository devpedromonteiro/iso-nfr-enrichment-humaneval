
import unittest
import re
import sys
import math
import copy


def get_closest_vowel(word):
    """Return the rightmost vowel that is between two consonants.

    A vowel at the beginning or end does not count. Case sensitive means the
    original character is returned unchanged, while vowel/consonant detection
    treats both lowercase and uppercase vowels as vowels.
    """
    vowels = "aeiouAEIOU"
    n = len(word)

    for i in range(n - 2, 0, -1):
        ch = word[i]
        if (
            ch in vowels
            and word[i - 1] not in vowels
            and word[i + 1] not in vowels
        ):
            return ch
    return ""
candidate = get_closest_vowel


def check(candidate):

    # Check some simple cases
    assert candidate("yogurt") == "u"
    assert candidate("full") == "u"
    assert candidate("easy") == ""
    assert candidate("eAsy") == ""
    assert candidate("ali") == ""
    assert candidate("bad") == "a"
    assert candidate("most") == "o"
    assert candidate("ab") == ""
    assert candidate("ba") == ""
    assert candidate("quick") == ""
    assert candidate("anime") == "i"
    assert candidate("Asia") == ""
    assert candidate("Above") == "o"

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
