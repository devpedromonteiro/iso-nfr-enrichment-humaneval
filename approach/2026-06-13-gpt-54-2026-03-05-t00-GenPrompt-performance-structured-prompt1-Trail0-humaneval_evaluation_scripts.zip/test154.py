
import unittest
import re
import sys
import math
import copy


def cycpattern_check(a, b):
    """Return True if b or any cyclic rotation of b is a substring of a."""
    if not b:
        return True
    if len(b) > len(a):
        return False

    doubled = b + b
    target_len = len(b)

    for i in range(target_len):
        if doubled[i:i + target_len] in a:
            return True
    return False
candidate = cycpattern_check


def check(candidate):

    # Check some simple cases
    #assert True, "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    #assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert  candidate("xyzw","xyw") == False , "test #0"
    assert  candidate("yello","ell") == True , "test #1"
    assert  candidate("whattup","ptut") == False , "test #2"
    assert  candidate("efef","fee") == True , "test #3"
    assert  candidate("abab","aabb") == False , "test #4"
    assert  candidate("winemtt","tinem") == True , "test #5"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
