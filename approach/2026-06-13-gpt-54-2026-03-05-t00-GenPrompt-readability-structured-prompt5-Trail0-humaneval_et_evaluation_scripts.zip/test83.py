
import unittest


def starts_one_ends(n):
    """
    Return the number of n-digit positive integers that start or end with 1.

    An n-digit positive integer:
    - starts with 1 if its first digit is 1
    - ends with 1 if its last digit is 1

    Uses inclusion-exclusion:
    count(start with 1) + count(end with 1) - count(start and end with 1)
    """
    if n <= 0:
        raise ValueError("n must be a positive integer")

    count_starting_with_one = 10 ** (n - 1)
    count_ending_with_one = 9 * (10 ** (n - 2)) if n > 1 else 1
    count_starting_and_ending_with_one = 10 ** (n - 2) if n > 1 else 1

    total_count = (
        count_starting_with_one
        + count_ending_with_one
        - count_starting_and_ending_with_one
    )

    return total_count
candidate = starts_one_ends


class Test(unittest.TestCase):
    def test(self):
        assert candidate(12) == 180000000000
        assert candidate(2) == 18
        assert candidate(14) == 18000000000000
        assert candidate(3) == 180
        assert candidate(19) == 1800000000000000000
        assert candidate(1) == 1
        assert candidate(8) == 18000000
        assert candidate(13) == 1800000000000
        assert candidate(16) == 1800000000000000
        assert candidate(11) == 18000000000
        assert candidate(17) == 18000000000000000
        assert candidate(4) == 1800
        assert candidate(20) == 18000000000000000000
        assert candidate(9) == 180000000
        assert candidate(6) == 180000
        assert candidate(15) == 180000000000000
        assert candidate(5) == 18000
        assert candidate(18) == 180000000000000000
        assert candidate(5) == 18000

    # Check some edge cases that are easy to work out by hand.
        assert candidate(7) == 1800000
        assert candidate(10) == 1800000000

if __name__ == '__main__':
    unittest.main()
