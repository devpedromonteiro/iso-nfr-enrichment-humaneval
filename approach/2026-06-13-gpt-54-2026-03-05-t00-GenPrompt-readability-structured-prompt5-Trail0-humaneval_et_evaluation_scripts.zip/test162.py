
import unittest


import hashlib


def string_to_md5(text):
    """
    Given a string 'text', return its md5 hash equivalent string.
    If 'text' is an empty string, return None.

    >>> string_to_md5('Hello world') == '3e25960a79dbc69b674cd4ec67a72c62'
    """
    if text == "":
        return None

    encoded_text = text.encode("utf-8")
    md5_hash = hashlib.md5(encoded_text)
    hexadecimal_digest = md5_hash.hexdigest()

    return hexadecimal_digest
candidate = string_to_md5


class Test(unittest.TestCase):
    def test(self):
        assert candidate("ObKvFxRMBLPbwVt") == '7811a108f0faba7b80722f1bfd79f5b5'
        assert candidate("fYDthxAGBi") == 'b856cc94dd78ae0ddc62ae7c2193c682'
        assert candidate("yhk") == 'a3dbe1d83b6caf90701237c674e25e20'
        assert candidate("nde") == 'a422413d9ca1bcff6c1b5ba7074d9be3'
        assert candidate("gnkhsnspxxz") == '75f375259d4dc9f5a7b46c9ad25fdb9a'
        assert candidate("zss") == 'aad1db35f0b1aa1072936d9977fa3cb5'
        assert candidate("v") == '9e3669d19b675bd57058fd4664205d2a'
        assert candidate("ye") == '00c66f1a036bd8f9cb709cb8d925d3d9'
        assert candidate('A B C') == '0ef78513b0cb8cef12743f5aeb35f888'
        assert candidate("o") == 'd95679752134a2d9eb61dbd7b91c4bcc'
        assert candidate("cqe") == '2d5b0d0f1ca9699d712cfe330e6b3b60'
        assert candidate("pbelwmk") == '7d48ca9cf4f80873af2b337cb462824c'
        assert candidate("MDJI") == '3283222321086faa8a5624e7d72c9bf5'
        assert candidate("dwnyF boOsdo") == 'a726a16fe6396fedc63aab3ed030dc3f'
        assert candidate("qpw") == '0d107b5fc5cb42327db91cf9b7eebbb4'
        assert candidate("JCV") == '3329474393ecc80ee3c3b92f4ac414b2'
        assert candidate("CYNPPxVbwc") == 'ec09f955fd202b3cd204bd62f74a801c'
        assert candidate("t") == 'e358efa489f58062f10dd7316b65649e'
        assert candidate("fPEYAnhliwYkV") == 'b481aa4685da6beb85f82c1145ccc4e0'
        assert candidate("ebjmilcprg") == '87b35ca4004ff49efecb6f90986bed1f'
        assert candidate("IrJZorcljfKs") == '16139d61f498ce5894280a5e5698e36d'
        assert candidate("jgkjTZ") == 'f059b276ea01208f7985992ac94ec10b'
        assert candidate("ZtBaMWM") == '1f8becd31f659dc3180b82412c052fb6'
        assert candidate("znftgxw") == 'f2c68677d91d5fef4d51a5e4ec6f8e87'
        assert candidate("LROyxujsRPd") == '0459af70991ed75a4f7317a6a432f0bd'
        assert candidate("ixlwfvwlcq") == '2fe54086b4a6e94b2a4827f41034acce'
        assert candidate("gsv") == '79613fb8e7ea792c36d318bb4b2ac641'
        assert candidate("HcQnr KDBjXW e") == '2034b414ccba9e3a75a7d7c502e56a7b'
        assert candidate("rve") == '6ca7a16d5aa37de5d8d20d0be63fe89c'
        assert candidate("hrfa") == '8634b2d56f69e3262532e4cfd736dc97'
        assert candidate("jrkkvnfcojt") == '0e19291c8150ef4cd9e430cf737cda26'
        assert candidate("suh") == '59ef778a74aa43312d57a832901efbbb'
        assert candidate("vm") == '686c821a80914aef822465b48019cd34'
        assert candidate(" FRWZWQ") == '5c0ce9dd99a75e9dd7559361e66a2a54'
        assert candidate("lbcneofdnw") == 'dd1382df6f425db00ef51e02d3abd6cb'
        assert candidate("jn") == '17cedeccc3a6555b9a5826e4d726eae3'
        assert candidate("ULYRdQdgYyKvr") == 'f9edfea582c38545d992caa017a47cfc'
        assert candidate('Hello world') == '3e25960a79dbc69b674cd4ec67a72c62'
        assert candidate("TO ZtNcewj") == '74472c4d750baacc3bee980a699d6714'
        assert candidate("tVxMRyCbqkMjN") == '1aad59314304ea0a64fcf28f73274904'
        assert candidate("Q MOKZHXU") == 'e5ce6c21b90130a1166ccdd1c4bf29d8'
        assert candidate("ODELWFRV") == '6585db1075bd8c6af21ab1991c9b3ef4'
        assert candidate("btxzvnrxff") == '6942ed804e8567dfd9eee5703665499f'
        assert candidate("XQRN RZ") == '51fd4b68ced0af3bb8b80e04e1f20cbd'
        assert candidate("h") == '2510c39011c5be704182423e3a695e91'
        assert candidate("UakQdq") == 'e37307dc975f4670f5abb03655bc3c52'
        assert candidate("vRhQwQXRAXYXk") == '4abaef25ba6fa86e66a7aed32bd07b6f'
        assert candidate("KYHyTpMq HE") == '99d9382fff950447ed38670ccccfdc13'
        assert candidate("njnfpiremy") == '6edd026a6702bf00ea5e7ad7e39e21cc'
        assert candidate("ayonokqiing") == 'ae404defebefbd172976705fe42a6cc3'
        assert candidate(" HOC") == 'f336f91cf78937b17147118f963f885c'
        assert candidate("amo") == '3d5390642ff7a7fd9b7ab8bac4ec3ec5'
        assert candidate("lNTfZa") == '2ba491e66313ab7eac5a38a1e324ec99'
        assert candidate("zkmskpstdgad") == 'd6f641f63e39c29372cd7cffb05625ae'
        assert candidate("TNEDBLXAD") == 'dc4ca5f7a9c1fa04c8c12897e67993b5'
        assert candidate("xe") == '956f8a3a1e6c05797e152fc2b2a0729b'
        assert candidate("RnAgsNQYpdYDfDZ") == '7919b1d4d171867f36b0440f57c1cfeb'
        assert candidate("DFOGRE") == '16acc14673bc90d88bf422ab339853f6'
        assert candidate("iAhGuHgG") == 'a4654a70be2c7ab01fe10feac675a900'
        assert candidate("yOEUDlaAVvW") == '3c0b7f8e2dc36c4dcca063b561cb3b58'
        assert candidate("NGNL") == 'ea9dc311cb9c0eba560b149e98da0d79'
        assert candidate("gai") == 'c8cdc5f3d46143b664d72d039b5832fc'
        assert candidate("voSeoS") == '08822b542e28e6c6ab8d4eedf1dca242'
        assert candidate("eu") == '4829322d03d1606fb09ae9af59a271d3'
        assert candidate("VaHxIhDUrvTOJRI") == '29b090376ebc459327d9c754c481b114'
        assert candidate("esishggicol") == 'b2094518286b45d5272baa6ccd00f942'
        assert candidate("GqtrXXiHwQt") == '0efda166b22fcd0b9c124a0eefc40b2b'
        assert candidate("noc") == '4a5e687705bc436b698d9c28cffe9e26'
        assert candidate("OJPOI ZHE") == '1ff6a83386e9364ee5282dc5a4cecb35'
        assert candidate("kpaiXNYXyA") == 'f520fc36e7bf3e77760bfa28c13b38dd'
        assert candidate("vl") == '28b3aabbdbbe9733da0a27c8c80a0eb7'
        assert candidate("vhk") == '6de4659459c90eb26d7fc4e7f307055f'
        assert candidate("R LHSKWX") == 'cdf8ebf81e06448220e46a06ef7b755e'
        assert candidate("bxaeneozucv") == '4c65531fd7306ff5533e1ea16bfb0cce'
        assert candidate("ambcshxwljh") == '76c387e45777e530b60b6d86f3435303'
        assert candidate("VMCacB") == '647231c97539d0bae003bdb7c9905ad3'
        assert candidate("yycsgllnyq") == '135a57c7afbd55b0761b9af0ec3e94ec'
        assert candidate("WGCJWEUA") == '00e78877b3373720890110d1b297d370'
        assert candidate("VWMM") == '15420d0335408c75578cae887ccd82ba'
        assert candidate("NBHXTMWN") == '37f381a64c465c9cfdaf6a12ec92aacd'
        assert candidate("AFTXSN") == 'be953e2dc57c6b15d4ad6668fb8f2fd3'
        assert candidate("MFRY") == '60696d391319094df10c4a40317a748d'
        assert candidate("OTUB") == '2aa6b636d7df0143879b5b98e12901f1'
        assert candidate(" YHZCIE") == '6e08b0ffaf891241e1cd65003734678a'
        assert candidate("SNTM") == '64354b4843c615754803f33af6fc83f3'
        assert candidate("KJNMLU") == 'c0524ab09d7461fc08a67e9f3c1a79a7'
        assert candidate(" QHLNEU") == '8a01a03aaac6af784853ae67da94a194'
        assert candidate("oou") == 'd5ad000b6930cfdfbc2512f79379a0d3'
        assert candidate('') == None
        assert candidate("tqudrevutw") == 'a749d9b6a10f8323ec418ee33186f5d7'
        assert candidate("xtmyzkvzksx") == '20686834435288eff091d416601d9f20'
        assert candidate("FLJD") == 'cf35c5593ed680044942ea8521867912'
        assert candidate("lixwbwonyge") == 'd2978bb846b45390b2652264c1061e1d'
        assert candidate("RZK") == '357f775f6fa1150ee751433691fe1adf'
        assert candidate("bpn") == 'b6982d2bb25edac541a9611541d0900e'
        assert candidate("BGS") == '3b7f57d0beb30d8eb58ce2e1a24cb7d4'
        assert candidate("qvzszqobvfmb") == '7e9300be67b3bba4c461450a31b9f699'
        assert candidate("nwg") == 'abe97dbb57b6944196ac7eb099a59c89'
        assert candidate("tk") == 'b6717b91c7595cc07f30aa9a784e6390'
        assert candidate("ukypumlar") == 'e946a5b014a8ad7a1d3df13d5e62ed5f'
        assert candidate("a") == '0cc175b9c0f1b6a831c399e269772661'
        assert candidate("x") == '9dd4e461268c8034f5c8564e155c67a6'
        assert candidate("ic") == 'f05a225e14ff5e194a8eef0c6990cefb'
        assert candidate("in") == '13b5bfe96f3e2fe411c9f66f4a582adf'
        assert candidate("xkq") == '6bd37d382fed677c4e90117903d54dcd'
        assert candidate("DZX BWORK") == '291df03432b3b0c8e87537b8454bcb33'
        assert candidate("kxb") == '9473bf3279aaaade35e410e4084db49e'
        assert candidate("usp") == '75581170ffc0cc5ae2d7c2823fe21d6a'
        assert candidate("raycf") == '87454cc36a29a3b495e0370278f35ea3'
        assert candidate("VSROZVQJ") == 'bd284620aa3a2fee11a2306a259fcd31'
        assert candidate("lyjJuN") == '799dbc4a750bd8bb86db6564248a0303'
        assert candidate("yu") == '385d04e7683a033fcc6c6654529eb7e9'
        assert candidate("upzouv") == '77122f6475a79d7d85d228e20ec2ebfe'
        assert candidate("YRdnAyRTb y") == 'ce5111a1384c8e457b0939ae29fa6b5b'
        assert candidate('password') == '5f4dcc3b5aa765d61d8327deb882cf99'

    # Check some edge cases that are easy to work out by hand.
        assert candidate("BSDxYJptDL") == 'a83048fc58eeaf69698f39d4d91e039f'
        assert candidate("RNG Fp") == 'c0abce6ec1437590811b930232b49b0e'
        assert candidate("lfe") == 'c2ce4fe80e2598c76706864b30bf041f'
        assert candidate("cykhnyr") == '75a727897a92c7223d260e57e0b2b3e8'
        assert candidate("oKvWMeUZ") == 'f9d54350a3b1c70f382f0e5a5b63a275'
        assert candidate("anrPPmb") == '56363dbba302c0ead87e8c695b8fc47e'
        assert candidate("g") == 'b2f5ff47436671b6e533d8dc3614845d'
        assert candidate("VORBKDEPW") == '8e5249f3fd9d3985cfa01913c146953b'
        assert candidate("zmtkwpjssm") == 'e142e3a9eabb8c6d2e051ddcec4da146'
        assert candidate("ZNCHUZLX") == 'f7ddb89419a3bf0b11910832591eb324'
        assert candidate("FWWK") == 'd295e57ca9b03d7ae988bb3a9be96416'
        assert candidate("kduesijtuh") == '94713284aca8a114b85c3edcd1ac98a9'
        assert candidate("VDST") == '2d9b5ab0a4868d61dd401f3a8b6f9035'
        assert candidate("krytoz") == '728bd6849b94ce3bee87d1d688a21286'
        assert candidate("MudxSfkMwtstmUK") == '2d9de72eca4e49f2036cf92f916cfaf5'
        assert candidate("HGBLNZHGD") == 'db6145eab6f0c7584160bf0494635633'

if __name__ == '__main__':
    unittest.main()
