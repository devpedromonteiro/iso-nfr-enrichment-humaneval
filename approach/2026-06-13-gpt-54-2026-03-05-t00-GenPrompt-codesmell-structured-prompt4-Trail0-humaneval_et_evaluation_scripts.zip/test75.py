
import unittest


def _is_prime(n):
    """Return True if n is a prime number, otherwise False."""
    if n < 2:
        return False
    if n == 2:
        return True
    if n % 2 == 0:
        return False

    divisor = 3
    while divisor * divisor <= n:
        if n % divisor == 0:
            return False
        divisor += 2
    return True


def is_multiply_prime(a):
    """Return True if a is the product of exactly three prime numbers."""
    if a < 2:
        return False

    prime_factors_count = 0
    remaining = a
    divisor = 2

    while divisor * divisor <= remaining and prime_factors_count < 3:
        while remaining % divisor == 0:
            if not _is_prime(divisor):
                return False
            prime_factors_count += 1
            remaining //= divisor

        divisor = 3 if divisor == 2 else divisor + 2

    if remaining > 1:
        prime_factors_count += 1

    return prime_factors_count == 3
candidate = is_multiply_prime


class Test(unittest.TestCase):
    def test(self):
        assert candidate(121) == False
        assert candidate(890) == True
        assert candidate(894) == False
        assert candidate(734) == False
        assert candidate(122) == False
        assert candidate(32) == False
        assert candidate(130) == True
        assert candidate(106) == False
        assert candidate(109) == False
        assert candidate(728) == False
        assert candidate(893) == False
        assert candidate(889) == False
        assert candidate(31) == False
        assert candidate(729) == False
        assert candidate(25) == False
        assert candidate(8) == True
        assert candidate(127) == False
        assert candidate(7) == False
        assert candidate(125) == True
        assert candidate(104) == False
        assert candidate(724) == False
        assert candidate(131) == False
        assert candidate(887) == False
        assert candidate(3) == False
        assert candidate(895) == False
        assert candidate(725) == True
        assert candidate(9 * 9 * 9) == False
        assert candidate(10) == False
        assert candidate(128) == False
        assert candidate(891) == False
        assert candidate(1) == False
        assert candidate(6) == False
        assert candidate(727) == False
        assert candidate(14) == False
        assert candidate(3 * 6 * 7) == False
        assert candidate(9) == False
        assert candidate(124) == True
        assert candidate(126) == False
        assert candidate(27) == True
        assert candidate(26) == False
        assert candidate(726) == False
        assert candidate(2) == False
        assert candidate(30) == True
        assert candidate(13) == False
        assert candidate(5) == False
        assert candidate(11 * 9 * 9) == False
        assert candidate(129) == False
        assert candidate(12) == True
        assert candidate(11) == False
        assert candidate(107) == False
        assert candidate(3 * 5 * 7) == True
        assert candidate(101) == False
        assert candidate(28) == True
        assert candidate(11 * 13 * 7) == True
        assert candidate(730) == True
        assert candidate(110) == True

if __name__ == '__main__':
    unittest.main()
