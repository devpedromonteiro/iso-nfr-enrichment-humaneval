
import unittest



def correct_bracketing(brackets: str) -> bool:
    """Return True if angle brackets are properly balanced and ordered.

    brackets is a string of "<" and ">".

    >>> correct_bracketing("<")
    False
    >>> correct_bracketing("<>")
    True
    >>> correct_bracketing("<<><>>")
    True
    >>> correct_bracketing("><<>")
    False
    """
    balance = 0

    for bracket in brackets:
        if bracket == "<":
            balance += 1
        elif bracket == ">":
            balance -= 1

        if balance < 0:
            return False

    return balance == 0
candidate = correct_bracketing


class Test(unittest.TestCase):
    def test(self):
        assert candidate("<") == False
        assert candidate("<>") == True
        assert candidate("<><>>>><<") == False
        assert candidate("<>>>>>") == False
        assert candidate("<>>><<<") == False
        assert candidate(">><<>>>><<>>>>") == False
        assert candidate(">>>>><<") == False
        assert candidate("<<><>><<><>>") == True
        assert candidate(">><>><>") == False
        assert not candidate(">")
        assert candidate("<<><>><<><>><>") == True
        assert candidate("<><><<<><><>><>><<><><<>>>") == True
        assert candidate("<><><>") == True
        assert candidate("><<<><<<") == False
        assert candidate("<><><><<><>><>") == True
        assert candidate("<<<<<><>") == False
        assert candidate("<><><<><>><><><><<><>><><><><<><>><>") == True
        assert candidate("<>><>") == False
        assert candidate("><<<>>>>>>>><<><<") == False
        assert candidate(">>>><<><<<") == False
        assert not candidate("><<>")
        assert candidate("<><<><>>") == True
        assert candidate(">") == False
        assert candidate("<<<>") == False
        assert candidate(">><<<") == False
        assert candidate("><<><><>") == False
        assert candidate("<><>>>>><><>>><") == False
        assert candidate("<<><>><<><>><><><<<><><>><>><<><><<>>>") == True
        assert candidate(">>>") == False
        assert candidate("<>><<><<><><><>><>>") == False
        assert candidate(">><<<>><<<<><") == False
        assert candidate(">>>><<<<") == False
        assert candidate("<<<<>><<>") == False
        assert candidate("<>")
        assert candidate(">>>><<<>><><><>><<><") == False
        assert candidate("<><>") == True
        assert not candidate("<")
        assert candidate("") == True
        assert candidate("><<<>><>") == False
        assert candidate("<>>><>") == False
        assert candidate("<<<>><>><") == False
        assert candidate("><><>>") == False
        assert candidate("<>>><>>>>>><><<") == False
        assert candidate("<>>><<<>>>>>><><>><>") == False
        assert candidate("<><><<<><><>><>><<><><<>>>")
        assert candidate("<><<><>><><><<<><><>><>><<><><<>>>") == True
        assert candidate("<<<") == False
        assert candidate(">>><><><<<>><") == False
        assert candidate("<<><>><><><<<><><>><>><<><><<>>>") == True
        assert candidate("<<><>>") == True
        assert candidate("<><><<><>><><><><<><>><>") == True
        assert candidate("<><><<><>><>")
        assert candidate("><<<><") == False
        assert candidate("<><><<>>>><<<<<>") == False
        assert candidate(">><<><>>><><") == False
        assert candidate(">>><>>><") == False
        assert candidate("><><<><") == False
        assert candidate("><>>><<") == False
        assert candidate("<><><<><>><>") == True
        assert candidate("><<") == False
        assert candidate("<<><>>")
        assert candidate(">><>><><") == False
        assert candidate("><>><") == False
        assert candidate(">><") == False
        assert candidate("<><><<><>><><<><>>") == True
        assert candidate(">>><<<>><><<<>>><><") == False
        assert candidate("<<><>><><><<<><><>><>><<><><<>>><><><<><>><>") == True
        assert candidate("<<<>>") == False
        assert not candidate("<><><<><>><>><<>")
        assert not candidate("<<<<")
        assert candidate("<<><>><>") == True
        assert not candidate("<<>")
        assert candidate("><<><>>") == False
        assert candidate("><>>><<>>><<<") == False
        assert candidate("<<><>><<><>><><><<><>><>") == True
        assert candidate("<>><<><") == False
        assert candidate("<<><") == False
        assert not candidate("<><><<><>><>>><>")
        assert candidate("<>><<<<><><>><>") == False
        assert not candidate("<<<><>>>>")
        assert candidate(">>>><><<<>>") == False

if __name__ == '__main__':
    unittest.main()
