
import unittest



def sort_third(lst: list):
    """Return a copy of lst where elements at indices divisible by 3 are sorted,
    while all other elements remain in their original positions.

    >>> sort_third([1, 2, 3])
    [1, 2, 3]
    >>> sort_third([5, 6, 3, 4, 8, 9, 2])
    [2, 6, 3, 4, 8, 9, 5]
    """
    result = lst[:]                 # make a copy
    third_elements = sorted(lst[::3])  # elements at indices 0, 3, 6, ...

    result[::3] = third_elements
    return result
candidate = sort_third


class Test(unittest.TestCase):
    def test(self):
        assert candidate([4, 11, 7, 4, 13, 12, 6]) == [4, 11, 7, 4, 13, 12, 6]
        assert candidate([3, 3, 6, 8, 2, 12, 1]) == [1, 3, 6, 3, 2, 12, 8]
        assert candidate([3, 4, 6, 4, 5, 12, 1, 6]) == [1, 4, 6, 3, 5, 12, 4, 6]
        assert candidate([3, 5, 8, 3, 6, 8, 2]) == [2, 5, 8, 3, 6, 8, 3]
        assert candidate([4, 4, 1]) == [4, 4, 1]
        assert candidate([4, 7, 6]) == [4, 7, 6]
        assert candidate([1, 11, 6, 3, 12, 8, 6]) == [1, 11, 6, 3, 12, 8, 6]
        assert candidate([1, 7, 6]) == [1, 7, 6]
        assert candidate([1, 1, -4, 1, -5, 1, 6, 1, 119, 4, -15]) == [1, 1, -4, 1, -5, 1, 4, 1, 119, 6, -15]
        assert candidate([1, 7, 7, 9, 1, 8, 1]) == [1, 7, 7, 1, 1, 8, 9]
        assert candidate([4, 2, 2]) == [4, 2, 2]
        assert candidate([8, 4, -2, 7, 0, 7, 4, 2, 126, 1, -6]) == [1, 4, -2, 4, 0, 7, 7, 2, 126, 8, -6]
        assert candidate([9, 7, 6, 5, 13, 6, 7]) == [5, 7, 6, 7, 13, 6, 9]
        assert candidate([6, 2, 11, 8, 13, 4, 1]) == [1, 2, 11, 6, 13, 4, 8]
        assert candidate([1, 1, 5]) == [1, 1, 5]
        assert candidate([9, 9, 1, 7, 4, 12, 3, 1]) == [3, 9, 1, 7, 4, 12, 9, 1]
        assert candidate([6, 7, 6, 9, 4, 12, 6]) == [6, 7, 6, 6, 4, 12, 9]
        assert candidate([6, 7, -8, 2, 26, 2, 1, 16, 13, -11]) == [-11, 7, -8, 1, 26, 2, 2, 16, 13, 6]
        assert tuple(candidate([5, 6, 3, 4, 8, 9, 2, 1])) == tuple([2, 6, 3, 4, 8, 9, 5, 1])
        assert candidate([4, 1, 6]) == [4, 1, 6]
        assert candidate([2, 3, 7]) == [2, 3, 7]
        assert candidate([8, 4, -15, 1, 26, 7, 6, 12, 17, -15]) == [-15, 4, -15, 1, 26, 7, 6, 12, 17, 8]
        assert candidate([1, 1, 2, 1, 4, 12, 4]) == [1, 1, 2, 1, 4, 12, 4]
        assert candidate([10, 6, 8, 8, 3, 6, 7, 3]) == [7, 6, 8, 8, 3, 6, 10, 3]
        assert candidate([9, 10, 5, 7, 9, 4, 1]) == [1, 10, 5, 7, 9, 4, 9]
        assert candidate([7, 1, 5, 4, 3, 11, 6, 6]) == [4, 1, 5, 6, 3, 11, 7, 6]
        assert candidate([9, 3, -14, 5, 23, 7, 5, 11, 17, -15]) == [-15, 3, -14, 5, 23, 7, 5, 11, 17, 9]
        assert candidate([5, 2, 6]) == [5, 2, 6]
        assert candidate([3, 6, 8]) == [3, 6, 8]
        assert candidate([6, 1, 8, 3, 9, 1, 7]) == [3, 1, 8, 6, 9, 1, 7]
        assert candidate([4, 2, 5, 6, 6, 6, 6]) == [4, 2, 5, 6, 6, 6, 6]
        assert candidate([10, 2, 11, 4, 7, 4, 3]) == [3, 2, 11, 4, 7, 4, 10]
        assert candidate([1, 2, 3, 9, 6, 4, 7]) == [1, 2, 3, 7, 6, 4, 9]
        assert candidate([9, 2, 8, 9, 11, 5, 3]) == [3, 2, 8, 9, 11, 5, 9]
        assert candidate([2, 10, 1, 6, 7, 13, 6, 4]) == [2, 10, 1, 6, 7, 13, 6, 4]
        assert candidate([7, 7, -9, 8, 23, 3, 4, 10, 17, -5]) == [-5, 7, -9, 4, 23, 3, 7, 10, 17, 8]
        assert candidate([10, 12, 6, 1, 10, 5, 2]) == [1, 12, 6, 2, 10, 5, 10]
        assert candidate([9, 7, -9, 5, 20, 7, 8, 15, 11, -5]) == [-5, 7, -9, 5, 20, 7, 8, 15, 11, 9]
        assert candidate([7, 6, 8, 2, 8, 13, 6]) == [2, 6, 8, 6, 8, 13, 7]
        assert candidate([6, 6, -7, 1, 19, 2, 7, 15, 16, -14]) == [-14, 6, -7, 1, 19, 2, 6, 15, 16, 7]
        assert candidate([3, 9, 6, 8, 6, 8, 3]) == [3, 9, 6, 3, 6, 8, 8]
        assert candidate([7, 3, 4, 1, 3, 14, 1]) == [1, 3, 4, 1, 3, 14, 7]
        assert candidate([8, 6, -13, 2, 28, 3, 5, 12, 17, -6]) == [-6, 6, -13, 2, 28, 3, 5, 12, 17, 8]
        assert candidate([2, 9, 6, 1, 12, 4, 4, 5]) == [1, 9, 6, 2, 12, 4, 4, 5]
        assert tuple(candidate([1, 2, 3])) == tuple(candidate([1, 2, 3]))
        assert candidate([4, 8, 8, 2, 2, 14, 1]) == [1, 8, 8, 2, 2, 14, 4]
        assert tuple(candidate([5, 6, 3, 4, 8, 9, 2])) == tuple([2, 6, 3, 4, 8, 9, 5])
        assert candidate([3, 10, 2, 7, 8, 4, 2]) == [2, 10, 2, 3, 8, 4, 7]
        assert candidate([6, 3, 8, 5, 6, 10, 4, 3]) == [4, 3, 8, 5, 6, 10, 6, 3]
        assert candidate([10, 8, 2, 3, 6, 14, 3]) == [3, 8, 2, 3, 6, 14, 10]
        assert tuple(candidate([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])) == tuple(candidate([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10]))
        assert candidate([1, 11, -16, 3, 22, 7, 5, 8, 16, -15]) == [-15, 11, -16, 1, 22, 7, 3, 8, 16, 5]
        assert candidate([4, 11, 5, 5, 5, 10, 7, 4]) == [4, 11, 5, 5, 5, 10, 7, 4]
        assert candidate([5, 11, 2, 7, 12, 11, 1]) == [1, 11, 2, 5, 12, 11, 7]
        assert candidate([2, 5, 6]) == [2, 5, 6]
        assert tuple(candidate([5, 8, 3, 4, 6, 9, 2])) == tuple([2, 8, 3, 4, 6, 9, 5])
        assert candidate([3, 6, 8, 7, 1, 14, 1]) == [1, 6, 8, 3, 1, 14, 7]
        assert candidate([1, 5, -10, 1, 22, 6, 8, 7, 17, -12]) == [-12, 5, -10, 1, 22, 6, 1, 7, 17, 8]
        assert candidate([7, 1, 4, 5, 6, 12, 4]) == [4, 1, 4, 5, 6, 12, 7]
        assert candidate([4, 2, -8, 1, -4, 2, 7, 1, 128, 5, -9]) == [1, 2, -8, 4, -4, 2, 5, 1, 128, 7, -9]
        assert candidate([10, 7, 10, 7, 4, 3, 1]) == [1, 7, 10, 7, 4, 3, 10]
        assert candidate([2, 3, -4, 4, -3, 7, 10, 3, 118, 3, -10]) == [2, 3, -4, 3, -3, 7, 4, 3, 118, 10, -10]
        assert candidate([5, 8, 6, 4, 11, 10, 4]) == [4, 8, 6, 4, 11, 10, 5]
        assert candidate([9, 6, -5, 6, -8, 5, 5, 4, 119, 6, -12]) == [5, 6, -5, 6, -8, 5, 6, 4, 119, 9, -12]
        assert candidate([10, 9, -13, 7, 22, 1, 1, 10, 16, -8]) == [-8, 9, -13, 1, 22, 1, 7, 10, 16, 10]
        assert candidate([4, 4, 7, 8, 10, 6, 5, 3]) == [4, 4, 7, 5, 10, 6, 8, 3]
        assert candidate([7, 7, 6, 4, 8, 12, 2]) == [2, 7, 6, 4, 8, 12, 7]
        assert candidate([7, 5, -1, 7, 2, 7, 9, 2, 126, 2, -15]) == [2, 5, -1, 7, 2, 7, 7, 2, 126, 9, -15]
        assert candidate([10, 6, -5, 3, -3, 2, 10, 5, 127, 2, -14]) == [2, 6, -5, 3, -3, 2, 10, 5, 127, 10, -14]
        assert candidate([10, 11, 7, 7, 4, 10, 5]) == [5, 11, 7, 7, 4, 10, 10]
        assert candidate([2, 8, 2, 1, 6, 11, 4]) == [1, 8, 2, 2, 6, 11, 4]
        assert candidate([1, 7, 13, 2, 13, 3, 4]) == [1, 7, 13, 2, 13, 3, 4]
        assert candidate([7, 7, -7, 6, -2, 3, 14, 5, 123, 3, -10]) == [3, 7, -7, 6, -2, 3, 7, 5, 123, 14, -10]
        assert candidate([10, 6, 8, 9, 11, 4, 7]) == [7, 6, 8, 9, 11, 4, 10]
        assert candidate([6, 3, -11, 9, 22, 6, 4, 11, 11, -10]) == [-10, 3, -11, 4, 22, 6, 6, 11, 11, 9]
        assert candidate([4, 4, 8]) == [4, 4, 8]
        assert candidate([2, 9, 7, 4, 8, 7, 4, 6]) == [2, 9, 7, 4, 8, 7, 4, 6]
        assert candidate([9, 6, -10, 2, -2, 1, 14, 5, 124, 6, -6]) == [2, 6, -10, 6, -2, 1, 9, 5, 124, 14, -6]
        assert candidate([7, 5, -1, 3, -1, 6, 5, 3, 125, 2, -11]) == [2, 5, -1, 3, -1, 6, 5, 3, 125, 7, -11]
        assert candidate([8, 10, 2, 8, 9, 7, 6, 6]) == [6, 10, 2, 8, 9, 7, 8, 6]
        assert candidate([2, 2, 4]) == [2, 2, 4]
        assert candidate([2, 3, 1]) == [2, 3, 1]
        assert candidate([9, 1, 5, 5, 3, 9, 4, 4]) == [4, 1, 5, 5, 3, 9, 9, 4]
        assert candidate([5, 9, 5, 5, 13, 3, 2]) == [2, 9, 5, 5, 13, 3, 5]
        assert candidate([2, 7, 1, 4, 2, 10, 1]) == [1, 7, 1, 2, 2, 10, 4]
        assert candidate([1, 5, -16, 7, 28, 2, 8, 6, 11, -6]) == [-6, 5, -16, 1, 28, 2, 7, 6, 11, 8]
        assert candidate([9, 3, -3, 7, -7, 6, 5, 5, 127, 1, -13]) == [1, 3, -3, 5, -7, 6, 7, 5, 127, 9, -13]
        assert candidate([3, 2, -1, 5, 0, 1, 8, 5, 128, 5, -11]) == [3, 2, -1, 5, 0, 1, 5, 5, 128, 8, -11]
        assert candidate([6, 7, 5]) == [6, 7, 5]
        assert candidate([6, 11, 9, 8, 3, 2, 1]) == [1, 11, 9, 6, 3, 2, 8]
        assert candidate([9, 9, 5, 5, 3, 5, 5]) == [5, 9, 5, 5, 3, 5, 9]
        assert candidate([9, 11, -17, 8, 24, 7, 5, 7, 10, -9]) == [-9, 11, -17, 5, 24, 7, 8, 7, 10, 9]
        assert candidate([1, 4, 2]) == [1, 4, 2]
        assert candidate([3, 1, 6, 4, 13, 10, 7, 6]) == [3, 1, 6, 4, 13, 10, 7, 6]
        assert candidate([2, 4, -4, 6, -8, 8, 4, 5, 123, 3, -10]) == [2, 4, -4, 3, -8, 8, 4, 5, 123, 6, -10]
        assert candidate([1, 9, 4, 2, 7, 8, 5]) == [1, 9, 4, 2, 7, 8, 5]
        assert candidate([1, 2, 11, 8, 8, 2, 4]) == [1, 2, 11, 4, 8, 2, 8]
        assert candidate([3, 3, -10, 4, -6, 5, 11, 3, 121, 5, -15]) == [3, 3, -10, 4, -6, 5, 5, 3, 121, 11, -15]
        assert candidate([7, 1, 2, 9, 11, 10, 4]) == [4, 1, 2, 7, 11, 10, 9]
        assert candidate([4, 3, -17, 8, 20, 7, 5, 14, 11, -14]) == [-14, 3, -17, 4, 20, 7, 5, 14, 11, 8]
        assert candidate([9, 5, -12, 2, 25, 6, 5, 7, 16, -14]) == [-14, 5, -12, 2, 25, 6, 5, 7, 16, 9]
        assert candidate([2, 4, 5, 7, 12, 4, 3]) == [2, 4, 5, 3, 12, 4, 7]
        assert candidate([6, 8, 4, 7, 8, 8, 3, 6]) == [3, 8, 4, 6, 8, 8, 7, 6]
        assert candidate([3, 8, 4, 2, 8, 12, 5, 5]) == [2, 8, 4, 3, 8, 12, 5, 5]
        assert candidate([2, 6, 2]) == [2, 6, 2]
        assert candidate([2, 10, 6, 8, 13, 11, 1, 1]) == [1, 10, 6, 2, 13, 11, 8, 1]
        assert candidate([3, 5, 3, 6, 10, 11, 1]) == [1, 5, 3, 3, 10, 11, 6]
        assert candidate([8, 10, 6, 4, 13, 4, 6]) == [4, 10, 6, 6, 13, 4, 8]
        assert candidate([6, 10, -7, 9, 27, 2, 2, 7, 12, -15]) == [-15, 10, -7, 2, 27, 2, 6, 7, 12, 9]
        assert candidate([4, 6, -6, 2, -3, 2, 5, 2, 128, 5, -12]) == [2, 6, -6, 4, -3, 2, 5, 2, 128, 5, -12]
        assert candidate([10, 7, 2, 4, 5, 7, 2]) == [2, 7, 2, 4, 5, 7, 10]
        assert candidate([8, 8, 4, 1, 4, 8, 7]) == [1, 8, 4, 7, 4, 8, 8]
        assert candidate([7, 7, 7, 4, 11, 14, 1, 6]) == [1, 7, 7, 4, 11, 14, 7, 6]
        assert tuple(candidate([5, 8, -12, 4, 23, 2, 3, 11, 12, -10])) == tuple(candidate([5, 8, -12, 4, 23, 2, 3, 11, 12, -10]))
        assert candidate([7, 4, 11, 8, 8, 1, 1]) == [1, 4, 11, 7, 8, 1, 8]
        assert candidate([3, 6, 9, 4, 5, 5, 2]) == [2, 6, 9, 3, 5, 5, 4]
        assert candidate([3, 7, -15, 6, 23, 3, 6, 11, 15, -14]) == [-14, 7, -15, 3, 23, 3, 6, 11, 15, 6]
        assert candidate([6, 5, 6, 2, 5, 1, 5]) == [2, 5, 6, 5, 5, 1, 6]
        assert candidate([4, 5, 3, 6, 7, 11, 6]) == [4, 5, 3, 6, 7, 11, 6]
        assert candidate([5, 7, 8, 4, 5, 8, 5]) == [4, 7, 8, 5, 5, 8, 5]
        assert tuple(candidate([5, 6, 9, 4, 8, 3, 2])) == tuple([2, 6, 9, 4, 8, 3, 5])
        assert candidate([7, 6, 1, 4, 3, 10, 3]) == [3, 6, 1, 4, 3, 10, 7]
        assert candidate([6, 7, 4]) == [6, 7, 4]
        assert candidate([1, 7, -3, 6, -6, 7, 9, 5, 126, 2, -7]) == [1, 7, -3, 2, -6, 7, 6, 5, 126, 9, -7]
        assert candidate([6, 6, 3, 9, 11, 11, 6]) == [6, 6, 3, 6, 11, 11, 9]
        assert candidate([2, 4, 3, 4, 4, 6, 1]) == [1, 4, 3, 2, 4, 6, 4]
        assert candidate([7, 8, -8, 5, -3, 6, 14, 2, 119, 5, -9]) == [5, 8, -8, 5, -3, 6, 7, 2, 119, 14, -9]
        assert candidate([6, 6, -9, 1, 2, 6, 10, 5, 127, 2, -6]) == [1, 6, -9, 2, 2, 6, 6, 5, 127, 10, -6]
        assert candidate([7, 3, 7, 8, 5, 8, 2]) == [2, 3, 7, 7, 5, 8, 8]
        assert candidate([9, 7, 7, 1, 4, 2, 4]) == [1, 7, 7, 4, 4, 2, 9]
        assert candidate([9, 3, -8, 7, 24, 6, 3, 7, 16, -7]) == [-7, 3, -8, 3, 24, 6, 7, 7, 16, 9]
        assert candidate([1, 3, 8, 2, 10, 8, 1, 1]) == [1, 3, 8, 1, 10, 8, 2, 1]

if __name__ == '__main__':
    unittest.main()
