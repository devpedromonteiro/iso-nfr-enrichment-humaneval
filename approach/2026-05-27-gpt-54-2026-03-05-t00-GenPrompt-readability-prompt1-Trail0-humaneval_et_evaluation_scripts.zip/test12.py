
import unittest

from typing import List, Optional


from typing import List, Optional


def longest(strings: List[str]) -> Optional[str]:
    """Out of a list of strings, return the longest one.

    Return the first string in case of multiple strings of the same length.
    Return None if the input list is empty.

    >>> longest([])

    >>> longest(['a', 'b', 'c'])
    'a'
    >>> longest(['a', 'bb', 'ccc'])
    'ccc'
    """
    if not strings:
        return None

    longest_string = strings[0]
    for s in strings[1:]:
        if len(s) > len(longest_string):
            longest_string = s

    return longest_string
candidate = longest


class Test(unittest.TestCase):
    def test(self):
        assert candidate(['i', 'u', 'r']) == 'i'
        assert candidate(['c', 'logvehhem', 'umvs', 'gkw', 'rhr', 'vyexmzch']) == 'logvehhem'
        assert candidate(['n', 'v', 'x']) == 'n'
        assert candidate(['s', 'e', 'q']) == 's'
        assert candidate(['t', 'b', 'h']) == 't'
        assert candidate(['v', 'zhkmizr', 'wyex', 'wjqo', 'ciap', 'ioj']) == 'zhkmizr'
        assert candidate(['m', 'hjystvsai', 'tumnp', 'uxv', 'vkl', 'iktqzxrv']) == 'hjystvsai'
        assert candidate(['t', 'b', 'w']) == 't'
        assert candidate(['v', 'odkvmah', 'fmh', 'psjdqunt', 'syrh', 'qwvghqcr']) == 'psjdqunt'
        assert candidate(['b', 'wiefonpj', 'qpvsakyqh', 'ooirzmqh', 'cyh', 'nfvkjv']) == 'qpvsakyqh'
        assert candidate(['v', 'a', 'm']) == 'v'
        assert candidate(['g', 'ygydv', 'zsohbakc', 'fjpxwgsr', 'otodxbga', 'pmlltonga']) == 'pmlltonga'
        assert candidate(['s', 'z', 'g']) == 's'
        assert candidate(['s', 't', 'o']) == 's'
        assert candidate(['e', 'jvupklf', 'imnpycfx', 'bzcduj', 'eqixkmbiy', 'tskez']) == 'eqixkmbiy'
        assert candidate(['x', 's', 'b']) == 'x'
        assert candidate(['t', 'ixesuuqxb', 'akvmz', 'wzwldgjz', 'mcfvjotnm', 'xori']) == 'ixesuuqxb'
        assert candidate(['v', 'y', 'z']) == 'v'
        assert candidate(['b', 'kza', 'uik', 'uijh', 'eqzejftbl', 'fac']) == 'eqzejftbl'
        assert candidate(['c', 'rbk', 'nyyhugpej', 'cfxjw', 'tndvwxsa', 'efzkgbudi']) == 'nyyhugpej'
        assert candidate(['b', 'o', 'm']) == 'b'
        assert candidate(['l', 'rppneqm', 'mqvd', 'yonee', 'ugldkkj', 'njbgjoop']) == 'njbgjoop'
        assert candidate(['h', 's', 'd']) == 'h'
        assert candidate(['l', 'dfbhyd', 'fxcinkrx', 'yissagos', 'uwnqyhxy', 'iztgjfudg']) == 'iztgjfudg'
        assert candidate(['c', 'm', 'a']) == 'c'
        assert candidate(['a', 'gnnseltot', 'akwpqkli', 'bpbgx', 'ydrrdwy', 'nidw']) == 'gnnseltot'
        assert candidate(['g', 'vxlrwchn', 'rgoghdbv', 'kcjju', 'ijksqerp', 'jcrkjni']) == 'vxlrwchn'
        assert candidate(['x', 'g', 'n']) == 'x'
        assert candidate(['j', 'x', 'z']) == 'j'
        assert candidate(['u', 'y', 'j']) == 'u'
        assert candidate(['v', 'z', 'l']) == 'v'
        assert candidate(['e', 'l', 'i']) == 'e'
        assert candidate(['d', 'fru', 'wjalnezcn', 'msdx', 'risayuo', 'rooknfpse']) == 'wjalnezcn'
        assert candidate(['x', 'y', 'z']) == 'x'
        assert candidate(['e', 'j', 'c']) == 'e'
        assert candidate(['e', 'e', 't']) == 'e'
        assert candidate(['r', 'h', 'x']) == 'r'
        assert candidate(['b', 'm', 'g']) == 'b'
        assert candidate(['w', 'tamgxrvr', 'rwyxsc', 'lswpd', 'qke', 'ljtkwujes']) == 'ljtkwujes'
        assert candidate(['u', 'ocmwx', 'gocns', 'gvbfdww', 'ssfzubi', 'yfdgv']) == 'gvbfdww'
        assert candidate(['p', 'd', 'a']) == 'p'
        assert candidate(['f', 'z', 'm']) == 'f'
        assert candidate(['x', 'rqpngsn', 'fxo', 'ayd', 'bldjie', 'yiiftuwkc']) == 'yiiftuwkc'
        assert candidate(['q', 'uupsqrag', 'vwcr', 'vlpgkmf', 'ebb', 'hhngqm']) == 'uupsqrag'
        assert candidate(['x', 'r', 'u']) == 'x'
        assert candidate(['s', 'njgj', 'dejwtok', 'mkskddbcp', 'oxemwayvo', 'ubcjouypj']) == 'mkskddbcp'
        assert candidate(['x', 'v', 'w']) == 'x'
        assert candidate(['c', 'z', 't']) == 'c'
        assert candidate(['t', 'wnvjdthhs', 'kbm', 'prlvh', 'ojtpp', 'tvrwuok']) == 'wnvjdthhs'
        assert candidate(['y', 'ruasz', 'vnzy', 'cktbfgp', 'wij', 'oskvo']) == 'cktbfgp'
        assert candidate(['a', 'yixbzyk', 'dfmcyo', 'kmwvx', 'styeg', 'fhei']) == 'yixbzyk'
        assert candidate(['z', 'b', 'f']) == 'z'
        assert candidate(['z', 'y', 'k']) == 'z'
        assert candidate(['j', 'a', 'p']) == 'j'
        assert candidate(['o', 'xyq', 'ntgn', 'pvtqwc', 'bbxty', 'mlzcy']) == 'pvtqwc'
        assert candidate([]) == None
        assert candidate(['q', 'lxamh', 'voicvblnb', 'bvytmisp', 'yivfwv', 'fmgncj']) == 'voicvblnb'
        assert candidate(['k', 'v', 's']) == 'k'
        assert candidate(['f', 'o', 'u']) == 'f'
        assert candidate(['a', 'r', 'h']) == 'a'
        assert candidate(['d', 'zcozusald', 'hvce', 'wzf', 'zdykqd', 'obak']) == 'zcozusald'
        assert candidate(['r', 'p', 'h']) == 'r'
        assert candidate(['q', 'v', 'u']) == 'q'
        assert candidate(['p', 'vzss', 'iqnejr', 'qsvuiv', 'xqvcqh', 'pevcja']) == 'iqnejr'
        assert candidate(['v', 'ahlx', 'kycdr', 'uve', 'onyzz', 'ebjp']) == 'kycdr'
        assert candidate(['t', 'n', 'e']) == 't'
        assert candidate(['n', 'yqzn', 'bbzdfhted', 'iia', 'juygeahsf', 'zrfxgf']) == 'bbzdfhted'
        assert candidate(['l', 'q', 'x']) == 'l'
        assert candidate(['z', 'w', 'o']) == 'z'
        assert candidate(['o', 'ajmdqe', 'pzpdkn', 'xfnrkwwl', 'apoqrezod', 'qhw']) == 'apoqrezod'
        assert candidate(['i', 'tujc', 'jyi', 'hwywam', 'bvfwnbqdv', 'dsc']) == 'bvfwnbqdv'
        assert candidate(['y', 'l', 'k']) == 'y'
        assert candidate(['s', 's', 'y']) == 's'
        assert candidate(['q', 'w', 'g']) == 'q'
        assert candidate(['x', 'cwnjhznrf', 'qazkxd', 'ifuvq', 'cueni', 'fzp']) == 'cwnjhznrf'
        assert candidate(['o', 'fwatymi', 'litvopt', 'ibcda', 'ulfgf', 'xpkezldlr']) == 'xpkezldlr'
        assert candidate(['u', 'lhmq', 'pshemmm', 'zmjyho', 'ajeobmwyv', 'ifan']) == 'ajeobmwyv'
        assert candidate(['a', 'cxpnpgrwe', 'ezda', 'fiym', 'xlw', 'hdhqvijm']) == 'cxpnpgrwe'
        assert candidate(['k', 'ohuuogxw', 'mds', 'qwmcwb', 'ktcgj', 'xmbaf']) == 'ohuuogxw'
        assert candidate(['e', 'sdv', 'jpmyt', 'lvw', 'swi', 'eot']) == 'jpmyt'
        assert candidate(['d', 'csil', 'qef', 'oktirf', 'gvumcc', 'kzhp']) == 'oktirf'
        assert candidate(['c', 'uztuk', 'vqav', 'qleqveztm', 'prew', 'lvxbqomwx']) == 'qleqveztm'
        assert candidate(['y', 'brouq', 'fiwx', 'ayrhzx', 'zjndmn', 'qudi']) == 'ayrhzx'
        assert candidate(['g', 'qztp', 'wocmcj', 'tyufmnqjw', 'gxzjdox', 'neacacmg']) == 'tyufmnqjw'
        assert candidate(['w', 'kshl', 'fekjnsrpe', 'odglxszx', 'cfvq', 'rjjnlsz']) == 'fekjnsrpe'
        assert candidate(['d', 'x', 'x']) == 'd'
        assert candidate(['a', 'vssugkg', 'wmniwmxwd', 'ktlfux', 'yrceq', 'dna']) == 'wmniwmxwd'
        assert candidate(['s', 'llv', 'fwn', 'zffgx', 'gyfro', 'qiwnqagxo']) == 'qiwnqagxo'
        assert candidate(['a', 'h', 'h']) == 'a'
        assert candidate(['d', 'lrkwoosb', 'dmbcgm', 'nusekhwj', 'waet', 'uelugt']) == 'lrkwoosb'
        assert candidate(['l', 'l', 'v']) == 'l'
        assert candidate(['u', 'qfdbi', 'jwxymwin', 'xilo', 'afwytgdm', 'ihzwvkp']) == 'jwxymwin'
        assert candidate(['t', 'rntpbpgzc', 'cdep', 'gskjgrzwo', 'vwu', 'dnlzycpa']) == 'rntpbpgzc'
        assert candidate(['f', 'l', 'c']) == 'f'
        assert candidate(['r', 'j', 'b']) == 'r'
        assert candidate(['w', 'igbqgwe', 'aqvihwzlv', 'caue', 'hybtb', 'idvykeyhs']) == 'aqvihwzlv'
        assert candidate(['e', 'ztvpfcf', 'qszifchgt', 'hqxcd', 'rebrhhsj', 'jppauc']) == 'qszifchgt'
        assert candidate(['y', 'x', 'c']) == 'y'
        assert candidate(['h', 's', 'g']) == 'h'
        assert candidate(['j', 'epkxrclw', 'axa', 'gba', 'tahjiywx', 'xhudcfasm']) == 'xhudcfasm'
        assert candidate(['n', 'p', 'e']) == 'n'
        assert candidate(['s', 't', 'c']) == 's'
        assert candidate(['x', 'yyy', 'zzzz', 'www', 'kkkk', 'abc']) == 'zzzz'

if __name__ == '__main__':
    unittest.main()
