
import unittest


def _digit_parity_counts(digits: str) -> tuple[int, int]:
    """Return counts of even and odd digits in a digit-only string."""
    even = 0
    odd = 0

    for digit in digits:
        if int(digit) % 2 == 0:
            even += 1
        else:
            odd += 1

    return even, odd


def even_odd_count(num):
    """Given an integer, return a tuple with the number of even and odd digits.

    Examples:
        even_odd_count(-12) == (1, 1)
        even_odd_count(123) == (1, 2)
    """
    digits = str(abs(num))
    return _digit_parity_counts(digits)
candidate = even_odd_count


class Test(unittest.TestCase):
    def test(self):
        assert candidate(7) == (0, 1)
        assert candidate(-80) == (2, 0)
        assert candidate(345577) == (1, 5)
        assert candidate(2) == (1, 0)
        assert candidate(345308) == (3, 3)
        assert candidate(-4) == (1, 0)
        assert candidate(0) == (1, 0)


    # Check some edge cases that are easy to work out by hand.
        assert candidate(345501) == (2, 4)
        assert candidate(-76) == (1, 1)
        assert candidate(-345816) == (3, 3)
        assert candidate(-45352) == (2, 3)
        assert candidate(-45351) == (1, 4)
        assert candidate(2450) == (3, 1)
        assert candidate(-345822) == (4, 2)
        assert candidate(3171) == (0, 4)
        assert candidate(-75) == (0, 2)
        assert candidate(-45348) == (3, 2)
        assert candidate(1) == (0, 1)
        assert candidate(346175) == (2, 4)
        assert candidate(4) == (1, 0)
        assert candidate(345265) == (3, 3)
        assert candidate(-45345) == (2, 3)
        assert candidate(-74) == (1, 1)
        assert candidate(-345819) == (2, 4)
        assert candidate(345360) == (3, 3)
        assert candidate(3452) == (2, 2)
        assert candidate(3347) == (1, 3)
        assert candidate(-345820) == (4, 2)
        assert candidate(-45343) == (2, 3)
        assert candidate(-45347) == (2, 3)
        assert candidate(346787) == (3, 3)
        assert candidate(-2) == (1, 0)
        assert candidate(-345821) == (3, 3)
        assert candidate(-77) == (0, 2)
        assert candidate(-73) == (0, 2)
        assert candidate(-79) == (0, 2)
        assert candidate(345858) == (3, 3)
        assert candidate(346658) == (4, 2)
        assert candidate(10) == (1, 1)
        assert candidate(345794) == (2, 4)
        assert candidate(346614) == (4, 2)
        assert candidate(3987) == (1, 3)
        assert candidate(9) == (0, 1)
        assert candidate(-5) == (0, 1)
        assert candidate(347145) == (2, 4)
        assert candidate(4207) == (3, 1)
        assert candidate(-45344) == (3, 2)
        assert candidate(3949) == (1, 3)
        assert candidate(3) == (0, 1)
        assert candidate(-82) == (2, 0)
        assert candidate(-81) == (1, 1)
        assert candidate(-45349) == (2, 3)
        assert candidate(346547) == (3, 3)
        assert candidate(5) == (0, 1)
        assert candidate(-45346) == (3, 2)
        assert candidate(-345817) == (2, 4)
        assert candidate(12) == (1, 1)
        assert candidate(3444) == (3, 1)
        assert candidate(3981) == (1, 3)
        assert candidate(0) == (1, 0)
        assert candidate(-3) == (0, 1)
        assert candidate(346081) == (4, 2)
        assert candidate(-345823) == (3, 3)
        assert candidate(8) == (1, 0)
        assert candidate(3015) == (1, 3)
        assert candidate(3724) == (2, 2)
        assert candidate(345220) == (4, 2)
        assert candidate(346211) == (3, 3)
        assert candidate(-78) == (1, 1)
        assert candidate(2810) == (3, 1)
        assert candidate(2650) == (3, 1)
        assert candidate(-83) == (1, 1)
        assert candidate(-345824) == (4, 2)
        assert candidate(-345818) == (3, 3)
        assert candidate(-6) == (1, 0)
        assert candidate(-7) == (0, 1)
        assert candidate(2708) == (3, 1)
        assert candidate(-1) == (0, 1)
        assert candidate(-345825) == (3, 3)

if __name__ == '__main__':
    unittest.main()
