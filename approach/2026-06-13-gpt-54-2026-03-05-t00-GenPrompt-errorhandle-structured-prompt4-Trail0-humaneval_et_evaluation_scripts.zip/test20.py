
import unittest

from typing import List, Tuple


from typing import List, Tuple


def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    """From a supplied list of numbers (of length at least two) select and return
    two that are the closest to each other and return them in order
    (smaller number, larger number).

    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.2])
    (2.0, 2.2)
    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.0])
    (2.0, 2.0)
    """
    if not isinstance(numbers, list):
        raise TypeError("numbers must be a list of numeric values")

    if len(numbers) < 2:
        raise ValueError("numbers must contain at least two elements")

    for i, value in enumerate(numbers):
        if not isinstance(value, (int, float)):
            raise TypeError(f"numbers[{i}] must be an int or float, got {type(value).__name__}")

    try:
        sorted_numbers = sorted(float(x) for x in numbers)
    except (TypeError, ValueError) as exc:
        raise TypeError("all elements in numbers must be numeric and sortable") from exc

    closest_pair = (sorted_numbers[0], sorted_numbers[1])
    smallest_diff = abs(sorted_numbers[1] - sorted_numbers[0])

    for i in range(1, len(sorted_numbers) - 1):
        current_diff = abs(sorted_numbers[i + 1] - sorted_numbers[i])
        if current_diff < smallest_diff:
            smallest_diff = current_diff
            closest_pair = (sorted_numbers[i], sorted_numbers[i + 1])

    return closest_pair
candidate = find_closest_elements


class Test(unittest.TestCase):
    def test(self):
        assert candidate([2.799, 5.734, 9.072, 8.167, 1.17]) == (8.167, 9.072)
        assert candidate([1.151, 7.331, 6.961, 1.121, 9.394]) == (1.121, 1.151)
        assert candidate([3.76, 5.019, 7.274, 5.739, 6.283, 3.921]) == (3.76, 3.921)
        assert candidate([6.325, 3.072, 5.428, 7.297, 4.089, 5.66]) == (5.428, 5.66)
        assert candidate([5.585, 6.614, 3.842, 7.308, 1.869, 4.385]) == (3.842, 4.385)
        assert candidate([5.266, 2.316, 2.106, 4.695, 7.829, 5.356]) == (5.266, 5.356)
        assert candidate([6.723, 1.347, 1.701, 9.386, 7.071, 4.776]) == (6.723, 7.071)
        assert candidate([4.149, 7.544, 8.706, 2.894, 6.973, 4.602]) == (4.149, 4.602)
        assert candidate([1.0, 2.0, 5.9, 4.0, 5.0]) == (5.0, 5.9)
        assert candidate([6.619, 4.238, 3.558, 1.332, 4.671, 3.48]) == (3.48, 3.558)
        assert candidate([2.511, 2.209, 5.873, 5.542, 9.527]) == (2.209, 2.511)
        assert candidate([2.02, 2.285, 5.994, 4.996, 10.628, 1.044]) == (2.02, 2.285)
        assert candidate([2.221, 4.878, 3.058, 5.94, 3.965]) == (2.221, 3.058)
        assert candidate([4.849, 6.916, 2.678, 8.661, 1.55]) == (1.55, 2.678)
        assert candidate([6.835, 2.3, 5.897, 8.478, 8.459, 3.905]) == (8.459, 8.478)
        assert candidate([1.476, 2.717, 8.239, 7.924, 3.257]) == (7.924, 8.239)
        assert candidate([1.861, 2.25, 2.69, 7.092, 10.91, 2.034]) == (1.861, 2.034)
        assert candidate([4.547, 4.481, 3.379, 1.256, 1.726, 1.324]) == (4.481, 4.547)
        assert candidate([6.674, 2.703, 6.562, 7.232, 1.66]) == (6.562, 6.674)
        assert candidate([1.738, 4.294, 4.231, 5.973, 7.751]) == (4.231, 4.294)
        assert candidate([4.543, 1.53, 2.265, 7.111, 5.605, 3.81]) == (3.81, 4.543)
        assert candidate([4.768, 3.585, 10.538, 2.821, 6.735]) == (2.821, 3.585)
        assert candidate([2.095, 1.209, 3.629, 8.322, 2.181, 4.773]) == (2.095, 2.181)
        assert candidate([6.545, 1.304, 2.802, 2.275, 9.414, 3.214]) == (2.802, 3.214)
        assert candidate([3.657, 2.81, 9.353, 1.637, 2.389]) == (2.389, 2.81)
        assert candidate([3.163, 7.088, 2.137, 8.142, 10.34, 4.478]) == (2.137, 3.163)
        assert candidate([1.126, 4.13, 1.621, 5.694, 9.119, 6.507]) == (1.126, 1.621)
        assert candidate([5.706, 4.372, 5.028, 6.128, 1.755, 1.426]) == (1.426, 1.755)
        assert candidate([5.663, 5.943, 3.838, 8.325, 3.551]) == (5.663, 5.943)
        assert candidate([1.167, 6.164, 1.599, 3.39, 2.371, 3.681]) == (3.39, 3.681)
        assert candidate([5.391, 7.059, 5.446, 8.009, 10.213, 7.823]) == (5.391, 5.446)
        assert candidate([2.887, 7.782, 8.023, 5.004, 6.454, 7.722]) == (7.722, 7.782)
        assert candidate([4.651, 4.954, 8.472, 5.048, 7.008, 1.21]) == (4.954, 5.048)
        assert candidate([5.491, 2.311, 4.077, 8.943, 10.549, 2.901]) == (2.311, 2.901)
        assert candidate([5.712, 1.274, 8.172, 4.921, 9.539, 4.876]) == (4.876, 4.921)
        assert candidate([2.455, 6.483, 4.497, 8.124, 9.81, 7.223]) == (6.483, 7.223)
        assert candidate([5.884, 3.934, 2.135, 5.072, 6.536, 5.227]) == (5.072, 5.227)
        assert candidate([6.26, 6.141, 7.317, 7.204, 4.595, 2.319]) == (7.204, 7.317)
        assert candidate([4.742, 4.371, 3.74, 7.145, 7.351, 1.976]) == (7.145, 7.351)
        assert candidate([3.902, 4.617, 5.353, 7.86, 4.224, 4.076]) == (4.076, 4.224)
        assert candidate([2.355, 5.36, 5.435, 9.968, 5.954]) == (5.36, 5.435)
        assert candidate([4.739, 5.317, 7.732, 9.028, 8.783]) == (8.783, 9.028)
        assert candidate([3.643, 6.34, 1.179, 3.094, 4.846, 7.076]) == (3.094, 3.643)
        assert candidate([3.457, 4.679, 1.687, 7.789, 3.562]) == (3.457, 3.562)
        assert candidate([1.922, 7.851, 6.952, 7.923, 10.47, 2.667]) == (7.851, 7.923)
        assert candidate([3.404, 6.53, 2.433, 8.401, 10.403, 5.454]) == (2.433, 3.404)
        assert candidate([4.476, 2.311, 7.797, 6.765, 8.914]) == (6.765, 7.797)
        assert candidate([2.934, 1.264, 5.155, 2.683, 6.177, 7.174]) == (2.683, 2.934)
        assert candidate([2.04, 4.721, 1.829, 8.584, 9.484]) == (1.829, 2.04)
        assert candidate([5.231, 5.467, 10.012, 5.877, 3.795]) == (5.231, 5.467)
        assert candidate([2.413, 6.334, 1.835, 7.668, 5.353, 3.727]) == (1.835, 2.413)
        assert candidate([1.881, 5.861, 7.574, 6.511, 9.97, 3.808]) == (5.861, 6.511)
        assert candidate([1.75, 3.762, 8.084, 3.769, 7.086]) == (3.762, 3.769)
        assert candidate([3.035, 3.043, 6.939, 3.285, 8.417, 2.245]) == (3.035, 3.043)
        assert candidate([5.728, 5.369, 2.503, 1.725, 2.121, 5.613]) == (5.613, 5.728)
        assert candidate([5.052, 2.518, 4.847, 5.006, 4.581]) == (5.006, 5.052)
        assert candidate([1.886, 6.604, 8.097, 2.398, 7.53]) == (1.886, 2.398)
        assert candidate([4.055, 7.398, 8.972, 3.325, 10.781, 6.26]) == (3.325, 4.055)
        assert candidate([1.747, 1.138, 2.993, 8.012, 9.711]) == (1.138, 1.747)
        assert candidate([4.005, 1.483, 4.773, 9.401, 10.654]) == (4.005, 4.773)
        assert candidate([5.162, 1.625, 2.306, 7.743, 3.918, 7.365]) == (7.365, 7.743)
        assert candidate([3.767, 6.465, 7.577, 9.717, 8.324]) == (7.577, 8.324)
        assert candidate([4.434, 3.213, 3.317, 2.077, 10.033]) == (3.213, 3.317)
        assert candidate([5.658, 6.558, 7.895, 8.161, 9.407, 3.14]) == (7.895, 8.161)
        assert candidate([1.0, 2.0, 3.0, 4.0, 5.0, 2.2]) == (2.0, 2.2)
        assert candidate([1.817, 7.132, 7.831, 5.286, 5.238, 7.889]) == (5.238, 5.286)
        assert candidate([1.808, 3.99, 2.648, 8.19, 10.03, 3.08]) == (2.648, 3.08)
        assert candidate([4.578, 7.334, 3.074, 7.698, 5.754, 3.228]) == (3.074, 3.228)
        assert candidate([1.846, 2.086, 8.878, 1.452, 5.541, 5.4]) == (5.4, 5.541)
        assert candidate([1.869, 7.234, 3.548, 4.517, 10.721, 2.386]) == (1.869, 2.386)
        assert candidate([1.917, 3.618, 5.743, 5.077, 4.788, 2.651]) == (4.788, 5.077)
        assert candidate([2.431, 3.098, 3.198, 1.749, 3.08, 5.905]) == (3.08, 3.098)
        assert candidate([2.122, 5.672, 3.248, 8.415, 7.934, 1.573]) == (7.934, 8.415)
        assert candidate([4.109, 4.434, 10.408, 1.231, 7.809]) == (4.109, 4.434)
        assert candidate([4.093, 1.763, 6.268, 6.813, 7.613]) == (6.268, 6.813)
        assert candidate([2.861, 5.281, 10.635, 6.34, 9.942]) == (9.942, 10.635)
        assert candidate([1.407, 2.722, 9.408, 6.13, 8.484]) == (8.484, 9.408)
        assert candidate([1.583, 1.622, 3.267, 1.369, 9.183, 1.109]) == (1.583, 1.622)
        assert candidate([1.0, 2.0, 3.0, 4.0, 5.0, 2.0]) == (2.0, 2.0)
        assert candidate([5.581, 3.297, 3.618, 7.633, 5.968]) == (3.297, 3.618)
        assert candidate([6.581, 2.975, 1.545, 7.51, 1.984, 6.974]) == (6.581, 6.974)
        assert candidate([1.899, 5.546, 1.471, 7.277, 4.704, 2.178]) == (1.899, 2.178)
        assert candidate([2.184, 1.057, 6.418, 3.603, 4.392, 2.992]) == (2.992, 3.603)
        assert candidate([6.888, 6.146, 4.217, 7.785, 1.434, 5.675]) == (5.675, 6.146)
        assert candidate([2.332, 2.681, 2.23, 8.684, 9.103]) == (2.23, 2.332)
        assert candidate([4.026, 7.41, 7.265, 5.317, 5.086, 3.325]) == (7.265, 7.41)
        assert candidate([1.1, 2.2, 3.1, 4.1, 5.1]) == (2.2, 3.1)
        assert candidate([3.366, 3.412, 4.331, 6.475, 1.551]) == (3.366, 3.412)
        assert candidate([2.376, 5.979, 5.7, 1.555, 4.588]) == (5.7, 5.979)
        assert candidate([1.886, 7.694, 1.523, 9.933, 1.796, 7.99]) == (1.796, 1.886)
        assert candidate([3.741, 3.162, 3.933, 7.305, 7.172]) == (7.172, 7.305)
        assert candidate([6.289, 5.037, 6.63, 6.769, 7.718, 6.371]) == (6.289, 6.371)
        assert candidate([6.401, 5.439, 7.455, 2.289, 3.226, 1.405]) == (1.405, 2.289)
        assert candidate([5.359, 3.637, 6.71, 5.559, 6.655]) == (6.655, 6.71)
        assert candidate([6.018, 3.681, 9.699, 4.695, 2.75]) == (2.75, 3.681)
        assert candidate([6.24, 5.278, 6.461, 4.531, 3.086, 3.952]) == (6.24, 6.461)
        assert candidate([2.409, 5.139, 3.874, 6.67, 1.106]) == (3.874, 5.139)
        assert candidate([3.851, 1.824, 8.417, 5.906, 3.636, 7.245]) == (3.636, 3.851)
        assert candidate([4.84, 6.872, 4.811, 6.062, 9.992, 1.229]) == (4.811, 4.84)
        assert candidate([2.909, 1.804, 2.091, 6.56, 1.804, 1.317]) == (1.804, 1.804)
        assert candidate([4.684, 1.291, 6.624, 7.021, 4.234]) == (6.624, 7.021)
        assert candidate([5.508, 7.684, 2.845, 8.601, 5.973]) == (5.508, 5.973)
        assert candidate([5.751, 7.791, 7.706, 9.224, 4.141, 3.511]) == (7.706, 7.791)
        assert candidate([6.04, 2.605, 5.636, 2.488, 2.464]) == (2.464, 2.488)
        assert candidate([1.939, 3.796, 8.864, 1.91, 4.997, 1.083]) == (1.91, 1.939)
        assert candidate([4.846, 5.266, 1.694, 4.9, 2.532]) == (4.846, 4.9)
        assert candidate([4.259, 1.581, 7.663, 8.805, 6.09]) == (7.663, 8.805)
        assert candidate([4.466, 5.158, 2.579, 6.165, 2.506]) == (2.506, 2.579)
        assert candidate([2.738, 4.255, 2.797, 5.502, 4.96, 1.763]) == (2.738, 2.797)
        assert candidate([1.42, 5.997, 2.369, 3.775, 2.189]) == (2.189, 2.369)
        assert candidate([3.986, 5.241, 4.771, 9.313, 2.081, 4.192]) == (3.986, 4.192)
        assert candidate([6.173, 5.936, 1.726, 2.43, 6.691, 3.497]) == (5.936, 6.173)
        assert candidate([3.328, 3.637, 1.28, 2.154, 1.604, 2.649]) == (3.328, 3.637)
        assert candidate([1.0, 2.0, 3.9, 4.0, 5.0, 2.2]) == (3.9, 4.0)
        assert candidate([2.651, 7.485, 7.842, 8.402, 3.653]) == (7.485, 7.842)
        assert candidate([2.03, 2.964, 6.733, 2.896, 6.259]) == (2.896, 2.964)
        assert candidate([4.419, 7.367, 1.304, 6.596, 1.457]) == (1.304, 1.457)
        assert candidate([6.549, 5.576, 1.734, 5.487, 10.576, 4.603]) == (5.487, 5.576)
        assert candidate([2.123, 7.816, 7.076, 3.267, 1.127, 6.14]) == (7.076, 7.816)
        assert candidate([3.188, 2.948, 1.127, 2.701, 4.923]) == (2.948, 3.188)
        assert candidate([5.791, 5.048, 2.941, 6.309, 4.976, 3.933]) == (4.976, 5.048)
        assert candidate([3.129, 5.724, 3.991, 5.781, 9.477, 2.189]) == (5.724, 5.781)
        assert candidate([4.826, 2.942, 3.366, 8.937, 5.509]) == (2.942, 3.366)
        assert candidate([5.656, 4.706, 6.049, 4.432, 10.071, 6.621]) == (4.432, 4.706)
        assert candidate([5.96, 6.282, 7.125, 3.733, 5.066]) == (5.96, 6.282)
        assert candidate([1.432, 4.03, 4.335, 4.673, 7.481, 1.211]) == (1.211, 1.432)
        assert candidate([5.324, 7.792, 5.351, 2.783, 1.186]) == (5.324, 5.351)
        assert candidate([5.682, 3.588, 6.756, 2.2, 6.169, 7.427]) == (5.682, 6.169)
        assert candidate([6.296, 2.382, 8.904, 7.696, 1.686, 6.854]) == (6.296, 6.854)
        assert candidate([6.716, 6.469, 6.587, 9.729, 8.598, 6.662]) == (6.662, 6.716)

if __name__ == '__main__':
    unittest.main()
