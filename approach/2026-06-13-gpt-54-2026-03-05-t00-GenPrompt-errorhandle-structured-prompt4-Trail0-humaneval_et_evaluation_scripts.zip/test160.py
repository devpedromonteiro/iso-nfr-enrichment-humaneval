
import unittest


def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and
    the second list is a list of integers. Use the two given lists to build the algebraic
    expression and return the evaluation of this expression.

    Supported operators:
        +, -, *, //, **

    Reliability / error-handling behavior:
        - validates input types and sizes explicitly
        - raises specific exceptions for invalid arguments
        - does not silently swallow runtime errors such as division by zero
    """
    supported_operators = {"+", "-", "*", "//", "**"}

    if not isinstance(operator, list):
        raise TypeError("operator must be a list")
    if not isinstance(operand, list):
        raise TypeError("operand must be a list")

    if len(operator) < 1:
        raise ValueError("operator list must contain at least one operator")
    if len(operand) < 2:
        raise ValueError("operand list must contain at least two operands")
    if len(operator) != len(operand) - 1:
        raise ValueError("length of operator must be equal to length of operand minus one")

    for op in operator:
        if not isinstance(op, str):
            raise TypeError("each operator must be a string")
        if op not in supported_operators:
            raise ValueError(f"unsupported operator: {op}")

    for value in operand:
        if not isinstance(value, int):
            raise TypeError("each operand must be an integer")
        if value < 0:
            raise ValueError("operands must be non-negative integers")

    expression = [operand[0]]
    for i, op in enumerate(operator):
        expression.append(op)
        expression.append(operand[i + 1])

    precedence = {"**": 3, "*": 2, "//": 2, "+": 1, "-": 1}
    values = []
    ops = []

    def apply_top_operator():
        if len(values) < 2:
            raise ValueError("invalid expression: insufficient operands")
        if not ops:
            raise ValueError("invalid expression: missing operator")

        right = values.pop()
        left = values.pop()
        op = ops.pop()

        if op == "+":
            values.append(left + right)
        elif op == "-":
            values.append(left - right)
        elif op == "*":
            values.append(left * right)
        elif op == "//":
            if right == 0:
                raise ZeroDivisionError("floor division by zero")
            values.append(left // right)
        elif op == "**":
            values.append(left ** right)
        else:
            raise ValueError(f"unsupported operator encountered during evaluation: {op}")

    try:
        values.append(expression[0])

        i = 1
        while i < len(expression):
            op = expression[i]
            val = expression[i + 1]

            while ops and (
                precedence[ops[-1]] > precedence[op]
                or (precedence[ops[-1]] == precedence[op] and op != "**")
            ):
                apply_top_operator()

            ops.append(op)
            values.append(val)
            i += 2

        while ops:
            apply_top_operator()

        if len(values) != 1:
            raise ValueError("invalid expression: evaluation did not resolve to a single result")

        return values[0]

    except (TypeError, ValueError, ZeroDivisionError, OverflowError):
        # Re-raise specific exceptions without swallowing them.
        raise
candidate = do_algebra


class Test(unittest.TestCase):
    def test(self):
        assert candidate(['**', '//', '-'], [5, 6, 6, 1]) == 2603
        assert candidate(['**', '-', '-'], [7, 1, 4, 9]) == -6
        assert candidate(['+', '**', '*'], [6, 2, 1, 1]) == 8
        assert candidate(['+', '+', '+'], [1, 4, 9, 9]) == 23
        assert candidate(['//', '-', '-'], [3, 3, 3, 6]) == -8
        assert candidate(['-', '*', '-'], [1, 1, 2, 3]) == -4
        assert candidate(['//', '-', '*'], [7, 2, 7, 5]) == -32
        assert candidate(['//', '*', '+'], [3, 5, 2, 3]) == 3
        assert candidate(['//', '**', '+'], [3, 7, 9, 3]) == 3
        assert candidate(['*', '//', '//'], [5, 2, 7, 9]) == 0
        assert candidate(['-', '//', '-'], [6, 8, 1, 10]) == -12
        assert candidate(['//', '**', '-'], [3, 7, 7, 1]) == -1
        assert candidate(['**', '*', '+'], [2, 3, 4, 5]) == 37
        assert candidate(['//', '//'], [8, 8, 7]) == 0
        assert candidate(['//', '//', '*'], [2, 1, 7, 6]) == 0
        assert candidate(['//', '//', '+'], [5, 2, 8, 2]) == 2
        assert candidate(['*', '+', '+'], [3, 2, 6, 5]) == 17
        assert candidate(['*', '**'], [5, 1, 6]) == 5
        assert candidate(['-', '+', '**'], [5, 3, 5, 6]) == 15627
        assert candidate(['-', '**', '//'], [1, 8, 3, 3]) == -169
        assert candidate(['**', '+', '-'], [3, 8, 1, 2]) == 6560
        assert candidate(['**', '//'], [12, 1, 6]) == 2
        assert candidate(['*', '+', '-'], [2, 2, 9, 6]) == 7
        assert candidate(['*', '+'], [2, 5, 7]) == 17
        assert candidate(['**', '*'], [2, 3, 1]) == 8
        assert candidate(['**', '//'], [7, 8, 8]) == 720600
        assert candidate(['-', '+', '-'], [3, 5, 9, 7]) == 0
        assert candidate(['**', '+'], [8, 4, 1]) == 4097
        assert candidate(['**', '*', '+'], [5, 2, 1, 9]) == 34
        assert candidate(['//', '-', '*'], [5, 4, 7, 1]) == -6
        assert candidate(['-', '**'], [6, 2, 2]) == 2
        assert candidate(['*', '+', '+'], [6, 3, 5, 5]) == 28
        assert candidate(['-', '**'], [8, 2, 7]) == -120
        assert candidate(['//', '**'], [4, 4, 4]) == 0
        assert candidate(['-', '//'], [5, 3, 8]) == 5
        assert candidate(['//', '**', '-'], [7, 2, 9, 3]) == -3
        assert candidate(['**', '-', '//'], [6, 1, 6, 7]) == 6
        assert candidate(['*', '//', '-'], [7, 1, 5, 10]) == -9
        assert candidate(['//', '*', '**'], [7, 6, 2, 1]) == 2
        assert candidate(['*', '*', '-'], [7, 8, 1, 9]) == 47
        assert candidate(['**', '+'], [8, 2, 7]) == 71
        assert candidate(['**', '//'], [9, 5, 9]) == 6561
        assert candidate(['**', '-', '*'], [5, 1, 2, 3]) == -1
        assert candidate(['*', '//', '+'], [7, 1, 8, 9]) == 9
        assert candidate(['//', '//', '+'], [2, 5, 8, 8]) == 8
        assert candidate(['*', '-', '+'], [6, 7, 4, 4]) == 42
        assert candidate(['-', '**', '-'], [7, 4, 1, 8]) == -5
        assert candidate(['+', '**', '+'], [4, 2, 7, 1]) == 133
        assert candidate(['*', '+'], [9, 3, 8]) == 35
        assert candidate(['*', '-', '//'], [4, 4, 2, 6]) == 16
        assert candidate(['*', '//', '//'], [7, 7, 6, 6]) == 1
        assert candidate(['**', '//', '//'], [1, 7, 6, 2]) == 0
        assert candidate(['*', '-', '**'], [2, 7, 7, 1]) == 7
        assert candidate(['+', '*', '**'], [6, 8, 1, 2]) == 14
        assert candidate(['**', '//', '+'], [5, 8, 3, 3]) == 130211
        assert candidate(['*', '-'], [6, 5, 7]) == 23
        assert candidate(['*', '*', '+'], [1, 3, 2, 9]) == 15
        assert candidate(['-', '*'], [3, 3, 6]) == -15
        assert candidate(['//', '-', '**'], [4, 8, 2, 2]) == -4
        assert candidate(['-', '**', '-'], [4, 5, 5, 9]) == -3130
        assert candidate(['**', '+', '*'], [1, 5, 5, 1]) == 6
        assert candidate(['-', '**'], [3, 5, 2]) == -22
        assert candidate(['+', '*'], [7, 3, 6]) == 25
        assert candidate(['*', '-', '**'], [5, 5, 2, 8]) == -231
        assert candidate(['+', '-', '**'], [6, 8, 4, 10]) == -1048562
        assert candidate(['+', '//', '*'], [7, 3, 7, 1]) == 7
        assert candidate(['**', '-', '//'], [7, 8, 1, 10]) == 5764801
        assert candidate(['//', '//', '+'], [1, 2, 8, 10]) == 10
        assert candidate(['*', '*', '-'], [3, 4, 1, 4]) == 8
        assert candidate(['//', '+', '**'], [7, 1, 5, 1]) == 12
        assert candidate(['*', '**'], [3, 2, 8]) == 768
        assert candidate(['*', '**'], [7, 3, 3]) == 189
        assert candidate(['+', '**', '-'], [5, 2, 5, 9]) == 28
        assert candidate(['-', '**', '*'], [5, 2, 7, 8]) == -1019
        assert candidate(['-', '+'], [8, 4, 3]) == 7
        assert candidate(['+', '-', '//'], [5, 4, 6, 2]) == 6
        assert candidate(['//', '+', '//'], [5, 1, 9, 4]) == 7
        assert candidate(['*', '**', '+'], [7, 1, 5, 1]) == 8
        assert candidate(['*', '+', '//'], [4, 6, 7, 10]) == 24
        assert candidate(['+', '*', '-'], [2, 3, 4, 5]) == 9
        assert candidate(['**', '*'], [8, 2, 2]) == 128
        assert candidate(['**', '-', '*'], [6, 4, 5, 1]) == 1291
        assert candidate(['-', '+'], [3, 4, 4]) == 3
        assert candidate(['+', '-'], [10, 3, 8]) == 5
        assert candidate(['//', '*'], [7, 3, 4]) == 8
        assert candidate(['//', '-'], [6, 1, 2]) == 4
        assert candidate(['**', '+'], [10, 3, 5]) == 1005
        assert candidate(['+', '-'], [3, 7, 6]) == 4
        assert candidate(['**', '//'], [9, 5, 2]) == 29524
        assert candidate(['*', '*'], [5, 2, 7]) == 70
        assert candidate(['*', '+', '**'], [5, 5, 2, 9]) == 537
        assert candidate(['-', '**'], [3, 3, 4]) == -78
        assert candidate(['**', '*', '*'], [7, 2, 4, 7]) == 1372
        assert candidate(['**', '*', '-'], [7, 6, 4, 6]) == 470590
        assert candidate(['//', '//'], [2, 7, 1]) == 0
        assert candidate(['+', '**', '+'], [6, 6, 4, 7]) == 1309
        assert candidate(['**', '*'], [10, 2, 8]) == 800
        assert candidate(['+', '//'], [3, 6, 4]) == 4
        assert candidate(['**', '+', '-'], [1, 5, 1, 1]) == 1
        assert candidate(['+', '-', '*'], [6, 8, 6, 1]) == 8
        assert candidate(['+', '**'], [7, 3, 5]) == 250
        assert candidate(['-', '//'], [7, 3, 2]) == 6
        assert candidate(['//', '+', '*'], [2, 6, 4, 4]) == 16
        assert candidate(['//', '//', '**'], [7, 1, 9, 1]) == 0
        assert candidate(['+', '*', '//'], [6, 5, 1, 3]) == 7
        assert candidate(['+', '**'], [3, 2, 4]) == 19
        assert candidate(['-', '*', '-'], [2, 7, 3, 9]) == -28
        assert candidate(['*', '*', '-'], [2, 1, 8, 4]) == 12
        assert candidate(['+', '**'], [7, 6, 6]) == 46663
        assert candidate(['**', '-', '-'], [1, 7, 7, 10]) == -16
        assert candidate(['**', '//', '//'], [1, 7, 4, 8]) == 0
        assert candidate(['-', '*', '*'], [7, 4, 7, 8]) == -217
        assert candidate(['**', '-'], [3, 2, 9]) == 0
        assert candidate(['-', '+', '**'], [5, 4, 2, 3]) == 9
        assert candidate(['+', '+'], [4, 4, 1]) == 9
        assert candidate(['-', '+'], [10, 7, 1]) == 4
        assert candidate(['-', '+', '*'], [5, 5, 4, 8]) == 32
        assert candidate(['//', '//', '*'], [4, 8, 9, 6]) == 0
        assert candidate(['+', '**', '-'], [1, 1, 9, 4]) == -2
        assert candidate(['+', '//', '+'], [5, 8, 2, 1]) == 10
        assert candidate(['-', '//', '**'], [4, 5, 8, 3]) == 4
        assert candidate(['+', '//', '*'], [5, 4, 8, 10]) == 5
        assert candidate(['**', '-', '+'], [2, 1, 7, 9]) == 4
        assert candidate(['//', '*'], [8, 4, 2]) == 4
        assert candidate(['//', '-', '*'], [4, 3, 3, 1]) == -2
        assert candidate(['-', '+', '+'], [1, 1, 9, 9]) == 18
        assert candidate(['-', '+', '**'], [1, 4, 2, 7]) == 125
        assert candidate(['*', '+'], [4, 8, 4]) == 36
        assert candidate(['*', '//', '*'], [7, 3, 1, 10]) == 210

if __name__ == '__main__':
    unittest.main()
