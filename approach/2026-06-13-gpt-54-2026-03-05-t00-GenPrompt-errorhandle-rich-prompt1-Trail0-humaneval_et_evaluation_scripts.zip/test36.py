
import unittest



def fizz_buzz(n: int):
    """Return the number of times the digit 7 appears in integers less than n
    which are divisible by 11 or 13.

    >>> fizz_buzz(50)
    0
    >>> fizz_buzz(78)
    2
    >>> fizz_buzz(79)
    3
    """
    if isinstance(n, bool):
        raise TypeError("n must be an integer, not bool")
    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if n < 0:
        raise ValueError("n must be non-negative")

    try:
        count = 0
        for i in range(n):
            if i % 11 == 0 or i % 13 == 0:
                count += str(i).count("7")
        return count
    except (TypeError, ValueError):
        raise
    except Exception as exc:
        raise RuntimeError("unexpected error while computing fizz_buzz") from exc
candidate = fizz_buzz


class Test(unittest.TestCase):
    def test(self):
        assert candidate(74) == 0
        assert candidate(99862) == 8022
        assert candidate(203) == 6
        assert candidate(99955) == 8023
        assert candidate(100495) == 8043
        assert candidate(205) == 6
        assert candidate(46) == 0
        assert candidate(76) == 0
        assert candidate(104) == 3
        assert candidate(78) == 2
        assert candidate(99) == 3
        assert candidate(52) == 0
        assert candidate(99834) == 8021
        assert candidate(105) == 3
        assert candidate(99673) == 8000
        assert candidate(100884) == 8071
        assert candidate(3223) == 149
        assert candidate(99181) == 7985
        assert candidate(47) == 0
        assert candidate(4073) == 195
        assert candidate(73) == 0
        assert candidate(50) == 0
        assert candidate(80) == 3
        assert candidate(82) == 3
        assert candidate(100564) == 8044
        assert candidate(3806) == 185
        assert candidate(79) == 3
        assert candidate(4072) == 195
        assert candidate(3009) == 144
        assert candidate(10837) == 681
        assert candidate(48) == 0
        assert candidate(83) == 3
        assert candidate(9675) == 614
        assert candidate(196) == 6
        assert candidate(3539) == 160
        assert candidate(103) == 3
        assert candidate(100282) == 8035
        assert candidate(99091) == 7982
        assert candidate(4194) == 197
        assert candidate(202) == 6
        assert candidate(4068) == 194
        assert candidate(200) == 6
        assert candidate(10844) == 681
        assert candidate(10985) == 687
        assert candidate(102) == 3
        assert candidate(49) == 0
        assert candidate(98) == 3
        assert candidate(100) == 3
        assert candidate(10450) == 654
        assert candidate(9647) == 612
        assert candidate(84) == 3
        assert candidate(77) == 0
        assert candidate(81) == 3
        assert candidate(10000) == 639
        assert candidate(99293) == 7987
        assert candidate(195) == 6
        assert candidate(10498) == 656
        assert candidate(201) == 6
        assert candidate(96) == 3
        assert candidate(9690) == 614
        assert candidate(9704) == 615
        assert candidate(198) == 6
        assert candidate(55) == 0
        assert candidate(10925) == 684
        assert candidate(4229) == 197
        assert candidate(51) == 0
        assert candidate(3077) == 145
        assert candidate(75) == 0
        assert candidate(9032) == 592
        assert candidate(197) == 6
        assert candidate(3712) == 168
        assert candidate(9282) == 601
        assert candidate(9367) == 603
        assert candidate(100000) == 8026
        assert candidate(100606) == 8045
        assert candidate(99579) == 7998
        assert candidate(10231) == 646
        assert candidate(9470) == 606
        assert candidate(54) == 0
        assert candidate(53) == 0
        assert candidate(3584) == 161
        assert candidate(4144) == 195
        assert candidate(4000) == 192
        assert candidate(3551) == 160
        assert candidate(4977) == 238
        assert candidate(99273) == 7986
        assert candidate(100563) == 8044

if __name__ == '__main__':
    unittest.main()
