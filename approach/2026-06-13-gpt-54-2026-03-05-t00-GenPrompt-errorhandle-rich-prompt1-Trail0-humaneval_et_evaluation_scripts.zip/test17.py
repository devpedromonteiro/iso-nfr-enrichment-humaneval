
import unittest

from typing import List


from typing import List


def parse_music(music_string: str) -> List[int]:
    """Input to this function is a string representing musical notes in a special ASCII format.
    Your task is to parse this string and return list of integers corresponding to how many beats each
    note lasts.

    Legend:
    'o'  - whole note, lasts four beats
    'o|' - half note, lasts two beats
    '.|' - quarter note, lasts one beat

    >>> parse_music('o o| .| o| o| .| .| .| .| o o')
    [4, 2, 1, 2, 2, 1, 1, 1, 1, 4, 4]
    """
    if not isinstance(music_string, str):
        raise TypeError(
            f"music_string must be of type str, got {type(music_string).__name__}"
        )

    if not music_string.strip():
        return []

    note_to_beats = {
        "o": 4,
        "o|": 2,
        ".|": 1,
    }

    tokens = music_string.split()
    beats: List[int] = []

    for index, token in enumerate(tokens):
        try:
            beats.append(note_to_beats[token])
        except KeyError as exc:
            raise ValueError(
                f"Invalid note token at position {index}: {token!r}. "
                f"Expected one of {sorted(note_to_beats.keys())}."
            ) from exc

    return beats
candidate = parse_music


class Test(unittest.TestCase):
    def test(self):
        assert candidate(".| o .| o o o o| o| o| .| o o o .| .|") == [1, 4, 1, 4, 4, 4, 2, 2, 2, 1, 4, 4, 4, 1, 1]
        assert candidate(".| o o| o| o .| .| .| o .| o o| o| .| o| o o| o| .|") == [1, 4, 2, 2, 4, 1, 1, 1, 4, 1, 4, 2, 2, 1, 2, 4, 2, 2, 1]
        assert candidate("o| o o| .| .| .| .| o| o| .| o o| o| o| .| .| o|") == [2, 4, 2, 1, 1, 1, 1, 2, 2, 1, 4, 2, 2, 2, 1, 1, 2]
        assert candidate("o .| o .| o o o| o| o| o| o o .| o|") == [4, 1, 4, 1, 4, 4, 2, 2, 2, 2, 4, 4, 1, 2]
        assert candidate("o| o| o| o o o .| .| o o| o| o o| o o| o|") == [2, 2, 2, 4, 4, 4, 1, 1, 4, 2, 2, 4, 2, 4, 2, 2]
        assert candidate("o o| o .| o o| .| o| .| .| o o| o| o o| o| .|") == [4, 2, 4, 1, 4, 2, 1, 2, 1, 1, 4, 2, 2, 4, 2, 2, 1]
        assert candidate("o| .| .| o| o o o o o|") == [2, 1, 1, 2, 4, 4, 4, 4, 2]
        assert candidate("o o| o o o| .| o| o .|") == [4, 2, 4, 4, 2, 1, 2, 4, 1]
        assert candidate("o| o") == [2, 4]
        assert candidate("o o o| .| o| .| .| .| o| o o") == [4, 4, 2, 1, 2, 1, 1, 1, 2, 4, 4]
        assert candidate('o| o| .| .| o o o o') == [2, 2, 1, 1, 4, 4, 4, 4]
        assert candidate("o o o") == [4, 4, 4]
        assert candidate("o .| o| o| .| o .| o| .| o|") == [4, 1, 2, 2, 1, 4, 1, 2, 1, 2]
        assert candidate(".| .| o o| .| o .| o| o o| o o| o| .| o| o .|") == [1, 1, 4, 2, 1, 4, 1, 2, 4, 2, 4, 2, 2, 1, 2, 4, 1]
        assert candidate("o") == [4]
        assert candidate("o| .| o o| .| .| o .| o .| o .| .| o o .|") == [2, 1, 4, 2, 1, 1, 4, 1, 4, 1, 4, 1, 1, 4, 4, 1]
        assert candidate(".| o| .| o| o .| o| o| .| o| o| o| .| o|") == [1, 2, 1, 2, 4, 1, 2, 2, 1, 2, 2, 2, 1, 2]
        assert candidate(".| .|") == [1, 1]
        assert candidate(".| .| o .| o| o o| o o| o .| .| o o o .| o") == [1, 1, 4, 1, 2, 4, 2, 4, 2, 4, 1, 1, 4, 4, 4, 1, 4]
        assert candidate("o o .| o| o o o o o o| o o| .| o") == [4, 4, 1, 2, 4, 4, 4, 4, 4, 2, 4, 2, 1, 4]
        assert candidate(".| o o| .| .|") == [1, 4, 2, 1, 1]
        assert candidate(".| o o| o| .| o .| .| o") == [1, 4, 2, 2, 1, 4, 1, 1, 4]
        assert candidate("o| o o| .| .| o o o| .| o .| o| o") == [2, 4, 2, 1, 1, 4, 4, 2, 1, 4, 1, 2, 4]
        assert candidate("o| o o| o| .| .| .| .| o|") == [2, 4, 2, 2, 1, 1, 1, 1, 2]
        assert candidate("o|") == [2]
        assert candidate("o| o o o o o o .| o| o| o") == [2, 4, 4, 4, 4, 4, 4, 1, 2, 2, 4]
        assert candidate("o| o| o| o o o o o| .|") == [2, 2, 2, 4, 4, 4, 4, 2, 1]
        assert candidate('o| .| o| .| o o| o o|') == [2, 1, 2, 1, 4, 2, 4, 2]
        assert candidate("o| o| .| .| o| .| o| o o| .| o| o| o|") == [2, 2, 1, 1, 2, 1, 2, 4, 2, 1, 2, 2, 2]
        assert candidate("o| .| .| o .| o") == [2, 1, 1, 4, 1, 4]
        assert candidate("o o o .| o| o| o") == [4, 4, 4, 1, 2, 2, 4]
        assert candidate("o| .| o| .| o| o| o| .| o| .| o| o| o| o .| o o| o|") == [2, 1, 2, 1, 2, 2, 2, 1, 2, 1, 2, 2, 2, 4, 1, 4, 2, 2]
        assert candidate("o| o| o o| o| o o| o| .| .| o o .| .| o o o .|") == [2, 2, 4, 2, 2, 4, 2, 2, 1, 1, 4, 4, 1, 1, 4, 4, 4, 1]
        assert candidate(".| o| .| o o .| .| o o| o| o o| .| .| .|") == [1, 2, 1, 4, 4, 1, 1, 4, 2, 2, 4, 2, 1, 1, 1]
        assert candidate(".|") == [1]
        assert candidate("o| .| o| o| o| o| o .|") == [2, 1, 2, 2, 2, 2, 4, 1]
        assert candidate(".| .| o o .| o|") == [1, 1, 4, 4, 1, 2]
        assert candidate("o o o .| o o| o| o .| o o o .| o o| o o") == [4, 4, 4, 1, 4, 2, 2, 4, 1, 4, 4, 4, 1, 4, 2, 4, 4]
        assert candidate(".| o") == [1, 4]
        assert candidate("o| .| o| o| o| o| o| o| o| .| o| o| o .| o o| .| o o|") == [2, 1, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 4, 1, 4, 2, 1, 4, 2]
        assert candidate("o o o| o") == [4, 4, 2, 4]
        assert candidate("o| o .| o| o| o| o .| .| o| .| o| .|") == [2, 4, 1, 2, 2, 2, 4, 1, 1, 2, 1, 2, 1]
        assert candidate("o o o o| o| o o| o") == [4, 4, 4, 2, 2, 4, 2, 4]
        assert candidate("o| .| o| o o o| o o o| o .| .| .| o .|") == [2, 1, 2, 4, 4, 2, 4, 4, 2, 4, 1, 1, 1, 4, 1]
        assert candidate(".| .| o| o| o o o| o| o o| o o .| .| o o o") == [1, 1, 2, 2, 4, 4, 2, 2, 4, 2, 4, 4, 1, 1, 4, 4, 4]
        assert candidate(".| o| o .| o|") == [1, 2, 4, 1, 2]
        assert candidate("o| o .| o o| .|") == [2, 4, 1, 4, 2, 1]
        assert candidate(".| o .| o .| o| .| o .| o|") == [1, 4, 1, 4, 1, 2, 1, 4, 1, 2]
        assert candidate("o| o| o|") == [2, 2, 2]
        assert candidate(".| o| o .| .|") == [1, 2, 4, 1, 1]
        assert candidate("o| .| .| .| .|") == [2, 1, 1, 1, 1]
        assert candidate("o o| o o .| o| o|") == [4, 2, 4, 4, 1, 2, 2]
        assert candidate(".| o| o o .| .| .| o .| o| .| .| .| o| o| o o .| .|") == [1, 2, 4, 4, 1, 1, 1, 4, 1, 2, 1, 1, 1, 2, 2, 4, 4, 1, 1]
        assert candidate(".| .| o| o o o .| o|") == [1, 1, 2, 4, 4, 4, 1, 2]
        assert candidate("o| .| o| o| .| o| o| o .| .| .| o| o o| .| o .| .|") == [2, 1, 2, 2, 1, 2, 2, 4, 1, 1, 1, 2, 4, 2, 1, 4, 1, 1]
        assert candidate("o .| .| o .| o| .| o|") == [4, 1, 1, 4, 1, 2, 1, 2]
        assert candidate("o .| .|") == [4, 1, 1]
        assert candidate("o| .| o| o") == [2, 1, 2, 4]
        assert candidate(".| o .| o o| .| o o o|") == [1, 4, 1, 4, 2, 1, 4, 4, 2]
        assert candidate(".| .| o| .| .| o| o| .| o| o o| .| .| .|") == [1, 1, 2, 1, 1, 2, 2, 1, 2, 4, 2, 1, 1, 1]
        assert candidate(".| o| o|") == [1, 2, 2]
        assert candidate("o .| o o| .| o| .| o o| .| o") == [4, 1, 4, 2, 1, 2, 1, 4, 2, 1, 4]
        assert candidate("o o o| o| o| o| o| o| o|") == [4, 4, 2, 2, 2, 2, 2, 2, 2]
        assert candidate(".| o| o| o| o o| o| o| o| o o| .| o") == [1, 2, 2, 2, 4, 2, 2, 2, 2, 4, 2, 1, 4]
        assert candidate("o .|") == [4, 1]
        assert candidate(".| .| o .| o| .| o .| o| o o| o|") == [1, 1, 4, 1, 2, 1, 4, 1, 2, 4, 2, 2]
        assert candidate("o .| o o .| o o| o| o o .|") == [4, 1, 4, 4, 1, 4, 2, 2, 4, 4, 1]
        assert candidate("o| o .| .| o .| o o| .| o o| o| o") == [2, 4, 1, 1, 4, 1, 4, 2, 1, 4, 2, 2, 4]
        assert candidate("o o| .| .| o| .| .| .|") == [4, 2, 1, 1, 2, 1, 1, 1]
        assert candidate("o o| .| .|") == [4, 2, 1, 1]
        assert candidate(".| o| o o .| o|") == [1, 2, 4, 4, 1, 2]
        assert candidate('.| .| .| .|') == [1, 1, 1, 1]
        assert candidate(".| .| .| o| .| o| .| o o| o") == [1, 1, 1, 2, 1, 2, 1, 4, 2, 4]
        assert candidate("o| o| o| o .| o o| o|") == [2, 2, 2, 4, 1, 4, 2, 2]
        assert candidate(".| .| .| o .| .| o| o o .| o| o o .| o| o| .|") == [1, 1, 1, 4, 1, 1, 2, 4, 4, 1, 2, 4, 4, 1, 2, 2, 1]
        assert candidate(".| o| o") == [1, 2, 4]
        assert candidate("o| o| .| o .|") == [2, 2, 1, 4, 1]
        assert candidate(".| .| o o| .| o o .| o| o .| o o| .| o o| o o| o o") == [1, 1, 4, 2, 1, 4, 4, 1, 2, 4, 1, 4, 2, 1, 4, 2, 4, 2, 4, 4]
        assert candidate("o .| o|") == [4, 1, 2]
        assert candidate(".| o o| o") == [1, 4, 2, 4]
        assert candidate("o| .| o| .| o o o| .|") == [2, 1, 2, 1, 4, 4, 2, 1]
        assert candidate('o o o o') == [4, 4, 4, 4]
        assert candidate("o| .| o o| .| o .| o o .| o| .| o| o| .|") == [2, 1, 4, 2, 1, 4, 1, 4, 4, 1, 2, 1, 2, 2, 1]
        assert candidate(".| o| .| o| o| .| o .| o") == [1, 2, 1, 2, 2, 1, 4, 1, 4]
        assert candidate('') == []
        assert candidate(".| o o o .|") == [1, 4, 4, 4, 1]
        assert candidate(".| .| o| .| o|") == [1, 1, 2, 1, 2]
        assert candidate("o o o .| o|") == [4, 4, 4, 1, 2]
        assert candidate(".| .| o o| o| .| o .| .| o .| .| .| o|") == [1, 1, 4, 2, 2, 1, 4, 1, 1, 4, 1, 1, 1, 2]
        assert candidate("o o .|") == [4, 4, 1]
        assert candidate(".| o o o o o o o o| .| o o .| o o| o|") == [1, 4, 4, 4, 4, 4, 4, 4, 2, 1, 4, 4, 1, 4, 2, 2]
        assert candidate("o| o .| o|") == [2, 4, 1, 2]
        assert candidate(".| .| o o| o o o o o| .| .| o| .| .| o| .| o| .| o|") == [1, 1, 4, 2, 4, 4, 4, 4, 2, 1, 1, 2, 1, 1, 2, 1, 2, 1, 2]
        assert candidate("o o .| o| o o o o| .| o o o o| o .|") == [4, 4, 1, 2, 4, 4, 4, 2, 1, 4, 4, 4, 2, 4, 1]
        assert candidate("o o o o| o o|") == [4, 4, 4, 2, 4, 2]
        assert candidate("o .| o o| o o o o o| .| o o o| .|") == [4, 1, 4, 2, 4, 4, 4, 4, 2, 1, 4, 4, 2, 1]
        assert candidate(".| o| o o o| o o|") == [1, 2, 4, 4, 2, 4, 2]
        assert candidate("o o| o| .|") == [4, 2, 2, 1]
        assert candidate(".| o| o| .| o o| o o| o o .| o| o| o| o o .|") == [1, 2, 2, 1, 4, 2, 4, 2, 4, 4, 1, 2, 2, 2, 4, 4, 1]
        assert candidate(".| o| .| o .| o| o o .| o| o| o o .| o o .|") == [1, 2, 1, 4, 1, 2, 4, 4, 1, 2, 2, 4, 4, 1, 4, 4, 1]
        assert candidate(".| o| o o| o") == [1, 2, 4, 2, 4]
        assert candidate("o| o| o .| o| o o o| o o .|") == [2, 2, 4, 1, 2, 4, 4, 2, 4, 4, 1]
        assert candidate(".| o o| .| o o o o| o .| o") == [1, 4, 2, 1, 4, 4, 4, 2, 4, 1, 4]
        assert candidate(".| o| .| o .| o .| .| o .| o o o .| o o .| .|") == [1, 2, 1, 4, 1, 4, 1, 1, 4, 1, 4, 4, 4, 1, 4, 4, 1, 1]
        assert candidate("o .| o| o|") == [4, 1, 2, 2]
        assert candidate(".| o| o| .| o") == [1, 2, 2, 1, 4]
        assert candidate("o| o o| o") == [2, 4, 2, 4]
        assert candidate("o o o o o o| .| o| o .| o o|") == [4, 4, 4, 4, 4, 2, 1, 2, 4, 1, 4, 2]
        assert candidate(".| o| o o|") == [1, 2, 4, 2]
        assert candidate("o| o o|") == [2, 4, 2]
        assert candidate("o o|") == [4, 2]
        assert candidate("o .| .| o") == [4, 1, 1, 4]
        assert candidate(".| .| .| .| o| .| .| o o .| o| o .|") == [1, 1, 1, 1, 2, 1, 1, 4, 4, 1, 2, 4, 1]
        assert candidate("o o o o| o| .| o o| o o .| o .| o|") == [4, 4, 4, 2, 2, 1, 4, 2, 4, 4, 1, 4, 1, 2]
        assert candidate("o o| o| .| .| o| o|") == [4, 2, 2, 1, 1, 2, 2]
        assert candidate(".| o| .| .| .| o .| o| o| o o .| o") == [1, 2, 1, 1, 1, 4, 1, 2, 2, 4, 4, 1, 4]
        assert candidate("o o o .| o o| o| o o .| o| o| o| o") == [4, 4, 4, 1, 4, 2, 2, 4, 4, 1, 2, 2, 2, 4]
        assert candidate("o| .| o| o| .| o| .| o .| .| .| .| o o o| o") == [2, 1, 2, 2, 1, 2, 1, 4, 1, 1, 1, 1, 4, 4, 2, 4]
        assert candidate("o o| .| o| o .| o o| o| o o| o o") == [4, 2, 1, 2, 4, 1, 4, 2, 2, 4, 2, 4, 4]
        assert candidate("o| o .| .| o| .| o| o| o") == [2, 4, 1, 1, 2, 1, 2, 2, 4]
        assert candidate("o o o| o o o| o") == [4, 4, 2, 4, 4, 2, 4]
        assert candidate("o o o| .| o") == [4, 4, 2, 1, 4]
        assert candidate("o .| o| o .| .| .| o o| o") == [4, 1, 2, 4, 1, 1, 1, 4, 2, 4]
        assert candidate(".| o| .|") == [1, 2, 1]
        assert candidate("o| o|") == [2, 2]
        assert candidate(".| .| .| o| o| o o .| o o .| o") == [1, 1, 1, 2, 2, 4, 4, 1, 4, 4, 1, 4]
        assert candidate("o| o o .| o o| o| o o| o o .|") == [2, 4, 4, 1, 4, 2, 2, 4, 2, 4, 4, 1]
        assert candidate("o| o| .| o| .| o o o o| o o| o| .| o o o o|") == [2, 2, 1, 2, 1, 4, 4, 4, 2, 4, 2, 2, 1, 4, 4, 4, 2]
        assert candidate("o o .| o") == [4, 4, 1, 4]

if __name__ == '__main__':
    unittest.main()
