
import unittest


def by_length(arr):
    """
    Given an array of integers, sort the integers that are between 1 and 9 inclusive,
    reverse the resulting array, and then replace each digit by its corresponding name from
    "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine".

    For example:
      arr = [2, 1, 1, 4, 5, 8, 2, 3]   
            -> sort arr -> [1, 1, 2, 2, 3, 4, 5, 8] 
            -> reverse arr -> [8, 5, 4, 3, 2, 2, 1, 1]
      return ["Eight", "Five", "Four", "Three", "Two", "Two", "One", "One"]
    
      If the array is empty, return an empty array:
      arr = []
      return []
    
      If the array has any strange number ignore it:
      arr = [1, -1 , 55] 
            -> sort arr -> [-1, 1, 55]
            -> reverse arr -> [55, 1, -1]
      return = ['One']
    """
    names = {
        1: "One",
        2: "Two",
        3: "Three",
        4: "Four",
        5: "Five",
        6: "Six",
        7: "Seven",
        8: "Eight",
        9: "Nine"
    }
    
    valid_numbers = sorted((x for x in arr if 1 <= x <= 9), reverse=True)
    return [names[x] for x in valid_numbers]
candidate = by_length


class Test(unittest.TestCase):
    def test(self):
        assert candidate([4, 3, 1, 6, 3, 5, 7, 1]) == ['Seven', 'Six', 'Five', 'Four', 'Three', 'Three', 'One', 'One']
        assert candidate([5, -5, 8, 5]) == ['Eight', 'Five', 'Five']
        assert candidate([6, 2, 50]) == ['Six', 'Two']
        assert candidate([4, 1, 60]) == ['Four', 'One']
        assert candidate([11, 3, 13]) == ['Three']
        assert candidate([1, -6, 57]) == ['One']
        assert candidate([4, 0, 6, 6]) == ['Six', 'Six', 'Four']
        assert candidate([2, 2, 2, 1, 8, 6, 7, 6]) == ['Eight', 'Seven', 'Six', 'Six', 'Two', 'Two', 'Two', 'One']
        assert candidate([4, -4, 53]) == ['Four']
        assert candidate([5, 4, 6, 3]) == ['Six', 'Five', 'Four', 'Three']
        assert candidate([6, 3, 1, 6, 4, 9, 1, 4]) == ['Nine', 'Six', 'Six', 'Four', 'Four', 'Three', 'One', 'One']
        assert candidate([6, 1, 5, 4]) == ['Six', 'Five', 'Four', 'One']
        assert candidate([4, 4, 7, 6]) == ['Seven', 'Six', 'Four', 'Four']
        assert candidate([5, -3, 51]) == ['Five']
        assert candidate([6, 7, 7]) == ['Seven', 'Seven', 'Six']
        assert candidate([3, 5, 3, 7, 5, 7, 5, 3]) == ['Seven', 'Seven', 'Five', 'Five', 'Five', 'Three', 'Three', 'Three']
        assert candidate([4, 5, 7]) == ['Seven', 'Five', 'Four']
        assert candidate([]) == [], "Error"
        assert candidate([5, 3, 3, 5]) == ['Five', 'Five', 'Three', 'Three']
        assert candidate([3, 1, 6, 9, 8, 3, 6, 3]) == ['Nine', 'Eight', 'Six', 'Six', 'Three', 'Three', 'Three', 'One']
        assert candidate([4, 7, 9]) == ['Nine', 'Seven', 'Four']
        assert candidate([4, 3, 56]) == ['Four', 'Three']
        assert candidate([6, 4, 6, 1, 6, 6, 6, 4]) == ['Six', 'Six', 'Six', 'Six', 'Six', 'Four', 'Four', 'One']
        assert candidate([4, -3, 6, 1]) == ['Six', 'Four', 'One']
        assert candidate([1, 4, 6, 4, 1, 9, 1, 2]) == ['Nine', 'Six', 'Four', 'Four', 'Two', 'One', 'One', 'One']
        assert candidate([4, -2, 50]) == ['Four']
        assert candidate([7, 5, 5, 5, 3, 13, 3, 8]) == ['Eight', 'Seven', 'Five', 'Five', 'Five', 'Three', 'Three']
        assert candidate([3, 4, 50]) == ['Four', 'Three']
        assert candidate([1, 2, 60]) == ['Two', 'One']
        assert candidate([6, -4, 50]) == ['Six']
        assert candidate([6, 3, 1, 7]) == ['Seven', 'Six', 'Three', 'One']
        assert candidate([12, 7, 4]) == ['Seven', 'Four']
        assert candidate([4, 4, 8]) == ['Eight', 'Four', 'Four']
        assert candidate([10, 4, 12]) == ['Four']
        assert candidate([]) == []
        assert candidate([2, 3, 5, 8, 5, 7, 6, 4]) == ['Eight', 'Seven', 'Six', 'Five', 'Five', 'Four', 'Three', 'Two']
        assert candidate([3, -1, 52]) == ['Three']
        assert candidate([5, -5, 51]) == ['Five']
        assert candidate([7, 5, 11]) == ['Seven', 'Five']
        assert candidate([2, 1, 1, 4, 5, 8, 2, 3]) == ["Eight", "Five", "Four", "Three", "Two", "Two", "One", "One"], "Error"
        assert candidate([1, -1 , 55]) == ['One'], "Error"

    # Check some edge cases that are easy to work out by hand.
        assert candidate([4, 3, 54]) == ['Four', 'Three']
        assert candidate([4, -6, 7, 6]) == ['Seven', 'Six', 'Four']
        assert candidate([1, -2, 2, 7]) == ['Seven', 'Two', 'One']
        assert candidate([1, 5, 6, 3, 9, 13, 2, 8]) == ['Nine', 'Eight', 'Six', 'Five', 'Three', 'Two', 'One']
        assert candidate([5, 4, 2, 2]) == ['Five', 'Four', 'Two', 'Two']
        assert candidate([6, -2, 50]) == ['Six']
        assert candidate([4, -1, 3, 3]) == ['Four', 'Three', 'Three']
        assert candidate([5, 5, 1, 2, 5, 6, 1, 1]) == ['Six', 'Five', 'Five', 'Five', 'Two', 'One', 'One', 'One']
        assert candidate([5, 2, 6, 6]) == ['Six', 'Six', 'Five', 'Two']
        assert candidate([3, -1, 8, 5]) == ['Eight', 'Five', 'Three']
        assert candidate([4, 3, 12]) == ['Four', 'Three']
        assert candidate([6, 5, 3, 9, 7, 12, 3, 2]) == ['Nine', 'Seven', 'Six', 'Five', 'Three', 'Three', 'Two']
        assert candidate([2, -6, 53]) == ['Two']
        assert candidate([5, 0, 4, 4]) == ['Five', 'Four', 'Four']
        assert candidate([5, -5, 8, 3]) == ['Eight', 'Five', 'Three']
        assert candidate([3, -6, 57]) == ['Three']
        assert candidate([6, 6, 3, 8, 3, 11, 4, 2]) == ['Eight', 'Six', 'Six', 'Four', 'Three', 'Three', 'Two']
        assert candidate([6, 4, 54]) == ['Six', 'Four']
        assert candidate([12, 7, 10]) == ['Seven']
        assert candidate([3, 1, 55]) == ['Three', 'One']
        assert candidate([6, -2, 56]) == ['Six']
        assert candidate([5, 1, 2, 6, 5, 5, 1, 5]) == ['Six', 'Five', 'Five', 'Five', 'Five', 'Two', 'One', 'One']
        assert candidate([12, 8, 11]) == ['Eight']
        assert candidate([4, 3, 10]) == ['Four', 'Three']
        assert candidate([11, 8, 12]) == ['Eight']
        assert candidate([5, 5, 10]) == ['Five', 'Five']
        assert candidate([8, 9, 7]) == ['Nine', 'Eight', 'Seven']
        assert candidate([8, 4, 4]) == ['Eight', 'Four', 'Four']
        assert candidate([1, 5, 2, 6, 6, 9, 5, 1]) == ['Nine', 'Six', 'Six', 'Five', 'Five', 'Two', 'One', 'One']
        assert candidate([4, 2, 51]) == ['Four', 'Two']
        assert candidate([9, 4, 8]) == ["Nine", "Eight", "Four"]
        assert candidate([5, 3, 2, 5]) == ['Five', 'Five', 'Three', 'Two']
        assert candidate([7, 5, 3, 6, 7, 12, 2, 8]) == ['Eight', 'Seven', 'Seven', 'Six', 'Five', 'Three', 'Two']
        assert candidate([2, 1, 50]) == ['Two', 'One']
        assert candidate([2, -3, 8, 1]) == ['Eight', 'Two', 'One']
        assert candidate([1, -1, 3, 2]) == ["Three", "Two", "One"]
        assert candidate([4, -2, 56]) == ['Four']
        assert candidate([6, 4, 4, 2, 7, 8, 6, 2]) == ['Eight', 'Seven', 'Six', 'Six', 'Four', 'Four', 'Two', 'Two']
        assert candidate([2, 1, 3, 6, 9, 12, 4, 7]) == ['Nine', 'Seven', 'Six', 'Four', 'Three', 'Two', 'One']
        assert candidate([4, 5, 6, 5, 4, 4, 4, 6]) == ['Six', 'Six', 'Five', 'Five', 'Four', 'Four', 'Four', 'Four']
        assert candidate([4, 2, 7]) == ['Seven', 'Four', 'Two']
        assert candidate([5, -5, 8, 4]) == ['Eight', 'Five', 'Four']
        assert candidate([2, 4, 1, 2]) == ['Four', 'Two', 'Two', 'One']
        assert candidate([3, 0, 52]) == ['Three']
        assert candidate([5, -5, 60]) == ['Five']
        assert candidate([9, 1, 3]) == ['Nine', 'Three', 'One']
        assert candidate([4, 5, 4, 8, 5, 12, 2, 1]) == ['Eight', 'Five', 'Five', 'Four', 'Four', 'Two', 'One']
        assert candidate([8, 7, 4]) == ['Eight', 'Seven', 'Four']
        assert candidate([2, -2, 4, 3]) == ['Four', 'Three', 'Two']
        assert candidate([3, -3, 5, 1]) == ['Five', 'Three', 'One']
        assert candidate([9, 8, 6]) == ['Nine', 'Eight', 'Six']
        assert candidate([2, 1, 1, 8, 5, 10, 4, 4]) == ['Eight', 'Five', 'Four', 'Four', 'Two', 'One', 'One']
        assert candidate([2, 0, 52]) == ['Two']
        assert candidate([5, 6, 2, 9, 3, 6, 4, 5]) == ['Nine', 'Six', 'Six', 'Five', 'Five', 'Four', 'Three', 'Two']
        assert candidate([3, 6, 5, 7, 3, 9, 1, 3]) == ['Nine', 'Seven', 'Six', 'Five', 'Three', 'Three', 'Three', 'One']
        assert candidate([10, 1, 6]) == ['Six', 'One']
        assert candidate([5, 7, 5]) == ['Seven', 'Five', 'Five']
        assert candidate([6, -6, 2, 4]) == ['Six', 'Four', 'Two']
        assert candidate([1, 4, 2, 7]) == ['Seven', 'Four', 'Two', 'One']
        assert candidate([10, 9, 11]) == ['Nine']
        assert candidate([3, 1, 3, 2, 4, 3, 1, 1]) == ['Four', 'Three', 'Three', 'Three', 'Two', 'One', 'One', 'One']
        assert candidate([9, 6, 13]) == ['Nine', 'Six']
        assert candidate([5, 9, 13]) == ['Nine', 'Five']
        assert candidate([1, 4, 2, 5]) == ['Five', 'Four', 'Two', 'One']
        assert candidate([4, 4, 2, 6, 9, 8, 1, 8]) == ['Nine', 'Eight', 'Eight', 'Six', 'Four', 'Four', 'Two', 'One']

if __name__ == '__main__':
    unittest.main()
