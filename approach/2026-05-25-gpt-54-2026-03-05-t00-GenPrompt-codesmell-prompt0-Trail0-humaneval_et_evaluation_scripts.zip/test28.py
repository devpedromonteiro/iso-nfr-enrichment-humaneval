
import unittest

from typing import List


from typing import List


def concatenate(strings: List[str]) -> str:
    """Concatenate list of strings into a single string.
    >>> concatenate([])
    ''
    >>> concatenate(['a', 'b', 'c'])
    'abc'
    """
    return "".join(strings)
candidate = concatenate


class Test(unittest.TestCase):
    def test(self):
        assert candidate(['h', 'r', 'k', 'h', 'x']) == 'hrkhx'
        assert candidate(['c', 'q', 'p']) == 'cqp'
        assert candidate(['p', 'a', 'm']) == 'pam'
        assert candidate([]) == ''
        assert candidate(['x', 'z', 'u']) == 'xzu'
        assert candidate(['w', 'q', 'z', 'q', 'b']) == 'wqzqb'
        assert candidate(['q', 'y', 'o', 'm', 'r']) == 'qyomr'
        assert candidate(['e', 'b', 'q']) == 'ebq'
        assert candidate(['c', 'z', 'r']) == 'czr'
        assert candidate(['r', 'n', 'w']) == 'rnw'
        assert candidate(['c', 'y', 'i', 'n', 'u']) == 'cyinu'
        assert candidate(['s', 'i', 'm', 'g', 'v']) == 'simgv'
        assert candidate(['z', 'f', 'g', 's', 'f']) == 'zfgsf'
        assert candidate(['c', 'f', 'm']) == 'cfm'
        assert candidate(['v', 'f', 'h']) == 'vfh'
        assert candidate(['a', 'x', 'j', 'i', 'r']) == 'axjir'
        assert candidate(['g', 'm', 'k']) == 'gmk'
        assert candidate(['w', 'e', 'y', 't', 'n']) == 'weytn'
        assert candidate(['q', 'l', 'w', 's', 'a']) == 'qlwsa'
        assert candidate(['j', 'm', 'o', 'm', 'q']) == 'jmomq'
        assert candidate(['d', 'r', 'w']) == 'drw'
        assert candidate(['u', 'r', 'k', 'v', 'b']) == 'urkvb'
        assert candidate(['x', 'y', 'z']) == 'xyz'
        assert candidate(['l', 'i', 'z']) == 'liz'
        assert candidate(['y', 'p', 's']) == 'yps'
        assert candidate(['i', 'z', 'c']) == 'izc'
        assert candidate(['b', 'o', 'o']) == 'boo'
        assert candidate(['b', 'b', 'l', 'o', 'x']) == 'bblox'
        assert candidate(['k', 'l', 'g']) == 'klg'
        assert candidate(['g', 't', 'e']) == 'gte'
        assert candidate(['b', 'p', 'z', 'n', 'd']) == 'bpznd'
        assert candidate(['f', 'b', 'w', 'u', 'z']) == 'fbwuz'
        assert candidate(['i', 'f', 'r']) == 'ifr'
        assert candidate(['k', 'm', 'v', 'n', 'n']) == 'kmvnn'
        assert candidate(['w', 'y', 'f']) == 'wyf'
        assert candidate(['v', 'u', 'j', 'p', 'v']) == 'vujpv'
        assert candidate(['t', 's', 'n', 's', 'l']) == 'tsnsl'
        assert candidate(['w', 'i', 'w']) == 'wiw'
        assert candidate(['w', 'l', 'l']) == 'wll'
        assert candidate(['m', 'a', 'v']) == 'mav'
        assert candidate(['p', 'a', 's', 'h', 'g']) == 'pashg'
        assert candidate(['k', 'p', 'l', 'o', 'a']) == 'kploa'
        assert candidate(['c', 'j', 'd']) == 'cjd'
        assert candidate(['s', 'n', 'f', 'n', 'c']) == 'snfnc'
        assert candidate(['x', 's', 'n', 'n', 'l']) == 'xsnnl'
        assert candidate(['p', 'a', 'u', 'x', 'n']) == 'pauxn'
        assert candidate(['n', 'x', 's']) == 'nxs'
        assert candidate(['t', 'x', 'r', 'h', 'j']) == 'txrhj'
        assert candidate(['i', 'a', 'z', 'g', 'v']) == 'iazgv'
        assert candidate(['f', 'a', 'o', 'e', 'i']) == 'faoei'
        assert candidate(['x', 'j', 'c']) == 'xjc'
        assert candidate(['c', 'v', 'z']) == 'cvz'
        assert candidate(['u', 'k', 'x']) == 'ukx'
        assert candidate(['n', 'x', 'i', 'g', 'h']) == 'nxigh'
        assert candidate(['u', 'n', 's', 'z', 'b']) == 'unszb'
        assert candidate(['x', 'y', 'z', 'w', 'k']) == 'xyzwk'
        assert candidate(['c', 'm', 'd']) == 'cmd'
        assert candidate(['r', 'i', 'j', 'b', 'l']) == 'rijbl'
        assert candidate(['y', 'm', 'i']) == 'ymi'
        assert candidate(['u', 'e', 'j']) == 'uej'
        assert candidate(['s', 'r', 'm', 'b', 'r']) == 'srmbr'
        assert candidate(['p', 'n', 't', 'b', 'j']) == 'pntbj'
        assert candidate(['x', 'o', 'r', 'h', 'm']) == 'xorhm'
        assert candidate(['y', 'y', 's', 'w', 'd']) == 'yyswd'
        assert candidate(['s', 'z', 'u', 'a', 'n']) == 'szuan'
        assert candidate(['c', 'h', 'a', 'n', 'b']) == 'chanb'
        assert candidate(['f', 'a', 'b', 'o', 'p']) == 'fabop'
        assert candidate(['a', 'a', 'f']) == 'aaf'
        assert candidate(['w', 'u', 'j', 'x', 'r']) == 'wujxr'
        assert candidate(['m', 'x', 'r']) == 'mxr'
        assert candidate(['c', 'j', 'i', 'z', 'k']) == 'cjizk'
        assert candidate(['d', 't', 'g', 'q', 'l']) == 'dtgql'
        assert candidate(['l', 'k', 'd']) == 'lkd'
        assert candidate(['b', 'n', 't', 'z', 'y']) == 'bntzy'
        assert candidate(['r', 'q', 'r', 'o', 'y']) == 'rqroy'
        assert candidate(['k', 'd', 'w', 'u', 'u']) == 'kdwuu'
        assert candidate(['a', 'q', 'p']) == 'aqp'
        assert candidate(['o', 'd', 'd']) == 'odd'
        assert candidate(['q', 'h', 'j']) == 'qhj'
        assert candidate(['h', 'u', 'y']) == 'huy'
        assert candidate(['s', 'q', 'e']) == 'sqe'
        assert candidate(['o', 'h', 'g']) == 'ohg'
        assert candidate(['a', 'v', 'b']) == 'avb'
        assert candidate(['p', 'q', 't']) == 'pqt'
        assert candidate(['l', 'l', 'n']) == 'lln'
        assert candidate(['e', 'g', 'b']) == 'egb'
        assert candidate(['c', 'o', 'l', 'x', 'l']) == 'colxl'

if __name__ == '__main__':
    unittest.main()
