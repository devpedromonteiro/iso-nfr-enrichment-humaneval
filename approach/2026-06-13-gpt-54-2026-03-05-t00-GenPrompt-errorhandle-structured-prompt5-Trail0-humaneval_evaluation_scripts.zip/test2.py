
import unittest
import re
import sys
import math
import copy



def truncate_number(number: float) -> float:
    """Given a positive floating point number, return its decimal part.

    The decimal part is the leftover after removing the integer part.

    >>> truncate_number(3.5)
    0.5
    """
    if not isinstance(number, (int, float)):
        raise TypeError("number must be an int or float")

    if isinstance(number, bool):
        raise TypeError("number must be an int or float, not bool")

    if number < 0:
        raise ValueError("number must be positive")

    try:
        return float(number) - int(float(number))
    except (OverflowError, ValueError) as exc:
        raise ValueError("number must be a finite numeric value") from exc
candidate = truncate_number




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(3.5) == 0.5
    assert abs(candidate(1.33) - 0.33) < 1e-6
    assert abs(candidate(123.456) - 0.456) < 1e-6


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
