
import unittest
import re
import sys
import math
import copy


import math

def max_fill(grid, capacity):
    """
    You are given a rectangular grid of wells. Each row represents a single well,
    and each 1 in a row represents a single unit of water.
    Each well has a corresponding bucket that can be used to extract water from it, 
    and all buckets have the same capacity.
    Your task is to use the buckets to empty the wells.
    Output the number of times you need to lower the buckets.

    Example 1:
        Input: 
            grid : [[0,0,1,0], [0,1,0,0], [1,1,1,1]]
            bucket_capacity : 1
        Output: 6

    Example 2:
        Input: 
            grid : [[0,0,1,1], [0,0,0,0], [1,1,1,1], [0,1,1,1]]
            bucket_capacity : 2
        Output: 5
    
    Example 3:
        Input: 
            grid : [[0,0,0], [0,0,0]]
            bucket_capacity : 5
        Output: 0

    Constraints:
        * all wells have the same length
        * 1 <= grid.length <= 10^2
        * 1 <= grid[:,1].length <= 10^2
        * grid[i][j] -> 0 | 1
        * 1 <= capacity <= 10
    """
    if not isinstance(grid, list):
        raise TypeError("grid must be a list of lists")

    if not isinstance(capacity, int):
        raise TypeError("capacity must be an integer")

    if capacity <= 0:
        raise ValueError("capacity must be greater than 0")

    if len(grid) == 0:
        raise ValueError("grid must not be empty")

    row_length = None
    total_drops = 0

    for i, row in enumerate(grid):
        if not isinstance(row, list):
            raise TypeError(f"grid[{i}] must be a list")

        if row_length is None:
            row_length = len(row)
            if row_length == 0:
                raise ValueError("grid rows must not be empty")
        elif len(row) != row_length:
            raise ValueError("all rows in grid must have the same length")

        water_units = 0
        for j, cell in enumerate(row):
            if not isinstance(cell, int):
                raise TypeError(f"grid[{i}][{j}] must be an integer")
            if cell not in (0, 1):
                raise ValueError(f"grid[{i}][{j}] must be 0 or 1")
            water_units += cell

        total_drops += math.ceil(water_units / capacity)

    return total_drops
candidate = max_fill


def check(candidate):


    # Check some simple cases
    assert True, "This prints if this assert fails 1 (good for debugging!)"
    assert candidate([[0,0,1,0], [0,1,0,0], [1,1,1,1]], 1) == 6, "Error"
    assert candidate([[0,0,1,1], [0,0,0,0], [1,1,1,1], [0,1,1,1]], 2) == 5, "Error"
    assert candidate([[0,0,0], [0,0,0]], 5) == 0, "Error"

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"
    assert candidate([[1,1,1,1], [1,1,1,1]], 2) == 4, "Error"
    assert candidate([[1,1,1,1], [1,1,1,1]], 9) == 2, "Error"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
