
import unittest
import re
import sys
import math
import copy

import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[2] * x^2 + .... xs[n] * x^n
    """
    if not isinstance(xs, list):
        raise TypeError("xs must be a list of numeric coefficients")
    if len(xs) == 0:
        raise ValueError("xs must not be empty")
    if not isinstance(x, (int, float)):
        raise TypeError("x must be a numeric value")
    if not all(isinstance(coeff, (int, float)) for coeff in xs):
        raise TypeError("all coefficients in xs must be numeric")

    return sum(coeff * math.pow(x, i) for i, coeff in enumerate(xs))


def find_zero(xs: list):
    """xs are coefficients of a polynomial.
    find_zero find x such that poly(x) = 0.
    find_zero returns only one zero point, even if there are many.
    Moreover, find_zero only takes list xs having even number of coefficients
    and largest non zero coefficient as it guarantees
    a solution.

    >>> round(find_zero([1, 2]), 2)  # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2)  # (x - 1) * (x - 2) * (x - 3)
    1.0
    """
    if not isinstance(xs, list):
        raise TypeError("xs must be a list of numeric coefficients")
    if len(xs) == 0:
        raise ValueError("xs must not be empty")
    if len(xs) % 2 != 0:
        raise ValueError("xs must contain an even number of coefficients")
    if not all(isinstance(coeff, (int, float)) for coeff in xs):
        raise TypeError("all coefficients in xs must be numeric")

    # Remove trailing zeros to determine the actual degree safely.
    trimmed_xs = xs[:]
    while trimmed_xs and trimmed_xs[-1] == 0:
        trimmed_xs.pop()

    if not trimmed_xs:
        raise ValueError("polynomial must not be identically zero")

    degree = len(trimmed_xs) - 1
    if degree % 2 == 0:
        raise ValueError("highest non-zero coefficient must correspond to an odd degree")

    leading_coeff = trimmed_xs[-1]

    def f(val):
        return poly(trimmed_xs, val)

    # Handle exact zero at x = 0 early.
    f0 = f(0.0)
    if f0 == 0:
        return 0.0

    # For odd-degree polynomials, one side tends to +inf and the other to -inf.
    # Expand interval until a sign change is found.
    left, right = -1.0, 1.0
    try:
        f_left = f(left)
        f_right = f(right)
    except (OverflowError, ValueError) as exc:
        raise ArithmeticError("failed to evaluate polynomial during bracketing") from exc

    max_iterations = 10_000
    iterations = 0

    while f_left * f_right > 0:
        iterations += 1
        if iterations > max_iterations:
            raise RuntimeError("failed to bracket a root within iteration limit")

        left *= 2.0
        right *= 2.0

        try:
            f_left = f(left)
            f_right = f(right)
        except (OverflowError, ValueError) as exc:
            raise ArithmeticError("failed to evaluate polynomial during interval expansion") from exc

    if f_left == 0:
        return left
    if f_right == 0:
        return right

    # Bisection method on a valid bracket.
    for _ in range(1_000):
        mid = (left + right) / 2.0
        try:
            f_mid = f(mid)
        except (OverflowError, ValueError) as exc:
            raise ArithmeticError("failed to evaluate polynomial during bisection") from exc

        if abs(f_mid) < 1e-12:
            return mid

        if f_left * f_mid < 0:
            right = mid
            f_right = f_mid
        else:
            left = mid
            f_left = f_mid

    # Return best approximation without leaving ambiguous state.
    return (left + right) / 2.0
candidate = find_zero




METADATA = {}


def check(candidate):
    import math
    import random
    rng = random.Random(42)
    import copy
    for _ in range(100):
        ncoeff = 2 * rng.randint(1, 4)
        coeffs = []
        for _ in range(ncoeff):
            coeff = rng.randint(-10, 10)
            if coeff == 0:
                coeff = 1
            coeffs.append(coeff)
        solution = candidate(copy.deepcopy(coeffs))
        assert math.fabs(poly(coeffs, solution)) < 1e-4



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
