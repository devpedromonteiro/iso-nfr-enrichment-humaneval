
import unittest
import re
import sys
import math
import copy


def unique_digits(x):
    """Given a list of positive integers x, return a sorted list of all
    elements that do not contain any even digit.

    Note: Returned list is sorted in increasing order.

    For example:
    >>> unique_digits([15, 33, 1422, 1])
    [1, 15, 33]
    >>> unique_digits([152, 323, 1422, 10])
    []
    """
    if not isinstance(x, list):
        raise TypeError("x must be a list of positive integers")

    result = []
    even_digits = {"0", "2", "4", "6", "8"}

    for i, value in enumerate(x):
        if not isinstance(value, int):
            raise TypeError(f"x[{i}] must be an integer, got {type(value).__name__}")
        if value <= 0:
            raise ValueError(f"x[{i}] must be a positive integer, got {value}")

        if all(digit not in even_digits for digit in str(value)):
            result.append(value)

    return sorted(result)
candidate = unique_digits


def check(candidate):

    # Check some simple cases
    assert candidate([15, 33, 1422, 1]) == [1, 15, 33]
    assert candidate([152, 323, 1422, 10]) == []
    assert candidate([12345, 2033, 111, 151]) == [111, 151]
    assert candidate([135, 103, 31]) == [31, 135]

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
