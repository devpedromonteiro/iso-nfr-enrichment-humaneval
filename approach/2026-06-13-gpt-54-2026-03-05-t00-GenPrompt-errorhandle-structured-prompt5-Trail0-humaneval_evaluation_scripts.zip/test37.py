
import unittest
import re
import sys
import math
import copy



def sort_even(l: list):
    """Return a new list where values at even indices are sorted, while odd indices remain unchanged.

    Even indices are 0, 2, 4, ...

    >>> sort_even([1, 2, 3])
    [1, 2, 3]
    >>> sort_even([5, 6, 3, 4])
    [3, 6, 5, 4]
    """
    if not isinstance(l, list):
        raise TypeError("sort_even expects a list as input")

    even_values = l[::2]

    try:
        sorted_even_values = sorted(even_values)
    except TypeError as exc:
        raise TypeError(
            "elements at even indices must be mutually comparable for sorting"
        ) from exc

    result = l.copy()
    result[::2] = sorted_even_values
    return result
candidate = sort_even




METADATA = {}


def check(candidate):
    assert tuple(candidate([1, 2, 3])) == tuple([1, 2, 3])
    assert tuple(candidate([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])) == tuple([-10, 3, -5, 2, -3, 3, 5, 0, 9, 1, 123])
    assert tuple(candidate([5, 8, -12, 4, 23, 2, 3, 11, 12, -10])) == tuple([-12, 8, 3, 4, 5, 2, 12, 11, 23, -10])



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
