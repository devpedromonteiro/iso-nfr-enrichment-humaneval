
import unittest
import re
import sys
import math
import copy

from typing import List, Any


from typing import List, Any


def filter_integers(values: List[Any]) -> List[int]:
    """Filter given list of any python values only for integers.

    >>> filter_integers(['a', 3.14, 5])
    [5]
    >>> filter_integers([1, 2, 3, 'abc', {}, []])
    [1, 2, 3]
    """
    if not isinstance(values, list):
        raise TypeError("values must be a list")

    result: List[int] = []

    for index, value in enumerate(values):
        try:
            if isinstance(value, bool):
                continue
            if isinstance(value, int):
                result.append(value)
        except TypeError as exc:
            raise TypeError(
                f"invalid item at index {index}: unable to evaluate type"
            ) from exc

    return result
candidate = filter_integers




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == []
    assert candidate([4, {}, [], 23.2, 9, 'adasd']) == [4, 9]
    assert candidate([3, 'c', 3, 3, 'a', 'b']) == [3, 3, 3]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
