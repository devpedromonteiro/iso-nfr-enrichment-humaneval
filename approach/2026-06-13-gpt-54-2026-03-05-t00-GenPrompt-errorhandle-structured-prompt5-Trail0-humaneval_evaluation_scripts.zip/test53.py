
import unittest
import re
import sys
import math
import copy



def add(x: int, y: int) -> int:
    """Add two numbers x and y.

    >>> add(2, 3)
    5
    >>> add(5, 7)
    12
    """
    if not isinstance(x, int):
        raise TypeError(f"x must be an int, got {type(x).__name__}")
    if not isinstance(y, int):
        raise TypeError(f"y must be an int, got {type(y).__name__}")

    try:
        return x + y
    except OverflowError:
        # Preserve specific arithmetic failures explicitly
        raise
candidate = add




METADATA = {}


def check(candidate):
    import random

    assert candidate(0, 1) == 1
    assert candidate(1, 0) == 1
    assert candidate(2, 3) == 5
    assert candidate(5, 7) == 12
    assert candidate(7, 5) == 12

    for i in range(100):
        x, y = random.randint(0, 1000), random.randint(0, 1000)
        assert candidate(x, y) == x + y



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
