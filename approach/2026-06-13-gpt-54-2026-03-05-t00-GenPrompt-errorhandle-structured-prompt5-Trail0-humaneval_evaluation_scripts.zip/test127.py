
import unittest
import re
import sys
import math
import copy


def intersection(interval1, interval2):
    """Determine whether the length of the intersection of two closed integer intervals is prime.

    Each interval must be a pair of integers (start, end) with start <= end.
    Returns "YES" if the intersection length is a prime number, otherwise "NO".

    Examples:
        intersection((1, 2), (2, 3)) -> "NO"
        intersection((-1, 1), (0, 4)) -> "NO"
        intersection((-3, -1), (-5, 5)) -> "YES"
    """

    def _validate_interval(interval, name):
        if not isinstance(interval, tuple):
            raise TypeError(f"{name} must be a tuple of two integers")
        if len(interval) != 2:
            raise ValueError(f"{name} must contain exactly two elements")

        start, end = interval

        if not isinstance(start, int) or not isinstance(end, int):
            raise TypeError(f"{name} must contain only integers")
        if start > end:
            raise ValueError(f"{name} must satisfy start <= end")

        return start, end

    def _is_prime(n):
        if n < 2:
            return False
        if n == 2:
            return True
        if n % 2 == 0:
            return False

        divisor = 3
        while divisor * divisor <= n:
            if n % divisor == 0:
                return False
            divisor += 2
        return True

    start1, end1 = _validate_interval(interval1, "interval1")
    start2, end2 = _validate_interval(interval2, "interval2")

    intersection_start = max(start1, start2)
    intersection_end = min(end1, end2)

    if intersection_start > intersection_end:
        return "NO"

    # Closed interval length by count of included integers.
    length = intersection_end - intersection_start + 1

    return "YES" if _is_prime(length) else "NO"
candidate = intersection


def check(candidate):

    # Check some simple cases
    assert candidate((1, 2), (2, 3)) == "NO"
    assert candidate((-1, 1), (0, 4)) == "NO"
    assert candidate((-3, -1), (-5, 5)) == "YES"
    assert candidate((-2, 2), (-4, 0)) == "YES"

    # Check some edge cases that are easy to work out by hand.
    assert candidate((-11, 2), (-1, -1)) == "NO"
    assert candidate((1, 2), (3, 5)) == "NO"
    assert candidate((1, 2), (1, 2)) == "NO"
    assert candidate((-2, -2), (-3, -2)) == "NO"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
