
import unittest
import re
import sys
import math
import copy


def tri(n):
    """Return the first n + 1 values of the Tribonacci sequence.

    Sequence definition:
    - tri(0) = 1
    - tri(1) = 3
    - tri(k) = 1 + k / 2, if k is even and k >= 2
    - tri(k) = tri(k - 1) + tri(k - 2) + tri(k + 1), if k is odd and k >= 3

    Args:
        n: Non-negative integer index.

    Returns:
        A list containing tri(0) through tri(n).

    Raises:
        TypeError: If n is not an integer.
        ValueError: If n is negative.
    """
    if isinstance(n, bool) or not isinstance(n, int):
        raise TypeError("n must be a non-negative integer")
    if n < 0:
        raise ValueError("n must be a non-negative integer")

    try:
        result = [0] * (n + 1)

        result[0] = 1
        if n >= 1:
            result[1] = 3

        for k in range(2, n + 1):
            if k % 2 == 0:
                result[k] = 1 + k // 2
            else:
                # tri(k) = tri(k - 1) + tri(k - 2) + tri(k + 1)
                # and for odd k, k + 1 is even, so compute directly
                next_even_value = 1 + (k + 1) // 2
                result[k] = result[k - 1] + result[k - 2] + next_even_value

        return result

    except (OverflowError, MemoryError):
        # Re-raise specific runtime failures without masking them
        raise
candidate = tri


def check(candidate):

    # Check some simple cases
    
    assert candidate(3) == [1, 3, 2.0, 8.0]
    assert candidate(4) == [1, 3, 2.0, 8.0, 3.0]
    assert candidate(5) == [1, 3, 2.0, 8.0, 3.0, 15.0]
    assert candidate(6) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0]
    assert candidate(7) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0]
    assert candidate(8) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0]
    assert candidate(9) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0]
    assert candidate(20) == [1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0, 6.0, 48.0, 7.0, 63.0, 8.0, 80.0, 9.0, 99.0, 10.0, 120.0, 11.0]

    # Check some edge cases that are easy to work out by hand.
    assert candidate(0) == [1]
    assert candidate(1) == [1, 3]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
