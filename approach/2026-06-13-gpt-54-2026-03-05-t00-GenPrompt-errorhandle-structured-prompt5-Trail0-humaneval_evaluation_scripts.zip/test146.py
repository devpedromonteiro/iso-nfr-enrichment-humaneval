
import unittest
import re
import sys
import math
import copy


def specialFilter(nums):
    """Return the count of numbers > 10 whose first and last digits are odd.

    Args:
        nums: An iterable of integers.

    Returns:
        int: Number of matching elements.

    Raises:
        TypeError: If nums is not iterable or contains non-integer elements.
        ValueError: If nums is None.
    """
    if nums is None:
        raise ValueError("nums must not be None")

    try:
        iterator = iter(nums)
    except TypeError as exc:
        raise TypeError("nums must be an iterable of integers") from exc

    count = 0
    for i, num in enumerate(iterator):
        if not isinstance(num, int) or isinstance(num, bool):
            raise TypeError(f"nums[{i}] must be an integer, got {type(num).__name__}")

        if num > 10:
            s = str(abs(num))
            first_digit = int(s[0])
            last_digit = int(s[-1])

            if first_digit % 2 == 1 and last_digit % 2 == 1:
                count += 1

    return count
candidate = specialFilter


def check(candidate):

    # Check some simple cases
    assert candidate([5, -2, 1, -5]) == 0  
    assert candidate([15, -73, 14, -15]) == 1
    assert candidate([33, -2, -3, 45, 21, 109]) == 2
    assert candidate([43, -12, 93, 125, 121, 109]) == 4
    assert candidate([71, -2, -33, 75, 21, 19]) == 3


    # Check some edge cases that are easy to work out by hand.
    assert candidate([1]) == 0              
    assert candidate([]) == 0                   



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
