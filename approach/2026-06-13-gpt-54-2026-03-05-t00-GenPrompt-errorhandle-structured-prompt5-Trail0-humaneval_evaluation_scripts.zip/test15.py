
import unittest
import re
import sys
import math
import copy



def string_sequence(n: int) -> str:
    """Return a string containing space-delimited numbers from 0 up to n inclusive.

    >>> string_sequence(0)
    '0'
    >>> string_sequence(5)
    '0 1 2 3 4 5'
    """
    if not isinstance(n, int):
        raise TypeError(f"n must be an int, got {type(n).__name__}")
    if n < 0:
        raise ValueError("n must be greater than or equal to 0")

    try:
        return " ".join(str(i) for i in range(n + 1))
    except Exception as exc:
        raise RuntimeError("failed to generate string sequence") from exc
candidate = string_sequence




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(0) == '0'
    assert candidate(3) == '0 1 2 3'
    assert candidate(10) == '0 1 2 3 4 5 6 7 8 9 10'


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
