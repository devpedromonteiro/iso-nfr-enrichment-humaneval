
import unittest
import re
import sys
import math
import copy

from typing import List


from typing import List


def below_zero(operations: List[int]) -> bool:
    """You're given a list of deposit and withdrawal operations on a bank account
    that starts with zero balance. Return True if at any point the balance falls
    below zero, otherwise return False.

    >>> below_zero([1, 2, 3])
    False
    >>> below_zero([1, 2, -4, 5])
    True
    """
    if not isinstance(operations, list):
        raise TypeError("operations must be a list of integers")

    balance = 0

    for index, operation in enumerate(operations):
        if not isinstance(operation, int):
            raise TypeError(
                f"operation at index {index} must be an integer, got {type(operation).__name__}"
            )

        balance += operation

        if balance < 0:
            return True

    return False
candidate = below_zero




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate([]) == False
    assert candidate([1, 2, -3, 1, 2, -3]) == False
    assert candidate([1, 2, -4, 5, 6]) == True
    assert candidate([1, -1, 2, -2, 5, -5, 4, -4]) == False
    assert candidate([1, -1, 2, -2, 5, -5, 4, -5]) == True
    assert candidate([1, -2, 2, -2, 5, -5, 4, -4]) == True


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
