
import unittest
import re
import sys
import math
import copy


def f(n):
    """Return a list of length n where, for 1-based index i:
    - if i is even, the value is factorial(i)
    - if i is odd, the value is the sum 1 + 2 + ... + i

    Example:
        f(5) == [1, 2, 6, 24, 15]
    """
    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if isinstance(n, bool):
        raise TypeError("n must be an integer, not bool")
    if n < 0:
        raise ValueError("n must be non-negative")

    result = []

    for i in range(1, n + 1):
        if i % 2 == 0:
            value = 1
            for j in range(1, i + 1):
                value *= j
        else:
            value = i * (i + 1) // 2
        result.append(value)

    return result
candidate = f


def check(candidate):

    assert candidate(5) == [1, 2, 6, 24, 15]
    assert candidate(7) == [1, 2, 6, 24, 15, 720, 28]
    assert candidate(1) == [1]
    assert candidate(3) == [1, 2, 6]


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
