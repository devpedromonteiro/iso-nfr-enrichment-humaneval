
import unittest
import re
import sys
import math
import copy


def is_multiply_prime(a):
    """Return True if `a` is the product of exactly 3 prime numbers, else False.

    Constraints/behavior:
    - `a` must be an integer.
    - Values less than 2 cannot be expressed as a product of 3 primes.
    - Raises:
        TypeError: if `a` is not an integer
        ValueError: if `a` is negative
    """
    if not isinstance(a, int):
        raise TypeError("a must be an integer")
    if a < 0:
        raise ValueError("a must be non-negative")
    if a < 2:
        return False

    def is_prime(n):
        if n < 2:
            return False
        if n == 2:
            return True
        if n % 2 == 0:
            return False
        i = 3
        while i * i <= n:
            if n % i == 0:
                return False
            i += 2
        return True

    prime_factors_count = 0
    remaining = a

    factor = 2
    while factor * factor <= remaining and prime_factors_count <= 3:
        while remaining % factor == 0:
            if not is_prime(factor):
                return False
            prime_factors_count += 1
            remaining //= factor
        factor += 1

    if remaining > 1:
        if not is_prime(remaining):
            return False
        prime_factors_count += 1

    return prime_factors_count == 3
candidate = is_multiply_prime


def check(candidate):

    assert candidate(5) == False
    assert candidate(30) == True
    assert candidate(8) == True
    assert candidate(10) == False
    assert candidate(125) == True
    assert candidate(3 * 5 * 7) == True
    assert candidate(3 * 6 * 7) == False
    assert candidate(9 * 9 * 9) == False
    assert candidate(11 * 9 * 9) == False
    assert candidate(11 * 13 * 7) == True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
