
import unittest
import re
import sys
import math
import copy


def exchange(lst1, lst2):
    """Determine whether elements can be exchanged between two lists so that
    lst1 contains only even numbers.

    Rules:
    - Any number of exchanges is allowed.
    - Returns "YES" if lst1 can be made all even, otherwise "NO".

    Error handling:
    - Both inputs must be non-empty lists.
    - All elements in both lists must be numbers (int or float).

    Examples:
        exchange([1, 2, 3, 4], [1, 2, 3, 4]) -> "YES"
        exchange([1, 2, 3, 4], [1, 5, 3, 4]) -> "NO"
    """
    if not isinstance(lst1, list):
        raise TypeError("lst1 must be a list")
    if not isinstance(lst2, list):
        raise TypeError("lst2 must be a list")
    if not lst1:
        raise ValueError("lst1 must be non-empty")
    if not lst2:
        raise ValueError("lst2 must be non-empty")

    for i, value in enumerate(lst1):
        if not isinstance(value, (int, float)):
            raise TypeError(f"lst1[{i}] must be a number")
        if isinstance(value, float) and not value.is_integer():
            raise ValueError(f"lst1[{i}] must be an integer-valued number for parity checks")

    for i, value in enumerate(lst2):
        if not isinstance(value, (int, float)):
            raise TypeError(f"lst2[{i}] must be a number")
        if isinstance(value, float) and not value.is_integer():
            raise ValueError(f"lst2[{i}] must be an integer-valued number for parity checks")

    odd_count_lst1 = sum(int(x) % 2 != 0 for x in lst1)
    even_count_lst2 = sum(int(x) % 2 == 0 for x in lst2)

    return "YES" if even_count_lst2 >= odd_count_lst1 else "NO"
candidate = exchange


def check(candidate):

    # Check some simple cases
    assert candidate([1, 2, 3, 4], [1, 2, 3, 4]) == "YES"
    assert candidate([1, 2, 3, 4], [1, 5, 3, 4]) == "NO"
    assert candidate([1, 2, 3, 4], [2, 1, 4, 3]) == "YES" 
    assert candidate([5, 7, 3], [2, 6, 4]) == "YES"
    assert candidate([5, 7, 3], [2, 6, 3]) == "NO" 
    assert candidate([3, 2, 6, 1, 8, 9], [3, 5, 5, 1, 1, 1]) == "NO"

    # Check some edge cases that are easy to work out by hand.
    assert candidate([100, 200], [200, 200]) == "YES"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
