
import unittest
import re
import sys
import math
import copy



def get_positive(l: list):
    """Return only positive numbers in the list.

    >>> get_positive([-1, 2, -4, 5, 6])
    [2, 5, 6]
    >>> get_positive([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    [5, 3, 2, 3, 9, 123, 1]
    """
    if not isinstance(l, list):
        raise TypeError("l must be a list")

    positive_numbers = []
    for index, value in enumerate(l):
        if not isinstance(value, (int, float)):
            raise TypeError(f"list element at index {index} must be a number")
        if value > 0:
            positive_numbers.append(value)

    return positive_numbers
candidate = get_positive




METADATA = {}


def check(candidate):
    assert candidate([-1, -2, 4, 5, 6]) == [4, 5, 6]
    assert candidate([5, 3, -5, 2, 3, 3, 9, 0, 123, 1, -10]) == [5, 3, 2, 3, 3, 9, 123, 1]
    assert candidate([-1, -2]) == []
    assert candidate([]) == []



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
