
import unittest
import re
import sys
import math
import copy



def same_chars(s0: str, s1: str) -> bool:
    """
    Check if two words have the same unique characters.

    >>> same_chars('eabcdzzzz', 'dddzzzzzzzddeddabc')
    True
    >>> same_chars('abcd', 'dddddddabc')
    True
    >>> same_chars('dddddddabc', 'abcd')
    True
    >>> same_chars('eabcd', 'dddddddabc')
    False
    >>> same_chars('abcd', 'dddddddabce')
    False
    >>> same_chars('eabcdzzzz', 'dddzzzzzzzddddabc')
    False
    """
    if not isinstance(s0, str):
        raise TypeError(f"s0 must be a str, got {type(s0).__name__}")
    if not isinstance(s1, str):
        raise TypeError(f"s1 must be a str, got {type(s1).__name__}")

    try:
        return set(s0) == set(s1)
    except TypeError as exc:
        # Re-raise with clearer context while preserving the original exception.
        raise TypeError("Inputs must be iterable strings containing hashable characters") from exc
candidate = same_chars




METADATA = {}


def check(candidate):
    assert candidate('eabcdzzzz', 'dddzzzzzzzddeddabc') == True
    assert candidate('abcd', 'dddddddabc') == True
    assert candidate('dddddddabc', 'abcd') == True
    assert candidate('eabcd', 'dddddddabc') == False
    assert candidate('abcd', 'dddddddabcf') == False
    assert candidate('eabcdzzzz', 'dddzzzzzzzddddabc') == False
    assert candidate('aabb', 'aaccc') == False



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
