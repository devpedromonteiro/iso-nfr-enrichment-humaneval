
import unittest

from typing import List


from typing import List


def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    """Insert `delimeter` between every two consecutive elements of `numbers`.

    >>> intersperse([], 4)
    []
    >>> intersperse([1, 2, 3], 4)
    [1, 4, 2, 4, 3]
    """
    n = len(numbers)
    if n == 0:
        return []

    result = [0] * (2 * n - 1)
    result[0::2] = numbers
    result[1::2] = [delimeter] * (n - 1)
    return result
candidate = intersperse


class Test(unittest.TestCase):
    def test(self):
        assert candidate([6, 2, 7], 4) == [6, 4, 2, 4, 7]
        assert candidate([7, 10, 8, 7], 11) == [7, 11, 10, 11, 8, 11, 7]
        assert candidate([5, 2, 3], 5) == [5, 5, 2, 5, 3]
        assert candidate([], 6) == []
        assert candidate([3, 7, 3], 7) == [3, 7, 7, 7, 3]
        assert candidate([6, 3, 4, 2], 12) == [6, 12, 3, 12, 4, 12, 2]
        assert candidate([6, 2, 5], 4) == [6, 4, 2, 4, 5]
        assert candidate([7, 2, 6], 2) == [7, 2, 2, 2, 6]
        assert candidate([5, 6, 7], 1) == [5, 1, 6, 1, 7]
        assert candidate([8, 7, 4, 3], 9) == [8, 9, 7, 9, 4, 9, 3]
        assert candidate([1, 1, 5, 4], 12) == [1, 12, 1, 12, 5, 12, 4]
        assert candidate([1, 7, 2], 4) == [1, 4, 7, 4, 2]
        assert candidate([2, 7, 2, 4], 12) == [2, 12, 7, 12, 2, 12, 4]
        assert candidate([2, 11, 3, 4], 12) == [2, 12, 11, 12, 3, 12, 4]
        assert candidate([1, 3, 5], 5) == [1, 5, 3, 5, 5]
        assert candidate([2, 3, 5], 2) == [2, 2, 3, 2, 5]
        assert candidate([2, 4, 2], 6) == [2, 6, 4, 6, 2]
        assert candidate([2, 10, 1, 1], 3) == [2, 3, 10, 3, 1, 3, 1]
        assert candidate([3, 3, 5], 5) == [3, 5, 3, 5, 5]
        assert candidate([3, 7, 4], 4) == [3, 4, 7, 4, 4]
        assert candidate([], 10) == []
        assert candidate([5, 7, 4, 6], 10) == [5, 10, 7, 10, 4, 10, 6]
        assert candidate([6, 3, 8, 3], 6) == [6, 6, 3, 6, 8, 6, 3]
        assert candidate([2, 3, 7, 2], 11) == [2, 11, 3, 11, 7, 11, 2]
        assert candidate([9, 4, 5, 6], 4) == [9, 4, 4, 4, 5, 4, 6]
        assert candidate([6, 5, 6], 3) == [6, 3, 5, 3, 6]
        assert candidate([7, 1, 5], 6) == [7, 6, 1, 6, 5]
        assert candidate([7, 1, 2], 7) == [7, 7, 1, 7, 2]
        assert candidate([7, 4, 5], 7) == [7, 7, 4, 7, 5]
        assert candidate([2, 2, 2], 2) == [2, 2, 2, 2, 2]
        assert candidate([5, 5, 4, 4], 4) == [5, 4, 5, 4, 4, 4, 4]
        assert candidate([2, 5, 1], 6) == [2, 6, 5, 6, 1]
        assert candidate([5, 5, 6], 2) == [5, 2, 5, 2, 6]
        assert candidate([], 9) == []
        assert candidate([9, 3, 5, 4], 8) == [9, 8, 3, 8, 5, 8, 4]
        assert candidate([10, 5, 7, 7], 10) == [10, 10, 5, 10, 7, 10, 7]
        assert candidate([2, 7, 8, 1], 8) == [2, 8, 7, 8, 8, 8, 1]
        assert candidate([], 3) == []
        assert candidate([4, 1, 7, 3], 12) == [4, 12, 1, 12, 7, 12, 3]
        assert candidate([10, 6, 2, 7], 11) == [10, 11, 6, 11, 2, 11, 7]
        assert candidate([5, 11, 4, 2], 11) == [5, 11, 11, 11, 4, 11, 2]
        assert candidate([6, 7, 2], 1) == [6, 1, 7, 1, 2]
        assert candidate([4, 1, 6, 2], 3) == [4, 3, 1, 3, 6, 3, 2]
        assert candidate([], 11) == []
        assert candidate([3, 2, 7], 7) == [3, 7, 2, 7, 7]
        assert candidate([7, 8, 4, 2], 10) == [7, 10, 8, 10, 4, 10, 2]
        assert candidate([3, 4, 3], 4) == [3, 4, 4, 4, 3]
        assert candidate([], 2) == []
        assert candidate([5, 5, 3, 5], 13) == [5, 13, 5, 13, 3, 13, 5]
        assert candidate([7, 9, 8, 6], 9) == [7, 9, 9, 9, 8, 9, 6]
        assert candidate([2, 1, 1, 1], 9) == [2, 9, 1, 9, 1, 9, 1]
        assert candidate([10, 1, 5, 4], 7) == [10, 7, 1, 7, 5, 7, 4]
        assert candidate([8, 11, 6, 4], 5) == [8, 5, 11, 5, 6, 5, 4]
        assert candidate([5, 6, 3, 2], 8) == [5, 8, 6, 8, 3, 8, 2]
        assert candidate([1, 4, 7, 7], 10) == [1, 10, 4, 10, 7, 10, 7]
        assert candidate([1, 4, 6, 4], 8) == [1, 8, 4, 8, 6, 8, 4]
        assert candidate([2, 3, 1], 3) == [2, 3, 3, 3, 1]
        assert candidate([5, 6, 7, 6], 3) == [5, 3, 6, 3, 7, 3, 6]
        assert candidate([3, 1, 5], 7) == [3, 7, 1, 7, 5]
        assert candidate([3, 2, 7], 1) == [3, 1, 2, 1, 7]
        assert candidate([9, 8, 7, 5], 3) == [9, 3, 8, 3, 7, 3, 5]
        assert candidate([9, 8, 8, 2], 3) == [9, 3, 8, 3, 8, 3, 2]
        assert candidate([9, 1, 5, 5], 6) == [9, 6, 1, 6, 5, 6, 5]
        assert candidate([9, 6, 5, 1], 13) == [9, 13, 6, 13, 5, 13, 1]
        assert candidate([], 4) == []
        assert candidate([7, 6, 4], 3) == [7, 3, 6, 3, 4]
        assert candidate([1, 7, 3], 1) == [1, 1, 7, 1, 3]
        assert candidate([1, 7, 7, 2], 12) == [1, 12, 7, 12, 7, 12, 2]
        assert candidate([8, 11, 2, 1], 3) == [8, 3, 11, 3, 2, 3, 1]
        assert candidate([5, 1, 2], 6) == [5, 6, 1, 6, 2]
        assert candidate([7, 3, 4], 3) == [7, 3, 3, 3, 4]
        assert candidate([9, 1, 7, 7], 5) == [9, 5, 1, 5, 7, 5, 7]
        assert candidate([6, 11, 8, 6], 10) == [6, 10, 11, 10, 8, 10, 6]
        assert candidate([5, 3, 3], 2) == [5, 2, 3, 2, 3]
        assert candidate([3, 2, 1], 5) == [3, 5, 2, 5, 1]
        assert candidate([2, 10, 7, 3], 5) == [2, 5, 10, 5, 7, 5, 3]
        assert candidate([2, 1, 5], 6) == [2, 6, 1, 6, 5]
        assert candidate([4, 5, 1], 1) == [4, 1, 5, 1, 1]
        assert candidate([8, 7, 4, 5], 11) == [8, 11, 7, 11, 4, 11, 5]
        assert candidate([1, 6, 2], 5) == [1, 5, 6, 5, 2]
        assert candidate([6, 4, 6, 5], 6) == [6, 6, 4, 6, 6, 6, 5]
        assert candidate([7, 2, 4], 1) == [7, 1, 2, 1, 4]
        assert candidate([4, 1, 5], 5) == [4, 5, 1, 5, 5]
        assert candidate([7, 4, 6], 7) == [7, 7, 4, 7, 6]
        assert candidate([4, 5, 4], 5) == [4, 5, 5, 5, 4]
        assert candidate([5, 5, 7], 7) == [5, 7, 5, 7, 7]
        assert candidate([5, 9, 4, 3], 3) == [5, 3, 9, 3, 4, 3, 3]
        assert candidate([3, 6, 2, 4], 4) == [3, 4, 6, 4, 2, 4, 4]
        assert candidate([1, 7, 6, 7], 3) == [1, 3, 7, 3, 6, 3, 7]
        assert candidate([7, 2, 5, 2], 3) == [7, 3, 2, 3, 5, 3, 2]
        assert candidate([2, 3, 4], 2) == [2, 2, 3, 2, 4]
        assert candidate([2, 2, 6, 4], 13) == [2, 13, 2, 13, 6, 13, 4]
        assert candidate([6, 1, 3], 4) == [6, 4, 1, 4, 3]
        assert candidate([2, 1, 3], 3) == [2, 3, 1, 3, 3]
        assert candidate([], 7) == []
        assert candidate([5, 1, 6], 7) == [5, 7, 1, 7, 6]
        assert candidate([6, 7, 2, 7], 3) == [6, 3, 7, 3, 2, 3, 7]
        assert candidate([7, 5, 7], 5) == [7, 5, 5, 5, 7]
        assert candidate([1, 7, 5], 2) == [1, 2, 7, 2, 5]
        assert candidate([1, 2, 3], 3) == [1, 3, 2, 3, 3]
        assert candidate([7, 2, 5, 7], 6) == [7, 6, 2, 6, 5, 6, 7]
        assert candidate([7, 3, 3], 1) == [7, 1, 3, 1, 3]
        assert candidate([3, 3, 3], 5) == [3, 5, 3, 5, 3]
        assert candidate([6, 9, 7, 3], 10) == [6, 10, 9, 10, 7, 10, 3]
        assert candidate([1, 7, 2, 3], 10) == [1, 10, 7, 10, 2, 10, 3]
        assert candidate([2, 1, 1], 3) == [2, 3, 1, 3, 1]
        assert candidate([7, 2, 3, 4], 6) == [7, 6, 2, 6, 3, 6, 4]
        assert candidate([4, 5, 2], 3) == [4, 3, 5, 3, 2]
        assert candidate([5, 4, 6, 7], 13) == [5, 13, 4, 13, 6, 13, 7]
        assert candidate([6, 7, 3], 7) == [6, 7, 7, 7, 3]

if __name__ == '__main__':
    unittest.main()
