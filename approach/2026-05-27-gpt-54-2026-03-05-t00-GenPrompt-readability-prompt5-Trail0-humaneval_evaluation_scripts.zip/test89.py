
import unittest
import re
import sys
import math
import copy


def encrypt(s):
    """Return a string encrypted by shifting each letter forward by 4.

    The alphabet is rotated so that:
    a -> e, b -> f, ..., w -> a, x -> b, y -> c, z -> d

    Examples:
        encrypt('hi') -> 'lm'
        encrypt('asdfghjkl') -> 'ewhjklnop'
        encrypt('gf') -> 'kj'
        encrypt('et') -> 'ix'
    """
    shift = 4
    result = []

    for char in s:
        if 'a' <= char <= 'z':
            new_pos = (ord(char) - ord('a') + shift) % 26
            result.append(chr(ord('a') + new_pos))
        elif 'A' <= char <= 'Z':
            new_pos = (ord(char) - ord('A') + shift) % 26
            result.append(chr(ord('A') + new_pos))
        else:
            result.append(char)

    return ''.join(result)
candidate = encrypt


def check(candidate):

    # Check some simple cases
    assert candidate('hi') == 'lm', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('asdfghjkl') == 'ewhjklnop', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('gf') == 'kj', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('et') == 'ix', "This prints if this assert fails 1 (good for debugging!)"

    assert candidate('faewfawefaewg')=='jeiajeaijeiak', "This prints if this assert fails 1 (good for debugging!)"
    assert candidate('hellomyfriend')=='lippsqcjvmirh', "This prints if this assert fails 2 (good for debugging!)"
    assert candidate('dxzdlmnilfuhmilufhlihufnmlimnufhlimnufhfucufh')=='hbdhpqrmpjylqmpyjlpmlyjrqpmqryjlpmqryjljygyjl', "This prints if this assert fails 3 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate('a')=='e', "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
