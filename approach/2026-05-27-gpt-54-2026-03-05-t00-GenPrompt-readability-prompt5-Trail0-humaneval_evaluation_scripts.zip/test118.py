
import unittest
import re
import sys
import math
import copy


def get_closest_vowel(word):
    """Return the rightmost vowel that is between two consonants.

    A vowel counts only if:
    - it is not the first or last character
    - the character before it is a consonant
    - the character after it is a consonant

    If no such vowel exists, return an empty string.
    """
    vowels = "aeiouAEIOU"

    def is_vowel(char):
        return char in vowels

    # Check from right to left, skipping the first and last characters.
    for i in range(len(word) - 2, 0, -1):
        if (
            is_vowel(word[i])
            and not is_vowel(word[i - 1])
            and not is_vowel(word[i + 1])
        ):
            return word[i]

    return ""
candidate = get_closest_vowel


def check(candidate):

    # Check some simple cases
    assert candidate("yogurt") == "u"
    assert candidate("full") == "u"
    assert candidate("easy") == ""
    assert candidate("eAsy") == ""
    assert candidate("ali") == ""
    assert candidate("bad") == "a"
    assert candidate("most") == "o"
    assert candidate("ab") == ""
    assert candidate("ba") == ""
    assert candidate("quick") == ""
    assert candidate("anime") == "i"
    assert candidate("Asia") == ""
    assert candidate("Above") == "o"

    # Check some edge cases that are easy to work out by hand.
    assert True



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
