
import unittest
import re
import sys
import math
import copy



def encode_shift(s: str):
    """
    returns encoded string by shifting every character by 5 in the alphabet.
    """
    return "".join([chr(((ord(ch) + 5 - ord("a")) % 26) + ord("a")) for ch in s])


def encode_shift(s: str):
    """
    Returns an encoded string by shifting every lowercase character by 5
    positions in the alphabet.
    """
    shift = 5
    start = ord("a")
    alphabet_size = 26

    return "".join(
        chr(((ord(ch) - start + shift) % alphabet_size) + start)
        for ch in s
    )


def decode_shift(s: str):
    """
    Takes as input a string encoded with encode_shift and returns the
    original decoded string.
    """
    shift = 5
    start = ord("a")
    alphabet_size = 26

    return "".join(
        chr(((ord(ch) - start - shift) % alphabet_size) + start)
        for ch in s
    )
candidate = decode_shift




METADATA = {}


def check(candidate):
    from random import randint, choice
    import copy
    import string

    letters = string.ascii_lowercase
    for _ in range(100):
        str = ''.join(choice(letters) for i in range(randint(10, 20)))
        encoded_str = encode_shift(str)
        assert candidate(copy.deepcopy(encoded_str)) == str



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
