
import unittest
import re
import sys
import math
import copy


def split_words(txt):
    '''
    Given a string of words, return a list of words split on whitespace.
    If no whitespace exists in the text, split on commas ','.
    If no commas exist either, return the number of lower-case letters
    with odd order in the alphabet:
        ord('a') = 0, ord('b') = 1, ... ord('z') = 25

    Examples
    split_words("Hello world!") â ["Hello", "world!"]
    split_words("Hello,world!") â ["Hello", "world!"]
    split_words("abcdef") â 3
    '''
    if any(char.isspace() for char in txt):
        return txt.split()

    if ',' in txt:
        return txt.split(',')

    odd_count = 0
    for char in txt:
        if char.islower() and (ord(char) - ord('a')) % 2 == 1:
            odd_count += 1

    return odd_count
candidate = split_words


def check(candidate):

    assert candidate("Hello world!") == ["Hello","world!"]
    assert candidate("Hello,world!") == ["Hello","world!"]
    assert candidate("Hello world,!") == ["Hello","world,!"]
    assert candidate("Hello,Hello,world !") == ["Hello,Hello,world","!"]
    assert candidate("abcdef") == 3
    assert candidate("aaabb") == 2
    assert candidate("aaaBb") == 1
    assert candidate("") == 0


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
