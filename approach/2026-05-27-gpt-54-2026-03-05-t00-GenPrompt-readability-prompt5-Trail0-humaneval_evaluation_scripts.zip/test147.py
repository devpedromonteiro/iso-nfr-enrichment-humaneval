
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    You are given a positive integer n. Create an array a of length n where:
        a[i] = i * i - i + 1   for 1 <= i <= n

    Return the number of triples (a[i], a[j], a[k]) such that:
        i < j < k
        a[i] + a[j] + a[k] is divisible by 3

    Example:
        Input: n = 5
        Output: 1
        Explanation:
            a = [1, 3, 7, 13, 21]
            The only valid triple is (1, 7, 13).
    """

    # For i >= 1:
    # a[i] = i^2 - i + 1 = i(i - 1) + 1
    # Since i(i - 1) is always divisible by 2 but we only care mod 3:
    #
    # Check i mod 3:
    #   i % 3 == 0 -> a[i] % 3 == 1
    #   i % 3 == 1 -> a[i] % 3 == 1
    #   i % 3 == 2 -> a[i] % 3 == 0
    #
    # So values in a are only congruent to 0 or 1 modulo 3.
    #
    # A triple sum is divisible by 3 only in these cases:
    #   0 + 0 + 0 = 0
    #   1 + 1 + 1 = 3
    #
    # Therefore:
    #   answer = C(count_0, 3) + C(count_1, 3)

    def comb3(x):
        if x < 3:
            return 0
        return x * (x - 1) * (x - 2) // 6

    count_0 = n // 3          # indices i where i % 3 == 2
    count_1 = n - count_0     # all remaining indices

    return comb3(count_0) + comb3(count_1)
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
