
import unittest
import re
import sys
import math
import copy


def solve(s):
    """Return the string with letter cases swapped.

    Rules:
    - If the string contains at least one letter, swap the case of each letter
      and leave all other characters unchanged.
    - If the string contains no letters, return the reversed string.

    Examples:
        solve("1234") -> "4321"
        solve("ab") -> "AB"
        solve("#a@C") -> "#A@c"
    """
    has_letter = any(char.isalpha() for char in s)

    if not has_letter:
        return s[::-1]

    result = []
    for char in s:
        if char.isalpha():
            result.append(char.swapcase())
        else:
            result.append(char)

    return "".join(result)
candidate = solve


def check(candidate):

    # Check some simple cases
    assert candidate("AsDf") == "aSdF"
    assert candidate("1234") == "4321"
    assert candidate("ab") == "AB"
    assert candidate("#a@C") == "#A@c"
    assert candidate("#AsdfW^45") == "#aSDFw^45"
    assert candidate("#6@2") == "2@6#"

    # Check some edge cases that are easy to work out by hand.
    assert candidate("#$a^D") == "#$A^d"
    assert candidate("#ccc") == "#CCC"

    # Don't remove this line:


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
