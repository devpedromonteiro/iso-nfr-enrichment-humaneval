
import unittest


def find_max(words):
    """Return the word with the highest number of unique characters.

    If multiple words have the same number of unique characters,
    return the lexicographically smallest one.

    Examples:
        find_max(["name", "of", "string"]) == "string"
        find_max(["name", "enam", "game"]) == "enam"
        find_max(["aaaaaaa", "bb", "cc"]) == "aaaaaaa"
    """
    best_word = ""
    highest_unique_count = -1

    for word in words:
        unique_character_count = len(set(word))

        is_better_unique_count = unique_character_count > highest_unique_count
        is_same_unique_count_but_lexicographically_smaller = (
            unique_character_count == highest_unique_count and word < best_word
        )

        if is_better_unique_count or is_same_unique_count_but_lexicographically_smaller:
            best_word = word
            highest_unique_count = unique_character_count

    return best_word
candidate = find_max


class Test(unittest.TestCase):
    def test(self):
        assert candidate(['twtilt', 'cre', 'g', 'mbbwmpdm']) == 'mbbwmpdm'
        assert candidate(['fhhnk', 'aaqhutjni']) == 'aaqhutjni'
        assert candidate(['jjp', 'wsyz']) == 'wsyz'
        assert candidate(['cajfyrft', 'fpuq']) == 'cajfyrft'
        assert candidate(['hxzj', 'yudn']) == 'hxzj'
        assert candidate(['vhvzkhnkx', 'andas', 'brewb', 'vcqze', 'ytfsxjrjyd']) == 'ytfsxjrjyd'
        assert candidate(['zspzvw', 'oklgrvr', 'bixsdp']) == 'bixsdp'
        assert candidate(['agcme', 'eitvog', 'pvd', 'gady']) == 'eitvog'
        assert candidate(['hoxb', 'wlhqvdsa']) == 'wlhqvdsa'
        assert candidate(['foweyb', 'qnwpbur']) == 'qnwpbur'
        assert candidate(['wwmewokey', 'zkjbxg', 'bmh', 'vjfrx', 'swojawequr']) == 'swojawequr'
        assert candidate(['rls', 'bfbsyy', 'mibyf']) == 'mibyf'
        assert candidate(['ttdf', 'caf', 'yahmbad']) == 'yahmbad'
        assert candidate(['nghmnegzm', 'qjtd']) == 'nghmnegzm'
        assert candidate(['chbndu', 'lughoi', 'pwblcar']) == 'pwblcar'
        assert candidate(['wpxvgoxv', 'vbltiy', 'htwzhsablna']) == 'htwzhsablna'
        assert candidate(['ildvzfb', 'cgdb', 'nmxj']) == 'ildvzfb'
        assert (candidate(["aaaaaaa", "bb", "cc"]) == "aaaaaaa"), 't3'
        assert candidate(['atijo', 'jiedpr', 'd', 'mpglwxazx']) == 'mpglwxazx'
        assert candidate(['hknt', 'svavejfe', 'y', 'hhyfarttj', 'ddwufuzq']) == 'hhyfarttj'
        assert candidate(['shnmd', 'jukow', 'hcwu', 'xcm', 'gti']) == 'jukow'
        assert candidate(['e']) == 'e'
        assert candidate(['qheozz', 'amx', 'uoddm', 'jsuisd']) == 'jsuisd'
        assert (candidate(["abc", "cba"]) == "abc"), 't4'
        assert candidate(['ecqhphdt', 'sjhu', 'w', 'iouhtz']) == 'ecqhphdt'
        assert candidate(['eyjy', 'eautt', 'crehuz']) == 'crehuz'
        assert candidate(['bflb', 'skdyz']) == 'skdyz'
        assert candidate(['mkolxv', 'pufd', 'o', 'nhc', 'jqphqdjtxfje']) == 'jqphqdjtxfje'
        assert candidate(['b']) == 'b'
        assert candidate(['svrgwe', 'pclxe', 'o', 'bubmvpvny', 'kfjzzyyn']) == 'bubmvpvny'
        assert candidate(['k']) == 'k'
        assert candidate(['hqvdkpsi', 'fmsr', 't', 'ifopzrwcm']) == 'ifopzrwcm'
        assert candidate(['vabfs', 'vqk', 'cdl']) == 'vabfs'
        assert candidate(['bpp', 'pyf', 'kqnqisnok']) == 'kqnqisnok'
        assert candidate(['unkndf', 'lawny', 't', 'clb', 'feeyavjwcs']) == 'feeyavjwcs'
        assert candidate(['sye', 'sizxd', 'qfumheq']) == 'qfumheq'
        assert (candidate(["b"]) == "b"), 't9'
        assert candidate(['prscjydsx', 'qqfg', 'rdbgt']) == 'prscjydsx'
        assert candidate(['hqv', 'wweg', 'wgbua']) == 'wgbua'
        assert candidate(['doim', 'mywv', 'h', 'bsp', 'oxqiutxywfda']) == 'oxqiutxywfda'
        assert candidate(['stjuaxoh', 'vjd', 'vhnm']) == 'stjuaxoh'
        assert candidate(['ezwzjo', 'utlogea', 'omuanig']) == 'omuanig'
        assert candidate(['pzynm', 'awivkzkma', 'eomxzgl']) == 'awivkzkma'
        assert candidate(['cby', 'uellzcfz', 'qsxyplgl', 'mdn']) == 'qsxyplgl'
        assert candidate(['ysddpvcn', 'klvxhuet', 'xegww']) == 'klvxhuet'
        assert candidate(['xwz', 'hkww', 'dibbumenspuo']) == 'dibbumenspuo'
        assert candidate(['hnmacvfj', 'ifibac', 'fttxfeevftc']) == 'hnmacvfj'
        assert candidate(['wfpboof', 'yizi', 'swrj']) == 'wfpboof'
        assert candidate(['xadczr', 'vizw', 'znkjpl', 'gac', 'hoew']) == 'xadczr'
        assert candidate(['iqia', 'kejd', 'och']) == 'kejd'
        assert candidate(['xgms', 'bmrxvv', 'hdte']) == 'bmrxvv'
        assert candidate(['agva', 'dtoz', 'mlxgr', 'qcg']) == 'mlxgr'
        assert candidate(['tagcc', 'wcwlgenfr', 'ljjgieud', 'vveiet']) == 'wcwlgenfr'
        assert candidate(['iuairmyk', 'ocv', 'cbtwodz']) == 'cbtwodz'
        assert candidate(['cod', 'xdxyu']) == 'xdxyu'
        assert candidate(['o']) == 'o'
        assert candidate(['hrgjujdqf', 'jnih', 'xhmkzl']) == 'hrgjujdqf'
        assert (candidate(["we", "are", "a", "mad", "nation"]) == "nation"), 't7'
        assert (candidate(["name", "of", "string"]) == "string"), "t1"
        assert candidate(['grsjo', 'hedw', 'b', 'zuh', 'xhdxt']) == 'grsjo'
        assert candidate(['ngll', 'tyzfvsc', 'u', 'yqiqmswme', 'kxxyysm']) == 'tyzfvsc'
        assert candidate(['gixp', 'qvbokh', 'ormvgppue', 'arg']) == 'ormvgppue'
        assert candidate(['htwmc', 'bzx', 'b', 'zeg', 'qfyz']) == 'htwmc'
        assert candidate(['rmbt', 'gdwtshzt', 'gsb', 'fur']) == 'gdwtshzt'
        assert candidate(['h']) == 'h'
        assert candidate(['fuperq', 'nvrgcl', 'iho']) == 'fuperq'
        assert candidate(['cfoiof', 'vzjbcwv', 'qffzxxku']) == 'qffzxxku'
        assert candidate(['vqxy', 'yet', 'i', 'mtvoymnzx', 'fmwrbov']) == 'mtvoymnzx'
        assert candidate(['flid', 'eqcx', 'puzsezkhz']) == 'puzsezkhz'
        assert candidate(['t']) == 't'
        assert candidate(['gmnyxopyi', 'fuqnnv', 'dvbc']) == 'gmnyxopyi'
        assert candidate(['rha', 'asn', 'tship', 'ess']) == 'tship'
        assert candidate(['jlrgosrn', 'mrbq', 's', 'cidcaga']) == 'jlrgosrn'
        assert candidate(['kvlbflrpx', 'dyculpfjz', 'tiotdbz']) == 'dyculpfjz'
        assert (candidate(["play", "this", "game", "of","footbott"]) == "footbott"), 't5'
        assert candidate(['jdzgkxhr', 'cen', 'mlklue']) == 'jdzgkxhr'
        assert candidate(['wzyych', 'wwmq', 'h', 'tcst']) == 'wzyych'
        assert candidate(['wjgtpe', 'dacsvcks', 'rtpik']) == 'dacsvcks'
        assert candidate(['s']) == 's'
        assert candidate(['tyuzaf', 'tcnntubob', 'yjssws']) == 'tcnntubob'
        assert candidate(['uhmryc', 'bjvyicmj', 'jawmlrcn', 'vww', 'rntn']) == 'jawmlrcn'
        assert candidate(['bkl', 'qny', 'wgit']) == 'wgit'
        assert candidate(['pet', 'kmqoxbt', 'nuquyr', 'amgjxtzjy']) == 'amgjxtzjy'
        assert (candidate(["name", "enam", "game"]) == "enam"), 't2'
        assert candidate(['lzognlo', 'jinmd']) == 'jinmd'
        assert candidate(['dak', 'ttceml', 'j', 'swaqrrlcg', 'ful']) == 'swaqrrlcg'
        assert candidate(['qbhptf', 'ampkzd', 'jepbdkosv', 'zgtdft']) == 'jepbdkosv'
        assert candidate(['dskhghnb', 'mmhaa']) == 'dskhghnb'
        assert candidate(['exj', 'xpdcmkvsw', 'iwf']) == 'xpdcmkvsw'
        assert candidate(['apgpgvy', 'bnpgp', 'ijpf']) == 'apgpgvy'
        assert candidate(['ljyn', 'onwka', 'w', 'bimmc']) == 'onwka'
        assert candidate(['pztyt', 'fwethq', 'y', 'tmmlhlqjf']) == 'tmmlhlqjf'
        assert candidate(['w']) == 'w'
        assert candidate(['iugyijgyt', 'yjxdcfi', 'mgmo', 'dwmazr', 'oxcqkzjcww']) == 'oxcqkzjcww'
        assert candidate(['tsldb', 'gjcio', 'kvnnond', 'vzu', 'vzik']) == 'gjcio'
        assert candidate(['aueuor', 'fmxkc', 'b', 'ciye', 'rlwasxtas']) == 'rlwasxtas'
        assert candidate(['ufzbuoz', 'dbaz', 'kopun']) == 'kopun'
        assert candidate(['g']) == 'g'
        assert candidate(['qmvmzph', 'pzkmmibi', 'aavpu']) == 'pzkmmibi'
        assert candidate(['wxhqf', 'jhpsj', 'amlkaehne', 'hke', 'jkktbvujm']) == 'amlkaehne'
        assert candidate(['upes', 'kvdqns', 'sfpiaoww', 'jfewgsyzo']) == 'jfewgsyzo'
        assert (candidate(["this", "is", "a", "prrk"]) == "this"), 't8'

    # Check some edge cases that are easy to work out by hand.
        assert candidate(['shmvzae', 'qeflck', 'r', 'tnndxpmlf']) == 'tnndxpmlf'
        assert candidate(['qqygli', 'ualw', 'avnhbvyf', 'kjizcn', 'ybdkgdlrxlf']) == 'ybdkgdlrxlf'
        assert candidate(['tegsx', 'ddg', 'acai']) == 'tegsx'
        assert candidate(['lfspzmg', 'puaqq', 'kbmp', 'pvfy', 'mkvpcxj']) == 'lfspzmg'
        assert candidate(['dbxsfams', 'mkwrsdpxf', 'mzu']) == 'mkwrsdpxf'
        assert candidate(['lijjqy', 'rwqmew']) == 'lijjqy'
        assert candidate(['kmv', 'xrcodpr', 'wchmmzp']) == 'wchmmzp'
        assert candidate(['uxxaq', 'ngsr', 'eawspmuzb', 'xazcphs']) == 'eawspmuzb'
        assert candidate(['jwcwigmna', 'ekww', 'irsuzq']) == 'jwcwigmna'
        assert candidate(['pljzl', 'dythcav']) == 'dythcav'
        assert candidate(['qok', 'somrrtogu', 'dakp']) == 'somrrtogu'
        assert candidate(['prsle', 'bxe', 'qqv', 'lyx', 'zhihdorqor']) == 'zhihdorqor'
        assert candidate(['zeskya', 'evvd', 'azjfjahr', 'yxqjr', 'zjonzrxgphju']) == 'zjonzrxgphju'
        assert candidate(['nquk', 'dmucv', 'jlw', 'ytvtnusv']) == 'ytvtnusv'
        assert candidate(['alwsufrg', 'zpa', 'hyvic']) == 'alwsufrg'
        assert candidate(['nqqok', 'bet', 'sjx']) == 'nqqok'
        assert candidate(['kxn', 'nxm', 'f', 'cnowck', 'jmqqxtl']) == 'jmqqxtl'
        assert candidate(['ddgazwvd', 'tmf', 'i', 'wpjua']) == 'ddgazwvd'
        assert (candidate(["we", "are", "gonna", "rock"]) == "gonna"), 't6'
        assert candidate(['abddvgqkk', 'kqedcc', 'osa']) == 'abddvgqkk'
        assert candidate(['jmyvisjti', 'ssym', 'uzjqxeg']) == 'jmyvisjti'
        assert candidate(['krjkhpm', 'ubmvvw', 'xlsxoh']) == 'krjkhpm'
        assert candidate(['fnz', 'fpzovx', 'a', 'zuaz', 'arzlzo']) == 'fpzovx'
        assert candidate(['cwcghsru', 'nzihzu', 'f', 'luzyj']) == 'cwcghsru'
        assert candidate(['rwwrcef', 'qebufez', 'cfmn']) == 'qebufez'
        assert candidate(['uubvnz', 'pnj', 'zedmelziy']) == 'zedmelziy'
        assert candidate(['ims', 'obb', 'eytgbk']) == 'eytgbk'
        assert candidate(['lya', 'thducp', 'w', 'prcgphbs']) == 'prcgphbs'
        assert candidate(['vhkyv', 'fzzgzqyzo', 'amyce']) == 'fzzgzqyzo'
        assert candidate(['dvjmsd', 'vaj', 'lyom', 'gmuiw', 'easxkrjddr']) == 'easxkrjddr'
        assert (candidate(["play", "play", "play"]) == "play"), 't10'
        assert candidate(['hdruovosng', 'esspiz', 'ztc']) == 'hdruovosng'
        assert candidate(['l']) == 'l'
        assert candidate(['crwip', 'wtaxe', 'm', 'emqsmkwj']) == 'emqsmkwj'
        assert candidate(['ntffz', 'wjjpao', 'uljddczgx']) == 'uljddczgx'

if __name__ == '__main__':
    unittest.main()
