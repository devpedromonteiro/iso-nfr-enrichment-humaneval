
import unittest



def sum_to_n(n: int):
    """sum_to_n is a function that sums numbers from 1 to n.
    >>> sum_to_n(30)
    465
    >>> sum_to_n(100)
    5050
    >>> sum_to_n(5)
    15
    >>> sum_to_n(10)
    55
    >>> sum_to_n(1)
    1
    """
    return n * (n + 1) // 2
candidate = sum_to_n


class Test(unittest.TestCase):
    def test(self):
        assert candidate(720) == 259560
        assert candidate(609) == 185745
        assert candidate(479) == 114960
        assert candidate(191) == 18336
        assert candidate(950) == 451725
        assert candidate(1) == 1
        assert candidate(709) == 251695
        assert candidate(867) == 376278
        assert candidate(379) == 72010
        assert candidate(813) == 330891
        assert candidate(990) == 490545
        assert candidate(224) == 25200
        assert candidate(774) == 299925
        assert candidate(981) == 481671
        assert candidate(891) == 397386
        assert candidate(676) == 228826
        assert candidate(20) == 210
        assert candidate(281) == 39621
        assert candidate(987) == 487578
        assert candidate(982) == 482653
        assert candidate(570) == 162735
        assert candidate(507) == 128778
        assert candidate(877) == 385003
        assert candidate(30) == 465
        assert candidate(957) == 458403
        assert candidate(318) == 50721
        assert candidate(666) == 222111
        assert candidate(896) == 401856
        assert candidate(594) == 176715
        assert candidate(343) == 58996
        assert candidate(714) == 255255
        assert candidate(497) == 123753
        assert candidate(718) == 258121
        assert candidate(391) == 76636
        assert candidate(60) == 1830
        assert candidate(550) == 151525
        assert candidate(707) == 250278
        assert candidate(304) == 46360
        assert candidate(54) == 1485
        assert candidate(336) == 56616
        assert candidate(161) == 13041
        assert candidate(176) == 15576
        assert candidate(361) == 65341
        assert candidate(209) == 21945
        assert candidate(547) == 149878
        assert candidate(271) == 36856
        assert candidate(6) == 21
        assert candidate(670) == 224785
        assert candidate(99) == 4950
        assert candidate(964) == 465130
        assert candidate(159) == 12720
        assert candidate(972) == 472878
        assert candidate(260) == 33930
        assert candidate(426) == 90951
        assert candidate(945) == 446985
        assert candidate(261) == 34191
        assert candidate(302) == 45753
        assert candidate(247) == 30628
        assert candidate(704) == 248160
        assert candidate(637) == 203203
        assert candidate(705) == 248865
        assert candidate(904) == 409060
        assert candidate(100) == 5050
        assert candidate(89) == 4005
        assert candidate(723) == 261726
        assert candidate(968) == 468996
        assert candidate(231) == 26796
        assert candidate(43) == 946
        assert candidate(943) == 445096
        assert candidate(657) == 216153
        assert candidate(91) == 4186
        assert candidate(909) == 413595
        assert candidate(213) == 22791
        assert candidate(283) == 40186
        assert candidate(828) == 343206
        assert candidate(546) == 149331
        assert candidate(979) == 479710
        assert candidate(875) == 383250
        assert candidate(484) == 117370
        assert candidate(66) == 2211
        assert candidate(931) == 433846
        assert candidate(192) == 18528
        assert candidate(11) == 66
        assert candidate(947) == 448878
        assert candidate(605) == 183315
        assert candidate(512) == 131328
        assert candidate(355) == 63190
        assert candidate(700) == 245350
        assert candidate(335) == 56280
        assert candidate(257) == 33153
        assert candidate(678) == 230181
        assert candidate(802) == 322003
        assert candidate(468) == 109746
        assert candidate(554) == 153735
        assert candidate(956) == 457446
        assert candidate(611) == 186966
        assert candidate(482) == 116403
        assert candidate(625) == 195625
        assert candidate(186) == 17391
        assert candidate(46) == 1081
        assert candidate(442) == 97903
        assert candidate(443) == 98346

if __name__ == '__main__':
    unittest.main()
