
import unittest


def match_parens(lst):
    def stats(s):
        balance = 0
        min_balance = 0
        for ch in s:
            if ch == '(':
                balance += 1
            else:
                balance -= 1
            if balance < min_balance:
                min_balance = balance
        return balance, min_balance

    a, b = lst
    bal_a, min_a = stats(a)
    bal_b, min_b = stats(b)

    def can_concat(first_bal, first_min, second_bal, second_min):
        total_bal = first_bal + second_bal
        if total_bal != 0:
            return False
        if first_min < 0:
            return False
        if first_bal + second_min < 0:
            return False
        return True

    return 'Yes' if (
        can_concat(bal_a, min_a, bal_b, min_b) or
        can_concat(bal_b, min_b, bal_a, min_a)
    ) else 'No'
candidate = match_parens


class Test(unittest.TestCase):
    def test(self):
        assert candidate((')())', '(()()(')) == 'Yes'
        assert candidate(('((((', ')')) == 'No'
        assert candidate(('()(', '())')) == 'Yes'
        assert candidate(('())', '((((')) == 'No'
        assert candidate(('(()(', '()(')) == 'No'
        assert candidate(('())', '(()()(')) == 'No'
        assert candidate([')', ')']) == 'No'
        assert candidate(('()(', ')')) == 'Yes'
        assert candidate(('(()(())', '()(')) == 'No'
        assert candidate(('(()()(', '())())')) == 'Yes'
        assert candidate(('())', ')())')) == 'No'
        assert candidate(('((((', '((((')) == 'No'
        assert candidate((')(', '(()()(')) == 'No'
        assert candidate((')())', ')())')) == 'No'
        assert candidate((')())', '((())')) == 'No'
        assert candidate(('()', '()(')) == 'No'
        assert candidate(('(()(())', '())())')) == 'No'
        assert candidate(('(', ')')) == 'Yes'
        assert candidate(('(())))', '()(')) == 'No'
        assert candidate(('()', '(()())((')) == 'No'
        assert candidate(('())())', '()(')) == 'No'
        assert candidate(('())())', '(()()(')) == 'Yes'
        assert candidate(('()(', '())())')) == 'No'
        assert candidate(('()))()', '())')) == 'No'
        assert candidate(('(())))', '((())')) == 'No'
        assert candidate(['()', '())']) == 'No'
        assert candidate(['(())))', '(()())((']) == 'Yes'
        assert candidate((')', '(())))')) == 'No'
        assert candidate([')())', '(()()(']) == 'Yes'
        assert candidate(('(()()(', '(()()(')) == 'No'
        assert candidate((')', '(()(())')) == 'Yes'
        assert candidate([')(()', '(()(']) == 'No'
        assert candidate(('(()(())', ')')) == 'Yes'
        assert candidate((')(', '()(')) == 'No'
        assert candidate(('(()()(', ')(()')) == 'No'
        assert candidate(('()(', '(()(())')) == 'No'
        assert candidate((')', '()(')) == 'Yes'
        assert candidate(('())', ')')) == 'No'
        assert candidate(('(()())((', '(()(())')) == 'No'
        assert candidate(('(()(', ')(()')) == 'No'
        assert candidate(('())())', ')())')) == 'No'
        assert candidate(('())', ')(')) == 'No'
        assert candidate(('(()(())', ')(')) == 'No'
        assert candidate(('()', '())')) == 'No'
        assert candidate((')())', '()(')) == 'No'
        assert candidate([')(', ')(']) == 'No'
    

    # Check some edge cases that are easy to work out by hand.
        assert candidate(('(()(', '(()())((')) == 'No'
        assert candidate((')', '(()()(')) == 'No'
        assert candidate(('()(', '(()())((')) == 'No'
        assert candidate(('((())', '(()(')) == 'No'
        assert candidate((')', '())())')) == 'No'
        assert candidate(('()(', '()(')) == 'No'
        assert candidate(['()(', ')']) == 'Yes'
        assert candidate(('(()()(', '(()(())')) == 'No'
        assert candidate(('())())', '()')) == 'No'
        assert candidate(('(()(())', '())')) == 'Yes'
        assert candidate(['(()(', '()))()']) == 'Yes'
        assert candidate(('(()(', '(()(')) == 'No'
        assert candidate(('(())))', '(())))')) == 'No'
        assert candidate(('()(', '(()(')) == 'No'
        assert candidate(('(', '(()())((')) == 'No'
        assert candidate(['(', ')']) == 'Yes'
        assert candidate(['((((', '((())']) == 'No'
        assert candidate(('())())', '(()(())')) == 'No'
        assert candidate(('())', '()')) == 'No'
        assert candidate(('(', '()))()')) == 'No'
        assert candidate(('())())', '(()(')) == 'Yes'
        assert candidate(('(()(())', ')())')) == 'No'
        assert candidate(('((((', '()')) == 'No'
        assert candidate((')())', '(())))')) == 'No'
        assert candidate(('(()())((', ')')) == 'No'
        assert candidate(('()(', ')())')) == 'No'
        assert candidate(('())', '()(')) == 'Yes'
        assert candidate(('()', '(()(())')) == 'No'
        assert candidate((')(()', '(())))')) == 'No'
        assert candidate(('(()()(', '()(')) == 'No'
        assert candidate(('())())', ')')) == 'No'
        assert candidate(['(()(())', '())())']) == 'No'
        assert candidate((')', ')')) == 'No'
        assert candidate(('())())', ')(()')) == 'No'
        assert candidate(('()))()', '(()(')) == 'Yes'
        assert candidate((')())', '((((')) == 'No'
        assert candidate(('(()(())', '(()()(')) == 'No'
        assert candidate(('()', ')())')) == 'No'
        assert candidate(('(())))', '(()()(')) == 'Yes'
        assert candidate((')(', ')(()')) == 'No'
        assert candidate(('(()()(', '(())))')) == 'Yes'
        assert candidate(('(())))', '(()(())')) == 'No'
        assert candidate(('((((', '(()(')) == 'No'
        assert candidate([')', '(']) == 'Yes'
        assert candidate((')(()', '())')) == 'No'
        assert candidate((')())', '())())')) == 'No'

if __name__ == '__main__':
    unittest.main()
