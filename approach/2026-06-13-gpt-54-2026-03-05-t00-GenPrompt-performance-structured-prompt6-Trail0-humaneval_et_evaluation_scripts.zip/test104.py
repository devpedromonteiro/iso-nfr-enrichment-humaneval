
import unittest


def unique_digits(x):
    """Given a list of positive integers x, return a sorted list of all
    elements that don't contain any even digit.

    Note: Returned list is sorted in increasing order.

    For example:
    >>> unique_digits([15, 33, 1422, 1])
    [1, 15, 33]
    >>> unique_digits([152, 323, 1422, 10])
    []
    """
    odd_digits = {'1', '3', '5', '7', '9'}
    result = []

    for n in x:
        s = str(n)
        if all(ch in odd_digits for ch in s):
            result.append(n)

    result.sort()
    return result
candidate = unique_digits


class Test(unittest.TestCase):
    def test(self):
        assert candidate([132, 100, 32]) == []
        assert candidate([13201, 1832, 113, 153]) == [113, 153]
        assert candidate([16, 29, 1817, 5]) == [5]
        assert candidate([18, 29, 1203, 4]) == []
        assert candidate([11957, 2956, 106, 146]) == [11957]
        assert candidate([11648, 1283, 106, 154]) == []
        assert candidate([13, 38, 1398, 5]) == [5, 13]
        assert candidate([138, 104, 35]) == [35]
        assert candidate([11330, 1632, 109, 146]) == []
        assert candidate([139, 102, 33]) == [33, 139]
        assert candidate([12495, 2236, 115, 146]) == [115]
        assert candidate([135, 99, 26]) == [99, 135]
        assert candidate([150, 323, 2227, 14]) == []
        assert candidate([152, 325, 2236, 9]) == [9]
        assert candidate([12263, 2608, 106, 153]) == [153]
        assert candidate([11838, 1681, 114, 152]) == []
        assert candidate([131, 103, 27]) == [131]
        assert candidate([12144, 2080, 111, 149]) == [111]
        assert candidate([15, 37, 668, 3]) == [3, 15, 37]
        assert candidate([11706, 2681, 115, 149]) == [115]
        assert candidate([157, 328, 2400, 12]) == [157]
        assert candidate([154, 326, 2275, 5]) == [5]
        assert candidate([12563, 2453, 106, 150]) == []
        assert candidate([154, 319, 854, 8]) == [319]
        assert candidate([155, 327, 606, 8]) == [155]
        assert candidate([137, 102, 31]) == [31, 137]
        assert candidate([151, 321, 686, 13]) == [13, 151]
        assert candidate([133, 108, 33]) == [33, 133]
        assert candidate([12592, 1020, 115, 148]) == [115]
        assert candidate([156, 322, 761, 7]) == [7]
        assert candidate([140, 107, 26]) == []
        assert candidate([139, 108, 27]) == [139]
        assert candidate([13, 34, 2003, 6]) == [13]
        assert candidate([137, 103, 29]) == [137]
        assert candidate([132, 98, 29]) == []
        assert candidate([10, 30, 2076, 3]) == [3]
        assert candidate([155, 323, 1014, 6]) == [155]
        assert candidate([130, 105, 31]) == [31]
        assert candidate([12296, 2695, 107, 152]) == []
        assert candidate([147, 322, 2180, 15]) == [15]
        assert candidate([147, 324, 1561, 10]) == []
        assert candidate([132, 108, 27]) == []
        assert candidate([136, 99, 26]) == [99]
        assert candidate([157, 319, 842, 13]) == [13, 157, 319]
        assert candidate([151, 325, 963, 8]) == [151]
        assert candidate([12, 36, 1972, 2]) == []
        assert candidate([133, 105, 30]) == [133]
        assert candidate([12590, 2103, 108, 149]) == []
        assert candidate([153, 322, 1603, 11]) == [11, 153]
        assert candidate([15, 28, 2033, 4]) == [15]
        assert candidate([19, 35, 1750, 2]) == [19, 35]
        assert candidate([132, 108, 33]) == [33]
        assert candidate([152, 323, 1422, 10]) == []
        assert candidate([151, 328, 1473, 9]) == [9, 151]
        assert candidate([138, 107, 33]) == [33]
        assert candidate([135, 103, 33]) == [33, 135]
        assert candidate([16, 36, 1245, 1]) == [1]
        assert candidate([149, 325, 551, 13]) == [13, 551]
        assert candidate([19, 30, 479, 5]) == [5, 19]
        assert candidate([147, 318, 852, 6]) == []
        assert candidate([11911, 2486, 116, 152]) == [11911]
        assert candidate([10, 29, 839, 2]) == []
        assert candidate([134, 98, 29]) == []
        assert candidate([12150, 1701, 115, 149]) == [115]
        assert candidate([135, 104, 33]) == [33, 135]
        assert candidate([12438, 2377, 108, 150]) == []
        assert candidate([20, 29, 817, 5]) == [5]
        assert candidate([150, 320, 1086, 11]) == [11]
        assert candidate([17, 30, 2073, 4]) == [17]
        assert candidate([133, 99, 27]) == [99, 133]
        assert candidate([139, 100, 36]) == [139]
        assert candidate([130, 99, 27]) == [99]
        assert candidate([11, 28, 1070, 4]) == [11]
        assert candidate([12768, 2105, 110, 149]) == []
        assert candidate([13139, 2540, 110, 146]) == [13139]
        assert candidate([137, 105, 35]) == [35, 137]
        assert candidate([10, 29, 1708, 6]) == []
        assert candidate([11, 31, 600, 1]) == [1, 11, 31]
        assert candidate([12, 32, 1527, 3]) == [3]
        assert candidate([13169, 2835, 114, 155]) == [155]
        assert candidate([12505, 2912, 114, 154]) == []
        assert candidate([17, 29, 2012, 6]) == [17]
        assert candidate([136, 100, 31]) == [31]
        assert candidate([12158, 1034, 110, 152]) == []
        assert candidate([11, 28, 445, 6]) == [11]
        assert candidate([137, 106, 32]) == [137]
        assert candidate([151, 322, 2270, 7]) == [7, 151]
        assert candidate([135, 101, 26]) == [135]
        assert candidate([156, 321, 810, 8]) == []
        assert candidate([11355, 1562, 115, 146]) == [115, 11355]
        assert candidate([154, 322, 863, 6]) == []
        assert candidate([13, 30, 1214, 6]) == [13]
        assert candidate([153, 328, 2074, 12]) == [153]
        assert candidate([12132, 1059, 110, 150]) == []
        assert candidate([140, 102, 33]) == [33]
        assert candidate([11323, 2509, 107, 146]) == []
        assert candidate([147, 325, 1540, 15]) == [15]
        assert candidate([15, 33, 1422, 1]) == [1, 15, 33]
        assert candidate([15, 37, 629, 5]) == [5, 15, 37]
        assert candidate([154, 323, 2077, 13]) == [13]
        assert candidate([18, 30, 792, 3]) == [3]
        assert candidate([20, 32, 1433, 1]) == [1]
        assert candidate([151, 320, 441, 5]) == [5, 151]
        assert candidate([11494, 2338, 115, 149]) == [115]
        assert candidate([135, 103, 31]) == [31, 135]

    # Check some edge cases that are easy to work out by hand.
        assert candidate([16, 30, 2202, 3]) == [3]
        assert candidate([154, 321, 941, 15]) == [15]
        assert candidate([12669, 1865, 111, 151]) == [111, 151]
        assert candidate([155, 327, 1737, 14]) == [155, 1737]
        assert candidate([11389, 1488, 112, 146]) == []
        assert candidate([153, 328, 616, 12]) == [153]
        assert candidate([156, 323, 1793, 9]) == [9, 1793]
        assert candidate([12, 30, 1352, 2]) == []
        assert candidate([18, 31, 1093, 4]) == [31]
        assert candidate([17, 29, 2356, 1]) == [1, 17]
        assert candidate([16, 31, 1988, 2]) == [31]
        assert candidate([153, 326, 1380, 15]) == [15, 153]
        assert candidate([137, 107, 30]) == [137]
        assert candidate([134, 107, 35]) == [35]
        assert candidate([156, 319, 2349, 5]) == [5, 319]
        assert candidate([12607, 2454, 115, 148]) == [115]
        assert candidate([13, 35, 1797, 4]) == [13, 35, 1797]
        assert candidate([12709, 2013, 109, 149]) == []
        assert candidate([148, 323, 1714, 14]) == []
        assert candidate([12345, 2033, 111, 151]) == [111, 151]
        assert candidate([12835, 1733, 115, 149]) == [115, 1733]
        assert candidate([138, 102, 33]) == [33]
        assert candidate([12, 31, 740, 6]) == [31]
        assert candidate([17, 36, 625, 6]) == [17]
        assert candidate([11466, 2311, 112, 150]) == []
        assert candidate([11998, 1341, 115, 155]) == [115, 155]

if __name__ == '__main__':
    unittest.main()
