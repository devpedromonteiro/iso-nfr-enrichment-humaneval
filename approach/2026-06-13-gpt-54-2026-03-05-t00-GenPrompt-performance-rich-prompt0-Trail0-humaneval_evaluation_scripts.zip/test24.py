
import unittest
import re
import sys
import math
import copy



def largest_divisor(n: int) -> int:
    """For a given number n, find the largest number that divides n evenly, smaller than n.

    >>> largest_divisor(15)
    5
    """
    if n <= 1:
        raise ValueError("n must be greater than 1")

    # The largest proper divisor is n divided by its smallest factor > 1.
    # Checking up to sqrt(n) minimizes work and avoids unnecessary allocations.
    if n % 2 == 0:
        return n // 2

    d = 3
    while d * d <= n:
        if n % d == 0:
            return n // d
        d += 2

    # n is prime
    return 1
candidate = largest_divisor




METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate(3) == 1
    assert candidate(7) == 1
    assert candidate(10) == 5
    assert candidate(100) == 50
    assert candidate(49) == 7


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
