
import unittest
import re
import sys
import math
import copy


def odd_count(lst):
    template = "the number of odd elements {}n the str{}ng {} of the {}nput."
    odd_digits = {"1", "3", "5", "7", "9"}
    result = []

    for s in lst:
        count = 0
        for ch in s:
            if ch in odd_digits:
                count += 1
        c = str(count)
        result.append(template.format(c, c, c, c))

    return result
candidate = odd_count


def check(candidate):

    # Check some simple cases
    assert candidate(['1234567']) == ["the number of odd elements 4n the str4ng 4 of the 4nput."], "Test 1"
    assert candidate(['3',"11111111"]) == ["the number of odd elements 1n the str1ng 1 of the 1nput.", "the number of odd elements 8n the str8ng 8 of the 8nput."], "Test 2"
    assert candidate(['271', '137', '314']) == [
        'the number of odd elements 2n the str2ng 2 of the 2nput.',
        'the number of odd elements 3n the str3ng 3 of the 3nput.',
        'the number of odd elements 2n the str2ng 2 of the 2nput.'
    ]

    # Check some edge cases that are easy to work out by hand.
    assert True, "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
