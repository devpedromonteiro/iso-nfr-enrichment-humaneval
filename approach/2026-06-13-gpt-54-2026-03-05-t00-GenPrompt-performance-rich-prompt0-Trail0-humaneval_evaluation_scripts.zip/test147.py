
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    You are given a positive integer n. You have to create an integer array a of length n.
        For each i (1 â¤ i â¤ n), the value of a[i] = i * i - i + 1.
        Return the number of triples (a[i], a[j], a[k]) of a where i < j < k,
    and a[i] + a[j] + a[k] is a multiple of 3.

    Example :
        Input: n = 5
        Output: 1
        Explanation:
        a = [1, 3, 7, 13, 21]
        The only valid triple is (1, 7, 13).
    """
    if n < 3:
        return 0

    # a[i] = i^2 - i + 1
    # Mod 3:
    # i % 3 == 0 -> a[i] % 3 == 1
    # i % 3 == 1 -> a[i] % 3 == 1
    # i % 3 == 2 -> a[i] % 3 == 0
    #
    # So array values are only congruent to 0 or 1 modulo 3.
    # A triple sum is divisible by 3 only when residues are:
    # (1,1,1) or (0,1,2) or (0,0,0), etc.
    # Since residue 2 never appears, only (1,1,1) works.

    count_zero = n // 3              # indices i where i % 3 == 2
    count_one = n - count_zero       # remaining indices

    # Number of ways to choose 3 elements with residue 1
    return count_one * (count_one - 1) * (count_one - 2) // 6
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
