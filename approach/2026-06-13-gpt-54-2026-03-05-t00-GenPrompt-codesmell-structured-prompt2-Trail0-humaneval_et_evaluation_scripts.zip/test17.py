
import unittest

from typing import List


from typing import List


NOTE_TO_BEATS = {
    "o": 4,
    "o|": 2,
    ".|": 1,
}


def parse_music(music_string: str) -> List[int]:
    """Parse a space-separated ASCII music string into note durations in beats.

    Legend:
    - 'o'  -> 4 beats
    - 'o|' -> 2 beats
    - '.|' -> 1 beat

    >>> parse_music('o o| .| o| o| .| .| .| .| o o')
    [4, 2, 1, 2, 2, 1, 1, 1, 1, 4, 4]
    """
    return [_parse_note(note) for note in music_string.split()]


def _parse_note(note: str) -> int:
    """Convert a single note token into its beat duration."""
    return NOTE_TO_BEATS[note]
candidate = parse_music


class Test(unittest.TestCase):
    def test(self):
        assert candidate(".| o .| o o o o| o| o| .| o o o .| .|") == [1, 4, 1, 4, 4, 4, 2, 2, 2, 1, 4, 4, 4, 1, 1]
        assert candidate(".| o o| o| o .| .| .| o .| o o| o| .| o| o o| o| .|") == [1, 4, 2, 2, 4, 1, 1, 1, 4, 1, 4, 2, 2, 1, 2, 4, 2, 2, 1]
        assert candidate("o| o o| .| .| .| .| o| o| .| o o| o| o| .| .| o|") == [2, 4, 2, 1, 1, 1, 1, 2, 2, 1, 4, 2, 2, 2, 1, 1, 2]
        assert candidate("o .| o .| o o o| o| o| o| o o .| o|") == [4, 1, 4, 1, 4, 4, 2, 2, 2, 2, 4, 4, 1, 2]
        assert candidate("o| o| o| o o o .| .| o o| o| o o| o o| o|") == [2, 2, 2, 4, 4, 4, 1, 1, 4, 2, 2, 4, 2, 4, 2, 2]
        assert candidate("o o| o .| o o| .| o| .| .| o o| o| o o| o| .|") == [4, 2, 4, 1, 4, 2, 1, 2, 1, 1, 4, 2, 2, 4, 2, 2, 1]
        assert candidate("o| .| .| o| o o o o o|") == [2, 1, 1, 2, 4, 4, 4, 4, 2]
        assert candidate("o o| o o o| .| o| o .|") == [4, 2, 4, 4, 2, 1, 2, 4, 1]
        assert candidate("o| o") == [2, 4]
        assert candidate("o o o| .| o| .| .| .| o| o o") == [4, 4, 2, 1, 2, 1, 1, 1, 2, 4, 4]
        assert candidate('o| o| .| .| o o o o') == [2, 2, 1, 1, 4, 4, 4, 4]
        assert candidate("o o o") == [4, 4, 4]
        assert candidate("o .| o| o| .| o .| o| .| o|") == [4, 1, 2, 2, 1, 4, 1, 2, 1, 2]
        assert candidate(".| .| o o| .| o .| o| o o| o o| o| .| o| o .|") == [1, 1, 4, 2, 1, 4, 1, 2, 4, 2, 4, 2, 2, 1, 2, 4, 1]
        assert candidate("o") == [4]
        assert candidate("o| .| o o| .| .| o .| o .| o .| .| o o .|") == [2, 1, 4, 2, 1, 1, 4, 1, 4, 1, 4, 1, 1, 4, 4, 1]
        assert candidate(".| o| .| o| o .| o| o| .| o| o| o| .| o|") == [1, 2, 1, 2, 4, 1, 2, 2, 1, 2, 2, 2, 1, 2]
        assert candidate(".| .|") == [1, 1]
        assert candidate(".| .| o .| o| o o| o o| o .| .| o o o .| o") == [1, 1, 4, 1, 2, 4, 2, 4, 2, 4, 1, 1, 4, 4, 4, 1, 4]
        assert candidate("o o .| o| o o o o o o| o o| .| o") == [4, 4, 1, 2, 4, 4, 4, 4, 4, 2, 4, 2, 1, 4]
        assert candidate(".| o o| .| .|") == [1, 4, 2, 1, 1]
        assert candidate(".| o o| o| .| o .| .| o") == [1, 4, 2, 2, 1, 4, 1, 1, 4]
        assert candidate("o| o o| .| .| o o o| .| o .| o| o") == [2, 4, 2, 1, 1, 4, 4, 2, 1, 4, 1, 2, 4]
        assert candidate("o| o o| o| .| .| .| .| o|") == [2, 4, 2, 2, 1, 1, 1, 1, 2]
        assert candidate("o|") == [2]
        assert candidate("o| o o o o o o .| o| o| o") == [2, 4, 4, 4, 4, 4, 4, 1, 2, 2, 4]
        assert candidate("o| o| o| o o o o o| .|") == [2, 2, 2, 4, 4, 4, 4, 2, 1]
        assert candidate('o| .| o| .| o o| o o|') == [2, 1, 2, 1, 4, 2, 4, 2]
        assert candidate("o| o| .| .| o| .| o| o o| .| o| o| o|") == [2, 2, 1, 1, 2, 1, 2, 4, 2, 1, 2, 2, 2]
        assert candidate("o| .| .| o .| o") == [2, 1, 1, 4, 1, 4]
        assert candidate("o o o .| o| o| o") == [4, 4, 4, 1, 2, 2, 4]
        assert candidate("o| .| o| .| o| o| o| .| o| .| o| o| o| o .| o o| o|") == [2, 1, 2, 1, 2, 2, 2, 1, 2, 1, 2, 2, 2, 4, 1, 4, 2, 2]
        assert candidate("o| o| o o| o| o o| o| .| .| o o .| .| o o o .|") == [2, 2, 4, 2, 2, 4, 2, 2, 1, 1, 4, 4, 1, 1, 4, 4, 4, 1]
        assert candidate(".| o| .| o o .| .| o o| o| o o| .| .| .|") == [1, 2, 1, 4, 4, 1, 1, 4, 2, 2, 4, 2, 1, 1, 1]
        assert candidate(".|") == [1]
        assert candidate("o| .| o| o| o| o| o .|") == [2, 1, 2, 2, 2, 2, 4, 1]
        assert candidate(".| .| o o .| o|") == [1, 1, 4, 4, 1, 2]
        assert candidate("o o o .| o o| o| o .| o o o .| o o| o o") == [4, 4, 4, 1, 4, 2, 2, 4, 1, 4, 4, 4, 1, 4, 2, 4, 4]
        assert candidate(".| o") == [1, 4]
        assert candidate("o| .| o| o| o| o| o| o| o| .| o| o| o .| o o| .| o o|") == [2, 1, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 4, 1, 4, 2, 1, 4, 2]
        assert candidate("o o o| o") == [4, 4, 2, 4]
        assert candidate("o| o .| o| o| o| o .| .| o| .| o| .|") == [2, 4, 1, 2, 2, 2, 4, 1, 1, 2, 1, 2, 1]
        assert candidate("o o o o| o| o o| o") == [4, 4, 4, 2, 2, 4, 2, 4]
        assert candidate("o| .| o| o o o| o o o| o .| .| .| o .|") == [2, 1, 2, 4, 4, 2, 4, 4, 2, 4, 1, 1, 1, 4, 1]
        assert candidate(".| .| o| o| o o o| o| o o| o o .| .| o o o") == [1, 1, 2, 2, 4, 4, 2, 2, 4, 2, 4, 4, 1, 1, 4, 4, 4]
        assert candidate(".| o| o .| o|") == [1, 2, 4, 1, 2]
        assert candidate("o| o .| o o| .|") == [2, 4, 1, 4, 2, 1]
        assert candidate(".| o .| o .| o| .| o .| o|") == [1, 4, 1, 4, 1, 2, 1, 4, 1, 2]
        assert candidate("o| o| o|") == [2, 2, 2]
        assert candidate(".| o| o .| .|") == [1, 2, 4, 1, 1]
        assert candidate("o| .| .| .| .|") == [2, 1, 1, 1, 1]
        assert candidate("o o| o o .| o| o|") == [4, 2, 4, 4, 1, 2, 2]
        assert candidate(".| o| o o .| .| .| o .| o| .| .| .| o| o| o o .| .|") == [1, 2, 4, 4, 1, 1, 1, 4, 1, 2, 1, 1, 1, 2, 2, 4, 4, 1, 1]
        assert candidate(".| .| o| o o o .| o|") == [1, 1, 2, 4, 4, 4, 1, 2]
        assert candidate("o| .| o| o| .| o| o| o .| .| .| o| o o| .| o .| .|") == [2, 1, 2, 2, 1, 2, 2, 4, 1, 1, 1, 2, 4, 2, 1, 4, 1, 1]
        assert candidate("o .| .| o .| o| .| o|") == [4, 1, 1, 4, 1, 2, 1, 2]
        assert candidate("o .| .|") == [4, 1, 1]
        assert candidate("o| .| o| o") == [2, 1, 2, 4]
        assert candidate(".| o .| o o| .| o o o|") == [1, 4, 1, 4, 2, 1, 4, 4, 2]
        assert candidate(".| .| o| .| .| o| o| .| o| o o| .| .| .|") == [1, 1, 2, 1, 1, 2, 2, 1, 2, 4, 2, 1, 1, 1]
        assert candidate(".| o| o|") == [1, 2, 2]
        assert candidate("o .| o o| .| o| .| o o| .| o") == [4, 1, 4, 2, 1, 2, 1, 4, 2, 1, 4]
        assert candidate("o o o| o| o| o| o| o| o|") == [4, 4, 2, 2, 2, 2, 2, 2, 2]
        assert candidate(".| o| o| o| o o| o| o| o| o o| .| o") == [1, 2, 2, 2, 4, 2, 2, 2, 2, 4, 2, 1, 4]
        assert candidate("o .|") == [4, 1]
        assert candidate(".| .| o .| o| .| o .| o| o o| o|") == [1, 1, 4, 1, 2, 1, 4, 1, 2, 4, 2, 2]
        assert candidate("o .| o o .| o o| o| o o .|") == [4, 1, 4, 4, 1, 4, 2, 2, 4, 4, 1]
        assert candidate("o| o .| .| o .| o o| .| o o| o| o") == [2, 4, 1, 1, 4, 1, 4, 2, 1, 4, 2, 2, 4]
        assert candidate("o o| .| .| o| .| .| .|") == [4, 2, 1, 1, 2, 1, 1, 1]
        assert candidate("o o| .| .|") == [4, 2, 1, 1]
        assert candidate(".| o| o o .| o|") == [1, 2, 4, 4, 1, 2]
        assert candidate('.| .| .| .|') == [1, 1, 1, 1]
        assert candidate(".| .| .| o| .| o| .| o o| o") == [1, 1, 1, 2, 1, 2, 1, 4, 2, 4]
        assert candidate("o| o| o| o .| o o| o|") == [2, 2, 2, 4, 1, 4, 2, 2]
        assert candidate(".| .| .| o .| .| o| o o .| o| o o .| o| o| .|") == [1, 1, 1, 4, 1, 1, 2, 4, 4, 1, 2, 4, 4, 1, 2, 2, 1]
        assert candidate(".| o| o") == [1, 2, 4]
        assert candidate("o| o| .| o .|") == [2, 2, 1, 4, 1]
        assert candidate(".| .| o o| .| o o .| o| o .| o o| .| o o| o o| o o") == [1, 1, 4, 2, 1, 4, 4, 1, 2, 4, 1, 4, 2, 1, 4, 2, 4, 2, 4, 4]
        assert candidate("o .| o|") == [4, 1, 2]
        assert candidate(".| o o| o") == [1, 4, 2, 4]
        assert candidate("o| .| o| .| o o o| .|") == [2, 1, 2, 1, 4, 4, 2, 1]
        assert candidate('o o o o') == [4, 4, 4, 4]
        assert candidate("o| .| o o| .| o .| o o .| o| .| o| o| .|") == [2, 1, 4, 2, 1, 4, 1, 4, 4, 1, 2, 1, 2, 2, 1]
        assert candidate(".| o| .| o| o| .| o .| o") == [1, 2, 1, 2, 2, 1, 4, 1, 4]
        assert candidate('') == []
        assert candidate(".| o o o .|") == [1, 4, 4, 4, 1]
        assert candidate(".| .| o| .| o|") == [1, 1, 2, 1, 2]
        assert candidate("o o o .| o|") == [4, 4, 4, 1, 2]
        assert candidate(".| .| o o| o| .| o .| .| o .| .| .| o|") == [1, 1, 4, 2, 2, 1, 4, 1, 1, 4, 1, 1, 1, 2]
        assert candidate("o o .|") == [4, 4, 1]
        assert candidate(".| o o o o o o o o| .| o o .| o o| o|") == [1, 4, 4, 4, 4, 4, 4, 4, 2, 1, 4, 4, 1, 4, 2, 2]
        assert candidate("o| o .| o|") == [2, 4, 1, 2]
        assert candidate(".| .| o o| o o o o o| .| .| o| .| .| o| .| o| .| o|") == [1, 1, 4, 2, 4, 4, 4, 4, 2, 1, 1, 2, 1, 1, 2, 1, 2, 1, 2]
        assert candidate("o o .| o| o o o o| .| o o o o| o .|") == [4, 4, 1, 2, 4, 4, 4, 2, 1, 4, 4, 4, 2, 4, 1]
        assert candidate("o o o o| o o|") == [4, 4, 4, 2, 4, 2]
        assert candidate("o .| o o| o o o o o| .| o o o| .|") == [4, 1, 4, 2, 4, 4, 4, 4, 2, 1, 4, 4, 2, 1]
        assert candidate(".| o| o o o| o o|") == [1, 2, 4, 4, 2, 4, 2]
        assert candidate("o o| o| .|") == [4, 2, 2, 1]
        assert candidate(".| o| o| .| o o| o o| o o .| o| o| o| o o .|") == [1, 2, 2, 1, 4, 2, 4, 2, 4, 4, 1, 2, 2, 2, 4, 4, 1]
        assert candidate(".| o| .| o .| o| o o .| o| o| o o .| o o .|") == [1, 2, 1, 4, 1, 2, 4, 4, 1, 2, 2, 4, 4, 1, 4, 4, 1]
        assert candidate(".| o| o o| o") == [1, 2, 4, 2, 4]
        assert candidate("o| o| o .| o| o o o| o o .|") == [2, 2, 4, 1, 2, 4, 4, 2, 4, 4, 1]
        assert candidate(".| o o| .| o o o o| o .| o") == [1, 4, 2, 1, 4, 4, 4, 2, 4, 1, 4]
        assert candidate(".| o| .| o .| o .| .| o .| o o o .| o o .| .|") == [1, 2, 1, 4, 1, 4, 1, 1, 4, 1, 4, 4, 4, 1, 4, 4, 1, 1]
        assert candidate("o .| o| o|") == [4, 1, 2, 2]
        assert candidate(".| o| o| .| o") == [1, 2, 2, 1, 4]
        assert candidate("o| o o| o") == [2, 4, 2, 4]
        assert candidate("o o o o o o| .| o| o .| o o|") == [4, 4, 4, 4, 4, 2, 1, 2, 4, 1, 4, 2]
        assert candidate(".| o| o o|") == [1, 2, 4, 2]
        assert candidate("o| o o|") == [2, 4, 2]
        assert candidate("o o|") == [4, 2]
        assert candidate("o .| .| o") == [4, 1, 1, 4]
        assert candidate(".| .| .| .| o| .| .| o o .| o| o .|") == [1, 1, 1, 1, 2, 1, 1, 4, 4, 1, 2, 4, 1]
        assert candidate("o o o o| o| .| o o| o o .| o .| o|") == [4, 4, 4, 2, 2, 1, 4, 2, 4, 4, 1, 4, 1, 2]
        assert candidate("o o| o| .| .| o| o|") == [4, 2, 2, 1, 1, 2, 2]
        assert candidate(".| o| .| .| .| o .| o| o| o o .| o") == [1, 2, 1, 1, 1, 4, 1, 2, 2, 4, 4, 1, 4]
        assert candidate("o o o .| o o| o| o o .| o| o| o| o") == [4, 4, 4, 1, 4, 2, 2, 4, 4, 1, 2, 2, 2, 4]
        assert candidate("o| .| o| o| .| o| .| o .| .| .| .| o o o| o") == [2, 1, 2, 2, 1, 2, 1, 4, 1, 1, 1, 1, 4, 4, 2, 4]
        assert candidate("o o| .| o| o .| o o| o| o o| o o") == [4, 2, 1, 2, 4, 1, 4, 2, 2, 4, 2, 4, 4]
        assert candidate("o| o .| .| o| .| o| o| o") == [2, 4, 1, 1, 2, 1, 2, 2, 4]
        assert candidate("o o o| o o o| o") == [4, 4, 2, 4, 4, 2, 4]
        assert candidate("o o o| .| o") == [4, 4, 2, 1, 4]
        assert candidate("o .| o| o .| .| .| o o| o") == [4, 1, 2, 4, 1, 1, 1, 4, 2, 4]
        assert candidate(".| o| .|") == [1, 2, 1]
        assert candidate("o| o|") == [2, 2]
        assert candidate(".| .| .| o| o| o o .| o o .| o") == [1, 1, 1, 2, 2, 4, 4, 1, 4, 4, 1, 4]
        assert candidate("o| o o .| o o| o| o o| o o .|") == [2, 4, 4, 1, 4, 2, 2, 4, 2, 4, 4, 1]
        assert candidate("o| o| .| o| .| o o o o| o o| o| .| o o o o|") == [2, 2, 1, 2, 1, 4, 4, 4, 2, 4, 2, 2, 1, 4, 4, 4, 2]
        assert candidate("o o .| o") == [4, 4, 1, 4]

if __name__ == '__main__':
    unittest.main()
