
import unittest


import math


def _is_valid_triangle(a, b, c):
    return a + b > c and a + c > b and b + c > a


def _heron_area(a, b, c):
    semi_perimeter = (a + b + c) / 2
    area = math.sqrt(
        semi_perimeter
        * (semi_perimeter - a)
        * (semi_perimeter - b)
        * (semi_perimeter - c)
    )
    return round(area, 2)


def triangle_area(a, b, c):
    '''
    Given the lengths of the three sides of a triangle. Return the area of
    the triangle rounded to 2 decimal points if the three sides form a valid triangle. 
    Otherwise return -1
    Three sides make a valid triangle when the sum of any two sides is greater 
    than the third side.
    Example:
    triangle_area(3, 4, 5) == 6.00
    triangle_area(1, 2, 10) == -1
    '''
    if not _is_valid_triangle(a, b, c):
        return -1

    return _heron_area(a, b, c)
candidate = triangle_area


class Test(unittest.TestCase):
    def test(self):
        assert candidate(2, 9, 3) == -1
        assert candidate(7, 1, 4) == -1
        assert candidate(1, 5, 8) == -1
        assert candidate(6, 1, 6) == 2.99
        assert candidate(1, 2, 11) == -1
        assert candidate(6, 6, 2) == 5.92
        assert candidate(9, 12, 1) == -1
        assert candidate(4, 7, 6) == 11.98
        assert candidate(2, 2, 2) == 1.73
        assert candidate(5, 5, 2) == 4.9
        assert candidate(5, 1, 6) == -1
        assert candidate(1, 4, 10) == -1
        assert candidate(7, 5, 6) == 14.7
        assert candidate(3, 6, 7) == 8.94
        assert candidate(15, 4, 7) == -1
        assert candidate(3, 4, 10) == -1
        assert candidate(2, 3, 6) == -1
        assert candidate(2, 4, 7) == -1
        assert candidate(1, 2, 10) == -1
        assert candidate(7, 1, 6) == -1
        assert candidate(2, 2, 8) == -1
        assert candidate(3, 8, 5) == -1
        assert candidate(2, 7, 3) == -1
        assert candidate(3, 6, 15) == -1
        assert candidate(5, 8, 5) == 12.0
        assert candidate(5, 5, 6) == 12.0
        assert candidate(5, 6, 7) == 14.7
        assert candidate(1, 12, 6) == -1
        assert candidate(7, 8, 5) == 17.32
        assert candidate(4, 2, 2) == -1
        assert candidate(4, 2, 1) == -1
        assert candidate(6, 5, 5) == 12.0
        assert candidate(2, 3, 3) == 2.83
        assert candidate(4, 2, 5) == 3.8
        assert candidate(7, 5, 4) == 9.8
        assert candidate(4, 8, 5) == 8.18
        assert candidate(4, 6, 4) == 7.94
        assert candidate(10, 2, 2) == -1
        assert candidate(2, 3, 8) == -1
        assert candidate(9, 9, 1) == 4.49
        assert candidate(1, 4, 6) == -1
        assert candidate(3, 4, 5) == 6.00
        assert candidate(1, 5, 11) == -1
        assert candidate(13, 4, 10) == 14.98
        assert candidate(2, 6, 3) == -1

    # Check some edge cases that are easy to work out by hand.
        assert candidate(6, 3, 5) == 7.48
        assert candidate(10, 5, 7) == 16.25
        assert candidate(6, 6, 3) == 8.71
        assert candidate(1, 1, 5) == -1
        assert candidate(11, 6, 3) == -1
        assert candidate(4, 3, 3) == 4.47
        assert candidate(12, 4, 9) == 13.64
        assert candidate(3, 1, 3) == 1.48
        assert candidate(5, 4, 6) == 9.92
        assert candidate(6, 4, 4) == 7.94
        assert candidate(4, 7, 9) == 13.42
        assert candidate(4, 6, 1) == -1
        assert candidate(1, 7, 11) == -1
        assert candidate(2, 6, 9) == -1
        assert candidate(1, 1, 1) == 0.43
        assert candidate(5, 2, 10) == -1
        assert candidate(4, 7, 15) == -1
        assert candidate(7, 6, 5) == 14.7
        assert candidate(1, 2, 2) == 0.97
        assert candidate(7, 3, 6) == 8.94
        assert candidate(9, 9, 2) == 8.94
        assert candidate(3, 7, 9) == 8.79
        assert candidate(4, 3, 1) == -1
        assert candidate(8, 6, 11) == 23.42
        assert candidate(2, 6, 1) == -1
        assert candidate(4, 7, 7) == 13.42
        assert candidate(2, 3, 5) == -1
        assert candidate(2, 3, 9) == -1
        assert candidate(4, 3, 7) == -1
        assert candidate(3, 5, 6) == 7.48
        assert candidate(3, 1, 2) == -1
        assert candidate(1, 4, 5) == -1
        assert candidate(6, 10, 10) == 28.62
        assert candidate(4, 3, 6) == 5.33
        assert candidate(6, 7, 8) == 20.33
        assert candidate(1, 12, 1) == -1
        assert candidate(3, 3, 3) == 3.9
        assert candidate(6, 8, 7) == 20.33
        assert candidate(8, 3, 5) == -1
        assert candidate(2, 1, 2) == 0.97
        assert candidate(3, 7, 3) == -1
        assert candidate(1, 2, 3) == -1
        assert candidate(6, 3, 2) == -1
        assert candidate(1, 11, 5) == -1
        assert candidate(2, 4, 3) == 2.9
        assert candidate(2, 2, 10) == -1
        assert candidate(2, 1, 3) == -1
        assert candidate(2, 6, 8) == -1
        assert candidate(4, 2, 6) == -1
        assert candidate(1, 5, 3) == -1
        assert candidate(5, 11, 2) == -1
        assert candidate(3, 4, 6) == 5.33
        assert candidate(4, 3, 4) == 5.56
        assert candidate(6, 5, 3) == 7.48
        assert candidate(1, 5, 2) == -1
        assert candidate(6, 3, 4) == 5.33
        assert candidate(4, 2, 9) == -1
        assert candidate(3, 7, 1) == -1
        assert candidate(2, 7, 7) == 6.93
        assert candidate(6, 7, 12) == 14.95
        assert candidate(1, 3, 6) == -1
        assert candidate(3, 1, 7) == -1
        assert candidate(4, 6, 2) == -1
        assert candidate(4, 10, 9) == 17.98
        assert candidate(1, 1, 7) == -1
        assert candidate(5, 6, 3) == 7.48
        assert candidate(3, 2, 9) == -1
        assert candidate(9, 10, 4) == 17.98
        assert candidate(3, 7, 13) == -1

if __name__ == '__main__':
    unittest.main()
