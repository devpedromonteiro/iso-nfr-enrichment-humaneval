
import unittest
import re
import sys
import math
import copy


def get_max_triples(n):
    """
    You are given a positive integer n. Create an array a of length n where:
        a[i] = i*i - i + 1   for 1 <= i <= n

    Return the number of triples (a[i], a[j], a[k]) such that:
        i < j < k
        and (a[i] + a[j] + a[k]) is divisible by 3.

    Example:
        n = 5
        a = [1, 3, 7, 13, 21]
        Valid triple count = 1
    """
    def comb3(x):
        return x * (x - 1) * (x - 2) // 6 if x >= 3 else 0

    count_mod = [0, 0, 0]

    for i in range(1, n + 1):
        value_mod = (i * i - i + 1) % 3
        count_mod[value_mod] += 1

    c0, c1, c2 = count_mod

    return (
        comb3(c0) +          # (0, 0, 0)
        comb3(c1) +          # (1, 1, 1)
        comb3(c2) +          # (2, 2, 2)
        c0 * c1 * c2         # (0, 1, 2)
    )
candidate = get_max_triples


def check(candidate):

    assert candidate(5) == 1
    assert candidate(6) == 4
    assert candidate(10) == 36
    assert candidate(100) == 53361


class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
