
import unittest
import re
import sys
import math
import copy


def even_odd_palindrome(n):
    """
    Given a positive integer n, return a tuple containing the number of even and odd
    integer palindromes in the range [1, n].

    Example:
        even_odd_palindrome(3) -> (1, 2)
        even_odd_palindrome(12) -> (4, 6)
    """
    even_count = 0
    odd_count = 0

    for number in range(1, n + 1):
        text = str(number)
        if text == text[::-1]:
            if number % 2 == 0:
                even_count += 1
            else:
                odd_count += 1

    return even_count, odd_count
candidate = even_odd_palindrome


def check(candidate):

    # Check some simple cases
    assert candidate(123) == (8, 13)
    assert candidate(12) == (4, 6)
    assert candidate(3) == (1, 2)
    assert candidate(63) == (6, 8)
    assert candidate(25) == (5, 6)
    assert candidate(19) == (4, 6)
    assert candidate(9) == (4, 5), "This prints if this assert fails 1 (good for debugging!)"

    # Check some edge cases that are easy to work out by hand.
    assert candidate(1) == (0, 1), "This prints if this assert fails 2 (also good for debugging!)"



class Test(unittest.TestCase):
    def test(self):
        check(candidate)

if __name__ == '__main__':
    unittest.main()
